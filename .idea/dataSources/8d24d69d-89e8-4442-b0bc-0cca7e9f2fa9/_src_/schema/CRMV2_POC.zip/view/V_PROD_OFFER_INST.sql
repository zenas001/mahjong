CREATE VIEW V_PROD_OFFER_INST AS select a.prod_offer_inst_id, a.prod_offer_id, a.cust_id, a.channel_id,
       a.create_date, a.status_cd, a.status_date, a.eff_date, a.exp_date,
       a.region, a.update_date, a.proc_serial, a.ext_prod_offer_inst_id,
       a.area_id, a.region_cd, a.update_staff, a.create_staff,
       a.trial_eff_date, a.trial_exp_date, a.rec_update_date,a.DISTRIBUTOR_ID, b.offer_type,
       b.offer_sub_type,b.ibs_offer_type
  from prod_offer_inst a, prod_offer b
 where a.prod_offer_id = b.prod_offer_id
/
