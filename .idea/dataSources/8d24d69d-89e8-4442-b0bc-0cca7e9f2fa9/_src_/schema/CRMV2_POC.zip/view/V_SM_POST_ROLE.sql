CREATE VIEW V_SM_POST_ROLE AS select
null POST_ID,
null ROLE_ID
from dual
/
