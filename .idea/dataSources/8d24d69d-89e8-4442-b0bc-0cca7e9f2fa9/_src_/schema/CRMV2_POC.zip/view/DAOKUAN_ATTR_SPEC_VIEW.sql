CREATE VIEW DAOKUAN_ATTR_SPEC_VIEW AS select distinct attr_name ,attr_cd from   DAOKUAN_ATTR_SPEC
/
