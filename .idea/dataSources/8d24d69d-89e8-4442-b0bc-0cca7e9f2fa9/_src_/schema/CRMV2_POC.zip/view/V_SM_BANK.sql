CREATE VIEW V_SM_BANK AS select
a.bank_area_id AREA_ID,
a.bank_name NAME,
a.bank_code CODE,
a.state_cd STATE,
a.bank_id BANK_ID,
a.parent_bank_id SUPER,
a.accp_bank ACCP_BANK,
a.account_id ZHID,
a.account_type ZH_TYPE
from   bank a
/
