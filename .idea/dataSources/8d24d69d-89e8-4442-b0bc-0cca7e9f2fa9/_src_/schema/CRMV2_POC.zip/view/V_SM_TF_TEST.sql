CREATE VIEW V_SM_TF_TEST AS select a.staff_position_id TFID,
       b.org_type TFLX,
       a.org_id TFTE,
       decode(a.status_cd, '1000', '10A', '10X') TFZT,
       a.create_date CREATE_DATE,
       c.staff_code GHGH,
       a.create_staff CREATER
  from staff_position a, organization b, staff c, position d
 where a.position_id = d.position_id
   AND d.position_sort = '11'
   and a.STAFF_ID = c.STAFF_ID
   and a.ORG_ID = b.ORG_ID
/
