CREATE VIEW V_SM_GW AS select a.position_id   GWID,
         a.position_name GWMC,
         a.position_type GWLX,
         decode(a.status_cd, '1000', '10A', '10X') STATE,
         a.position_desc REMARK
    from position a
/
