CREATE VIEW WEIHU_NETWORK_EVALUATE_VIEW AS select e."TABLE_ID1",e."TABLE_VALUE1",e."TABLE_ID2",e."TABLE_VALUE2",e."TABLE_ID3",e."TABLE_VALUE3",e."TABLE_ID4",e."TABLE_VALUE4",e."DATA_INDEX",e."TABLE_VALUE",e."TARGET_VALUE",e."PRIORITY",e."CONTACT",e."FF_MAINTAIN",e."PROVINCE_MAINTAIN",f.result,f.remark,f.pro_num,f.update_value,f.update_percent,f.state
  from (select a.table_id table_id1,
               a.table_value table_value1,
               b.table_id table_id2,
               b.table_value table_value2,
               c.table_id table_id3,
               c.table_value table_value3,
               d.table_id table_id4,
               d.table_value table_value4,
               d.data_index,
               d.table_value,
               d.target_value,
               d.priority,
               d.contact,
               d.ff_maintain,
               d.province_maintain
          from weihu_network_evaluate_table a,
               weihu_network_evaluate_table b,
               weihu_network_evaluate_table c,
               weihu_network_evaluate_table d
         where b.parent = a.table_id
           and c.parent = b.table_id
           and d.parent = c.table_id
           and a.parent = 0
         order by a.orders, b.orders, c.orders, d.orders) e
  left join (select * from  weihu_network_evaluate_data b where
    trunc(update_date) = trunc(sysdate)-1) f on e.data_index=f.data_index
/
