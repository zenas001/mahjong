CREATE VIEW PROD_ZJ AS select prod_inst_id,attr_value
     from prod_inst_attr
     where attr_id=910000164 and status_cd<>'1100'
/
