CREATE VIEW V_SM_INDUSTRY AS select a.attr_value_id id,
       (select d.attr_value from attr_value d where d.attr_value_id = a.parent_value_id) UP_LEVEL_CODE,
       a.attr_value INDUSTRY_CODE,
       a.attr_value_name INDUSTRY_NAME,
       null INDUSTRY_EXPLAIN,
       null INDUSTRY_NOTE,
       (select substr(b.attr_value, 1, 1)
          from attr_value b
         where b.attr_value_id = a.attr_value_id) INDUSTRY_SORT_CODE,
         nvl(
              (select e.attr_value_name
                 from attr_value e
                where e.attr_value_id = a.parent_value_id),null)
             UP_LEVEL_NAME,
       (select c.attr_value_name
          from attr_value c
         where c.attr_value =
               (select substr(b.attr_value, 1, 1)
                  from attr_value b
                 where b.attr_value_id = a.attr_value_id)
           and c.attr_id in (select a.attr_id
                               from attr_spec a
                              where a.class_id = 1
                                and a.java_code = 'industryCd')) INDUSTRY_SORT_NAME
  from attr_value a
 where a.attr_id in (select a.attr_id
                       from attr_spec a
                      where a.class_id = 1
                        and a.java_code = 'industryCd')
/
