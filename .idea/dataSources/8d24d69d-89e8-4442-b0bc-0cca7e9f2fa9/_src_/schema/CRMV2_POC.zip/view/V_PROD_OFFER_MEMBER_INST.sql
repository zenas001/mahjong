CREATE VIEW V_PROD_OFFER_MEMBER_INST AS select a.MEMBER_INST_ID,a.PROD_OFFER_INST_ID,a.MEMBER_ID,a.PROD_OFFER_MEMBER_ID,a.STATUS_CD,a.STATUS_DATE,a.CREATE_DATE,a.EFF_DATE,a.EXP_DATE,a.AREA_ID,a.REGION_CD,a.CREATE_STAFF,a.UPDATE_DATE,a.UPDATE_STAFF,a.ROLE_CD,a.REC_UPDATE_DATE,a.BANK_ID,a.BANK_ACCOUNT,b.prod_offer_member_inst_id as ext_key_id,c.class_id
  from prod_offer_member_inst a, prod_offer_member_inst_ext b,prod_offer_member          c
 where a.member_inst_id = b.prod_offer_member_inst_id(+) and c.prod_offer_member_id = a.prod_offer_member_id
/
