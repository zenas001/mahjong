CREATE VIEW V_SM_ZH AS select
a.payment_plan ZHID,
a.payment_bank_id ZHYH,
a.payment_account_name ZHMC,
a.payment_account ZHZH,
a.payment_method_id ZHLX,
null ZHZX,
null ZHDL,
null ZHDX,
(select b.cust_id from account b where b.account_id=a.account_id and rownum<2)ZHKH,
a.create_date ZHRQ,
a.status_date ZHGR,
decode(a.status_cd,'1000','10A','10X') ZHZT,
null ZHYB,
a.region_cd REGION,
a.update_date REAL_MODIFY_DATE,
a.acc_agreement_code ACC_AGREEMENT_CODE,
a.send_entrust_method SEND_METHOD_TYPE,
a.entrust_type ENTRUST_TYPE
from payment_plan a
/
