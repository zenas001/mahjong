CREATE VIEW V_SM_CY AS SELECT a.party_name AS cymc,
       (select b.cert_type from party_certification b where b.party_id=a.party_id and rownum<2) cyzl,
       (select b.cert_number from party_certification b where b.party_id=a.party_id and rownum<2)  cymk,
       (select b.cert_address from party_certification b where b.party_id=a.party_id and rownum<2) cydz,
      /* (select c.cust_address_id from cust c where a.party_id=c.party_id and rownum<2) cydx,*/
      (select f.post_address from party_contact_info f where a.party_id = f.party_id and rownum<2) cydx,
       --b.cert_type AS cyzl, b.cert_type AS cymk,
       --c.cust_address cydz, c.cust_address_id cydx,
       a.english_name cypm,a.party_abbrname cyjp, NULL cycs,
       (SELECT e.nationality FROM individual e where e.party_id=a.party_id and rownum<2) cygj,
       --d.nationality cygj,
       NULL cyhy, a.party_type cylx, NULL cycm, NULL cyyy, a.create_date cyrq,
       a.update_date cygr, decode(a.status_cd, '1000', '10A', '10X') cyzt,
       (select f.postcode from party_contact_info f where a.party_id = f.party_id and rownum<2) cyyb,
       --e.postcode cyyb,
       a.party_id cyid,
       (select b.cert_address from party_certification b where b.party_id=a.party_id and rownum<2) identify_addr,
       --b.cert_address identify_addr,
       a.region_cd region, a.update_date real_modify_date, a.cert_check_result check_result
  FROM party a
/
