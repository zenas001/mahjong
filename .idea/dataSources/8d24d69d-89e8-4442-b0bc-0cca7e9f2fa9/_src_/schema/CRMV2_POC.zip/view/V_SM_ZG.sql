CREATE VIEW V_SM_ZG AS select
a.prod_inst_acct_id ZGID,
a.prod_inst_id ZGZR,
a.account_id ZGZH,
a.acct_item_type_group_id ZGZL,
a.payment_limit_type ZGFF,
a.payment_limit ZGXE,
a.priority ZGXS,
a.create_date ZGRQ,
a.status_date ZGGR,
a.status_cd ZGZT,
a.charge_type ZGFG,
null ZGTL,
a.invoice_formart_flag ZGFP,
a.area_id ZGQY,
null ZGFL,
a.update_date REAL_MODIFY_DATE
from PROD_INST_ACCT a
/
