CREATE VIEW V_SM_MDSE AS select
a.prod_offer_inst_id MDSE_ID,
a.prod_offer_id MDSE_SPEC_ID,
a.cust_id PROPERTY_CUSTID,
a.create_date CREATE_DATE,
a.exp_date EXP_DATE,
decode(a.status_cd,'1000','70A','1097','70N','70R') STATE,
(select b.prod_inst_id from Offer_Prod_Inst_Rel b where b.prod_offer_inst_id = a.prod_offer_inst_id and rownum<2) PROD_ID,
null PROD_FEA_ID,
(select c.offer_type from prod_offer c where c.prod_offer_id = a.prod_offer_id and rownum<2) MDSE_TYPE,
a.status_date MODIFY_DATE,
a.region REGION,
null MDSE_SERV_NUMBER,
a.eff_date EFF_DATE,
null ATTR_SORT,
a.trial_eff_date TRIAL_EFF_DATE,
a.trial_exp_date TRIAL_EXP_DATE,
a.update_date REAL_MODIFY_DATE,
null VER_DATE,
null WH_REMARK,
null JT_MDSE_SPEC
from prod_offer_inst a
/
