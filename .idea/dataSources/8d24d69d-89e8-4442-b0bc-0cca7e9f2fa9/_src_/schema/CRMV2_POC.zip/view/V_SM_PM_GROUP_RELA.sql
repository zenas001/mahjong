CREATE VIEW V_SM_PM_GROUP_RELA AS select
null RELA_ID,
a.prod_offer_inst_id GROUP_ID,
b.class_id OBJ_TYPE,
a.member_id OBJ_VALUE,
a.create_date CREATE_DATE,
a.status_date MODIFY_DATE,
a.region_cd REGION,
a.status_cd STATE,
a.role_cd OBJ_ROLE,
null REAL_MODIFY_DATE,
a.exp_date EXP_DATE,
a.eff_date EFF_DATE,
null BANK_ID,
null BANK_ACCOUNT
from prod_offer_member_inst a,prod_offer_member b
where a.prod_offer_member_id = b.prod_offer_member_id
/
