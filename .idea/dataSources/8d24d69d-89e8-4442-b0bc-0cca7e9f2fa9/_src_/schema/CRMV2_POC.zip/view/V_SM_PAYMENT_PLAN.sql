CREATE VIEW V_SM_PAYMENT_PLAN AS select
a.payment_plan  PAYMENT_PLAN_ID,
a.proportion PROPORTION,
a.limitation LIMITATION,
null  CUST_ACCT_ID,
a.account_id TEL_ACCT_ID,
a.priority PRIORITY,
a.create_date CREATE_DATE,
a.status_date MODIFY_DATE,
a.status_cd STATE,
a.area_id REGION,
a.update_date REAL_MODIFY_DATE
from payment_plan a
/
