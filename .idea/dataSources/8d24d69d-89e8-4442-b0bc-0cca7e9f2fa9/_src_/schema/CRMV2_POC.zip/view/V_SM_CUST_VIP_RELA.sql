CREATE VIEW V_SM_CUST_VIP_RELA AS select null AREA_CODE,a.area_id  AREA_ID,
a.cust_id CUST_ID ,a.update_date REAL_MODIFY_DATE ,
b.member_code  VIP_NBR
from cust a ,club_member b where a.cust_id = b.cust_id
/
