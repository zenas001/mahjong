CREATE VIEW V_SM_KH_STRATEGIC AS select
null STRATEGIC_ID,
null KHID,
null SUB_OBJ_TYPE,
null SUB_OBJ_ID,
null STATE,
null CREATE_DATE,
null MODIFY_DATE,
null REAL_DATE ,
null ISMAIN
    from dual  a
/
