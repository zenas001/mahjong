CREATE VIEW V_SM_P_POPEDOM_FORMULA AS select
null ID,
null POPEDOM_ID,
null FORMULA_ID
from dual  a
/
