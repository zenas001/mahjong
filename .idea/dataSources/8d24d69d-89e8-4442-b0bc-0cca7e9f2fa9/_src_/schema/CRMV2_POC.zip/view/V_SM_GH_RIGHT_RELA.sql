CREATE VIEW V_SM_GH_RIGHT_RELA AS select null CREATE_DATE,null GHGH,
null REAL_MODIFY_DATE ,null  RELA_GHGH,
null RELA_ID ,  null RELA_TEID,
null TEID  from dual
/
