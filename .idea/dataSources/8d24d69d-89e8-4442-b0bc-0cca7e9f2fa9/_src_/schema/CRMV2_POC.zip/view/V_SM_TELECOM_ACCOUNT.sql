CREATE VIEW V_SM_TELECOM_ACCOUNT AS select
a.account_id TEL_ACCT_ID,
a.account_number TEL_ACCT_CODE,
a.account_name TEL_ACCT_NAME,
null TEL_ACCT_CREDIT,
a.account_number AGREEMENT_CODE,
a.cust_id CUSTOMER_ID,
a.create_date CREATE_DATE,
a.status_date MODIFY_DATE,
decode(a.status_cd,'1000','10A','70X') STATE,
a.region_cd REGION,
a.account_name NAME,
(select b.post_address from BILL_FORMAT_CUSTOMIZE b where b.account_id = a.account_id and rownum<2) DELIVER_ADDRESS,
(select b.post_code from BILL_FORMAT_CUSTOMIZE b where b.account_id = a.account_id and rownum<2) ZIP_CODE,
null BELONGING_ID,
null ACCT_CANCLE,
null IS_POST,
a.rec_update_date REAL_MODIFY_DATE,
(select c.prod_inst_id from prod_inst_acct c where c.account_id = a.account_id and rownum<2) SIGN_PROD_ID,
a.deduct_limit DEDUCT_LIMIT,
a.deduct_charge DEDUCT_CHARGE,
null PRINT_PROD_ID
from account  a
/
