CREATE VIEW V_PROD_INST_ATTR AS select a."PROD_INST_ATTR_ID",a."PROD_INST_ID",a."ATTR_ID",a."ATTR_VALUE_ID",a."ATTR_VALUE",a."STATUS_CD",a."STATUS_DATE",a."EFF_DATE",a."EXP_DATE",a."CREATE_DATE",a."UPDATE_DATE",a."PROC_SERIAL",a."AREA_ID",a."REGION_CD",a."UPDATE_STAFF",a."CREATE_STAFF",a."REC_UPDATE_DATE", b.prod_inst_attr_id as ext_key_id
  from prod_inst_attr a, prod_inst_attr_ext b
 where a.prod_inst_attr_id = b.prod_inst_attr_id(+)
/
