CREATE VIEW V_STAFF_4HB AS SELECT DISTINCT su.staff_code,
                su.password,
                nvl((SELECT party_name
                      FROM party pt
                     WHERE pt.party_id = s.party_id
                           AND pt.status_cd = '1000'),
                    '未知姓名') staff_name,
                sp.staff_position_id member_id,
                org.org_id team_id,
                org.org_name team_name,
                org.common_region_id area_id,
                s.staff_id crm_staff_id
  FROM system_user    su,
       staff          s,
       organization   org,
       staff_position sp,
       position       ps
 WHERE s.staff_id = su.staff_id(+)
       AND sp.org_id = org.org_id(+)
       AND sp.position_id = ps.position_id
       AND ps.position_sort = '11'
       AND s.staff_id(+) = sp.staff_id
       AND su.status_cd = '1000'
       AND s.status_cd = '1000'
       AND org.status_cd = '1000'
/
