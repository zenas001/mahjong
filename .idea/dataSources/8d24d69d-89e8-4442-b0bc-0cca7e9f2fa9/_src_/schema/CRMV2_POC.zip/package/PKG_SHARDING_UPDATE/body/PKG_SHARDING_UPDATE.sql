CREATE package body           PKG_SHARDING_UPDATE is
  PROCEDURE PRC_MAIN_ENTRY IS
     CURSOR CUR IS
      SELECT *
        FROM Sharding_update_t1
       WHERE CURSOR_SQL IS NOT NULL
         AND STATE='70A';
    V_CNT NUMBER(2);
  BEGIN
    FOR REC IN CUR LOOP
       SELECT COUNT(*) INTO V_CNT
        FROM Sharding_update_t1
       WHERE TABLE_NAME=REC.TABLE_NAME
         AND STATE='70A';
     IF V_CNT>0 THEN
      PRC_EXEC_TABLE(REC.TABLE_NAME);
     END IF;
    END LOOP;
  END PRC_MAIN_ENTRY;

  PROCEDURE PRC_EXEC_TABLE(I_TABLE_NAME IN VARCHAR2) IS
    V_CURSOR_SQL  VARCHAR2(4000);
    I         NUMBER DEFAULT 1;
    V_SQL     VARCHAR2(2000);
    V_ERR_MSG VARCHAR2(500);
    V_CNT     NUMBER;
    V_DATE DATE;
    V_MAX_NUM NUMBER DEFAULT 2000;
  BEGIN
        UPDATE Sharding_update_t1 SET BEGIN_TIME=SYSDATE,ERR_MSG='',STATE='70B' WHERE TABLE_NAME=I_TABLE_NAME;
        SELECT SYSDATE INTO V_DATE FROM DUAL;
        INSERT INTO SHARDING_LOG VALUES(I_TABLE_NAME,V_DATE,'','');
        COMMIT;
        SELECT CURSOR_SQL INTO V_CURSOR_SQL FROM Sharding_update_t1 WHERE TABLE_NAME=I_TABLE_NAME;
      WHILE INSTR(V_CURSOR_SQL, ';', 1, I) > 0 LOOP
        if i = 1 then
          V_SQL := SUBSTR(V_CURSOR_SQL,
                          1,
                          INSTR(V_CURSOR_SQL, ';', 1, I) - 1);

        else
          V_SQL := SUBSTR(V_CURSOR_SQL,
                          INSTR(V_CURSOR_SQL, ';', 1, I - 1) + 1,
                          INSTR(V_CURSOR_SQL, ';', 1, I) -
                          INSTR(V_CURSOR_SQL, ';', 1, I - 1) - 1);
        end if;
        IF INSTR(UPPER(V_SQL), 'DROP') > 0 THEN
          V_SQL := 'BEGIN
                 EXECUTE IMMEDIATE ''' || V_SQL ||
                   ''';
                exception when others then null;
                END;';
        ELSIF  INSTR(UPPER(REPLACE(V_SQL,' ','')), 'CREATETABLE') > 0 THEN
          IF INSTR(UPPER(V_SQL),'CRMV2.'||I_TABLE_NAME)>0  THEN
            V_SQL:=V_SQL||' AND ROWNUM<='||V_MAX_NUM;
          END IF;
          IF INSTR(UPPER(V_SQL),'CRMV2.'||I_TABLE_NAME)>0 AND INSTR(UPPER(I_TABLE_NAME),'HIS')>0 THEN
              V_SQL:=V_SQL||' AND UPDATE_DATE >= TO_DATE(''20160101'',''YYYYMMDD'')';
          END IF;
              V_SQL:=REPLACE(V_SQL,'''','''''');
          V_SQL := 'BEGIN EXECUTE IMMEDIATE ''' || V_SQL || '''; END;';
        ELSE
          V_SQL:=REPLACE(V_SQL,'''','''''');
          V_SQL := 'BEGIN EXECUTE IMMEDIATE ''' || V_SQL || '''; END;';
        END IF;
        -- DBMS_OUTPUT.put_line(V_SQL);
        EXECUTE IMMEDIATE V_SQL;
        i := i + 1;
      END LOOP;
          EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM R_'||I_TABLE_NAME INTO V_CNT;
        IF V_CNT=0 THEN
         UPDATE Sharding_update_t1 SET END_TIME=SYSDATE,STATE='70C',V_TOTAL_NEW=NVL(V_TOTAL_NEW,0)+V_CNT WHERE TABLE_NAME=I_TABLE_NAME;
        ELSE
          PRC_SHARDING_UPDATE(I_TABLE_NAME);
          UPDATE Sharding_update_t1 SET END_TIME=SYSDATE,STATE='70A',V_TOTAL_NEW=NVL(V_TOTAL_NEW,0)+V_CNT WHERE TABLE_NAME=I_TABLE_NAME;
        END IF;
        UPDATE SHARDING_LOG SET END_TIME=SYSDATE,NUM=V_CNT WHERE TABLE_NAME=I_TABLE_NAME AND BEGIN_TIME=V_DATE;
        COMMIT;
      exception when others then
        ROLLBACK;
      V_ERR_MSG:=SUBSTR(SQLERRM,0,300);
      UPDATE Sharding_update_t1 SET ERR_MSG=V_ERR_MSG,STATE='70E' WHERE TABLE_NAME=I_TABLE_NAME;
      COMMIT;

  END PRC_EXEC_TABLE;

  PROCEDURE PRC_SHARDING_UPDATE(I_CUR_TABLE IN VARCHAR2) IS
    TYPE ref_cursor_type IS REF CURSOR;
    cur          ref_cursor_type;
    maxrows      number default 5000;
    row_id_table dbms_sql.Urowid_Table;
    COL1_table   dbms_sql.number_Table;
    COL2_table   dbms_sql.number_Table;
    COL0_table   dbms_sql.number_Table;
    v_sql        VARCHAR2(1000);
    V_CNT        NUMBER(2);
  BEGIN

    v_sql := 'SELECT * FROM R_' || I_CUR_TABLE;
    open cur for v_sql;
    select COUNT(*)
      INTO V_CNT
      from dba_tab_cols
     where TABLE_NAME = 'R_'||I_CUR_TABLE;
    IF V_CNT = 3 THEN
      LOOP
        EXIT WHEN cur%NOTFOUND;
        FETCH cur bulk collect
          into row_id_table, COL1_table,COL0_table limit maxrows;
        forall i in 1 .. row_id_table.count
        EXECUTE IMMEDIATE
                         'UPDATE CRMV2.' || I_CUR_TABLE ||
                         ' SET SHARDING_ID=NVL(:V1,0) WHERE ROWID=:V3' USING
                         COL1_table(i), row_id_table(i)
          ;
        commit;
      end loop;
    ELSE
      LOOP
        EXIT WHEN cur%NOTFOUND;
        FETCH cur bulk collect
          into row_id_table, COL1_table, COL2_table,COL0_table limit maxrows;
        forall i in 1 .. row_id_table.count
        EXECUTE IMMEDIATE
                         'UPDATE CRMV2.' || I_CUR_TABLE ||
                         ' SET SHARDING_ID=NVL(:V1,0),SHARDING_ID_OPPOSITE=NVL(:V2,0) WHERE ROWID=:V3'
                         USING COL1_table(i), COL2_table(i),
                         row_id_table(i)
          ;
        commit;
      end loop;
    END IF;
    COMMIT;
    close cur;
    exception when others then
      ROLLBACK;
       RAISE_APPLICATION_ERROR(-20100, 'PRC_SHARDING_UPDATE' || '过程出错:' || SQLERRM);
  END PRC_SHARDING_UPDATE;
end PKG_SHARDING_UPDATE;
/
