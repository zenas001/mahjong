CREATE PACKAGE           PKG_INTF IS

  FUNCTION FNC_GET_INTF_DEFINE_CONFIGS(I_PROD_ITEM_ID_STR  IN VARCHAR2, --产品订单项id, 如111, 222, 333
                                       I_OFFER_ITEM_ID_STR IN VARCHAR2 --销售品订单项id
                                       ) RETURN VARCHAR2
  /*-------------------------------------------------
      功能: 查询接口配置信息
    -------------------------------------------------*/
  ;

  /*-------------------------------------------------
      功能: 查停复机INTF_DEFINE_CONFIG
    -------------------------------------------------*/
 FUNCTION FNC_GET_TFJ_DEFINE_CONFIGS(I_PROD_OFFER_ID     IN NUMBER,
                                     I_PRODUCT_ID        IN NUMBER,
                                     I_SERVICE_OFFER_ID  IN NUMBER,
                                     I_AREA_ID           IN NUMBER
                                     ) RETURN VARCHAR2
  ;

  /*----------------------------------------------------------------------------
      功能: 查停复机INTF_DEFINE_CONFIG_4G add by wwb 20140414
    ----------------------------------------------------------------------------*/
 FUNCTION FNC_GET_TFJ_DEFINE_CONFIGS_4G(I_PROD_OFFER_ID      IN NUMBER,
                                         I_PRODUCT_ID         IN NUMBER,
                                         I_SERVICE_OFFER_ID   IN NUMBER,
                                         I_AREA_ID            IN NUMBER,
                                         I_ATTR_ID            IN VARCHAR2,
                                         I_ATTR_VALUE_NEW     IN VARCHAR2,
                                         I_ACTION             IN VARCHAR2
                                        ) RETURN VARCHAR2
  ;
  /*----------------------------------------------------------------------------
      功能: 预付费互改 FNC_GET_TFJ_DEFINE_CONFIGS_OCS add by qiurl 20141024
    ----------------------------------------------------------------------------*/
 FUNCTION FNC_GET_TFJ_DEFINE_CONFIGS_OCS (I_PROD_OFFER_ID      IN NUMBER,
                                         I_PRODUCT_ID         IN NUMBER,
                                         I_SERVICE_OFFER_ID   IN NUMBER,
                                         I_AREA_ID            IN NUMBER,
                                         I_ATTR_ID            IN VARCHAR2,
                                         I_ACTION             IN VARCHAR2
                                        ) RETURN VARCHAR2
  ;
END PKG_INTF;
/
