CREATE PACKAGE           PKG_CUST_CREDIT_LEVEL_FROM_ODS  is

  -- Author  : QIURL
  -- Created : 2013-08-29
  -- Purpose : 从ODS更新客户的信用等级
  --  注：
  /******************************************

  *****************************************/

  --从ODS获取客户信用等级
  PROCEDURE PROC_SYNC_CUST_CREDIT_LEVEL;

END PKG_CUST_CREDIT_LEVEL_FROM_ODS;
/
