CREATE PACKAGE           PKG_get_awr_top10sql IS

  PROCEDURE get_awr_top10sql;

END PKG_get_awr_top10sql;
/
