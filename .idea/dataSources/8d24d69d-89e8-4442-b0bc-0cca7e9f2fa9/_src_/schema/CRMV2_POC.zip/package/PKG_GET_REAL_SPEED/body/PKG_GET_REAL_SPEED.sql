CREATE package body           PKG_GET_REAL_SPEED is

  function getNetAge(i_prodInstId in number,i_beginDate IN DATE) --获取宽带在网的时间 返回年
   return number is
    v_cnt      number;
    v_net_date date;
    v_mouths   number;
  begin
    select create_date
      into v_net_date
      from prod_inst
     where prod_inst_id = i_prodInstId;
    /*zhengcl crm00060966 网龄可选包，要根据可选包起始计算时间判断网龄
    产品创建时间是2009年，网龄可选包起始计算时间是2013年，要用2013年开始算网龄*/
    IF i_beginDate IS NOT NULL AND i_beginDate >v_net_date THEN
      v_net_date:=i_beginDate;
    END IF;
    v_mouths := months_between(last_day(sysdate), last_day(v_net_date));
    v_cnt    := trunc(v_mouths / 12);
    return v_cnt;
  end;

  function isNetAgeAdd(i_prodInstId in number) --宽带网龄是否增加
   return number is
    v_last_cnt   number;
    v_now_cnt    number;
    v_change_cnt number;
    v_net_date   date;
    v_mouths     number;
  begin

    select create_date
      into v_net_date
      from prod_inst
     where prod_inst_id = i_prodInstId;
    v_mouths   := months_between(add_months(last_day(sysdate), -1),
                                 last_day(v_net_date));
    v_last_cnt := trunc(v_mouths / 12);
    v_now_cnt  := getNetAge(i_prodInstId,NULL);
    if v_now_cnt > v_last_cnt then
      v_change_cnt := 1;
    else
      v_change_cnt := 0;
    end if;

    --封顶五年
    if v_now_cnt > 5 then
      v_change_cnt := 0;
    end if;
    --封顶五年
    return v_change_cnt;
  end; ------isNetAgeAdd

  -- 计算 光纤接入（校校通）
  function getNewSjslspecidBySimApp(i_prodInstId   In number,
                                    old_sjslspecid In number,
                                    o_result       out varchar2)
    return number IS
    new_sjslspecid number(10);
    sulvspecid     number(10);
    cnt            number(3);
    prodofferid    varchar2(50);
  begin
    new_sjslspecid := 0;

    SELECT count(*)
      into cnt
      FROM prod_inst a
     WHERE a.prod_inst_id = i_prodInstId;
    if cnt = 0 then
      return new_sjslspecid;
    end if;

    --是否存在提速可选包
    SELECT count(*)
      into cnt
      FROM prod_offer_inst poi, offer_prod_inst_rel opi
     WHERE poi.status_cd = '1000'
       and opi.status_cd = '1000'
       and opi.prod_inst_id = i_prodInstId
       and opi.prod_offer_inst_id = poi.prod_offer_inst_id
       and exists (SELECT *
              FROM attr_spec at, Attr_Value av
             WHERE at.java_code = 'autoUpSpeedOne'
               and to_char(poi.prod_offer_id) = av.attr_value
               and at.attr_id = av.attr_id);

    if cnt = 1 then

      SELECT poi.prod_offer_id
        into prodofferid
        FROM prod_offer_inst poi, offer_prod_inst_rel opi
       WHERE poi.status_cd = '1000'
         and opi.status_cd = '1000'
         and opi.prod_inst_id = i_prodInstId
         and opi.prod_offer_inst_id = poi.prod_offer_inst_id
         and exists (SELECT *
                FROM attr_spec at, Attr_Value av
               WHERE at.java_code = 'autoUpSpeedOne'
                 and to_char(poi.prod_offer_id) = av.attr_value
                 and at.attr_id = av.attr_id);

      --判断是否能获取提档速率
      SELECT count(*)
        into cnt
        FROM (SELECT b.parent_value_id, rownum n
                FROM attr_spec a, Attr_Value b
               WHERE a.java_code = prodofferid
                 and a.attr_id = b.attr_id
                 and a.status_cd != '1100'
                 and b.status_cd != '1100'
                 and old_sjslspecid < b.parent_value_id
               order by b.parent_value_id) xx
       WHERE rownum < 2; --xx.n = 1 这个不行 导致排序取最小值出现错误

      if cnt = 1 then
        --获取提档速率
        SELECT xx.parent_value_id
          into new_sjslspecid
          FROM (SELECT b.parent_value_id, rownum n
                  FROM attr_spec a, Attr_Value b
                 WHERE a.java_code = prodofferid
                   and a.attr_id = b.attr_id
                   and a.status_cd != '1100'
                   and b.status_cd != '1100'
                   and old_sjslspecid < b.parent_value_id
                 order by b.parent_value_id) xx
         WHERE rownum < 2; --xx.n = 1; 使用这个有问题。导致排序取最小值出现错误
      end if;
    end if;
    return new_sjslspecid;
  end getNewSjslspecidBySimApp;

  function getGXNetAgeUpSpeed(i_prodInstId   In number,
                              old_sjslspecid In number,
                              o_result       out varchar2) --收集报错信息
   Return Number Is
    new_sjslspecid number(10);
    sulvspecid     number(10);
    cnt            number(3);
    net_age        number(10); --宽带在网年限
    attrValueId    number(12);
    i_ck_sulvdw    number(10); --每年增量速率的大小
    i_max_sulv     number(10); --最大值
    prodofferid    varchar2(100);
    i_begin_date   DATE;---网龄可选包起始计算的时间
    --msg       varchar2(1240);
    i_first_add    number(10);--首年增量速率的大小（为attr_value的manage_grade字段）
  begin
    cnt            := 0;
    new_sjslspecid := 0;
    attrValueId    := 0;
    --是否存在提速可选包
    SELECT count(*)
      into cnt
      FROM prod_offer_inst poi, offer_prod_inst_rel opi
     WHERE poi.status_cd = '1000'
       and opi.status_cd = '1000'
       and opi.prod_inst_id = i_prodInstId
       and opi.prod_offer_inst_id = poi.prod_offer_inst_id
       and exists (SELECT *
              FROM attr_spec at, Attr_Value av
             WHERE at.java_code = 'autoNetAgeUpSpeed'
               and to_char(poi.prod_offer_id) = av.attr_value
               and at.attr_id = av.attr_id);

    if cnt = 1 then
      SELECT poi.prod_offer_id
        into prodofferid
        FROM prod_offer_inst poi, offer_prod_inst_rel opi
       WHERE poi.status_cd = '1000'
         and opi.status_cd = '1000'
         and opi.prod_inst_id = i_prodInstId
         and opi.prod_offer_inst_id = poi.prod_offer_inst_id
         and exists (SELECT *
                FROM attr_spec at, Attr_Value av
               WHERE at.java_code = 'autoNetAgeUpSpeed'
                 and to_char(poi.prod_offer_id) = av.attr_value
                 and at.attr_id = av.attr_id);

      SELECT av.attr_desc, av.max_value,av.eff_date,av.manage_grade
        into i_ck_sulvdw, i_max_sulv,i_begin_date,i_first_add
        FROM attr_spec at, Attr_Value av
       WHERE at.java_code = 'autoNetAgeUpSpeed'
         and at.attr_id = av.attr_id
         and av.attr_value = prodofferid;

      SELECT count(*)
        into cnt
        FROM prod_inst_attr a, attr_spec b, attr_value av
       WHERE a.prod_inst_id = i_prodInstId
         and a.attr_id = b.attr_id
         and b.java_code = '008'
         and a.attr_value_id = av.attr_value_id;

      if cnt = 1 then
        --获取下行速率
        SELECT av.attr_desc
          into sulvspecid
          FROM prod_inst_attr a, attr_spec b, attr_value av
         WHERE a.prod_inst_id = i_prodInstId
           and a.attr_id = b.attr_id
           and b.java_code = '008'
           and a.attr_value_id = av.attr_value_id;
      end if;

      net_age := getNetAge(i_prodInstId,i_begin_date);
      -- 封顶五年
      if net_age > 5 then
        net_age := 5;
      end if;
      -- 封顶五年
      if net_age > 0 then
        --mod by wangxm 20150320 crm00060966 FJCRMV2.0_BUG_福建省_关于政企宽带网龄提速套餐网龄计算规则有误的申告单
        if i_first_add is null or i_first_add = 0 then
           i_first_add :=i_ck_sulvdw;
        end if;
        if net_age = 1 then
           new_sjslspecid := sulvspecid + i_first_add;--网龄N为1年时，新速率=旧速率+首年增量速率的大小
        end if;
        if net_age >1 then
            --网龄N>1年时，新速率=旧速率+首年增量速率的大小+(N-1)*次年后每年增量速率的大小
           new_sjslspecid := sulvspecid + i_first_add + i_ck_sulvdw *( net_age-1);
        end if;
        if new_sjslspecid <= old_sjslspecid then
          --如果计算的速率比别的规则少，则还是其他规则的速率
          new_sjslspecid := 0;
        end if;
        --如果提速超过最大速率，则最大速率作为新的提速速率
        if i_max_sulv is not null and i_max_sulv >= old_sjslspecid and new_sjslspecid > i_max_sulv  then
          new_sjslspecid := i_max_sulv;
        end if;
      end if;
    end if;
    return new_sjslspecid;
  end getGXNetAgeUpSpeed;

  PROCEDURE getProdRealSpeed(i_prodInstId    IN NUMBER, -- 产品对应的实例id
                             o_realfeaspecid out NUMBER, -- 若返回0，表示不需要做任何操作，-1 为错误
                             o_result        out varchar2 --如果有错，返回错误信息
                             ) is
    new_sjslspecid  number(10);
    old_sjslspecid  number(10);
    sulvspecid      number(10);
    cnt             number(3);
    net_age         number(10); --宽带在网年限
    attrValueId     number(12);
    temp_sjslspecid number(10);
  BEGIN
    cnt             := 0;
    new_sjslspecid  := 0;
    temp_sjslspecid := 0;
    old_sjslspecid  := 0;
    attrValueId     := 0;
    SELECT count(*)
      into cnt
      FROM prod_inst_attr a, attr_spec b, attr_value av
     WHERE a.prod_inst_id = i_prodInstId
       and a.attr_id = b.attr_id
       and b.java_code = 'SJSL'
       and a.attr_value_id = av.attr_value_id;

    if cnt = 1 then
      --获取旧的实际速率
      SELECT av.attr_desc
        into old_sjslspecid
        FROM prod_inst_attr a, attr_spec b, attr_value av
       WHERE a.prod_inst_id = i_prodInstId
         and a.attr_id = b.attr_id
         and b.java_code = 'SJSL'
         and a.attr_value_id = av.attr_value_id;
    end if;

    SELECT count(*)
      into cnt
      FROM prod_inst_attr a, attr_spec b, attr_value av
     WHERE a.prod_inst_id = i_prodInstId
       and a.attr_id = b.attr_id
       and b.java_code = '008'
       and a.attr_value_id = av.attr_value_id;

    if cnt = 1 then
      --获取下行速率
      SELECT av.attr_desc
        into sulvspecid
        FROM prod_inst_attr a, attr_spec b, attr_value av
       WHERE a.prod_inst_id = i_prodInstId
         and a.attr_id = b.attr_id
         and b.java_code = '008'
         and a.attr_value_id = av.attr_value_id;
    end if;
    --如果实际速率 = 0 那么就用下行速率作为旧速率
    if old_sjslspecid = 0 then
      old_sjslspecid := sulvspecid;
    end if;

    --计算网龄提速
    temp_sjslspecid := getGXNetAgeUpSpeed(i_prodInstId,
                                          old_sjslspecid,
                                          o_result);
    if new_sjslspecid < temp_sjslspecid then
      new_sjslspecid := temp_sjslspecid;
    end if;

    --档次提速 校校通
    temp_sjslspecid := getNewSjslspecidBySimApp(i_prodInstId,
                                                sulvspecid,
                                                o_result); --改为用下行速率放进去计算
    if new_sjslspecid < temp_sjslspecid then
      new_sjslspecid := temp_sjslspecid;
    end if;

    if new_sjslspecid > old_sjslspecid then

      SELECT count(*)
        into cnt
        FROM attr_value a
       WHERE a.attr_id = 800000283
         and a.attr_desc = new_sjslspecid
         and rownum < 2;
      if cnt = 1 then
        --得到正常的提速规格
        SELECT a.attr_value_id
          into attrValueId
          FROM attr_value a
         WHERE a.attr_id = 800000283
           and a.attr_desc = new_sjslspecid
           and rownum < 2;
      else
        --报错规格不符合 不能得到正常的提速规格
        o_result    := '提速规格获取错误，请检查配置要提速[' || new_sjslspecid;
        o_result    := o_result || '] 当前实际速率或下行速率为[' || sulvspecid ||
                       ']/1000=*M';
        attrValueId := -1;
      end if;
    end if;
    o_realfeaspecid := attrValueId;
    o_result        := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      o_realfeaspecid := -1;
      o_result        := 'getProdRealSpeed过程异常';
  END getProdRealSpeed;

  procedure autoNetAgeUpSpeed as
    cnt            NUMBER(3) := 0;
    seq_id         number(12) := 0;
    seq_pi_id      number(12) := 0;
    attrValueId    number(12);
    o_result       varchar2(1240);
    prodOfferId    number(12);
    old_sjslspecid number(12);
    sulvspecid     number(12);
  BEGIN

    --20150108 crm00059688 全省都有网龄提速

    for netProdOfferInst in (SELECT opir.prod_inst_id,
                                    poi.area_id,
                                    poi.region_cd,
                                    poi.cust_id,
                                    av.attr_desc,
                                    av.max_value,
                                    av.eff_date
                               FROM prod_offer_inst     poi,
                                    offer_prod_inst_rel opir,
                                    attr_spec           at,
                                    Attr_Value          av
                              WHERE at.java_code = 'autoNetAgeUpSpeed'
                                and at.attr_id = av.attr_id
                                and to_char(poi.prod_offer_id) = av.attr_value
                                 and opir.prod_inst_id=1904524063--------------测试
                                and opir.prod_offer_inst_id =
                                    poi.prod_offer_inst_id
                                and poi.status_cd = '1000'
                                and opir.status_cd = '1000') loop
      begin
        attrValueId := 0;
        SELECT count(*)
          into cnt
          FROM prod_inst a
         WHERE a.prod_inst_id = netProdOfferInst.prod_inst_id
           and a.status_cd = '100000';

        if cnt != 1 then
          attrValueId := -3; --不在用的数据，job不管
        end if;
        if attrValueId != -3 and
           getNetAge(netProdOfferInst.prod_inst_id,netProdOfferInst.eff_date) > 0 then

          --查找主销售品
          SELECT count(*)
            into cnt
            FROM offer_prod_inst_rel a, prod_offer_inst b, prod_offer o
           WHERE a.prod_inst_id = netProdOfferInst.prod_inst_id
             and a.prod_offer_inst_id = b.prod_offer_inst_id
             and b.prod_offer_id = o.prod_offer_id
             and o.offer_sub_type = 'T01';

          if cnt = 1 then
            SELECT b.prod_offer_inst_id
              into prodOfferId
              FROM offer_prod_inst_rel a, prod_offer_inst b, prod_offer o
             WHERE a.prod_inst_id = netProdOfferInst.prod_inst_id
               and a.prod_offer_inst_id = b.prod_offer_inst_id
               and b.prod_offer_id = o.prod_offer_id
               and o.offer_sub_type = 'T01';
          else
            attrValueId := -1;
            o_result    := '根据产品id' || netProdOfferInst.prod_inst_id ||
                           '获取主销售品失败';
          end if;
          --判断是否队列上面已经有在处理，如果有就不处理了
          if attrValueId != -1 then
            SELECT count(*)
              into cnt
              FROM o_auto_proc_queue
             WHERE SRC_INST_ID = prodOfferId
               and SRC_TYPE = 'ProdOfferInst'
               and queue_desc = '光纤提速队列';
            if cnt > 0 then
              attrValueId := -2; --已经队列中有数据了 就不再次做处理了。
              o_result    := '队列中已经存在提速处理数据';
            end if;
          end if;

          old_sjslspecid := 0;
          SELECT count(*)
            into cnt
            FROM prod_inst_attr a, attr_spec b, attr_value av
           WHERE a.prod_inst_id = netProdOfferInst.prod_inst_id
             and a.attr_id = b.attr_id
             and b.java_code = 'SJSL'
             and a.attr_value_id = av.attr_value_id;

          if cnt = 1 then
            --获取旧的实际速率
            SELECT av.attr_desc
              into old_sjslspecid
              FROM prod_inst_attr a, attr_spec b, attr_value av
             WHERE a.prod_inst_id = netProdOfferInst.prod_inst_id
               and a.attr_id = b.attr_id
               and b.java_code = 'SJSL'
               and a.attr_value_id = av.attr_value_id;
          end if;

          SELECT count(*)
            into cnt
            FROM prod_inst_attr a, attr_spec b, attr_value av
           WHERE a.prod_inst_id = netProdOfferInst.prod_inst_id
             and a.attr_id = b.attr_id
             and b.java_code = '008'
             and a.attr_value_id = av.attr_value_id;

          if cnt = 1 then
            --获取下行速率
            SELECT av.attr_desc
              into sulvspecid
              FROM prod_inst_attr a, attr_spec b, attr_value av
             WHERE a.prod_inst_id = netProdOfferInst.prod_inst_id
               and a.attr_id = b.attr_id
               and b.java_code = '008'
               and a.attr_value_id = av.attr_value_id;
          end if;
          --如果实际速率 = 0 那么就用下行速率作为旧速率
          if old_sjslspecid = 0 then
            old_sjslspecid := sulvspecid;
          end if;

          --计算是否要提速 返回的 attrValueId > 0 表示要提速的。需要加入自动队列中
          if attrValueId != -2 and attrValueId != -1 then
            attrValueId := getGXNetAgeUpSpeed(netProdOfferInst.prod_inst_id,
                                              old_sjslspecid,
                                              o_result);
          end if;

          if attrValueId <= 0 then
            attrValueId := 0; --不做处理。
          else
            --如果有提速加入自动处理队列中
            seq_id := seq_o_auto_proc_queue_id.nextval;
            insert into o_auto_proc_queue
              (QUEUE_ID,SUPER_QUEUE_ID,PRIORITY,SRC_TYPE,SRC_INST_ID,SRC_ACTION,PROC_TYPE,CUST_ORDER_ID,ORDER_ITEM_ID,REMARK,QUEUE_DESC,EXTEND,EFF_DATE,AREA_ID,REGION_CD,CREATE_STAFF,CREATE_DATE,STATUS_CD,STATUS_DATE,UPDATE_STAFF,UPDATE_DATE,CUST_ID,BEGIN_DATE)
            values
              (seq_id,0,null,'ProdOfferInst',prodOfferId,'3020500000','MOD',null,null,'','光纤提速队列','',null,netProdOfferInst.Area_Id,netProdOfferInst.region_cd,51447,sysdate,'200098',sysdate,-1,sysdate,netProdOfferInst.cust_id,trunc(last_day(sysdate)) + 1 + 1 / 24);

            insert into proc_queue_attr
              (ATTR_ID,QUEUE_ID,SUPER_ATTR_ID,OBJ_TYPE,OBJ_SPEC,OBJ_ID,PROC_TYPE,REMARK,AREA_ID,REGION_CD,CREATE_STAFF,CREATE_DATE,STATUS_CD,STATUS_DATE,UPDATE_STAFF,UPDATE_DATE,OBJ_VALUE,VALID_BEAN,VALID_PARAM1,VALID_PARAM2)
            values
              (seq_proc_queue_attr_id.nextval,seq_id,0,'CHNCD',0,0,'INSERT','',netProdOfferInst.Area_Id,netProdOfferInst.region_cd,51447,sysdate,'1299',sysdate,null,sysdate,'600105B021','','','');

            seq_pi_id := seq_o_auto_proc_queue_id.nextval;
            insert into o_auto_proc_queue
              (QUEUE_ID,SUPER_QUEUE_ID,PRIORITY,SRC_TYPE,SRC_INST_ID,SRC_ACTION,PROC_TYPE,CUST_ORDER_ID,ORDER_ITEM_ID,REMARK,QUEUE_DESC,EXTEND,EFF_DATE,AREA_ID,REGION_CD,CREATE_STAFF,CREATE_DATE,STATUS_CD,STATUS_DATE,UPDATE_STAFF,UPDATE_DATE,CUST_ID,BEGIN_DATE)
            values
              (seq_pi_id,seq_id,null,'ProdInst',netProdOfferInst.Prod_Inst_Id,'4040800000','MOD',null,null,'','光纤提速队列','',null,netProdOfferInst.Area_Id,netProdOfferInst.region_cd,51447,sysdate,'200099',sysdate,null,sysdate,netProdOfferInst.Cust_Id,null);

            --800000283 要修改的 规格，  --900000047  为要设置的值。
           insert into proc_queue_attr
              (ATTR_ID,QUEUE_ID,SUPER_ATTR_ID,OBJ_TYPE,OBJ_SPEC,OBJ_ID,PROC_TYPE,REMARK,AREA_ID,REGION_CD,CREATE_STAFF,CREATE_DATE,STATUS_CD,STATUS_DATE,UPDATE_STAFF,UPDATE_DATE,OBJ_VALUE,VALID_BEAN,VALID_PARAM1,VALID_PARAM2)
            values
              (seq_proc_queue_attr_id.nextval,seq_pi_id,0,'CHECK',800000283,0,'INSERT','',netProdOfferInst.Area_Id,netProdOfferInst.region_cd,51447,sysdate,'1299',sysdate,null,sysdate,attrValueId,'lanSpeedCheck','1','800303460');
          end if;

        end if;

      EXCEPTION
        WHEN OTHERS THEN
          seq_id := seq_o_auto_proc_queue_id.nextval;
          insert into o_auto_proc_queue
            (QUEUE_ID,SUPER_QUEUE_ID,PRIORITY,SRC_TYPE,SRC_INST_ID,SRC_ACTION,PROC_TYPE,CUST_ORDER_ID,ORDER_ITEM_ID,REMARK,QUEUE_DESC,EXTEND,EFF_DATE,AREA_ID,REGION_CD,CREATE_STAFF,CREATE_DATE,STATUS_CD,STATUS_DATE,UPDATE_STAFF,UPDATE_DATE,CUST_ID,BEGIN_DATE)
          values
            (seq_id,0,null,'ProdInst',netProdOfferInst.prod_inst_id,'3020500000','MOD',null,null,'网龄提速自动队列异常错误，请联系维护人员检查次数据','光纤提速队列','',null,netProdOfferInst.Area_Id,netProdOfferInst.region_cd,51447,sysdate,'400001',sysdate,-1,sysdate,netProdOfferInst.cust_id,null);
      end;

    end loop;
    commit;
  end autoNetAgeUpSpeed;

end PKG_GET_REAL_SPEED;
/
