CREATE PACKAGE           pkg_deal_cust_mail IS

  -- Author  : 林志强
  -- Created : 2012/2/25 9:45:54
  -- Purpose :

  /*获取产权客户名下产品数*/
  FUNCTION func_cust_own_prod_count(in_cust_id IN NUMBER) RETURN NUMBER; ----入参：客户ID

  /*判断客户是否为政企客户*/
  FUNCTION func_check_cust_statecos(in_cust_id IN NUMBER) RETURN BOOLEAN; ----入参：客户ID

  /*判断产品是否在用*/
  FUNCTION func_check_prod_exist(in_acc_nbr IN VARCHAR2, ----业务号码
                                 in_cust_id IN NUMBER) RETURN BOOLEAN; ----客户ID
  /*判断邮箱记录是否存在*/
  FUNCTION func_check_mail_exist(in_mail_address IN VARCHAR2) RETURN BOOLEAN; ----入参：邮箱地址

  /*插入邮箱记录到cust_mail表*/
  FUNCTION func_insert_mail_record(in_cust_id      IN NUMBER, ----客户ID
                                   in_mail_address IN VARCHAR2, ----邮箱地址
                                   in_use_type     VARCHAR2, ----用途:账单推送
                                   in_source       IN VARCHAR2) ----来源:主动推送
   RETURN BOOLEAN;

  /*更新cust_mail表的记录*/
  FUNCTION func_update_mail_record(in_cust_mail_id IN NUMBER, ----cust_mail表ID
                                   in_status_cd    IN VARCHAR2) ----状态：1100
   RETURN BOOLEAN;

  /*查询一个月内竣工的新装-CDMA业务产品的订单，并处理邮箱记录*/
  PROCEDURE proc_deal_new_cdma_record;

  /*查询一个月内竣工的拆除-CDMA业务产品的订单，并处理邮箱记录*/
  PROCEDURE proc_deal_del_cdma_record;
END pkg_deal_cust_mail;
/
