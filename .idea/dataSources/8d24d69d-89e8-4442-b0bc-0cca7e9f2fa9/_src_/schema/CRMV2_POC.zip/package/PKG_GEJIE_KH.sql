CREATE package           PKG_GEJIE_KH is

  -- Author  : MaLong
  -- Created : 2006-12-16 8:21:33
  -- Purpose : To do the automatic job for product and merchandise
    PROCEDURE MAIN;
end PKG_GEJIE_KH;
/
