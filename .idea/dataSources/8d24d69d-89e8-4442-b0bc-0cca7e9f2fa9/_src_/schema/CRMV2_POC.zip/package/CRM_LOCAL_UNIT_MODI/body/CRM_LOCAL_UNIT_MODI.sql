CREATE PACKAGE BODY           CRM_LOCAL_UNIT_MODI IS

  V_TABLE         VARCHAR2(200);
  V_MODI_ENTITY   VARCHAR2(1000);
  V_COLUMN_KEY_ID VARCHAR2(1000);
  V_COLUMN        VARCHAR2(1000);
  V_COLUMN2       VARCHAR2(1000);
  V_MODI_MAN      VARCHAR2(100);
  V_REMARK        VARCHAR2(2000);
  V_SQL           VARCHAR2(1000);
  V_IN_NUM        NUMBER(10) := 0;
  OUT_LOG_MSG     VARCHAR2(2000);
  V_COUNT         NUMBER(10) := 0;
  V_TRUE          NUMBER(2) := 0;
  V_NUM           NUMBER(10) := 0;
  V_NUM1          NUMBER(10) := 1;
  V_NUM2          NUMBER(10) := 0;
  V_TABLE_BEGIN   VARCHAR2(100);
  V_TABLE_END     VARCHAR2(100);
  OUT_ERR_MSG     VARCHAR2(1000);
  V_UP_COLUMN     VARCHAR2(1000);
  V_KEY_ID        VARCHAR2(1000);
  V_AREA_CODE     NUMBER(10) := 0;
  V_CHECK_MAN     VARCHAR2(100);
  V_STATE         VARCHAR2(20);
  V_CHECK_REMARK  VARCHAR2(2000);
  V_LOG_ID        NUMBER(10) := 0;

  -- V_COT_NUM         NUMBER(10) := 0;
  -- V_CHECK           NUMBER(10) := 0;
  v_ct1   NUMBER(10) := 0;
  v_ct2   NUMBER(10) := 0;
  v_ct3   NUMBER(10) := 0;
  ERR_MSG VARCHAR2(2000);
  PROCEDURE CRM_LOCAL_UNIT_MODI_MAIN(IN_LOG_ID    IN NUMBER,
                                     IN_CHECK_MAN IN VARCHAR2,
                                     IN_STATE     IN VARCHAR2,
                                     ERR_MSG      OUT VARCHAR2) IS
  BEGIN
    V_LOG_ID := IN_LOG_ID;
    IF IN_STATE = '10R' THEN
      ERR_MSG := '该脚本被审核人员' || IN_CHECK_MAN || '撤销';
      UPDATE CRM_LOCAL_UNIT_MODI_TEMP_TABLE
         SET STATE        = '10R',
             CHECK_DATE   = SYSDATE,
             CHECK_MAN    = IN_CHECK_MAN,
             CHECK_REMARK = ERR_MSG
       WHERE LOG_ID = V_LOG_ID;
      COMMIT;
      GOTO K;
    ELSIF IN_STATE = '10A' THEN
      NULL;
    ELSE
      ERR_MSG := '前台传入状态有问题,请联系管理员';
      GOTO K;
    END IF;

    V_CHECK_MAN := IN_CHECK_MAN;
    SELECT COUNT(*)
      INTO V_COUNT
      FROM CRM_LOCAL_UNIT_MODI_TEMP_TABLE
     WHERE LOG_ID = V_LOG_ID;

    IF V_COUNT = 0 THEN
      ERR_MSG := '错误!根据主键未查询到记录修改语句,请联系管理员处理';
      GOTO K;
    ELSIF V_COUNT > 1 THEN
      ERR_MSG := '错误!根据主键未查询到2条记录修改语句,请联系管理员处理';
      GOTO K;
    ELSIF V_COUNT = 1 THEN
      NULL;
    ELSE
      ERR_MSG := '错误!系统查询异常,请联系管理员处理';
      GOTO K;
    END IF;

    BEGIN
      SELECT STATE, CHECK_REMARK
        INTO V_STATE, V_CHECK_REMARK
        FROM CRM_LOCAL_UNIT_MODI_TEMP_TABLE
       WHERE LOG_ID = V_LOG_ID;
      IF V_STATE = '10R' THEN
        ERR_MSG := '错误!' || V_CHECK_REMARK;
        GOTO K;
      ELSIF V_STATE = '10X' THEN
        ERR_MSG := '错误!该脚本已经执行过了,请核查';
        GOTO K;
      ELSIF V_STATE = '10A' THEN
        NULL;
      ELSE
        ERR_MSG := '错误!该条审核记录状态有问题,请联系管理员';
        GOTO K;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        ERR_MSG := '错误!该条审核记录状态为空,请联系管理员';
        GOTO K;
    END;
    SELECT TABLE_NAME,
           MODI_ENTITY,
           COLUMN_KEY_ID,
           COLUMN_NAME,
           REMARK,
           MODI_MAN,
           V_TABLE_END
      INTO V_TABLE,
           V_MODI_ENTITY,
           V_COLUMN_KEY_ID,
           V_COLUMN,
           V_REMARK,
           V_MODI_MAN,
           V_TABLE_END
      FROM CRM_LOCAL_UNIT_MODI_TEMP_TABLE
     WHERE LOG_ID = V_LOG_ID;
    --获取修改条件的第一个值
    BEGIN
      V_NUM  := 0;
      V_NUM2 := 0;
      SELECT INSTR(V_COLUMN_KEY_ID, '=''') INTO V_NUM FROM DUAL;
      SELECT SUBSTR(V_COLUMN_KEY_ID, 1, V_NUM - 1)
        INTO V_COLUMN2
        FROM DUAL;
      SELECT INSTR(V_COLUMN_KEY_ID, ''' ') INTO V_NUM2 FROM DUAL;
      SELECT SUBSTR(V_COLUMN_KEY_ID, V_NUM + 2, V_NUM2 - V_NUM - 2)
        INTO V_KEY_ID
        FROM DUAL;
      V_NUM  := 0;
      V_NUM2 := 0;
    EXCEPTION
      WHEN OTHERS THEN
        ERR_MSG := SQLERRM;
        ERR_MSG := '错误！备份日志表时出错@' || ERR_MSG;
        GOTO K;
    END;

    --记录总日志
    GET_COLUMN_VALUE(V_COLUMN, V_TABLE, OUT_LOG_MSG, OUT_ERR_MSG);
    IF OUT_ERR_MSG <> '000000' THEN
      ERR_MSG := OUT_ERR_MSG;
      GOTO K;
    END IF;
    -- SELECT FFCAIL.LOG_ID_SEQ.NEXTVAL INTO V_data_LOG_ID FROM DUAL;
    INSERT INTO CRM_LOCAL_UNIT_MODI_DATA_LOG
    VALUES
      (V_LOG_ID,
       V_TABLE,
       OUT_LOG_MSG,
       NULL,
       V_MODI_MAN,
       V_REMARK,
       SYSDATE,
       V_COLUMN2,
       V_KEY_ID,
       V_CHECK_MAN);
    ERR_MSG := '【修改前数据' || OUT_LOG_MSG || '】';
    --更新
    V_COUNT := 0;
    BEGIN
      V_SQL := 'SELECT COUNT(*)  FROM ALL_TAB_COLUMNS
        WHERE table_name=''' || V_TABLE_END || ''' ' ||
               'AND COLUMN_NAME = ''UPDATE_DATE''';
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF V_COUNT > 0 THEN
        V_SQL := 'update' || ' ' || V_TABLE || ' ' || 'set' || ' ' ||
                 V_MODI_ENTITY || ' ,' || 'UPDATE_DATE =
             sysdate ' || ' ' || 'where' || ' ' ||
                 V_COLUMN_KEY_ID;
      ELSIF V_COUNT = 0 THEN
        V_SQL := 'update' || ' ' || V_TABLE || ' ' || 'set' || ' ' ||
                 V_MODI_ENTITY || ' ' || 'where' || ' ' || V_COLUMN_KEY_ID;
      END IF;
      EXECUTE IMMEDIATE V_SQL;
      UPDATE CRM_LOCAL_UNIT_MODI_TEMP_TABLE
         SET STATE        = '10X',
             CHECK_MAN    = V_CHECK_MAN,
             CHECK_DATE   = SYSDATE,
             CHECK_REMARK = '该脚本已经执行成功'
       WHERE LOG_ID = V_LOG_ID;
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        ERR_MSG := SQLERRM;
        ERR_MSG := SQLERRM || '!错误！修改数据时报错 ';
        ROLLBACK;
        UPDATE CRM_LOCAL_UNIT_MODI_TEMP_TABLE
           SET STATE        = '10F',
               CHECK_MAN    = V_CHECK_MAN,
               CHECK_DATE   = SYSDATE,
               CHECK_REMARK = '更新数据时出错'
         WHERE LOG_ID = V_LOG_ID;
        COMMIT;
        GOTO K;
    END;

    --记录总日志
    GET_COLUMN_VALUE(V_COLUMN, V_TABLE, OUT_LOG_MSG, OUT_ERR_MSG);
    UPDATE CRM_LOCAL_UNIT_MODI_DATA_LOG
       SET NEW_COLUMN_DATA = OUT_LOG_MSG
     WHERE LOG_ID = V_LOG_ID;
    COMMIT;
    ERR_MSG := '【该数据已通过' || V_CHECK_MAN || '审核,数据已修改】【修改人' || V_MODI_MAN ||
               ' 在 ' || TO_CHAR(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') ||
               ' 时间修改数据成功!】' || ERR_MSG || ' 【修改后数据' || OUT_LOG_MSG || '】';
    crmv2.wh_common_process.new_p_ins_billing_update(V_TABLE_END,
                                                     V_COLUMN2,
                                                     V_KEY_ID,
                                                     V_REMARK,
                                                     V_MODI_MAN);
    <<K>>
    NULL;
  END CRM_LOCAL_UNIT_MODI_MAIN;

  --记录日志
  PROCEDURE GET_COLUMN_VALUE(V_COLUMN    IN VARCHAR2,
                             V_TABLE     IN VARCHAR2,
                             OUT_V_STR   OUT VARCHAR2,
                             OUT_ERR_MSG OUT VARCHAR2) IS
    C_COLUMN   VARCHAR2(100);
    V_COUNT    NUMBER(10) := 0;
    V_STR_TEMP VARCHAR2(2000);
    V_STR      VARCHAR2(2000);
    V_IN_NUM   NUMBER(10) := 0;
    V_SQL      VARCHAR2(1000);
    V_NUM1     NUMBER(10) := 1;
    ERR_MSG    VARCHAR2(1000) := '000000';
  BEGIN
    V_COUNT := GET_CHAR_CNT(V_COLUMN, ','); --获取字符串中有多少逗号
    --如果有一个逗号的话直接获取
    IF V_COUNT = 1 THEN
      SELECT REPLACE(V_COLUMN, ',') INTO C_COLUMN FROM DUAL;
      DBMS_OUTPUT.PUT_LINE(C_COLUMN);
      BEGIN
        V_SQL := 'select ' || C_COLUMN || ' from ' || V_TABLE || ' where ' ||
                 V_COLUMN_KEY_ID;
        EXECUTE IMMEDIATE V_SQL
          INTO V_STR_TEMP;
        DBMS_OUTPUT.PUT_LINE(V_STR_TEMP);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_STR_TEMP := '';
        WHEN OTHERS THEN
          ERR_MSG := 'A获取字符串列名时出错,请检查入参V_COLUMN';
          GOTO K;
      END;
      V_STR := C_COLUMN || '=' || V_STR_TEMP;
      --大于一个逗号时循环获取
    ELSIF V_COUNT > 1 THEN
      FOR REC IN 1 .. V_COUNT LOOP
        SELECT INSTR(V_COLUMN, ',', V_NUM1) INTO V_IN_NUM FROM DUAL;
        SELECT SUBSTR(V_COLUMN, V_NUM1, V_IN_NUM - V_NUM1)
          INTO C_COLUMN
          FROM DUAL;
        BEGIN
          V_SQL := 'select ' || C_COLUMN || ' from ' || V_TABLE ||
                   ' where ' || V_COLUMN_KEY_ID;
          EXECUTE IMMEDIATE V_SQL
            INTO V_STR_TEMP;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            V_STR_TEMP := '';
          WHEN OTHERS THEN
            ERR_MSG := 'B获取字符串列名时出错,请检查入参V_COLUMN;测试执行语句：' || V_SQL || ';' ||
                       '入参字段：' || V_COLUMN;

            GOTO K;
        END;
        V_STR_TEMP := C_COLUMN || '=' || V_STR_TEMP;
        V_STR      := V_STR || V_STR_TEMP || ';';
        V_NUM1     := V_IN_NUM + 1;
        V_STR_TEMP := '';
      END LOOP;
      OUT_V_STR := V_STR;
    END IF;
    OUT_V_STR := V_STR;
    <<K>>
    OUT_ERR_MSG := ERR_MSG;
  END GET_COLUMN_VALUE;

  --判断脚本是否符合要求并记录进稽核表
  PROCEDURE MODI_CHECK_INTO_TEMP_LOG(IN_TABLE         IN VARCHAR2,
                                     IN_MODI_ENTITY   IN VARCHAR2,
                                     IN_COLUMN_KEY_ID IN VARCHAR2,
                                     IN_COLUMN        IN VARCHAR2,
                                     IN_REMARK        IN VARCHAR2,
                                     IN_MODI_MAN      IN VARCHAR2,
                                     IN_AREA_CODE     IN NUMBER,
                                     ERR_MSG          OUT VARCHAR2) IS

  BEGIN
    V_TABLE         := TRIM(UPPER(IN_TABLE));
    V_MODI_ENTITY   := IN_MODI_ENTITY;
    V_COLUMN_KEY_ID := IN_COLUMN_KEY_ID;
    V_REMARK        := IN_REMARK;
    V_MODI_MAN      := IN_MODI_MAN;
    V_AREA_CODE     := IN_AREA_CODE;
    V_COLUMN        := TRIM(IN_COLUMN);
    IF SUBSTR(V_COLUMN, -1) <> ',' THEN
      V_COLUMN := V_COLUMN || ',';
    ELSE
      NULL;
    END IF;

    OUT_ERR_MSG := '000000';
    V_LOG_ID    := 0;

    --用于记录输入值测试
    /*  insert into temp_test
    values
      (IN_TABLE,
       IN_MODI_ENTITY,
       IN_COLUMN_KEY_ID,
       IN_COLUMN,
       IN_REMARK,
       IN_MODI_MAN,
       IN_AREA_CODE);
       commit;*/

    SELECT TRIM(V_COLUMN_KEY_ID) INTO V_COLUMN_KEY_ID FROM DUAL;
    V_COLUMN_KEY_ID := V_COLUMN_KEY_ID || ' ';
    V_UP_COLUMN     := UPPER(V_COLUMN);

    IF V_MODI_MAN IS NULL THEN
      ERR_MSG := '错误！非正常用户登录修改';
      GOTO R;
    END IF;

    select instr(V_UP_COLUMN, 'COMMON_REGION_ID') into v_ct1 from dual;
    select instr(V_UP_COLUMN, 'AREA_ID') into v_ct2 from dual;
    select instr(V_UP_COLUMN, 'REGION_CD') into v_ct3 from dual;
    if v_ct1 > 0 or v_ct2 > 0 or v_ct3 > 0 then
      ERR_MSG := '错误！不允许修改地区，请到维护系统指定界面修改地区';
      V_TRUE  := 1;
      GOTO R;
    end if;
    ----------------------
    V_COUNT := GET_CHAR_CNT(V_TABLE, '.'); --获取字符串中有多少逗号
    IF V_COUNT = 0 THEN
      IF TRIM(V_TABLE) IN
         ('CUST_PRICE_PLAN_PARAM', 'CUST_PRICE_PLAN_PARAM_HIS') THEN
        V_TABLE_END := V_TABLE;
        V_TABLE     := 'BILL.' || V_TABLE;
      ELSE
        V_TABLE_END   := V_TABLE;
        V_TABLE_BEGIN := 'CRMV2';
        V_TABLE       := 'CRMV2.' || V_TABLE;
      END IF;
    ELSIF V_COUNT > 1 THEN
      ERR_MSG := '错误！输入修改表名有问题1,请检查';
      V_TRUE  := 1;
      GOTO R;
    ELSIF V_COUNT = 1 THEN
      SELECT INSTR(V_TABLE, '.', V_NUM1) INTO V_NUM FROM DUAL;
      SELECT SUBSTR(V_TABLE, V_NUM + 1) INTO V_TABLE_END FROM DUAL;
      SELECT SUBSTR(V_TABLE, 1, V_NUM - 1) INTO V_TABLE_BEGIN FROM DUAL;
      V_TRUE := 0;
    ELSE
      V_TRUE  := 1;
      ERR_MSG := '错误！输入修改表名有问题2,请检查';
      GOTO R;
    END IF;
    BEGIN
      EXECUTE IMMEDIATE 'select 1 from ' || V_TABLE || ' where 1=2';
    EXCEPTION
      WHEN OTHERS THEN
        V_TRUE  := 1;
        ERR_MSG := '错误！输入修改表名有问题3,请检查';
        GOTO R;
    END;
    /*    ----仓库类表修改权限
    SELECT COUNT(1)
      INTO V_CHECK
      FROM ITSC_CRM.MKT_RESO_TABLE
     WHERE TABLE_NAME = V_TABLE_END;

    IF V_CHECK > 0 THEN

      SELECT COUNT(1)
        INTO V_COT_NUM
        FROM ITSC_CRM.MKT_RESO_USER
       WHERE UPPER(GH) = UPPER(V_MODI_MAN);

      IF V_COT_NUM = 0 THEN
        V_TRUE  := 1;
        ERR_MSG := '您没有仓库类表修改权限,请联系省IT维护人员处理';
        GOTO R;
      END IF;
    END IF;*/

    --判断查询到的数据大于1个
    BEGIN
      V_SQL := 'select count(*) from ' || ' ' || V_TABLE || ' where ' ||
               V_COLUMN_KEY_ID;
      EXECUTE IMMEDIATE V_SQL
        INTO V_COUNT;
      IF V_COUNT > 1 THEN
        ERR_MSG := '错误！根据主键查询数据大于1列,
        不允许更改一个条件一次更改多条,请检查脚本或档案数据';
        V_TRUE  := 1;
        GOTO R;
      ELSIF V_COUNT = 0 THEN
        ERR_MSG := '错误！根据主键查询没有查询到数据,请修改条件！';
        V_TRUE  := 1;
        GOTO R;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ERR_MSG := '错误！根据主键没有查询到数据,请检查脚本或档案数据';
        /*  GOTO p;*/
        V_TRUE := 1;
        GOTO R;
      WHEN OTHERS THEN
        ERR_MSG := SQLERRM;
        GOTO R;
    END;

    SELECT COUNT(*)
      INTO V_COUNT
      FROM WH_TABLENAME
     WHERE UPPER(TABLE_NAME) = V_TABLE_END
       AND UPPER(OWNER) = V_TABLE_BEGIN
       AND TABLE_LOCK = 'ENABLED';
    IF V_COUNT > 0 THEN
      NULL;
    ELSIF V_COUNT = 0 THEN
      ERR_MSG := '错误！该表不在修改表单范围,请联系维护人员确认是否需要添加配置表-itsc_crm.wh_tablename';
      V_TRUE  := 1;
      GOTO R;
    END IF;
    FOR REC IN (SELECT *
                  FROM ALL_CONS_COLUMNS
                 WHERE UPPER(TABLE_NAME) = V_TABLE_END
                   AND OWNER = V_TABLE_BEGIN /*'CRM'*/
                   AND CONSTRAINT_NAME LIKE 'PK_%') LOOP
      SELECT INSTR(V_UP_COLUMN, REC.COLUMN_NAME) INTO V_COUNT FROM DUAL;
      IF V_COUNT > 0 THEN
        V_TRUE  := 1;
        ERR_MSG := '错误！不允许修改主键,如需修改请联系后台维护人员';
        GOTO R;
      ELSE
        NULL;
      END IF;
    END LOOP;
    IF V_TRUE = 0 THEN

      --查看可以修改的表
      GET_COLUMN_VALUE(V_COLUMN, V_TABLE, OUT_LOG_MSG, OUT_ERR_MSG);
      IF OUT_ERR_MSG <> '000000' THEN
        ERR_MSG := OUT_ERR_MSG;
        GOTO R;
      END IF;
      SELECT CRM_LOCAL_UNIT_MODI_LOG_ID_SEQ.NEXTVAL
        INTO V_LOG_ID
        FROM DUAL;
      INSERT INTO CRM_LOCAL_UNIT_MODI_TEMP_TABLE
      VALUES
        (V_LOG_ID,
         V_TABLE,
         V_MODI_ENTITY,
         V_COLUMN_KEY_ID,
         V_COLUMN,
         V_REMARK,
         V_MODI_MAN,
         OUT_LOG_MSG,
         V_AREA_CODE,
         '10A',
         NULL,
         NULL,
         SYSDATE,
         NULL,
         V_TABLE_END);
      COMMIT;
      ERR_MSG := '【' || V_MODI_MAN || ',您的修改申请已提交，流水号是' || V_LOG_ID || ' 】
                 【 您修改的字段现档案数据是' || OUT_LOG_MSG || ' 】
                 【 您提交的预修改结果是' || V_MODI_ENTITY || ' 】
                 【 待本地脚本审核人员通过后即可执行成功 】';
    END IF;
    <<R>>
    NULL;
  END MODI_CHECK_INTO_TEMP_LOG;
  FUNCTION GET_CHAR_CNT(IN_CHAR VARCHAR2, IN_CONDITION VARCHAR2)
  /*jiangy -- 用于统计字符量*/
   RETURN NUMBER IS
    V_SQL VARCHAR2(3000);
    --MAX_NUM   NUMBER(10) := 0;
    --BEGIN_NUM NUMBER(10) := 0;
    V_INT NUMBER(10) := 0;
  BEGIN
    V_SQL := IN_CHAR;
    select length(V_SQL) - length(replace(V_SQL, IN_CONDITION))
      into V_INT
      from dual;

    --返回统计数据
    RETURN V_INT;
  END GET_CHAR_CNT;
  procedure exvalue(in_sql          varchar2,
                    in_statement_id varchar2,
                    exe_cost        out varchar) is
    v_in_sql       varchar2(2000);
    v_statement_id varchar2(30);
    v_cost         integer;
    V_SQL          VARCHAR2(1000);
  begin
    v_in_sql       := in_sql;
    v_statement_id := in_statement_id;
    v_sql          := 'explain   plan   set   statement_id=''' ||
                      v_statement_id || '''   for   ' || v_in_sql || '';
    execute immediate v_sql;
    commit;
    select a.cost
      into v_cost
      from plan_table a
     where a.statement_id = v_statement_id
       and a.operation = 'SELECT STATEMENT';
    exe_cost := v_cost;
  EXCEPTION
    WHEN OTHERS THEN
      rollback;
      exe_cost := 0;
  end exvalue;
END CRM_LOCAL_UNIT_MODI;
/
