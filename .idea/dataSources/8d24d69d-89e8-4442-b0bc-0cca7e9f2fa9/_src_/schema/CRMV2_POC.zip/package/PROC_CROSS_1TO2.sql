CREATE PACKAGE           proc_cross_1TO2 IS


  procedure main(i_mdseId       in varchar2, --商品mdseId
                 i_operate      in varchar2, --操作类型
                 o_result       out number,
                 o_errMsg       out varchar2);

--同步商品信息
   PROCEDURE proc_cross_prod_1TO2(i_mdseId       in varchar2,
                                  i_vpn_mdseId   in varchar2,
                                  i_cust_seq     in number,
                                  i_BATCH_ID     in number,
                                  o_errMsg       out varchar2 );
--同步客户信息
   PROCEDURE proc_cross_kh_1TO2(i_mdseId       in varchar2,
                                  i_BATCH_ID     in number,
                                  o_cust_seq     out number,
                                  o_errMsg       out varchar2 );

--同步客户信息
   PROCEDURE proc_cross_account_1TO2(i_prodId       in varchar2,
                                  i_BATCH_ID     in number,
                                  i_region       in number,
                                  i_cust_seq     in number,
                                  i_prod_inst_seq in number,
                                  o_errMsg       out varchar2 );

end proc_cross_1TO2;
/
