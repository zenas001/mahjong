CREATE package           P_CESHI is

  ---ADD SUJ
  -- Public type declarations
  procedure PROD_ATTR_CS_CS(I_AREA    in number, ---区域
                            I_ACCOUNT in varchar2, ---号码
                            O_MSG     out varchar2, ---返回
                            O_remark  out varchar2, ---返回错误日志
                            flag      out varchar2 ---失败为0，成功为1
                            );

  procedure mkt_key_number(store_name in varchar2, ---仓库名称（团队名称）
                           mkt_dalei  in varchar2, ---号码
                           mkt_xilei  in varchar2, ---返回
                           O_remark   out varchar2, ---返回错误日志
                           flag       out varchar2 ---失败为0，成功为1
                           );

  procedure GH_ADD_PRI(in_ghdl         in varchar2, ---工号
                       in_org          in varchar2,
                       in_privilege_id in varchar2,
                       O_remark        out varchar2, ---返回错误日志
                       flag            out varchar2 ---失败为0，成功为1
                       );

  procedure GH_DEL_PRI(in_ghdl         in varchar2, ---工号
                       in_org          in varchar2,
                       in_privilege_id in varchar2,
                       O_remark        out varchar2, ---返回错误日志
                       flag            out varchar2 ---失败为0，成功为1
                       );

 procedure GH_PRIVILEGE(I_STAFF_CODE in varchar2, ---区域
                         I_ORG_NAME   in varchar2, ---号码
                         i_privilege  in varchar2,
                         O_remark     out varchar2, ---返回错误日志
                         flag         out varchar2 ---失败为0，成功为1
                         );

end P_CESHI;
/
