CREATE PACKAGE BODY           PKG_TFJ IS
 /*

    计费停复机(充值开通)。

    Author  : g.caijx

    Created : 2012-08-11
 */

  PROCEDURE PROC_INTF_CHARGE_OPEN IS

    V_COUNT                 NUMBER(10);

    V_PROD_INST_A           PROD_INST%ROWTYPE;

    V_PROD_INST_A_AREA_CODE AREA_CODE%ROWTYPE;

    V_PRODUCT_Z             PRODUCT%ROWTYPE;

  BEGIN



    FOR REC IN (SELECT REQ_ID,ACC_NBR,OPEN_CODE,LATN_ID,OPEN_STATE,

                       CRM_STATE,CRM_DATE

                  FROM (SELECT REQ_ID,ACC_NBR,OPEN_CODE,LATN_ID,OPEN_STATE,

                               CRM_STATE,CRM_DATE

                          FROM INTF_CHARGE_OPEN_REQUEST


                         WHERE OPEN_STATE = '70B'

                           AND CRM_STATE = '70A'

                           AND LATN_ID = '591'

                         ORDER BY REQ_ID)

                 WHERE ROWNUM < 1000) LOOP

      BEGIN

        V_PROD_INST_A := NULL;

        V_PRODUCT_Z   := NULL;



        SELECT

            PROD_INST_ID,PRODUCT_ID,ACC_PROD_INST_ID,ADDRESS_ID,OWNER_CUST_ID,

            PAYMENT_MODE_CD,PRODUCT_PASSWORD,IMPORTANT_LEVEL,AREA_CODE,ACC_NBR,

            EXCH_ID,COMMON_REGION_ID,REMARK,PAY_CYCLE,BEGIN_RENT_TIME,

            STOP_RENT_TIME,FINISH_TIME,STOP_STATUS,STATUS_CD,CREATE_DATE,

            STATUS_DATE,UPDATE_DATE,PROC_SERIAL,USE_CUST_ID,EXT_PROD_INST_ID,

            ADDRESS_DESC,AREA_ID,UPDATE_STAFF,CREATE_STAFF,REC_UPDATE_DATE,

            ACCOUNT,VERSION,COMMUNITY_ID,EXT_ACC_PROD_INST_ID



          INTO

            V_PROD_INST_A.PROD_INST_ID,V_PROD_INST_A.PRODUCT_ID,V_PROD_INST_A.ACC_PROD_INST_ID,V_PROD_INST_A.ADDRESS_ID,V_PROD_INST_A.OWNER_CUST_ID,

            V_PROD_INST_A.PAYMENT_MODE_CD,V_PROD_INST_A.PRODUCT_PASSWORD,V_PROD_INST_A.IMPORTANT_LEVEL,V_PROD_INST_A.AREA_CODE,V_PROD_INST_A.ACC_NBR,

            V_PROD_INST_A.EXCH_ID,V_PROD_INST_A.COMMON_REGION_ID,V_PROD_INST_A.REMARK,V_PROD_INST_A.PAY_CYCLE,V_PROD_INST_A.BEGIN_RENT_TIME,

            V_PROD_INST_A.STOP_RENT_TIME,V_PROD_INST_A.FINISH_TIME,V_PROD_INST_A.STOP_STATUS,V_PROD_INST_A.STATUS_CD,V_PROD_INST_A.CREATE_DATE,

            V_PROD_INST_A.STATUS_DATE,V_PROD_INST_A.UPDATE_DATE,V_PROD_INST_A.PROC_SERIAL,V_PROD_INST_A.USE_CUST_ID,V_PROD_INST_A.EXT_PROD_INST_ID,

            V_PROD_INST_A.ADDRESS_DESC,V_PROD_INST_A.AREA_ID,V_PROD_INST_A.UPDATE_STAFF,V_PROD_INST_A.CREATE_STAFF,V_PROD_INST_A.REC_UPDATE_DATE,

            V_PROD_INST_A.ACCOUNT,V_PROD_INST_A.VERSION,V_PROD_INST_A.COMMUNITY_ID,V_PROD_INST_A.EXT_ACC_PROD_INST_ID



          FROM PROD_INST PI

         WHERE PI.ACC_NBR = REC.ACC_NBR

           AND PI.AREA_CODE = '0591';



        SELECT

            AREA_CODE_ID,REGION_ID,AREA_NBR,AREA_CODE,AREA_ID,

            REGION_CD,UPDATE_STAFF,CREATE_STAFF

          INTO

            V_PROD_INST_A_AREA_CODE.AREA_CODE_ID,V_PROD_INST_A_AREA_CODE.REGION_ID,V_PROD_INST_A_AREA_CODE.AREA_NBR,V_PROD_INST_A_AREA_CODE.AREA_CODE,V_PROD_INST_A_AREA_CODE.AREA_ID,

            V_PROD_INST_A_AREA_CODE.REGION_CD,V_PROD_INST_A_AREA_CODE.UPDATE_STAFF,V_PROD_INST_A_AREA_CODE.CREATE_STAFF

          FROM AREA_CODE AC

         WHERE AC.REGION_ID = V_PROD_INST_A.COMMON_REGION_ID

           AND ROWNUM = 1;



        FOR REC1 IN (SELECT

                        PIZ.PROD_INST_ID,PIZ.PRODUCT_ID,PIZ.ACC_PROD_INST_ID,PIZ.ADDRESS_ID,PIZ.OWNER_CUST_ID,

                        PIZ.PAYMENT_MODE_CD,PIZ.PRODUCT_PASSWORD,PIZ.IMPORTANT_LEVEL,PIZ.AREA_CODE,PIZ.ACC_NBR,

                        PIZ.EXCH_ID,PIZ.COMMON_REGION_ID,PIZ.REMARK,PIZ.PAY_CYCLE,PIZ.BEGIN_RENT_TIME,

                        PIZ.STOP_RENT_TIME,PIZ.FINISH_TIME,PIZ.STOP_STATUS,PIZ.STATUS_CD,PIZ.CREATE_DATE,

                        PIZ.STATUS_DATE,PIZ.UPDATE_DATE,PIZ.PROC_SERIAL,PIZ.USE_CUST_ID,PIZ.EXT_PROD_INST_ID,

                        PIZ.ADDRESS_DESC,PIZ.AREA_ID,PIZ.UPDATE_STAFF,PIZ.CREATE_STAFF,PIZ.REC_UPDATE_DATE,

                        PIZ.ACCOUNT,PIZ.VERSION,PIZ.COMMUNITY_ID,PIZ.EXT_ACC_PROD_INST_ID



                       FROM PROD_INST_REL PIR, PROD_INST PIZ

                      WHERE PIR.PROD_INST_A_ID = V_PROD_INST_A.PROD_INST_ID

                        AND PIR.PROD_INST_Z_ID = PIZ.PROD_INST_ID

                        AND PIR.RELATION_TYPE_CD = '100600') LOOP



          SELECT COUNT(*)

            INTO V_COUNT

            FROM TFJ_NWKCALL_CONFIG C

           WHERE C.MDSE_SPEC_ID = REC1.PRODUCT_ID

             AND C.PROD_SPEC_ID = V_PROD_INST_A.PRODUCT_ID

             AND '0' || C.AREA_ID = V_PROD_INST_A.AREA_CODE

             AND C.STATE = 'A'

             AND C.TFJ_FLAG = 'Y'

             AND ROWNUM = 1;



          IF V_COUNT > 0 THEN

            SELECT

                PRODUCT_ID,PRODUCT_NBR,PRODUCT_NAME,PRODUCT_DESC,MANAGE_GRADE,

                PRODUCT_TYPE,PRODUCT_PROVIDER_ID,EFF_DATE,EXP_DATE,PROD_FUNC_TYPE,

                GROUP_CODE,VERSION_CD,PROD_FUN_CD,SYSTEM_CODE,EXT_PROD_ID,

                STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,

                REGION_CD,UPDATE_STAFF,CREATE_STAFF,INTF_TYPE,OBJECT_TYPE,

                SUP_PRODUCT_ID,REMARK,IBS_PROD_TYPE

              INTO

                V_PRODUCT_Z.PRODUCT_ID,V_PRODUCT_Z.PRODUCT_NBR,V_PRODUCT_Z.PRODUCT_NAME,V_PRODUCT_Z.PRODUCT_DESC,V_PRODUCT_Z.MANAGE_GRADE,

                V_PRODUCT_Z.PRODUCT_TYPE,V_PRODUCT_Z.PRODUCT_PROVIDER_ID,V_PRODUCT_Z.EFF_DATE,V_PRODUCT_Z.EXP_DATE,V_PRODUCT_Z.PROD_FUNC_TYPE,

                V_PRODUCT_Z.GROUP_CODE,V_PRODUCT_Z.VERSION_CD,V_PRODUCT_Z.PROD_FUN_CD,V_PRODUCT_Z.SYSTEM_CODE,V_PRODUCT_Z.EXT_PROD_ID,

                V_PRODUCT_Z.STATUS_CD,V_PRODUCT_Z.STATUS_DATE,V_PRODUCT_Z.CREATE_DATE,V_PRODUCT_Z.UPDATE_DATE,V_PRODUCT_Z.AREA_ID,

                V_PRODUCT_Z.REGION_CD,V_PRODUCT_Z.UPDATE_STAFF,V_PRODUCT_Z.CREATE_STAFF,V_PRODUCT_Z.INTF_TYPE,V_PRODUCT_Z.OBJECT_TYPE,

                V_PRODUCT_Z.SUP_PRODUCT_ID,V_PRODUCT_Z.REMARK,V_PRODUCT_Z.IBS_PROD_TYPE

              FROM PRODUCT P

             WHERE P.PRODUCT_ID = REC1.PRODUCT_ID;



            INSERT INTO TFJ_WORK_ORDER_CDMA

              (ORDER_SERIAL_NBR,

               PROD_SPEC_ID,

               SERV_ID,

               ACC_NBR,

               ACTION,

               ORDER_STATE,

               SOURCE,

               CREATE_DATE,

               STATE,

               STATE_DATE,

               LATN_ID,

               BUREAU_ID,

               IF_QUOTA,

               PRIORITY,

               STAFF_ID,

               COMMENTS,

               AREA_ID,

               MDSE_SPEC_ID,

               SWD_ID,

               INSERT_DATE,

               EXCH_ID,

               HLR_NBR,

               STS,

               STS_DATE,

               OWE_QUOTA,

               PAY_TYPE)

              SELECT SEQ_RDER_SERIAL_NBR_ID.NEXTVAL,

                     (SELECT P.EXT_PROD_ID

                        FROM PRODUCT P

                       WHERE P.PRODUCT_ID = V_PROD_INST_A.PRODUCT_ID),

                     V_PROD_INST_A.PROD_INST_ID,

                     V_PROD_INST_A.ACC_NBR,

                     REC.OPEN_CODE,

                     '5SA',

                     '充值开通',

                     SYSDATE,

                     '5SN',

                     SYSDATE,

                     REC.LATN_ID,

                     V_PROD_INST_A_AREA_CODE.AREA_NBR,

                     'F',

                     '1',

                     '1',

                     NULL,

                     SUBSTR(V_PROD_INST_A_AREA_CODE.AREA_NBR, 1, 3),

                     V_PRODUCT_Z.EXT_PROD_ID,

                     '0',

                     SYSDATE,

                     NULL,

                     NULL,

                     '5SN',

                     SYSDATE,

                     NULL,

                     DECODE(V_PROD_INST_A.PAYMENT_MODE_CD,

                            '1201',

                            '1',

                            '1200',

                            '2',

                            '2100',

                            '3')

                FROM DUAL;

          END IF;

        END LOOP;



        UPDATE INTF_CHARGE_OPEN_REQUEST

           SET CRM_STATE = '70B', CRM_DATE = SYSDATE

         WHERE REQ_ID = REC.REQ_ID;

         COMMIT;

      EXCEPTION

        WHEN OTHERS THEN

          ROLLBACK;

      END;

    END LOOP;

  END;



  PROCEDURE PROC_EXTRACT_WORK_ORDER

  /*

      功能: 从计费系统把非CDMA的数据搬到CRM接口表中。

    */

   IS

    V_INT        NUMBER(10) := 0;

    V_NUM        NUMBER(10) := 0;

    V_BEGIN_DATE DATE;

  BEGIN

    SELECT SYSDATE INTO V_BEGIN_DATE FROM DUAL;

    FOR REC IN (SELECT ORDER_SERIAL_NBR

                  FROM (SELECT ORDER_SERIAL_NBR

                          FROM INTF_WORK_ORDER

                         WHERE NBR_TYPE <> '3'

                           AND CRM_STATE = '70A'

                         ORDER BY ORDER_SERIAL_NBR)

                 WHERE ROWNUM < 3000) LOOP

      V_INT := V_INT + 1;

      V_NUM := V_NUM + 1;

      BEGIN

        INSERT INTO WORK_ORDER

          (ORDER_SERIAL_NBR,

           SERV_ID,

           ACTION,

           SOURCE,

           CREATE_DATE,

           STATE,

           STATE_DATE,

           AREA_ID,

           ACC_NBR,

           COMMENTS,

           STAFF_ID,

           PROD_SPEC_ID,

           IF_QUOTA,

           PRIORITY,

           SWD_ID,

           MDSE_SPEC_ID,

           ORDER_STATE,

           LATN_ID,

           FLAG,

           BUREAU_ID,

           SERVICE_CODE,

           HLR_NBR,

           EXCH_ID,

           STOP_FLAG,

           IMS_CODE)

          SELECT TO_CHAR(ORDER_SERIAL_NBR),

                 SERV_ID,

                 DECODE(ACTION, 1, 3, 2, 4, 4, 6, 9, 3, 7, 8, ACTION),

                 SUBSTR(SOURCE, 1, 5),

                 SYSDATE,

                 '5SA',

                 SYSDATE,

                 LATN_ID, --AREA_ID,

                 ACC_NBR,

                 COMMENTS,

                 1,

                 PROD_SPEC_ID,

                 IF_QUOTA,

                 '',

                 SWD_ID, --SWD_ID,

                 NULL,

                 '5SA',

                 LATN_ID,

                 0,

                 BUREAU_ID,

                 SERVICE_CODE,

                 HLR_NBR,

                 EXCH_ID,

                 STOP_FLAG,

                 NULL --IMS_CODE

            FROM INTF_WORK_ORDER

           WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;

        UPDATE INTF_WORK_ORDER

           SET CRM_STATE = '70B', CRM_STATE_DATE = SYSDATE

         WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;

      EXCEPTION

        WHEN OTHERS THEN

          UPDATE INTF_WORK_ORDER

             SET CRM_STATE = '70E', CRM_STATE_DATE = SYSDATE

           WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;

      END;

      IF V_INT > 100 THEN

        COMMIT;

        V_INT := 0;

      END IF;

    END LOOP;

    IF V_NUM > 0 THEN

      INSERT INTO WORK_ORDER_TEMP

      VALUES

        ('',

         V_NUM,

         V_BEGIN_DATE,

         SYSDATE,

         SEQ_WORK_ORDER_TEMP_ID.NEXTVAL,

         '非CDMA',

         '');

    END IF;

    --COMMIT;

    --PKG_UTIL.LOCK_SLEEP(5);

  END;



  PROCEDURE PROC_EXTRACT_WORK_ORDER_CDMA

  /*

      功能: 从计费系统把CDMA的数据搬到CRM接口表中。

   */

   IS

    V_INT        NUMBER(10) := 0;

    V_NUM        NUMBER(10) := 0;

    V_BEGIN_DATE DATE;

  BEGIN

    SELECT SYSDATE INTO V_BEGIN_DATE FROM DUAL;

    FOR REC IN (SELECT ORDER_SERIAL_NBR

                  FROM (SELECT ORDER_SERIAL_NBR

                          FROM INTF_WORK_ORDER

                         WHERE NBR_TYPE = '3'

                           AND CRM_STATE = '70A'

                         ORDER BY ORDER_SERIAL_NBR)

                 WHERE ROWNUM < 3000) LOOP

      V_INT := V_INT + 1;

      V_NUM := V_NUM + 1;

      BEGIN

        INSERT INTO WORK_ORDER_CDMA

          (ORDER_SERIAL_NBR,

           SERV_ID,

           ACTION,

           SOURCE,

           CREATE_DATE,

           STATE,

           STATE_DATE,

           AREA_ID,

           ACC_NBR,

           COMMENTS,

           STAFF_ID,

           PROD_SPEC_ID,

           IF_QUOTA,

           PRIORITY,

           SWD_ID,

           MDSE_SPEC_ID,

           ORDER_STATE,

           LATN_ID,

           FLAG,

           BUREAU_ID,

           SERVICE_CODE,

           HLR_NBR,

           EXCH_ID,

           STOP_FLAG,

           OWE_QUOTA)

          SELECT TO_CHAR(ORDER_SERIAL_NBR),

                 SERV_ID,

                 DECODE(ACTION, 1, 3, 2, 4, 4, 6, 9, 3, 7, 8, ACTION),

                 SUBSTR(SOURCE, 1, 5),

                 SYSDATE,

                 '5SA',

                 SYSDATE,

                 LATN_ID, --AREA_ID,

                 ACC_NBR,

                 COMMENTS,

                 1,

                 PROD_SPEC_ID,

                 IF_QUOTA,

                 '',

                 SWD_ID, --SWD_ID,

                 NULL,

                 '5SA',

                 LATN_ID,

                 0,

                 BUREAU_ID,

                 SERVICE_CODE,

                 HLR_NBR,

                 EXCH_ID,

                 STOP_FLAG,

                 OWE_AMOUNT / 10 OWE_AMOUNT

            FROM INTF_WORK_ORDER

           WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;

        UPDATE INTF_WORK_ORDER

           SET CRM_STATE = '70B', CRM_STATE_DATE = SYSDATE

         WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;

      EXCEPTION

        WHEN OTHERS THEN

          UPDATE INTF_WORK_ORDER

             SET CRM_STATE = '70E', CRM_STATE_DATE = SYSDATE

           WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;

      END;

      IF V_INT > 100 THEN

        COMMIT;

        V_INT := 0;

      END IF;

    END LOOP;

    IF V_NUM > 0 THEN

      INSERT INTO WORK_ORDER_TEMP

      VALUES

        ('',

         V_NUM,

         V_BEGIN_DATE,

         SYSDATE,

         SEQ_WORK_ORDER_TEMP_ID.NEXTVAL,

         'CDMA',

         '');

    END IF;

    --COMMIT;

    --PKG_UTIL.LOCK_SLEEP(10);

  END;



  /*

  功能: WORK_ORDER_CDMA 分发程控

  Author  : g.caijx

  Created : 2012-8-6

  */

  PROCEDURE PROC_NWK_TRANSFORM_ORDER_CDMA(I_ORDER_SERIAL_NBR NUMBER, --WORK_ORDER_CDMA.ORDER_SERIAL_NBR

                                          I_SERV_ID          IN NUMBER --产品实例标识

                                          ) IS

    V_COUNT            NUMBER(10);

    V_ORDER_SERIAL_NBR NUMBER(12);

    V_ERR_MSG          VARCHAR(1000);



    V_ACTION NUMBER(5); --停复机动作

    V_FLAG   NUMBER(10); --是否封顶断网、校园宽带（驻地网）停机标识

    V_IS_CREDIT_CONTROL TFJ_WORK_ORDER_CDMA.IS_CREDIT_CONTROL%TYPE:=NULL;

  BEGIN



    FOR REC1 IN (SELECT PIA.PRODUCT_ID PRODUCT_ID_A,

                        PIZ.PRODUCT_ID PRODUCT_ID_Z,

                        PIZ.PROD_INST_ID PROD_INST_ID_Z,

                        PIA.AREA_CODE,

                        PZ.EXT_PROD_ID,

                        DECODE(PIA.PAYMENT_MODE_CD,

                               '1201',

                               '1',

                               '1200',

                               '2',

                               '2100',

                               '3') PAYMENT_MODE_CD

                   FROM PROD_INST     PIA,

                        PROD_INST_REL PIR,

                        PROD_INST     PIZ,

                        PRODUCT       PZ

                  WHERE PIA.PROD_INST_ID = I_SERV_ID

                    AND PIA.PROD_INST_ID = PIR.PROD_INST_A_ID

                    AND PIR.PROD_INST_Z_ID = PIZ.PROD_INST_ID

                    AND PIR.RELATION_TYPE_CD = '100600'

                    AND PIZ.PRODUCT_ID = PZ.PRODUCT_ID) LOOP



      SELECT COUNT(*)

        INTO V_COUNT

        FROM TFJ_NWKCALL_CONFIG C

       WHERE C.MDSE_SPEC_ID = REC1.PRODUCT_ID_Z

         AND C.PROD_SPEC_ID = REC1.PRODUCT_ID_A

         AND '0' || C.AREA_ID = REC1.AREA_CODE

         AND C.STATE = 'A'

         AND C.TFJ_FLAG = 'Y'

         AND ROWNUM = 1;



      --判断被复机的用户是否有‘被封顶断网’特性，若有此特性，就不发1X和evdo复机单；

      --若无此特性，则发关联的复机单；

      IF V_COUNT > 0 AND

         REC1.PRODUCT_ID_Z IN (800296775, 800303268, 800000576) THEN

        --800296775: 1X上网，800303268: 3G上网，800000576：校园宽带（驻地网）

        SELECT C.ACTION

          INTO V_ACTION

          FROM WORK_ORDER_CDMA C

         WHERE C.ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR

           AND ROWNUM = 1;



        IF V_ACTION = 6 THEN

          IF REC1.PRODUCT_ID_Z IN (800296775, 800303268) THEN

            --1X上网，3G上网

            SELECT COUNT(*)

              INTO V_FLAG

              FROM PROD_INST_ATTR A

             WHERE A.PROD_INST_ID = I_SERV_ID

               AND A.ATTR_ID = 800000279 --800000279: 封顶断网状态

               AND A.ATTR_VALUE = 'FDDW2' --FDDW2: 被封顶断网

               AND A.STATUS_CD = '1000'

               AND ROWNUM = 1;

            IF V_FLAG > 0 THEN

              V_COUNT := 0; --置为0, 表示不发复机单.

            END IF;

          ELSE

            --校园宽带（驻地网）

            SELECT COUNT(*)

              INTO V_FLAG

              FROM PROD_INST_ATTR A

             WHERE A.PROD_INST_ID = REC1.PROD_INST_ID_Z

               AND A.ATTR_ID = 800001698 --800001698: 停复机标识

               AND A.ATTR_VALUE = 'TJ' --TJ: 停机

               AND A.STATUS_CD = '1000'

               AND ROWNUM = 1;

            IF V_FLAG > 0 THEN

              V_COUNT := 0; --置为0, 表示不发复机单.

            END IF;

          END IF;

        END IF;

      END IF;



      IF V_COUNT > 0 THEN

        SELECT SEQ_RDER_SERIAL_NBR_ID.NEXTVAL

          INTO V_ORDER_SERIAL_NBR

          FROM DUAL;

        BEGIN

          SELECT ATTR_VALUE

            INTO V_IS_CREDIT_CONTROL

            FROM PROD_INST_ATTR

           WHERE PROD_INST_ID =  I_SERV_ID

             AND ATTR_ID = 800072702

             AND STATUS_CD != 1100;

        EXCEPTION WHEN OTHERS THEN

          V_IS_CREDIT_CONTROL := NULL;

        END;

        INSERT INTO TFJ_WORK_ORDER_CDMA

          (ORDER_SERIAL_NBR,

           PROD_SPEC_ID,

           SERV_ID,

           ACC_NBR,

           ACTION,

           ORDER_STATE,

           SOURCE,

           CREATE_DATE,

           STATE,

           STATE_DATE,

           LATN_ID,

           BUREAU_ID,

           IF_QUOTA,

           PRIORITY,

           STAFF_ID,

           COMMENTS,

           AREA_ID,

           MDSE_SPEC_ID,

           SWD_ID,

           INSERT_DATE,

           EXCH_ID,

           HLR_NBR,

           STS,

           STS_DATE,

           OWE_QUOTA,

           PAY_TYPE,

           IS_CREDIT_CONTROL)

          SELECT V_ORDER_SERIAL_NBR,

                 (SELECT P.EXT_PROD_ID

                    FROM PRODUCT P

                   WHERE P.PRODUCT_ID = PROD_SPEC_ID),

                 SERV_ID,

                 ACC_NBR,

                 ACTION,

                 ORDER_STATE,

                 SOURCE,

                 CREATE_DATE,

                 '5SN',

                 STATE_DATE,

                 LATN_ID,

                 BUREAU_ID,

                 IF_QUOTA,

                 PRIORITY,

                 STAFF_ID,

                 COMMENTS,

                 AREA_ID,

                 REC1.EXT_PROD_ID,

                 SWD_ID,

                 SYSDATE,

                 EXCH_ID,

                 HLR_NBR,

                 '5SN',

                 SYSDATE,

                 OWE_QUOTA,

                 REC1.PAYMENT_MODE_CD,

                 V_IS_CREDIT_CONTROL

            FROM WORK_ORDER_CDMA

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;



        INSERT INTO WORK_ORDER_CDMA_HIS

          (ORDER_SERIAL_NBR,

           PARENT_ORDER_SERIAL_NBR,

           PROD_SPEC_ID,

           SERV_ID,

           ACC_NBR,

           SERVICE_CODE,

           ACTION,

           ORDER_STATE,

           SOURCE,

           CREATE_DATE,

           STATE,

           STATE_DATE,

           LATN_ID,

           BUREAU_ID,

           IF_QUOTA,

           PRIORITY,

           STAFF_ID,

           COMMENTS,

           AREA_ID,

           SWD_ID,

           MDSE_SPEC_ID,

           FLAG,

           EXCH_ID,

           HLR_NBR,

           STOP_FLAG,

           OWE_QUOTA)

          SELECT V_ORDER_SERIAL_NBR,

                 ORDER_SERIAL_NBR,

                 PROD_SPEC_ID,

                 SERV_ID,

                 ACC_NBR,

                 SERVICE_CODE,

                 ACTION,

                 ORDER_STATE,

                 SOURCE,

                 CREATE_DATE,

                 '5SC',

                 SYSDATE,

                 LATN_ID,

                 BUREAU_ID,

                 IF_QUOTA,

                 PRIORITY,

                 STAFF_ID,

                 COMMENTS,

                 AREA_ID,

                 SWD_ID,

                 REC1.EXT_PROD_ID,

                 FLAG,

                 EXCH_ID,

                 HLR_NBR,

                 STOP_FLAG,

                 OWE_QUOTA

            FROM WORK_ORDER_CDMA

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

      END IF;

    END LOOP;



    UPDATE WORK_ORDER_CDMA

       SET STATE = '5SN', STATE_DATE = SYSDATE

     WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

  EXCEPTION

    WHEN OTHERS THEN

      V_ERR_MSG := SQLERRM;

      ROLLBACK;

      UPDATE WORK_ORDER_CDMA

         SET STATE = '5SE', STATE_DATE = SYSDATE, COMMENTS = V_ERR_MSG

       WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

  END;



  /*

  功能: WORK_ORDER 分发程控

  Author  : g.caijx

  Created : 2012-8-6

  */

  PROCEDURE PROC_NWK_TRANSFORM_ORDER(I_ORDER_SERIAL_NBR NUMBER, --WORK_ORDER.ORDER_SERIAL_NBR

                                     I_SERV_ID          IN NUMBER --产品实例标识

                                     ) IS

    V_COUNT            NUMBER(10);

    V_ORDER_SERIAL_NBR NUMBER(12);

    V_ERR_MSG          VARCHAR(1000);

    V_IS_CREDIT_CONTROL TFJ_WORK_ORDER.IS_CREDIT_CONTROL%TYPE:=NULL;

  BEGIN

    FOR REC1 IN (SELECT PIA.PRODUCT_ID PRODUCT_ID_A,

                        PIZ.PRODUCT_ID PRODUCT_ID_Z,

                        PIA.AREA_CODE,

                        PZ.EXT_PROD_ID,

                        DECODE(PIA.PAYMENT_MODE_CD,

                               '1201',

                               '1',

                               '1200',

                               '2',

                               '2100',

                               '3') PAYMENT_MODE_CD

                   FROM PROD_INST     PIA,

                        PROD_INST_REL PIR,

                        PROD_INST     PIZ,

                        PRODUCT       PZ

                  WHERE PIA.PROD_INST_ID = I_SERV_ID

                    AND PIA.PROD_INST_ID = PIR.PROD_INST_A_ID

                    AND PIR.PROD_INST_Z_ID = PIZ.PROD_INST_ID

                    AND PIR.RELATION_TYPE_CD = '100600'

                    AND PIZ.PRODUCT_ID = PZ.PRODUCT_ID) LOOP



      SELECT COUNT(*)

        INTO V_COUNT

        FROM TFJ_NWKCALL_CONFIG C

       WHERE C.MDSE_SPEC_ID = REC1.PRODUCT_ID_Z

         AND C.PROD_SPEC_ID = REC1.PRODUCT_ID_A

         AND '0' || C.AREA_ID = REC1.AREA_CODE

         AND C.STATE = 'A'

         AND C.TFJ_FLAG = 'Y'

         AND ROWNUM = 1;



      IF V_COUNT > 0 THEN

        SELECT SEQ_RDER_SERIAL_NBR_ID.NEXTVAL

          INTO V_ORDER_SERIAL_NBR

          FROM DUAL;

        BEGIN

          SELECT ATTR_VALUE

            INTO V_IS_CREDIT_CONTROL

            FROM PROD_INST_ATTR

           WHERE PROD_INST_ID =  I_SERV_ID

             AND ATTR_ID = 800072702

             AND STATUS_CD != 1100;

        EXCEPTION WHEN OTHERS THEN

          V_IS_CREDIT_CONTROL := NULL;

        END;

        INSERT INTO TFJ_WORK_ORDER

          (ORDER_SERIAL_NBR,

           PROD_SPEC_ID,

           SERV_ID,

           ACC_NBR,

           ACTION,

           ORDER_STATE,

           SOURCE,

           CREATE_DATE,

           STATE,

           STATE_DATE,

           LATN_ID,

           BUREAU_ID,

           IF_QUOTA,

           PRIORITY,

           STAFF_ID,

           COMMENTS,

           AREA_ID,

           MDSE_SPEC_ID,

           SWD_ID,

           INSERT_DATE,

           EXCH_ID,

           HLR_NBR,

           IS_CREDIT_CONTROL)

          SELECT V_ORDER_SERIAL_NBR,

                 (SELECT P.EXT_PROD_ID

                    FROM PRODUCT P

                   WHERE P.PRODUCT_ID = PROD_SPEC_ID),

                 SERV_ID,

                 ACC_NBR,

                 ACTION,

                 ORDER_STATE,

                 SOURCE,

                 CREATE_DATE,

                 '5SN',

                 STATE_DATE,

                 LATN_ID,

                 BUREAU_ID,

                 IF_QUOTA,

                 PRIORITY,

                 STAFF_ID,

                 COMMENTS,

                 AREA_ID,

                 REC1.EXT_PROD_ID,

                 SWD_ID,

                 SYSDATE,

                 EXCH_ID,

                 HLR_NBR,

                 V_IS_CREDIT_CONTROL

            FROM WORK_ORDER

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;



        INSERT INTO WORK_ORDER_HIS

          (ORDER_SERIAL_NBR,

           PARENT_ORDER_SERIAL_NBR,

           PROD_SPEC_ID,

           SERV_ID,

           ACC_NBR,

           SERVICE_CODE,

           ACTION,

           ORDER_STATE,

           SOURCE,

           CREATE_DATE,

           STATE,

           STATE_DATE,

           LATN_ID,

           BUREAU_ID,

           IF_QUOTA,

           PRIORITY,

           STAFF_ID,

           COMMENTS,

           AREA_ID,

           SWD_ID,

           MDSE_SPEC_ID,

           FLAG,

           EXCH_ID,

           HLR_NBR,

           STOP_FLAG)

          SELECT V_ORDER_SERIAL_NBR,

                 ORDER_SERIAL_NBR,

                 PROD_SPEC_ID,

                 SERV_ID,

                 ACC_NBR,

                 SERVICE_CODE,

                 ACTION,

                 ORDER_STATE,

                 SOURCE,

                 CREATE_DATE,

                 '5SC',

                 SYSDATE,

                 LATN_ID,

                 BUREAU_ID,

                 IF_QUOTA,

                 PRIORITY,

                 STAFF_ID,

                 COMMENTS,

                 AREA_ID,

                 SWD_ID,

                 REC1.EXT_PROD_ID,

                 FLAG,

                 EXCH_ID,

                 HLR_NBR,

                 STOP_FLAG

            FROM WORK_ORDER

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

      END IF;

    END LOOP;



    UPDATE WORK_ORDER

       SET STATE = '5SN', STATE_DATE = SYSDATE

     WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

  EXCEPTION

    WHEN OTHERS THEN

      V_ERR_MSG := SQLERRM;

      ROLLBACK;

      UPDATE WORK_ORDER

         SET STATE = '5SE', STATE_DATE = SYSDATE, COMMENTS = V_ERR_MSG

       WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

  END;



 PROCEDURE PROC_LOAD_WORK_ORDER(I_SERV_ID IN NUMBER, --产品实例id

                                I_SERV_TYPE_ID IN VARCHAR2, --产品规格id

                                I_SERIAL_NBR IN VARCHAR2, --TFJ_ACC_NBR表的主键

                                I_ACT_TYPE IN VARCHAR2 --动作类型（T：双停；S：单停；K：开机）

                                )

   /*

     功能: 对TFJ_ACC_NBR表中记录进行CRM档案更新处理。

   */

  IS

   V_CUST_ORDER_ID TFJ_ACC_NBR.PROC_ORD_ID%TYPE; --生成的订单id

   V_ERR_CODE NUMBER(4) := 0; --0:成功, 1失败

   V_ERR_MSG TFJ_ACC_NBR.ERR_STR%TYPE;

   V_COUNT        NUMBER(10);

    V_ORDER_SERIAL_NBR   TFJ_ACC_NBR.ORDER_SERIAL_NBR%TYPE;

    V_STOP_FLAG2_CNT     NUMBER(10):=0;

   V_COUNT_DELETE NUMBER(10);

 BEGIN

   BEGIN

     UPDATE TFJ_ACC_NBR

        SET STATE = 'R', ERR_STR = '抵消单'

      WHERE (STATE = 'A' OR STATE = 'E')

        AND SERV_ID = I_SERV_ID

        AND TO_NUMBER(SERIAL_NBR) < TO_NUMBER(I_SERIAL_NBR);

     COMMIT;

   EXCEPTION

     WHEN OTHERS THEN

       NULL;

   END;

   /* 2014-10-22 liufzh
    *crm00058543  FJCRMV2.0_BUG_三明市_关于陈如忠等50个欠费用户无法停机的事宜
    * 判断这个号码是否拆机状态，是的话就不处理
    */
   select count(*)
     into V_COUNT_DELETE
     from prod_inst
    where prod_inst_id = I_SERV_ID
      and status_cd = '110000';
   IF V_COUNT_DELETE >= 1 then
      V_ERR_MSG := '该号码已经拆机,无需处理';
     UPDATE TFJ_ACC_NBR SET STATE='D', ERR_STR = V_ERR_MSG WHERE SERIAL_NBR = I_SERIAL_NBR;
     INSERT INTO TFJ_ACC_NBR_BAK

          (SERIAL_NBR,

           SERV_TYPE_ID,

           ACC_NBR,

           ACT_TYPE,

           STATE,

           STATE_DATE,

           PROC_ORD_ID,

           PROC_NUM,

           ERR_NUM,

           ERR_STR,

           APP_AREA_ID,

           AREA_ID,

           SERV_ID,

           ORDER_SERIAL_NBR,

           COURSE_NUM)

          SELECT SERIAL_NBR,

                 SERV_TYPE_ID,

                 ACC_NBR,

                 ACT_TYPE,

                 STATE,

                 STATE_DATE,

                 PROC_ORD_ID,

                 PROC_NUM,

                 ERR_NUM,

                 ERR_STR,

                 APP_AREA_ID,

                 AREA_ID,

                 SERV_ID,

                 ORDER_SERIAL_NBR,

                 COURSE_NUM

            FROM TFJ_ACC_NBR

           WHERE SERIAL_NBR = I_SERIAL_NBR;



        DELETE TFJ_ACC_NBR WHERE SERIAL_NBR = I_SERIAL_NBR;

   ELSE
      --crm00062898  FJCRMV2.0_REQ_全省_关于停机出单用户补应停未停工单的优化  qiurl 20150713
      BEGIN

        SELECT ORDER_SERIAL_NBR

          INTO V_ORDER_SERIAL_NBR

          FROM TFJ_ACC_NBR

         WHERE SERIAL_NBR = I_SERIAL_NBR;

      EXCEPTION WHEN OTHERS THEN

        NULL;

      END;

      SELECT COUNT(*)

        INTO V_STOP_FLAG2_CNT

        FROM WORK_ORDER

       WHERE ORDER_SERIAL_NBR = V_ORDER_SERIAL_NBR

         AND STOP_FLAG = 2;

      IF V_STOP_FLAG2_CNT = 0 THEN

         SELECT COUNT(*)

           INTO V_STOP_FLAG2_CNT

           FROM WORK_ORDER_CDMA

          WHERE ORDER_SERIAL_NBR = V_ORDER_SERIAL_NBR

            AND STOP_FLAG = 2;

      END IF;

      IF V_STOP_FLAG2_CNT >0   THEN

         V_COUNT := 0;

         V_ERR_CODE := 0;

         V_CUST_ORDER_ID := -1;

         V_ERR_MSG := 'WORK_ORDER系统表STOP_TYPE字段值为2,不生成CRM定单';

         GOTO  DEAL_TFJ_ACC_NBR;

      END IF;


    --crm00025751 对于CDMA业务，停复机不要判断在途单

    IF I_SERV_TYPE_ID = '800000002' THEN

      --800000002: 移动语音
       V_COUNT := 0;
    ELSE

      --判断在途单

      IF PKG_COMMON.FNC_IS_ON_ROAD(I_SERV_ID) THEN

        V_COUNT := 1;

      ELSE

        V_COUNT := 0;

      END IF;

    END IF;


    <<DEAL_TFJ_ACC_NBR>>

    IF V_COUNT = 0 THEN

      IF V_STOP_FLAG2_CNT = 0 THEN

      BEGIN

        PKG_TFJ.SP_TFJ_REQUEST(I_SERV_ID,

                               I_SERIAL_NBR,

                               I_ACT_TYPE,

                               V_CUST_ORDER_ID);

      EXCEPTION

        WHEN OTHERS THEN

          ROLLBACK;

          V_ERR_CODE := 1;

          V_ERR_MSG  := SUBSTR(SQLERRM,1,125);

      END;

      END IF;

      UPDATE TFJ_ACC_NBR

         SET STATE       = DECODE(V_ERR_CODE, 0, 'C', 'E'),

             STATE_DATE  = SYSDATE,

             PROC_ORD_ID = TO_CHAR(V_CUST_ORDER_ID),

             ERR_NUM     = DECODE(V_ERR_CODE, 0, 0, 1),

             ERR_STR     = V_ERR_MSG

       WHERE SERIAL_NBR = I_SERIAL_NBR;



      IF V_ERR_CODE = 0 THEN

        INSERT INTO TFJ_ACC_NBR_BAK

          (SERIAL_NBR,

           SERV_TYPE_ID,

           ACC_NBR,

           ACT_TYPE,

           STATE,

           STATE_DATE,

           PROC_ORD_ID,

           PROC_NUM,

           ERR_NUM,

           ERR_STR,

           APP_AREA_ID,

           AREA_ID,

           SERV_ID,

           ORDER_SERIAL_NBR,

           COURSE_NUM)

          SELECT SERIAL_NBR,

                 SERV_TYPE_ID,

                 ACC_NBR,

                 ACT_TYPE,

                 STATE,

                 STATE_DATE,

                 PROC_ORD_ID,

                 PROC_NUM,

                 ERR_NUM,

                 ERR_STR,

                 APP_AREA_ID,

                 AREA_ID,

                 SERV_ID,

                 ORDER_SERIAL_NBR,

                 COURSE_NUM

            FROM TFJ_ACC_NBR

           WHERE SERIAL_NBR = I_SERIAL_NBR;



        DELETE TFJ_ACC_NBR WHERE SERIAL_NBR = I_SERIAL_NBR;

      END IF;

    ELSE

      UPDATE TFJ_ACC_NBR SET PROC_NUM = 10, ERR_STR = V_ERR_MSG WHERE SERIAL_NBR = I_SERIAL_NBR;

    END IF;
    END IF;

    COMMIT;

  EXCEPTION

    WHEN OTHERS THEN

      NULL;

  END;



  PROCEDURE SP_TFJ_REQUEST(I_SERV_ID       IN NUMBER, --产品实例id

                           I_SERIAL_NBR    IN NUMBER, --TFJ_ACC_NBR表的主键

                           I_ACT_TYPE      IN VARCHAR2, --动作类型（T：双停；S：单停；K：开机）

                           O_CUST_ORDER_ID OUT NUMBER --产生的订单id

                           )

  /*

      功能: 关联停复机 被SP_TFJ_REDO调用

  */

   IS

    V_PROD_INST PROD_INST%ROWTYPE;
    V_PROD_INST_HIS PROD_INST%ROWTYPE;

  BEGIN

    IF NVL(I_ACT_TYPE, '-1') NOT IN ('S', 'T', 'K') THEN

      RAISE_APPLICATION_ERROR(-20001,

                              '传入的停机类型[' || I_ACT_TYPE ||

                              ']不合法. （T：双停；S：单停；K：开机） 产品实例id: ' ||

                              I_SERV_ID);

    END IF;



    BEGIN

      SELECT

          PROD_INST_ID,PRODUCT_ID,ACC_PROD_INST_ID,ADDRESS_ID,OWNER_CUST_ID,

          PAYMENT_MODE_CD,PRODUCT_PASSWORD,IMPORTANT_LEVEL,AREA_CODE,ACC_NBR,

          EXCH_ID,COMMON_REGION_ID,REMARK,PAY_CYCLE,BEGIN_RENT_TIME,

          STOP_RENT_TIME,FINISH_TIME,STOP_STATUS,STATUS_CD,CREATE_DATE,

          STATUS_DATE,UPDATE_DATE,PROC_SERIAL,USE_CUST_ID,EXT_PROD_INST_ID,

          ADDRESS_DESC,AREA_ID,UPDATE_STAFF,CREATE_STAFF,REC_UPDATE_DATE,

          ACCOUNT,VERSION,COMMUNITY_ID,EXT_ACC_PROD_INST_ID



        INTO

          V_PROD_INST.PROD_INST_ID,V_PROD_INST.PRODUCT_ID,V_PROD_INST.ACC_PROD_INST_ID,V_PROD_INST.ADDRESS_ID,V_PROD_INST.OWNER_CUST_ID,

          V_PROD_INST.PAYMENT_MODE_CD,V_PROD_INST.PRODUCT_PASSWORD,V_PROD_INST.IMPORTANT_LEVEL,V_PROD_INST.AREA_CODE,V_PROD_INST.ACC_NBR,

          V_PROD_INST.EXCH_ID,V_PROD_INST.COMMON_REGION_ID,V_PROD_INST.REMARK,V_PROD_INST.PAY_CYCLE,V_PROD_INST.BEGIN_RENT_TIME,

          V_PROD_INST.STOP_RENT_TIME,V_PROD_INST.FINISH_TIME,V_PROD_INST.STOP_STATUS,V_PROD_INST.STATUS_CD,V_PROD_INST.CREATE_DATE,

          V_PROD_INST.STATUS_DATE,V_PROD_INST.UPDATE_DATE,V_PROD_INST.PROC_SERIAL,V_PROD_INST.USE_CUST_ID,V_PROD_INST.EXT_PROD_INST_ID,

          V_PROD_INST.ADDRESS_DESC,V_PROD_INST.AREA_ID,V_PROD_INST.UPDATE_STAFF,V_PROD_INST.CREATE_STAFF,V_PROD_INST.REC_UPDATE_DATE,

          V_PROD_INST.ACCOUNT,V_PROD_INST.VERSION,V_PROD_INST.COMMUNITY_ID,V_PROD_INST.EXT_ACC_PROD_INST_ID

        FROM PROD_INST PI

       WHERE PI.PROD_INST_ID = I_SERV_ID;

    EXCEPTION

      WHEN OTHERS THEN

        RAISE_APPLICATION_ERROR(-20002,

                                '产品实例不存在. 产品实例id: ' || I_SERV_ID);

    END;

    V_PROD_INST_HIS := V_PROD_INST;

    PKG_TFJ.TFJ_ACC_NBR_PROCESS(V_PROD_INST, I_ACT_TYPE, O_CUST_ORDER_ID,V_PROD_INST_HIS);

  END;



  PROCEDURE TFJ_ACC_NBR_PROCESS(I_PROD_INST     IN OUT PROD_INST%ROWTYPE, --产品实例

                                I_ACT_TYPE      IN VARCHAR2, --停机类型（T：双停；S：单停；K：开机）

                                O_CUST_ORDER_ID OUT NUMBER, --产生的订单id

                                I_PROD_INST_OLD     IN OUT PROD_INST%ROWTYPE)

  /*

      功能: 批量语音类停复机工单的处理，由接口直接产生到2表中并修改实例表状态。

    */

   IS

    V_IS_OWE_STOP      BOOLEAN := FALSE; --欠费双停

    V_IS_CALL_OWE_STOP BOOLEAN := FALSE; --欠费单停

    V_IS_USER_STOP     BOOLEAN := FALSE;

    V_IS_PECC_STOP     BOOLEAN := FALSE;

    V_IS_REMOVE_STOP   BOOLEAN := FALSE;

    V_IS_GSTJ          BOOLEAN := FALSE;



    V_OWE_STOP_ATTR_ID      ATTR_SPEC.ATTR_ID%TYPE := 800000251; --欠费双停attr_id

    V_CALL_OWE_STOP_ATTR_ID ATTR_SPEC.ATTR_ID%TYPE := 800013054; --欠费单停attr_id



    V_ORDER_ITEM_PROC_ATTR_LIST TYPE_ORDER_ITEM_PROC_ATTR_LIST; --订单项处理属性

  BEGIN

    --TTP22871

    IF ( I_ACT_TYPE IN ('S','T')

         AND I_PROD_INST.STATUS_CD = '110000'

         AND I_PROD_INST.PRODUCT_ID <> 800000002 ) THEN

       RETURN;

    END IF ;



    V_ORDER_ITEM_PROC_ATTR_LIST := TYPE_ORDER_ITEM_PROC_ATTR_LIST();



    --判断挂失停机、欠费单停、欠费双停、违章停机、停机保号、拆机停属性；

    FOR REC IN (SELECT A.ATTR_ID

                  FROM PROD_INST_ATTR A

                 WHERE A.PROD_INST_ID = I_PROD_INST.PROD_INST_ID

                 AND A.STATUS_CD = '1000') LOOP

      CASE REC.ATTR_ID

      --欠费单停

        WHEN V_CALL_OWE_STOP_ATTR_ID THEN

          V_IS_CALL_OWE_STOP := TRUE;

          --欠费双停

        WHEN V_OWE_STOP_ATTR_ID THEN

          V_IS_OWE_STOP := TRUE;

          --800000250: 预拆机

        WHEN 800000250 THEN

          V_IS_REMOVE_STOP := TRUE;

          --800000252: 违章停机

        WHEN 800000252 THEN

          V_IS_PECC_STOP := TRUE;

          --800000253: 用户申请停机

        WHEN 800000253 THEN

          V_IS_USER_STOP := TRUE;

          --800000254: 挂失停机

        WHEN 800000254 THEN

          V_IS_GSTJ := TRUE;

        ELSE

          NULL;

      END CASE;

    END LOOP;



    /*  28    欠费单停            4060300001

    29    欠费单停复机        4070300001

    30    欠费双停            4060300002

    31    欠费双停复机        4070300002 */

    --单停处理

    IF I_ACT_TYPE = 'S' THEN

      --如果已经单停或双停时，直接反回成功。

      IF V_IS_CALL_OWE_STOP OR V_IS_OWE_STOP THEN

        RETURN;

      END IF;



      --直接插入一个欠费单停的属性, 800013054--欠费单停

      PKG_TFJ.PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST,

                                          'A',

                                          V_CALL_OWE_STOP_ATTR_ID,

                                          '1',

                                          PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                          V_ORDER_ITEM_PROC_ATTR_LIST);



      --处理产品实例(移到二表)

      PKG_TFJ.PROC_PROCESS_PROD_INST(I_PROD_INST, '120000', PKG_CONSTANTS.TFJ_CHANNEL_NBR); --120000: 停机

      --处理销售品实例(移到二表)

      --PKG_TFJ.PROC_PROCESS_PROD_OFFER_INST(I_PROD_INST, PKG_CONSTANTS.TFJ_CHANNEL_NBR);



      --正常状态，产生订单；

      IF (NOT V_IS_PECC_STOP) AND (NOT V_IS_USER_STOP) AND

         (NOT V_IS_REMOVE_STOP) AND (NOT V_IS_GSTJ) THEN

        PKG_TFJ.PROC_CREATE_ORDER(I_PROD_INST,

                                  28, --28    欠费单停

                                  V_ORDER_ITEM_PROC_ATTR_LIST,

                                  PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                  O_CUST_ORDER_ID,

                                  I_PROD_INST_OLD);

      END IF;



      --双停处理

    ELSIF I_ACT_TYPE = 'T' THEN

      --如果已经双停时，直接反回成功。

      IF V_IS_OWE_STOP THEN

        RETURN;

      END IF;



      --增加欠费双停属性

      PKG_TFJ.PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST,

                                          'A',

                                          V_OWE_STOP_ATTR_ID,

                                          '1',

                                          PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                          V_ORDER_ITEM_PROC_ATTR_LIST);

      --如果已经欠费单停的话,删除欠费单停属性,增加欠费双停属性

      IF V_IS_CALL_OWE_STOP THEN

        --删除欠费单停属性

        PKG_TFJ.PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST,

                                            'D',

                                            V_CALL_OWE_STOP_ATTR_ID,

                                            NULL,

                                            PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                            V_ORDER_ITEM_PROC_ATTR_LIST);

      END IF;

      --处理产品实例(移到二表)

      PKG_TFJ.PROC_PROCESS_PROD_INST(I_PROD_INST, '120000', PKG_CONSTANTS.TFJ_CHANNEL_NBR); --120000: 停机

      --处理销售品实例(移到二表)

      --PKG_TFJ.PROC_PROCESS_PROD_OFFER_INST(I_PROD_INST, PKG_CONSTANTS.TFJ_CHANNEL_NBR);



      --否则是正常状态，产生订单

      IF (NOT V_IS_PECC_STOP) AND (NOT V_IS_USER_STOP) AND

         (NOT V_IS_REMOVE_STOP) AND (NOT V_IS_GSTJ) THEN

        PKG_TFJ.PROC_CREATE_ORDER(I_PROD_INST,

                                  30, --30    欠费双停

                                  V_ORDER_ITEM_PROC_ATTR_LIST,

                                  PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                  O_CUST_ORDER_ID,

                                  I_PROD_INST_OLD);

      END IF;



      --开机处理

    ELSIF I_ACT_TYPE = 'K' THEN

      --如果没有欠费单停或双停时，直接反回成功。

      IF (NOT V_IS_CALL_OWE_STOP) AND (NOT V_IS_OWE_STOP) THEN

        RETURN;

      END IF;



      --删除欠费停机属性

      IF V_IS_OWE_STOP THEN

        PKG_TFJ.PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST,

                                            'D',

                                            V_OWE_STOP_ATTR_ID,

                                            NULL,

                                            PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                            V_ORDER_ITEM_PROC_ATTR_LIST);

      ELSIF V_IS_CALL_OWE_STOP THEN

        PKG_TFJ.PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST,

                                            'D',

                                            V_CALL_OWE_STOP_ATTR_ID,

                                            NULL,

                                            PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                            V_ORDER_ITEM_PROC_ATTR_LIST);

      END IF;

      --处理产品实例(移到二表)

      IF (NOT V_IS_PECC_STOP) AND (NOT V_IS_USER_STOP) AND

         (NOT V_IS_REMOVE_STOP) AND (NOT V_IS_GSTJ) THEN

         --如果只有双停或单停属性, 才将产品实例状态改为 '100000', 否则不改变产品实例状态

         PKG_TFJ.PROC_PROCESS_PROD_INST(I_PROD_INST, '100000', PKG_CONSTANTS.TFJ_CHANNEL_NBR); --100000: 在用

      ELSE

         --不改变产品实例状态

         PKG_TFJ.PROC_PROCESS_PROD_INST(I_PROD_INST, NULL, PKG_CONSTANTS.TFJ_CHANNEL_NBR);

      END IF;

      --处理销售品实例(移到二表)

      --PKG_TFJ.PROC_PROCESS_PROD_OFFER_INST(I_PROD_INST, PKG_CONSTANTS.TFJ_CHANNEL_NBR);



      --只有欠费停机状态

      IF (NOT V_IS_PECC_STOP) AND (NOT V_IS_USER_STOP) AND

         (NOT V_IS_REMOVE_STOP) AND (NOT V_IS_GSTJ) THEN

        --产生订单

        IF V_IS_OWE_STOP THEN

          PKG_TFJ.PROC_CREATE_ORDER(I_PROD_INST,

                                    31, --31    欠费双停复机

                                    V_ORDER_ITEM_PROC_ATTR_LIST,

                                    PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                    O_CUST_ORDER_ID,

                                    I_PROD_INST_OLD);

        ELSIF V_IS_CALL_OWE_STOP THEN

          PKG_TFJ.PROC_CREATE_ORDER(I_PROD_INST,

                                    29, --29    欠费单停复机

                                    V_ORDER_ITEM_PROC_ATTR_LIST,

                                    PKG_CONSTANTS.TFJ_CHANNEL_NBR,

                                    O_CUST_ORDER_ID,

                                    I_PROD_INST_OLD);

        END IF;

      END IF;

    END IF;

  END;



  PROCEDURE PROC_TRANSFORM_WORK_ORDER(I_ORDER_SERIAL_NBR IN NUMBER, --WORK_ORDER表的主键

                                      I_PROD_SPEC_ID     IN NUMBER, --

                                      I_SERV_ID          IN NUMBER, --prod_inst_id

                                      I_ACC_NBR          IN VARCHAR2, --号码

                                      I_ACTION           IN NUMBER, --

                                      I_LATN_ID          IN NUMBER, --如591

                                      I_STOP_FLAG        IN NUMBER --停机保号状态, 1为停机保号

                                      )

  /*

    功能: 把Work_order和work_order_cdma表的数据分发给电子工单系统、PF系统、激活系统等

   */

   IS

    TMP_SEND_TARGET TFJ_PROD_SPEC_SEND_CONFIG.SEND_TARGET%TYPE;

    TMP_APP_AREA_ID TFJ_ACC_NBR.APP_AREA_ID%TYPE;

    TMP_AREA_CODE   PROD_INST.AREA_CODE%TYPE;

    ERR_STR         VARCHAR2(4000);

    TMP_COURSE_NUM  TFJ_ACC_NBR.COURSE_NUM%TYPE;

    ERR_NUM         NUMBER(10);

    IMS_FLAG        NUMBER(10);

    NGN_FLAG        NUMBER(10);

    V_ZYLX          ATTR_SPEC.ATTR_ID%TYPE; --资源类型

    V_ZYLX_NAME     ATTR_SPEC.ATTR_NAME%TYPE;

  BEGIN

    ERR_NUM := 0;

    --获取数据发送目标

    BEGIN

      SELECT SEND_TARGET

        INTO TMP_SEND_TARGET

        FROM TFJ_PROD_SPEC_SEND_CONFIG

       WHERE STATE = 'A'

         AND AREA_ID = I_LATN_ID

         AND PROD_SPEC_ID = I_PROD_SPEC_ID;

    EXCEPTION

      WHEN OTHERS THEN

        TMP_SEND_TARGET := 'PF';

    END;



    --不是停机保号状态

    IF I_STOP_FLAG != 1 THEN

      --数据发送给电子工单系统

      IF TMP_SEND_TARGET = 'GD' THEN

        BEGIN

          SELECT COUNT(*)

            INTO IMS_FLAG

            FROM PROD_INST_ATTR A

           WHERE A.PROD_INST_ID = I_SERV_ID

             AND A.ATTR_ID = 800000351

             AND attr_value||''='IMS'

             AND A.STATUS_CD = '1000'

             AND ROWNUM = 1;



          IF IMS_FLAG = 1 THEN

            ERR_STR := 'TFJ_WORK_ORDER_JH';

            INSERT INTO TFJ_WORK_ORDER_JH

              (ORDER_SERIAL_NBR,

               PROD_SPEC_ID,

               SERV_ID,

               ACC_NBR,

               ACTION,

               ORDER_STATE,

               SOURCE,

               CREATE_DATE,

               STATE,

               STATE_DATE,

               LATN_ID,

               BUREAU_ID,

               IF_QUOTA,

               PRIORITY,

               STAFF_ID,

               COMMENTS,

               AREA_ID,

               MDSE_SPEC_ID,

               SWD_ID,

               INSERT_DATE,

               EXCH_ID,

               HLR_NBR,

               IMS_CODE)

              SELECT A.ORDER_SERIAL_NBR,

                     (SELECT P.EXT_PROD_ID

                        FROM PRODUCT P

                       WHERE P.PRODUCT_ID = A.PROD_SPEC_ID),

                     A.SERV_ID,

                     DECODE(B.ACCOUNT_FLAG,

                            'N',

                            A.ACC_NBR,

                            'Y',

                            A.SERVICE_CODE),

                     A.ACTION,

                     A.ORDER_STATE,

                     SOURCE,

                     A.CREATE_DATE,

                     '5SN',

                     A.STATE_DATE,

                     A.LATN_ID,

                     A.BUREAU_ID,

                     A.IF_QUOTA,

                     A.PRIORITY,

                     A.STAFF_ID,

                     A.COMMENTS,

                     A.AREA_ID,

                     A.MDSE_SPEC_ID,

                     A.SWD_ID,

                     SYSDATE,

                     A.EXCH_ID,

                     A.HLR_NBR,

                     'IMS'

                FROM WORK_ORDER A, TFJ_PROD_SPEC_CONFIG B

               WHERE A.ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR

                 AND A.PROD_SPEC_ID = B.PROD_SPEC_ID;

          ELSE

            ERR_STR := 'TFJ_WORK_ORDER_GD';

            SELECT COUNT(*)

              INTO NGN_FLAG

              FROM PROD_INST_ATTR A

             WHERE A.PROD_INST_ID = I_SERV_ID

               AND A.ATTR_ID = 800000351

               AND attr_value||''='NGN'

               AND A.STATUS_CD = '1000'

               AND ROWNUM = 1;



            INSERT INTO TFJ_WORK_ORDER_GD

              (ORDER_SERIAL_NBR,

               PROD_SPEC_ID,

               SERV_ID,

               ACC_NBR,

               ACTION,

               ORDER_STATE,

               SOURCE,

               CREATE_DATE,

               STATE,

               STATE_DATE,

               LATN_ID,

               BUREAU_ID,

               IF_QUOTA,

               PRIORITY,

               STAFF_ID,

               COMMENTS,

               AREA_ID,

               MDSE_SPEC_ID,

               SWD_ID,

               INSERT_DATE,

               EXCH_ID,

               HLR_NBR,

               IMS_CODE)

              SELECT A.ORDER_SERIAL_NBR,

                     (SELECT P.EXT_PROD_ID

                        FROM PRODUCT P

                       WHERE P.PRODUCT_ID = A.PROD_SPEC_ID),

                     A.SERV_ID,

                     DECODE(B.ACCOUNT_FLAG,

                            'N',

                            A.ACC_NBR,

                            'Y',

                            A.SERVICE_CODE),

                     A.ACTION,

                     A.ORDER_STATE,

                     SOURCE,

                     A.CREATE_DATE,

                     '5SN',

                     A.STATE_DATE,

                     A.LATN_ID,

                     A.BUREAU_ID,

                     A.IF_QUOTA,

                     A.PRIORITY,

                     A.STAFF_ID,

                     A.COMMENTS,

                     A.AREA_ID,

                     A.MDSE_SPEC_ID,

                     A.SWD_ID,

                     SYSDATE,

                     A.EXCH_ID,

                     A.HLR_NBR,

                     DECODE(NGN_FLAG, '1', 'NGN', '')

                FROM WORK_ORDER A, TFJ_PROD_SPEC_CONFIG B

               WHERE A.ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR

                 AND A.PROD_SPEC_ID = B.PROD_SPEC_ID;

          END IF;



        EXCEPTION

          WHEN OTHERS THEN

            ERR_NUM := -1;

            ERR_STR := '插入' || ERR_STR || '表失败' || SQLERRM;

            GOTO ERR_PROCESS;

        END;

      ELSIF TMP_SEND_TARGET = 'ISAP' THEN

        --在1.0会插TFJ_WORK_ORDER_CDMA表,

        --2.0去掉了, 因为pf自己会去计费取

        NULL;

        --数据发送给PF系统

      ELSE

        BEGIN

          SELECT A.ATTR_VALUE_ID,

                 (SELECT V.ATTR_VALUE_NAME

                    FROM ATTR_VALUE V

                   WHERE V.ATTR_VALUE_ID = A.ATTR_VALUE_ID)

            INTO V_ZYLX, V_ZYLX_NAME

            FROM PROD_INST_ATTR A

           WHERE A.PROD_INST_ID = I_SERV_ID

             AND A.ATTR_ID = 800000324 --800000324: 资源类型

             AND A.STATUS_CD = '1000'

             AND ROWNUM = 1;

        EXCEPTION

          WHEN OTHERS THEN

            V_ZYLX      := '';

            V_ZYLX_NAME := '';

        END;

        BEGIN

          INSERT INTO TFJ_WORK_ORDER

            (ORDER_SERIAL_NBR,

             PROD_SPEC_ID,

             SERV_ID,

             ACC_NBR,

             ACTION,

             ORDER_STATE,

             SOURCE,

             CREATE_DATE,

             STATE,

             STATE_DATE,

             LATN_ID,

             BUREAU_ID,

             IF_QUOTA,

             PRIORITY,

             STAFF_ID,

             COMMENTS,

             AREA_ID,

             MDSE_SPEC_ID,

             SWD_ID,

             INSERT_DATE,

             EXCH_ID,

             HLR_NBR,

             ZYLX,

             ZYLX_NAME)

            SELECT A.ORDER_SERIAL_NBR,

                   (SELECT P.EXT_PROD_ID

                      FROM PRODUCT P

                     WHERE P.PRODUCT_ID = A.PROD_SPEC_ID),

                   A.SERV_ID,

                   DECODE(B.ACCOUNT_FLAG,

                          'N',

                          A.ACC_NBR,

                          'Y',

                          A.SERVICE_CODE),

                   A.ACTION,

                   A.ORDER_STATE,

                   SOURCE,

                   A.CREATE_DATE,

                   '5SN',

                   A.STATE_DATE,

                   A.LATN_ID,

                   A.BUREAU_ID,

                   A.IF_QUOTA,

                   A.PRIORITY,

                   A.STAFF_ID,

                   A.COMMENTS,

                   A.AREA_ID,

                   A.MDSE_SPEC_ID,

                   A.SWD_ID,

                   SYSDATE,

                   A.EXCH_ID,

                   A.HLR_NBR,

                   V_ZYLX,

                   V_ZYLX_NAME

              FROM WORK_ORDER A, TFJ_PROD_SPEC_CONFIG B

             WHERE A.ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR

               AND A.PROD_SPEC_ID = B.PROD_SPEC_ID;

        EXCEPTION

          WHEN OTHERS THEN

            ERR_NUM := -1;

            ERR_STR := '插入Tfj_WOrk_order表失败' || SQLERRM;

            GOTO ERR_PROCESS;

        END;

      END IF;

    END IF;



    IF TMP_SEND_TARGET = 'ISAP' THEN

      --对套餐停、特音催缴和取消特音催缴、强制停机的处理

      IF I_ACTION IN ('8', '106', '109', '80') THEN

        BEGIN

          INSERT INTO WORK_ORDER_CDMA_HIS

            (ORDER_SERIAL_NBR,

             PARENT_ORDER_SERIAL_NBR,

             PROD_SPEC_ID,

             SERV_ID,

             ACC_NBR,

             SERVICE_CODE,

             ACTION,

             ORDER_STATE,

             SOURCE,

             CREATE_DATE,

             STATE,

             STATE_DATE,

             LATN_ID,

             BUREAU_ID,

             IF_QUOTA,

             PRIORITY,

             STAFF_ID,

             COMMENTS,

             AREA_ID,

             SWD_ID,

             MDSE_SPEC_ID,

             FLAG,

             EXCH_ID,

             HLR_NBR,

             STOP_FLAG,

             OWE_QUOTA)

            SELECT ORDER_SERIAL_NBR,

                   PARENT_ORDER_SERIAL_NBR,

                   PROD_SPEC_ID,

                   SERV_ID,

                   ACC_NBR,

                   SERVICE_CODE,

                   ACTION,

                   ORDER_STATE,

                   SOURCE,

                   CREATE_DATE,

                   '5SC',

                   SYSDATE,

                   LATN_ID,

                   BUREAU_ID,

                   IF_QUOTA,

                   PRIORITY,

                   STAFF_ID,

                   COMMENTS,

                   AREA_ID,

                   SWD_ID,

                   MDSE_SPEC_ID,

                   FLAG,

                   EXCH_ID,

                   HLR_NBR,

                   STOP_FLAG,

                   OWE_QUOTA

              FROM WORK_ORDER_CDMA

             WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

          DELETE FROM WORK_ORDER_CDMA

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

        EXCEPTION

          WHEN OTHERS THEN

            ERR_NUM := -1;

            ERR_STR := '插入work_order_cdma_his表失败' || SQLERRM;

            GOTO ERR_PROCESS_CDMA;

        END;

        --其它动作往tfj_Acc_nbr表插记录

      ELSE

        --获取受理区域和长途区号

        BEGIN

          SELECT PI.AREA_ID, PI.AREA_CODE

            INTO TMP_APP_AREA_ID, TMP_AREA_CODE

            FROM PROD_INST PI

           WHERE PI.PROD_INST_ID = I_SERV_ID;

        EXCEPTION

          WHEN OTHERS THEN

            TMP_APP_AREA_ID := NULL;

            TMP_AREA_CODE   := NULL;

        END;



        BEGIN

          SELECT MOD(SUBSTR(I_ACC_NBR, -2), 20)

            INTO TMP_COURSE_NUM

            FROM DUAL;

        EXCEPTION

          WHEN OTHERS THEN

            TMP_COURSE_NUM := 0;

        END;

        --往tfj_acc_nbr表插记录

        BEGIN

          INSERT INTO TFJ_ACC_NBR

            (SERIAL_NBR,

             SERV_TYPE_ID,

             SERV_ID,

             ACC_NBR,

             ACT_TYPE,

             STATE,

             STATE_DATE,

             PROC_ORD_ID,

             PROC_NUM,

             ERR_NUM,

             APP_AREA_ID,

             AREA_ID,

             ORDER_SERIAL_NBR,

             COURSE_NUM)

            SELECT SEQ_TFJ_ACC_NBR_ID.NEXTVAL,

                   PROD_SPEC_ID,

                   SERV_ID,

                   ACC_NBR,

                   DECODE(ACTION, 3, 'S', 6, 'K', 4, 'T'),

                   'A',

                   SYSDATE,

                   '',

                   0,

                   0,

                   TMP_APP_AREA_ID,

                   TMP_AREA_CODE,

                   ORDER_SERIAL_NBR,

                   TMP_COURSE_NUM

              FROM WORK_ORDER_CDMA

             WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

        EXCEPTION

          WHEN OTHERS THEN

            ERR_NUM := -1;

            ERR_STR := '插入TFJ_ACC_NBR表失败' || SQLERRM;

            GOTO ERR_PROCESS_CDMA;

        END;

        --对于停机保号状态的处理

        IF I_STOP_FLAG = 1 THEN

          UPDATE WORK_ORDER_CDMA

             SET STATE = '5SN', STATE_DATE = SYSDATE

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

          --更新work_order表状态

        ELSE

          UPDATE WORK_ORDER_CDMA

             SET STATE = '5SB', STATE_DATE = SYSDATE

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

        END IF;

      END IF;



    ELSE

      --对套餐停、特音催缴和取消特音催缴、强制停机的处理

      IF I_ACTION IN ('8', '106', '109', '80') THEN

        BEGIN

          INSERT INTO WORK_ORDER_HIS

            (ORDER_SERIAL_NBR,

             PARENT_ORDER_SERIAL_NBR,

             PROD_SPEC_ID,

             SERV_ID,

             ACC_NBR,

             SERVICE_CODE,

             ACTION,

             ORDER_STATE,

             SOURCE,

             CREATE_DATE,

             STATE,

             STATE_DATE,

             LATN_ID,

             BUREAU_ID,

             IF_QUOTA,

             PRIORITY,

             STAFF_ID,

             COMMENTS,

             AREA_ID,

             SWD_ID,

             MDSE_SPEC_ID,

             FLAG,

             EXCH_ID,

             HLR_NBR,

             STOP_FLAG)

            SELECT ORDER_SERIAL_NBR,

                   PARENT_ORDER_SERIAL_NBR,

                   PROD_SPEC_ID,

                   SERV_ID,

                   ACC_NBR,

                   SERVICE_CODE,

                   ACTION,

                   ORDER_STATE,

                   SOURCE,

                   CREATE_DATE,

                   '5SC',

                   SYSDATE,

                   LATN_ID,

                   BUREAU_ID,

                   IF_QUOTA,

                   PRIORITY,

                   STAFF_ID,

                   COMMENTS,

                   AREA_ID,

                   SWD_ID,

                   MDSE_SPEC_ID,

                   FLAG,

                   EXCH_ID,

                   HLR_NBR,

                   STOP_FLAG

              FROM WORK_ORDER

             WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

          DELETE FROM WORK_ORDER

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

        EXCEPTION

          WHEN OTHERS THEN

            ERR_NUM := -1;

            ERR_STR := '插入work_order_his表失败' || SQLERRM;

            GOTO ERR_PROCESS;

        END;

        --其它动作往tfj_Acc_nbr表插记录

      ELSE

        --获取受理区域和长途区号

        BEGIN

          SELECT PI.AREA_ID, PI.AREA_CODE

            INTO TMP_APP_AREA_ID, TMP_AREA_CODE

            FROM PROD_INST PI

           WHERE PI.PROD_INST_ID = I_SERV_ID;

        EXCEPTION

          WHEN OTHERS THEN

            TMP_APP_AREA_ID := NULL;

            TMP_AREA_CODE   := NULL;

        END;



        BEGIN

          SELECT MOD(SUBSTR(I_ACC_NBR, -2), 20)

            INTO TMP_COURSE_NUM

            FROM DUAL;

        EXCEPTION

          WHEN OTHERS THEN

            TMP_COURSE_NUM := 0;

        END;

        --往tfj_acc_nbr表插记录

        BEGIN

          INSERT INTO TFJ_ACC_NBR

            (SERIAL_NBR,

             SERV_TYPE_ID,

             SERV_ID,

             ACC_NBR,

             ACT_TYPE,

             STATE,

             STATE_DATE,

             PROC_ORD_ID,

             PROC_NUM,

             ERR_NUM,

             APP_AREA_ID,

             AREA_ID,

             ORDER_SERIAL_NBR,

             COURSE_NUM)

            SELECT SEQ_TFJ_ACC_NBR_ID.NEXTVAL,

                   PROD_SPEC_ID,

                   SERV_ID,

                   ACC_NBR,

                   DECODE(ACTION, 3, 'S', 6, 'K', 4, 'T'),

                   'A',

                   SYSDATE,

                   '',

                   0,

                   0,

                   TMP_APP_AREA_ID,

                   TMP_AREA_CODE,

                   ORDER_SERIAL_NBR,

                   TMP_COURSE_NUM

              FROM WORK_ORDER

             WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

        EXCEPTION

          WHEN OTHERS THEN

            ERR_NUM := -1;

            ERR_STR := '插入TFJ_ACC_NBR表失败' || SQLERRM;

            GOTO ERR_PROCESS;

        END;

        --对于停机保号状态的处理

        IF I_STOP_FLAG = 1 THEN

          UPDATE WORK_ORDER

             SET STATE = '5SN', STATE_DATE = SYSDATE

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

          --更新work_order表状态

        ELSE

          UPDATE WORK_ORDER

             SET STATE = '5SB', STATE_DATE = SYSDATE

           WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

        END IF;

      END IF;

    END IF;



    --例外处理

    <<ERR_PROCESS>>

    IF ERR_NUM = -1 THEN

      ROLLBACK;--回滚

      UPDATE WORK_ORDER

         SET STATE = '5SE', STATE_DATE = SYSDATE, COMMENTS = SUBSTR(ERR_STR,1,500)

       WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

      RETURN;

    END IF;



    <<ERR_PROCESS_CDMA>>

    IF ERR_NUM = -1 THEN

      ROLLBACK;--回滚

      UPDATE WORK_ORDER_CDMA

         SET STATE = '5SE', STATE_DATE = SYSDATE, COMMENTS = SUBSTR(ERR_STR,1,500)

       WHERE ORDER_SERIAL_NBR = I_ORDER_SERIAL_NBR;

      RETURN;

    END IF;



    --COMMIT;

  END;



  PROCEDURE PROC_CREATE_ORDER(I_PROD_INST                 IN PROD_INST%ROWTYPE, --产品实例

                              I_SERVICE_OFFER_ID          IN SERVICE_OFFER.SERVICE_OFFER_ID%TYPE, --SERVICE_OFFER_ID

                              I_ORDER_ITEM_PROC_ATTR_LIST IN TYPE_ORDER_ITEM_PROC_ATTR_LIST, --变更的属性

                              I_CHANNEL_NBR               IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE, --渠道

                              O_CUST_ORDER_ID             OUT NUMBER, --产生的订单id

                              I_PROD_INST_OLD     IN OUT PROD_INST%ROWTYPE)

  /*

    功能: 生成订单

    Author  : g.caijx

    Created : 2012-7-7

    */

   IS

    V_CUST_SO_NUMBER      CUSTOMER_ORDER.CUST_SO_NUMBER%TYPE; --订单流水号

    V_CUST_ORDER_ID       CUSTOMER_ORDER.CUST_ORDER_ID%TYPE; --订单id

    V_PROD_ORDER_ITEM_ID  ORDER_ITEM.ORDER_ITEM_ID%TYPE; --产品订单项id

    V_OFFER_ORDER_ITEM_ID ORDER_ITEM.ORDER_ITEM_ID%TYPE; --销售品订单项id

    V_PROD_OFFER_INST     PROD_OFFER_INST%ROWTYPE; --销售品实例

    V_IS_4G_FLAG         NUMBER(9); --添加4G标识

    --crm00068707  DTS_CRM数据双写_接口过程修改
    V_AREA_NBR              AREA_CODE.AREA_NBR%TYPE;

    V_KEY_ID                NUMBER(12);

  BEGIN

    --crm00068707  DTS_CRM数据双写_接口过程修改
    SELECT A.AREA_NBR
      INTO V_AREA_NBR
      FROM AREA_CODE A, COMMON_REGION B
     WHERE A.REGION_ID = B.COMMON_REGION_ID
       AND B.COMMON_REGION_ID = I_PROD_INST.AREA_ID ;

    --生成新的订单流水号

    SELECT 'FJ' || TO_CHAR(SYSDATE, 'YYYYMMDD') ||

           LPAD(TO_CHAR(SEQ_CUSTOMER_ORDER_SO_NUMBER.NEXTVAL), 8, '0')

      INTO V_CUST_SO_NUMBER

      FROM DUAL;

    --订单id

    SELECT SEQ_CUSTOMER_ORDER_ID.NEXTVAL INTO V_CUST_ORDER_ID FROM DUAL;

    --插订单

    SELECT SEQ_CUSTOMER_ORDER_HIS_ID.NEXTVAL  INTO V_KEY_ID FROM DUAL;

    INSERT INTO CUSTOMER_ORDER_HIS

      (CUST_ORDER_ID,

       CUSTOMER_INTERACTION_EVENT_ID,

       CHANNEL_ID,

       CUST_ID,

       STAFF_ID,

       CUST_SO_NUMBER,

       CUST_ORDER_TYPE,

       STATUS_CD,

       STATUS_DATE,

       PRE_HANDLE_FLAG,

       HANDLE_PEOPLE_NAME,

       PRIORITY,

       REASON,

       CREATE_DATE,

       UPDATE_DATE,

       ACCEPT_TIME,

       EXT_CUST_ORDER_ID,

       LAN_ID,

       REMARK,

       BOOK_TIME,

       AREA_ID,

       REGION_CD,

       UPDATE_STAFF,

       CREATE_STAFF,

       ORG_ID,

       HIS_ID,

       ORDER_FROM,

       DB_INST_ID,

       PROC_PRIORITY)

      SELECT V_CUST_ORDER_ID, --CUST_ORDER_ID,

             NULL, --CUSTOMER_INTERACTION_EVENT_ID,

             (SELECT C.CHANNEL_ID

                FROM CHANNEL C

               WHERE C.CHANNEL_NBR = I_CHANNEL_NBR

                 AND ROWNUM = 1), --CHANNEL_ID,

             I_PROD_INST.OWNER_CUST_ID, --CUST_ID,

             PKG_CONSTANTS.JK_STAFF_ID, --STAFF_ID,

             V_CUST_SO_NUMBER, --CUST_SO_NUMBER,

             '101', --CUST_ORDER_TYPE,???

             '300000', --STATUS_CD,(300000: 竣工)

             SYSDATE, --STATUS_DATE,

             NULL, --PRE_HANDLE_FLAG,

             NULL, --HANDLE_PEOPLE_NAME,

             '100', --PRIORITY,

             NULL, --REASON,

             SYSDATE, --CREATE_DATE,

             SYSDATE, --UPDATE_DATE,

             SYSDATE, --ACCEPT_TIME,

             NULL, --EXT_CUST_ORDER_ID,

             NULL, --LAN_ID,

             NULL, --REMARK,

             NULL, --BOOK_TIME,

             I_PROD_INST.AREA_ID, --AREA_ID,

             I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

             PKG_CONSTANTS.JK_ORG_ID, --ORG_ID,

             V_KEY_ID,--SEQ_CUSTOMER_ORDER_HIS_ID.NEXTVAL, --HIS_ID,

             I_CHANNEL_NBR, --ORDER_FROM,

             NULL, --DB_INST_ID,

             NULL --PROC_PRIORITY,

        FROM DUAL;

    --crm00068707  DTS_CRM数据双写_接口过程修改
    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'CUSTOMER_ORDER_HIS',
                                            I_COLUMN_NAME => 'HIS_ID',
                                            I_KEY_ID      => V_KEY_ID,
                                            I_TOPIC       => '数据双写',
                                            I_TYPE        => '1004',
                                            I_REASON      => '数据双写 PKG_TFJ',
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);

    --插产品订单项

    SELECT SEQ_ORDER_ITEM_ID.NEXTVAL INTO V_PROD_ORDER_ITEM_ID FROM DUAL;

    SELECT SEQ_ORDER_ITEM_HIS_ID.NEXTVAL INTO V_KEY_ID FROM DUAL;

    INSERT INTO ORDER_ITEM_HIS

      (ORDER_ITEM_ID,

       CUST_ORDER_ID,

       ORDER_ITEM_CD,

       CUST_WORKSHEET_ID,

       STATUS_CD,

       STATUS_DATE,

       STATUS_CHANGE_REASON,

       PRIORITY,

       PRE_HANDLE_FLAG,

       HANDLE_TIME,

       ARCHIVE_DATE,

       FINISH_TIME,

       ORDER_ITEM_OBJ_ID,

       INSTALL_TIME_SEGMENT_ID,

       BEGIN_TIME_SEGMENT_ID,

       SERVICE_OFFER_ID,

       CREATE_DATE,

       UPDATE_DATE,

       REASON,

       EXT_ORDER_ITEM_ID,

       LAN_ID,

       CLASS_ID,

       AREA_ID,

       REGION_CD,

       UPDATE_STAFF,

       CREATE_STAFF,

       HIS_ID,

       ORDER_CLASS_ID,

       DB_INST_ID,

       PF_PROCESS_FLAG,

       PROC_PRIORITY)

      SELECT V_PROD_ORDER_ITEM_ID, --ORDER_ITEM_ID,

             V_CUST_ORDER_ID, --CUST_ORDER_ID,

             '1300', --ORDER_ITEM_CD,(1300: 产品订单项)

             NULL, --CUST_WORKSHEET_ID,

             '300000', --STATUS_CD,(300000: 竣工)

             SYSDATE, --STATUS_DATE,

             NULL, --STATUS_CHANGE_REASON,

             NULL, --PRIORITY,

             NULL, --PRE_HANDLE_FLAG,

             NULL, --HANDLE_TIME,

             SYSDATE, --ARCHIVE_DATE,

             SYSDATE, --FINISH_TIME,

             I_PROD_INST.PROD_INST_ID, --ORDER_ITEM_OBJ_ID,

             NULL, --INSTALL_TIME_SEGMENT_ID,

             NULL, --BEGIN_TIME_SEGMENT_ID,

             I_SERVICE_OFFER_ID, --SERVICE_OFFER_ID,

             SYSDATE, --CREATE_DATE,

             SYSDATE, --UPDATE_DATE,

             NULL, --REASON,

             NULL, --EXT_ORDER_ITEM_ID,

             NULL, --LAN_ID,

             4, --CLASS_ID,

             I_PROD_INST.AREA_ID, --AREA_ID,

             I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

             V_KEY_ID,--SEQ_ORDER_ITEM_HIS_ID.NEXTVAL, --HIS_ID,

             NULL, --ORDER_CLASS_ID,

             NULL, --DB_INST_ID,

             NULL, --PF_PROCESS_FLAG,

             NULL --PROC_PRIORITY,

        FROM DUAL;

    --crm00068707  DTS_CRM数据双写_接口过程修改
    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'ORDER_ITEM_HIS',
                                            I_COLUMN_NAME => 'HIS_ID',
                                            I_KEY_ID      => V_KEY_ID,
                                            I_TOPIC       => '数据双写',
                                            I_TYPE        => '1004',
                                            I_REASON      => '数据双写 PKG_TFJ',
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);

    --插销售品订单项

    BEGIN

      SELECT

          POI.PROD_OFFER_INST_ID,POI.PROD_OFFER_ID,POI.CUST_ID,POI.CHANNEL_ID,POI.CREATE_DATE,

          POI.STATUS_CD,POI.STATUS_DATE,POI.EFF_DATE,POI.EXP_DATE,POI.REGION,

          POI.UPDATE_DATE,POI.PROC_SERIAL,POI.EXT_PROD_OFFER_INST_ID,POI.AREA_ID,POI.REGION_CD,

          POI.UPDATE_STAFF,POI.CREATE_STAFF,POI.TRIAL_EFF_DATE,POI.TRIAL_EXP_DATE,POI.REC_UPDATE_DATE,

          POI.SERVICE_NBR,POI.VERSION,POI.END_AUTO,POI.REMARK,POI.WH_REMARK,

          POI.EXT_FLAG1,POI.EXT_FLAG2

        INTO

          V_PROD_OFFER_INST.PROD_OFFER_INST_ID,V_PROD_OFFER_INST.PROD_OFFER_ID,V_PROD_OFFER_INST.CUST_ID,V_PROD_OFFER_INST.CHANNEL_ID,V_PROD_OFFER_INST.CREATE_DATE,

          V_PROD_OFFER_INST.STATUS_CD,V_PROD_OFFER_INST.STATUS_DATE,V_PROD_OFFER_INST.EFF_DATE,V_PROD_OFFER_INST.EXP_DATE,V_PROD_OFFER_INST.REGION,

          V_PROD_OFFER_INST.UPDATE_DATE,V_PROD_OFFER_INST.PROC_SERIAL,V_PROD_OFFER_INST.EXT_PROD_OFFER_INST_ID,V_PROD_OFFER_INST.AREA_ID,V_PROD_OFFER_INST.REGION_CD,

          V_PROD_OFFER_INST.UPDATE_STAFF,V_PROD_OFFER_INST.CREATE_STAFF,V_PROD_OFFER_INST.TRIAL_EFF_DATE,V_PROD_OFFER_INST.TRIAL_EXP_DATE,V_PROD_OFFER_INST.REC_UPDATE_DATE,

          V_PROD_OFFER_INST.SERVICE_NBR,V_PROD_OFFER_INST.VERSION,V_PROD_OFFER_INST.END_AUTO,V_PROD_OFFER_INST.REMARK,V_PROD_OFFER_INST.WH_REMARK,

          V_PROD_OFFER_INST.EXT_FLAG1,V_PROD_OFFER_INST.EXT_FLAG2

        FROM OFFER_PROD_INST_REL R

        JOIN PROD_OFFER_INST POI

          ON POI.PROD_OFFER_INST_ID = R.PROD_OFFER_INST_ID

        JOIN PROD_OFFER PO

          ON PO.PROD_OFFER_ID = POI.PROD_OFFER_ID

       WHERE R.PROD_INST_ID = I_PROD_INST.PROD_INST_ID

         AND PO.OFFER_TYPE IN ('10', '11')

         AND POI.STATUS_CD = '1000'

         AND ROWNUM < 2;

    EXCEPTION

      WHEN OTHERS THEN

        RAISE_APPLICATION_ERROR(-20102, '找不到销售品实例');

    END;



    SELECT SEQ_ORDER_ITEM_ID.NEXTVAL INTO V_OFFER_ORDER_ITEM_ID FROM DUAL;

    SELECT SEQ_ORDER_ITEM_HIS_ID.NEXTVAL INTO V_KEY_ID FROM DUAL;

    INSERT INTO ORDER_ITEM_HIS

      (ORDER_ITEM_ID,

       CUST_ORDER_ID,

       ORDER_ITEM_CD,

       CUST_WORKSHEET_ID,

       STATUS_CD,

       STATUS_DATE,

       STATUS_CHANGE_REASON,

       PRIORITY,

       PRE_HANDLE_FLAG,

       HANDLE_TIME,

       ARCHIVE_DATE,

       FINISH_TIME,

       ORDER_ITEM_OBJ_ID,

       INSTALL_TIME_SEGMENT_ID,

       BEGIN_TIME_SEGMENT_ID,

       SERVICE_OFFER_ID,

       CREATE_DATE,

       UPDATE_DATE,

       REASON,

       EXT_ORDER_ITEM_ID,

       LAN_ID,

       CLASS_ID,

       AREA_ID,

       REGION_CD,

       UPDATE_STAFF,

       CREATE_STAFF,

       HIS_ID,

       ORDER_CLASS_ID,

       DB_INST_ID,

       PF_PROCESS_FLAG,

       PROC_PRIORITY)

      SELECT V_OFFER_ORDER_ITEM_ID, --ORDER_ITEM_ID,

             V_CUST_ORDER_ID, --CUST_ORDER_ID,

             '1200', --ORDER_ITEM_CD,(1200: 销售品订单项)

             NULL, --CUST_WORKSHEET_ID,

             '300000', --STATUS_CD,(300000: 竣工)

             SYSDATE, --STATUS_DATE,

             NULL, --STATUS_CHANGE_REASON,

             NULL, --PRIORITY,

             NULL, --PRE_HANDLE_FLAG,

             NULL, --HANDLE_TIME,

             SYSDATE, --ARCHIVE_DATE,

             SYSDATE, --FINISH_TIME,

             V_PROD_OFFER_INST.PROD_OFFER_INST_ID, --ORDER_ITEM_OBJ_ID,

             NULL, --INSTALL_TIME_SEGMENT_ID,

             NULL, --BEGIN_TIME_SEGMENT_ID,

             503, --SERVICE_OFFER_ID,--503: 变更

             SYSDATE, --CREATE_DATE,

             SYSDATE, --UPDATE_DATE,

             NULL, --REASON,

             NULL, --EXT_ORDER_ITEM_ID,

             NULL, --LAN_ID,

             6, --CLASS_ID,

             I_PROD_INST.AREA_ID, --AREA_ID,

             I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

             V_KEY_ID,--SEQ_ORDER_ITEM_HIS_ID.NEXTVAL, --HIS_ID,

             NULL, --ORDER_CLASS_ID,

             NULL, --DB_INST_ID,

             NULL, --PF_PROCESS_FLAG,

             NULL --PROC_PRIORITY,

        FROM DUAL;

    --crm00068707  DTS_CRM数据双写_接口过程修改
    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'ORDER_ITEM_HIS',
                                            I_COLUMN_NAME => 'HIS_ID',
                                            I_KEY_ID      => V_KEY_ID,
                                            I_TOPIC       => '数据双写',
                                            I_TYPE        => '1004',
                                            I_REASON      => '数据双写 PKG_TFJ',
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);


    SELECT SEQ_ORDER_ITEM_ACT_RELA_HIS_ID.NEXTVAL INTO V_KEY_ID FROM DUAL;

    INSERT INTO ORDER_ITEM_ACT_RELA_HIS

      (HIS_ID,

       ORDER_ITEM_ID,

       SERVICE_OFFER_ID,

       ORDER_ITEM_ACT_RELA_ID,

       TARGET,

       STATUS_CD,

       STATUS_DATE,

       CREATE_DATE,

       UPDATE_DATE,

       AREA_ID,

       REGION_CD,

       UPDATE_STAFF,

       CREATE_STAFF,

       DB_INST_ID)

      SELECT V_KEY_ID,--SEQ_ORDER_ITEM_ACT_RELA_HIS_ID.NEXTVAL, --HIS_ID,

             V_PROD_ORDER_ITEM_ID, --ORDER_ITEM_ID,

             I_SERVICE_OFFER_ID, --SERVICE_OFFER_ID,

             SEQ_ORDER_ITEM_ACT_RELA_ID.NEXTVAL, --ORDER_ITEM_ACT_RELA_ID,

             'A', --TARGET,

             '1000', --STATUS_CD,

             SYSDATE, --STATUS_DATE,

             SYSDATE, --CREATE_DATE,

             SYSDATE, --UPDATE_DATE,

             I_PROD_INST.AREA_ID, --AREA_ID,

             I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

             NULL --DB_INST_ID,

        FROM DUAL;

    --crm00068707  DTS_CRM数据双写_接口过程修改
   /* PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'ORDER_ITEM_ACT_RELA_HIS',
                                            I_COLUMN_NAME => 'HIS_ID',
                                            I_KEY_ID      => V_KEY_ID,
                                            I_TOPIC       => '数据双写',
                                            I_TYPE        => '1004',
                                            I_REASON      => '数据双写 PKG_TFJ',
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR); */

      --crm00074562   DTS_CRM数据双写_接口过程修改
    ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_ACT_RELA_HIS','HIS_ID',V_KEY_ID,
      '数据双写 PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',V_CUST_ORDER_ID);

    SELECT SEQ_ORDER_ITEM_ACT_RELA_HIS_ID.NEXTVAL INTO V_KEY_ID FROM DUAL;

    INSERT INTO ORDER_ITEM_ACT_RELA_HIS

      (HIS_ID,

       ORDER_ITEM_ID,

       SERVICE_OFFER_ID,

       ORDER_ITEM_ACT_RELA_ID,

       TARGET,

       STATUS_CD,

       STATUS_DATE,

       CREATE_DATE,

       UPDATE_DATE,

       AREA_ID,

       REGION_CD,

       UPDATE_STAFF,

       CREATE_STAFF,

       DB_INST_ID)

      SELECT V_KEY_ID,--SEQ_ORDER_ITEM_ACT_RELA_HIS_ID.NEXTVAL, --HIS_ID,

             V_OFFER_ORDER_ITEM_ID, --ORDER_ITEM_ID,

             503, --SERVICE_OFFER_ID,--503: 变更

             SEQ_ORDER_ITEM_ACT_RELA_ID.NEXTVAL, --ORDER_ITEM_ACT_RELA_ID,

             'A', --TARGET,

             '1000', --STATUS_CD,

             SYSDATE, --STATUS_DATE,

             SYSDATE, --CREATE_DATE,

             SYSDATE, --UPDATE_DATE,

             I_PROD_INST.AREA_ID, --AREA_ID,

             I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

             NULL --DB_INST_ID,

        FROM DUAL;

    --crm00068707  DTS_CRM数据双写_接口过程修改
    /*PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'ORDER_ITEM_ACT_RELA_HIS',
                                            I_COLUMN_NAME => 'HIS_ID',
                                            I_KEY_ID      => V_KEY_ID,
                                            I_TOPIC       => '数据双写',
                                            I_TYPE        => '1004',
                                            I_REASON      => '数据双写 PKG_TFJ',
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);         */
    --crm00074562   DTS_CRM数据双写_接口过程修改
    ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_ACT_RELA_HIS','HIS_ID',V_KEY_ID,
      '数据双写 PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',V_CUST_ORDER_ID);


    FOR I IN 1 .. I_ORDER_ITEM_PROC_ATTR_LIST.COUNT LOOP

      SELECT SEQ_OR_ITEM_PROC_ATTR_HIS_ID.NEXTVAL INTO V_KEY_ID FROM DUAL;

      INSERT INTO ORDER_ITEM_PROC_ATTR_HIS

        (ORDER_ITEM_PROC_ATTR_ID,

         ORDER_ITEM_ID,

         CLASS_ID,

         OBJ_INST_ID,

         OBJ_ATTR,

         OPERATE,

         NEW_VALUE,

         OLD_VALUE,

         STATUS,

         CREATE_DATE,

         STATUS_DATE,

         REMARK,

         OBJ_ATTR_ID,

         AREA_ID,

         REGION_CD,

         UPDATE_STAFF,

         CREATE_STAFF,

         HIS_ID,

         UPDATE_DATE,

         DB_INST_ID,

         VERSION)

        SELECT SEQ_ORDER_ITEM_PROC_ATTR_ID.NEXTVAL, --ORDER_ITEM_PROC_ATTR_ID,

               V_PROD_ORDER_ITEM_ID, --ORDER_ITEM_ID,

               4, --CLASS_ID,

               I_PROD_INST.PROD_INST_ID, --OBJ_INST_ID,

               S.ATTR_CD, --OBJ_ATTR,

               DECODE(I_ORDER_ITEM_PROC_ATTR_LIST(I).OPERATE,

                      'A',

                      '10',

                      'M',

                      '11',

                      'D',

                      '12'), --OPERATE,

               I_ORDER_ITEM_PROC_ATTR_LIST(I).NEW_VALUE, --NEW_VALUE,

               I_ORDER_ITEM_PROC_ATTR_LIST(I).OLD_VALUE, --OLD_VALUE,

               '1000', --STATUS,

               SYSDATE, --CREATE_DATE,

               SYSDATE, --STATUS_DATE,

               NULL, --REMARK,

               I_ORDER_ITEM_PROC_ATTR_LIST(I).ATTR_ID, --OBJ_ATTR_ID,

               I_PROD_INST.AREA_ID, --AREA_ID,

               I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

               PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

               PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

               V_KEY_ID,--SEQ_OR_ITEM_PROC_ATTR_HIS_ID.NEXTVAL, --HIS_ID,

               SYSDATE, --UPDATE_DATE,

               NULL, --DB_INST_ID,

               NULL --VERSION,

          FROM ATTR_SPEC S

         WHERE S.ATTR_ID = I_ORDER_ITEM_PROC_ATTR_LIST(I).ATTR_ID;

    --crm00068707  DTS_CRM数据双写_接口过程修改
    /*PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'ORDER_ITEM_PROC_ATTR_HIS',
                                            I_COLUMN_NAME => 'HIS_ID',
                                            I_KEY_ID      => V_KEY_ID,
                                            I_TOPIC       => '数据双写',
                                            I_TYPE        => '1004',
                                            I_REASON      => '数据双写 PKG_TFJ',
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);  */

    --crm00074562   DTS_CRM数据双写_接口过程修改
    ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR_HIS','HIS_ID',V_KEY_ID,
      '数据双写 PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',V_CUST_ORDER_ID);

    END LOOP;

 --begin------------------------------------
    --4G标识属性
    SELECT COUNT(*) INTO V_IS_4G_FLAG FROM PROD_INST_ATTR PIA
        WHERE PIA.PROD_INST_ID = I_PROD_INST.PROD_INST_ID AND PIA.ATTR_ID ='800069099';

     IF V_IS_4G_FLAG > 0 THEN

        SELECT  SEQ_OR_ITEM_PROC_ATTR_HIS_ID.NEXTVAL INTO V_KEY_ID FROM DUAL;

         INSERT INTO ORDER_ITEM_PROC_ATTR_HIS

        (ORDER_ITEM_PROC_ATTR_ID,

         ORDER_ITEM_ID,

         CLASS_ID,

         OBJ_INST_ID,

         OBJ_ATTR,

         OPERATE,

         NEW_VALUE,

         OLD_VALUE,

         STATUS,

         CREATE_DATE,

         STATUS_DATE,

         REMARK,

         OBJ_ATTR_ID,

         AREA_ID,

         REGION_CD,

         UPDATE_STAFF,

         CREATE_STAFF,

         HIS_ID,

         UPDATE_DATE,

         DB_INST_ID,

         VERSION)

        SELECT SEQ_ORDER_ITEM_PROC_ATTR_ID.NEXTVAL, --ORDER_ITEM_PROC_ATTR_ID,

               V_PROD_ORDER_ITEM_ID, --ORDER_ITEM_ID,

               4, --CLASS_ID,

               I_PROD_INST.PROD_INST_ID, --OBJ_INST_ID,

               '4GUser', --OBJ_ATTR,

               '10', --OPERATE,

               'main', --NEW_VALUE,

               NULL, --OLD_VALUE,

               '1000', --STATUS,

               SYSDATE, --CREATE_DATE,

               SYSDATE, --STATUS_DATE,

               NULL, --REMARK,

               '800069099', --OBJ_ATTR_ID,

               I_PROD_INST.AREA_ID, --AREA_ID,

               I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

               PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

               PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

               V_KEY_ID ,--SEQ_OR_ITEM_PROC_ATTR_HIS_ID.NEXTVAL, HIS_ID,

               SYSDATE, --UPDATE_DATE,

               NULL, --DB_INST_ID,

               NULL --VERSION,

          FROM ATTR_SPEC S

         WHERE S.ATTR_ID = '800069099';

    --crm00068707  DTS_CRM数据双写_接口过程修改
    /*PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'ORDER_ITEM_PROC_ATTR_HIS',
                                            I_COLUMN_NAME => 'HIS_ID',
                                            I_KEY_ID      => V_KEY_ID,
                                            I_TOPIC       => '数据双写',
                                            I_TYPE        => '1004',
                                            I_REASON      => '数据双写 PKG_TFJ',
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR); */

    --crm00074562   DTS_CRM数据双写_接口过程修改
    ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR_HIS','HIS_ID',V_KEY_ID,
      '数据双写 PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',V_CUST_ORDER_ID);

      END IF;
   --end------------------------------------

    --接口竣工操作

    PKG_FINISH.PROC_ORDER_FINISH_NOTIFY(V_CUST_ORDER_ID,

                                        I_ORDER_ITEM_PROC_ATTR_LIST,

                                        V_IS_4G_FLAG,

                                        I_PROD_INST_OLD); --添加4G送集团标识


    O_CUST_ORDER_ID := V_CUST_ORDER_ID;

  EXCEPTION

    WHEN OTHERS THEN

      RAISE_APPLICATION_ERROR(-20101,

                              '产生订单失败. 产品实例id: ' ||

                              I_PROD_INST.PROD_INST_ID || SQLERRM);

  END;



  PROCEDURE PROC_AUTO_SO_SERV(I_PROD_INST_ID    IN NUMBER, --接入类产品实例标识

                              I_ACT_TYPE        IN VARCHAR2, --动作类型（T：双停；S：单停；K：开机）

                              I_SERIAL_NBR      IN VARCHAR2, --TFJ_ACC_NBR表的主键

                              O_INTF_SO_SERV_ID OUT NUMBER, --INTF_SO_SERV表id

                              O_ERR_CODE        OUT NUMBER, --错误编码（0--成功 1--失败）

                              O_ERR_MSG         OUT VARCHAR2 --错误信息

                              )

  /*

    功能: 插INTF_SO_SERV表, 由轮询来生成订单

    Author  : g.caijx

    Created : 2012-7-7

    */

   IS

    V_IS_OWE_STOP      BOOLEAN := FALSE; --欠费双停

    V_IS_CALL_OWE_STOP BOOLEAN := FALSE; --欠费单停



    V_OWE_STOP_ATTR_ID           ATTR_SPEC.ATTR_ID%TYPE := 800000251; --欠费双停attr_id

    V_CALL_OWE_STOP_ATTR_ID      ATTR_SPEC.ATTR_ID%TYPE := 800013054; --欠费单停attr_id

    V_OWE_STOP_EXT_ATTR_NBR      ATTR_SPEC.EXT_ATTR_NBR%TYPE := '590000251'; --欠费双停EXT_ATTR_NBR

    V_CALL_OWE_STOP_EXT_ATTR_NBR ATTR_SPEC.EXT_ATTR_NBR%TYPE := '590000255'; --欠费单停EXT_ATTR_NBR



    V_SERVICE_OFFER_CD SERVICE_OFFER.STANDARD_CD%TYPE;--动作



    V_COUNT NUMBER;



    V_PROD_FUNC_TYPE PRODUCT.PROD_FUNC_TYPE%TYPE;

    V_PRODUCT_CODE   INTF_SO_SERV.PRODUCT_CODE%TYPE;

    V_ACC_NBR        INTF_SO_SERV.ACC_NBR%TYPE;

    V_AREA_ID        INTF_SO_SERV.AREA_ID%TYPE;

    V_AREA_CODE      INTF_SO_SERV.AREA_CODE%TYPE;



    V_ATTR_NBR   INTF_SO_ATTR.ATTR_NBR%TYPE;

    V_ATTR_VALUE INTF_SO_ATTR.ATTR_VALUE%TYPE;



    V_INTF_SO_SERV_ID INTF_SO_SERV.INTF_SO_SERV_ID%TYPE;

    V_INTF_SO_BUSI_ID INTF_SO_BUSI.INTF_SO_BUSI_ID%TYPE;

    V_INTF_SO_ATTR_ID INTF_SO_ATTR.INTF_SO_ATTR_ID%TYPE;

  BEGIN

    O_ERR_CODE := '1';



    --查询INTF_SO_SERV判断是否存在待处理的记录，如果存在反馈失败，处理结束。

    SELECT COUNT(*)

      INTO V_COUNT

      FROM INTF_SO_SERV S

     WHERE S.PROD_INST_ID = I_PROD_INST_ID

       AND S.STATE NOT IN ('70C','70D')

       AND S.CHANNEL_NBR = PKG_CONSTANTS.TFJ_CHANNEL_NBR;

    IF V_COUNT > 0 THEN

      O_ERR_MSG := '该产品实例已有在途申请';

      RETURN;

    END IF;



    --查询产品是否在用，是否存在，是否是接入类产品

    BEGIN

      SELECT P.EXT_PROD_ID,

             PI.ACC_NBR,

             PI.AREA_ID,

             PI.AREA_CODE,

             P.PROD_FUNC_TYPE

        INTO V_PRODUCT_CODE,

             V_ACC_NBR,

             V_AREA_ID,

             V_AREA_CODE,

             V_PROD_FUNC_TYPE

        FROM PROD_INST PI

        JOIN PRODUCT P

          ON PI.PRODUCT_ID = P.PRODUCT_ID

       WHERE PI.PROD_INST_ID = I_PROD_INST_ID;



      IF V_PROD_FUNC_TYPE <> '101' THEN

        O_ERR_MSG := '该产品不是接入类产品: ' || I_PROD_INST_ID;

        RETURN;

      END IF;

    EXCEPTION

      WHEN OTHERS THEN

        O_ERR_MSG := '产品不存在或不在用';

        RETURN;

    END;



    --判断是否有在途单

    IF PKG_COMMON.FNC_IS_ON_ROAD(I_PROD_INST_ID) THEN

      O_ERR_MSG := '有在途单';

      RETURN;

    END IF;



    -----------------------------------------

    --判断挂失停机、欠费单停、欠费双停、违章停机、停机保号、拆机停属性；

    FOR REC IN (SELECT A.ATTR_ID

                  FROM PROD_INST_ATTR A

                 WHERE A.PROD_INST_ID = I_PROD_INST_ID

                 AND A.STATUS_CD = '1000') LOOP

      CASE REC.ATTR_ID

      --欠费单停

        WHEN V_CALL_OWE_STOP_ATTR_ID THEN

          V_IS_CALL_OWE_STOP := TRUE;

          --欠费双停

        WHEN V_OWE_STOP_ATTR_ID THEN

          V_IS_OWE_STOP := TRUE;

        ELSE

          NULL;

      END CASE;

    END LOOP;



    /*

    欠费单停  4060300001

    欠费单停复机  4070300001

    欠费双停  4060300002

    欠费双停复机  4070300002

    */

    --单停处理

    IF I_ACT_TYPE = 'S' THEN

      --如果已经单停或双停时，直接反回成功。

      IF V_IS_CALL_OWE_STOP OR V_IS_OWE_STOP THEN

        O_ERR_CODE := 0;

        RETURN;

      END IF;



      V_SERVICE_OFFER_CD := '4060300001';

      V_ATTR_NBR   := V_CALL_OWE_STOP_EXT_ATTR_NBR;

      V_ATTR_VALUE := '1';

      --双停处理

    ELSIF I_ACT_TYPE = 'T' THEN

      --如果已经双停时，直接反回成功。

      IF V_IS_OWE_STOP THEN

        O_ERR_CODE := 0;

        RETURN;

      END IF;



      V_SERVICE_OFFER_CD := '4060300002';

      V_ATTR_NBR   := V_OWE_STOP_EXT_ATTR_NBR;

      V_ATTR_VALUE := '1';

      --开机处理

    ELSIF I_ACT_TYPE = 'K' THEN

      --如果没有欠费单停或双停时，直接反回成功。

      IF (NOT V_IS_CALL_OWE_STOP) AND (NOT V_IS_OWE_STOP) THEN

        O_ERR_CODE := 0;

        RETURN;

      END IF;



      IF V_IS_OWE_STOP THEN

        V_SERVICE_OFFER_CD := '4070300002';

        V_ATTR_NBR := V_OWE_STOP_EXT_ATTR_NBR;

      ELSIF V_IS_CALL_OWE_STOP THEN

        V_SERVICE_OFFER_CD := '4070300001';

        V_ATTR_NBR := V_CALL_OWE_STOP_EXT_ATTR_NBR;

      END IF;

      V_ATTR_VALUE := NULL; --null: 删除属性

    END IF;



    BEGIN

      --记录标准对象服务INTF_SO_SERV

      SELECT SEQ_INTF_SO_SERV_ID.NEXTVAL INTO V_INTF_SO_SERV_ID FROM DUAL;

      INSERT INTO INTF_SO_SERV

        (INTF_SO_SERV_ID,

         ACC_NBR,

         PRODUCT_CODE,

         AREA_ID,

         PROD_INST_ID,

         CHANNEL_NBR,

         AREA_CODE)

      VALUES

        (V_INTF_SO_SERV_ID,

         V_ACC_NBR,

         V_PRODUCT_CODE,

         V_AREA_ID,

         I_PROD_INST_ID,

         PKG_CONSTANTS.TFJ_CHANNEL_NBR,

         V_AREA_CODE);



      --记录标准对象业务INTF_SO_BUSI

      SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL INTO V_INTF_SO_BUSI_ID FROM DUAL;

      INSERT INTO INTF_SO_BUSI

        (INTF_SO_BUSI_ID,

         INTF_SO_SERV_ID,

         SERIAL_SEQ,

         BUSI_CODE,

         BUSI_TYPE,

         SERVICE_OFFER_CODE,

         OBJ_ID,

         ACTION_TYPE)

      VALUES

        (V_INTF_SO_BUSI_ID,

         V_INTF_SO_SERV_ID,

         0,

         V_PRODUCT_CODE,

         '1300',

         V_SERVICE_OFFER_CD,

         I_PROD_INST_ID,

         'M'); --[更新]



      --写入标准对象属性INTF_SO_ATTR

      SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL INTO V_INTF_SO_ATTR_ID FROM DUAL;

      INSERT INTO INTF_SO_ATTR

        (INTF_SO_ATTR_ID,

         INTF_SO_SERV_ID,

         INTF_SO_BUSI_ID,

         SERIAL_SEQ,

         ATTR_NBR,

         ATTR_VALUE)

      VALUES

        (V_INTF_SO_ATTR_ID,

         V_INTF_SO_SERV_ID,

         V_INTF_SO_BUSI_ID,

         0,

         V_ATTR_NBR,

         V_ATTR_VALUE);



      --如果是双停, 并且已经单停了, 则还需要删除单停属性

      IF I_ACT_TYPE = 'T' AND V_IS_CALL_OWE_STOP THEN

        SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL

          INTO V_INTF_SO_ATTR_ID

          FROM DUAL;

        INSERT INTO INTF_SO_ATTR

          (INTF_SO_ATTR_ID,

           INTF_SO_SERV_ID,

           INTF_SO_BUSI_ID,

           SERIAL_SEQ,

           ATTR_NBR,

           ATTR_VALUE)

        VALUES

          (V_INTF_SO_ATTR_ID,

           V_INTF_SO_SERV_ID,

           V_INTF_SO_BUSI_ID,

           0,

           V_CALL_OWE_STOP_EXT_ATTR_NBR,

           NULL);

      END IF;

    EXCEPTION

      WHEN OTHERS THEN

        O_ERR_MSG := '插表出错: ' || SQLERRM;

        RETURN;

    END;



    O_INTF_SO_SERV_ID := V_INTF_SO_SERV_ID;

    O_ERR_CODE        := 0;

  EXCEPTION

    WHEN OTHERS THEN

      O_ERR_MSG := SQLERRM;

  END;



  PROCEDURE PROC_PROCESS_PROD_INST(I_PROD_INST   IN OUT PROD_INST%ROWTYPE, --产品实例

                                   I_STATUS_CD   IN PROD_INST.STATUS_CD%TYPE, --产品状态, 该参数为NULL时, 不修改产品实例状态

                                   I_CHANNEL_NBR IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE --渠道

                                   )

  /*

      功能: 处理产品实例

    */

   IS

    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;

    V_NEW_STATUS_DATE DATE;

    V_CHANNEL_NAME    CHANNEL.CHANNEL_NAME%TYPE;

    V_PROD_INST_HIS_ID PROD_INST_HIS.HIS_ID%TYPE;

  BEGIN

    SELECT SEQ_PROD_INST_HIS_ID.NEXTVAL  INTO V_PROD_INST_HIS_ID FROM DUAL;

    V_NEW_STATUS_DATE := SYSDATE;

    --产品实例移到2表

    INSERT INTO PROD_INST_HIS

      (PROD_INST_ID,

       PRODUCT_ID,

       ACC_PROD_INST_ID,

       ADDRESS_ID,

       OWNER_CUST_ID,

       PAYMENT_MODE_CD,

       PRODUCT_PASSWORD,

       IMPORTANT_LEVEL,

       AREA_CODE,

       ACC_NBR,

       EXCH_ID,

       COMMON_REGION_ID,

       REMARK,

       PAY_CYCLE,

       BEGIN_RENT_TIME,

       STOP_RENT_TIME,

       FINISH_TIME,

       STOP_STATUS,

       STATUS_CD,

       CREATE_DATE,

       STATUS_DATE,

       UPDATE_DATE,

       PROC_SERIAL,

       USE_CUST_ID,

       EXT_PROD_INST_ID,

       ADDRESS_DESC,

       AREA_ID,

       UPDATE_STAFF,

       CREATE_STAFF,

       HIS_ID,

       REC_UPDATE_DATE,

       ACCOUNT,

       COMMUNITY_ID,

       VERSION,

       EXT_ACC_PROD_INST_ID)

      SELECT I_PROD_INST.PROD_INST_ID, --PROD_INST_ID,

             I_PROD_INST.PRODUCT_ID, --PRODUCT_ID,

             I_PROD_INST.ACC_PROD_INST_ID, --ACC_PROD_INST_ID,

             I_PROD_INST.ADDRESS_ID, --ADDRESS_ID,

             I_PROD_INST.OWNER_CUST_ID, --OWNER_CUST_ID,

             I_PROD_INST.PAYMENT_MODE_CD, --PAYMENT_MODE_CD,

             I_PROD_INST.PRODUCT_PASSWORD, --PRODUCT_PASSWORD,

             I_PROD_INST.IMPORTANT_LEVEL, --IMPORTANT_LEVEL,

             I_PROD_INST.AREA_CODE, --AREA_CODE,

             I_PROD_INST.ACC_NBR, --ACC_NBR,

             I_PROD_INST.EXCH_ID, --EXCH_ID,

             I_PROD_INST.COMMON_REGION_ID, --COMMON_REGION_ID,

             I_PROD_INST.REMARK, --REMARK,

             I_PROD_INST.PAY_CYCLE, --PAY_CYCLE,

             I_PROD_INST.BEGIN_RENT_TIME, --BEGIN_RENT_TIME,

             I_PROD_INST.STOP_RENT_TIME, --STOP_RENT_TIME,

             I_PROD_INST.FINISH_TIME, --FINISH_TIME,

             I_PROD_INST.STOP_STATUS, --STOP_STATUS,

             I_PROD_INST.STATUS_CD, --STATUS_CD,

             I_PROD_INST.CREATE_DATE, --CREATE_DATE,

             I_PROD_INST.STATUS_DATE, --STATUS_DATE,

             V_NEW_STATUS_DATE, --UPDATE_DATE,

             I_PROD_INST.PROC_SERIAL, --PROC_SERIAL,

             I_PROD_INST.USE_CUST_ID, --USE_CUST_ID,

             I_PROD_INST.EXT_PROD_INST_ID, --EXT_PROD_INST_ID,

             I_PROD_INST.ADDRESS_DESC, --ADDRESS_DESC,

             I_PROD_INST.AREA_ID, --AREA_ID,

             I_PROD_INST.UPDATE_STAFF, --UPDATE_STAFF,

             I_PROD_INST.CREATE_STAFF, --CREATE_STAFF,

             V_PROD_INST_HIS_ID , --HIS_ID,

             V_NEW_STATUS_DATE, --REC_UPDATE_DATE,

             I_PROD_INST.ACCOUNT, --ACCOUNT,

             I_PROD_INST.COMMUNITY_ID, --COMMUNITY_ID,

             I_PROD_INST.VERSION, --VERSION,
       I_PROD_INST.EXT_ACC_PROD_INST_ID --EXT_ACC_PROD_INST_ID

        FROM DUAL;

  ----crm00074562   DTS_CRM数据双写_接口过程修改
  ds_ins_intf_ins_ds_update_wh('PROD_INST_HIS','HIS_ID',V_PROD_INST_HIS_ID,
            'PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',null);


    --改产品实例

    UPDATE PROD_INST PI

       SET PI.UPDATE_DATE  = SYSDATE,

           PI.STATUS_CD    = DECODE(I_STATUS_CD, NULL, I_PROD_INST.STATUS_CD, I_STATUS_CD),--当I_STATUS_CD为NULL时, 不修改产品实例STATUS_CD

           PI.STATUS_DATE  = V_NEW_STATUS_DATE,

           PI.UPDATE_STAFF = PKG_CONSTANTS.JK_STAFF_ID,

           PI.VERSION =  PI.VERSION + 1

     WHERE PI.PROD_INST_ID = I_PROD_INST.PROD_INST_ID;

    --刷新I_PROD_INST

    SELECT

          PROD_INST_ID,PRODUCT_ID,ACC_PROD_INST_ID,ADDRESS_ID,OWNER_CUST_ID,

          PAYMENT_MODE_CD,PRODUCT_PASSWORD,IMPORTANT_LEVEL,AREA_CODE,ACC_NBR,

          EXCH_ID,COMMON_REGION_ID,REMARK,PAY_CYCLE,BEGIN_RENT_TIME,

          STOP_RENT_TIME,FINISH_TIME,STOP_STATUS,STATUS_CD,CREATE_DATE,

          STATUS_DATE,UPDATE_DATE,PROC_SERIAL,USE_CUST_ID,EXT_PROD_INST_ID,

          ADDRESS_DESC,AREA_ID,UPDATE_STAFF,CREATE_STAFF,REC_UPDATE_DATE,

          ACCOUNT,VERSION,COMMUNITY_ID,EXT_ACC_PROD_INST_ID



      INTO

          I_PROD_INST.PROD_INST_ID,I_PROD_INST.PRODUCT_ID,I_PROD_INST.ACC_PROD_INST_ID,I_PROD_INST.ADDRESS_ID,I_PROD_INST.OWNER_CUST_ID,

          I_PROD_INST.PAYMENT_MODE_CD,I_PROD_INST.PRODUCT_PASSWORD,I_PROD_INST.IMPORTANT_LEVEL,I_PROD_INST.AREA_CODE,I_PROD_INST.ACC_NBR,

          I_PROD_INST.EXCH_ID,I_PROD_INST.COMMON_REGION_ID,I_PROD_INST.REMARK,I_PROD_INST.PAY_CYCLE,I_PROD_INST.BEGIN_RENT_TIME,

          I_PROD_INST.STOP_RENT_TIME,I_PROD_INST.FINISH_TIME,I_PROD_INST.STOP_STATUS,I_PROD_INST.STATUS_CD,I_PROD_INST.CREATE_DATE,

          I_PROD_INST.STATUS_DATE,I_PROD_INST.UPDATE_DATE,I_PROD_INST.PROC_SERIAL,I_PROD_INST.USE_CUST_ID,I_PROD_INST.EXT_PROD_INST_ID,

          I_PROD_INST.ADDRESS_DESC,I_PROD_INST.AREA_ID,I_PROD_INST.UPDATE_STAFF,I_PROD_INST.CREATE_STAFF,I_PROD_INST.REC_UPDATE_DATE,

          I_PROD_INST.ACCOUNT,I_PROD_INST.VERSION,I_PROD_INST.COMMUNITY_ID,I_PROD_INST.EXT_ACC_PROD_INST_ID



      FROM PROD_INST PI

     WHERE PI.PROD_INST_ID = I_PROD_INST.PROD_INST_ID;



    --插INTF_INS_BILLING_UPDATE表

    BEGIN

      SELECT A.AREA_NBR

        INTO V_AREA_NBR

      FROM AREA_CODE A, COMMON_REGION B

     WHERE A.REGION_ID = B.COMMON_REGION_ID

       AND B.COMMON_REGION_ID = I_PROD_INST.AREA_ID;



      SELECT C.CHANNEL_NAME

        INTO V_CHANNEL_NAME

        FROM CHANNEL C

       WHERE C.CHANNEL_NBR = I_CHANNEL_NBR

         AND ROWNUM = 1;

    EXCEPTION

      WHEN OTHERS THEN

        NULL;

    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'PROD_INST',

                                            I_COLUMN_NAME => 'PROD_INST_ID',

                                            I_KEY_ID      => I_PROD_INST.PROD_INST_ID,

                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),

                                            I_TYPE        => '1004',

                                            I_REASON      => NULL,

                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,

                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION

    WHEN OTHERS THEN

      RAISE_APPLICATION_ERROR(-20301,

                              '把产品实例信息移到二表失败.' || SQLERRM);

  END;



  PROCEDURE PROC_PROCESS_PROD_OFFER_INST(I_PROD_INST   IN PROD_INST%ROWTYPE, --产品实例

                                         I_CHANNEL_NBR IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE --渠道

                                         )

  /*

      功能: 处理销售品实例

   */

   IS

    V_PROD_OFFER_INST PROD_OFFER_INST%ROWTYPE; --销售品实例

    V_AREA_NBR        AREA_CODE.AREA_NBR%TYPE;

    V_NEW_STATUS_DATE DATE;

    V_CHANNEL_NAME    CHANNEL.CHANNEL_NAME%TYPE;

    V_PROD_OFFER_INST_HIS_ID  PROD_OFFER_INST_HIS.HIS_ID%TYPE;

  BEGIN

    V_NEW_STATUS_DATE := SYSDATE;

    --根据prodinst取销售品实例

    BEGIN

      SELECT

          POI.PROD_OFFER_INST_ID,POI.PROD_OFFER_ID,POI.CUST_ID,POI.CHANNEL_ID,POI.CREATE_DATE,

          POI.STATUS_CD,POI.STATUS_DATE,POI.EFF_DATE,POI.EXP_DATE,POI.REGION,

          POI.UPDATE_DATE,POI.PROC_SERIAL,POI.EXT_PROD_OFFER_INST_ID,POI.AREA_ID,POI.REGION_CD,

          POI.UPDATE_STAFF,POI.CREATE_STAFF,POI.TRIAL_EFF_DATE,POI.TRIAL_EXP_DATE,POI.REC_UPDATE_DATE,

          POI.SERVICE_NBR,POI.VERSION,POI.END_AUTO,POI.REMARK,POI.WH_REMARK,

          POI.EXT_FLAG1,POI.EXT_FLAG2, poi.ext_prod_offer_inst_id

        INTO

          V_PROD_OFFER_INST.PROD_OFFER_INST_ID,V_PROD_OFFER_INST.PROD_OFFER_ID,V_PROD_OFFER_INST.CUST_ID,V_PROD_OFFER_INST.CHANNEL_ID,V_PROD_OFFER_INST.CREATE_DATE,

          V_PROD_OFFER_INST.STATUS_CD,V_PROD_OFFER_INST.STATUS_DATE,V_PROD_OFFER_INST.EFF_DATE,V_PROD_OFFER_INST.EXP_DATE,V_PROD_OFFER_INST.REGION,

          V_PROD_OFFER_INST.UPDATE_DATE,V_PROD_OFFER_INST.PROC_SERIAL,V_PROD_OFFER_INST.EXT_PROD_OFFER_INST_ID,V_PROD_OFFER_INST.AREA_ID,V_PROD_OFFER_INST.REGION_CD,

          V_PROD_OFFER_INST.UPDATE_STAFF,V_PROD_OFFER_INST.CREATE_STAFF,V_PROD_OFFER_INST.TRIAL_EFF_DATE,V_PROD_OFFER_INST.TRIAL_EXP_DATE,V_PROD_OFFER_INST.REC_UPDATE_DATE,

          V_PROD_OFFER_INST.SERVICE_NBR,V_PROD_OFFER_INST.VERSION,V_PROD_OFFER_INST.END_AUTO,V_PROD_OFFER_INST.REMARK,V_PROD_OFFER_INST.WH_REMARK,

          V_PROD_OFFER_INST.EXT_FLAG1,V_PROD_OFFER_INST.EXT_FLAG2, V_PROD_OFFER_INST.Ext_Prod_Offer_Inst_Id

        FROM OFFER_PROD_INST_REL R

        JOIN PROD_OFFER_INST POI

          ON POI.PROD_OFFER_INST_ID = R.PROD_OFFER_INST_ID

        JOIN PROD_OFFER PO

          ON PO.PROD_OFFER_ID = POI.PROD_OFFER_ID

       WHERE R.PROD_INST_ID = I_PROD_INST.PROD_INST_ID

         AND PO.OFFER_TYPE IN ('10', '11')

         AND POI.STATUS_CD = '1000'

         AND ROWNUM < 2;

    EXCEPTION

      WHEN OTHERS THEN

        RAISE_APPLICATION_ERROR(-20102, '找不到销售品实例');

    END;

   SELECT SEQ_PROD_OFFER_INST_HIS_ID.NEXTVAL INTO V_PROD_OFFER_INST_HIS_ID FROM DUAL;

    --插2表

    INSERT INTO PROD_OFFER_INST_HIS

      (PROD_OFFER_INST_ID,

       PROD_OFFER_ID,

       CUST_ID,

       CHANNEL_ID,

       CREATE_DATE,

       STATUS_CD,

       STATUS_DATE,

       EFF_DATE,

       EXP_DATE,

       REGION,

       UPDATE_DATE,

       PROC_SERIAL,

       EXT_PROD_OFFER_INST_ID,

       LAN_ID,

       AREA_ID,

       REGION_CD,

       UPDATE_STAFF,

       CREATE_STAFF,

       HIS_ID,

       REC_UPDATE_DATE,

       TRIAL_EFF_DATE,

       TRIAL_EXP_DATE,

       SERVICE_NBR,

       VERSION)

      SELECT V_PROD_OFFER_INST.PROD_OFFER_INST_ID, --PROD_OFFER_INST_ID,

             V_PROD_OFFER_INST.PROD_OFFER_ID, --PROD_OFFER_ID,

             V_PROD_OFFER_INST.CUST_ID, --CUST_ID,

             V_PROD_OFFER_INST.CHANNEL_ID, --CHANNEL_ID,

             V_PROD_OFFER_INST.CREATE_DATE, --CREATE_DATE,

             V_PROD_OFFER_INST.STATUS_CD, --STATUS_CD,

             V_PROD_OFFER_INST.STATUS_DATE, --STATUS_DATE,

             V_PROD_OFFER_INST.EFF_DATE, --EFF_DATE,

             V_PROD_OFFER_INST.EXP_DATE, --EXP_DATE,

             V_PROD_OFFER_INST.REGION, --REGION,

             V_NEW_STATUS_DATE, --UPDATE_DATE,

             V_PROD_OFFER_INST.PROC_SERIAL, --PROC_SERIAL,

             V_PROD_OFFER_INST.EXT_PROD_OFFER_INST_ID, --EXT_PROD_OFFER_INST_ID,

             NULL, --LAN_ID,

             V_PROD_OFFER_INST.AREA_ID, --AREA_ID,

             V_PROD_OFFER_INST.REGION_CD, --REGION_CD,

             V_PROD_OFFER_INST.UPDATE_STAFF, --UPDATE_STAFF,

             V_PROD_OFFER_INST.CREATE_STAFF, --CREATE_STAFF,

             V_PROD_OFFER_INST_HIS_ID, --HIS_ID,

             V_NEW_STATUS_DATE, --REC_UPDATE_DATE,

             V_PROD_OFFER_INST.TRIAL_EFF_DATE, --TRIAL_EFF_DATE,

             V_PROD_OFFER_INST.TRIAL_EXP_DATE, --TRIAL_EXP_DATE,

             V_PROD_OFFER_INST.SERVICE_NBR, --SERVICE_NBR,

             V_PROD_OFFER_INST.VERSION --VERSION,

        FROM DUAL;

        ----crm00074562   DTS_CRM数据双写_接口过程修改
  ds_ins_intf_ins_ds_update_wh('PROD_OFFER_INST_HIS','HIS_ID',V_PROD_OFFER_INST_HIS_ID,
            'PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',null);



    --改销售品实例

    UPDATE PROD_OFFER_INST POI

       SET POI.UPDATE_DATE  = SYSDATE,

           POI.STATUS_DATE  = V_NEW_STATUS_DATE,

           POI.UPDATE_STAFF = PKG_CONSTANTS.JK_STAFF_ID,

           POI.VERSION = POI.VERSION + 1

     WHERE POI.PROD_OFFER_INST_ID = V_PROD_OFFER_INST.PROD_OFFER_INST_ID;



    --插INTF_INS_BILLING_UPDATE表

    BEGIN

      SELECT A.AREA_NBR

        INTO V_AREA_NBR

      FROM AREA_CODE A, COMMON_REGION B

     WHERE A.REGION_ID = B.COMMON_REGION_ID

       AND B.COMMON_REGION_ID = I_PROD_INST.AREA_ID;



      SELECT C.CHANNEL_NAME

        INTO V_CHANNEL_NAME

        FROM CHANNEL C

       WHERE C.CHANNEL_NBR = I_CHANNEL_NBR

         AND ROWNUM = 1;

    EXCEPTION

      WHEN OTHERS THEN

        NULL;

    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'PROD_OFFER_INST',

                                            I_COLUMN_NAME => 'PROD_OFFER_INST_ID',

                                            I_KEY_ID      => V_PROD_OFFER_INST.PROD_OFFER_INST_ID,

                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),

                                            I_TYPE        => '1004',

                                            I_REASON      => NULL,

                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,

                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION

    WHEN OTHERS THEN

      RAISE_APPLICATION_ERROR(-20301,

                              '把销售品实例信息移到二表失败. ' || SQLERRM);

  END;



  PROCEDURE PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST                 IN PROD_INST%ROWTYPE, --产品实例

                                        I_ACTION                    IN VARCHAR2, --动作(A:新增, M:更新, D:删除)

                                        I_ATTR_ID                   IN PROD_INST_ATTR.ATTR_ID%TYPE, --属性

                                        I_ATTR_VALUE                IN PROD_INST_ATTR.ATTR_VALUE%TYPE, --属性值. 枚举类型请传ATTR_VALUE_ID, 当I_ACTION为D时,忽略该参数

                                        I_CHANNEL_NBR               IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE, --渠道

                                        O_ORDER_ITEM_PROC_ATTR_LIST IN OUT TYPE_ORDER_ITEM_PROC_ATTR_LIST --记录下变更的属性

                                        )

  /*

      功能: 处理产品实例属性

    */

   IS

    V_PROD_INST_ATTR        PROD_INST_ATTR%ROWTYPE;

    V_NEW_PROD_INST_ATTR_ID PROD_INST_ATTR.PROD_INST_ATTR_ID%TYPE;

    V_AREA_NBR              AREA_CODE.AREA_NBR%TYPE;

    V_NEW_STATUS_DATE       DATE;

    V_CHANNEL_NAME          CHANNEL.CHANNEL_NAME%TYPE;

    V_NEW_ATTR_VALUE_ID     PROD_INST_ATTR.ATTR_VALUE_ID%TYPE;

    V_ATTR_TYPE             ATTR_SPEC.ATTR_TYPE%TYPE;

    V_NEW_ATTR_VALUE        PROD_INST_ATTR.ATTR_VALUE%TYPE;

    V_EXP_DATE              PROD_INST_ATTR.EXP_DATE%TYPE;

    V_PROD_INST_ATTR_HIS_ID PROD_INST_ATTR_HIS.HIS_ID%TYPE;

  BEGIN

    IF O_ORDER_ITEM_PROC_ATTR_LIST IS NULL THEN

      O_ORDER_ITEM_PROC_ATTR_LIST := TYPE_ORDER_ITEM_PROC_ATTR_LIST();

    END IF;

    O_ORDER_ITEM_PROC_ATTR_LIST.EXTEND();

    O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).OPERATE := I_ACTION;

    O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).ATTR_ID := I_ATTR_ID;



    SELECT (SELECT S.ATTR_TYPE

              FROM ATTR_SPEC S

             WHERE S.ATTR_ID = I_ATTR_ID

               AND ROWNUM = 1)

      INTO V_ATTR_TYPE

      FROM DUAL;



    IF I_ACTION <> 'D' THEN

      --枚举类型处理

      IF V_ATTR_TYPE = 'T3' THEN

        V_NEW_ATTR_VALUE_ID := I_ATTR_VALUE;

        SELECT (SELECT V.ATTR_VALUE

                  FROM ATTR_VALUE V

                 WHERE V.ATTR_VALUE_ID = V_NEW_ATTR_VALUE_ID

                   AND ROWNUM = 1)

          INTO V_NEW_ATTR_VALUE

          FROM DUAL;

      ELSE

        V_NEW_ATTR_VALUE_ID := NULL;

        V_NEW_ATTR_VALUE := I_ATTR_VALUE;

      END IF;

    END IF;



    IF I_ACTION = 'A' THEN

      SELECT SEQ_PROD_INST_ATTR_ID.NEXTVAL

        INTO V_NEW_PROD_INST_ATTR_ID

        FROM DUAL;

      INSERT INTO PROD_INST_ATTR A

        (PROD_INST_ATTR_ID,

         PROD_INST_ID,

         ATTR_ID,

         ATTR_VALUE_ID,

         ATTR_VALUE,

         STATUS_CD,

         STATUS_DATE,

         EFF_DATE,

         EXP_DATE,

         CREATE_DATE,

         UPDATE_DATE,

         PROC_SERIAL,

         AREA_ID,

         REGION_CD,

         UPDATE_STAFF,

         CREATE_STAFF,

         REC_UPDATE_DATE)

        SELECT V_NEW_PROD_INST_ATTR_ID, --PROD_INST_ATTR_ID,

               I_PROD_INST.PROD_INST_ID, --PROD_INST_ID,

               I_ATTR_ID, --ATTR_ID,

               V_NEW_ATTR_VALUE_ID, --ATTR_VALUE_ID,

               V_NEW_ATTR_VALUE, --ATTR_VALUE,

               '1000', --STATUS_CD,

               SYSDATE, --STATUS_DATE,

               SYSDATE, --EFF_DATE,

               TO_DATE('2199-01-01', 'yyyy-mm-dd'), --EXP_DATE,

               SYSDATE, --CREATE_DATE,

               SYSDATE, --UPDATE_DATE,

               NULL, --PROC_SERIAL,

               I_PROD_INST.AREA_ID, --AREA_ID,

               I_PROD_INST.COMMON_REGION_ID, --REGION_CD,

               PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,

               PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,

               NULL --REC_UPDATE_DATE,

          FROM DUAL;



      O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).PROD_INST_ATTR_ID := V_NEW_PROD_INST_ATTR_ID;

      O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).NEW_VALUE := I_ATTR_VALUE;

      O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).OLD_VALUE := NULL;

    ELSIF I_ACTION = 'D' OR I_ACTION = 'M' THEN

      V_NEW_STATUS_DATE := SYSDATE;

      IF  I_ACTION = 'M' THEN

        V_EXP_DATE := FUNC_CALC_EFF_DATE(I_ATTR_ID);

      END IF;

      --一定会有值

      SELECT

          PROD_INST_ATTR_ID,PROD_INST_ID,ATTR_ID,ATTR_VALUE_ID,ATTR_VALUE,

          STATUS_CD,STATUS_DATE,EFF_DATE,EXP_DATE,CREATE_DATE,

          UPDATE_DATE,PROC_SERIAL,AREA_ID,REGION_CD,UPDATE_STAFF,

          CREATE_STAFF,REC_UPDATE_DATE,VERSION

        INTO

          V_PROD_INST_ATTR.PROD_INST_ATTR_ID,V_PROD_INST_ATTR.PROD_INST_ID,V_PROD_INST_ATTR.ATTR_ID,V_PROD_INST_ATTR.ATTR_VALUE_ID,V_PROD_INST_ATTR.ATTR_VALUE,

          V_PROD_INST_ATTR.STATUS_CD,V_PROD_INST_ATTR.STATUS_DATE,V_PROD_INST_ATTR.EFF_DATE,V_PROD_INST_ATTR.EXP_DATE,V_PROD_INST_ATTR.CREATE_DATE,

          V_PROD_INST_ATTR.UPDATE_DATE,V_PROD_INST_ATTR.PROC_SERIAL,V_PROD_INST_ATTR.AREA_ID,V_PROD_INST_ATTR.REGION_CD,V_PROD_INST_ATTR.UPDATE_STAFF,

          V_PROD_INST_ATTR.CREATE_STAFF,V_PROD_INST_ATTR.REC_UPDATE_DATE,V_PROD_INST_ATTR.VERSION

        FROM PROD_INST_ATTR A

       WHERE A.PROD_INST_ID = I_PROD_INST.PROD_INST_ID

         AND A.ATTR_ID = I_ATTR_ID

         AND A.STATUS_CD = '1000'

         AND ROWNUM = 1;

  SELECT SEQ_PROD_INST_ATTR_HIS_ID.NEXTVAL INTO V_PROD_INST_ATTR_HIS_ID FROM DUAL;



      INSERT INTO PROD_INST_ATTR_HIS AH

        (PROD_INST_ATTR_ID,

         PROD_INST_ID,

         ATTR_ID,

         ATTR_VALUE_ID,

         ATTR_VALUE,

         STATUS_CD,

         STATUS_DATE,

         EFF_DATE,

         EXP_DATE,

         CREATE_DATE,

         UPDATE_DATE,

         PROC_SERIAL,

         AREA_ID,

         REGION_CD,

         UPDATE_STAFF,

         CREATE_STAFF,

         HIS_ID,

         REC_UPDATE_DATE)

        SELECT A.PROD_INST_ATTR_ID, --PROD_INST_ATTR_ID,

               A.PROD_INST_ID, --PROD_INST_ID,

               A.ATTR_ID, --ATTR_ID,

               A.ATTR_VALUE_ID, --ATTR_VALUE_ID,

               A.ATTR_VALUE, --ATTR_VALUE,

               DECODE(I_ACTION,'D','1100',A.STATUS_CD), --STATUS_CD,

               A.STATUS_DATE, --STATUS_DATE,

               A.EFF_DATE, --EFF_DATE,

              -- DECODE(I_ACTION,'D',V_NEW_STATUS_DATE,A.EXP_DATE), --EXP_DATE,  CQ00038585

              DECODE(I_ACTION,'D',V_NEW_STATUS_DATE,V_EXP_DATE), --EXP_DATE,

               A.CREATE_DATE, --CREATE_DATE,

               V_NEW_STATUS_DATE, --UPDATE_DATE,

               A.PROC_SERIAL, --PROC_SERIAL,

               A.AREA_ID, --AREA_ID,

               A.REGION_CD, --REGION_CD,

               A.UPDATE_STAFF, --UPDATE_STAFF,

               A.CREATE_STAFF, --CREATE_STAFF,

               V_PROD_INST_ATTR_HIS_ID, --HIS_ID,

               V_NEW_STATUS_DATE --REC_UPDATE_DATE,

          FROM PROD_INST_ATTR A

         WHERE A.PROD_INST_ATTR_ID = V_PROD_INST_ATTR.PROD_INST_ATTR_ID;

   --crm00074562  DTS_CRM数据双写_接口过程修改
   ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS','HIS_ID',V_PROD_INST_ATTR_HIS_ID,
            'PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',null);

      IF I_ACTION = 'D' THEN

        O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).PROD_INST_ATTR_ID := V_PROD_INST_ATTR.PROD_INST_ATTR_ID;

        IF V_ATTR_TYPE = 'T3' THEN

          O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).NEW_VALUE := V_PROD_INST_ATTR.ATTR_VALUE_ID;

          O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).OLD_VALUE := V_PROD_INST_ATTR.ATTR_VALUE_ID;

        ELSE

          O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).NEW_VALUE := V_PROD_INST_ATTR.ATTR_VALUE;

          O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).OLD_VALUE := V_PROD_INST_ATTR.ATTR_VALUE;

        END IF;



        --删属性

        --CQ  crm00039160 存在欠费停机属性重复现象

        IF V_PROD_INST_ATTR.ATTR_ID IN  (800000251,800013054)  THEN

   SELECT SEQ_PROD_INST_ATTR_HIS_ID.NEXTVAL  INTO V_PROD_INST_ATTR_HIS_ID FROM DUAL;

          INSERT INTO PROD_INST_ATTR_HIS AH

            (PROD_INST_ATTR_ID,

             PROD_INST_ID,

             ATTR_ID,

             ATTR_VALUE_ID,

             ATTR_VALUE,

             STATUS_CD,

             STATUS_DATE,

             EFF_DATE,

             EXP_DATE,

             CREATE_DATE,

             UPDATE_DATE,

             PROC_SERIAL,

             AREA_ID,

             REGION_CD,

             UPDATE_STAFF,

             CREATE_STAFF,

             HIS_ID,

             REC_UPDATE_DATE)

            SELECT A.PROD_INST_ATTR_ID, --PROD_INST_ATTR_ID,

                   A.PROD_INST_ID, --PROD_INST_ID,

                   A.ATTR_ID, --ATTR_ID,

                   A.ATTR_VALUE_ID, --ATTR_VALUE_ID,

                   A.ATTR_VALUE, --ATTR_VALUE,

                   DECODE(I_ACTION,'D','1100',A.STATUS_CD), --STATUS_CD,

                   A.STATUS_DATE, --STATUS_DATE,

                   A.EFF_DATE, --EFF_DATE,

                --   DECODE(I_ACTION,'D',V_NEW_STATUS_DATE,A.EXP_DATE), --EXP_DATE,  CQ00038585

                   DECODE(I_ACTION,'D',V_NEW_STATUS_DATE,V_EXP_DATE), --EXP_DATE,

                   A.CREATE_DATE, --CREATE_DATE,

                   V_NEW_STATUS_DATE, --UPDATE_DATE,

                   A.PROC_SERIAL, --PROC_SERIAL,

                   A.AREA_ID, --AREA_ID,

                   A.REGION_CD, --REGION_CD,

                   A.UPDATE_STAFF, --UPDATE_STAFF,

                   A.CREATE_STAFF, --CREATE_STAFF,

                   V_PROD_INST_ATTR_HIS_ID, --HIS_ID,

                   V_NEW_STATUS_DATE --REC_UPDATE_DATE,

              FROM PROD_INST_ATTR A

             WHERE A.PROD_INST_ATTR_ID <> V_PROD_INST_ATTR.PROD_INST_ATTR_ID

               AND A.ATTR_ID = V_PROD_INST_ATTR.ATTR_ID

               AND A.PROD_INST_ID = V_PROD_INST_ATTR.PROD_INST_ID;

   --crm00074562  DTS_CRM数据双写_接口过程修改
   ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS','HIS_ID',V_PROD_INST_ATTR_HIS_ID,
            'PKG_TFJ',PKG_CONSTANTS.JK_STAFF_ID,'CREATE',null);


          DELETE FROM PROD_INST_ATTR A

           WHERE A.PROD_INST_ID = V_PROD_INST_ATTR.PROD_INST_ID

             AND A.ATTR_ID = V_PROD_INST_ATTR.ATTR_ID ;

        ELSE

          DELETE FROM PROD_INST_ATTR A

           WHERE A.PROD_INST_ATTR_ID = V_PROD_INST_ATTR.PROD_INST_ATTR_ID;

        END IF;



      ELSIF I_ACTION = 'M' THEN

        O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).PROD_INST_ATTR_ID := V_PROD_INST_ATTR.PROD_INST_ATTR_ID;

        O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).NEW_VALUE := I_ATTR_VALUE;

        IF V_ATTR_TYPE = 'T3' THEN

          O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).OLD_VALUE := V_PROD_INST_ATTR.ATTR_VALUE_ID;

        ELSE

          O_ORDER_ITEM_PROC_ATTR_LIST(O_ORDER_ITEM_PROC_ATTR_LIST.LAST).OLD_VALUE := V_PROD_INST_ATTR.ATTR_VALUE;

        END IF;



        --改属性

        UPDATE PROD_INST_ATTR A

           SET A.UPDATE_DATE  = SYSDATE,

               A.STATUS_DATE  = V_NEW_STATUS_DATE,

               A.UPDATE_STAFF = PKG_CONSTANTS.JK_STAFF_ID,

               A.ATTR_VALUE_ID= V_NEW_ATTR_VALUE_ID,

               A.ATTR_VALUE   = V_NEW_ATTR_VALUE,

               A.EFF_DATE = V_EXP_DATE ,  -- CQ00038585  ADD

               A.VERSION = A.VERSION + 1

         WHERE A.PROD_INST_ATTR_ID = V_PROD_INST_ATTR.PROD_INST_ATTR_ID;

      END IF;

    END IF;



    --插INTF_INS_BILLING_UPDATE表

    BEGIN

      SELECT A.AREA_NBR

        INTO V_AREA_NBR

      FROM AREA_CODE A, COMMON_REGION B

     WHERE A.REGION_ID = B.COMMON_REGION_ID

       AND B.COMMON_REGION_ID = I_PROD_INST.AREA_ID;



      SELECT C.CHANNEL_NAME

        INTO V_CHANNEL_NAME

        FROM CHANNEL C

       WHERE C.CHANNEL_NBR = I_CHANNEL_NBR

         AND ROWNUM = 1;

    EXCEPTION

      WHEN OTHERS THEN

        NULL;

    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'PROD_INST_ATTR',

                                            I_COLUMN_NAME => 'PROD_INST_ATTR_ID',

                                            I_KEY_ID      => CASE

                                                               WHEN I_ACTION = 'A' THEN

                                                                V_NEW_PROD_INST_ATTR_ID

                                                               ELSE

                                                                V_PROD_INST_ATTR.PROD_INST_ATTR_ID

                                                             END,

                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),

                                            I_TYPE        => '1004',

                                            I_REASON      => NULL,

                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,

                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION

    WHEN OTHERS THEN

      RAISE_APPLICATION_ERROR(-20201, '处理产品实例属性失败. ' || SQLERRM);

  END;



  /*

  0        立即生效

  1        次月生效

  2        当月生效

  3        次月16日生效

  */

  FUNCTION FUNC_CALC_EFF_DATE(I_ATTR_ID     IN  ATTR_SPEC.ATTR_ID%TYPE)  RETURN DATE IS

    V_MOD_EFF_TYPE  ATTR_SPEC.MOD_EFF_TYPE%TYPE;

    RESULT          DATE;

  BEGIN

    SELECT MOD_EFF_TYPE INTO V_MOD_EFF_TYPE

      FROM ATTR_SPEC

     WHERE ATTR_ID =  I_ATTR_ID;

     IF V_MOD_EFF_TYPE IS NULL OR V_MOD_EFF_TYPE = 0 THEN

        RESULT := SYSDATE;

     ELSIF V_MOD_EFF_TYPE = 1 THEN

        RESULT := TRUNC(ADD_MONTHS(SYSDATE,1),'MM');

     ELSIF V_MOD_EFF_TYPE = 2 THEN

        RESULT := TRUNC(SYSDATE,'MM');

     ELSIF V_MOD_EFF_TYPE = 3 THEN

        RESULT := TRUNC(ADD_MONTHS(SYSDATE,1),'MM') + 15;

     END IF;

     RETURN RESULT;

  EXCEPTION WHEN OTHERS THEN

     RETURN NULL;

  END ;



END PKG_TFJ;
/
