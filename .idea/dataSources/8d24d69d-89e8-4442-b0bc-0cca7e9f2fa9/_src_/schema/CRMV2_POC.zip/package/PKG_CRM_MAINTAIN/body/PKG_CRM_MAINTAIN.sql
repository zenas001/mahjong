CREATE PACKAGE BODY           PKG_CRM_MAINTAIN IS
  /*-------------------------------------------------
    INTF_ORDER
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_ORDER_HIS IS
  BEGIN
    FOR REC IN (SELECT * FROM INTF_ORDER WHERE STATE IN ('70C', '70D')) LOOP
      BEGIN
        INSERT INTO INTF_ORDER_HIS
          SELECT * FROM INTF_ORDER WHERE INTF_ORDER_ID = REC.INTF_ORDER_ID;
        DELETE FROM INTF_ORDER WHERE INTF_ORDER_ID = REC.INTF_ORDER_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    INTF_SO_SERV
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_SO_SERV_HIS IS
  BEGIN
    FOR REC IN (SELECT * FROM INTF_SO_SERV WHERE STATE IN ('70C', '70D')) LOOP
      BEGIN
        --INTF_SO_ATTR
        INSERT INTO INTF_SO_ATTR_HIS
          SELECT *
            FROM INTF_SO_ATTR
           WHERE INTF_SO_SERV_ID = REC.INTF_SO_SERV_ID;
        DELETE FROM INTF_SO_ATTR
         WHERE INTF_SO_SERV_ID = REC.INTF_SO_SERV_ID;

        --INTF_SO_BUSI_REL
        /*FOR REC_1 IN (SELECT *
                        FROM INTF_SO_BUSI
                       WHERE INTF_SO_SERV_ID = REC.INTF_SO_SERV_ID) LOOP
          INSERT INTO INTF_SO_BUSI_REL_HIS
            SELECT *
              FROM INTF_SO_BUSI_REL
             WHERE INTF_SO_BUSI_A_ID = REC_1.INTF_SO_BUSI_ID
                OR INTF_SO_BUSI_Z_ID = REC_1.INTF_SO_BUSI_ID;
          DELETE FROM INTF_SO_BUSI_REL
           WHERE INTF_SO_BUSI_A_ID = REC_1.INTF_SO_BUSI_ID
              OR INTF_SO_BUSI_Z_ID = REC_1.INTF_SO_BUSI_ID;
        END LOOP;*/

        --INTF_SO_BUSI
        INSERT INTO INTF_SO_BUSI_HIS
          SELECT *
            FROM INTF_SO_BUSI
           WHERE INTF_SO_SERV_ID = REC.INTF_SO_SERV_ID;
        DELETE FROM INTF_SO_BUSI
         WHERE INTF_SO_SERV_ID = REC.INTF_SO_SERV_ID;

        --INTF_SO_SERV
        INSERT INTO INTF_SO_SERV_HIS
          SELECT *
            FROM INTF_SO_SERV
           WHERE INTF_SO_SERV_ID = REC.INTF_SO_SERV_ID;
        DELETE FROM INTF_SO_SERV
         WHERE INTF_SO_SERV_ID = REC.INTF_SO_SERV_ID;

        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    INTF_ALL
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_ALL_HIS IS
  BEGIN
    FOR REC IN (SELECT *
                  FROM INTF_ALL A
                 WHERE NOT EXISTS
                 (SELECT *
                          FROM INTF_ORDER IO
                         WHERE IO.INTF_ALL_ID = A.INTF_ALL_ID)) LOOP
      BEGIN
        --INTF_ALL_ORDER_ITEM_REL
        INSERT INTO INTF_ALL_ORDER_ITEM_REL_HIS
          SELECT *
            FROM INTF_ALL_ORDER_ITEM_REL
           WHERE INTF_ALL_ID = REC.INTF_ALL_ID;
        DELETE FROM INTF_ALL_ORDER_ITEM_REL
         WHERE INTF_ALL_ID = REC.INTF_ALL_ID;

        --INTF_DATA_INFO
        INSERT INTO INTF_DATA_INFO_HIS
          SELECT * FROM INTF_DATA_INFO WHERE INTF_ALL_ID = REC.INTF_ALL_ID;
        DELETE FROM INTF_DATA_INFO WHERE INTF_ALL_ID = REC.INTF_ALL_ID;

        --INTF_ALL
        INSERT INTO INTF_ALL_HIS
          SELECT * FROM INTF_ALL WHERE INTF_ALL_ID = REC.INTF_ALL_ID;
        DELETE FROM INTF_ALL WHERE INTF_ALL_ID = REC.INTF_ALL_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    INTF_SMS_QUEUE
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_SMS_QUEUE_HIS IS
  BEGIN
    FOR REC IN (SELECT * FROM INTF_SMS_QUEUE WHERE STATE IN ('70C', '70D')) LOOP
      BEGIN
        INSERT INTO INTF_SMS_QUEUE_HIS
          SELECT *
            FROM INTF_SMS_QUEUE
           WHERE INTF_SMS_QUEUE_ID = REC.INTF_SMS_QUEUE_ID;
        DELETE FROM INTF_SMS_QUEUE
         WHERE INTF_SMS_QUEUE_ID = REC.INTF_SMS_QUEUE_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    INTF_REGION_UPDATE_QUEUE
    Author  : ouzhf
    Created : 2012-12-9
  -------------------------------------------------*/
  PROCEDURE PROC_REGION_UPDATE_QUEUE_HIS IS
  BEGIN
    FOR REC IN (SELECT *
                  FROM INTF_REGION_UPDATE_QUEUE
                 WHERE STATE IN ('70C', '70D')) LOOP
      BEGIN
        INSERT INTO INTF_REGION_UPDATE_QUEUE_HIS
          SELECT *
            FROM INTF_REGION_UPDATE_QUEUE
           WHERE INTF_REGION_UPDATE_INFO_ID =
                 REC.INTF_REGION_UPDATE_INFO_ID;
        DELETE FROM INTF_REGION_UPDATE_QUEUE
         WHERE INTF_REGION_UPDATE_INFO_ID = REC.INTF_REGION_UPDATE_INFO_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    INTF_UIM_INFO
    Author  : ouzhf
    Created : 2012-12-9
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_UIM_INFO_HIS IS
  BEGIN
    FOR REC IN (SELECT * FROM INTF_UIM_INFO WHERE STATE IN ('70C', '70D')) LOOP
      BEGIN
        INSERT INTO INTF_UIM_INFO_HIS
          SELECT * FROM INTF_UIM_INFO WHERE PSNM = REC.PSNM;
        DELETE FROM INTF_UIM_INFO WHERE PSNM = REC.PSNM;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    INTF_INS_BILLING_UPDATE_HIS
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_INS_BILL_UPDATE_HIS IS
  BEGIN
    FOR REC IN (SELECT *
                  FROM INTF_INS_BILLING_UPDATE
                 WHERE STATE IN ('70C', '70D')) LOOP
      BEGIN
        INSERT INTO INTF_INS_BILLING_UPDATE_HIS
          SELECT * FROM INTF_INS_BILLING_UPDATE WHERE INS_ID = REC.INS_ID;
        DELETE FROM INTF_INS_BILLING_UPDATE WHERE INS_ID = REC.INS_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    PROC_WORK_ORDER_HIS
    Author  : ouzhf
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER_HIS IS
  BEGIN
    FOR REC IN (SELECT *
                  FROM WORK_ORDER A
                 WHERE STATE IN ('5SC')
                    OR (STATE = '5SE' AND
                       (EXISTS (SELECT 1
                                   FROM WORK_ORDER
                                  WHERE SERV_ID = A.SERV_ID
                                    AND ORDER_SERIAL_NBR > A.ORDER_SERIAL_NBR) OR
                        EXISTS
                        (SELECT 1
                            FROM WORK_ORDER_HIS
                           WHERE SERV_ID = A.SERV_ID
                             AND ORDER_SERIAL_NBR > A.ORDER_SERIAL_NBR)))) LOOP
      BEGIN
        INSERT INTO WORK_ORDER_HIS
          SELECT *
            FROM WORK_ORDER
           WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;
        DELETE FROM WORK_ORDER
         WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    PROC_WORK_ORDER_CDMA_HIS
    Author  : ouzhf
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER_CDMA_HIS IS
  BEGIN
    FOR REC IN (SELECT *
                  FROM WORK_ORDER_CDMA A
                 WHERE STATE IN ('5SC')
                    OR (STATE = '5SE' AND
                       (EXISTS (SELECT 1
                                   FROM WORK_ORDER_CDMA
                                  WHERE SERV_ID = A.SERV_ID
                                    AND ORDER_SERIAL_NBR > A.ORDER_SERIAL_NBR) OR
                        EXISTS
                        (SELECT 1
                            FROM WORK_ORDER_CDMA_HIS
                           WHERE SERV_ID = A.SERV_ID
                             AND ORDER_SERIAL_NBR > A.ORDER_SERIAL_NBR)))) LOOP
      BEGIN
        INSERT INTO WORK_ORDER_CDMA_HIS
          SELECT *
            FROM WORK_ORDER_CDMA
           WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;
        DELETE FROM WORK_ORDER_CDMA
         WHERE ORDER_SERIAL_NBR = REC.ORDER_SERIAL_NBR;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    PROC_TFJ_ACC_NBR_HIS
    Author  : ouzhf
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR_HIS IS
  BEGIN
    FOR REC IN (SELECT * FROM TFJ_ACC_NBR WHERE STATE IN ('R')) LOOP
      BEGIN
        INSERT INTO TFJ_ACC_NBR_BAK
          SELECT * FROM TFJ_ACC_NBR WHERE SERIAL_NBR = REC.SERIAL_NBR;
        DELETE FROM TFJ_ACC_NBR WHERE SERIAL_NBR = REC.SERIAL_NBR;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    PROC_TFJ_ACC_NBR_RELA_HIS
    Author  : ouzhf
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR_RELA_HIS IS
  BEGIN
    FOR REC IN (SELECT * FROM TFJ_ACC_NBR_RELA WHERE STATE IN ('C', 'R')) LOOP
      BEGIN
        INSERT INTO TFJ_ACC_NBR_RELA_HIS
          SELECT * FROM TFJ_ACC_NBR_RELA WHERE SERIAL_NBR = REC.SERIAL_NBR;
        DELETE FROM TFJ_ACC_NBR_RELA WHERE SERIAL_NBR = REC.SERIAL_NBR;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    PROC_INTF_SO_SERV
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_SO_SERV IS
  BEGIN
    --已经成功数据处理
    update intf_so_serv
       set state = '70C', state_date = sysdate, remark = '已经成功'
     where cust_so_number is not null
       and state not in ('70C', '70D');
    --自动受理业务无变更处理
    update intf_so_serv
       set state = '70D', state_date = sysdate
     where err_msg like '%当前业务没有做任何变动%'
       and state = '70E'
       and deal_num > 2;
    --自动受理在途单延长1个小时
    update intf_so_serv
       set state          = '70B',
           deal_num       = 2,
           next_deal_time = sysdate + 60 / 24 / 60 --延长1个小时
     where state = '70E'
       and err_msg like '%在途%'
       and next_deal_time < sysdate
       and deal_num > 2;
    --割接中延长半个小时
    update intf_so_serv
       set state          = '70B',
           deal_num       = 2,
           next_deal_time = sysdate + 30 / 24 / 60 --延长半个小时
     where state = '70E'
       and err_msg like '%割接中%'
       and next_deal_time < sysdate
       and deal_num > 2;
    --对已经拆机的号码无需处理
    update intf_so_serv a
       set state      = '70D',
           state_date = sysdate,
           remark     = '号码已经失效，无需处理'
     where exists (select 1
              from prod_inst
             where prod_inst_id = a.prod_inst_id
               and status_cd = '110000'
               and rownum = 1)
       and state = '70E'
       and err_msg like '%获取不到满足条件的产权客户ID，对应的产品实例不存在或已失效%'
       and deal_num > 2;
    --对在用的号码重新发起处理
    update intf_so_serv a
       set deal_num       = 2,
           next_deal_time = sysdate,
           acc_nbr        = (select acc_nbr
                               from prod_inst
                              where prod_inst_id = a.prod_inst_id
                                and status_cd <> '110000'
                                and rownum = 1)
     where exists (select 1
              from prod_inst
             where prod_inst_id = a.prod_inst_id
               and status_cd <> '110000'
               and acc_nbr is not null
               and rownum = 1)
       and state = '70E'
       and err_msg like '%获取不到满足条件的产权客户ID，对应的产品实例不存在或已失效%'
       and deal_num > 2;
    --超时异常错误重跑
    update intf_so_serv
       set deal_num = 2, next_deal_time = sysdate
     where state = '70E'
       and err_msg like '%调用接口[%_WS_URL]超时%'
       and deal_num > 2
       and cust_so_number is null;
    --未知错误问题重跑
    update intf_so_serv
       set deal_num = 2, next_deal_time = sysdate
     where state = '70E'
       and err_msg like '%未知错误%'
       and deal_num > 2;
    --连接池超时问题重跑
    update intf_so_serv
       set deal_num = 2, next_deal_time = sysdate
     where err_msg like '%java.net.ConnectException%'
       and state = '70E'
       and deal_num > 2;

    --crm00040667 begin
    --拨打充值开通对应的可选包已拆除作废不处理
    delete from intf_so_busi
     where (intf_so_serv_id, obj_id) in
           (select intf_so_serv_id,
                   to_char(substr(err_msg,
                                  instr(err_msg, '](') + 2,
                                  instr(err_msg, ')所属的基础销售品应不为空') -
                                  instr(err_msg, '](') - 2)) obj_id
              from intf_so_serv
             where channel_nbr = '600105B001'
               and state = '70E'
               and deal_num > 2
               and err_msg like
                   '%系统平台内部错误(销售品实例[PROD_OFFER_INST]下的可选包%所属的基础销售品应不为空%'
               and cust_so_number is null)
       and busi_type = '1200'
       and action_type = 'M';
    --拨打充值开通对应的可选包已拆除问题重跑
    update intf_so_serv
       set deal_num = 2, next_deal_time = sysdate
     where channel_nbr = '600105B001'
       and state = '70E'
       and deal_num > 2
       and err_msg like
           '%系统平台内部错误(销售品实例[PROD_OFFER_INST]下的可选包%所属的基础销售品应不为空%'
       and cust_so_number is null;
     --crm00040667 end

    --停复机未配置的无需处理
    update intf_so_serv
       set state = '70D', state_date = sysdate
     where channel_nbr = '600105B007'
       and state = '70E'
       and err_msg like '%中找不到编码为[59000025_]属性%'
       and deal_num > 2;
    --拆机失败回滚成功的无需处理
    update intf_so_serv
       set state = '70D', state_date = sysdate, remark = '拆机失败已经回滚'
     where channel_nbr in ('600105B004', '600105B005')
       and state = '70E'
       and err_msg like '%拆机处理失败3次以上，已通知计费拆机回滚%'
       and deal_num > 2;
    --计费环境异常延长2个小时重跑
    update intf_so_serv
       set deal_num = 2, next_deal_time = sysdate + 2 / 24 --延迟2个小时
     where channel_nbr in ('600105B004', '600105B005')
       and state = '70E'
       and err_msg =
           'debtOweQry:callQBalanceOweFromTuxedo异常:Could not get a Tuxedo session removeFailDeal:TPException:Could not get a Tuxedo session'
       and deal_num > 2;
    /*年缴相关维护开始-------------------------------------------------*/
    --计费发布引起的问题重跑
    update intf_so_serv
       set deal_num = 2, next_deal_time = sysdate
     where channel_nbr = '600105B003'
       and err_msg like
           '%已丢弃程序包  的当前状态ORA-04061: package "BILL_591.PKG_ONE_PRICE_CALC" 的当前状态失效%'
       and state = '70E'
       and deal_num > 2;
    --年缴已经拆除的无需处理
    update intf_so_serv
       set state = '70D', state_date = sysdate
     where channel_nbr = '600105B003'
       and state = '70E'
       and deal_num > 2
       and err_msg like
           '%系统平台内部错误(销售品实例[PROD_OFFER_INST]下的可选包%所属的基础销售品应不为空%';
    --计费历史的未销帐的年缴数据无需处理
    update intf_so_serv
       set state      = '70D',
           state_date = sysdate,
           remark     = '计费系统中历史的续缴还存在未销帐的费用引起，无需处理'
     where channel_nbr = '600105B003'
       and state = '70E'
       and deal_num > 2
       and err_msg like '%出错，存在未缴纳的年缴费用，请先缴费后再办理续缴业务%';
    --同计费交互过程出错的年缴数据，无需处理
    update intf_so_serv
       set state      = '70D',
           state_date = sysdate,
           remark     = 'CRM与计费的交互过程中出错，无需处理'
     where channel_nbr = '600105B003'
       and state = '70E'
       and deal_num > 2
       and err_msg like '%根据%获取instanceId出错:根据%取不到数据%';
    /*年缴相关维护结束-------------------------------------------------*/
    commit;
  END;

  /*-------------------------------------------------
    PROC_INTF_ORDER
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_ORDER IS
  BEGIN
    --超过2天的短信不在发送
    update intf_order
       set state = '70D', state_date = sysdate
     where channel_nbr = '600105A001'
       and state = '70E'
       and state_date - create_date > 2;
    --短信队列处理异常重新处理
    update intf_order
       set deal_num = 2, next_deal_time = sysdate + 60 / 24 / 60 --延长1个小时
     where channel_nbr = '600105A001'
       and state = '70E'
       and deal_num > 2;
    --统一充值系统用户不存在或用户已存在的无需处理
    update intf_order
       set state = '70D', state_date = sysdate
     where channel_nbr = '600105A008'
       and state = '70E'
       and err_msg in ('用户不存在', '用户已存在')
       and deal_num > 2;
    --本地携号数据同步用户已经存在的无需处理
    update intf_order
       set state = '70D'
     where err_msg like '%ORA-00001: unique constraint%'
       and channel_nbr = '600105B008'
       and state = '70E'
       and deal_num > 2;
    --厦门一卡通系统不存在的无需处理
    update intf_order
       set state = '70D', state_date = sysdate
     where channel_nbr = '600105A052'
       and state = '70E'
       and err_msg = '没有原始交易，请联系发卡方'
       and deal_num > 2;
    --接口调用超时重置
    update intf_order
       set deal_num = 2, next_deal_time = sysdate
     where state = '70E'
       and err_msg like '调用接口[%]超时%'
       and deal_num > 2;
    --接口连接失败重置
    update intf_order
       set deal_num = 2, next_deal_time = sysdate
     where state = '70E'
       and err_msg like '%Connection closed;%'
       and deal_num > 2;
    commit;
  END;

  /*-------------------------------------------------
    PROC_TFJ_ACC_NBR
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR IS
    cursor cur is
      select a.serial_nbr from tfj_acc_nbr a
       where state = 'E'
         and not exists (select 1
                from tfj_acc_nbr
               where serv_id = a.serv_id
                 and order_serial_nbr > a.order_serial_nbr)
         and not exists
       (select 1
                from tfj_acc_nbr_bak
               where serv_id = a.serv_id
                 and order_serial_nbr > a.order_serial_nbr);
  BEGIN
    --停复机档案更新失败重新处理
    update tfj_acc_nbr
       set proc_num = 0
     where state = 'A'
       and proc_num = 10;
    --停复机档案5SA处理失败重新处理
/*    update tfj_acc_nbr a
       set state = 'A'
     where state = 'E'
       and not exists (select 1
              from tfj_acc_nbr
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and not exists
     (select 1
              from tfj_acc_nbr_bak
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr);*/
    commit;
    for rec in cur loop
       update tfj_acc_nbr a
       set state = 'A'
        where serial_nbr = rec.serial_nbr;
       commit;
    end loop;
  END;

  /*-------------------------------------------------
    PROC_TFJ_ACC_NBR_RELA
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR_RELA IS
  BEGIN
    --关联停复机处理失败重新处理
    update tfj_acc_nbr_rela a
       set state = 'S'
     where state = 'E'
       and serial_nbr = (select max(to_number(serial_nbr))
                           from tfj_acc_nbr_rela
                          where serv_id = a.serv_id);
    commit;
  END;

  /*-------------------------------------------------
    PROC_WORK_ORDER
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER IS
  BEGIN
    --C网停复机5SA处理失败重新处理
    update work_order a
       set state = '5SA'
     where state = '5SE'
       and not exists (select 1
              from work_order
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and not exists (select 1
              from work_order_his
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and not exists (select 1
              from tfj_work_order
             where order_serial_nbr = a.order_serial_nbr)
       and not exists (select 1
              from tfj_work_order_jh
             where order_serial_nbr = a.order_serial_nbr)
       and not exists
     (select 1
              from tfj_work_order_gd
             where order_serial_nbr = a.order_serial_nbr);
    --C网停复机5SB处理失败重新处理
    update work_order a
       set state = '5SB'
     where state = '5SE'
       and not exists (select 1
              from work_order_cdma
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and not exists
     (select 1
              from work_order_cdma_his
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and (exists
            (select 1
               from tfj_work_order
              where order_serial_nbr = a.order_serial_nbr) or exists
            (select 1
               from tfj_work_order_jh
              where order_serial_nbr = a.order_serial_nbr) or exists
            (select 1
               from tfj_work_order_gd
              where order_serial_nbr = a.order_serial_nbr));
    commit;
  END;

  /*-------------------------------------------------
    PROC_WORK_ORDER_CDMA
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER_CDMA IS
  BEGIN
    --C网停复机5SA处理失败重新处理
    update work_order_cdma a
       set state = '5SA'
     where state = '5SE'
       and not exists (select 1
              from work_order_cdma
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and not exists (select 1
              from work_order_cdma_his
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and not exists
     (select 1
              from tfj_work_order_cdma
             where order_serial_nbr = a.order_serial_nbr);
    --C网停复机5SB处理失败重新处理
    update work_order_cdma a
       set state = '5SB'
     where state = '5SE'
       and not exists (select 1
              from work_order_cdma
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and not exists (select 1
              from work_order_cdma_his
             where serv_id = a.serv_id
               and order_serial_nbr > a.order_serial_nbr)
       and exists
     (select 1
              from tfj_work_order_cdma
             where order_serial_nbr = a.order_serial_nbr);
    commit;
  END;

  /*-------------------------------------------------
    PROC_INTF_INS_BILL_UPDATE
    Author  : ouzhf
    Created : 2012-10-29
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_INS_BILL_UPDATE IS
  BEGIN
    --批量送计费失败重新处理
    update intf_ins_billing_update
       set deal_num = 2, next_deal_time = sysdate
     where deal_num > 3
       and state = '70E';
    commit;
  END;

END PKG_CRM_MAINTAIN;
/
