CREATE PACKAGE BODY           PKG_XM20170 IS

  /*
  外部属性编码：
  申请期限      590001661
  指定播报号码  590000371
  旧号码        590001170

  主从关系  100600
  同号关系  109910
  主副关系  109920
  */
  C_ZC_RELATION CONSTANT prod_inst_attr.attr_value%TYPE := '100600';
  C_TH_RELATION CONSTANT prod_inst_attr.attr_value%TYPE := '109910';
  C_ZF_RELATION CONSTANT prod_inst_attr.attr_value%TYPE := '109920';

  --common_region_type : C4= 1499
  C_REGION_TYPE CONSTANT common_region.region_type%TYPE := '1499';

  --申请期限      590001661
  C_DEADLINE_EXT_ATTR_NBR CONSTANT attr_spec.ext_attr_nbr%TYPE := '590001661';
  /*
  800000003 小灵通 594000248
  800000000 普通电话  594000276
  800000002 移动语音  610003886
  */
  /*号码信息查询*/
  PROCEDURE PROC_NBR_INFO_QUERY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                                I_ACC_NBR     IN VARCHAR2, --业务号码
                                O_EXT_PROD_ID OUT VARCHAR2, --外部产品规格编码（失败为空），比如：594000276-普通电话, 610003886-移动语音， 594000248-小灵通
                                O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                O_ERR_MSG     OUT VARCHAR2 --错误信息
                                ) IS
    v_res_count    NUMBER := 0;
    v_prod_inst_id prod_inst.prod_inst_id%TYPE;
    v_query_count  NUMBER := 0;

    CURSOR cur_prod_inst_query IS
      SELECT pi.prod_inst_id, pi.product_id
        FROM prod_inst pi, common_region cr
       WHERE 1 = 1
         AND pi.common_region_id = cr.common_region_id
         AND pi.status_cd != '110000' --拆机状态
         AND pi.area_code = I_AREA_CODE
         AND cr.region_type = C_REGION_TYPE --C4级
         AND pi.acc_nbr = I_ACC_NBR;

  BEGIN
    O_EXT_PROD_ID := '';
    O_ERR_CODE    := 0;
    O_ERR_MSG     := '';

    IF (I_ACC_NBR IS NULL) OR (I_AREA_CODE IS NULL) THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '入参为空';
      RETURN;
    END IF;
      FOR rec IN  cur_prod_inst_query LOOP
      IF v_res_count = 0 THEN
        v_prod_inst_id := rec.prod_inst_id;
        v_res_count    := v_res_count + 1;
        --res_count = 1,取到第2条记录
      ELSE
        v_res_count := v_res_count + 1;
        --v_prod_inst_id放A端
        SELECT COUNT(*)
          INTO v_query_count
          FROM prod_inst_rel pir
         WHERE 1 = 1
           AND pir.relation_type_cd IN (C_TH_RELATION, C_ZF_RELATION)
           AND pir.prod_inst_a_id = v_prod_inst_id
           AND pir.prod_inst_z_id = rec.prod_inst_id;

        IF v_query_count = 0 THEN
          --没有查到同号关系或主副关系，把v_prod_inst_id放Z端
          SELECT COUNT(*)
            INTO v_query_count
            FROM prod_inst_rel pir
           WHERE 1 = 1
             AND pir.relation_type_cd IN (C_TH_RELATION, C_ZF_RELATION)
             AND pir.prod_inst_z_id = v_prod_inst_id
             AND pir.prod_inst_a_id = rec.prod_inst_id;

          IF v_query_count = 0 THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := '查询异常';
            RETURN;
          ELSE
            v_prod_inst_id := rec.prod_inst_id;
          END IF;
        END IF;
      END IF;
     END LOOP;
     IF  v_prod_inst_id  IS  NOT NULL  THEN
     SELECT p.ext_prod_id
      INTO O_EXT_PROD_ID
      FROM product p, prod_inst pi
     WHERE 1 = 1
       AND p.product_id = pi.product_id
       AND pi.prod_inst_id = v_prod_inst_id;
      END  IF ;
 IF O_EXT_PROD_ID IS NULL THEN --如果一表查询记录为0，那就查询二表
    FOR rec IN  (SELECT pis.prod_inst_id, pis.product_id
        FROM prod_inst_his pis, common_region cr
       WHERE 1 = 1
         AND piS.common_region_id = cr.common_region_id
         AND pis.status_cd != '110000' --拆机状态
         AND pis.area_code = I_AREA_CODE
         AND cr.region_type = C_REGION_TYPE --C4级
         AND pis.acc_nbr = I_ACC_NBR)  LOOP
      IF v_res_count = 0 THEN
        v_prod_inst_id := rec.prod_inst_id;
        v_res_count    := v_res_count + 1;
        --res_count = 1,取到第2条记录
      ELSE
        v_res_count := v_res_count + 1;
        --v_prod_inst_id放A端
        SELECT COUNT(*)
          INTO v_query_count
          FROM prod_inst_rel pir
         WHERE 1 = 1
           AND pir.relation_type_cd IN (C_TH_RELATION, C_ZF_RELATION)
           AND pir.prod_inst_a_id = v_prod_inst_id
           AND pir.prod_inst_z_id = rec.prod_inst_id;

        IF v_query_count = 0 THEN
          --没有查到同号关系或主副关系，把v_prod_inst_id放Z端
          SELECT COUNT(*)
            INTO v_query_count
            FROM prod_inst_rel pir
           WHERE 1 = 1
             AND pir.relation_type_cd IN (C_TH_RELATION, C_ZF_RELATION)
             AND pir.prod_inst_z_id = v_prod_inst_id
             AND pir.prod_inst_a_id = rec.prod_inst_id;

          IF v_query_count = 0 THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := '查询异常';
            RETURN;
          ELSE
            v_prod_inst_id := rec.prod_inst_id;
          END IF;
        END IF;
      END IF;
    END LOOP;

    SELECT p.ext_prod_id
      INTO O_EXT_PROD_ID
      FROM product p, prod_inst_his pis
     WHERE 1 = 1
       AND p.product_id = pis.product_id
       AND pis.prod_inst_id = v_prod_inst_id;
    END  IF;
  EXCEPTION
    WHEN OTHERS THEN
      O_EXT_PROD_ID := '';
      O_ERR_CODE    := 1;
      O_ERR_MSG     := '查询异常';
      RETURN;
  END PROC_NBR_INFO_QUERY;

  /*改号通知音信息查询*/
  PROCEDURE PROC_GHTZY_INFO_QUERY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                                  I_ACC_NBR_OLD IN VARCHAR2, --旧业务号码
                                  I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话
                                  O_ACC_NBR_NEW OUT VARCHAR2, --新业务号码（失败为空）
                                  O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                  O_ERR_MSG     OUT VARCHAR2 --错误信息
                                  ) IS

    v_prod_inst_id     prod_inst.prod_inst_id%TYPE;
    v_deadline_value   prod_inst_attr.attr_value%TYPE;
    v_tzy_prod_inst_id prod_inst.prod_inst_id%TYPE;
    v_tzy_status_date  prod_inst_attr.status_date%TYPE;
    v_secrecy          prod_inst_attr.attr_value%TYPE;
    v_exp_date         DATE;

  BEGIN
    O_ACC_NBR_NEW := '';
    O_ERR_CODE    := 0;
    O_ERR_MSG     := '';

    IF (I_ACC_NBR_OLD IS NULL) OR (I_AREA_CODE IS NULL) OR
       (I_EXT_PROD_ID IS NULL) THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '入参为空';
      RETURN;
    END IF;

    --从历史表中取最新的记录
    SELECT pih.prod_inst_id
      INTO v_prod_inst_id
      FROM prod_inst_his pih, product p
     WHERE 1 = 1
       AND pih.rec_update_date =
           (SELECT max(pih_tmp.rec_update_date)
              FROM prod_inst_his pih_tmp, product p_tmp
             WHERE 1 = 1
               AND pih_tmp.product_id = p_tmp.product_id
               AND p_tmp.ext_prod_id = I_EXT_PROD_ID
               AND pih_tmp.area_code = I_AREA_CODE
               AND pih_tmp.acc_nbr = I_ACC_NBR_OLD)
       AND pih.product_id = p.product_id
       AND p.ext_prod_id = I_EXT_PROD_ID
       AND pih.area_code = I_AREA_CODE
       AND pih.acc_nbr = I_ACC_NBR_OLD;

    BEGIN
      /*
      改号通知音             800303319
      改号通知音延期         800994915
      改号通知音三个月       800303578
      */
      --查改号通知音功能类产品
      SELECT piz.prod_inst_id
        INTO v_tzy_prod_inst_id
        FROM prod_inst pia, prod_inst piz, product p
       WHERE 1 = 1
         AND pia.prod_inst_id = piz.acc_prod_inst_id
         AND piz.product_id = p.product_id
         AND p.ext_prod_id IN ('800303319', '800303578', '800994915')
         AND pia.status_cd != '110000'
         AND piz.status_cd != '110000'
         AND pia.prod_inst_id = v_prod_inst_id;

      --查功能类产品属性
      SELECT pia.status_date, pia.attr_value
        INTO v_tzy_status_date, v_deadline_value
        FROM prod_inst_attr pia, attr_spec a_s
       WHERE 1 = 1
         AND a_s.attr_id = pia.attr_id
         AND a_s.ext_attr_nbr = C_DEADLINE_EXT_ATTR_NBR
         AND pia.prod_inst_id = v_tzy_prod_inst_id;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '用户没有办理改号通知业务';
        RETURN;
    END;

    --判断产品实例的改号通知音的期限是否已经失效
    --v_deadline_value取值：月份（ONE，TOW，THREE），天数值
    CASE v_deadline_value
      WHEN 'ONE' THEN
        v_exp_date := ADD_MONTHS(v_tzy_status_date, 1);
      WHEN 'TOW' THEN
        v_exp_date := ADD_MONTHS(v_tzy_status_date, 2);
      WHEN 'THREE' THEN
        v_exp_date := ADD_MONTHS(v_tzy_status_date, 3);
      ELSE
        v_exp_date := v_tzy_status_date + v_deadline_value;
    END CASE;

    IF v_exp_date < SYSDATE THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '改号通知业务已过期';
      RETURN;
    END IF;

    BEGIN
      --判断114是否保密, 590000303
      SELECT pia.attr_value
        INTO v_secrecy
        FROM prod_inst_attr pia, attr_spec a_s
       WHERE 1 = 1
         AND pia.attr_id = a_s.attr_id
         AND a_s.ext_attr_nbr = '590000303'
         AND pia.prod_inst_id = v_prod_inst_id;

      IF v_secrecy = 'Y' THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '用户办理了查号保密';
        RETURN;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    SELECT pi.acc_nbr
      INTO O_ACC_NBR_NEW
      FROM prod_inst pi
     WHERE 1 = 1
       AND pi.prod_inst_id = v_prod_inst_id;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '无查询记录';
    WHEN OTHERS THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '查询异常';
  END PROC_GHTZY_INFO_QUERY;

  /*呼叫限制密码查询*/
  PROCEDURE PROC_HJXZ_INFO_QUERY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                                 I_ACC_NBR     IN VARCHAR2, --业务号码
                                 I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话
                                 O_HJXZ_PWD    OUT VARCHAR2, --呼叫限制密码（失败为空）
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2 --错误信息
                                 ) IS

    v_prod_inst_id      prod_inst.prod_inst_id%TYPE;
    v_hjxz_prod_inst_id prod_inst.prod_inst_id%TYPE;

  BEGIN
    O_HJXZ_PWD := '';
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    pkg_common.proc_main_prod_inst(I_AREA_CODE,
                                    I_ACC_NBR,
                                    I_EXT_PROD_ID,
                                    v_prod_inst_id,
                                    O_ERR_CODE,
                                    O_ERR_MSG);

    IF O_ERR_CODE = 1 THEN
      RETURN;
    END IF;

    --查呼叫限制（800303464）功能类产品
    SELECT pi.prod_inst_id
      INTO v_hjxz_prod_inst_id
      FROM prod_inst pi, product p
     WHERE 1 = 1
       AND p.product_id = pi.product_id
       AND pi.status_cd != '110000'
       AND p.ext_prod_id = '800303464'--'800303464' --呼叫限制 800303464
       AND pi.acc_prod_inst_id = v_prod_inst_id;

    --获取密码属性
    SELECT pia.attr_value
      INTO O_HJXZ_PWD
      FROM prod_inst_attr pia, attr_spec a_s
     WHERE 1 = 1
       AND pia.attr_id = a_s.attr_id
       AND a_s.ext_attr_nbr = '590000366' --密码：590000366
       AND pia.prod_inst_id = v_hjxz_prod_inst_id;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      O_HJXZ_PWD := '';
      O_ERR_CODE := 1;
      O_ERR_MSG  := '查询数据不存在';
      RETURN;
    WHEN OTHERS THEN
      O_HJXZ_PWD := '';
      O_ERR_CODE := 1;
      O_ERR_MSG  := '查询异常';
      RETURN;
  END PROC_HJXZ_INFO_QUERY;

  /*业务密码验证*/
  PROCEDURE PROC_PWD_VERIFY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                            I_ACC_NBR     IN VARCHAR2, --业务号码
                            I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话, 594000248-小灵通
                            I_PWD         IN Varchar2, --密码值（明文）
                            O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                            O_ERR_MSG     OUT VARCHAR2 --错误信息
                            ) IS

    v_eny_pwd       prod_inst_attr.attr_value%TYPE;
    v_prod_inst_pwd prod_inst_attr.attr_value%TYPE;
    v_prod_inst_id  prod_inst.prod_inst_id%TYPE;
  --为0：统一密码，为1：密码
  v_pwd_type      number := 0;

  BEGIN
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    pkg_common.proc_main_prod_inst(I_AREA_CODE,
                                    I_ACC_NBR,
                                    I_EXT_PROD_ID,
                                    v_prod_inst_id,
                                    O_ERR_CODE,
                                    O_ERR_MSG);

    IF O_ERR_CODE = 1 THEN
      RETURN;
    END IF;

    BEGIN
      --获取统一密码属性
      SELECT pia.attr_value
        INTO v_prod_inst_pwd
        FROM prod_inst_attr pia, attr_spec a_s
       WHERE 1 = 1
         AND pia.attr_id = a_s.attr_id
         AND a_s.ext_attr_nbr = '590004515' --统一密码：590004515
         AND pia.prod_inst_id = v_prod_inst_id;

    EXCEPTION
      --没有统一密码，验证密码（590000366）
      WHEN NO_DATA_FOUND THEN
        BEGIN
          --获取密码属性
          SELECT pia.attr_value
            INTO v_prod_inst_pwd
            FROM prod_inst_attr pia, attr_spec a_s
           WHERE 1 = 1
             AND pia.attr_id = a_s.attr_id
             AND a_s.ext_attr_nbr = '590000366' --密码：590000366
             AND pia.prod_inst_id = v_prod_inst_id;

          v_pwd_type := 1;
        EXCEPTION
          WHEN OTHERS THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := '档案异常';
            RETURN;
        END;

    END;

    pkg_util.proc_user_encrypt('123456', v_eny_pwd);

    IF v_eny_pwd = v_prod_inst_pwd THEN
        O_ERR_CODE := 1;
        O_ERR_MSG := '未初始化';
        RETURN;
    END IF;

  IF v_pwd_type = 0 THEN
    pkg_util.proc_encry_new(I_PWD, v_eny_pwd,O_ERR_CODE, O_ERR_MSG);
  ELSE
    pkg_util.proc_user_encrypt(I_PWD, v_eny_pwd);
  END IF;

    IF v_eny_pwd != v_prod_inst_pwd THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '密码错误';
      RETURN;
    ELSE
      O_ERR_CODE := 0;
      O_ERR_MSG  := '';
      RETURN;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '查询异常';
      RETURN;
  END PROC_PWD_VERIFY;
END PKG_XM20170;
/
