CREATE PACKAGE BODY           PKG_HIS_TO_PACK IS

  PROCEDURE PROC_HIS_TO_PACK(DATE IN NUMBER, TYPE IN VARCHAR2) IS
    I_DATE         NUMBER;
    V_TYPE         VARCHAR2(30);
    v_pack_boolean BOOLEAN;

  BEGIN
    I_DATE := DATE;
    V_TYPE := TYPE;
    if V_TYPE = 'QUERY' then
      v_pack_boolean := FUNC_HIS_ORDER_PACK(I_DATE);
    end if;
    if V_TYPE = 'CUSTOMER' then
      v_pack_boolean := FUNC_HIS_ORDER_PACK_EXT(I_DATE);
    end if;
  END;

  FUNCTION FUNC_HIS_ORDER_PACK(DATE IN NUMBER) RETURN BOOLEAN IS
    I_DATE NUMBER;
    v_intf BOOLEAN;
  BEGIN
    I_DATE := DATE;
    v_intf := FUNC_HIS_ORDER_INTF(ADD_MONTHS(SYSDATE, -6),
                                  ADD_MONTHS(SYSDATE, -6) - I_DATE,
                                  'QUERY');
    RETURN v_intf;
  END;

  FUNCTION FUNC_HIS_ORDER_PACK_EXT(DATE IN NUMBER) RETURN BOOLEAN IS
    I_DATE NUMBER;
    v_intf BOOLEAN;

  BEGIN
    I_DATE := DATE;
    v_intf := FUNC_HIS_ORDER_INTF(ADD_MONTHS(SYSDATE, -6),
                                  ADD_MONTHS(SYSDATE, -6) - I_DATE,
                                  'CUSTOMER');
    RETURN v_intf;
  END;

  FUNCTION FUNC_HIS_ORDER_INTF(BEGIN_ITEM  IN DATE,
                               FINISH_TIME IN DATE,
                               TYPE        IN VARCHAR2) RETURN BOOLEAN IS
    D_BEGIN_ITEM  DATE;
    D_FINISH_TIME DATE;
    V_TYPE        VARCHAR2(30);
    V_SISE        VARCHAR2(30);
    V_SISE_HIS    VARCHAR2(30);
    B_CHANL       VARCHAR2(30);

    CURSOR CUST_ORDER_HISS IS
      select SEQ_CUSTOMER_ORDER_PACK_ID.nextval CUSTOMER_ORDER_PACK_ID,
             coh.cust_order_id,
             coh.cust_so_number,
             coh.area_id,
             coh.region_cd,
             '1299' STATUS_CD,
             sysdate STATUS_DATE,
             sysdate CREATE_DATE,
             V_TYPE OBJ_TYPE,
             rownum
        from customer_order_his coh
       where coh.his_id =
             (select max(b.his_id)
                from customer_order_his b
               where b.cust_so_number = coh.cust_so_number)
         and coh.update_date > D_FINISH_TIME
         and coh.update_date < D_BEGIN_ITEM;

  BEGIN
    D_BEGIN_ITEM  := BEGIN_ITEM;
    D_FINISH_TIME := FINISH_TIME;
    V_TYPE        := TYPE;

    FOR CUR IN CUST_ORDER_HISS LOOP
      BEGIN
        select COUNT(1)
          into V_SISE
          from customer_order_pack cop
         where cop.cust_so_number = CUR.CUST_SO_NUMBER
           AND COP.OBJ_TYPE = V_TYPE
           AND rownum < 2;
        select COUNT(1)
          into V_SISE_HIS
          from customer_order_pack_his cop
         where cop.cust_so_number = CUR.CUST_SO_NUMBER
           AND COP.OBJ_TYPE = V_TYPE
           AND rownum < 2;
        select CO.CHANNEL_ID
          into B_CHANL
          from Customer_Order_His CO
         where CO.CUST_SO_NUMBER = CUR.CUST_SO_NUMBER;

        iF (V_SISE = 0 AND V_SISE_HIS = 0 AND B_CHANL <> 134) then
          insert into customer_order_pack
            (CUSTOMER_ORDER_PACK_ID,
             CUSTOMER_ORDER_ID,
             CUST_SO_NUMBER,
             AREA_ID,
             REGION_CD,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             OBJ_TYPE)
          VALUES
            (CUR.CUSTOMER_ORDER_PACK_ID,
             CUR.cust_order_id,
             CUR.cust_so_number,
             CUR.area_id,
             CUR.region_cd,
             CUR.STATUS_CD,
             CUR.STATUS_DATE,
             CUR.CREATE_DATE,
             CUR.OBJ_TYPE);
        end if;

        IF MOD(CUR.rownum, 1000) = 0 then
          COMMIT;
        END if;
      END;
    END LOOP;
    COMMIT;
    RETURN true;
  END;
END PKG_HIS_TO_PACK;
/
