CREATE PACKAGE BODY           pkg_deal_cust_mail IS

  FUNCTION func_cust_own_prod_count(in_cust_id IN NUMBER) RETURN NUMBER IS
    RESULT NUMBER;
    /*
    功能说明：获取一个客户，战略分群是政企客户的，
    证件类型不是‘公章、企业代码证、工商登记号和单位公函、未知、不详、数固客户编码、集团编号、预开户编号’，且产权客户名下产品数量
    入参：客户ID
    编写日期：2012/2/23
    编写人：林志强
    */
  BEGIN
    SELECT COUNT(*)
      INTO RESULT
      FROM cust a, party_certification b, prod_inst c
     WHERE a.cust_id = in_cust_id
       AND a.cust_type = '1000'
       AND b.cert_sort = '10'
       AND b.cert_type NOT IN ('6', '7', '15', '39', '38')
       AND a.party_id = b.party_id
       AND c.owner_cust_id = a.cust_id
       AND c.status_cd <> '1100';
    RETURN(RESULT);
  END;

  FUNCTION func_check_cust_statecos(in_cust_id IN NUMBER) RETURN BOOLEAN IS
    RESULT  BOOLEAN;
    i_count INTEGER;

    /*
    功能说明：判断一个客户是否为政企客户
    入参：客户ID
    编写日期：2012/2/23
    编写人：林志强
    */
  BEGIN

    --条件一：战略分群是政企客户的，如果证件类型是公章、企业代码证、工商登记号和单位公函，则判定为政企客户

    SELECT COUNT(*)
      INTO i_count
      FROM cust a, party_certification c
     WHERE c.cert_sort = '10'
       AND a.cust_type = '1000'
       AND a.party_id = c.party_id
       AND c.cert_type IN ('6', '7', '15', '39')
       AND a.cust_id = in_cust_id;

    IF i_count > 0
    THEN
      RESULT := TRUE;
    ELSE

      --条件二：战略分群是政企客户的，如果证件类型不是‘’，且产权客户名下产品数量大于等于50个的，判定为政企客户

      i_count := func_cust_own_prod_count(in_cust_id);

      IF i_count > 49
      THEN
        RESULT := TRUE;
      ELSE
        RESULT := FALSE;
      END IF;
    END IF;
    RETURN(RESULT);
  END;

  FUNCTION func_check_prod_exist(in_acc_nbr IN VARCHAR2,
                                 in_cust_id IN NUMBER) RETURN BOOLEAN IS
    RESULT  BOOLEAN;
    i_count INTEGER;
    /*
    功能说明：判断一个客户的号码档案是否存在，即不存在历史表中
    入参：业务号码,客户ID
    编写日期：2012/2/24
    编写人：林志强
    */
  BEGIN

    SELECT COUNT(*)
      INTO i_count
      FROM prod_inst a
     WHERE a.owner_cust_id = in_cust_id
       AND a.acc_nbr = in_acc_nbr;

    IF i_count > 0
    THEN
      RESULT := TRUE;
    ELSE
      RESULT := FALSE;
    END IF;

    RETURN(RESULT);
  END;

  FUNCTION func_check_mail_exist(in_mail_address IN VARCHAR2) RETURN BOOLEAN IS
    RESULT  BOOLEAN;
    i_count INTEGER;
    /*
    功能说明：判断一个客户的邮箱地址记录是否存在
    入参：邮箱地址
    返回值：存在的记录数
    编写日期：2012/2/24
    编写人：林志强
    */
  BEGIN
    SELECT COUNT(*)
      INTO i_count
      FROM cust_mail a
     WHERE a.mail_addr = in_mail_address;

    IF i_count > 0
    THEN
      RESULT := TRUE;
    ELSE
      RESULT := FALSE;
    END IF;
    RETURN(RESULT);
  END;

  FUNCTION func_insert_mail_record(in_cust_id      IN NUMBER,
                                   in_mail_address IN VARCHAR2,
                                   in_use_type     VARCHAR2,
                                   in_source       IN VARCHAR2)
    RETURN BOOLEAN IS
    RESULT BOOLEAN;
    /*
    功能说明：插入一个custMail记录
    入参：客户ID,邮箱，type,source
    编写日期：2012/2/24
    编写人：林志强
    */
  BEGIN
    INSERT INTO cust_mail
      (cust_mail_id,
       cust_id,
       addr_serial,
       mail_addr,
       SOURCE,
       use_type,
       status_cd,
       status_date,
       create_date)
    VALUES
      (seq_cust_mail_id.nextval,
       in_cust_id,
       seq_cust_mail_id.currval,
       in_mail_address,
       in_source,
       in_use_type,
       '1000',
       SYSDATE,
       SYSDATE);

    --commit;
    RESULT := TRUE; --插入成功 ，返回true
    RETURN(RESULT);
  EXCEPTION
    WHEN OTHERS THEN
      RESULT := FALSE; --插入失败 ，返回false
      RETURN(RESULT);
  END;

  FUNCTION func_update_mail_record(in_cust_mail_id IN NUMBER,
                                   in_status_cd    IN VARCHAR2)
    RETURN BOOLEAN IS
    RESULT BOOLEAN;
    /*
    功能说明：更新一个custMail记录
    入参：客户邮箱记录ID，状态
    编写日期：2012/2/24
    编写人：林志强
    */
  BEGIN
    UPDATE cust_mail a
       SET a.status_cd   = in_status_cd,
           a.status_date = SYSDATE,
           a.update_date = SYSDATE
     WHERE a.cust_mail_id = in_cust_mail_id;

    --COMMIT;

    RESULT := TRUE;
    RETURN(RESULT);
  EXCEPTION
    WHEN OTHERS THEN
      RESULT := FALSE;
      RETURN(RESULT);
  END;

  PROCEDURE proc_deal_new_cdma_record IS
    i_product_id       NUMBER := 0;
    i_service_offer_id NUMBER := 0;
    i_sys_class_id     NUMBER := 0;
    i_result           BOOLEAN := FALSE;
    i_cust_id          NUMBER := 0;
    i_acc_nbr          VARCHAR2(32);
    i_mail_address     VARCHAR2(50);
    i                  NUMBER := 0;
    /*
    功能说明：查询一个月内竣工的新装-CDMA业务产品的订单，
    且号码档案仍存在的（含：在用、停机等，只要prod表还能查到记录，未到历史表就行）；
    再查此号码对应的客户是否为‘政企业客户’；
    若是政企客户，则不做任何处理；
    若不是‘政企客户’，再将‘此号码’+‘@189.cn’，看下这个邮箱地址在KH_MAILADDR表是否已有记录，
    若已有记录，则不再往kh_mailaddr表插记录；
    若没有记录，则新增相应的记录（USE_TYPE=’账单推送 ‘,SOURCE=’主动推送’）
    编写日期：2012/2/24
    编写人：林志强
    */
  BEGIN

    BEGIN
      --查询产品id
      SELECT a.product_id
        INTO i_product_id
        FROM product a
       WHERE a.product_name = '移动语音';
    EXCEPTION
      WHEN no_data_found
           OR too_many_rows THEN
        i_product_id := NULL;
    END;

    BEGIN
      --查询动作id
      SELECT a.service_offer_id
        INTO i_service_offer_id
        FROM service_offer a
       WHERE a.service_offer_name = '新装';
    EXCEPTION
      WHEN no_data_found
           OR too_many_rows THEN
        i_service_offer_id := NULL;
    END;

    BEGIN
      --查询classid
      SELECT a.class_id
        INTO i_sys_class_id
        FROM sys_class a
       WHERE a.java_code = 'ProdInst';
    EXCEPTION
      WHEN no_data_found
           OR too_many_rows THEN
        i_sys_class_id := NULL;
    END;

    IF i_product_id IS NOT NULL
       AND i_service_offer_id IS NOT NULL
       AND i_sys_class_id IS NOT NULL
    THEN
      --查询制定时段内竣工的新装-CDMA业务产品的订单的业务号码和客户id
      FOR rec IN (SELECT pi.owner_cust_id, pi.acc_nbr
                    FROM customer_order_his co,
                         order_item_his     oi,
                         prod_inst          pi
                   WHERE co.status_cd = '300000'
                     AND co.cust_order_id = oi.cust_order_id
                     AND oi.class_id = i_sys_class_id
                     AND oi.service_offer_id = i_service_offer_id
                     AND oi.order_item_obj_id = pi.prod_inst_id
                     AND pi.product_id = i_product_id
                     AND co.update_date BETWEEN
                         add_months(to_date(to_char(SYSDATE, 'YYYY-MM-DD'),
                                            'YYYY-MM-DD'),
                                    -1) AND
                         to_date(to_char(SYSDATE, 'YYYY-MM-DD'),
                                 'YYYY-MM-DD'))
      LOOP
        i_cust_id := rec.owner_cust_id;
        i_acc_nbr := rec.acc_nbr;

        i_result := func_check_prod_exist(i_acc_nbr, i_cust_id); --判断号码档案是否存在
        IF i_result = TRUE
        THEN
          i_result := func_check_cust_statecos(i_cust_id); --判断是否为政企
          IF i_result = FALSE
          THEN
            i_mail_address := i_acc_nbr || '@189.cn';
            i_result       := func_check_mail_exist(i_mail_address); --判断邮箱地址是否存在
            IF i_result = FALSE
            THEN
              i_result := func_insert_mail_record(i_cust_id,
                                                  i_mail_address,
                                                  '账单推送',
                                                  '主动推送'); --插入记录
              IF i_result = TRUE
              THEN
                i := i + 1; --插入成功计数器 +1
              ELSE
                ROLLBACK; --回滚，返回
                RETURN;
              END IF;

              IF i = 10
              THEN
                BEGIN
                  COMMIT; --每10 条记录提交一次
                EXCEPTION
                  WHEN OTHERS THEN
                    ROLLBACK; --回滚，返回
                    RETURN;
                END;

                i := 0; --计数器置0

              END IF;
            END IF;
          END IF;
        END IF;
      END LOOP;

      ---判断记录是否全部提交
      IF i > 0
      THEN
        BEGIN
          COMMIT;
          --i := 0;
        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK; --回滚，返回
            RETURN;
        END;
      END IF;
    END IF;
  END;

  PROCEDURE proc_deal_del_cdma_record IS
    i_product_id       NUMBER := 0;
    i_service_offer_id NUMBER := 0;
    i_sys_class_id     NUMBER := 0;
    i_result           BOOLEAN := FALSE;
    i_cust_id          NUMBER := 0;
    i_acc_nbr          VARCHAR2(32);
    i_mail_address     VARCHAR2(50);
    i                  NUMBER := 0;

    /*
    功能说明：查询一个月内竣工的拆除-CDMA业务产品的订单，且号码档案已不在用（在prod表查不到记录）；
    再将‘此号码’+‘@189.cn’，看下这个邮箱地址在KH_MAILADDR表是否已有记录，
    若有记录，则将记录状态改为‘历史’；
    若没有记录，不做任何处理；
    编写日期：2012/2/24
    编写人：林志强
    */

  BEGIN

    BEGIN
      --查询产品id
      SELECT a.product_id
        INTO i_product_id
        FROM product a
       WHERE a.product_name = '移动语音';
    EXCEPTION
      WHEN no_data_found
           OR too_many_rows THEN
        i_product_id := NULL;
    END;

    BEGIN
      --查询动作id
      SELECT a.service_offer_id
        INTO i_service_offer_id
        FROM service_offer a
       WHERE a.service_offer_name = '拆机';
    EXCEPTION
      WHEN no_data_found
           OR too_many_rows THEN
        i_service_offer_id := NULL;
    END;

    BEGIN
      --查询classid
      SELECT a.class_id
        INTO i_sys_class_id
        FROM sys_class a
       WHERE a.java_code = 'ProdInst';
    EXCEPTION
      WHEN no_data_found
           OR too_many_rows THEN
        i_sys_class_id := NULL;
    END;

    IF i_product_id IS NOT NULL
       AND i_service_offer_id IS NOT NULL
       AND i_sys_class_id IS NOT NULL
    THEN
      --查询制定时段内竣工的新装-CDMA业务产品的订单的业务号码和客户id
      FOR rec IN (SELECT pi.owner_cust_id, pi.acc_nbr
                    FROM customer_order_his co,
                         order_item_his     oi,
                         prod_inst          pi
                   WHERE co.status_cd = '300000'
                     AND co.cust_order_id = oi.cust_order_id
                     AND oi.class_id = i_sys_class_id
                     AND oi.service_offer_id = i_service_offer_id
                     AND oi.order_item_obj_id = pi.prod_inst_id
                     AND pi.product_id = i_product_id
                     AND co.update_date BETWEEN
                         add_months(to_date(to_char(SYSDATE, 'YYYY-MM-DD'),
                                            'YYYY-MM-DD'),
                                    -1) AND
                         to_date(to_char(SYSDATE, 'YYYY-MM-DD'),
                                 'YYYY-MM-DD'))
      LOOP
        i_cust_id := rec.owner_cust_id;
        i_acc_nbr := rec.acc_nbr;

        i_result := func_check_prod_exist(i_acc_nbr, i_cust_id); --判断号码档案是否存在

        IF i_result = FALSE
        THEN

          i_mail_address := i_acc_nbr || '@189.cn';
          i_result       := func_check_mail_exist(i_mail_address); --判断邮箱地址是否存在

          IF i_result = TRUE
          THEN

            FOR rec IN (SELECT cm.cust_mail_id
                          FROM cust_mail cm
                         WHERE cm.mail_addr = i_mail_address)
            LOOP
              i_result := func_update_mail_record(rec.cust_mail_id, '1100');

              IF i_result = TRUE
              THEN
                i := i + 1; --插入成功计数器 +1
              ELSE
                ROLLBACK; --回滚，返回
                RETURN;
              END IF;
            END LOOP;

            BEGIN
              COMMIT;
              i := 0;
            EXCEPTION
              WHEN OTHERS THEN
                ROLLBACK;
                RETURN;
            END;

          END IF;

        END IF;

      END LOOP;
    END IF;
  END;

END pkg_deal_cust_mail;
/
