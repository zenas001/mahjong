CREATE package           PKG_UPDATE_COMMUNITY_ID is
  /*标准社区ID割接*/
  PROCEDURE PROC_MAIN; --返回具体的错误信息

end PKG_UPDATE_COMMUNITY_ID;
/
