CREATE PACKAGE BODY           PKG_COUNT_NUMBER2_FROM_ORDER is
  --取当天受理的订单中，产品为移动语音、无线宽带，动作为业务改名、过户、拆机、新装、使用客户变更，更新1中取的数据；
  PROCEDURE PKG_YD_WX IS
    cur_party_name          varchar(500);
    cur_cert_number         varchar(500);
    cur_cert_type           varchar(50);
    party_name              varchar(500);
    cert_number_use         varchar(500);
    cert_type               varchar(50);
    mobile_use_count_temp   number;
    mobile_own_count_temp   number;
    mobile_use_count_temp_b number;
    mobile_own_count_temp_b number;
    owner_cust_id           number;
    prod_inst_num           number;
    cert_mobile_num_temp    number;
    user_cust_num           number;
    party_num               number;
    party_num_2             number;
    party_num_3             number;
    new_cert_number         varchar(500);
    old_cert_number         varchar(500);
    old_num                 number;
    new_num                 number;
    O_ERR_MSG               varchar(1000);
    CURSOR customer_order_his IS
      select coh.cust_order_id, coh.cust_id, rownum
        from crmv2.customer_order_his coh
       where coh.update_date > trunc(sysdate) - 1;
     --  coh.cust_so_number = 'FJ2016072178809701';
    -- coh.cust_so_number = 'FJ2016040661296877';
    --coh.cust_so_number = 'FJ2016062178783901';
    --coh.cust_so_number = 'FJ2016061778781501';
  begin
    for cur in customer_order_his loop
      select count(1)
        into party_num
        from crmv2.party p, crmv2.cust c, crmv2.party_certification pc
       where p.party_id = c.party_id
         and pc.party_id = c.party_id
         and c.cust_id = cur.cust_id
         and p.party_name is not null
         and pc.cert_number is not null
         and pc.cert_type is not null
         and rownum = 1;
      if party_num > 0 then
        select p.party_name, pc.cert_number, pc.cert_type
          into cur_party_name, cur_cert_number, cur_cert_type
          from crmv2.party p, crmv2.cust c, crmv2.party_certification pc
         where p.party_id = c.party_id
           and pc.party_id = c.party_id
           and c.cust_id = cur.cust_id
           and rownum = 1;

        for cur_order_item in (select oih.service_offer_id,
                                      oih.order_item_obj_id,
                                      oih.class_id,
                                      oih.order_item_id
                                 from crmv2.order_item_his oih
                                where oih.cust_order_id = cur.cust_order_id) loop
          mobile_use_count_temp   := 0;
          mobile_own_count_temp   := 0;
          mobile_use_count_temp_b := 0;
          mobile_own_count_temp_b := 0;
          if cur_order_item.class_id = 4 then
            select count(1)
              into prod_inst_num
              from crmv2.prod_inst pi, crmv2.product p
             where pi.product_id = p.product_id
               and pi.prod_inst_id = cur_order_item.order_item_obj_id
               and p.product_id in
                   (800000002, 800000007, 900283009, 800575119, 901132803);
            if prod_inst_num > 0 then
              select count(1)
                into party_num_2
                from crmv2.prod_inst           pi,
                     crmv2.cust                c,
                     crmv2.party_certification pc,
                     crmv2.party               p
               where pi.prod_inst_id = cur_order_item.order_item_obj_id
                 and pi.use_cust_id = c.cust_id
                 and c.party_id = p.party_id
                 and p.party_id = pc.party_id
                 and p.party_name is not null
                 and pc.cert_number is not null
                 and pi.owner_cust_id is not null;

              if party_num_2 > 0 then
                select pc.cert_type,
                       p.party_name,
                       pc.cert_number,
                       pi.owner_cust_id
                  into cert_type,
                       party_name,
                       cert_number_use,
                       owner_cust_id
                  from crmv2.prod_inst           pi,
                       crmv2.cust                c,
                       crmv2.party_certification pc,
                       crmv2.party               p
                 where pi.prod_inst_id = cur_order_item.order_item_obj_id
                   and pi.use_cust_id = c.cust_id
                   and c.party_id = p.party_id
                   and p.party_id = pc.party_id
                   and p.party_name is not null
                   and pc.cert_number is not null
                   and pi.owner_cust_id is not null
                   and rownum = 1;

                if cur_order_item.service_offer_id = '100' then
                  --新装
                  if cert_type in ('1', '2', '3', '4', '12', '14', '22') then
                    mobile_own_count_temp := mobile_own_count_temp + 1;
                  else
                    if cert_type in ('7', '6', '40', '39', '15') then
                      mobile_use_count_temp := mobile_use_count_temp + 1;
                    end if;
                  end if;
                ELSIF cur_order_item.service_offer_id = '101' then
                  --拆机
                  if cert_type in ('1', '2', '3', '4', '12', '14', '22') then
                    mobile_own_count_temp := mobile_own_count_temp - 1;
                  else
                    if cert_type in ('7', '6', '40', '39', '15') then
                      mobile_use_count_temp := mobile_use_count_temp - 1;
                    end if;
                  end if;
                else
                  --使用客户变更
                  if cur.cust_id != owner_cust_id then
                    if cur_cert_type in
                       ('1', '2', '3', '4', '12', '14', '22') and
                       cert_type in ('7', '6', '40', '39', '15') then
                      --1.个人-->政企
                      --判断使用客户客户是否有变更
                      select count(1)
                        into user_cust_num
                        from crmv2.order_item_proc_attr_his oip
                       where oip.order_item_id =
                             cur_order_item.order_item_id
                         and oip.obj_attr_id = 17141;
                      if user_cust_num > 0 then
                        mobile_own_count_temp   := mobile_own_count_temp - 1;
                        mobile_use_count_temp_b := mobile_use_count_temp_b + 1;
                      end if;
                    ELSIF cur_cert_type in
                          ('1', '2', '3', '4', '12', '14', '22') and
                          cert_type in
                          ('1', '2', '3', '4', '12', '14', '22') then
                      --2.a个人-->b个人
                      mobile_own_count_temp   := mobile_own_count_temp - 1;
                      mobile_own_count_temp_b := mobile_own_count_temp_b + 1;
                    ELSIF cur_cert_type in ('7', '6', '40', '39', '15') and
                          cert_type in
                          ('1', '2', '3', '4', '12', '14', '22') then
                      --3.政企-->个人
                      mobile_use_count_temp   := mobile_use_count_temp - 1;
                      mobile_own_count_temp_b := mobile_own_count_temp_b + 1;
                    ELSIF cur_cert_type in ('7', '6', '40', '39', '15') and
                          cert_type in ('7', '6', '40', '39', '15') then
                      --4.a政企-->b政企
                      --判断使用客户客户是否有变更
                      select count(1)
                        into user_cust_num
                        from crmv2.order_item_proc_attr_his oip
                       where oip.order_item_id =
                             cur_order_item.order_item_id
                         and oip.obj_attr_id = 17141;
                      if user_cust_num > 0 then
                        mobile_use_count_temp   := mobile_use_count_temp - 1;
                        mobile_use_count_temp_b := mobile_use_count_temp_b - 1;
                      end if;
                    end if;
                  end if;
                end if;

              end if;
            end if;

            if mobile_use_count_temp != 0 or mobile_own_count_temp != 0 then
              select count(1)
                into cert_mobile_num_temp
                from crmv2.cert_mobile_num c
               where c.cert_number = cur_cert_number;
              if cert_mobile_num_temp > 0 then
                update crmv2.cert_mobile_num c
                   set c.mobile_owner_num     = c.mobile_owner_num +
                                                mobile_own_count_temp,
                       c.mobile_user_num      = c.mobile_user_num +
                                                mobile_use_count_temp,
                       c.mobile_user_num_new  = c.mobile_user_num +
                                                mobile_use_count_temp,
                       c.mobile_owner_num_new = c.mobile_owner_num +
                                                mobile_own_count_temp,
                       c.update_date          = sysdate
                 where c.cert_number = cur_cert_number;
              else
                insert into cert_mobile_num
                  (CERT_MOBILE_NUM_ID,
                   CERT_TYPE,
                   CERT_NUMBER,
                   CUST_NAME,
                   MOBILE_OWNER_NUM,
                   MOBILE_USER_NUM,
                   MOBILE_OWNER_NUM_NEW,
                   MOBILE_USER_NUM_NEW,
                   CREATE_DATE,
                   UPDATE_DATE,
                   STATUS_DATE)
                values
                  (crmv2.seq_CERT_MOBILE_NUM_ID.nextval,
                   cur_cert_type,
                   cur_cert_number,
                   cur_party_name,
                   mobile_own_count_temp,
                   mobile_use_count_temp,
                   mobile_own_count_temp,
                   mobile_use_count_temp,
                   sysdate,
                   sysdate,
                   sysdate);
              end if;
            end if;
            if mobile_use_count_temp_b != 0 or mobile_own_count_temp_b != 0 then
              select count(1)
                into cert_mobile_num_temp
                from crmv2.cert_mobile_num c
               where c.cert_number = cert_number_use;
              --where c.cert_number = '350111195401080636';
              if cert_mobile_num_temp > 0 then
                update crmv2.cert_mobile_num c
                   set c.mobile_owner_num     = c.mobile_owner_num +
                                                mobile_own_count_temp_b,
                       c.mobile_user_num_new  = c.mobile_user_num +
                                                mobile_use_count_temp_b,
                       c.mobile_user_num      = c.mobile_user_num +
                                                mobile_use_count_temp_b,
                       c.mobile_owner_num_new = c.mobile_owner_num +
                                                mobile_own_count_temp_b,
                       c.update_date          = sysdate
                 where c.cert_number = cert_number_use;
              else
                insert into cert_mobile_num
                  (CERT_MOBILE_NUM_ID,
                   CERT_TYPE,
                   CERT_NUMBER,
                   CUST_NAME,
                   MOBILE_OWNER_NUM,
                   MOBILE_USER_NUM,
                   MOBILE_OWNER_NUM_NEW,
                   MOBILE_USER_NUM_NEW,
                   CREATE_DATE,
                   UPDATE_DATE,
                   STATUS_DATE)
                values
                  (crmv2.seq_CERT_MOBILE_NUM_ID.nextval,
                   cert_type,
                   cert_number_use,
                   party_name,
                   mobile_own_count_temp_b,
                   mobile_use_count_temp_b,
                   mobile_own_count_temp_b,
                   mobile_use_count_temp_b,
                   sysdate,
                   sysdate,
                   sysdate);
              end if;
            end if;

          elsif cur_order_item.class_id = 138 then
            select count(1)
              into user_cust_num
              from crmv2.order_item_proc_attr_his oip
             where oip.order_item_id = cur_order_item.order_item_id
               and oip.obj_attr_id = 21016
               and oip.new_value is not null
               and oip.old_value is not null;
            if user_cust_num > 0 then
              select oip.new_value, oip.old_value
                into new_cert_number, old_cert_number
                from crmv2.order_item_proc_attr_his oip
               where oip.order_item_id = cur_order_item.order_item_id
                 and oip.obj_attr_id = 21016
                 and oip.new_value is not null
                 and oip.old_value is not null;
              select count(1)
                into old_num
                from crmv2.cert_mobile_num c
               where c.cert_number = old_cert_number;
              --旧的证件号码下有数量才需要更新
              if old_num > 0 then
                select count(1)
                  into new_num
                  from crmv2.cert_mobile_num c
                 where c.cert_number = new_cert_number;
                select c.mobile_owner_num, c.mobile_user_num
                  into mobile_own_count_temp, mobile_use_count_temp
                  from crmv2.cert_mobile_num c
                 where c.cert_number = old_cert_number;
                if new_num > 0 then
                  update crmv2.cert_mobile_num c
                     set c.mobile_owner_num     = c.mobile_owner_num +
                                                  mobile_own_count_temp,
                         c.mobile_user_num      = c.mobile_user_num +
                                                  mobile_use_count_temp,
                         c.mobile_user_num_new  = c.mobile_user_num +
                                                  mobile_use_count_temp,
                         c.mobile_owner_num_new = c.mobile_owner_num +
                                                  mobile_own_count_temp,
                         c.update_date          = sysdate
                   where c.cert_number = cur_cert_number;
                else
                  select count(1)
                    into party_num_3
                    from crmv2.party_certification pc, crmv2.party p
                   where pc.party_id = p.party_id
                     and pc.cert_number = new_cert_number
                     and p.party_name is not null
                     and pc.cert_type is not null;
                  if party_num_3 > 0 then
                    select pc.cert_type, p.party_name
                      into cert_type, party_name
                      from crmv2.party_certification pc, crmv2.party p
                     where pc.party_id = p.party_id
                       and pc.cert_number = new_cert_number;
                    insert into crmv2.cert_mobile_num
                      (CERT_MOBILE_NUM_ID,
                       CERT_TYPE,
                       CERT_NUMBER,
                       CUST_NAME,
                       MOBILE_OWNER_NUM,
                       MOBILE_USER_NUM,
                       MOBILE_OWNER_NUM_NEW,
                       MOBILE_USER_NUM_NEW,
                       CREATE_DATE,
                       UPDATE_DATE,
                       STATUS_DATE)
                    values
                      (crmv2.seq_CERT_MOBILE_NUM_ID.nextval,
                       cert_type,
                       new_cert_number,
                       party_name,
                       mobile_own_count_temp,
                       mobile_use_count_temp,
                       mobile_own_count_temp,
                       mobile_use_count_temp,
                       sysdate,
                       sysdate,
                       sysdate);
                  end if;
                end if;
                delete from crmv2.cert_mobile_num c
                 where c.cert_number = old_cert_number;
              end if;
            end if;
          end if;

        end loop;
      end if;

      IF MOD(cur.rownum, 5000) = 0 then
        COMMIT;
      END if;
      COMMIT;

    end loop;
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_MSG := SUBSTR(SQLERRM, 1, 1000);
      insert into crmv2.intf_log
        (LOG_ID, CUST_SO_NUMBER, REMARK, DB_INST_ID, MSG_TYPE)
      values
        (crmv2.seq_intf_log_id.nextval,
         cur_cert_number,
         O_ERR_MSG,
         '1',
         'pkgCountNumber2FromOrder');
      COMMIT;
  end PKG_YD_WX;

END PKG_COUNT_NUMBER2_FROM_ORDER;
/
