CREATE PACKAGE           PKG_10000 IS

  -- Author  : wangjianjun
  -- Created : 2012-05-03
  -- Purpose : 10000号接口

  /************************************************************************
    Function    : 查询宽带套餐有效期
    Description ：
    Author　    ：wangjianjun
    Date        : 2012-05-03
    Parameter   :
                  I_ACC_NBR      -- 宽带业务号码，如：454309392
                  I_AREA_CODE    -- 区号，如：0591
                  O_EXP_DATE     -- 到期时间，字符串格式YYYYMMDD
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_KD_INFO(I_ACC_NBR   IN VARCHAR2,
                               I_AREA_CODE IN VARCHAR2,
                               O_EXP_DATE  OUT VARCHAR2,
                               O_ERR_CODE  OUT NUMBER,
                               O_ERR_MSG   OUT VARCHAR2);

  /************************************************************************
    Function    : 查询关联宽带信息
    Description ：根据传入的业务号码、区号、产品规格编码，查询产品做为计费号码关联的有线宽带业务号码和帐号
    Author　    ：wangjianjun
    Date        : 2012-05-03
    Parameter   :
                  I_ACC_NBR       -- 业务号码
                  I_AREA_CODE     -- 区号
                  I_EXT_PROD_ID   -- 转入接入号码对应产品的外部产品规格编码（1.0产品编码）
                  O_PROD_INST_ID  -- 产品实例标识（关联多个时，产品实例标识之间通过','号分隔）
                  O_ACC_NBR       -- 宽带业务号码（关联多个时，业务号码之间通过','号分隔）
                  O_ACCOUNT       -- 宽带帐号（关联多个时，帐号之间通过','号分隔）
                  O_ERR_CODE      -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG       -- 错误信息
    Modification :
                  应10000要求增加输出参数O_PROD_INST_ID --renl 20120621
  ************************************************************************/
  PROCEDURE PROC_QUERY_RELA_KD_INFO(I_ACC_NBR      IN VARCHAR2,
                                    I_AREA_CODE    IN VARCHAR2,
                                    I_EXT_PROD_ID  IN VARCHAR2,
                                    O_PROD_INST_ID OUT VARCHAR2,
                                    O_ACC_NBR      OUT VARCHAR2,
                                    O_ACCOUNT      OUT VARCHAR2,
                                    O_ERR_CODE     OUT NUMBER,
                                    O_ERR_MSG      OUT VARCHAR2);

  /************************************************************************
    Function    : 改号通知接口
    Description ：
    Author　    ：wangjianjun
    Date        : 2012-05-03
    Parameter   :
                  I_ACCOUNT    -- 输入号码
                  O_ACCOUNT    -- 主副卡号码
                  O_ACCTYPE    -- 输入号码类型 1：主卡 2：副卡
                  O_ERR_CODE   -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG    -- 错误信息

  PROCEDURE PROC_GET_NOTICE(I_PROD_OFFER_INST_ID IN NUMBER, --续费对应的销售品实例标识
                               O_ERR_CODE           OUT NUMBER, --错误编码（0--成功 1--失败）
                               O_ERR_MSG            OUT VARCHAR2); --错误信息
  ************************************************************************/

  /************************************************************************
    Function    : 号码信息查询
    Description ：根据号码、区号（可选）、产品规格编码（可选）查询号码的产品规格编码、产品规格名称、区号、业务号码、接入帐号。
    Author　    ：wangjianjun
    Date        : 2012-05-03
    Parameter   :
                  I_ACC_NBR     -- 业务号码
                  I_AREA_CODE   -- 区号（可选）
                  I_EXT_PROD_ID -- 产品规格编码（可选）
                  O_NBR_INFO    -- 号码信息格式：产品编码，产品规格名称，区号，业务号码，接入帐号，是否小灵通超无标识（标识为主、副、非）。当记录有多条时，用‘；’隔开
                  O_ERR_CODE    -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG     -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_NBR_INFO(I_ACC_NBR     IN VARCHAR2,
                                I_AREA_CODE   IN VARCHAR2,
                                I_EXT_PROD_ID IN VARCHAR2,
                                O_NBR_INFO    OUT VARCHAR2,
                                O_ERR_CODE    OUT NUMBER,
                                O_ERR_MSG     OUT VARCHAR2);

  /************************************************************************
  Function    : 订单竣工查询
  Description ：订单是否竣工查询
  Author　    ：wangjianjun
  Date        : 2012-05-03
  Parameter   :
                I_CUST_SO_NUMBER    -- 客户订单流水号
                O_RESULT            -- 0 未竣工; 1 已竣工
                O_ERR_CODE          -- 处理结果（0--成功 1--失败）
                O_ERR_MSG           -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_ORDER_INFO(I_CUST_SO_NUMBER IN VARCHAR2,
                                  O_RESULT         OUT VARCHAR2,
                                  O_ERR_CODE       OUT NUMBER,
                                  O_ERR_MSG        OUT VARCHAR2);

  /************************************************************************
      Function    : 小灵通携号转网查询
      Description ：判断若输入小灵通号码为携号转网的旧号码，返回天翼号码给10000号系统；若不是携号转网的小灵通，则返回号码为空；
      Author　    ：wangjianjun
      Date        : 2012-05-04
      Parameter   :
                    I_ACC_NBR      -- 业务号码
                    I_AREA_CODE    -- 区号
                    O_CDMA_ACC_NBR -- 天翼业务号码
                    O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                    O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_XHZW(I_ACC_NBR      IN VARCHAR2,
                            I_AREA_CODE    IN VARCHAR2,
                            O_CDMA_ACC_NBR OUT VARCHAR2,
                            O_ERR_CODE     OUT NUMBER,
                            O_ERR_MSG      OUT VARCHAR2);

  /************************************************************************
    Function    : 无线宽带关联主副卡查询
    Description ：查询天翼手机是否存在无线宽带主副卡关联或T7加装关系的关联号码，如果有，则返回关联号码，
                  由外围系统发起关联停保复机或关联停机保号
    Author　    ：wangjianjun
    Date        : 2012-05-04
    Parameter   :
                  I_ACC_NBR      -- 业务号码
                  I_AREA_CODE    -- 区号
                  O_ACCTYPE      -- 输入号码类型 1：主卡 2：副卡
                  O_RELA_ACC_NBR -- 输出关联的业务号码
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_DOUBLE_NUMBER(I_ACC_NBR      IN VARCHAR2,
                                     I_AREA_CODE    IN VARCHAR2,
                                     O_ACCTYPE      OUT VARCHAR2,
                                     O_RELA_ACC_NBR OUT VARCHAR2,
                                     O_ERR_CODE     OUT NUMBER,
                                     O_ERR_MSG      OUT VARCHAR2);

  /************************************************************************
    Function    : 档案信息查询
    Description ：根据输入号码查询该业务号码的信息
    Author　    ：wangjianjun
    Date        : 2012-05-04
    Parameter   :
                  IO_ACC_NBR                -- 业务号码
                  I_AREA_CODE               -- 区号
                  I_EXT_PROD_ID             -- 产品规格编码
                  O_CUSTiCUST_NAME          --用户名称
                  O_SERViSTATE              --业务号码状态
                  O_ADDRiWHOLE_ADDR         --用户地址
                  O_CUSTiCUST_KIND_ID       --用户性质
                  O_CUSTiINDUS_CAT_ID       --行业划分
                  O_SERViPROD_ID            --电话类型
                  O_ACCTiACCT_NBR           --合同号
                  O_CUSTiCERT_NBR           --身份证号
                  O_SERViCREA_DATE          --装机时间（yyyymmddhh24miss)
                  O_EXCHiEXCH_CODE          --局向
                  O_SERV_TYPEiSERV_TYPE_ID  --服务类型编码
                  O_SOiAREA_ID              --号码区域信息
                  O_CUSTiCUST_GRADE_ID      --用户等级（重要、不重要）按数据库中值返回
                  O_CUSTiCUST_SORT_ID       --用户大类 按数据库中值返回
                  O_CUSTiSTATE              --是否有绑定宽带（ADSL，LAN）帐号0为没有１表示为有
                  O_CUSTiCUST_CODE          --是否有高级密码  0表示没有  1表示有
                  O_CUSTiVIP                --是否有超级无绳  0表示没有  1表示有
                  O_CUSTiCUST_GH            --是否是公话      0是公话    1不是公话
                  O_CUSTiLTBL               --是否有灵通伴侣标识 0表示没有  1表示有
                  O_FEEiPACKAGE             --资费套餐说明
                  O_PAYiTYPE                --帐户类型
                  O_MAIN_GROUP_ID           --战略分群
                  O_ZJLX                    --证件类型
                  O_DX_STATE
                  O_KH_BRAND_ID
                  O_KH_BRAND
                  O_CUSTTYCW
                  O_ERR_CODE                -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG                 -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_ARCHIVE_INFO(IO_ACC_NBR               IN OUT VARCHAR2, -- 业务号码
                                    I_AREA_CODE              IN VARCHAR2, -- 区号
                                    I_EXT_PROD_ID            IN VARCHAR2, -- 产品规格编码
                                    O_CUSTiCUST_NAME         OUT varchar2, --用户名称
                                    O_SERViSTATE             OUT varchar2, --业务号码状态
                                    O_ADDRiWHOLE_ADDR        OUT varchar2, --用户地址
                                    O_CUSTiCUST_KIND_ID      OUT varchar2, --用户性质
                                    O_CUSTiINDUS_CAT_ID      OUT varchar2, --行业划分
                                    O_SERViPROD_ID           OUT varchar2, --电话类型
                                    O_ACCTiACCT_NBR          OUT varchar2, --合同号
                                    O_CUSTiCERT_NBR          OUT varchar2, --身份证号
                                    O_SERViCREA_DATE         OUT varchar2, --装机时间（yyyymmddhh24miss)
                                    O_EXCHiEXCH_CODE         OUT varchar2, --局向
                                    O_SERV_TYPEiSERV_TYPE_ID OUT varchar2, --服务类型编码
                                    O_SOiAREA_ID             OUT varchar2, --号码区域信息
                                    O_CUSTiCUST_GRADE_ID     OUT varchar2, --用户等级（重要、不重要）按数据库中值返回
                                    O_CUSTiCUST_SORT_ID      OUT varchar2, --用户大类 按数据库中值返回
                                    O_CUSTiSTATE             OUT varchar2, --是否有绑定宽带（ADSL，LAN）帐号0为没有１表示为有
                                    O_CUSTiCUST_CODE         OUT varchar2, --是否有高级密码  0表示没有  1表示有
                                    O_CUSTiVIP               OUT varchar2, --是否有超级无绳  0表示没有  1表示有
                                    O_CUSTiCUST_GH           OUT varchar2, --是否是公话      0是公话    1不是公话
                                    O_CUSTiLTBL              OUT varchar2, --是否有灵通伴侣标识 0表示没有  1表示有
                                    O_FEEiPACKAGE            OUT VARCHAR2, --资费套餐说明
                                    O_PAYiTYPE               OUT VARCHAR2, --帐户类型
                                    O_MAIN_GROUP_ID          OUT VARCHAR2, --战略分群
                                    O_ZJLX                   OUT VARCHAR2, --证件类型
                                    O_DX_STATE               OUT VARCHAR2,
                                    O_KH_BRAND_ID            OUT VARCHAR2,
                                    O_KH_BRAND               OUT VARCHAR2,
                                    O_CUSTTYCW               OUT varchar2,
                                    O_ERR_CODE               OUT NUMBER, -- 处理结果（0--成功 1--失败）
                                    O_ERR_MSG                OUT VARCHAR2 -- 错误信息
                                    );

  /************************************************************************
    Function    : 查询传入号码的家庭短号、户主号码和家庭成员号码
    Description ：以传入的业务号码（可能是家庭短号号码、户主号码或是某个家庭成员的号码）为参数，
                  查询该号码是否加入家庭短号，以及所加入的家庭短号的户主和家庭成员号码
    Author　    ：renli
    Date        : 2012-06-13
    Parameter   :
                  I_AREA_CODE         -- 区号
                  I_ACC_NBR           -- 业务号码
                  I_EXT_PROD_ID       -- 接入类产品外部编码
                  O_ERR_CODE          -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG           -- 错误信息
                  O_HOST_NBR          --户主号码
                  O_HOST_SHORT_NBR    --户主短号
                  O_HOST_STATUS_CD    --户主号码状态
                  O_MEMBER_NBR        --家庭成员号码，多个时用逗号隔开
                  O_MEMBER_SHORT_NBR  --家庭成员短号，多个时用逗号隔开，顺序与号码对应
                  O_MEMBER_STATUS_CD  --家庭成员号码状态，多个时用逗号隔开，顺序与号码对应
                  O_JTDH_NBR          -- 家庭短号本身的号码
  ************************************************************************/
  PROCEDURE PROC_JTDH_MEMBER_QUERY(I_AREA_CODE        IN VARCHAR2, --区号，如：福州0591
                                   I_ACC_NBR          IN VARCHAR2, --接入号码，如：15359121897
                                   I_EXT_PROD_ID      IN VARCHAR2, --接入类产品外部编码，如移动语音：610003886
                                   O_ERR_CODE         OUT NUMBER, --处理结果（0--成功 1--失败）
                                   O_ERR_MSG          OUT VARCHAR2, --错误信息
                                   O_HOST_NBR         OUT VARCHAR2, --户主号码
                                   O_HOST_SHORT_NBR   OUT VARCHAR2, --户主短号
                                   O_HOST_STATUS_CD   OUT VARCHAR2, --户主号码状态
                                   O_MEMBER_NBR       OUT VARCHAR2, --家庭成员号码，多个时用逗号隔开
                                   O_MEMBER_SHORT_NBR OUT VARCHAR2, --家庭成员短号，多个时用逗号隔开，顺序与号码对应
                                   O_MEMBER_STATUS_CD OUT VARCHAR2, --家庭成员号码状态，多个时用逗号隔开，顺序与号码对应
                                   O_JTDH_NBR         OUT VARCHAR2 -- 家庭短号本身的号码
                                   );

  /************************************************************************
    Function    : 查询传入号码是否可受理一键通
    Description ：查询传入号码是否可受理一键通
    Author　    ：renli
    Date        : 2012-06-13
    Parameter   :
                  I_AREA_CODE    -- 区号
                  I_ACC_NBR      -- 业务号码
                  I_EXT_PROD_ID  -- 接入类产品外部编码
                  I_TYPE         -- 查询类型
                                 1为一键通判断，
                                 2为亲情短号判断，
                                 3 e家成员判断，
                                 4当前号码所在的E家是否有开通亲情短号功能
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
                  O_RESULT       -- 结果信息：是否是(一键通、 亲情短号、e家成员)用户 0：不是；1：是
  ************************************************************************/
  PROCEDURE PROC_QUERY_IS_YJT(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                              I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                              I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                              I_TYPE        IN VARCHAR2, --1为一键通判断，2为亲情短号判断，3 e家成员判断，4当前号码所在的E家是否有开通亲情短号功能
                              O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                              O_ERR_MSG     OUT VARCHAR2, --错误信息
                              O_RESULT      OUT VARCHAR2 --结果信息，是否是(一键通、 亲情短号、e家成员)用户 0：不是；1：是
                              );
 /* 亲情网查询 */
  PROCEDURE PROC_QUERY_OFFER_REL_INFO(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR     IN VARCHAR2, --业务号码
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_ZHU_HAO   OUT VARCHAR2, --主号
                                 O_ZHU_HAO_AREA  OUT VARCHAR2, --主号区域
                                 O_FU_HAO OUT VARCHAR2,
                                 O_FU_HAO_AREA OUT VARCHAR2
                                 );
END PKG_10000;
/
