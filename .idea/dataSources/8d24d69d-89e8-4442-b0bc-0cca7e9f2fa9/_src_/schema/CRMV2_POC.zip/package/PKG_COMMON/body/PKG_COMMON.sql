CREATE PACKAGE BODY           PKG_COMMON IS
  /*查询客户下在用的邮箱地址。*/
  PROCEDURE PROC_QUERY_MAIL_ADDR(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_RESULT      OUT VARCHAR2 --结果信息（成功时返回邮箱地址，失败时为空）
                                 ) IS
    --变量定义
    V_SEP VARCHAR2(2); --分隔符
    --过程主体
  BEGIN
    --变量初始化
    V_SEP      := ',';
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';
    O_RESULT   := '';
    /*
    1、根据客户标识查询客户在用的邮箱地址。
    若存在记录，返回成功编码0，并循环将邮箱地址拼接成以逗号隔开的字符串并返回；
    若记录不存在，返回失败编码1，并返回空字符串；
    */
    BEGIN
      FOR REC IN (SELECT DISTINCT CM.MAIL_ADDR
                    FROM PRODUCT P, PROD_INST PI, CUST_MAIL CM
                   WHERE 1 = 1
                     AND P.PRODUCT_ID = PI.PRODUCT_ID
                     AND PI.OWNER_CUST_ID = CM.CUST_ID
                     AND PI.AREA_CODE = I_AREA_CODE
                     AND PI.ACC_NBR = I_ACC_NBR
                     AND P.EXT_PROD_ID = I_EXT_PROD_ID) LOOP
        O_RESULT := O_RESULT || REC.MAIL_ADDR || V_SEP;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
    END;
    IF O_RESULT IS NULL THEN
      O_ERR_CODE := 1;
    END IF;

  END PROC_QUERY_MAIL_ADDR;

  /*绑定或取消客户下在用的邮箱地址。*/
  PROCEDURE PROC_HANDLE_MAIL_ADDR(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                  I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                  I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                  I_MAIL_ADDR   IN VARCHAR2, --邮箱地址，如13305027420@189.cn
                                  I_USE_TYPE    IN VARCHAR2, --邮箱用途，如：账单推送、广告推送
                                  I_SOURCE      IN VARCHAR2, --来源，如网厅、掌厅、短厅等
                                  I_ACTION      IN VARCHAR2, --动作，A：绑定，R：取消
                                  O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                  O_ERR_MSG     OUT VARCHAR2 --错误信息
                                  ) IS
    --变量定义
    V_CUST_MAIL_ID CUST_MAIL.CUST_MAIL_ID%TYPE;
    V_CUST_ID      CUST_MAIL.CUST_ID%TYPE;
    V_USE_TYPE     CUST_MAIL.USE_TYPE%TYPE;
    --过程主体
  BEGIN
    --变量初始化
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    /*
    1、查询客户标识是否存在，不存在时返回失败
    */
    BEGIN
      SELECT DISTINCT PI.OWNER_CUST_ID
        INTO V_CUST_ID
        FROM PRODUCT P, PROD_INST PI
       WHERE 1 = 1
         AND P.PRODUCT_ID = PI.PRODUCT_ID
         AND PI.AREA_CODE = I_AREA_CODE
         AND PI.ACC_NBR = I_ACC_NBR
         AND P.EXT_PROD_ID = I_EXT_PROD_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          O_ERR_CODE := 1;
          RETURN;
        END;
    END;
    /* 设置邮箱用途的默认值 */
    IF I_USE_TYPE IS NULL THEN
      V_USE_TYPE := '账单推送';
    ELSE
      V_USE_TYPE := I_USE_TYPE;
    END IF;
    /* 2、当动作为A时执行插入动作 */
    IF I_ACTION = 'A' THEN
      SELECT SEQ_CUST_MAIL_ID.NEXTVAL INTO V_CUST_MAIL_ID FROM DUAL;
      INSERT INTO CUST_MAIL
        (CUST_MAIL_ID,
         CUST_ID,
         ADDR_SERIAL,
         MAIL_ADDR,
         SOURCE,
         USE_TYPE,
         AREA_ID,
         REGION_CD,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         CREATE_STAFF,
         UPDATE_DATE,
         UPDATE_STAFF)
      VALUES
        (V_CUST_MAIL_ID,
         V_CUST_ID,
         '',
         I_MAIL_ADDR,
         I_SOURCE,
         V_USE_TYPE,
         '',
         '',
         '',
         SYSDATE,
         SYSDATE,
         '',
         SYSDATE,
         '');
      COMMIT;
    END IF;
    /* 3、当动作为R时，执行删除动作 */
    IF I_ACTION = 'R' THEN
      DELETE FROM CUST_MAIL
       WHERE 1 = 1
         AND CUST_ID = V_CUST_ID
         AND MAIL_ADDR = I_MAIL_ADDR;
      COMMIT;
    END IF;
  END PROC_HANDLE_MAIL_ADDR;

  /************************************************************************
    Function    : 无线宽带关联主副卡查询
    Description ：以传入的接入号码为主卡（或副卡）查询关联的副卡（或主卡）
    Author　    ：wangjianjun
    Date        : 2012-05-04
    Parameter   :
                  I_ACC_NBR      -- 业务号码
                  I_AREA_CODE    -- 区号
                  O_ACCTYPE      -- 输入号码类型 1：主卡 2：副卡
                  O_RELA_ACC_NBR -- 输出关联的业务号码
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_DOUBLE_NUMBER(I_ACC_NBR      IN VARCHAR2,
                                     I_AREA_CODE    IN VARCHAR2,
                                     O_ACCTYPE      OUT VARCHAR2,
                                     O_RELA_ACC_NBR OUT VARCHAR2,
                                     O_ERR_CODE     OUT NUMBER,
                                     O_ERR_MSG      OUT VARCHAR2) IS
    --变量定义
    V_IN_PROD_INST_ID  PROD_INST.PROD_INST_ID%TYPE;
    V_FUN_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
    V_MAN_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
  BEGIN
    --变量初始化
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    BEGIN
      -- 通过业务号码和区号查询传入的接入类产品实例ID
      SELECT PI.PROD_INST_ID
        INTO V_IN_PROD_INST_ID
        FROM PROD_INST PI
       WHERE PI.ACC_NBR = I_ACC_NBR
         AND PI.AREA_CODE = I_AREA_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '通过业务号码与区号未找到对应产品实例';
        RETURN;
    END;
    BEGIN
      -- 通过传入的产品实例ID查询Z端一卡双芯实例ID
      SELECT PIR.PROD_INST_Z_ID
        INTO V_FUN_PROD_INST_ID
        FROM PRODUCT_RELATION PR, PROD_INST_REL PIR
       WHERE PR.PRODUCT_REL_ID = PIR.PRODUCT_REL_ID
         AND PIR.PROD_INST_A_ID = V_IN_PROD_INST_ID
         AND PR.PRODUCT_Z_ID = 800551826
         AND PR.RELATION_TYPE_CD = '100600';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '数据异常，通过业务号码与区号未找到一卡双芯功能产品';
        RETURN;
    END;
    BEGIN
      -- 通过一卡双芯实例ID查询非转入的A端产品实例信息
      SELECT PI.ACC_NBR
        INTO O_RELA_ACC_NBR
        FROM PRODUCT_RELATION PR, PROD_INST_REL PIR, PROD_INST PI
       WHERE PR.PRODUCT_REL_ID = PIR.PRODUCT_REL_ID
         AND PIR.PROD_INST_A_ID = PI.PROD_INST_ID
         AND PIR.PROD_INST_Z_ID = V_FUN_PROD_INST_ID
         AND PIR.PROD_INST_A_ID <> V_IN_PROD_INST_ID
         AND PR.PRODUCT_Z_ID = 800551826
         AND PR.RELATION_TYPE_CD = '100600';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '数据异常，一卡双芯未关联另一端产品';
        RETURN;
    END;
    BEGIN
      -- 查询一卡双芯实例的主号码ID属性值
      SELECT PIA.ATTR_VALUE
        INTO V_MAN_PROD_INST_ID
        FROM PROD_INST_ATTR PIA
       WHERE PIA.PROD_INST_ID = V_FUN_PROD_INST_ID
         AND PIA.ATTR_ID = 800004083;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '数据异常，一卡双芯实例为设置主号码ID属性值';
        RETURN;
    END;
    IF V_MAN_PROD_INST_ID = V_IN_PROD_INST_ID THEN
      O_ACCTYPE := '1';
    ELSE
      O_ACCTYPE := '2';
    END IF;
  END PROC_QUERY_DOUBLE_NUMBER;

  /*-------------------------------------------------
  查询产品信息(宽带, 移动语音)

  Author  : g.caijx
  Created : 2012-05-28
  -------------------------------------------------*/
  PROCEDURE PROC_QUERY_PROD_INFO(I_TYPE           IN NUMBER, --1: CDMA; 2: 宽带
                                 I_SERVICE_NUMBER IN VARCHAR2, --CDMD: 18999034567; 宽带帐号: 480112717@fzlan
                                 I_AREA_CODE      IN VARCHAR2, --区号
                                 O_ACC_NBR        OUT VARCHAR2, --业务号码
                                 O_EXT_PROD_ID    OUT VARCHAR2, --产品规格id
                                 O_IS_STOP        OUT NUMBER, --CDMA或宽带是否停机. 0:是; 1: 不是
                                 O_IS_GMGN        OUT NUMBER, --CDMA或宽带是否公免公纳. 0:是; 1: 不是
                                 O_IS_E_HOME      OUT NUMBER, --CDMA或宽带是否是加入e8, e9. 0:是; 1: 不是
                                 O_FLAG           OUT NUMBER, --是否已经受理过在线电脑医生程控. 0:是; 1: 不是
                                 O_TC_FLAG        OUT NUMBER, --是否已经受理过电脑医生功能费(包年-套餐). 0:未受理; 1: 已受理
                                 O_E_HOME_NAME    OUT VARCHAR2, --e家套餐名
                                 O_SWLH_NAME      OUT VARCHAR2, --商务领航套餐名
                                 O_SERVICE_CODE   OUT VARCHAR2, --e家中的宽带帐号
                                 O_SERVICE_NUMBER OUT VARCHAR2, --e家中的手机号码
                                 O_ERR_CODE       OUT NUMBER, -- 处理结果（0--成功 1--失败）
                                 O_ERR_MSG        OUT VARCHAR2 -- 错误信息
                                 ) IS
    V_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
    V_COUNT        NUMBER;
  BEGIN
    O_ERR_CODE := 1;

    IF (I_TYPE IS NULL) OR (I_SERVICE_NUMBER IS NULL) OR
       (I_AREA_CODE IS NULL) THEN
      O_ERR_MSG := '入参不能为空';
      RETURN;
    END IF;

    BEGIN
      IF I_TYPE = 1 THEN
        SELECT PI.PROD_INST_ID
          INTO V_PROD_INST_ID
          FROM PROD_INST PI
         WHERE PI.ACC_NBR = I_SERVICE_NUMBER
           AND PI.AREA_CODE = I_AREA_CODE
           AND PI.PRODUCT_ID = 800000002
           AND ROWNUM < 2;
      ELSIF I_TYPE = 2 THEN
        SELECT PI.PROD_INST_ID
          INTO V_PROD_INST_ID
          FROM PROD_INST PI
         WHERE PI.ACCOUNT = I_SERVICE_NUMBER
           AND PI.AREA_CODE = I_AREA_CODE
           AND PI.PRODUCT_ID NOT IN (800000002, 800000000)
           AND ROWNUM < 2;
      ELSE
        O_ERR_MSG := 'TYPE参数不合法';
        RETURN;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_MSG := '查不到档案';
        RETURN;
    END;

    SELECT PI.ACC_NBR, P.EXT_PROD_ID, DECODE(PI.STATUS_CD, '120000', 0, 1) --120000: 停机
      INTO O_ACC_NBR, O_EXT_PROD_ID, O_IS_STOP
      FROM PROD_INST PI
      JOIN PRODUCT P ON P.PRODUCT_ID = PI.PRODUCT_ID
     WHERE PI.PROD_INST_ID = V_PROD_INST_ID;

    --CDMA或宽带是否公免公纳
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PROD_INST_ACCT A
     WHERE A.PROD_INST_ID = V_PROD_INST_ID
       AND A.CHARGE_TYPE IN (SELECT V.ATTR_VALUE
                               FROM ATTR_VALUE V
                              WHERE V.ATTR_ID = 800001808 --800001808: ProdInstAcct.chargeType
                                AND V.ATTR_VALUE_TYPE = 3) --3: 公免
       AND ROWNUM < 2;
    IF V_COUNT > 0 THEN
      O_IS_GMGN := 0;
    ELSE
      O_IS_GMGN := 1;
    END IF;

    --判断有加入e家
    O_IS_E_HOME := 1;
    FOR V_REC IN (SELECT D.PROD_OFFER_NAME
                    FROM PROD_INST           A,
                         OFFER_PROD_INST_REL B,
                         PROD_OFFER_INST     C,
                         PROD_OFFER          D
                   WHERE A.PROD_INST_ID = B.PROD_INST_ID
                     AND B.PROD_OFFER_INST_ID = C.PROD_OFFER_INST_ID
                     AND C.PROD_OFFER_ID = D.PROD_OFFER_ID
                     AND D.OFFER_TYPE = '11'
                     AND EXISTS
                   (SELECT *
                            FROM OFFER_PROD_INST_REL
                           WHERE ROLE_CD IN (1, 2, 3, 2187)
                             AND PROD_OFFER_INST_ID = C.PROD_OFFER_INST_ID)
                     AND A.PROD_INST_ID = V_PROD_INST_ID) LOOP
      O_IS_E_HOME   := 0;
      O_E_HOME_NAME := O_E_HOME_NAME || V_REC.PROD_OFFER_NAME || ',';
    END LOOP;

    --判断有加入商务领航
    BEGIN
      SELECT PO.PROD_OFFER_NAME
        INTO O_SWLH_NAME
        FROM OFFER_PROD_INST_REL R
        JOIN PROD_OFFER_INST POI ON POI.PROD_OFFER_INST_ID =
                                    R.PROD_OFFER_INST_ID
        JOIN PROD_OFFER PO ON PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
       WHERE R.PROD_INST_ID = V_PROD_INST_ID
         AND REGEXP_LIKE(PO.PROD_OFFER_NAME, '商务领航')
         AND ROWNUM < 2;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    IF I_TYPE = 2 THEN
      --移动语音
      BEGIN
        SELECT F.ACC_NBR
          INTO O_SERVICE_NUMBER
          FROM PROD_INST           A,
               OFFER_PROD_INST_REL B,
               PROD_OFFER_INST     C,
               PROD_OFFER          D,
               OFFER_PROD_INST_REL E,
               PROD_INST           F
         WHERE A.PROD_INST_ID = B.PROD_INST_ID
           AND B.PROD_OFFER_INST_ID = C.PROD_OFFER_INST_ID
           AND C.PROD_OFFER_ID = D.PROD_OFFER_ID
           AND D.OFFER_TYPE = '11'
           AND C.PROD_OFFER_INST_ID = E.PROD_OFFER_INST_ID
           AND E.ROLE_CD = 2
           AND E.PROD_INST_ID = F.PROD_INST_ID
           AND A.PROD_INST_ID = V_PROD_INST_ID;
      EXCEPTION
        WHEN OTHERS THEN
          O_SERVICE_NUMBER := '';
      END;
    ELSE
      --宽带帐号
      BEGIN
        SELECT F.ACCOUNT
          INTO O_SERVICE_CODE
          FROM PROD_INST           A,
               OFFER_PROD_INST_REL B,
               PROD_OFFER_INST     C,
               PROD_OFFER          D,
               OFFER_PROD_INST_REL E,
               PROD_INST           F
         WHERE A.PROD_INST_ID = B.PROD_INST_ID
           AND B.PROD_OFFER_INST_ID = C.PROD_OFFER_INST_ID
           AND C.PROD_OFFER_ID = D.PROD_OFFER_ID
           AND D.OFFER_TYPE = '11'
           AND C.PROD_OFFER_INST_ID = E.PROD_OFFER_INST_ID
           AND E.ROLE_CD = 3
           AND E.PROD_INST_ID = F.PROD_INST_ID
           AND A.PROD_INST_ID = V_PROD_INST_ID;
      EXCEPTION
        WHEN OTHERS THEN
          O_SERVICE_CODE := '';
      END;
    END IF;

    /*   --查询产品实例对应的销售品
    BEGIN
      SELECT PO.PROD_OFFER_NAME, POI.PROD_OFFER_INST_ID
        INTO V_PROD_OFFER_NAME, V_E_HOME_PROD_OFFER_INST_ID
        FROM OFFER_PROD_INST_REL R
        JOIN PROD_OFFER_INST POI ON POI.PROD_OFFER_INST_ID =
                                    R.PROD_OFFER_INST_ID
        JOIN PROD_OFFER PO ON PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
       WHERE R.PROD_INST_ID = V_PROD_INST_ID
         AND (REGEXP_LIKE(PO.PROD_OFFER_NAME, 'e[89]', 'i') OR REGEXP_LIKE(PO.PROD_OFFER_NAME, '商务领航'))
         AND ROWNUM < 2;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    IF REGEXP_LIKE(V_PROD_OFFER_NAME, 'e[89]', 'i') THEN
      --说明有加入e家
      O_IS_E_HOME   := 0;
      O_E_HOME_NAME := V_PROD_OFFER_NAME;
      --这个for最多只会循环一次
      FOR V_REC IN (SELECT A.ATTR_ID, PI.ACC_NBR, PI.ACCOUNT
                      FROM OFFER_PROD_INST_REL R
                      JOIN PROD_INST PI ON R.PROD_INST_ID = PI.PROD_INST_ID
                      JOIN PROD_INST_ATTR A ON A.PROD_INST_ID =
                                               PI.PROD_INST_ID
                     WHERE R.PROD_OFFER_INST_ID =
                           V_E_HOME_PROD_OFFER_INST_ID
                       AND A.ATTR_ID =
                           DECODE(I_TYPE, 1, 800014006, 2, 800013279) --800013279: 是否天翼; 800014006: 是否有线宽带
                       AND ROWNUM < 2) LOOP
        IF I_TYPE = 1 THEN
          O_SERVICE_NUMBER := V_REC.ACC_NBR;
        ELSIF I_TYPE = 2 THEN
          O_SERVICE_CODE := V_REC.ACCOUNT;
        END IF;
      END LOOP;
    ELSE
      O_IS_E_HOME := 1;
      IF REGEXP_LIKE(V_PROD_OFFER_NAME, '商务领航') THEN
        O_SWLH_NAME := O_E_HOME_NAME;
      END IF;
    END IF;*/

    --是否已经受理过在线电脑医生程控
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PROD_INST_REL A, PROD_INST B
     WHERE A.PROD_INST_Z_ID = B.PROD_INST_ID
       AND A.PROD_INST_A_ID = V_PROD_INST_ID
       AND B.PRODUCT_ID = '800303527'; --800303527: 在线电脑医生
    IF V_COUNT > 0 THEN
      O_FLAG := 1;
    ELSE
      O_FLAG := 0;
    END IF;

    --是否已经受理过电脑医生功能费(包年-套餐)
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PROD_INST_REL       A,
           PROD_INST           B,
           OFFER_PROD_INST_REL C,
           PROD_OFFER_INST     D
     WHERE A.PROD_INST_Z_ID = B.PROD_INST_ID
       AND B.PROD_INST_ID = C.PROD_INST_ID
       AND C.PROD_OFFER_INST_ID = D.PROD_OFFER_INST_ID
       AND A.PROD_INST_A_ID = V_PROD_INST_ID
       AND D.PROD_OFFER_ID = 800007169; --800007169: 电脑医生功能费（包年-套餐）
    IF V_COUNT > 0 THEN
      O_TC_FLAG := 1;
    ELSE
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST           A,
             OFFER_PROD_INST_REL B,
             PROD_OFFER_INST_REL C,
             PROD_OFFER_INST     D
       WHERE A.PROD_INST_ID = B.PROD_INST_ID
         AND B.PROD_OFFER_INST_ID = C.RELA_PROD_OFFER_INST_ID
         AND C.RELATED_PROD_OFFER_INST_ID = D.PROD_OFFER_INST_ID
         AND A.PROD_INST_ID = V_PROD_INST_ID
         AND D.PROD_OFFER_ID = 800007169; --800007169: 电脑医生功能费（包年-套餐）
      IF V_COUNT > 0 THEN
        O_TC_FLAG := 1;
      ELSE
        O_TC_FLAG := 0;
      END IF;
    END IF;

    O_ERR_CODE := 0;
  END;

  PROCEDURE PROC_QUERY_QQDH_MEMBER(I_AREA_CODE        IN VARCHAR2, --区域，如：福州0591
                                   I_ACC_NBR          IN VARCHAR2, --接入号码，如：15359121897
                                   I_EXT_PROD_ID      IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                   O_ERR_CODE         OUT NUMBER, --错误编码（0--成功 1--失败）
                                   O_ERR_MSG          OUT VARCHAR2, --错误信息
                                   O_HOST_NBR         OUT VARCHAR2, --户主号码
                                   O_HOST_SHORT_NBR   OUT VARCHAR2, --户主短号
                                   O_HOST_STATUS_CD   OUT VARCHAR2, --户主号码状态
                                   O_MEMBER_NBR       OUT VARCHAR2, --家庭成员号码，多个时用逗号隔开
                                   O_MEMBER_SHORT_NBR OUT VARCHAR2, --家庭成员短号，多个时用逗号隔开，顺序与号码对应
                                   O_MEMBER_STATUS_CD OUT VARCHAR2, --家庭成员号码状态，多个时用逗号隔开，顺序与号码对应
                                   O_JTDH_NBR         OUT VARCHAR2 -- 家庭短号本身的号码
                                   ) IS
    --变量定义
    V_SEP              VARCHAR(2);
    V_PROD_INST_ID_TMP PROD_INST.PROD_INST_ID%TYPE;
    V_PROD_INST_ID     PROD_INST.PROD_INST_ID%TYPE;
    --过程主体
  BEGIN
    --变量初始化
    V_SEP      := ',';
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    BEGIN

      --1先判断产品实例是否有效存在
      BEGIN
        SELECT PI.PROD_INST_ID
          INTO V_PROD_INST_ID_TMP
          FROM PRODUCT P, PROD_INST PI
         WHERE 1 = 1
           AND P.PRODUCT_ID = PI.PRODUCT_ID
           AND PI.AREA_CODE = I_AREA_CODE
           AND PI.ACC_NBR = I_ACC_NBR
           AND P.EXT_PROD_ID = I_EXT_PROD_ID
           AND PI.STATUS_CD = '100000';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          O_ERR_CODE := 1;
          O_ERR_MSG  := '无效号码';
          RETURN;
      END;

      --2查询家庭短号接入类产品实例
      IF I_EXT_PROD_ID = '610007885' THEN
        SELECT PI.PROD_INST_ID, PI.ACC_NBR
          INTO V_PROD_INST_ID, O_JTDH_NBR
          FROM PROD_INST PI
         WHERE 1 = 1
           AND PI.PROD_INST_ID = V_PROD_INST_ID_TMP;
      ELSE
        SELECT PI_A.PROD_INST_ID, PI_A.ACC_NBR
          INTO V_PROD_INST_ID, O_JTDH_NBR
          FROM PRODUCT P_A, PROD_INST PI_A, PROD_INST_REL PIR
         WHERE 1 = 1
           AND P_A.PRODUCT_ID = PI_A.PRODUCT_ID
           AND PI_A.PROD_INST_ID = PIR.PROD_INST_A_ID
           AND PIR.PROD_INST_Z_ID = V_PROD_INST_ID_TMP
           AND P_A.EXT_PROD_ID = '610007885'
           AND PIR.RELATION_TYPE_CD = '100300'
           AND PI_A.STATUS_CD = '100000'
           AND (PIR.ROLE_CD = '829' OR PIR.ROLE_CD = '830');
      END IF;

      --3查询户主号码、短号及状态
      SELECT PI_Z.ACC_NBR, PIA_Z.ATTR_VALUE, PI_Z.STATUS_CD
        INTO O_HOST_NBR, O_HOST_SHORT_NBR, O_HOST_STATUS_CD
        FROM PROD_INST_REL  PIR,
             PROD_INST      PI_Z,
             PRODUCT        P_Z,
             PROD_INST_ATTR PIA_Z,
             ATTR_SPEC      AS_
       WHERE 1 = 1
         AND PIR.PROD_INST_Z_ID = PI_Z.PROD_INST_ID
         AND PI_Z.PRODUCT_ID = P_Z.PRODUCT_ID
         AND PI_Z.PROD_INST_ID = PIA_Z.PROD_INST_ID
         AND PIR.PROD_INST_A_ID = V_PROD_INST_ID
         AND PIA_Z.ATTR_ID = AS_.ATTR_ID
         AND AS_.EXT_ATTR_NBR = '590013626'
         AND PIR.RELATION_TYPE_CD = '100300' --关系CD
         AND PIR.ROLE_CD = '829'; --户主角色

      --4查询家庭成员的号码、短号和状态
      O_MEMBER_NBR       := '';
      O_MEMBER_SHORT_NBR := '';
      O_MEMBER_STATUS_CD := '';

      FOR REC IN (SELECT PI_Z.ACC_NBR, PIA_Z.ATTR_VALUE, PI_Z.STATUS_CD
                    FROM PROD_INST_REL  PIR,
                         PROD_INST      PI_Z,
                         PRODUCT        P_Z,
                         PROD_INST_ATTR PIA_Z,
                         ATTR_SPEC      AS_
                   WHERE 1 = 1
                     AND PIR.PROD_INST_Z_ID = PI_Z.PROD_INST_ID
                     AND PI_Z.PRODUCT_ID = P_Z.PRODUCT_ID
                     AND PI_Z.PROD_INST_ID = PIA_Z.PROD_INST_ID
                     AND PIR.PROD_INST_A_ID = V_PROD_INST_ID
                     AND PIA_Z.ATTR_ID = AS_.ATTR_ID
                     AND AS_.EXT_ATTR_NBR = '590013626'
                     AND PIR.RELATION_TYPE_CD = '100300' --关系CD
                     AND PIR.ROLE_CD = '830' --家庭成员角色
                  ) LOOP

        O_MEMBER_NBR       := O_MEMBER_NBR || REC.ACC_NBR || V_SEP;
        O_MEMBER_SHORT_NBR := O_MEMBER_SHORT_NBR || REC.ATTR_VALUE || V_SEP;
        O_MEMBER_STATUS_CD := O_MEMBER_STATUS_CD || REC.STATUS_CD || V_SEP;

      END LOOP;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
    END;

  END PROC_QUERY_QQDH_MEMBER;

  /*查询号码是否可受理一键通*/
  PROCEDURE PROC_QUERY_IS_ENABLE_YJT(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                     I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                     I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                     O_ERR_CODE    OUT NUMBER, --错误编码（0--成功(允许受理） 1--失败）
                                     O_ERR_MSG     OUT VARCHAR2, --错误信息
                                     O_RESULT      OUT VARCHAR2 --结果信息
                                     ) IS
    --变量定义
    V_PROD_INST_ID    PROD_INST.PROD_INST_ID%TYPE;
    V_PAYMENT_MODE_CD PROD_INST.PAYMENT_MODE_CD%TYPE;
    V_EXT_PROD_ID     PRODUCT.EXT_PROD_ID%TYPE;
    V_EXT_OFFER_NBR   PROD_OFFER.EXT_OFFER_NBR%TYPE;
    V_PROD_OFFER_NAME PROD_OFFER.PROD_OFFER_NAME%TYPE;
    V_RELATION_NUM    NUMBER;
    --过程主体
  BEGIN
    --变量初始化
    O_ERR_CODE        := 0;
    O_ERR_MSG         := '';
    O_RESULT          := '';
    V_PAYMENT_MODE_CD := '';
    V_EXT_PROD_ID     := '';
    V_EXT_OFFER_NBR   := '';
    V_PROD_OFFER_NAME := '';

    BEGIN
      --1.0判断产品实例是否有效存在
      BEGIN
        IF I_EXT_PROD_ID IS NULL THEN
          SELECT DISTINCT PI.PROD_INST_ID
            INTO V_PROD_INST_ID
            FROM PROD_INST PI
           WHERE 1 = 1
             AND PI.AREA_CODE = I_AREA_CODE
             AND PI.ACC_NBR = I_ACC_NBR
             AND PI.STATUS_CD = '100000';
        ELSE
          SELECT PI.PROD_INST_ID
            INTO V_PROD_INST_ID
            FROM PRODUCT P, PROD_INST PI
           WHERE 1 = 1
             AND P.PRODUCT_ID = PI.PRODUCT_ID
             AND PI.AREA_CODE = I_AREA_CODE
             AND PI.ACC_NBR = I_ACC_NBR
             AND P.EXT_PROD_ID = I_EXT_PROD_ID
             AND PI.STATUS_CD = '100000';
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          O_ERR_CODE := 1;
          O_ERR_MSG  := '无效号码';
          RETURN;
      END;

      --1当产品规格为“移动语音”时
      IF I_EXT_PROD_ID = '610003886' THEN
        --1.1判断产品实例的付费模式
        SELECT PI.PAYMENT_MODE_CD
          INTO V_PAYMENT_MODE_CD
          FROM PROD_INST PI
         WHERE 1 = 1
           AND PI.PROD_INST_ID = V_PROD_INST_ID;
        --若为‘预付费（OCS）’，不允许受理一键通功能；
        IF V_PAYMENT_MODE_CD = '2100' THEN
          O_ERR_CODE := 1;
          O_ERR_MSG  := '预付费（OCS）用户';
          RETURN;
        END IF;

        --1.2判断Z端产品实例规格及关系
        SELECT COUNT(*)
          INTO V_RELATION_NUM
          FROM PROD_INST_REL PIR, PROD_INST PI_A, PRODUCT P_A
         WHERE 1 = 1
           AND PIR.PROD_INST_Z_ID = V_PROD_INST_ID
           AND PIR.PROD_INST_A_ID = PI_A.PROD_INST_ID
           AND PI_A.PRODUCT_ID = P_A.PRODUCT_ID
           AND PIR.RELATION_TYPE_CD = '109920'
           AND P_A.EXT_PROD_ID = '610007185';
        IF V_RELATION_NUM > 0 THEN
          O_ERR_CODE := 1;
          O_ERR_MSG  := '一卡双号用户';
          RETURN;
        END IF;

        --1.3判断A端产品实例的主套餐规格
        FOR REC IN (SELECT PO.EXT_OFFER_NBR, PO.PROD_OFFER_NAME
                    --into V_EXT_OFFER_NBR, V_PROD_OFFER_NAME
                      FROM PRODUCT             P_A,
                           PROD_INST           PI_A,
                           PROD_INST_REL       PIR,
                           OFFER_PROD_INST_REL OPIR,
                           PROD_OFFER_INST     POI,
                           PROD_OFFER          PO
                     WHERE 1 = 1
                       AND PIR.PROD_INST_Z_ID = V_PROD_INST_ID
                       AND PIR.PROD_INST_A_ID = PI_A.PROD_INST_ID
                       AND P_A.PRODUCT_ID = PI_A.PRODUCT_ID
                       AND PI_A.PROD_INST_ID = OPIR.PROD_INST_ID
                       AND OPIR.PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
                       AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
                       AND PO.OFFER_TYPE IN ('10', '11') --销售品类型：基础销售品,套餐销售品
                       AND PO.OFFER_SUB_TYPE = 'T01' --销售品子类型：接入类销售品
                       AND POI.STATUS_CD = '1000' --状态编码：在用
                       AND SYSDATE BETWEEN POI.EFF_DATE AND POI.EXP_DATE --当前时间在生失效时间区间内
                    ) LOOP
          V_EXT_OFFER_NBR   := REC.EXT_OFFER_NBR;
          V_PROD_OFFER_NAME := REC.PROD_OFFER_NAME;
          --若为‘集团综合VPN’，不允许受理一键通功能；
          IF V_EXT_OFFER_NBR = '800001646' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘军翼网’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001270' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
          END IF;
        END LOOP;

        --2当产品规格为“普通电话”时
      ELSIF I_EXT_PROD_ID = '594000276' THEN
        --2.1判断产品实例的主套餐规格
        FOR REC IN (SELECT PO.EXT_OFFER_NBR, PO.PROD_OFFER_NAME
                    --into V_EXT_OFFER_NBR, V_PROD_OFFER_NAME
                      FROM PRODUCT             P_A,
                           PROD_INST           PI_A,
                           PROD_INST_REL       PIR,
                           OFFER_PROD_INST_REL OPIR,
                           PROD_OFFER_INST     POI,
                           PROD_OFFER          PO
                     WHERE 1 = 1
                       AND PIR.PROD_INST_Z_ID = V_PROD_INST_ID
                       AND PIR.PROD_INST_A_ID = PI_A.PROD_INST_ID
                       AND P_A.PRODUCT_ID = PI_A.PRODUCT_ID
                       AND PI_A.PROD_INST_ID = OPIR.PROD_INST_ID
                       AND OPIR.PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
                       AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
                       AND PO.OFFER_TYPE IN ('10', '11') --销售品类型：基础销售品,套餐销售品
                       AND PO.OFFER_SUB_TYPE = 'T01' --销售品子类型：接入类销售品
                       AND POI.STATUS_CD = '1000' --状态编码：在用
                       AND SYSDATE BETWEEN POI.EFF_DATE AND POI.EXP_DATE --当前时间在生失效时间区间内
                    ) LOOP
          V_EXT_OFFER_NBR   := REC.EXT_OFFER_NBR;
          V_PROD_OFFER_NAME := REC.PROD_OFFER_NAME;
          --若为‘企业总机V3.0通用版’，不允许受理一键通功能；
          IF V_EXT_OFFER_NBR = '800001254' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘企业总机V3.0选号版’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001495' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘协同通信-固网虚号码’，不允许受理一键通功能；
            /*
            ELSIF V_EXT_OFFER_NBR = '800001184' THEN
              O_ERR_CODE := 1;
              O_ERR_MSG  := V_PROD_OFFER_NAME;
              O_RESULT   := V_EXT_OFFER_NBR;
              RETURN;
              */
            --若为‘功能型虚拟网’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001875' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘集团综合VPN’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001646' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘综合虚拟网（综合VPN）’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001876' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
          END IF;
        END LOOP;

        --3当产品为规格为“企业总机”、“固网虚号码”，或产品规格为空时
      ELSIF (I_EXT_PROD_ID = '594000146' OR --I_EXT_PROD_ID = '600047744' OR
            I_EXT_PROD_ID = '610005565' OR I_EXT_PROD_ID IS NULL) THEN
        FOR REC IN (SELECT P_A.EXT_PROD_ID,
                           PO.EXT_OFFER_NBR,
                           PO.PROD_OFFER_NAME
                    --into V_EXT_PROD_ID, V_EXT_OFFER_NBR, V_PROD_OFFER_NAME
                      FROM PRODUCT             P_A,
                           PROD_INST           PI_A,
                           PROD_INST_REL       PIR,
                           OFFER_PROD_INST_REL OPIR,
                           PROD_OFFER_INST     POI,
                           PROD_OFFER          PO
                     WHERE 1 = 1
                       AND PI_A.PROD_INST_ID = V_PROD_INST_ID
                       AND PIR.PROD_INST_A_ID = PI_A.PROD_INST_ID
                       AND P_A.PRODUCT_ID = PI_A.PRODUCT_ID
                       AND PI_A.PROD_INST_ID = OPIR.PROD_INST_ID
                       AND OPIR.PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
                       AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
                       AND PO.OFFER_TYPE IN ('10', '11') --销售品类型：基础销售品,套餐销售品
                       AND PO.OFFER_SUB_TYPE = 'T01' --销售品子类型：接入类销售品
                       AND POI.STATUS_CD = '1000' --状态编码：在用
                       AND SYSDATE BETWEEN POI.EFF_DATE AND POI.EXP_DATE --当前时间在生失效时间区间内
                    ) LOOP
          V_EXT_PROD_ID     := REC.EXT_PROD_ID;
          V_EXT_OFFER_NBR   := REC.EXT_OFFER_NBR;
          V_PROD_OFFER_NAME := REC.PROD_OFFER_NAME;
          --若为‘企业总机V3.0通用版’，不允许受理一键通功能；
          IF V_EXT_OFFER_NBR = '800001254' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘企业总机V3.0选号版’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001495' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘协同通信-固网虚号码’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001184' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘功能型虚拟网’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001875' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘集团综合VPN’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001646' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --若为‘综合虚拟网（综合VPN）’，不允许受理一键通功能；
          ELSIF V_EXT_OFFER_NBR = '800001876' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := V_PROD_OFFER_NAME;
            O_RESULT   := V_EXT_OFFER_NBR;
            RETURN;
            --4IC卡、公话，不允许受理一键通功能。
            --I_EXT_PROD_ID不是‘普通电话’，号码是固话格式的(如何判断？)，不让受理
          ELSIF V_EXT_PROD_ID <> '594000276' THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := 'IC卡或公话';
            RETURN;
          END IF;
        END LOOP;

        --4IC卡、公话，不允许受理一键通功能。
        --I_EXT_PROD_ID不是‘普通电话’，号码是固话格式的(如何判断？)，不让受理
      ELSIF I_EXT_PROD_ID <> '594000276' THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := 'IC卡或公话';
        RETURN;
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := SQLERRM;
    END;

  END PROC_QUERY_IS_ENABLE_YJT;

  /*查询业务号码的包类型及所在E家的基础包号码*/
  PROCEDURE PROC_QUERY_BASE_SHARE_PACK(I_AREA_CODE     IN VARCHAR2, --区号
                                       I_ACC_NBR       IN VARCHAR2, --接入号码
                                       I_EXT_PROD_ID   IN VARCHAR2, --产品外部编码
                                       O_ERR_CODE      OUT NUMBER, --错误编码（0--成功 1--失败）
                                       O_ERR_MSG       OUT VARCHAR2, --错误信息
                                       O_PACK_TYPE     OUT VARCHAR2, --1:基础包  2：共享包 0：两者均不是
                                       O_BASE_PACK_NBR OUT VARCHAR2, --E家的基础包的天翼号码和固话号码
                                       O_ALL_PACK_NBR  OUT VARCHAR2, --E家所有包的天翼号码和固话
                                       O_ALL_PACK_ROLE OUT VARCHAR2 --E家所有包与亲情短号关系中的角色(1表示户主、2表示家庭成员、0表示未加入亲情短号)
                                       ) IS
    V_PROD_inst_ID       prod_inst.prod_inst_id%type;
    V_PROD_OFFER_inst_ID prod_offer_inst.prod_offer_inst_id%type;

    V_ALL_PACK_MOBILEPNONE_NBRS varchar2(200) := '';
    V_ALL_PACK_PNONE_NBRS       varchar2(200) := '';

    V_BASE_PACK_MOBILEPNONE_NBRS varchar2(200) := '';
    V_BASE_PACK_PNONE_NBRS       varchar2(200) := '';

    V_ALL_PACK_MOBILEPNONE_ROLES varchar2(20) := '';
    V_ALL_PACK_PNONE_ROLES       varchar2(20) := '';

  BEGIN
    --变量初始化
    O_ERR_MSG   := '';
    O_ERR_CODE  := 0;
    O_PACK_TYPE := 0;

    --检查业务号码是否有效
    BEGIN
      SELECT pi.prod_inst_id
        INTO V_PROD_inst_ID
        FROM product p, prod_inst pi
       WHERE 1 = 1
         AND pi.product_id = p.product_id
         AND p.ext_prod_id = I_EXT_PROD_ID
         AND pi.acc_nbr = I_ACC_NBR
         AND pi.area_code = I_AREA_CODE
         AND pi.status_cd = '100000';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '无效号码';
        RETURN;
    END;
    --查询业务号码是何种e家成员类型
    FOR REC1 IN (SELECT opir.prod_offer_inst_id, oprr.role_name
                   FROM offer_prod_inst_rel opir, offer_prod_rel_role oprr
                  WHERE opir.role_cd = oprr.role_cd
                    AND opir.prod_inst_id = V_PROD_inst_ID) LOOP
      IF instr(REC1.role_name, '基础包') > 0 THEN
        O_PACK_TYPE          := 1;
        V_PROD_OFFER_inst_ID := REC1.prod_offer_inst_id;
        EXIT;
      ELSIF instr(REC1.role_name, '共享包') > 0 THEN
        O_PACK_TYPE          := 2;
        V_PROD_OFFER_inst_ID := REC1.prod_offer_inst_id;
        EXIT;
      END IF;
    END LOOP;
    --找出e家所有包的天翼号码和固话,并找到它们的角色
    FOR REC2 IN (select t.acc_nbr, t.ext_prod_id, t.role_name, pir.role_cd
                   from prod_inst_rel pir
                   join prod_inst pi2 on pi2.prod_inst_id =
                                         pir.prod_inst_a_id
                   join product p2 on pi2.product_id = p2.product_id
                                  and p2.ext_prod_id = '610007885'
                  right outer join (select pi1.acc_nbr,
                                          p1.ext_prod_id,
                                          oprr.role_name,
                                          pi1.prod_inst_id --,pir.role_cd--,
                                     from prod_inst           pi1,
                                          product             p1,
                                          offer_prod_inst_rel opir,
                                          offer_prod_rel_role oprr
                                    where 1 = 1
                                      and pi1.prod_inst_id =
                                          opir.prod_inst_id
                                      and pi1.product_id = p1.product_id
                                      and opir.prod_offer_inst_id =
                                          V_PROD_OFFER_INST_ID
                                      and opir.role_cd = oprr.role_cd
                                      and p1.ext_prod_id in
                                          ('610003886', '594000276')
                                      and pi1.status_cd = '100000') t on pir.prod_inst_z_id =
                                                                         t.prod_inst_id) LOOP
      IF REC2.role_name like '%基础包%' THEN
        IF REC2.ext_prod_id = '610003886' THEN
          V_BASE_PACK_MOBILEPNONE_NBRS := V_BASE_PACK_MOBILEPNONE_NBRS ||
                                          REC2.acc_nbr || ',';
        ELSIF REC2.ext_prod_id = '594000276' THEN
          V_BASE_PACK_PNONE_NBRS := V_BASE_PACK_PNONE_NBRS || REC2.acc_nbr || ',';
        END IF;
      END IF;
      IF REC2.ext_prod_id = '610003886' THEN
        V_ALL_PACK_MOBILEPNONE_NBRS := V_ALL_PACK_MOBILEPNONE_NBRS ||
                                       REC2.acc_nbr || ',';
        IF REC2.role_cd = '829' THEN
          V_ALL_PACK_MOBILEPNONE_ROLES := V_ALL_PACK_MOBILEPNONE_ROLES || '1' || ',';
        ELSIF REC2.role_cd = '830' THEN
          V_ALL_PACK_MOBILEPNONE_ROLES := V_ALL_PACK_MOBILEPNONE_ROLES || '2' || ',';
        ELSE
          V_ALL_PACK_MOBILEPNONE_ROLES := V_ALL_PACK_MOBILEPNONE_ROLES || '0' || ',';
        END IF;
      ELSIF REC2.ext_prod_id = '594000276' THEN
        V_ALL_PACK_PNONE_NBRS := V_ALL_PACK_PNONE_NBRS || REC2.acc_nbr || ',';
        IF REC2.role_cd = '829' THEN
          V_ALL_PACK_PNONE_ROLES := V_ALL_PACK_PNONE_ROLES || '1' || ',';
        ELSIF REC2.role_cd = '830' THEN
          V_ALL_PACK_PNONE_ROLES := V_ALL_PACK_PNONE_ROLES || '2' || ',';
        ELSE
          V_ALL_PACK_PNONE_ROLES := V_ALL_PACK_PNONE_ROLES || '0' || ',';
        END IF;
      END IF;
    END LOOP;
    O_BASE_PACK_NBR := V_BASE_PACK_MOBILEPNONE_NBRS || ';' ||
                       V_BASE_PACK_PNONE_NBRS;
    O_ALL_PACK_NBR  := V_ALL_PACK_MOBILEPNONE_NBRS || ';' ||
                       V_ALL_PACK_PNONE_NBRS;
    O_ALL_PACK_ROLE := V_ALL_PACK_MOBILEPNONE_ROLES || ';' ||
                       V_ALL_PACK_PNONE_ROLES;

  END PROC_QUERY_BASE_SHARE_PACK;

  PROCEDURE PROC_INTF_INS_BILLING_UPDATE_2(I_TABLE_NAME  INTF_INS_BILLING_UPDATE.TABLE_NAME%TYPE,
                                         I_COLUMN_NAME INTF_INS_BILLING_UPDATE.COLUMN_NAME%TYPE,
                                         I_KEY_ID      INTF_INS_BILLING_UPDATE.KEY_ID%TYPE,
                                         I_TOPIC       INTF_INS_BILLING_UPDATE.TOPIC%TYPE,
                                         I_TYPE        INTF_INS_BILLING_UPDATE.TYPE%TYPE,
                                         I_REASON      INTF_INS_BILLING_UPDATE.REASON%TYPE,
                                         I_OPERATOR    INTF_INS_BILLING_UPDATE.OPERATOR%TYPE,
                                         I_AREA_NBR    INTF_INS_BILLING_UPDATE.AREA_NBR%TYPE)
  /*-------------------------------------------------
      功能: 插INTF_INS_BILLING_UPDATE表
    -------------------------------------------------*/
   IS
     V_PROD_INST_ID         PROD_INST.PROD_INST_ID%TYPE;
     V_PROD_OFFER_INST_ID   PROD_OFFER_INST.PROD_OFFER_INST_ID%TYPE;
     V_FLAG                 BOOLEAN;
  BEGIN

    INSERT INTO INTF_INS_BILLING_UPDATE
      (INS_ID,
       TABLE_NAME,
       COLUMN_NAME,
       KEY_ID,
       TOPIC,
       TYPE,
       REASON,
       OPERATOR,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       DEAL_NUM,
       NEXT_DEAL_TIME,
       ERR_MSG,
       REMARK,
       AREA_NBR)
      SELECT SEQ_INTF_INS_BILLING_UPDATE_ID.NEXTVAL, --INS_ID,
             I_TABLE_NAME, --TABLE_NAME,
             I_COLUMN_NAME, --COLUMN_NAME,
             I_KEY_ID, --KEY_ID,
             I_TOPIC, --TOPIC,
             I_TYPE, --TYPE,
             I_REASON, --REASON,
             I_OPERATOR, --OPERATOR,
             DECODE(I_TOPIC, '停复机（HB）-计费', '70G', '70A'), --STATE（停复机的特殊优先处理）,
             SYSDATE, --STATE_DATE,
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             0, --DEAL_NUM,
             SYSDATE, --NEXT_DEAL_TIME,
             NULL, --ERR_MSG,
             NULL, --REMARK,
             I_AREA_NBR --AREA_NBR,
        FROM DUAL;
      BEGIN
            V_PROD_INST_ID := NULL;
            V_FLAG := FALSE;
            IF I_TABLE_NAME = 'PROD_INST'  THEN
              V_FLAG := FUNC_IS_OCS(I_KEY_ID) ;
            ELSIF I_TABLE_NAME = 'PROD_INST_ATTR'  THEN
              BEGIN
                SELECT PROD_INST_ID INTO  V_PROD_INST_ID
                  FROM PROD_INST_ATTR
                 WHERE PROD_INST_ATTR_ID = I_KEY_ID;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  SELECT PROD_INST_ID INTO  V_PROD_INST_ID
                    FROM PROD_INST_ATTR_HIS
                   WHERE PROD_INST_ATTR_ID = I_KEY_ID
                     AND ROWNUM = 1;
              END;
              V_FLAG := FUNC_IS_OCS(V_PROD_INST_ID) ;
            ELSIF I_TABLE_NAME = 'PROD_OFFER_INST'  THEN
              V_PROD_INST_ID := FUNC_GET_PROD_INST_ID(I_KEY_ID);
              V_FLAG := FUNC_IS_OCS(V_PROD_INST_ID) ;
            ELSIF I_TABLE_NAME = 'PROD_OFFER_INST_ATTR'  THEN
              BEGIN
                SELECT PROD_OFFER_INST_ID INTO  V_PROD_OFFER_INST_ID
                  FROM PROD_OFFER_INST_ATTR
                 WHERE PROD_OFFER_INST_ATTR_ID = I_KEY_ID;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  SELECT PROD_OFFER_INST_ID INTO  V_PROD_OFFER_INST_ID
                    FROM PROD_OFFER_INST_ATTR_HIS

                   WHERE PROD_OFFER_INST_ATTR_ID = I_KEY_ID
                     AND ROWNUM = 1;
              END;
              V_PROD_INST_ID := FUNC_GET_PROD_INST_ID(V_PROD_OFFER_INST_ID);
              V_FLAG := FUNC_IS_OCS(V_PROD_INST_ID) ;
            ELSIF I_TABLE_NAME = 'OFFER_PROD_INST_REL'  THEN
              BEGIN
                SELECT PROD_OFFER_INST_ID INTO  V_PROD_OFFER_INST_ID
                  FROM OFFER_PROD_INST_REL
                 WHERE OFFER_PROD_INST_REL_ID = I_KEY_ID;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  SELECT PROD_OFFER_INST_ID INTO  V_PROD_OFFER_INST_ID
                    FROM OFFER_PROD_INST_REL_HIS
                   WHERE OFFER_PROD_INST_REL_ID = I_KEY_ID
                     AND ROWNUM = 1;
              END;
              V_PROD_INST_ID := FUNC_GET_PROD_INST_ID(V_PROD_OFFER_INST_ID);
              V_FLAG := FUNC_IS_OCS(V_PROD_INST_ID) ;
            ELSIF I_TABLE_NAME = 'PROD_OFFER_INST_REL'  THEN
              BEGIN
                SELECT RELA_PROD_OFFER_INST_ID INTO  V_PROD_OFFER_INST_ID
                  FROM PROD_OFFER_INST_REL
                 WHERE PROD_OFFER_INST_REL_ID = I_KEY_ID;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  SELECT RELA_PROD_OFFER_INST_ID INTO  V_PROD_OFFER_INST_ID
                    FROM PROD_OFFER_INST_REL_HIS
                   WHERE PROD_OFFER_INST_REL_ID = I_KEY_ID
                     AND ROWNUM = 1;
              END;
              V_PROD_INST_ID := FUNC_GET_PROD_INST_ID(V_PROD_OFFER_INST_ID);
              V_FLAG := FUNC_IS_OCS(V_PROD_INST_ID) ;
            END IF;
            /*
            IF V_FLAG THEN
              INSERT INTO INTF_INS_OCS_UPDATE
                (INS_ID,
                 TABLE_NAME,
                 COLUMN_NAME,
                 KEY_ID,
                 TOPIC,
                 TYPE,
                 REASON,
                 OPERATOR,
                 STATE,
                 STATE_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 DEAL_NUM,
                 NEXT_DEAL_TIME,
                 ERR_MSG,
                 REMARK,
                 AREA_NBR)
                SELECT SEQ_INTF_INS_OCS_UPDATE_ID.NEXTVAL, --INS_ID,
                       I_TABLE_NAME, --TABLE_NAME,
                       I_COLUMN_NAME, --COLUMN_NAME,
                       I_KEY_ID, --KEY_ID,
                       I_TOPIC, --TOPIC,
                       I_TYPE, --TYPE,
                       I_REASON, --REASON,
                       I_OPERATOR, --OPERATOR,
                       '70A', --STATE ,
                       SYSDATE, --STATE_DATE,
                       SYSDATE, --CREATE_DATE,
                       SYSDATE, --UPDATE_DATE,
                       0, --DEAL_NUM,
                       SYSDATE, --NEXT_DEAL_TIME,
                       NULL, --ERR_MSG,
                       NULL, --REMARK,
                       I_AREA_NBR --AREA_NBR,
                  FROM DUAL;
            END IF;
            */
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
  END;



  FUNCTION FUNC_GET_PROD_INST_ID(I_PROD_OFFER_INST_ID NUMBER) RETURN NUMBER
  IS
    V_PROD_INST_ID        PROD_INST.PROD_INST_ID%TYPE;
  BEGIN
    V_PROD_INST_ID := NULL;
    BEGIN
      SELECT PROD_INST_ID INTO  V_PROD_INST_ID
        FROM OFFER_PROD_INST_REL
       WHERE PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID;
    EXCEPTION
      WHEN OTHERS THEN
        SELECT PROD_INST_ID INTO  V_PROD_INST_ID
          FROM OFFER_PROD_INST_REL_HIS
         WHERE PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID
           AND ROWNUM = 1;
    END;
    RETURN   V_PROD_INST_ID;
  END;

  FUNCTION FUNC_IS_OCS(I_PROD_INST_ID NUMBER) RETURN BOOLEAN
  IS
    V_CNT       INTEGER;
  BEGIN
    SELECT COUNT(1) INTO V_CNT
      FROM PROD_INST
     WHERE PAYMENT_MODE_CD = '2100'
       AND PROD_INST_ID = I_PROD_INST_ID ;
    IF V_CNT = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END;


  FUNCTION FNC_IS_ON_ROAD(I_PROD_INST_ID IN PROD_INST.PROD_INST_ID%TYPE --产品实例id
                          ) RETURN BOOLEAN
  /*-------------------------------------------------
      功能: 判断产品实例是否在途
    -------------------------------------------------*/
   IS
    V_COUNT NUMBER(10);
  BEGIN
    SELECT COUNT(*)
      INTO V_COUNT
      FROM ORDER_ITEM A
     WHERE A.CLASS_ID = 4
       AND A.ORDER_ITEM_OBJ_ID = I_PROD_INST_ID
       AND STATUS_CD NOT IN ('300000', '401300') --300000: 竣工, 401300: 撤单
       AND ROWNUM = 1;

    IF V_COUNT > 0 THEN
      RETURN TRUE;
    END IF;
    RETURN FALSE;
  END;

  /************************************************************************
  Function  ：判断销售品是否为单接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    :（1 是 0 否）
  ************************************************************************/
  FUNCTION FUNC_IS_SIMPLE_ACCESS_OFFER(I_PROD_OFFER_ID NUMBER) RETURN BOOLEAN IS
    V_REL_COUNT NUMBER;
  BEGIN
    SELECT COUNT(*)
      INTO V_REL_COUNT
      FROM PROD_OFFER A, OFFER_PROD_REL B, PRODUCT C
     WHERE A.OFFER_SUB_TYPE = 'T01'
       AND A.PROD_OFFER_ID = B.PROD_OFFER_ID
       AND B.PRODUCT_ID = C.PRODUCT_ID
       AND C.PROD_FUNC_TYPE = '101'
       AND B.STATUS_CD = '1000'
       AND NVL(B.EFF_DATE, SYSDATE) <= SYSDATE
       AND NVL(B.EXP_DATE, SYSDATE) >= SYSDATE
       AND B.MAX_COUNT = 1
       AND B.MIN_COUNT = 1
       AND B.PROD_OFFER_ID = I_PROD_OFFER_ID;
    IF V_REL_COUNT = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FUNC_IS_SIMPLE_ACCESS_OFFER;

  /************************************************************************
  Function  ：判断销售品是否为多接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    : 结果（1 是 0 否）
  ************************************************************************/
  FUNCTION FUNC_IS_MULTI_ACCESS_OFFER(I_PROD_OFFER_ID NUMBER) RETURN BOOLEAN IS
    V_OFFER_SUB_TYPE PROD_OFFER.OFFER_SUB_TYPE%TYPE;
  BEGIN
    BEGIN
      SELECT A.OFFER_SUB_TYPE
        INTO V_OFFER_SUB_TYPE
        FROM PROD_OFFER A
       WHERE A.PROD_OFFER_ID = I_PROD_OFFER_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN FALSE;
    END;
    IF V_OFFER_SUB_TYPE = 'T01' THEN
      IF FUNC_IS_SIMPLE_ACCESS_OFFER(I_PROD_OFFER_ID) THEN
        RETURN FALSE;
      ELSE
        RETURN TRUE;
      END IF;
    ELSE
      RETURN FALSE;
    END IF;
  END FUNC_IS_MULTI_ACCESS_OFFER;

  /************************************************************************
  Function  ：获取产品属性信息
  Author　  ：Ouzhifang
  Date      : 2012-09-24
  Parameter : I_PROD_INST_ID        --产品实例标识
  Parameter : I_EXT_ATTR_NBR        --属性规格编码
  return    : O_ATTR_VALUE          --属性值（T1返回属性值，T3返回属性值名称）
  ************************************************************************/
  PROCEDURE PROC_QUERY_PROD_ATTR(I_PROD_INST_ID IN NUMBER,
                                 I_EXT_ATTR_NBR IN VARCHAR2,
                                 O_ATTR_VALUE   OUT VARCHAR2,
                                 O_ERR_CODE     OUT NUMBER,
                                 O_ERR_MSG      OUT VARCHAR2) IS
    V_ATTR_TYPE ATTR_SPEC.ATTR_TYPE%TYPE;
    V_ATTR_ID   ATTR_SPEC.ATTR_ID%TYPE;
  BEGIN
    --初始化
    O_ATTR_VALUE := '';
    BEGIN
      --查询在用的属性值信息
      SELECT A.ATTR_VALUE, B.ATTR_ID, B.ATTR_TYPE
        INTO O_ATTR_VALUE, V_ATTR_ID, V_ATTR_TYPE
        FROM PROD_INST_ATTR A, ATTR_SPEC B
       WHERE A.ATTR_ID = B.ATTR_ID
         AND B.EXT_ATTR_NBR = I_EXT_ATTR_NBR
         AND A.STATUS_CD = '1000'
         AND A.PROD_INST_ID = I_PROD_INST_ID
         AND ROWNUM = 1;
      --对于选择类型的返回对应的属性值
      IF O_ATTR_VALUE IS NOT NULL AND V_ATTR_ID IS NOT NULL AND
         V_ATTR_TYPE = 'T3' THEN
        SELECT ATTR_VALUE_NAME
          INTO O_ATTR_VALUE
          FROM ATTR_VALUE
         WHERE STATUS_CD = '1000'
           AND ATTR_ID = V_ATTR_ID
           AND ATTR_VALUE = O_ATTR_VALUE;
      END IF;
      O_ERR_CODE := 0;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --查询失败返回
        O_ATTR_VALUE := '';
        O_ERR_CODE   := 1;
        O_ERR_MSG    := sqlerrm;
    END;
  END PROC_QUERY_PROD_ATTR;

  /************************************************************************
  Function  ：获取销售品属性信息
  Author　  ：Ouzhifang
  Date      : 2012-09-24
  Parameter : I_PROD_OFFER_INST_ID  --销售品实例标识
  Parameter : I_EXT_ATTR_NBR        --属性规格编码
  return    : O_ATTR_VALUE          --属性值（T1返回属性值，T3返回属性值ID）
  ************************************************************************/
  PROCEDURE PROC_QUERY_OFFER_ATTR(I_PROD_OFFER_INST_ID IN NUMBER,
                                  I_EXT_ATTR_NBR       IN VARCHAR2,
                                  O_ATTR_VALUE         OUT VARCHAR2,
                                  O_ERR_CODE           OUT NUMBER,
                                  O_ERR_MSG            OUT VARCHAR2) IS
    V_ATTR_TYPE ATTR_SPEC.ATTR_TYPE%TYPE;
    V_ATTR_ID   ATTR_SPEC.ATTR_ID%TYPE;
  BEGIN
    --初始化
    O_ATTR_VALUE := '';
    O_ERR_CODE   := 0;
    BEGIN
      --查询在用的属性值信息
      SELECT A.ATTR_VALUE, B.ATTR_ID, B.ATTR_TYPE
        INTO O_ATTR_VALUE, V_ATTR_ID, V_ATTR_TYPE
        FROM PROD_OFFER_INST_ATTR A, ATTR_SPEC B
       WHERE A.ATTR_ID = B.ATTR_ID
         AND B.EXT_ATTR_NBR = I_EXT_ATTR_NBR
         AND (A.EXP_DATE IS NULL OR A.EXP_DATE > SYSDATE)
         AND A.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID
         AND ROWNUM = 1;
      --对于选择类型的返回对应的属性值
      IF O_ATTR_VALUE IS NOT NULL AND V_ATTR_ID IS NOT NULL AND
         V_ATTR_TYPE = 'T3' THEN
        SELECT ATTR_VALUE_ID
          INTO O_ATTR_VALUE
          FROM ATTR_VALUE
         WHERE STATUS_CD = '1000'
           AND ATTR_ID = V_ATTR_ID
           AND ATTR_VALUE = O_ATTR_VALUE;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          --查询在用的属性值信息
          SELECT ATTR_VALUE, ATTR_ID, ATTR_TYPE
            INTO O_ATTR_VALUE, V_ATTR_ID, V_ATTR_TYPE
            FROM (SELECT A.ATTR_VALUE,
                         B.ATTR_ID,
                         B.ATTR_TYPE,
                         ROW_NUMBER() OVER(PARTITION BY A.ATTR_ID ORDER BY A.HIS_ID DESC)
                    FROM PROD_OFFER_INST_ATTR_HIS A, ATTR_SPEC B
                   WHERE A.ATTR_ID = B.ATTR_ID
                     AND B.EXT_ATTR_NBR = I_EXT_ATTR_NBR
                     AND (A.EXP_DATE IS NULL OR A.EXP_DATE > SYSDATE)
                     AND A.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID)
           WHERE ROWNUM = 1;
          --对于选择类型的返回对应的属性值
          IF O_ATTR_VALUE IS NOT NULL AND V_ATTR_ID IS NOT NULL AND
             V_ATTR_TYPE = 'T3' THEN
            SELECT ATTR_VALUE_ID
              INTO O_ATTR_VALUE
              FROM ATTR_VALUE
             WHERE STATUS_CD = '1000'
               AND ATTR_ID = V_ATTR_ID
               AND ATTR_VALUE = O_ATTR_VALUE;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            --查询失败返回
            O_ATTR_VALUE := '';
            O_ERR_CODE   := 1;
            O_ERR_MSG    := sqlerrm;
        END;
    END;
  END PROC_QUERY_OFFER_ATTR;

   /*产品实例查询（对于多条，返回主号）*/
   PROCEDURE PROC_MAIN_PROD_INST(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                            I_ACC_NBR     IN VARCHAR2, --业务号码
                            I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话, 594000248-小灵通
                            O_PROD_INST_ID OUT NUMBER, --产品实例ID
                            O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                            O_ERR_MSG     OUT VARCHAR2 --错误信息
                            ) IS
    v_res_count NUMBER := 0;
    v_query_count NUMBER := 0;

    CURSOR cur_prod_inst_query IS
        SELECT pi.prod_inst_id
          FROM prod_inst pi, common_region cr, product p
         WHERE 1 = 1
           AND pi.common_region_id = cr.common_region_id
           AND cr.region_type = '1499'--C4级
           AND pi.status_cd != '110000' --拆机状态
           AND pi.area_code = I_AREA_CODE
           AND pi.product_id = p.product_id
           AND p.ext_prod_id = I_EXT_PROD_ID
           AND pi.acc_nbr = I_ACC_NBR;

    BEGIN
        O_PROD_INST_ID := '';
        O_ERR_CODE    := 0;
        O_ERR_MSG     := '';

        IF (I_ACC_NBR IS NULL) OR (I_AREA_CODE IS NULL) OR (I_EXT_PROD_ID IS NULL) THEN
           O_ERR_CODE := 1;
           O_ERR_MSG := '入参为空';
           RETURN;
        END IF;

        FOR rec IN cur_prod_inst_query LOOP
            IF v_res_count = 0 THEN
                O_PROD_INST_ID := rec.prod_inst_id;
                v_res_count := v_res_count + 1;
            --res_count = 1,取到第2条记录
            ELSE
                v_res_count := v_res_count + 1;
                --v_prod_inst_id放A端
                SELECT COUNT(*)
                  INTO v_query_count
                  FROM prod_inst_rel pir
                 WHERE 1 = 1
                   AND pir.relation_type_cd = '109920' --主副关系，一号双机
                   AND pir.prod_inst_a_id = O_PROD_INST_ID
                   AND pir.prod_inst_z_id = rec.prod_inst_id;
                IF v_query_count = 0 THEN
                    --没有查到主副关系，把v_prod_inst_id放Z端
                    SELECT COUNT(*)
                      INTO v_query_count
                      FROM prod_inst_rel pir
                     WHERE 1 = 1
                       AND pir.relation_type_cd = '109920'
                       AND pir.prod_inst_z_id = O_PROD_INST_ID
                       AND pir.prod_inst_a_id = rec.prod_inst_id;

                    IF v_query_count = 0 THEN
                        O_PROD_INST_ID := '';
                        O_ERR_CODE := 1;
                        O_ERR_MSG := '查询异常';
                        RETURN;
                    ELSE
                        O_PROD_INST_ID := rec.prod_inst_id;
                        O_ERR_CODE := 0;
                        O_ERR_MSG := '';
                        RETURN;
                    END IF;
                END IF;
            END IF;
        END LOOP;
    END PROC_MAIN_PROD_INST;

    /*-------------------------------------------------
      功能: 插INTF_INS_BILLING_UPDATE表
    -------------------------------------------------*/
    PROCEDURE PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  INTF_INS_BILLING_UPDATE.TABLE_NAME%TYPE,--表名
                                         I_COLUMN_NAME INTF_INS_BILLING_UPDATE.COLUMN_NAME%TYPE, --主键字段名
                                         I_KEY_ID      INTF_INS_BILLING_UPDATE.KEY_ID%TYPE,      --主键id
                                         I_TOPIC       INTF_INS_BILLING_UPDATE.TOPIC%TYPE,       --主题（批量计费使用，双写可空）
                                         I_TYPE        INTF_INS_BILLING_UPDATE.TYPE%TYPE,        --类型（批量计费使用，双写可空）
                                         I_REASON      INTF_INS_BILLING_UPDATE.REASON%TYPE,      --备注（批量计费使用，双写可空）
                                         I_OPERATOR    INTF_INS_BILLING_UPDATE.OPERATOR%TYPE,    --操作员工（批量计费使用，双写可空）
                                         I_AREA_NBR    INTF_INS_BILLING_UPDATE.AREA_NBR%TYPE    --区域id（批量计费使用，双写可空）
                                         ) IS
     V_PROD_INST_ID         PROD_INST.PROD_INST_ID%TYPE;

     V_PROD_OFFER_INST_ID   PROD_OFFER_INST.PROD_OFFER_INST_ID%TYPE;
     V_FLAG                 BOOLEAN;
     v_ds_flag varchar2(6);
     v_bill_flag varchar2(6);
  BEGIN
    v_ds_flag := '';
    -- 判断表是否需要双写
    begin
      select 'x' into v_ds_flag from sys_class where
        (table_name = I_TABLE_NAME or his_table_name = I_TABLE_NAME) and is_ds ='1' and rownum <= 1;
      exception
      when no_data_found then v_ds_flag := '';
    end;
    if v_ds_flag = 'x' then
      -- 将表信息插入basejk.intf_ins_ds_update表中
      insert into intf_ins_ds_update(INS_ID,
         TABLE_NAME,COLUMN_NAME,KEY_ID,
         TOPIC,TYPE,REASON,OPERATOR,
         STATE,STATE_DATE,CREATE_DATE,UPDATE_DATE,
         DEAL_NUM,NEXT_DEAL_TIME,ERR_MSG,REMARK,
         AREA_NBR,OP_TYPE,SHARDING_ID)
      values(seq_intf_ins_ds_update_id.nextval,
         I_TABLE_NAME,I_COLUMN_NAME,I_KEY_ID,
         I_TOPIC,'1001',I_REASON, null,'70A',sysdate,
         sysdate,sysdate,0,null, null,null,
         null,null,null);
    end if;
    -- 判断表是否需要写增量计费表
    begin
       select 'x' into v_bill_flag from attr_value
           where attr_id = '950024489' and attr_value = I_TABLE_NAME and rownum <= 1;
       exception
       when no_data_found then v_bill_flag := '';
    end;
    if v_bill_flag = 'x' then
        PROC_INTF_INS_BILLING_UPDATE_2(I_TABLE_NAME,I_COLUMN_NAME,I_KEY_ID,I_TOPIC,I_TYPE,I_REASON,I_OPERATOR,I_AREA_NBR);
    end if;
  END PROC_INTF_INS_BILLING_UPDATE;

  FUNCTION FUNC_GET_AREA_NBR(I_TABLE_NAME IN VARCHAR2,
                             I_KEY_ID     IN NUMBER) RETURN VARCHAR2
  IS
    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE:='';
  BEGIN
    IF I_TABLE_NAME = 'CUST_CERTIFICATION' THEN
       SELECT A.AREA_NBR
         INTO V_AREA_NBR
         FROM AREA_CODE A, COMMON_REGION B,CUST_CERTIFICATION C
        WHERE A.REGION_ID = B.COMMON_REGION_ID
          AND B.COMMON_REGION_ID = C.AREA_ID
          AND C.CUST_CERTIFICATION_ID = I_KEY_ID;
    END IF;
    RETURN V_AREA_NBR;
  END;

END PKG_COMMON;
/
