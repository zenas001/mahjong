CREATE PACKAGE BODY           PKG_CREDIT_LIMIT_FROMODS IS

  FUNCTION INSERT_INTO_LOG(OBJ_ID   IN NUMBER,
                           MSG      IN VARCHAR2,
                           ERR_INFO IN CLOB) RETURN BOOLEAN IS
  BEGIN
    INSERT INTO CREDIT_LIMIT_SYNC_LOG
      (LOG_ID, OBJ_ID, MSG, ERROR_INFO, CREATE_DATE)
    VALUES
      (SEQ_CREDIT_LIMIT_SYNC_LOG_ID.NEXTVAL, OBJ_ID, MSG, ERR_INFO, SYSDATE);
    RETURN TRUE;
  END INSERT_INTO_LOG;

  --从ODS获取帐期授信额度
  PROCEDURE GET_CREDIT_LIMIT_FROM_ODS IS
    V_END_CYCLE_ID VARCHAR2(100) := '000000';
    V_COUNT        NUMBER(12);
    V_SQL          VARCHAR2(400);
    O_ERR_MSG      CLOB;
    RET            BOOLEAN;
  BEGIN
    BEGIN
      SELECT END_CYCLE_ID

        INTO V_END_CYCLE_ID
        FROM INT_CRM_STATUS@LK_CRM2ODS
       WHERE INT_NAME = 'CUST_CREDIT_QUOTA_MONALL'
         AND IS_NEW = 1;
      RET := INSERT_INTO_LOG(0, '客户授信额度全量同步开始,同步周期:' || V_END_CYCLE_ID, '');
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        V_END_CYCLE_ID := '000000';
    END;
    --如果开关开时取数据到CRM 注：ODS只有一条帐期记录
    --IF V_END_CYCLE_ID <> TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM') THEN
    IF V_END_CYCLE_ID = '000000' THEN
      NULL;
    ELSE
      BEGIN
        V_SQL := 'TRUNCATE TABLE CREDIT_LIMIT_MONTH_TMP';
        EXECUTE IMMEDIATE V_SQL;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      BEGIN
        INSERT INTO CREDIT_LIMIT_MONTH_TMP
          SELECT CUST_CREDIT_ID,
                 CUST_ID,
                 BILLING_CYCLE_ID,
                 CREDIT_QUOTA_ID,
                 CREATED_DATE,
                 ETL_DATE,
                 LATN_ID
            FROM INTF_CUST_CREDIT_QUOTA_MONALL@LK_CRM2ODS
           WHERE BILLING_CYCLE_ID = V_END_CYCLE_ID;

        SELECT COUNT(1) INTO V_COUNT FROM CREDIT_LIMIT_MONTH_TMP;
        RET := INSERT_INTO_LOG(0, '取数成功,共计:' || V_COUNT, '');
        COMMIT;

        --先从客户授信额度帐期临时表中取出所有数据存入授信额度处理表CUST_LIMIT_MONTH
        INSERT INTO CUST_LIMIT_MONTH
          (CUST_CREDIT_ID, CUST_ID, BILLING_CYCLE_ID, LATN_ID, CREDIT_QUOTA_ID, CREATED_DATE, ETL_DATE, STATE, MODI_DATE)
          SELECT CUST_CREDIT_ID,
                 CUST_ID,
                 BILLING_CYCLE_ID,
                 LATN_ID,
                 CREDIT_QUOTA_ID,
                 CREATED_DATE,
                 ETL_DATE,
                 'WAIT',
                 SYSDATE
            FROM CREDIT_LIMIT_MONTH_TMP;

        --数据取完,要关闭开关
        UPDATE INT_CRM_STATUS@LK_CRM2ODS
           SET IS_NEW = 0
         WHERE INT_NAME = 'CUST_CREDIT_QUOTA_MONALL'
           AND IS_NEW = 1;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          O_ERR_MSG := SQLERRM;
          RET       := INSERT_INTO_LOG(0, '取数失败', O_ERR_MSG);

          NULL;
      END;
    END IF;
  END GET_CREDIT_LIMIT_FROM_ODS;

  --判断积分客户的临时授信额度是否在有效期。增加判断是否存在手动授信额度（ADD BY WANGCHI 20091021 CRM00017681）
  --RETURN 1:没有记录 2:临时额度在有效期内
  --3:临时额度不在有效期内（CRM00030137上线后改为表示临时额度不在有效期内或没有手工授信额度或者手工授信额度失效）
  --4:有手动授信额度（CRM00030137上线后改为表示有手动授信额度且有效）
  --CRM00026642 用测问题_六期_FJCRMV6.10REQ_钻金会员欠费催停的需求
  /*
    CUST_QUOTA_INFO.ACT_QUOTA
  这个是通过ODS系统过来，无条件更新
  对于有更新ACT_QUOTA字段时，需要更新CUST_QUOTA_INFO.CUST_QUOTA这个字段，对这个字段更新条件如下，
  如果ATRI_QUOTA手动授信额度有值不做处理，
  如果手动授信额度没有值，需要判断TMP_QUOTA临时授信是否有值，如果有值的话，判断是否在有效期内，如果有也不做更新。否则更新CUST_QUOTA这个字段
    */
  FUNCTION JUDGE_TEMP_CREDIT_LIMIT_VALID(V1_CUSTID IN NUMBER) RETURN INTEGER IS
    STR_YYYYMMDD VARCHAR2(8);
    L_COUNT      NUMBER := 0;
    VFLAG        INTEGER := 1;
    VKG          INTEGER := 0; --CRM00030137 开关
    VISTYPE      INTEGER := 0; --CRM00030137 是否退出VIP级别失效
    VISVIP       INTEGER := 0; --CRM00030137 是否VIP客户
    O_ERR_MSG    CLOB;
    RET          BOOLEAN;
    --1、CUST_VIP_INFO没记录则不是VIP客户
    --2、CUST_VIP_INFO表中有记录且VIP级别是钻、金、银才是VIP客户其余都不是VIP客户，
    CURSOR AA IS
      SELECT TO_CHAR(B.EFF_DATE, 'YYYYMMDD') AS EFFDATE,
             TO_CHAR(B.EXP_DATE, 'YYYYMMDD') AS EXPDATE,
             A.ATRI_CREDIT_LEVEL AS ATRI_QUOTA, --手动授信额度
             B.CREDIT_LEVEL AS TMP_QUOTA, --临时授信额度
             A.CREDIT_LIMIT_ID
        FROM CREDIT_LIMIT A, TEMP_CREDIT_LIMIT B
       WHERE A.CREDIT_LIMIT_ID = B.CREDIT_LIMIT_ID(+)
         AND CUST_ID = V1_CUSTID;

  BEGIN
    SELECT COUNT(*)
      INTO L_COUNT
      FROM CREDIT_LIMIT
     WHERE CUST_ID = V1_CUSTID;
    IF L_COUNT = 0 THEN
      VFLAG := 1;
    ELSE
      BEGIN
        SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') INTO STR_YYYYMMDD FROM DUAL;
        FOR REC IN AA LOOP
          --失效时间生效
          --ADD WANGCHI 20091021 CRM00017681 如果有手动授信额度的话，只能同步ACT_QUOTA字段
          IF REC.ATRI_QUOTA <> 0 AND NVL(REC.ATRI_QUOTA, '') IS NOT NULL AND
             REC.ATRI_QUOTA <> '590100' THEN
            --20110808 CRM00030137子单_授信2.0补充完善支撑需求_后台
            --开关打开
            VFLAG := 4; --有手动生效方式且有效
            ---EFF_TYPE=1表示手动授信退出VIP失效
            SELECT COUNT(*)
              INTO VISTYPE
              FROM CREDIT_LIMIT A
             WHERE CUST_ID = V1_CUSTID
               AND A.EFF_TYPE = 1;
            --退出VIP失效
            IF VISTYPE > 0 THEN
              --判断是否还是VIP
              SELECT COUNT(*)
                INTO VISVIP
                FROM CLUB_MEMBER B
               WHERE B.MEMBERSHIP_LEVEL IN ('1000', '1100', '1200')
                 AND B.STATUS_CD = '1000'
                 AND CUST_ID = V1_CUSTID;

              IF VISVIP = 0 THEN
                --非VIP客户
                VFLAG := 3; --有手动授信额度但已失效
              END IF;
            END IF;

          ELSIF REC.EFFDATE <= STR_YYYYMMDD AND REC.EXPDATE >= STR_YYYYMMDD AND
                NVL(REC.TMP_QUOTA, '') IS NOT NULL THEN
            VFLAG := 2; --临时授信在有效期内
          ELSIF REC.EFFDATE <= STR_YYYYMMDD AND
                NVL(REC.EXPDATE, '') IS NULL AND
                NVL(REC.TMP_QUOTA, '') IS NOT NULL THEN
            --未设置失效时间，表示无限期
            VFLAG := 2;
            --ELSIF (NVL(REC.EFFDATE,'') IS NOT NULL AND REC.EFFDATE>STR_YYYYMMDD) OR (NVL(REC.EXPDATE,'') IS NOT NULL AND REC.EXPDATE<STR_YYYYMMDD) THEN
          ELSE
            VFLAG := 3; ---无手动授信额度
          END IF;
        END LOOP;
      END;
    END IF;
    RETURN VFLAG;
    --处理异常
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_MSG := SQLERRM;
      RET       := INSERT_INTO_LOG(V1_CUSTID, '判断是否生失效失败', O_ERR_MSG);

      RETURN 0;
  END JUDGE_TEMP_CREDIT_LIMIT_VALID;

  --增量取授信额度
  PROCEDURE KH_CREDIT_LIMIT_INCREMENT IS
    V_DEAL_COUNT   INTEGER; --记录操作次数,满100条数据提交一次
    V_DEAL_ALL_NUM INTEGER; --记录本过程处理总数据量
    V_LOOPCOUNTER  INTEGER; --每天只处理30万数据
    V_FAIL_COUNT   INTEGER; --处理失败的计数
    AREAID NUMBER(12);--保存区域id
    CREDIT_ID NUMBER(12);

    V_CUR_CUST_REC CUST_LIMIT_MONTH%ROWTYPE;
    STR_VIPNBR     VARCHAR2(30);
    V_STR_BILL     VARCHAR2(100); --帐期

    VFLAG     INTEGER := 0; --判断标识
    O_ERR_MSG CLOB;
    RET       BOOLEAN;
    --处理失败的数据
    CURSOR CUR_CUST_F IS
      SELECT *
        FROM CUST_LIMIT_MONTH
       WHERE STATE = 'FAIL'
       ORDER BY BILLING_CYCLE_ID, CUST_CREDIT_ID;

    --处理等待同步的数据
    CURSOR CUR_CUST_W IS
      SELECT *
        FROM CUST_LIMIT_MONTH
       WHERE STATE = 'WAIT'
       ORDER BY BILLING_CYCLE_ID, CUST_CREDIT_ID;

  BEGIN

    V_DEAL_COUNT   := 0; --记录操作次数,满100条数据提交一次
    V_DEAL_ALL_NUM := 0; --记录本过程处理总数据量
    V_LOOPCOUNTER  := 0; --每天只处理30W数据
    V_FAIL_COUNT   := 0; --处理失败的计数

    --先处理前期同步失败的数据，控制在每天最多处理10万以内
    OPEN CUR_CUST_F;
    LOOP
      FETCH CUR_CUST_F
        INTO V_CUR_CUST_REC; --POINT ++
      EXIT WHEN CUR_CUST_F%NOTFOUND;

      V_DEAL_COUNT   := V_DEAL_COUNT + 1;
      V_DEAL_ALL_NUM := V_DEAL_ALL_NUM + 1;
      V_LOOPCOUNTER  := V_LOOPCOUNTER + 1;

      BEGIN

        --增加规则：历史表已处理时间大于当前未处理时间，就直接删除进历史
        BEGIN
          SELECT MAX(BILLING_CYCLE_ID)
            INTO V_STR_BILL
            FROM CUST_LIMIT_MONTH_HIS
           WHERE CUST_ID = V_CUR_CUST_REC.CUST_ID;
        EXCEPTION
          WHEN OTHERS THEN
            V_STR_BILL := '000000';
        END;
        select  Max(b.area_code_id) into AREAID from area_code b where b.area_nbr=to_char(V_CUR_CUST_REC.LATN_ID);
        IF V_CUR_CUST_REC.BILLING_CYCLE_ID > NVL(V_STR_BILL, '000000') THEN
          ----MODIFY BY WANGCHI 20091021 CRM00017681 授信额度相关字段挪到新表CUST_QUOTA_INFO中
          --简化原有的判断处理
          VFLAG := JUDGE_TEMP_CREDIT_LIMIT_VALID(V_CUR_CUST_REC.CUST_ID);
          --4：有手动授信额度且有效
          --2：有临时授信额度且有效
          select MAX(a.credit_limit_id) into CREDIT_ID from CREDIT_LIMIT a where A.CUST_ID = V_CUR_CUST_REC.CUST_ID;
          IF VFLAG = 4 OR VFLAG = 2 THEN
            UPDATE CREDIT_LIMIT A
               SET A.CREDIT_LIMIT_FEE = V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                   A.UPDATE_DATE      = SYSDATE
             WHERE A.CUST_ID = V_CUR_CUST_REC.CUST_ID;
            --并传计费批量接口
            SYNC_CREDIT_LIMIT_DATA_2_JF(CREDIT_ID);
            --1:没有授信额度
          ELSIF VFLAG = 1 THEN
            INSERT INTO CREDIT_LIMIT A
              (CREDIT_LIMIT_ID, CUST_ID, CREDIT_LEVEL, CREDIT_LIMIT_FEE, CREATE_DATE, UPDATE_DATE, STATUS_CD,area_id,region_cd)
            VALUES
              (SEQ_CREDIT_LIMIT_ID.NEXTVAL, V_CUR_CUST_REC.CUST_ID, V_CUR_CUST_REC.CREDIT_QUOTA_ID, V_CUR_CUST_REC.CREDIT_QUOTA_ID, SYSDATE, SYSDATE, '1000',AREAID,AREAID);
            select SEQ_CREDIT_LIMIT_ID.currval into CREDIT_ID from dual;
            --并传计费批量接口
            SYNC_CREDIT_LIMIT_DATA_2_JF(CREDIT_ID);
            /*ELSIF JUDGE_TEMP_CREDIT_LIMIT_VALID(V_CUR_CUST_REC.CUST_ID)=2 THEN
            --临时授信额度还在生效期内，则只变更原授信额度    */
            --3:临时额度不在有效期内或没有手工授信额度或者手工授信额度失效
          ELSIF VFLAG = 3 THEN
            UPDATE CREDIT_LIMIT A
               SET A.CREDIT_LIMIT_FEE = V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                   A.CREDIT_LEVEL     = V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                   A.UPDATE_DATE      = SYSDATE
             WHERE CUST_ID = V_CUR_CUST_REC.CUST_ID;
            --并传计费批量接口
            SYNC_CREDIT_LIMIT_DATA_2_JF(CREDIT_ID);
          END IF;
        END IF;
        --同步后，处理表数据进历史
        INSERT INTO CUST_LIMIT_MONTH_HIS
          (HIS_ID, CUST_CREDIT_ID, CUST_ID, BILLING_CYCLE_ID, LATN_ID, CREDIT_QUOTA_ID, CREATED_DATE, ETL_DATE, STATE, MODI_DATE)
          SELECT SEQ_CUST_LIMIT_MONTH_HIS_ID.NEXTVAL,
                 V_CUR_CUST_REC.CUST_CREDIT_ID,
                 V_CUR_CUST_REC.CUST_ID,
                 V_CUR_CUST_REC.BILLING_CYCLE_ID,
                 V_CUR_CUST_REC.LATN_ID,
                 V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                 V_CUR_CUST_REC.CREATED_DATE,
                 V_CUR_CUST_REC.ETL_DATE,
                 'SUCC',
                 SYSDATE
            FROM DUAL;

        --成功从一表删除
        DELETE FROM CUST_LIMIT_MONTH
         WHERE CUST_CREDIT_ID = V_CUR_CUST_REC.CUST_CREDIT_ID
           AND BILLING_CYCLE_ID = V_CUR_CUST_REC.BILLING_CYCLE_ID;

      EXCEPTION
        WHEN OTHERS THEN
          STR_VIPNBR   := '';
          V_FAIL_COUNT := V_FAIL_COUNT + 1;
          UPDATE CUST_LIMIT_MONTH
             SET MODI_DATE = SYSDATE,
                 FAIL_NUM  = NVL(V_CUR_CUST_REC.FAIL_NUM, 0) + 1
           WHERE CUST_CREDIT_ID = V_CUR_CUST_REC.CUST_CREDIT_ID
             AND BILLING_CYCLE_ID = V_CUR_CUST_REC.BILLING_CYCLE_ID;
          --失败处理次数大于30次就直接删除 V_CUR_CUST_REC.FAIL_NUM还是上期计数，未加一
          IF V_CUR_CUST_REC.FAIL_NUM >= 30 THEN
            INSERT INTO CUST_LIMIT_MONTH_HIS
              (HIS_ID, CUST_CREDIT_ID, CUST_ID, BILLING_CYCLE_ID, LATN_ID, CREDIT_QUOTA_ID, CREATED_DATE, ETL_DATE, STATE, MODI_DATE)
              SELECT SEQ_CUST_LIMIT_MONTH_HIS_ID.NEXTVAL,
                     V_CUR_CUST_REC.CUST_CREDIT_ID,
                     V_CUR_CUST_REC.CUST_ID,
                     V_CUR_CUST_REC.BILLING_CYCLE_ID,
                     V_CUR_CUST_REC.LATN_ID,
                     V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                     V_CUR_CUST_REC.CREATED_DATE,
                     V_CUR_CUST_REC.ETL_DATE,
                     'FAIL',
                     SYSDATE
                FROM DUAL;
            DELETE FROM CUST_LIMIT_MONTH
             WHERE CUST_CREDIT_ID = V_CUR_CUST_REC.CUST_CREDIT_ID
               AND BILLING_CYCLE_ID = V_CUR_CUST_REC.BILLING_CYCLE_ID;
          END IF;
      END;

      IF V_DEAL_COUNT = 100 THEN
        --满100条数据提交一次
        V_DEAL_COUNT := 0;
        COMMIT;
      END IF;

      --一天只处理20万上期处理失败的数据
      IF V_LOOPCOUNTER > 200000 THEN
        COMMIT;
        EXIT;
      END IF;

    END LOOP;

    OPEN CUR_CUST_W;
    LOOP
      FETCH CUR_CUST_W
        INTO V_CUR_CUST_REC; --POINT ++
      EXIT WHEN CUR_CUST_W%NOTFOUND;

      V_DEAL_COUNT   := V_DEAL_COUNT + 1;
      V_DEAL_ALL_NUM := V_DEAL_ALL_NUM + 1;
      V_LOOPCOUNTER  := V_LOOPCOUNTER + 1;

      BEGIN
        --MODIFY BY WANGCHI 20091021 CRM00017681 授信额度相关字段挪到新表CUST_QUOTA_INFO中
        --简化原有的判断处理
        VFLAG := JUDGE_TEMP_CREDIT_LIMIT_VALID(V_CUR_CUST_REC.CUST_ID);
        --4：有手动授信额度且有效
        --2：有临时授信额度且有效
        select  Max(b.area_code_id) into AREAID from area_code b where b.area_nbr=to_char(V_CUR_CUST_REC.LATN_ID);
        select MAX(a.credit_limit_id) into CREDIT_ID from CREDIT_LIMIT a where A.CUST_ID = V_CUR_CUST_REC.CUST_ID;
        IF VFLAG = 4 OR VFLAG = 2 THEN
          UPDATE CREDIT_LIMIT A
             SET A.CREDIT_LIMIT_FEE = V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                 A.UPDATE_DATE      = SYSDATE
           WHERE CUST_ID = V_CUR_CUST_REC.CUST_ID;
          --并传计费批量接口
          SYNC_CREDIT_LIMIT_DATA_2_JF(CREDIT_ID);
          --3:没有授信额度
        ELSIF VFLAG = 1 THEN

          INSERT INTO CREDIT_LIMIT A
            (CREDIT_LIMIT_ID, CUST_ID, CREDIT_LEVEL, CREDIT_LIMIT_FEE, CREATE_DATE, UPDATE_DATE, STATUS_CD,area_id,region_cd)
          VALUES
            (SEQ_CREDIT_LIMIT_ID.NEXTVAL, V_CUR_CUST_REC.CUST_ID, V_CUR_CUST_REC.CREDIT_QUOTA_ID, V_CUR_CUST_REC.CREDIT_QUOTA_ID, SYSDATE, SYSDATE, '1000',AREAID,AREAID);
          select SEQ_CREDIT_LIMIT_ID.currval into CREDIT_ID from dual;
          --并传计费批量接口
          SYNC_CREDIT_LIMIT_DATA_2_JF(CREDIT_ID);
          /* --临时授信额度还在生效期内，则只变更原授信额度
          */
          --3:临时额度不在有效期内或没有手工授信额度或者手工授信额度失效
        ELSIF VFLAG = 3 THEN
          UPDATE CREDIT_LIMIT A
             SET A.CREDIT_LIMIT_FEE = V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                 A.CREDIT_LEVEL     = V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                 A.UPDATE_DATE      = SYSDATE
           WHERE CUST_ID = V_CUR_CUST_REC.CUST_ID;
          --并传计费批量接口
          SYNC_CREDIT_LIMIT_DATA_2_JF(CREDIT_ID);
        END IF;
        --同步后，处理表数据进历史
        INSERT INTO CUST_LIMIT_MONTH_HIS
          (HIS_ID, CUST_CREDIT_ID, CUST_ID, BILLING_CYCLE_ID, LATN_ID, CREDIT_QUOTA_ID, CREATED_DATE, ETL_DATE, STATE, MODI_DATE)
          SELECT SEQ_CUST_LIMIT_MONTH_HIS_ID.NEXTVAL,
                 V_CUR_CUST_REC.CUST_CREDIT_ID,
                 V_CUR_CUST_REC.CUST_ID,
                 V_CUR_CUST_REC.BILLING_CYCLE_ID,
                 V_CUR_CUST_REC.LATN_ID,
                 V_CUR_CUST_REC.CREDIT_QUOTA_ID,
                 V_CUR_CUST_REC.CREATED_DATE,
                 V_CUR_CUST_REC.ETL_DATE,
                 'SUCC',
                 SYSDATE
            FROM DUAL;

        --成功从一表删除
        DELETE FROM CUST_LIMIT_MONTH
         WHERE CUST_CREDIT_ID = V_CUR_CUST_REC.CUST_CREDIT_ID
           AND BILLING_CYCLE_ID = V_CUR_CUST_REC.BILLING_CYCLE_ID;

      EXCEPTION
        WHEN OTHERS THEN
          STR_VIPNBR   := '';
          V_FAIL_COUNT := V_FAIL_COUNT + 1;
          UPDATE CUST_LIMIT_MONTH
             SET STATE    = 'FAIL',
                 FAIL_NUM = NVL(V_CUR_CUST_REC.FAIL_NUM, 0) + 1
           WHERE CUST_CREDIT_ID = V_CUR_CUST_REC.CUST_CREDIT_ID
             AND BILLING_CYCLE_ID = V_CUR_CUST_REC.BILLING_CYCLE_ID;
      END;

      IF V_DEAL_COUNT = 100 THEN
        --满100条数据提交一次
        V_DEAL_COUNT := 0;
        COMMIT;
      END IF;

      --一天只处理80万上期处理失败的数据
      IF V_LOOPCOUNTER > 800000 THEN
        COMMIT;
        EXIT;
      END IF;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_MSG := SQLERRM;
      RET       := INSERT_INTO_LOG(0, '客户授信额度处理失败', O_ERR_MSG);
      ROLLBACK;
  END KH_CREDIT_LIMIT_INCREMENT;

  --送计费批量接口
  PROCEDURE SYNC_CREDIT_LIMIT_DATA_2_JF(V2_CREDIT_LIMIT_ID IN NUMBER) IS
  BEGIN
    --调用接口过程  crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
/*    BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CREDIT_LIMIT', 'CREDIT_LIMIT_ID', V2_CREDIT_LIMIT_ID, 'PKG_CREDIT_LIMIT_FROMODS 修改授信额度', '1002', 'PKG_CREDIT_LIMIT_FROMODS 修改授信额度', '', '590');
*/
   PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CREDIT_LIMIT', 'CREDIT_LIMIT_ID', V2_CREDIT_LIMIT_ID, 'PKG_CREDIT_LIMIT_FROMODS 修改授信额度', '1002', 'PKG_CREDIT_LIMIT_FROMODS 修改授信额度', '', '590');

END SYNC_CREDIT_LIMIT_DATA_2_JF;

  PROCEDURE MAIN_PROC IS
    RET BOOLEAN;
  BEGIN
    GET_CREDIT_LIMIT_FROM_ODS;
    KH_CREDIT_LIMIT_INCREMENT;
    RET := INSERT_INTO_LOG(0, '客户授信额度全量同步结束', '');
    COMMIT;
  END MAIN_PROC;

END PKG_CREDIT_LIMIT_FROMODS;
/
