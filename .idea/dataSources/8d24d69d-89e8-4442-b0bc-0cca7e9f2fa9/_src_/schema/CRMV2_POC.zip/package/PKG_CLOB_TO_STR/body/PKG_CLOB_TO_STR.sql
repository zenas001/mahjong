CREATE PACKAGE BODY           PKG_CLOB_TO_STR IS
  /* Created Date: 2010-07-23
   Author: linyx
   Descript：解析XML字段值
  */

  PROCEDURE CLOB_TO_STR_MAIN1(IN_CLOB        in CLOB,
                              IN_PRIMARY_KEY IN VARCHAR2,
                              IN_PARAM       in VARCHAR2,
                              IN_ID          in number,
                              IN_TABLE_NAME  IN VARCHAR2) IS
    v_cnt1        NUMBER(3);
    v_cnt2        NUMBER(3);
    v_cnt3        NUMBER(3);
    V_CLOB        CLOB;
    V_PRIMARY_KEY VARCHAR2(10000);
    V_PARAM       VARCHAR2(10000);
    V_PARAM1      VARCHAR2(10000);
    n1            number;
    n2            number;
    m1            number;
    m2            number;
    m             number;
    q             number;
    o             number;
    o1            number;
    RESULT_TMP    VARCHAR2(10000);
    --RESULT        VARCHAR2(2000);
    t_PARAM      VARCHAR2(10000);
    p_PARAM      VARCHAR2(10000);
    t_PARAM_1    VARCHAR2(10000);
    V_MODI_MAN   VARCHAR2(500);
    V_ADD_TABLE  NUMBER := 0;
    v_table_name varchar(50);
    v_id         number := 1;
    v_err_str    varchar2(10000);
    v_sql        varchar2(10000);
    v_prim_value varchar2(10000);
  BEGIN

    V_CLOB        := IN_CLOB;
    V_PRIMARY_KEY := IN_PRIMARY_KEY;
    V_PARAM       := IN_PARAM;
    v_param1      := IN_PARAM;
    v_cnt1        := GET_CHAR_CNT1(V_CLOB, '<' || V_PRIMARY_KEY || '>');
    v_cnt3        := GET_CHAR_CNT1(V_PARAM, ',');
    v_id          := IN_id;
    v_table_name  := IN_TABLE_NAME; --V_MODI_MAN || '_' ||
    --to_char(sysdate, 'yyyymmddhh24miss');
    /*    begin
      v_sql := 'drop table ' || v_table_name;
      execute immediate v_sql;
    exception
      when others then
        null;
    end;*/
    begin
      v_sql := 'select count(*) from ' || v_table_name;
      o1    := 1;
      EXECUTE immediate v_sql;
    exception
      when others then
        v_sql := sqlerrm;
        o1    := 0;
    end;
    if o1 = 0 then
      v_sql := 'create table ' || v_table_name || ' (XML_TO_STR_ID NUMBER,' ||
               V_PRIMARY_KEY || ' VARCHAR2(2000))';

      EXECUTE immediate v_sql;

    end if;
    v_sql := 'select nvl(max(XML_TO_STR_ID)+1,1) from ' || v_table_name;
    EXECUTE immediate v_sql
      into v_id;
    if o1 = 0 then
      loop
        select instr(v_param1, ',') into o from dual;
        if o > 0 then
          select substr(v_param1, 0, o - 1) into p_PARAM from dual;
          execute immediate 'alter table ' || v_table_name || ' add (' ||
                            p_PARAM || ' varchar2(2000))';
        else
          p_PARAM := v_param1;
          if p_param is not null then
            execute immediate 'alter table ' || v_table_name || ' add (' ||
                              p_PARAM || ' varchar2(2000))';
          end if;
          exit;
        end if;
        begin
          select substr(v_param1, o + 1) into v_param1 from dual;
        end;
      end loop;
    end if;
    -- RESULT        := '';
    if V_PARAM is not null then
      V_PARAM   := ',' || V_PARAM || ',';
      t_PARAM_1 := substr(V_PARAM,
                          instr(V_PARAM, ',', 1, 1) + 1,
                          instr(V_PARAM, ',', 1, 2) -
                          instr(V_PARAM, ',', 1, 1) - 1);
      v_cnt2    := GET_CHAR_CNT1(V_CLOB, '<' || t_PARAM_1 || '>');
      --DBMS_OUTPUT.put_line('-----M:' || M);
      for i in 1 .. v_cnt1 loop
        ---定位IN_PRIMARY_KEY前后的位置，以判断对应的V_PARAM
        n1 := instr(V_CLOB, '<' || IN_PRIMARY_KEY || '>', 1, i);
        n2 := instr(V_CLOB, '<' || IN_PRIMARY_KEY || '>', 1, i + 1);

        if n2 <= 0 THEN
          n2 := 999999999;
        end if;
        for j in 1 .. v_cnt2 loop
          ---取第一个参数节点的位置
          m1 := instr(V_CLOB, '<' || t_PARAM_1 || '>', 1, j);
          m2 := instr(V_CLOB, '<' || t_PARAM_1 || '>', 1, j + 1);
          if m2 <= 0 THEN
            m2 := 999999999;
          end if;
          IF m1 > n1 and m1 < n2 THEN
            v_prim_value := CLOB_TO_STR_SINGLE1(V_CLOB, V_PRIMARY_KEY, i);
            v_sql        := 'insert into ' || v_table_name ||
                            ' (XML_TO_STR_ID,' || V_PRIMARY_KEY ||
                            ') values (' || to_char(v_id) || ',''' ||
                            v_prim_value || ''')';
            execute immediate v_sql;
            commit;

            for k in 1 .. v_cnt3 + 1 loop
              -----对每个参数节点循环判断其位置是否位于第一个参数节点和第二个参数节点之间
              t_PARAM := substr(V_PARAM,
                                instr(V_PARAM, ',', 1, k) + 1,
                                instr(V_PARAM, ',', 1, k + 1) -
                                instr(V_PARAM, ',', 1, k) - 1);

              RESULT_TMP := '';
              q          := 0;
              for t in 1 .. v_cnt2 loop
                m := instr(V_CLOB, '<' || t_PARAM || '>', 1, t);
                --- DBMS_OUTPUT.put_line('-----t_PARAM-m:' || m);

                if m >= m1 and m < m2 then
                  if q = 0 then
                    RESULT_TMP := CLOB_TO_STR_SINGLE1(V_CLOB, t_PARAM, t);
                  else
                    RESULT_TMP := ',' || RESULT_TMP ||
                                  CLOB_TO_STR_SINGLE1(V_CLOB, t_PARAM, t);
                  end if;
                  q := q + 1;
                end if;
              end loop;
              commit;
              begin
                v_sql := 'update ' || v_table_name || ' set ' || t_PARAM ||
                         ' = ''' || RESULT_TMP ||
                         ''' where XML_TO_STR_ID =' || to_char(v_id);
                execute immediate v_sql;
              exception
                when others then
                  v_err_str := sqlerrm;
              end;
              commit;

            end loop;
            v_id        := v_id + 1;
            V_ADD_TABLE := 1;
          ELSE
            NULL;
          END IF;
        end loop;
      end loop;
    else
      for i in 1 .. v_cnt1 loop
        v_prim_value := substr(CLOB_TO_STR_SINGLE1(V_CLOB, V_PRIMARY_KEY, i),
                               1,
                               100);
        v_sql        := 'insert into ' || v_table_name ||
                        ' (XML_TO_STR_ID,' || V_PRIMARY_KEY || ') values (' ||
                        to_char(v_id) || ',''' || v_prim_value || ''')';
        execute immediate v_sql;
        v_id := v_id + 1;
        commit;
      end loop;
    end if;

    COMMIT;
  exception
    when others then
      v_sql := sqlerrm;
  END CLOB_TO_STR_MAIN1;

  PROCEDURE CLOB_TO_STR_MAIN(IN_CLOB        in CLOB,
                             IN_PRIMARY_KEY IN VARCHAR2,
                             IN_PARAM       in VARCHAR2,
                             IN_ID          in number,
                             IN_TABLE_NAME  IN VARCHAR2) IS
    v_cnt1        NUMBER(3);
    v_cnt2        NUMBER(3);
    v_cnt3        NUMBER(3);
    V_CLOB        CLOB;
    V_PRIMARY_KEY VARCHAR2(10000);
    V_PARAM       VARCHAR2(10000);
    V_PARAM1      VARCHAR2(10000);
    n1            number;
    n2            number;
    m1            number;
    m2            number;
    m             number;
    q             number;
    o             number;
    o1            number;
    RESULT_TMP    VARCHAR2(10000);
    --RESULT        VARCHAR2(2000);
    t_PARAM      VARCHAR2(10000);
    p_PARAM      VARCHAR2(10000);
    t_PARAM_1    VARCHAR2(10000);
    V_MODI_MAN   VARCHAR2(50);
    V_ADD_TABLE  NUMBER := 0;
    v_table_name varchar(50);
    v_id         number;
    v_err_str    varchar2(10000);
    v_sql        varchar2(10000);
  BEGIN

    V_CLOB        := IN_CLOB;
    V_PRIMARY_KEY := IN_PRIMARY_KEY;
    V_PARAM       := IN_PARAM;
    v_param1      := IN_PARAM;
    v_cnt1        := GET_CHAR_CNT1(V_CLOB, '<' || V_PRIMARY_KEY || '>');
    v_cnt3        := GET_CHAR_CNT1(V_PARAM, ',');
    v_id          := in_id;
    v_table_name  := IN_TABLE_NAME; --V_MODI_MAN || '_' ||
    --to_char(sysdate, 'yyyymmddhh24miss');
    /*    begin
       v_sql := 'drop table ' || v_table_name;
       execute immediate v_sql;
     exception
       when others then
         null;
     end;
     begin
       v_sql := 'select count(*) from ' || v_table_name;
       EXECUTE immediate v_sql;
       o1 := 1;
     exception
       when others then
         v_sql := sqlerrm;
         o1    := 0;
     end;
    if o1 = 0 then
       v_sql := 'create table ' || v_table_name || ' (XML_TO_STR_ID NUMBER,' ||
                V_PRIMARY_KEY || ' VARCHAR2(200))';

       EXECUTE immediate v_sql;
     end if;
     if o1 = 0 then
       loop
         select instr(v_param1, ',') into o from dual;
         if o > 0 then
           select substr(v_param1, 0, o - 1) into p_PARAM from dual;
           execute immediate 'alter table ' || v_table_name || ' add (' ||
                             p_PARAM || ' varchar2(200))';
         else
           p_PARAM := v_param1;
           if p_param is not null then
             execute immediate 'alter table ' || v_table_name || ' add (' ||
                               p_PARAM || ' varchar2(200))';
           end if;
           exit;
         end if;
         begin
           select substr(v_param1, o + 1) into v_param1 from dual;
         end;
       end loop;
     end if;*/
    -- RESULT        := '';
    if V_PARAM is not null then
      V_PARAM   := ',' || V_PARAM || ',';
      t_PARAM_1 := substr(V_PARAM,
                          instr(V_PARAM, ',', 1, 1) + 1,
                          instr(V_PARAM, ',', 1, 2) -
                          instr(V_PARAM, ',', 1, 1) - 1);
      v_cnt2    := GET_CHAR_CNT1(V_CLOB, '<' || t_PARAM_1 || '>');
      --DBMS_OUTPUT.put_line('-----M:' || M);
      for i in 1 .. v_cnt1 loop
        ---定位IN_PRIMARY_KEY前后的位置，以判断对应的V_PARAM
        n1 := instr(V_CLOB, '<' || IN_PRIMARY_KEY || '>', 1, i);
        n2 := instr(V_CLOB, '<' || IN_PRIMARY_KEY || '>', 1, i + 1);

        if n2 <= 0 THEN
          n2 := 999999999;
        end if;
        for j in 1 .. v_cnt2 loop
          ---取第一个参数节点的位置
          m1 := instr(V_CLOB, '<' || t_PARAM_1 || '>', 1, j);
          m2 := instr(V_CLOB, '<' || t_PARAM_1 || '>', 1, j + 1);
          if m2 <= 0 THEN
            m2 := 999999999;
          end if;
          IF m1 > n1 and m1 < n2 THEN
            begin
              v_sql := 'update ' || v_table_name || ' set ' ||
                       V_PRIMARY_KEY || ' = ''' ||
                       CLOB_TO_STR_SINGLE1(V_CLOB, V_PRIMARY_KEY, i) ||
                       ''' where XML_TO_STR_ID =' || to_char(v_id);
              execute immediate v_sql;
            exception
              when others then
                v_err_str := sqlerrm;
            end;
            commit;
            /*            execute immediate 'insert into ' || v_table_name ||
                              ' (XML_TO_STR_ID,' || V_PRIMARY_KEY ||
                              ') values (' || v_id || ',' ||
                              CLOB_TO_STR_SINGLE1(V_CLOB, V_PRIMARY_KEY, i) || ')';
            commit;*/

            for k in 1 .. v_cnt3 + 1 loop
              -----对每个参数节点循环判断其位置是否位于第一个参数节点和第二个参数节点之间
              t_PARAM := substr(V_PARAM,
                                instr(V_PARAM, ',', 1, k) + 1,
                                instr(V_PARAM, ',', 1, k + 1) -
                                instr(V_PARAM, ',', 1, k) - 1);

              RESULT_TMP := '';
              q          := 0;
              for t in 1 .. v_cnt2 loop
                m := instr(V_CLOB, '<' || t_PARAM || '>', 1, t);
                --- DBMS_OUTPUT.put_line('-----t_PARAM-m:' || m);

                if m >= m1 and m < m2 then
                  if q = 0 then
                    RESULT_TMP := CLOB_TO_STR_SINGLE1(V_CLOB, t_PARAM, t);
                  else
                    RESULT_TMP := ',' || RESULT_TMP ||
                                  CLOB_TO_STR_SINGLE1(V_CLOB, t_PARAM, t);
                  end if;
                  q := q + 1;
                end if;
              end loop;
              commit;
              begin
                v_sql := 'update ' || v_table_name || ' set ' || t_PARAM ||
                         ' = ''' || RESULT_TMP ||
                         ''' where XML_TO_STR_ID =' || to_char(v_id);
                execute immediate v_sql;
              exception
                when others then
                  v_err_str := sqlerrm;
              end;
              commit;

            end loop;
            V_ADD_TABLE := 1;
          ELSE
            NULL;
          END IF;
        end loop;
      end loop;
    else
      for i in 1 .. v_cnt1 loop
        execute immediate 'insert into ' || v_table_name ||
                          ' (XML_TO_STR_ID,' || V_PRIMARY_KEY ||
                          ') values (' || v_id || ',''' ||
                          CLOB_TO_STR_SINGLE1(V_CLOB, V_PRIMARY_KEY, i) ||
                          ''')';
        commit;
      end loop;
    end if;

    COMMIT;
  exception
    when others then
      null;
  END CLOB_TO_STR_MAIN;

  function CLOB_TO_STR_SINGLE1(IN_CLOB   IN CLOB,
                               IN_COLUMN IN VARCHAR2,
                               IN_I      NUMBER) RETURN varchar2 IS
    V_CLOB   CLOB;
    V_COLUMN VARCHAR2(100);
    RESULT   VARCHAR2(4000);
    I        NUMBER(3);
  BEGIN
    V_CLOB   := IN_CLOB;
    V_COLUMN := IN_COLUMN;
    I        := IN_I;
    RESULT   := substr(V_CLOB,
                       instr(V_CLOB, '<' || IN_COLUMN || '>', 1, i) +
                       LENGTH(V_COLUMN) + 2,
                       instr(V_CLOB, '</' || IN_COLUMN || '>', 1, i) -
                       instr(V_CLOB, '<' || IN_COLUMN || '>', 1, i) -
                       LENGTH(V_COLUMN) - 2);
    RETURN RESULT;
  END CLOB_TO_STR_SINGLE1;

  FUNCTION GET_CHAR_CNT1(IN_CHAR CLOB, IN_CONDITION VARCHAR2) RETURN NUMBER IS
    V_SQL     VARCHAR2(10000);
    MAX_NUM   NUMBER(10) := 0;
    BEGIN_NUM NUMBER(10) := 0;
    V_INT     NUMBER(10) := 0;
  BEGIN
    V_SQL := IN_CHAR;
    SELECT INSTR(V_SQL, IN_CONDITION, '-1') INTO MAX_NUM FROM DUAL;
    SELECT INSTR(V_SQL, IN_CONDITION) INTO BEGIN_NUM FROM DUAL;
    <<P>>
    IF BEGIN_NUM > 0 AND BEGIN_NUM <> MAX_NUM THEN
      V_INT := V_INT + 1;
      SELECT INSTR(V_SQL, IN_CONDITION, BEGIN_NUM + 1)
        INTO BEGIN_NUM
        FROM DUAL;
      GOTO P;
    ELSIF BEGIN_NUM > 0 AND BEGIN_NUM = MAX_NUM THEN
      V_INT := V_INT + 1;
    ELSE
      NULL;
    END IF;
    RETURN V_INT;
  END GET_CHAR_CNT1;

END PKG_CLOB_TO_STR;
/
