CREATE PACKAGE           pkg_potential_cust_to_his IS
PROCEDURE insert_log(i_msg        IN VARCHAR2,
                       i_err        IN VARCHAR2,
                       i_key_id     IN NUMBER,
                       i_table_name IN VARCHAR2) ;
FUNCTION check_cust_cond(i_cust_id IN NUMBER, i_status_cd IN VARCHAR2)
    RETURN BOOLEAN;

FUNCTION move_to_his(i_cust_id IN NUMBER, i_rec_update_date IN DATE)
    RETURN BOOLEAN;

PROCEDURE move_potential_cust_to_his;

PROCEDURE main;

END pkg_potential_cust_to_his;
/
