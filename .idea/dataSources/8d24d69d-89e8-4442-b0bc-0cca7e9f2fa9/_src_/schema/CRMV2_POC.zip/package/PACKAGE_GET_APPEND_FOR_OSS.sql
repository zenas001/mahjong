CREATE package           package_get_append_for_oss is

  -- Author  : ADMIN
  -- Created : 2007-12-24 1024:1i:10
  procedure get_append_for_oss(IN_PROD_INST_ID           IN NUMBER,
                                               OUT_PROD_SPEC_CODE        out VARCHAR2,
                                               OUT_SERVICE_CODE          out VARCHAR2,
                                               APPEND_PROD_SPEC_CODE     out VARCHAR2,
                                               HAVING_APPEND_PROD_OR_NOT out VARCHAR2,
                                               LOCAL_NET_ID              out VARCHAR2,
                                               AREA_ID                   out VARCHAR2,
                                               BILL_TYPE                 out VARCHAR2,
                                               c_err_msg                 OUT VARCHAR2,
                                               n_ERR_NO                  OUT NUMBER);

end package_get_append_for_oss;
/
