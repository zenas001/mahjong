CREATE PACKAGE BODY           PKG_CRM_UTIL IS

PROCEDURE PROC_GET_NEXTVAL_NEW(TABLENAME     IN VARCHAR2,
                                                        SEQNAME       IN VARCHAR2,
                                                        O_RESULT      OUT VARCHAR2,
                                                        O_MSG OUT VARCHAR2,
                                                        O_NEXTVAL_NEW OUT NUMBER) IS
v_i number:= 10;
begin
loop
  begin
  O_NEXTVAL_NEW := FUNC_GET_NEXTVAL_NEW(TABLENAME, SEQNAME);
  EXCEPTION
     WHEN OTHERS then
        O_RESULT := -1;
        O_MSG := substr(SQLERRM, 0, 1000);
    end;
    v_i := v_i -1;
      if(O_NEXTVAL_NEW is not null and O_NEXTVAL_NEW != 0) then
          O_RESULT := 1;
          O_MSG := null;
      end if;
    exit when ((O_NEXTVAL_NEW is not null and O_NEXTVAL_NEW != 0) or v_i = 0);
 end loop;

END PROC_GET_NEXTVAL_NEW;

FUNCTION FUNC_GET_NEXTVAL_NEW(tableName in varchar2,
                                                seqName   in varchar2)
  RETURN NUMBER IS

  V_NEXTVAL     NUMBER(11) := 0;
  V_NEXTVAL_NEW NUMBER(11) := 0;
  v_sql         varchar2(512);
begin
    execute immediate 'SELECT ' || seqName || '_NEW.NEXTVAL FROM DUAL' INTO V_NEXTVAL;
    v_sql := 'SELECT ' || seqName || ' FROM ' || tableName || ' WHERE ID= ' || V_NEXTVAL;
    execute immediate v_sql into  V_NEXTVAL_NEW;
  RETURN V_NEXTVAL_NEW;

END FUNC_GET_NEXTVAL_NEW;

END PKG_CRM_UTIL;
/
