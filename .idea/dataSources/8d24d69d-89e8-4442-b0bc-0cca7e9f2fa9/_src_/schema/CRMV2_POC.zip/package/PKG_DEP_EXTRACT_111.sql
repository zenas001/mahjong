CREATE PACKAGE           PKG_DEP_EXTRACT_111 IS
  --批次号生成，格式 BUS_CODE||YYYYMMDDHH24MISS
  FUNCTION FUN_BATCH_NBR_CREATE(IN_BUS_CODE IN VARCHAR2) RETURN VARCHAR2;

  --文件名生成,格式 60010500011000000036BUS6001620140530U001.txt
  FUNCTION FUN_FILE_NAME_CREATE(IN_BUS_CODE        IN VARCHAR2, --业务功能编码
                                IN_USE_TYPE        IN VARCHAR2,
                                IN_CURRENT_PACKAGE IN NUMBER -- 分割批次次数
                                ) RETURN VARCHAR2;
  FUNCTION FUN_BUS90001_FILE_NAME_CREATE(IN_CURRENT_PACKAGE IN NUMBER -- 分割批次次数
                                         ) RETURN VARCHAR2;

  /** 共同体
   *  文件抽取 处理中，文件生成 等待中，文件上传 等待中
   *  按照10W条数据创建1个文件。
  */
  PROCEDURE PROC_DEP_COMMON(IN_BUS_CODE          IN VARCHAR2, --业务功能编码
                            IN_USE_TYPE          IN VARCHAR2,
                            IN_BATCH_NBR         IN VARCHAR2, --批次号
                            IN_CURRENT_PACKAGE   IN NUMBER, --分割批次号
                            IN_TOTAL_PACKAGE_NUM IN NUMBER); --分割次数总数

  /**
  * 数据抽取完后回填
  *
  * 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
  */
  PROCEDURE PROC_DEP_COMPLETE(IN_BUS_CODE  IN VARCHAR2,
                              IN_BATCH_NBR IN VARCHAR2);
  /*
  *清空数据中间表
  */
  PROCEDURE PROC_INIT_TABLE(IN_BUS_CODE IN VARCHAR2);
  /*
  分批次*/
  PROCEDURE PROC_CURRENT_PACKAGE_AVG(IN_TABLE_NAME       IN VARCHAR2,
                                     IN_BATCH_NBR        IN VARCHAR2,
                                     IN_MAX_NUMBER       IN INTEGER,
                                     O_TOTAL_PACKAGE_NUM OUT INTEGER);
  /*
  * 订单信息稽核 20140624 add by wangweibin
  */
  PROCEDURE PROC_BUS60016;
  /*
  * 订单费用稽核 20140707 add by lingy
  */
  PROCEDURE PROC_BUS60017;

  /*
  * 订单费用稽核 20140707 add by lingy
  */
  PROCEDURE PROC_BUS60018;
  /*
  * 卡资源稽核 20140707 add by lingy
  */
  PROCEDURE PROC_BUS60020;

  /*
  WAP比对稽核 add by linyx
  */
  PROCEDURE PROC_BUS24001;

  /* 4G产品实例日增量稽核*/
  procedure PROC_BUS60024;
  /* 4G产品实例月增量稽核*/
  procedure PROC_BUS60025;
  /* 4G销售品实例日增量稽核*/
  procedure PROC_BUS60026;
  /* 4G销售品实例月增量稽核*/
  procedure PROC_BUS60027;
  /*GG数据上传集团*/
  procedure PROC_GG_UPLOAD;
  /*IVPN数据上传集团*/
  procedure PROC_BUS23002;
  /*一点收费数据上传集团*/
  procedure PROC_BUS23001;
  /*省受理集团卡同步集团*/
  procedure PROC_BUS80009;
  /*精品渠道串码上传集团*/
  procedure PROC_BUS80010;
  /*
  * 上传号码及属性名称 20160107 add by xiely
  */
  PROCEDURE PROC_BUS90001(IN_ATTR_NAME IN VARCHAR2); --属性名
END PKG_DEP_EXTRACT_111;
/
