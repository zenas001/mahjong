CREATE PACKAGE           PKG_IMPORTPIMRES IS


  Function fun_saveNewPimRes(  v_PESN          in varchar2,
                               v_PROD_SPEC_ID in varchar2,
                               v_CARD_TYPE    in varchar2,
                               v_ACC_NBR      in varchar2,
                               v_AREA_CODE    in varchar2,
                               v_CAPABILITY   in varchar2,
                               v_UPIN2   in varchar2,
                               v_UPIN1   in varchar2,
                               v_PIN2    in varchar2,
                               v_PIN1    in varchar2,
                               v_PASSWD  in varchar2,
                               v_PSNM    in varchar2,
                               v_ICCID   in varchar2,
                               v_ICCS    in varchar2,
                               v_iccid_sub in varchar2,
                                v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
                               v_JTZK in varchar2, --增加节点 by lixj
             v_physicalSize in varchar2,---物理尺寸 by fangj
       v_cWSJ in varchar2,---C网数据 by fangj
             v_cGSM in varchar2,---C-G双模 by fangj
             v_nearFieldPaye in varchar2,---近场支付 by fangj
                               v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId  out varchar2,
                               o_msg     out varchar2
                           )return number;

  Function fun_saveUSIMRes(    v_PESN          in varchar2,
                               v_PROD_SPEC_ID in varchar2,
                               v_CARD_TYPE    in varchar2,
                               v_ACC_NBR      in varchar2,
                               v_AREA_CODE    in varchar2,
                               v_CAPABILITY   in varchar2,
                               v_UPIN2   in varchar2,
                               v_UPIN1   in varchar2,
                               v_PIN2    in varchar2,
                               v_PIN1    in varchar2,
                               v_PASSWD  in varchar2,
                               v_PSNM    in varchar2,
                               v_ICCID   in varchar2,
                               v_ICCS    in varchar2,
                               v_iccid_sub in varchar2,
                               v_UPIN1_AGENT    in varchar2,
                                v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
             v_JTZK in varchar2, --增加节点 by lixj
             v_physicalSize in varchar2,---物理尺寸 by fangj
       v_cWSJ in varchar2,---C网数据 by fangj
             v_cGSM in varchar2,---C-G双模 by fangj
             v_nearFieldPaye in varchar2,---近场支付 by fangj
                               v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId  out varchar2,
                               o_msg     out varchar2
                           )return number;

  Function fun_saveJKFLWGRes(      v_PESN          in varchar2,
                               v_PROD_SPEC_ID in varchar2,
                               v_CARD_TYPE    in varchar2,
                               v_ACC_NBR      in varchar2,
                               v_AREA_CODE    in varchar2,
                               v_CAPABILITY   in varchar2,
                               v_UPIN2   in varchar2,
                               v_UPIN1   in varchar2,
                               v_PIN2    in varchar2,
                               v_PIN1    in varchar2,
                               v_PASSWD  in varchar2,
                               v_PSNM    in varchar2,
                               v_ICCID   in varchar2,
                               v_ICCS    in varchar2,
                               v_iccid_sub in varchar2,
                               v_akey in varchar2,
                                v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
                               v_JTZK in varchar2, --增加节点 by lixj
                    v_physicalSize in varchar2,---物理尺寸 by fangj
        v_cWSJ in varchar2,---C网数据 by fangj
        v_cGSM in varchar2,---C-G双模 by fangj
        v_nearFieldPaye in varchar2,---近场支付 by fangj
                               v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId  out varchar2,
                               o_msg     out varchar2
                           )return number;



  PROCEDURE PROC_importPimRes( v_PESN          in varchar2,
                               v_PROD_SPEC_ID in varchar2,
                               v_CARD_TYPE    in varchar2,
                               v_ACC_NBR      in varchar2,
                               v_AREA_CODE    in varchar2,
                               v_CAPABILITY   in varchar2,
                               v_UPIN1   in varchar2,
                               v_UPIN2   in varchar2,
                               v_PIN2    in varchar2,
                               v_PIN1    in varchar2,
                               v_PASSWD  in varchar2,
                               v_PSNM    in varchar2,
                               v_ICCID   in varchar2,
                               i_ICCS    in varchar2,
                               v_UPIN1_AGENT    in varchar2,  -- 代理商 "UPIN1_AGENT"
                               v_akey    in varchar2,      -- e8-C机卡分离  "MY"
                               v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
             v_JTZK in varchar2, --增加节点 by lixj
             v_physicalSize in varchar2,---物理尺寸 by fangj
       v_cWSJ in varchar2,---C网数据 by fangj
             v_cGSM in varchar2,---C-G双模 by fangj
             v_nearFieldPaye in varchar2,---近场支付 by fangj
                               v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId  out varchar2,
                               o_result            out varchar2,  --校验编码
                               o_msg               out varchar2 --错误信息的返回
                           );
end PKG_IMPORTPIMRES;
/
