CREATE PACKAGE BODY           pkg_pk_itest IS

  ----2013-12-30--------------------------------------------------------------------------------
  --2）查询订单子项信息列表
  PROCEDURE pro_order_item_list(i_cust_so_number  IN VARCHAR2,
                                o_order_item_list OUT order_item_list) AS
    --未竣工
    CURSOR cur IS
      SELECT oi.*
        FROM customer_order co, order_item oi
       WHERE co.cust_order_id = oi.cust_order_id
         AND co.cust_so_number = i_cust_so_number;
    --已竣工
    CURSOR cur_his IS
      SELECT oi.*
        FROM customer_order_his co, order_item_his oi
       WHERE co.cust_order_id = oi.cust_order_id
         AND co.cust_so_number = i_cust_so_number;
    --临时定义
    o_order_item_rec_temp order_item_rec;

  BEGIN
    IF i_cust_so_number IS NOT NULL THEN
      --需要先初始化List
      o_order_item_list := order_item_list();
      --未竣工
      FOR rec IN cur LOOP
        o_order_item_rec_temp.order_item_id      := rec.order_item_id;
        o_order_item_rec_temp.order_item_type    := '';
        o_order_item_rec_temp.order_item_obj_id  := '';
        o_order_item_rec_temp.service_offer_name := '';
        o_order_item_rec_temp.status_name        := '';
        o_order_item_rec_temp.create_date        := rec.create_date;
        o_order_item_list.EXTEND;
        o_order_item_list(o_order_item_list.LAST) := o_order_item_rec_temp;
      END LOOP;
      --已竣工
      FOR rec_his IN cur_his LOOP
        o_order_item_rec_temp.order_item_id      := rec_his.order_item_id;
        o_order_item_rec_temp.order_item_type    := '';
        o_order_item_rec_temp.order_item_obj_id  := '';
        o_order_item_rec_temp.service_offer_name := '';
        o_order_item_rec_temp.status_name        := '';
        o_order_item_rec_temp.create_date        := rec_his.create_date;
        o_order_item_list.EXTEND;
        o_order_item_list(o_order_item_list.LAST) := o_order_item_rec_temp;
      END LOOP;
    END IF;
  END;
  ----2014-01-06--------------------------------------------------------------------------------
  --USIM卡和号码空闲判断
  PROCEDURE getnumberstatus(numtype   IN VARCHAR2, -- ‘1’天翼,‘2’固定电话,‘3’USIM卡号
                            numchar   IN VARCHAR2, -- USIM卡号
                            numstatus OUT VARCHAR2) AS --返回值是‘1’ 表示可用， ‘0’表示占用

  BEGIN
    IF numtype = 3 AND numchar IS NOT NULL THEN
      --‘3’USIM卡号
      SELECT decode(COUNT(a.mkt_reso_key), 1, 1, 0)
        INTO numstatus
        FROM crmv1.mkt_resource a
       WHERE a.state = '70A'
         AND a.mkt_reso_key = numchar;
    ELSIF numtype = 2 AND numchar IS NOT NULL THEN
      --‘2’固定电话（请加区号，如059187654321）
      SELECT decode(COUNT(a.prod_inst_id), 0, 1, 0)
        INTO numstatus
        FROM crmv2.prod_inst a
       WHERE a.area_code = substr(numchar, 1, 4)
         AND a.acc_nbr = substr(numchar, 5);
    ELSIF numtype = 1 AND numchar IS NOT NULL THEN
      -- ‘1’天翼
      SELECT decode(COUNT(a.prod_inst_id), 0, 1, 0)
        INTO numstatus
        FROM crmv2.prod_inst a
       WHERE a.acc_nbr = numchar;
    ELSE
      numstatus := 0;
    END IF;
  END;

END pkg_pk_itest;
/
