CREATE PACKAGE BODY           PKG_CRM IS
  /*
  封顶断网
  Author  : g.caijx
  Created : 2012-8-3
  */
  PROCEDURE PROC_WIRELESS_BROAD_STOP IS
    V_COUNT      NUMBER;
    V_HAS_FDDW   BOOLEAN := FALSE; --是否有'封顶断网'属性
    V_ATTR_VALUE PROD_INST_ATTR.ATTR_VALUE%TYPE; --'封顶断网'属性值
    V_PROD_INST  PROD_INST%ROWTYPE;

    V_PRODUCT_CODE    INTF_SO_SERV.PRODUCT_CODE%TYPE;
    V_INTF_SO_SERV_ID INTF_SO_SERV.INTF_SO_SERV_ID%TYPE;
    V_INTF_SO_BUSI_ID INTF_SO_BUSI.INTF_SO_BUSI_ID%TYPE;
    V_INTF_SO_ATTR_ID INTF_SO_ATTR.INTF_SO_ATTR_ID%TYPE;

    C_CHANNEL_NBR VARCHAR2(30) := '600105B018';
    V_ERR_CODE    NUMBER(1);
    V_ERR_MSG     VARCHAR2(1000);
  BEGIN
    FOR REC IN (SELECT *
                  FROM (SELECT *
                          FROM INTF_WIRELESS_BROAD_STOP_USER
                         WHERE CRM_STATE = '00A'
                         ORDER BY REC_ID)
                 WHERE ROWNUM < 1000) LOOP
      BEGIN
        V_ERR_CODE := 1;
        V_ERR_MSG  := NULL;
        --根据区号、接入号码、接入号码规格查询产品实例表并查询17（预开通）或18（充值开通）的数据
        BEGIN
          SELECT *
            INTO V_PROD_INST
            FROM PROD_INST PI
           WHERE PI.PROD_INST_ID = REC.PROD_ID;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20001, '档案不存在');
        END;

        --判断是否有在途单
        SELECT COUNT(*)
          INTO V_COUNT
          FROM ORDER_ITEM OI
         WHERE OI.CLASS_ID = '4'
           AND OI.ORDER_ITEM_OBJ_ID = REC.PROD_ID
           AND ROWNUM = 1;
        IF V_COUNT > 0 THEN
          RAISE_APPLICATION_ERROR(-20001, '有在途单');
        END IF;

        --查询INTF_SO_SERV判断是否存在待处理的记录，如果存在反馈失败，处理结束。
        SELECT COUNT(*)
          INTO V_COUNT
          FROM INTF_SO_SERV S
         WHERE S.PROD_INST_ID = REC.PROD_ID
           AND S.CHANNEL_NBR = C_CHANNEL_NBR
           AND S.STATE NOT IN ('70C', '70D')
           AND ROWNUM = 1;
        IF V_COUNT > 0 THEN
          RAISE_APPLICATION_ERROR(-20001, '该产品实例已有在途申请');
        END IF;

        --取 '封顶断网' 属性值
        BEGIN
          SELECT A.ATTR_VALUE
            INTO V_ATTR_VALUE
            FROM PROD_INST_ATTR A
           WHERE A.PROD_INST_ID = REC.PROD_ID
             AND A.ATTR_ID = 800000279 --800000279: 封顶断网状态
             AND A.STATUS_CD = '1000'
             AND ROWNUM = 1;
          V_HAS_FDDW := TRUE;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
        --如果属性值为 '在用'
        --则删除该属性，新增“被封顶断网“属性，回写计费数据crm_state=‘00B’和crm_state_date字段
        IF V_ATTR_VALUE = 'FDDW1' THEN
          --FDDW1: 在用
          BEGIN
            --记录标准对象服务INTF_SO_SERV
            SELECT SEQ_INTF_SO_SERV_ID.NEXTVAL
              INTO V_INTF_SO_SERV_ID
              FROM DUAL;

            SELECT P.EXT_PROD_ID
              INTO V_PRODUCT_CODE
              FROM PRODUCT P
             WHERE P.PRODUCT_ID = V_PROD_INST.PRODUCT_ID;

            INSERT INTO INTF_SO_SERV
              (INTF_SO_SERV_ID,
               ACC_NBR,
               PRODUCT_CODE,
               AREA_ID,
               PROD_INST_ID,
               CHANNEL_NBR,
               AREA_CODE)
            VALUES
              (V_INTF_SO_SERV_ID,
               V_PROD_INST.ACC_NBR,
               V_PRODUCT_CODE,
               V_PROD_INST.AREA_ID,
               V_PROD_INST.PROD_INST_ID,
               C_CHANNEL_NBR,
               V_PROD_INST.AREA_CODE);

            --记录标准对象业务INTF_SO_BUSI
            SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL
              INTO V_INTF_SO_BUSI_ID
              FROM DUAL;
            INSERT INTO INTF_SO_BUSI
              (INTF_SO_BUSI_ID,
               INTF_SO_SERV_ID,
               SERIAL_SEQ,
               BUSI_CODE,
               BUSI_TYPE,
               SERVICE_OFFER_CODE,
               OBJ_ID,
               ACTION_TYPE)
            VALUES
              (V_INTF_SO_BUSI_ID,
               V_INTF_SO_SERV_ID,
               0,
               V_PRODUCT_CODE,
               '1300',
               '4040100000', --[改产品信息]
               REC.PROD_ID,
               'M'); --[更新]

            --写入标准对象属性INTF_SO_ATTR
            SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL
              INTO V_INTF_SO_ATTR_ID
              FROM DUAL;
            INSERT INTO INTF_SO_ATTR
              (INTF_SO_ATTR_ID,
               INTF_SO_SERV_ID,
               INTF_SO_BUSI_ID,
               SERIAL_SEQ,
               ATTR_NBR,
               ATTR_VALUE)
            VALUES
              (V_INTF_SO_ATTR_ID,
               V_INTF_SO_SERV_ID,
               V_INTF_SO_BUSI_ID,
               0,
               '590000279', --590000279: 封顶断网
               '800000464' --800000464: 被封顶断网 attr_value_id
               );
          EXCEPTION
            WHEN OTHERS THEN
              RAISE_APPLICATION_ERROR(-20001,
                                      '插intf_so..表失败: ' || SQLERRM);

          END;
          ---处理完成 更新计费表
          UPDATE INTF_WIRELESS_BROAD_STOP_USER
             SET CRM_STATE = '00B', CRM_STATE_DATE = SYSDATE
           WHERE REC_ID = REC.REC_ID;

          --如果属性值为 '被封顶断网'
          --则无须处理，直接回写crm_state=‘00B’和crm_state_date;
        ELSIF V_ATTR_VALUE = 'FDDW2' THEN
          --FDDW2: 被封顶断网

          ---处理完成 更新计费表
          UPDATE INTF_WIRELESS_BROAD_STOP_USER
             SET CRM_STATE = '00B', CRM_STATE_DATE = SYSDATE
           WHERE REC_ID = REC.REC_ID;

          --如果没有 封顶断网 属性 或属性值为 '申请重新开机'
          --则将crm_state改为‘00C’，处理失败；需人工干预查原因；
        ELSIF NOT V_HAS_FDDW --没有 封顶断网 属性
              OR V_ATTR_VALUE = 'FDDW3' THEN
          --FDDW3: 申请重新开机

          ---处理完成 更新计费表
          UPDATE INTF_WIRELESS_BROAD_STOP_USER
             SET CRM_STATE = '00C', CRM_STATE_DATE = SYSDATE
           WHERE REC_ID = REC.REC_ID;
        END IF;
        V_ERR_CODE := 0;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          V_ERR_MSG := SQLERRM;
      END;

      --日志
      BEGIN
        INSERT INTO INTF_BROAD_STOP_LOG
          (INTF_BROAD_STOP_LOG_ID,
           JF_REC_ID,
           PROD_INST_ID,
           ATTR_VALUE,
           ERR_CODE,
           ERR_MSG,
           CREATE_DATE,
           UPDATE_DATE)
        VALUES
          (SEQ_INTF_BROAD_STOP_LOG_ID.NEXTVAL,
           REC.REC_ID,
           REC.PROD_ID,
           V_ATTR_VALUE,
           V_ERR_CODE,
           V_ERR_MSG,
           SYSDATE,
           SYSDATE);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
    END LOOP;
  END;

  /*
  封顶断网开机
  Author  : g.caijx
  Created : 2012-8-31
  */
  PROCEDURE PROC_WIRELESS_BROAD_STOP_JOB IS
    V_COUNT                 NUMBER(10);
    V_BEGIN_DATE            DATE;
    V_GOTIME                NUMBER(10) := 0;
    V_PROD_INST_A           PROD_INST%ROWTYPE;
    V_PRODUCT_Z             PRODUCT%ROWTYPE;
    V_PROD_INST_A_AREA_CODE AREA_CODE%ROWTYPE;

    C_CHANNEL_NBR               VARCHAR2(30) := '600105B018';
    V_ORDER_ITEM_PROC_ATTR_LIST PKG_TFJ.TYPE_ORDER_ITEM_PROC_ATTR_LIST;

    V_ERR_CODE NUMBER(1);
    V_ERR_MSG  VARCHAR2(1000);
    V_DONE_CNT NUMBER(10);
  BEGIN
    SELECT SYSDATE, EXTRACT(DAY FROM SYSDATE)
      INTO V_BEGIN_DATE, V_GOTIME
      FROM DUAL;

    IF V_GOTIME <> 1 THEN
      RETURN;
    END IF;

    /*FDDW1 在用
    FDDW2 被封顶断网
    FDDW3 申请重新开机*/
    FOR REC IN (SELECT A.PROD_INST_ID, A.ATTR_VALUE
                  FROM PROD_INST_ATTR A
                 WHERE A.ATTR_ID = 800000279 --800000279: 封顶断网状态
                   AND A.ATTR_VALUE IN ('FDDW2', 'FDDW3')
                   AND A.STATUS_CD = '1000') LOOP
     --如果INTF_WIRELESS_BROAD_STOP_USER表存在本月的被封顶断网数据,不再处理,进行下循环
     SELECT  COUNT(*) INTO V_DONE_CNT
       FROM  INTF_WIRELESS_BROAD_STOP_USER
      WHERE  PROD_ID = REC.PROD_INST_ID
        AND  CRM_STATE_DATE > TRUNC(SYSDATE,'MONTH') ;
      IF V_DONE_CNT > 0  THEN
          GOTO here;
      END IF;

      V_ERR_CODE := 1;
      V_ERR_MSG  := NULL;

      BEGIN
        SELECT *
          INTO V_PROD_INST_A
          FROM PROD_INST PI
         WHERE PI.PROD_INST_ID = REC.PROD_INST_ID;

        --如果号码在用且是'被封顶断网'状态, 则发起 '1X上网' '3G上网' 程控复机.
        IF V_PROD_INST_A.STATUS_CD = '100000' AND REC.ATTR_VALUE = 'FDDW2' THEN
          SELECT *
            INTO V_PROD_INST_A_AREA_CODE
            FROM AREA_CODE AC
           WHERE AC.REGION_ID = V_PROD_INST_A.COMMON_REGION_ID
             AND ROWNUM = 1;

          FOR REC1 IN (SELECT PIZ.*
                         FROM PROD_INST_REL PIR, PROD_INST PIZ
                        WHERE PIR.PROD_INST_A_ID =
                              V_PROD_INST_A.PROD_INST_ID
                          AND PIR.PROD_INST_Z_ID = PIZ.PROD_INST_ID
                          AND PIR.RELATION_TYPE_CD = '100600'
                         -- AND PIZ.PRODUCT_ID IN (800296775, 800303268) --800296775: 1X上网 , 800303268: 3G上网
                          /*
                          800296775: 1X上网 , 800303268: 3G上网  900960838:4G（LTE）上网
                          mod by liufzh 20140627  crm00056210  FJCRMV2.0_BUG_4G用户封顶断网后头次月没有恢复
                          PKG_CRM.PROC_WIRELESS_BROAD_STOP_JOB处理封顶断网开机只针对如果号码在用且是'被封顶断网'状态,
                          则发起 '1X上网' '3G上网' 程控复机.现在增加有4G（LTE）上网 900960838也要复机
                          */
                          AND PIZ.PRODUCT_ID IN (800296775, 800303268,900960838)
                       ) LOOP
            SELECT COUNT(*)
              INTO V_COUNT
              FROM TFJ_NWKCALL_CONFIG C
             WHERE C.MDSE_SPEC_ID = REC1.PRODUCT_ID
               AND C.PROD_SPEC_ID = V_PROD_INST_A.PRODUCT_ID
               AND '0' || C.AREA_ID = V_PROD_INST_A.AREA_CODE
               AND C.STATE = 'A'
               AND C.TFJ_FLAG = 'Y'
               AND ROWNUM = 1;

            IF V_COUNT > 0 THEN
              SELECT *
                INTO V_PRODUCT_Z
                FROM PRODUCT P
               WHERE P.PRODUCT_ID = REC1.PRODUCT_ID;

              INSERT INTO TFJ_WORK_ORDER_CDMA
                (ORDER_SERIAL_NBR,
                 PROD_SPEC_ID,
                 SERV_ID,
                 ACC_NBR,
                 ACTION,
                 ORDER_STATE,
                 SOURCE,
                 CREATE_DATE,
                 STATE,
                 STATE_DATE,
                 LATN_ID,
                 BUREAU_ID,
                 IF_QUOTA,
                 PRIORITY,
                 STAFF_ID,
                 COMMENTS,
                 AREA_ID,
                 MDSE_SPEC_ID,
                 SWD_ID,
                 INSERT_DATE,
                 EXCH_ID,
                 HLR_NBR,
                 STS,
                 STS_DATE,
                 OWE_QUOTA,
                 PAY_TYPE)
                SELECT SEQ_RDER_SERIAL_NBR_ID.NEXTVAL,
                       (SELECT P.EXT_PROD_ID
                          FROM PRODUCT P
                         WHERE P.PRODUCT_ID = V_PROD_INST_A.PRODUCT_ID),
                       V_PROD_INST_A.PROD_INST_ID,
                       V_PROD_INST_A.ACC_NBR,
                       '6',
                       '5SA',
                       '被封顶断网开机',
                       SYSDATE,
                       '5SN',
                       SYSDATE,
                       SUBSTR(V_PROD_INST_A_AREA_CODE.AREA_NBR, 1, 3),
                       V_PROD_INST_A_AREA_CODE.AREA_NBR,
                       'F',
                       '1',
                       '1',
                       NULL,
                       SUBSTR(V_PROD_INST_A_AREA_CODE.AREA_NBR, 1, 3),
                       V_PRODUCT_Z.EXT_PROD_ID,
                       '0',
                       SYSDATE,
                       NULL,
                       NULL,
                       '5SN',
                       SYSDATE,
                       NULL,
                       DECODE(V_PROD_INST_A.PAYMENT_MODE_CD,
                              '1201',
                              '1',
                              '1200',
                              '2',
                              '2100',
                              '3')
                  FROM DUAL;
            END IF;
          END LOOP;
        END IF;

        --V_COUNT 不等于0表示要将'封顶断网'属性置为'在用'
        V_COUNT := 0;
        IF (V_PROD_INST_A.STATUS_CD = '100000') THEN
          V_COUNT := 1;
        ELSE
          /*800000251: 欠费双停
          800013054: 欠费单停*/
          --判断是否是'单停'或'双停'
          /* crm00052394 加
          800000250: 预拆机 800000252: 违章停机 800000253: 用户申请停机 800000254: 挂失停机
          */
          SELECT COUNT(*)
            INTO V_COUNT
            FROM PROD_INST_ATTR A
           WHERE A.PROD_INST_ID = V_PROD_INST_A.PROD_INST_ID
             AND A.ATTR_ID IN (800000251, 800013054,800000250,800000252,800000253,800000254)
             AND A.STATUS_CD = '1000'
             AND ROWNUM = 1;
        END IF;

        IF V_COUNT > 0 THEN
          PKG_TFJ.PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST                 => V_PROD_INST_A,
                                              I_ACTION                    => 'M',
                                              I_ATTR_ID                   => 800000279, --800000279: 封顶断网状态
                                              I_ATTR_VALUE                => '800000463', --800000463: 在用(ATTR_VALUE_ID)
                                              I_CHANNEL_NBR               => C_CHANNEL_NBR,
                                              O_ORDER_ITEM_PROC_ATTR_LIST => V_ORDER_ITEM_PROC_ATTR_LIST);
        END IF;

        V_ERR_CODE := 0;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          V_ERR_MSG := SQLERRM;
      END;

      BEGIN
        --日志
        INSERT INTO INTF_BROAD_STOP_LOG
          (INTF_BROAD_STOP_LOG_ID,
           JF_REC_ID,
           PROD_INST_ID,
           ATTR_VALUE,
           ERR_CODE,
           ERR_MSG,
           CREATE_DATE,
           UPDATE_DATE)
        VALUES
          (SEQ_INTF_BROAD_STOP_LOG_ID.NEXTVAL,
           0,
           REC.PROD_INST_ID,
           REC.ATTR_VALUE,
           V_ERR_CODE,
           V_ERR_MSG,
           SYSDATE,
           SYSDATE);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      COMMIT;
      <<here>>
      V_DONE_CNT := 0;
    END LOOP;
  END;

  */
  /*短信发送*/
  PROCEDURE PROC_FOR_SMS(I_ORDER_ITEM_ID IN NUMBER, --订单项ID
                         I_CUST_ORDER_ID IN NUMBER, --客户订单ID
                         O_ERR_CODE      OUT NUMBER, --错误编码（0--成功 1--失败）
                         O_ERR_MSG       OUT VARCHAR2 --错误信息
                         ) IS
    v_content            varchar2(2048) := '';
    v_prod_inst_id       prod_inst.prod_inst_id%type; -- 订单项关联的产品，实例ID
    v_product_id         product.product_id%type; --订单项关联产品，产品规格ID
    v_prod_offer_id      prod_offer.prod_offer_id%type; --产品关联主销售品规格ID
    v_prod_offer_name    prod_offer.prod_offer_name%type; --产品关联主销售品名称
    v_prod_offer_inst_id prod_offer_inst.prod_offer_inst_id%type; --产品关联主销售品实例ID
    v_acc_nbr            prod_inst.acc_nbr%type; --订单项产联产品，业务号码
    v_area_code          prod_inst.area_code%type; --订单项产联产品，区号
    v_cust_id            prod_inst.owner_cust_id%type; --订单项产联产品,产权客户ID
    v_cust_name          party.party_name%type; --产权客户名称
    v_finish_time        prod_inst.finish_time%type; -- 订单项报竣的时间
    v_channel_id         customer_order.channel_id%type; --订单的受理渠道
    v_op_type            service_offer.op_type%type; --操作类型
    v_class_id           order_item.class_id%type;
    v_order_item_obj_id  order_item.order_item_obj_id%type;
    v_cust_so_number     customer_order.cust_so_number%type;
    v_offer_sub_type     prod_offer.offer_sub_type%type;
    v_region_name        common_region.region_name%type;
    v_contact_phone      varchar2(20) := '';
    v_time_wnd           number := 1;
    v_is_ej              number := 0;
    v_is_ykt             number := 0;
    v_temp               number := 0;
  begin
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    --查询订单信息
    begin
      select a.channel_id,
             b.order_item_obj_id,
             b.finish_time,
             b.class_id,
             c.op_type,
             a.cust_so_number
        into v_channel_id,
             v_order_item_obj_id,
             v_finish_time,
             v_class_id,
             v_op_type,
             v_cust_so_number
        from customer_order_his a, order_item_his b, service_offer c
       where a.cust_order_id = b.cust_order_id
         and b.service_offer_id = c.service_offer_id
         and b.order_item_id = i_order_item_id
         and a.cust_order_id = I_CUST_ORDER_ID;
    exception
      when no_data_found then
        begin
          select a.channel_id,
                 b.order_item_obj_id,
                 b.finish_time,
                 b.class_id,
                 c.op_type,
                 a.cust_so_number
            into v_channel_id,
                 v_order_item_obj_id,
                 v_finish_time,
                 v_class_id,
                 v_op_type,
                 v_cust_so_number
            from customer_order a, order_item b, service_offer c
           where a.cust_order_id = b.cust_order_id
             and b.service_offer_id = c.service_offer_id
             and b.order_item_id = i_order_item_id;
        exception
          when no_data_found then
            O_ERR_CODE := '1';
            O_ERR_MSG  := '订单不存在！' || sqlerrm;
            return;
        end;
    end;
    for rec in (select c.home_phone, c.office_phone, c.mobile_phone
                  from order_contact_info b, party_contact_info c
                 where b.Cust_Order_Id = I_CUST_ORDER_ID
                   and b.contact_id = c.contact_id) loop
      if length(rec.home_phone) = 11 and
         substr(rec.home_phone, 0, 3) in ('133', '153', '189', '180') then
        v_contact_phone := rec.home_phone;
        exit;
      elsif length(rec.office_phone) = 11 and
            substr(rec.office_phone, 0, 3) in ('133', '153', '189', '180') then
        v_contact_phone := rec.office_phone;
        exit;
      elsif length(rec.mobile_phone) = 11 and
            substr(rec.mobile_phone, 0, 3) in ('133', '153', '189', '180') then
        v_contact_phone := rec.mobile_phone;
        exit;
      end if;
    end loop;
    if v_contact_phone is null then
      for rec in (select c.home_phone, c.office_phone, c.mobile_phone
                    from order_contact_info_his b, party_contact_info c
                   where b.Cust_Order_Id = I_CUST_ORDER_ID
                     and b.contact_id = c.contact_id) loop
        if length(rec.home_phone) = 11 and
           substr(rec.home_phone, 0, 3) in ('133', '153', '189', '180') then
          v_contact_phone := rec.home_phone;
          exit;
        elsif length(rec.office_phone) = 11 and
              substr(rec.office_phone, 0, 3) in
              ('133', '153', '189', '180') then
          v_contact_phone := rec.office_phone;
          exit;
        elsif length(rec.mobile_phone) = 11 and
              substr(rec.mobile_phone, 0, 3) in
              ('133', '153', '189', '180') then
          v_contact_phone := rec.mobile_phone;
          exit;
        end if;
      end loop;
    end if;
    if v_class_id = 4 then
      --当class_id = 4时表示为产品订单项，获取产品信息
      begin
        select a.acc_nbr,
               a.area_code,
               a.product_id,
               a.owner_cust_id,
               a.prod_inst_id,
               b.region_name
          into v_acc_nbr,
               v_area_code,
               v_product_id,
               v_cust_id,
               v_prod_inst_id,
               v_region_name
          from prod_inst a, common_region b
         where a.prod_inst_id = v_order_item_obj_id
           and a.area_id = b.common_region_id;
        -- 根据预开通属性判断是否为预开通
        select count(*)
          into v_is_ykt
          from prod_inst_attr
         where prod_inst_id = v_prod_inst_id
           and attr_id = 800000280;
      exception
        when no_data_found then
          O_ERR_CODE := '1';
          O_ERR_MSG  := '产品不存在！' || sqlerrm;
          return;
      end;
    elsif v_class_id = 6 then
      --当class_id = 6时表示为销售品订单项，获取销售品信息
      begin
        select a.prod_offer_inst_id,
               a.prod_offer_id,
               a.cust_id,
               b.offer_sub_type,
               b.prod_offer_name,
               a.eff_date,
               c.area_code
          into v_prod_offer_inst_id,
               v_prod_offer_id,
               v_cust_id,
               v_offer_sub_type,
               v_prod_offer_name,
               v_finish_time,
               v_area_code
          from prod_offer_inst a, prod_offer b, area_code c
         where a.prod_offer_inst_id = v_order_item_obj_id
           and a.region_cd = c.region_id
           and a.prod_offer_id = b.prod_offer_id;
      exception
        when no_data_found then
          begin
            select distinct a.prod_offer_inst_id,
                            a.prod_offer_id,
                            a.cust_id
              into v_prod_offer_inst_id, v_prod_offer_id, v_cust_id
              from prod_offer_inst_his a
             where a.prod_offer_inst_id = v_order_item_obj_id;
          exception
            when no_data_found then
              O_ERR_CODE := '1';
              O_ERR_MSG  := '销售品不存在！' || sqlerrm;
              return;
          end;
      end;
      -- 判断是否为E家
      select count(a.prod_inst_id)
        into v_is_ej
        from offer_prod_inst_rel a, prod_offer_inst b, prod_offer c
       where a.prod_offer_inst_id = b.prod_offer_inst_id
         and b.prod_offer_id = c.prod_offer_id
         and c.offer_type = '11'
         and a.role_cd in (1, 2, 3, 2187)
         and a.prod_offer_inst_id = v_prod_offer_inst_id;
    end if;
    begin
      select b.party_name
        into v_cust_name
        from cust a, party b
       where a.party_id = b.party_id
         and a.cust_id = v_cust_id;
    exception
      when no_data_found then
        null;
    end;
    /**
    * 短信发送逻辑开始
    **/

    --产品订单项处理逻辑
    if v_class_id = 4 then
      begin
        if v_product_id = 800000002 then
          --天翼
          begin
            --天翼新装且非预开通 处理逻辑
            if v_op_type = '10' and v_is_ykt = 0 then
              for rec1 in (select b.prod_offer_inst_id,
                                  b.prod_offer_id,
                                  a.prod_offer_name,
                                  b.eff_date
                             from prod_offer          a,
                                  prod_offer_inst     b,
                                  offer_prod_inst_rel c
                            where b.prod_offer_inst_id =
                                  c.prod_offer_inst_id
                              and a.prod_offer_id = b.prod_offer_id
                              and c.prod_inst_id = v_prod_inst_id
                              and c.status_cd = '1000') loop
                if is_simple_access_offer(rec1.prod_offer_id) = 1 then
                  --crm00014331 天翼用户新装的发送条件为主套餐竣工（①前台受理：按系统竣工时间；②预开通用户以第一个电话结束后发送），直接发送短信通知本机：
                  -- 产品订单项，规格为移动语音，动作为新装，且销售品类型为单接入类销售品时，发送短信
                  v_content := '尊敬的客户:欢迎您使用中国电信天翼业务，您申请的“' ||
                               rec1.prod_offer_name || '”套餐于' ||
                               to_char(extract(year from rec1.eff_date)) || '年' ||
                               to_char(extract(month from rec1.eff_date)) || '月' ||
                               to_char(extract(day from rec1.eff_date)) ||
                               '日 生效。详询中国电信10000号';
                  proc_send_sms_for_log(v_area_code,
                                        v_acc_nbr,
                                        v_product_id,
                                        v_prod_inst_id,
                                        I_ORDER_ITEM_ID,
                                        v_cust_so_number,
                                        v_content,
                                        v_time_wnd,
                                        o_err_code,
                                        o_err_msg);
                  --crm00013964 FJREQ_五期_天翼用户入网后自动发送宣传短信的需求
                  proc_send_sms_crm00013946(v_area_code,
                                            v_acc_nbr,
                                            v_product_id,
                                            v_prod_inst_id,
                                            I_ORDER_ITEM_ID,
                                            v_cust_so_number,
                                            v_finish_time,
                                            v_time_wnd,
                                            o_err_code,
                                            o_err_msg);
                  --crm00025251 前台新装‘CDMA业务’同时 新装‘翼支付’附属功能，竣工时，给用户发送短信
                  for rec2 in (Select a.attr_value
                                 From mkt_res_inst_attr a,
                                      mkt_res_inst      b,
                                      prod_inst_attr    c
                                Where c.prod_inst_id = v_prod_inst_id
                                  And c.attr_id = '800000347' --天翼，USIM卡信息属性
                                  And b.mkt_res_inst_code = c.attr_value
                                  And a.mkt_res_inst_id = b.mkt_res_inst_id
                                  And a.attr_id = '800014505' --初始密码
                                  And c.status_Cd = '1000'
                                  and exists
                                (select 1
                                         from prod_inst_rel b
                                        where b.product_rel_id = 800304400 --天翼与翼支付关联
                                          and b.status_cd = '1000'
                                          and b.prod_inst_a_id =
                                              c.prod_inst_id)) loop
                    v_content := '尊敬的客户，您的天翼号码初始业务密码为' || rec2.attr_value ||
                                 '，请您及时登录电信网上营业厅www.fj.ct10000.com更改。';
                    proc_send_sms_for_log(v_area_code,
                                          v_acc_nbr,
                                          v_product_id,
                                          v_prod_inst_id,
                                          I_ORDER_ITEM_ID,
                                          v_cust_so_number,
                                          v_content,
                                          v_time_wnd,
                                          o_err_code,
                                          o_err_msg);
                  end loop;
                end if;
              end loop;
            elsif v_op_type = '11' then
              -- 天翼变更处理逻辑
              begin
                -- 历史表数据
                for rec in (select decode(b.eff_date,
                                          null,
                                          sysdate,
                                          b.eff_date) eff_date,
                                   d.prod_offer_name,
                                   d.prod_offer_id
                              from order_item_proc_attr_his a,
                                   offer_prod_inst_rel      b,
                                   prod_offer_inst          c,
                                   prod_offer               d
                             where a.order_item_id = I_ORDER_ITEM_ID
                               and a.class_id = 39
                               and b.offer_prod_inst_rel_id = a.obj_inst_id
                               and b.prod_offer_inst_id =
                                   c.prod_offer_inst_id
                               and c.prod_offer_id = d.prod_offer_id
                               and a.operate = '10') loop
                  if is_simple_access_offer(rec.prod_offer_id) = 1 then
                    --crm00014331 天翼用户变更套餐的发送条件为系统竣工时间，直接发送短信通知本机：
                    v_content := '尊敬的客户：您已成功办理天翼套餐变更业务，您申请的“' ||
                                 rec.prod_offer_name || '”套餐将于' ||
                                 to_char(extract(year from rec.eff_date)) || '年' ||
                                 to_char(extract(month from rec.eff_date)) || '月' ||
                                 to_char(extract(day from rec.eff_date)) ||
                                 '日 生效。详询中国电信10000号';
                    proc_send_sms_for_log(v_area_code,
                                          v_acc_nbr,
                                          v_product_id,
                                          v_prod_inst_id,
                                          I_ORDER_ITEM_ID,
                                          v_cust_so_number,
                                          v_content,
                                          v_time_wnd,
                                          o_err_code,
                                          o_err_msg);
                  end if;
                end loop;
                -- 查询1表数据
                for rec in (select decode(b.eff_date,
                                          null,
                                          sysdate,
                                          b.eff_date) eff_date,
                                   d.prod_offer_name,
                                   d.prod_offer_id
                              from order_item_proc_attr a,
                                   offer_prod_inst_rel  b,
                                   prod_offer_inst      c,
                                   prod_offer           d
                             where a.order_item_id = I_ORDER_ITEM_ID
                               and a.class_id = 39
                               and b.offer_prod_inst_rel_id = a.obj_inst_id
                               and b.prod_offer_inst_id =
                                   c.prod_offer_inst_id
                               and c.prod_offer_id = d.prod_offer_id
                               and a.operate = '10') loop
                  if is_simple_access_offer(rec.prod_offer_id) = 1 then
                    --crm00014331 天翼用户变更套餐的发送条件为系统竣工时间，直接发送短信通知本机：
                    v_content := '尊敬的客户：您已成功办理天翼套餐变更业务，您申请的“' ||
                                 rec.prod_offer_name || '”套餐将于' ||
                                 to_char(extract(year from rec.eff_date)) || '年' ||
                                 to_char(extract(month from rec.eff_date)) || '月' ||
                                 to_char(extract(day from rec.eff_date)) ||
                                 '日 生效。详询中国电信10000号';
                    proc_send_sms_for_log(v_area_code,
                                          v_acc_nbr,
                                          v_product_id,
                                          v_prod_inst_id,
                                          I_ORDER_ITEM_ID,
                                          v_cust_so_number,
                                          v_content,
                                          v_time_wnd,
                                          o_err_code,
                                          o_err_msg);
                  end if;
                end loop;
                select count(*)
                  into v_temp
                  from order_item_proc_attr_his a
                 where a.order_item_id = i_order_item_id
                   and a.obj_inst_id = v_prod_inst_id
                   and a.class_id = 4
                   and a.obj_attr_id = 800000280 --预开通属性
                   and a.operate = '12'; --删除动作
                if v_temp > 0 then
                  for rec1 in (select b.prod_offer_inst_id,
                                      b.prod_offer_id,
                                      a.prod_offer_name,
                                      b.eff_date
                                 from prod_offer_inst     b,
                                      offer_prod_inst_rel c,
                                      prod_offer          a
                                where b.prod_offer_inst_id =
                                      c.prod_offer_inst_id
                                  and c.status_cd = '1000'
                                  and c.prod_inst_id = v_prod_inst_id
                                  and b.prod_offer_id = a.prod_offer_id) loop
                    if is_simple_access_offer(rec1.prod_offer_id) = 1 then
                      --crm00014331 天翼用户新装的发送条件为主套餐竣工（①前台受理：按系统竣工时间；②预开通用户以第一个电话结束后发送），直接发送短信通知本机：
                      -- 产品订单项，规格为移动语音，动作为新装，且销售品类型为单接入类销售品时，发送短信
                      v_content := '尊敬的客户:欢迎您使用中国电信天翼业务，您申请的“' ||
                                   rec1.prod_offer_name || '”套餐于' ||
                                   to_char(extract(year from v_finish_time)) || '年' ||
                                   to_char(extract(month from v_finish_time)) || '月' ||
                                   to_char(extract(day from v_finish_time)) ||
                                   '日 生效。详询中国电信10000号';
                      proc_send_sms_for_log(v_area_code,
                                            v_acc_nbr,
                                            v_product_id,
                                            v_prod_inst_id,
                                            I_ORDER_ITEM_ID,
                                            v_cust_so_number,
                                            v_content,
                                            v_time_wnd,
                                            o_err_code,
                                            o_err_msg);
                      --crm00013964 FJREQ_五期_天翼用户入网后自动发送宣传短信的需求
                      proc_send_sms_crm00013946(v_area_code,
                                                v_acc_nbr,
                                                v_product_id,
                                                v_prod_inst_id,
                                                I_ORDER_ITEM_ID,
                                                v_cust_so_number,
                                                v_finish_time,
                                                v_time_wnd,
                                                o_err_code,
                                                o_err_msg);
                    end if;
                  end loop;
                end if;
                --亲情短号码属性变更的短信发送逻辑
                proc_send_sms_for_change_qqdhm(I_ORDER_ITEM_ID,
                                               I_CUST_ORDER_ID,
                                               v_cust_so_number,
                                               v_time_wnd,
                                               o_err_code,
                                               o_err_msg);
              end;
            end if;
          end;
        elsif v_product_id = 800000008 and v_op_type = '10' then
          --有线宽带新装处理逻辑
          begin
            --crm00028205 子单_关于新装宽带用户实现统一账号的IT需求_接口
            for rec in (select a.area_code,
                               a.acc_nbr,
                               a.product_id,
                               a.prod_inst_id
                          from prod_inst_rel b, prod_inst a
                         where b.prod_inst_a_id = v_prod_inst_id
                           and b.product_rel_id = 800082444
                           and b.prod_inst_z_id = a.prod_inst_id
                           and a.product_id = 800000002
                           and b.status_cd = '1000') loop
              v_content := '尊敬的客户，您的天翼宽带账号即为您的手机号。编辑免费短信w，发送到10001，即可查询宽带上网密码。温馨提示：如果您的账户欠费，将导致手机和宽带无法使用。';
              proc_send_sms_for_log(rec.area_code,
                                    rec.acc_nbr,
                                    rec.product_id,
                                    rec.prod_inst_id,
                                    I_ORDER_ITEM_ID,
                                    v_cust_so_number,
                                    v_content,
                                    v_time_wnd,
                                    o_err_code,
                                    o_err_msg);
            end loop;

          end;
        elsif v_product_id = 800000054 and v_op_type = '10' then
          begin
            --crm00030200 虚号码新装竣工时发短信给主号码
            for rec in (select b.acc_nbr,
                               b.prod_inst_id,
                               b.product_id,
                               b.area_code
                          from prod_inst_rel  a,
                               prod_inst      b,
                               prod_inst_attr c
                         where a.prod_inst_z_id = c.prod_inst_id
                           and c.attr_id = 800004083 --主号码ID
                           and c.attr_value = b.prod_inst_id
                           and a.product_rel_id = 18283 --一卡双号与天翼关联
                           and a.prod_inst_a_id = v_prod_inst_id) loop
              v_content := '尊敬的用户,您的号码' || rec.acc_nbr || '上已成功受理了一个' ||
                           v_region_name || '的虚号码' || v_acc_nbr || ',您的号码' ||
                           rec.acc_nbr || '在' || v_region_name ||
                           '漫游时,拨打国内电话或手机上网按本地电话计费的规则已生效!';
              proc_send_sms_for_log(rec.area_code,
                                    rec.acc_nbr,
                                    rec.product_id,
                                    rec.prod_inst_id,
                                    I_ORDER_ITEM_ID,
                                    v_cust_so_number,
                                    v_content,
                                    v_time_wnd,
                                    o_err_code,
                                    o_err_msg);
            end loop;
          end;
        end if;
      end;
    elsif v_class_id = 6 then
      --销售品订单项处理逻辑
      begin
        if v_is_ej > 0 then
          if v_contact_phone is not null then
            -- E家受理时，发送信息给订单联系人
            for rec3 in (select a.content1, a.content2, a.content3, a.rule
                           from sms_content_config a
                          where a.acc_nbr_type = 'orderContact'
                            and a.busi_type = 'ej'
                            and a.op_type = v_op_type
                            and a.class_id = 6
                            and a.spec_id = v_prod_offer_id) loop
              if rec3.rule = 'wsx' and
                 nvl(v_finish_time, sysdate) > sysdate then
                v_content := rec3.content1;
                if rec3.content2 is not null then
                  v_content := v_content || v_prod_offer_name ||
                               rec3.content2;
                end if;
                if rec3.content3 is not null then
                  v_content := v_content ||
                               to_char(extract(year from v_finish_time)) || '年' ||
                               to_char(extract(month from v_finish_time)) || '月' ||
                               to_char(extract(day from v_finish_time)) ||
                               rec3.content3;
                end if;
                proc_send_sms_for_log(v_area_code,
                                      v_contact_phone,
                                      '800000002',
                                      v_prod_inst_id,
                                      I_ORDER_ITEM_ID,
                                      v_cust_so_number,
                                      v_content,
                                      v_time_wnd,
                                      o_err_code,
                                      o_err_msg);
              elsif rec3.rule = 'ysx' and
                    nvl(v_finish_time, sysdate) <= sysdate then
                v_content := rec3.content1;
                if rec3.content2 is not null then
                  v_content := v_content || v_prod_offer_name ||
                               rec3.content2;
                end if;
                if rec3.content3 is not null then
                  v_content := v_content ||
                               to_char(extract(year from v_finish_time)) || '年' ||
                               to_char(extract(month from v_finish_time)) || '月' ||
                               to_char(extract(day from v_finish_time)) ||
                               rec3.content3;
                end if;
                proc_send_sms_for_log(v_area_code,
                                      v_contact_phone,
                                      '800000002',
                                      v_prod_inst_id,
                                      I_ORDER_ITEM_ID,
                                      v_cust_so_number,
                                      v_content,
                                      v_time_wnd,
                                      o_err_code,
                                      o_err_msg);
              end if;
            end loop;
          end if;
          if v_op_type = '10' then
            for rec in (select decode(b.eff_date, null, sysdate, b.eff_date) eff_date,
                               decode(b.exp_date, null, sysdate, b.exp_date) exp_date,
                               c.operate,
                               d.area_code,
                               d.acc_nbr,
                               a.product_id,
                               d.prod_inst_id,
                               b.role_cd,
                               e.role_name
                          from offer_prod_rel           a,
                               offer_prod_inst_rel      b,
                               order_item_proc_attr_his c,
                               prod_inst                d,
                               offer_prod_rel_role      e
                         where c.order_item_id = I_ORDER_ITEM_ID
                           and c.class_id = 39
                           and c.obj_inst_id = b.offer_prod_inst_rel_id
                           and a.product_id = 800000002
                           and a.offer_prod_rela_id = b.offer_prod_rel_id
                           and b.prod_inst_id = d.prod_inst_id
                           and b.role_cd = e.role_cd(+)
                           and a.prod_offer_id = v_prod_offer_id
                           and b.prod_offer_inst_id = v_prod_offer_inst_id) loop
              if rec.role_cd = 2 then
                --crm00014331 E家新装，套餐竣工后，发送短信通知套餐内的天翼手机（基础包）
                v_content := '尊敬的客户：欢迎您成为中国电信"我的e家"品牌客户,您申请的' ||
                             v_prod_offer_name || '套餐将于 ' ||
                             to_char(extract(year from rec.eff_date)) || '年' ||
                             to_char(extract(month from rec.eff_date)) || '月' ||
                             to_char(extract(day from rec.eff_date)) ||
                             '日 生效。 详情咨询客服热线10000号.';
              else
                --crm00014331 E家新装，套餐竣工后，发送短信通知套餐内的天翼手机（可选包）
                v_content := '您已成功加入 ' || v_cust_name || ' 客户的“' ||
                             v_prod_offer_name || '”套餐，您申请的' ||
                             rec.role_name || '于' ||
                             to_char(extract(year from rec.eff_date)) || '年' ||
                             to_char(extract(month from rec.eff_date)) || '月' ||
                             to_char(extract(day from rec.eff_date)) ||
                             '日 生效。详询中国电信10000号';
              end if;
              select count(1)
                into v_temp
                from sms_content_config a
               where a.class_id = 6
                 and a.spec_id = v_prod_offer_id
                 and a.acc_nbr_type = 'orderContact'
                 and a.busi_type in ('kxb', 'jcb');
              if v_temp > 0 and v_contact_phone is not null then
                proc_send_sms_for_log(rec.area_code,
                                      v_contact_phone,
                                      rec.product_id,
                                      rec.prod_inst_id,
                                      I_ORDER_ITEM_ID,
                                      v_cust_so_number,
                                      v_content,
                                      v_time_wnd,
                                      o_err_code,
                                      o_err_msg);
              else
                proc_send_sms_for_log(rec.area_code,
                                      rec.acc_nbr,
                                      rec.product_id,
                                      rec.prod_inst_id,
                                      I_ORDER_ITEM_ID,
                                      v_cust_so_number,
                                      v_content,
                                      v_time_wnd,
                                      o_err_code,
                                      o_err_msg);
              end if;
            end loop;
          elsif v_op_type = '11' then
            for rec in (select obj_inst_id, operate
                          from order_item_proc_attr_his a
                         where a.class_id = 39
                           and a.order_item_id = i_order_item_id) loop
              if rec.operate = '10' then
                --关系新增时，查1表的销售品产品实例关系
                for rec1 in (select decode(b.eff_date,
                                           null,
                                           sysdate,
                                           b.eff_date) eff_date,
                                    decode(b.exp_date,
                                           null,
                                           sysdate,
                                           b.exp_date) exp_date,
                                    d.area_code,
                                    d.acc_nbr,
                                    a.product_id,
                                    d.prod_inst_id,
                                    b.role_cd,
                                    e.role_name
                               from offer_prod_rel      a,
                                    offer_prod_inst_rel b,
                                    prod_inst           d,
                                    offer_prod_rel_role e
                              where b.offer_prod_inst_rel_id =
                                    rec.obj_inst_id
                                and a.product_id = 800000002
                                and a.offer_prod_rela_id =
                                    b.offer_prod_rel_id
                                and b.prod_inst_id = d.prod_inst_id
                                and b.role_cd = e.role_cd(+)
                                and a.prod_offer_id = v_prod_offer_id
                                and b.prod_offer_inst_id =
                                    v_prod_offer_inst_id
                                and rownum = 1) loop
                  if rec1.role_cd = 2 then
                    --crm00014331 E家新装，套餐竣工后，发送短信通知套餐内的天翼手机（基础包）
                    v_content := '尊敬的客户：欢迎您成为中国电信"我的e家"品牌客户,您申请的' ||
                                 v_prod_offer_name || '套餐将于 ' ||
                                 to_char(extract(year from rec1.eff_date)) || '年' ||
                                 to_char(extract(month from rec1.eff_date)) || '月' ||
                                 to_char(extract(day from rec1.eff_date)) ||
                                 '日 生效。 详情咨询客服热线10000号.';
                  else
                    --crm00014331 E家新装，套餐竣工后，发送短信通知套餐内的天翼手机（可选包）
                    v_content := '您已成功加入 ' || v_cust_name || ' 客户的“' ||
                                 v_prod_offer_name || '”套餐，您申请的' ||
                                 rec1.role_name || '于' ||
                                 to_char(extract(year from rec1.eff_date)) || '年' ||
                                 to_char(extract(month from rec1.eff_date)) || '月' ||
                                 to_char(extract(day from rec1.eff_date)) ||
                                 '日 生效。详询中国电信10000号';
                  end if;
                  proc_send_sms_for_log(rec1.area_code,
                                        rec1.acc_nbr,
                                        rec1.product_id,
                                        rec1.prod_inst_id,
                                        I_ORDER_ITEM_ID,
                                        v_cust_so_number,
                                        v_content,
                                        v_time_wnd,
                                        o_err_code,
                                        o_err_msg);
                end loop;
              else
                --关系删除时，查询2表的销售品产品实例关系
                for rec1 in (select decode(b.eff_date,
                                           null,
                                           sysdate,
                                           b.eff_date) eff_date,
                                    decode(b.exp_date,
                                           null,
                                           sysdate,
                                           b.exp_date) exp_date,
                                    d.area_code,
                                    d.acc_nbr,
                                    a.product_id,
                                    d.prod_inst_id,
                                    b.role_cd,
                                    e.role_name
                               from offer_prod_rel          a,
                                    offer_prod_inst_rel_his b,
                                    prod_inst               d,
                                    offer_prod_rel_role     e
                              where b.offer_prod_inst_rel_id =
                                    rec.obj_inst_id
                                and a.product_id = 800000002
                                and a.offer_prod_rela_id =
                                    b.offer_prod_rel_id
                                and b.prod_inst_id = d.prod_inst_id
                                and b.role_cd = e.role_cd(+)
                                and a.prod_offer_id = v_prod_offer_id
                                and b.prod_offer_inst_id =
                                    v_prod_offer_inst_id
                                and exists
                              (select 1
                                       from (select distinct offer_prod_inst_rel_id,
                                                             max(his_id) over(partition by offer_prod_inst_rel_id) as max_his_id
                                               from offer_prod_inst_rel_his f) t
                                      where b.his_id = t.max_his_id
                                        and b.offer_prod_inst_rel_id =
                                            t.offer_prod_inst_rel_id)) loop
                  --crm00014331 E家变更，套餐竣工后，发送短信通知套餐内的天翼手机
                  v_content := '您已成功退出 ' || v_cust_name || ' 客户的“' ||
                               v_prod_offer_name || '”套餐，您申请的' ||
                               rec1.role_name || '于' ||
                               to_char(extract(year from rec1.exp_date)) || '年' ||
                               to_char(extract(month from rec1.exp_date)) || '月' ||
                               to_char(extract(day from rec1.exp_date)) ||
                               '日 失效。详询中国电信10000号';
                  proc_send_sms_for_log(rec1.area_code,
                                        rec1.acc_nbr,
                                        rec1.product_id,
                                        rec1.prod_inst_id,
                                        I_ORDER_ITEM_ID,
                                        v_cust_so_number,
                                        v_content,
                                        v_time_wnd,
                                        o_err_code,
                                        o_err_msg);
                end loop;
              end if;
            end loop;
          end if;
          --总机服务
        elsif v_prod_offer_id = 800001245 then
          begin
            --crm00014331新装总机服务套餐，套餐竣工后，发送短信通知
            if v_op_type = '10' then
              for rec in (select decode(b.eff_date,
                                        null,
                                        sysdate,
                                        b.eff_date) eff_date,
                                 decode(b.exp_date,
                                        null,
                                        sysdate,
                                        b.exp_date) exp_date,
                                 c.operate,
                                 d.area_code,
                                 d.acc_nbr,
                                 a.product_id,
                                 d.prod_inst_id
                            from offer_prod_rel           a,
                                 offer_prod_inst_rel      b,
                                 order_item_proc_attr_his c,
                                 prod_inst                d
                           where c.order_item_id = I_ORDER_ITEM_ID
                             and c.class_id = 39
                             and c.obj_inst_id = b.offer_prod_inst_rel_id
                             and a.product_id = 800000002
                             and a.offer_prod_rela_id = b.offer_prod_rel_id
                             and b.prod_inst_id = d.prod_inst_id
                             and a.prod_offer_id = v_prod_offer_id
                             and b.prod_offer_inst_id = v_prod_offer_inst_id) loop
                --crm00014331新装总机服务套餐，套餐竣工后，发送短信通知加装包本机
                v_content := '尊敬的客户：欢迎您使用中国电信总机服务，您申请的总机服务套餐将于' ||
                             to_char(extract(year from rec.eff_date)) || '年' ||
                             to_char(extract(month from rec.eff_date)) || '月' ||
                             to_char(extract(day from rec.eff_date)) ||
                             '日 生效。详询中国电信10000号';
                proc_send_sms_for_log(rec.area_code,
                                      rec.acc_nbr,
                                      rec.product_id,
                                      rec.prod_inst_id,
                                      I_ORDER_ITEM_ID,
                                      v_cust_so_number,
                                      v_content,
                                      v_time_wnd,
                                      o_err_code,
                                      o_err_msg);
              end loop;
            else
              for rec in (select obj_inst_id, operate
                            from order_item_proc_attr_his a
                           where a.class_id = 39
                             and a.order_item_id = i_order_item_id) loop
                if rec.operate = '10' then
                  --关系新增时，查1表的销售品产品实例关系
                  for rec1 in (select decode(b.eff_date,
                                             null,
                                             sysdate,
                                             b.eff_date) eff_date,
                                      decode(b.exp_date,
                                             null,
                                             sysdate,
                                             b.exp_date) exp_date,
                                      d.area_code,
                                      d.acc_nbr,
                                      a.product_id,
                                      d.prod_inst_id,
                                      b.role_cd,
                                      e.role_name
                                 from offer_prod_rel      a,
                                      offer_prod_inst_rel b,
                                      prod_inst           d,
                                      offer_prod_rel_role e
                                where b.offer_prod_inst_rel_id =
                                      rec.obj_inst_id
                                  and a.product_id = 800000002
                                  and a.offer_prod_rela_id =
                                      b.offer_prod_rel_id
                                  and b.prod_inst_id = d.prod_inst_id
                                  and b.role_cd = e.role_cd(+)
                                  and a.prod_offer_id = v_prod_offer_id
                                  and b.prod_offer_inst_id =
                                      v_prod_offer_inst_id
                                  and rownum = 1) loop
                    --crm00014331 总机服务套餐变更：加装包入网，发送短信通知加装包本机
                    v_content := '尊敬的客户:您已成功加入总机服务，将于' ||
                                 to_char(extract(year from rec1.eff_date)) || '年' ||
                                 to_char(extract(month from rec1.eff_date)) || '月' ||
                                 to_char(extract(day from rec1.eff_date)) ||
                                 '日 生效。详询中国电信10000号';
                    proc_send_sms_for_log(rec1.area_code,
                                          rec1.acc_nbr,
                                          rec1.product_id,
                                          rec1.prod_inst_id,
                                          I_ORDER_ITEM_ID,
                                          v_cust_so_number,
                                          v_content,
                                          v_time_wnd,
                                          o_err_code,
                                          o_err_msg);
                  end loop;
                else
                  --关系删除时，查询2表的销售品产品实例关系
                  for rec1 in (select decode(b.eff_date,
                                             null,
                                             sysdate,
                                             b.eff_date) eff_date,
                                      decode(b.exp_date,
                                             null,
                                             sysdate,
                                             b.exp_date) exp_date,
                                      d.area_code,
                                      d.acc_nbr,
                                      a.product_id,
                                      d.prod_inst_id,
                                      b.role_cd,
                                      e.role_name
                                 from offer_prod_rel          a,
                                      offer_prod_inst_rel_his b,
                                      prod_inst               d,
                                      offer_prod_rel_role     e
                                where b.offer_prod_inst_rel_id =
                                      rec.obj_inst_id
                                  and a.product_id = 800000002
                                  and a.offer_prod_rela_id =
                                      b.offer_prod_rel_id
                                  and b.prod_inst_id = d.prod_inst_id
                                  and b.role_cd = e.role_cd(+)
                                  and a.prod_offer_id = v_prod_offer_id
                                  and b.prod_offer_inst_id =
                                      v_prod_offer_inst_id
                                  and exists
                                (select 1
                                         from (select distinct offer_prod_inst_rel_id,
                                                               max(his_id) over(partition by offer_prod_inst_rel_id) as max_his_id
                                                 from offer_prod_inst_rel_his f) t
                                        where b.his_id = t.max_his_id
                                          and b.offer_prod_inst_rel_id =
                                              t.offer_prod_inst_rel_id)) loop
                    --crm00014331 总机服务套餐变更：加装包退网，发送短信通知加装包本机
                    v_content := '尊敬的客户:您已成功退出总机服务，将于' ||
                                 to_char(extract(year from rec1.exp_date)) || '年' ||
                                 to_char(extract(month from rec1.exp_date)) || '月' ||
                                 to_char(extract(day from rec1.exp_date)) ||
                                 '日 失效。详询中国电信10000号';
                    proc_send_sms_for_log(rec1.area_code,
                                          rec1.acc_nbr,
                                          rec1.product_id,
                                          rec1.prod_inst_id,
                                          I_ORDER_ITEM_ID,
                                          v_cust_so_number,
                                          v_content,
                                          v_time_wnd,
                                          o_err_code,
                                          o_err_msg);
                  end loop;
                end if;
              end loop;
            end if;
          end;
          --亲情短号
        elsif v_prod_offer_id = 800771865 then
          proc_send_sms_for_qqdh(I_ORDER_ITEM_ID,
                                 I_CUST_ORDER_ID,
                                 v_cust_so_number,
                                 v_time_wnd,
                                 o_err_code,
                                 o_err_msg);
        else
          --非特殊处理的销售品，根据配置表数据发送短信
          for rec4 in (select a.content1,
                              a.content2,
                              a.content3,
                              a.rule,
                              a.acc_nbr_type
                         from sms_content_config a
                        where a.op_type = v_op_type
                          and a.class_id = 6
                          and (a.busi_type is null or
                              a.busi_type not in ('ej', 'kxb', 'jcb'))
                          and a.spec_id = v_prod_offer_id) loop
            if rec4.rule = 'wsx' then
              if nvl(v_finish_time, sysdate) > sysdate then
                -- 未生效
                v_content := rec4.content1;
                if rec4.content2 is not null then
                  v_content := v_content || v_prod_offer_name ||
                               rec4.content2;
                end if;
                if rec4.content3 is not null then
                  v_content := v_content ||
                               to_char(extract(year from v_finish_time)) || '年' ||
                               to_char(extract(month from v_finish_time)) || '月' ||
                               to_char(extract(day from v_finish_time)) ||
                               rec4.content3;
                end if;
              end if;
            elsif rec4.rule = 'ysx' then
              if nvl(v_finish_time, sysdate) <= sysdate then
                -- 已生效
                v_content := rec4.content1;
                if rec4.content2 is not null then
                  v_content := v_content || v_prod_offer_name ||
                               rec4.content2;
                end if;
                if rec4.content3 is not null then
                  v_content := v_content ||
                               to_char(extract(year from v_finish_time)) || '年' ||
                               to_char(extract(month from v_finish_time)) || '月' ||
                               to_char(extract(day from v_finish_time)) ||
                               rec4.content3;
                end if;
              end if;
            else
              -- 不区分生效时间
              v_content := rec4.content1;
              if rec4.content2 is not null then
                v_content := v_content || v_prod_offer_name ||
                             rec4.content2;
              end if;
              if rec4.content3 is not null then
                v_content := v_content ||
                             to_char(extract(year from v_finish_time)) || '年' ||
                             to_char(extract(month from v_finish_time)) || '月' ||
                             to_char(extract(day from v_finish_time)) ||
                             rec4.content3;
              end if;
            end if;
            --短信发送给订单联系人
            if rec4.acc_nbr_type = 'orderContact' and
               v_contact_phone is not null then
              proc_send_sms_for_log(v_area_code,
                                    v_contact_phone,
                                    '800000002',
                                    v_prod_inst_id,
                                    I_ORDER_ITEM_ID,
                                    v_cust_so_number,
                                    v_content,
                                    v_time_wnd,
                                    o_err_code,
                                    o_err_msg);
            elsif v_offer_sub_type = 'T02' then
              --功能类基础销售品，短信发送给销售品关联的程控关联的天翼
              --新装时从1表取数据
              if v_op_type = '10' then
                begin
                  select c.area_code,
                         c.acc_nbr,
                         c.product_id,
                         c.prod_inst_id
                    into v_area_code,
                         v_acc_nbr,
                         v_product_id,
                         v_prod_inst_id
                    from offer_prod_inst_rel a,
                         prod_inst_rel       b,
                         prod_inst           c
                   where a.prod_inst_id = b.prod_inst_z_id
                     and b.relation_type_cd = '100600'
                     and b.prod_inst_a_id = c.prod_inst_id
                     and c.product_id = 800000002
                     and a.prod_offer_inst_id = v_prod_offer_inst_id;
                  proc_send_sms_for_log(v_area_code,
                                        v_acc_nbr,
                                        v_product_id,
                                        v_prod_inst_id,
                                        I_ORDER_ITEM_ID,
                                        v_cust_so_number,
                                        v_content,
                                        v_time_wnd,
                                        o_err_code,
                                        o_err_msg);
                exception
                  when no_data_found then
                    null;
                end;
              elsif v_op_type = '12' then
                --删除时从2表取关系数据
                begin
                  select c.area_code,
                         c.acc_nbr,
                         c.product_id,
                         c.prod_inst_id
                    into v_area_code,
                         v_acc_nbr,
                         v_product_id,
                         v_prod_inst_id
                    from offer_prod_inst_rel_his a,
                         prod_inst_rel           b,
                         -- 正确的应该是这个，但是因为现在没有索引，所以就先用一表，等索引加了再切回来
                         --  prod_inst_rel_his       b,
                         prod_inst c
                   where a.prod_inst_id = b.prod_inst_z_id
                     and b.relation_type_cd = '100600'
                     and b.prod_inst_a_id = c.prod_inst_id
                     and c.product_id = 800000002
                     and a.prod_offer_inst_id = v_prod_offer_inst_id
                     and rownum = 1;
                  proc_send_sms_for_log(v_area_code,
                                        v_acc_nbr,
                                        v_product_id,
                                        v_prod_inst_id,
                                        I_ORDER_ITEM_ID,
                                        v_cust_so_number,
                                        v_content,
                                        v_time_wnd,
                                        o_err_code,
                                        o_err_msg);
                exception
                  when no_data_found then
                    null;
                end;
              end if;
            else
              begin
                --非功能类基础销售品，短信发送给订单处理属性中记录的销售品关联的天翼
                select d.area_code, d.acc_nbr, a.product_id, d.prod_inst_id
                  into v_area_code, v_acc_nbr, v_product_id, v_prod_inst_id
                  from offer_prod_rel           a,
                       offer_prod_inst_rel_his  b, --新装和删除时，2表都会有至少一条记录，所以直接用2表
                       order_item_proc_attr_his c,
                       prod_inst                d
                 where c.order_item_id = I_ORDER_ITEM_ID
                   and c.class_id = 39
                   and c.obj_inst_id = b.offer_prod_inst_rel_id
                   and a.product_id = 800000002
                   and a.prod_offer_id = v_prod_offer_id
                   and a.offer_prod_rela_id = b.offer_prod_rel_id
                   and b.prod_inst_id = d.prod_inst_id
                   and b.prod_offer_inst_id = v_prod_offer_inst_id
                   and exists (select 1
                          from (select distinct offer_prod_inst_rel_id,
                                                max(his_id) over(partition by offer_prod_inst_rel_id) as max_his_id
                                  from offer_prod_inst_rel_his f) t
                         where b.his_id = t.max_his_id
                           and b.offer_prod_inst_rel_id =
                               t.offer_prod_inst_rel_id)
                   and rownum = 1;
                proc_send_sms_for_log(v_area_code,
                                      v_acc_nbr,
                                      v_product_id,
                                      v_prod_inst_id,
                                      I_ORDER_ITEM_ID,
                                      v_cust_so_number,
                                      v_content,
                                      v_time_wnd,
                                      o_err_code,
                                      o_err_msg);
              exception
                when no_data_found then
                  null;
              end;
            end if;
          end loop;
        end if;
      end;
    end if;
  END PROC_FOR_SMS;

  /*--新装或者是拨打开通 crm00013946
  1、请保留之前已提供的竣工短信通知等功能；
  2、本需求说列的入网包括：新装竣工 和 预开户的开通竣工两种情况；
  3、需求中的第1、第2点需要给189号码发两条短信，请分两次发送；
  4、需求中的第3点，要在竣工后24小时再发短信；
  */
  procedure proc_send_sms_crm00013946(i_area_code      in varchar2,
                                      i_acc_nbr        in varchar2,
                                      i_product_id     in varchar2,
                                      i_prod_inst_id   in varchar2,
                                      i_order_item_id  in varchar2,
                                      i_cust_so_number in varchar2,
                                      i_finish_time    date,
                                      i_time_wnd       in number,
                                      o_err_code       out number,
                                      o_err_msg        out varchar2) as
    v_sub_account varchar2(10) := '';

  begin
    --新装或者是拨打开通 crm00013946
    /*1、请保留之前已提供的竣工短信通知等功能；
    2、本需求说列的入网包括：新装竣工 和 预开户的开通竣工两种情况；
    3、需求中的第1、第2点需要给189号码发两条短信，请分两次发送；
    4、需求中的第3点，要在竣工后24小时再发短信；
    */
    v_sub_account := substr(i_acc_nbr, 1, 3); --取前3位
    for rec in (select a.content1, a.send_Type
                  from sms_content_config a
                 where a.acc_nbr in ('ALL', v_sub_account)
                   and a.class_id = '4'
                   and a.spec_id = i_product_id
                   and status_cd = '1000') loop
      if rec.send_type = 'S' then
        --立即发送的短信
        proc_send_sms_for_log(i_area_code,
                              i_acc_nbr,
                              i_product_id,
                              i_prod_inst_id,
                              I_ORDER_ITEM_ID,
                              i_cust_so_number,
                              rec.content1,
                              i_time_wnd,
                              o_err_code,
                              o_err_msg);
      elsif rec.send_Type = 'M' then
        --次日发送的短信
        --判断订单的竣工时间是12点前还是后
        --如果是12点前则下午送短信，如果是12点后明天上午送
        --0-立即发送（优先发送） 1-进入队列顺序发送 10-上午发送  11-下午发送
        if (trunc(sysdate) - trunc(i_finish_time)) >= 1 then
          --昨天以前竣工的，立即送
          proc_send_sms_for_log(i_area_code,
                                i_acc_nbr,
                                i_product_id,
                                i_prod_inst_id,
                                I_ORDER_ITEM_ID,
                                i_cust_so_number,
                                rec.content1,
                                i_time_wnd,
                                o_err_code,
                                o_err_msg);
        elsif to_number(substr(to_char(i_finish_time, 'yyyymmddhh24'), 9, 2)) >= 12 then
          --下午竣工的，在次日上午发
          proc_send_sms_for_log(i_area_code,
                                i_acc_nbr,
                                i_product_id,
                                i_prod_inst_id,
                                I_ORDER_ITEM_ID,
                                i_cust_so_number,
                                rec.content1,
                                10, --次日上午发短信
                                o_err_code,
                                o_err_msg);
        elsif to_number(substr(to_char(i_finish_time, 'yyyymmddhh24'), 9, 2)) <= 11 then
          --上午竣工的，下午发
          proc_send_sms_for_log(i_area_code,
                                i_acc_nbr,
                                i_product_id,
                                i_prod_inst_id,
                                I_ORDER_ITEM_ID,
                                i_cust_so_number,
                                rec.content1,
                                11, --下午发短信
                                o_err_code,
                                o_err_msg);
        end if;
      elsif rec.send_Type = 'G' then
        --固定次日上午发送
        proc_send_sms_for_log(i_area_code,
                              i_acc_nbr,
                              i_product_id,
                              i_prod_inst_id,
                              I_ORDER_ITEM_ID,
                              i_cust_so_number,
                              rec.content1,
                              10, --次日上午发短信
                              o_err_code,
                              o_err_msg);
      elsif rec.send_Type = 'H' then
        --固定次日下午送 --当前时间大于竣工时间1天，待确认
        if (trunc(sysdate) - trunc(i_finish_time)) >= 1 then
          proc_send_sms_for_log(i_area_code,
                                i_acc_nbr,
                                i_product_id,
                                i_prod_inst_id,
                                I_ORDER_ITEM_ID,
                                i_cust_so_number,
                                rec.content1,
                                11, --下午发短信
                                o_err_code,
                                o_err_msg);
        end if;
      end if;
    end loop;
  end proc_send_sms_crm00013946;

  /*移动语音亲情短号变更短信发送逻辑*/
  procedure proc_send_sms_for_change_qqdhm(I_ORDER_ITEM_ID  IN NUMBER, --订单项ID
                                           I_CUST_ORDER_ID  IN NUMBER, --客户订单ID
                                           v_cust_so_number IN VARCHAR2, --订单流水号
                                           v_time_wnd       IN NUMBER, --时间窗口
                                           o_err_code       out number,
                                           o_err_msg        out varchar2) is
    v_content           varchar2(4000) := '';
    v_cy_acc_nbr        prod_inst.acc_nbr%type;
    v_cy_short_nbr      prod_inst.acc_nbr%type;
    v_prod_inst_id      prod_inst.prod_inst_id%type;
    v_qqdh_prod_inst_id prod_inst.prod_inst_id%type;
  begin
    --判断是否变更亲情短号码属性
    begin
      select new_value, obj_inst_id
        into v_cy_short_nbr, v_prod_inst_id
        from (select oipa.new_value, oipa.obj_inst_id
                from order_item oi, order_item_proc_attr oipa
               where oi.order_item_id = oipa.order_item_id
                 and oi.order_item_id = I_ORDER_ITEM_ID
                 and oipa.obj_attr_id = '800013655'
                 and oipa.operate = '11'
              union
              select oipa.new_value, oipa.obj_inst_id
                from order_item_his oi, order_item_proc_attr_his oipa
               where oi.order_item_id = oipa.order_item_id
                 and oi.order_item_id = I_ORDER_ITEM_ID
                 and oipa.obj_attr_id = '800013655'
                 and oipa.operate = '11');
    exception
      when no_data_found then
        return;
    end;

    --判断A端是否关联亲情短号接入类产品实例
    begin
      select distinct pir.prod_inst_a_id
        into v_qqdh_prod_inst_id
        from prod_inst pi, prod_inst_rel pir
       where 1 = 1
         and pir.prod_inst_z_id = v_prod_inst_id
         and pir.prod_inst_a_id = pi.prod_inst_id
         and pi.product_id = '800771864'
         and pi.status_cd = '100000'
         and pir.status_cd = '1000';
    exception
      when no_data_found then
        return;
    end;

    for rec in (select decode(pi.prod_inst_id, v_prod_inst_id, 1, 0) is_self,
                       pi.area_code,
                       pi.acc_nbr,
                       pi.product_id,
                       pi.prod_inst_id
                  from prod_inst pi, prod_inst_rel pir
                 where 1 = 1
                   and pir.prod_inst_a_id = v_qqdh_prod_inst_id
                   and pir.prod_inst_z_id = pi.prod_inst_id
                   and pir.role_cd in ('829', '830')
                   and pi.product_id in ('800000000', '800000002')
                   and pir.status_cd = '1000' --有效的产品实例关系
                   and pi.status_cd = '100000'
                 order by is_self desc) loop

      if rec.is_self = 1 then
        v_content    := '您的亲情短号码已变更为' || v_cy_short_nbr || '，e家内天翼成员拨打短号码' ||
                        v_cy_short_nbr || '（固话成员拨打短号码' || v_cy_short_nbr ||
                        '）即可找到您。查看e家内其他成员亲情短号码请回复“cxdh”到10001。';
        v_cy_acc_nbr := rec.acc_nbr;
      else
        v_content := v_cy_acc_nbr || '的亲情短号码变更为：' || v_cy_short_nbr ||
                     '。查看e家内其他家庭成员短号请回复“cxdh”到10001。';
      end if;
      if rec.product_id = 800000002 then
        proc_send_sms_for_log(rec.area_code,
                              rec.acc_nbr,
                              rec.product_id,
                              rec.prod_inst_id,
                              I_ORDER_ITEM_ID,
                              v_cust_so_number,
                              v_content,
                              v_time_wnd,
                              o_err_code,
                              o_err_msg);
      end if;

    end loop;

  end proc_send_sms_for_change_qqdhm;

  /*亲情短号短信发送逻辑*/
  procedure proc_send_sms_for_qqdh(I_ORDER_ITEM_ID  IN NUMBER, --订单项ID
                                   I_CUST_ORDER_ID  IN NUMBER, --客户订单ID
                                   v_cust_so_number IN VARCHAR2, --订单流水号
                                   v_time_wnd       IN NUMBER, --时间窗口
                                   o_err_code       out number,
                                   o_err_msg        out varchar2) is

    v_content            varchar2(4000) := '';
    v_qqdh_order_item_id order_item.order_item_id%type; --亲情短号订单项ID
    v_qqdh_prod_inst_id  prod_inst.prod_inst_id%type; --亲情短号产品实例ID
    v_qqdh_op_type       service_offer.op_type%type; --亲情短号操作类型
    v_hz_acc_nbr         prod_inst.acc_nbr%type; --户主业务号码
    v_cy_acc_nbr         prod_inst.acc_nbr%type; --家庭成员业务号码
    v_cy_short_nbr       prod_inst.acc_nbr%type; --家庭成员亲情短号码

  begin
    --查找订单中亲情短号的接入类产品订单项
    begin
      select oi.order_item_id, pi.prod_inst_id, so.op_type
        into v_qqdh_order_item_id, v_qqdh_prod_inst_id, v_qqdh_op_type
        from order_item_his oi, prod_inst pi, service_offer so
       where 1 = 1
         and oi.cust_order_id = I_CUST_ORDER_ID
         and oi.order_item_obj_id = pi.prod_inst_id
         and oi.service_offer_id = so.service_offer_id
         and oi.class_id = '4'
         and pi.product_id = '800771864'; --亲情短号的接入类产品ID
    exception
      when no_data_found then
        return;
    end;

    --亲情短号创建，此时跟移动语音的关系必然为创建
    if v_qqdh_op_type = '10' then
      for rec in (select oipa.operate   rel_op_type,
                         oipa.new_value prod_inst_rel_id
                    from order_item_his           oi,
                         order_item_proc_attr_his oipa,
                         service_offer            so
                   where 1 = 1
                     and oi.order_item_id = v_qqdh_order_item_id
                     and oi.service_offer_id = so.service_offer_id
                     and oi.order_item_id = oipa.order_item_id
                     and oipa.class_id = '136' --产品实例间关系的类ID
                  ) loop
        --对户主和成员发送短信通知
        for rec1 in (select decode(pir.prod_inst_rel_id,
                                   rec.prod_inst_rel_id,
                                   1,
                                   0) is_self,
                            pi.area_code,
                            pi.acc_nbr,
                            pi.product_id,
                            pi.prod_inst_id,
                            pia.attr_value short_nbr
                       from prod_inst_rel  pir,
                            prod_inst      pi,
                            prod_inst_attr pia
                      where 1 = 1
                        and pir.prod_inst_a_id = v_qqdh_prod_inst_id
                        and pir.prod_inst_z_id = pi.prod_inst_id
                        and pi.prod_inst_id = pia.prod_inst_id
                        and pi.product_id in ('800000000', '800000002')
                        and pir.role_cd in ('829', '830')
                        and pia.attr_id = '800013655' --亲情短号码属性ID
                        and pir.status_cd = '1000' --有效的产品实例关系
                        and pi.status_cd = '100000'
                      order by is_self desc) loop

          if rec1.is_self = 1 then
            v_content      := '您的e家已开通亲情短号功能。e家内天翼成员拨打短号码' ||
                              rec1.short_nbr || '（固话成员拨打短号码' ||
                              rec1.short_nbr ||
                              '*）即可找到您。查看e家内其他成员亲情短号码请回复“cxdh”到10001，' ||
                              '查看短信管理指令请回复“亲情短号”到10001。';
            v_cy_acc_nbr   := rec1.acc_nbr;
            v_cy_short_nbr := rec1.short_nbr;
          else
            v_content := v_cy_acc_nbr || '的亲情短号码为：' || v_cy_short_nbr ||
                         '。查看e家内其他家庭成员短号请回复“cxdh”到10001。';
          end if;
          if rec1.product_id = 800000002 then
            proc_send_sms_for_log(rec1.area_code,
                                  rec1.acc_nbr,
                                  rec1.product_id,
                                  rec1.prod_inst_id,
                                  I_ORDER_ITEM_ID,
                                  v_cust_so_number,
                                  v_content,
                                  v_time_wnd,
                                  o_err_code,
                                  o_err_msg);
          end if;
        end loop;
      end loop;

      --亲情短号移除，此时跟移动语音的关系必然为移除
    elsif v_qqdh_op_type = '12' then
      --对户主和成员发送短信通知
      for rec in (select pi.area_code,
                         pi.acc_nbr,
                         pi.product_id,
                         pi.prod_inst_id,
                         pir.role_cd
                    from order_item_his           oi,
                         order_item_proc_attr_his oipa,
                         service_offer            so,
                         prod_inst_rel_his        pir,
                         prod_inst                pi
                   where 1 = 1
                     and oi.order_item_id = v_qqdh_order_item_id
                     and oi.service_offer_id = so.service_offer_id
                     and oi.order_item_id = oipa.order_item_id
                     and oipa.class_id = '136'
                     and oipa.operate = '12'
                     and oipa.old_value = pir.prod_inst_rel_id
                     and pir.prod_inst_a_id = v_qqdh_prod_inst_id
                     and pir.prod_inst_z_id = pi.prod_inst_id
                     and pi.product_id in ('800000000', '800000002')
                     and pir.role_cd in ('829', '830')
                     and pir.status_cd = '1100' --失效的产品实例关系
                     and pi.status_cd = '100000'
                   order by role_cd) loop
        if rec.role_cd = '829' then
          v_content    := '您的亲情短号已成功关闭，家庭成员间不能再使用亲情短号进行通话！';
          v_hz_acc_nbr := rec.acc_nbr;
        else
          v_content := '户主' || v_hz_acc_nbr ||
                       '已关闭亲情短号，家庭成员间不能再使用亲情短号进行通话！';
        end if;
        if rec.product_id = 800000002 then
          proc_send_sms_for_log(rec.area_code,
                                rec.acc_nbr,
                                rec.product_id,
                                rec.prod_inst_id,
                                I_ORDER_ITEM_ID,
                                v_cust_so_number,
                                v_content,
                                v_time_wnd,
                                o_err_code,
                                o_err_msg);
        end if;
      end loop;

      --亲情短号变更，此时跟移动语音的关系有入网跟退网两种
    else
      for rec in (select oipa.operate rel_op_type,
                         oipa.new_value || oipa.old_value prod_inst_rel_id
                    from order_item_his           oi,
                         order_item_proc_attr_his oipa,
                         service_offer            so
                   where 1 = 1
                     and oi.order_item_id = v_qqdh_order_item_id
                     and oi.service_offer_id = so.service_offer_id
                     and oi.order_item_id = oipa.order_item_id
                     and oipa.class_id = '136' --产品实例间关系的类ID
                  ) loop
        --入网
        if rec.rel_op_type = '10' then
          for rec1 in (select decode(pir.prod_inst_rel_id,
                                     rec.prod_inst_rel_id,
                                     1,
                                     0) is_self,
                              pi.area_code,
                              pi.acc_nbr,
                              pi.product_id,
                              pi.prod_inst_id,
                              pia.attr_value short_nbr
                         from prod_inst_rel  pir,
                              prod_inst      pi,
                              prod_inst_attr pia
                        where 1 = 1
                          and pir.prod_inst_a_id = v_qqdh_prod_inst_id
                          and pir.prod_inst_z_id = pi.prod_inst_id
                          and pi.prod_inst_id = pia.prod_inst_id
                          and pi.product_id in ('800000000', '800000002')
                          and pir.role_cd in ('829', '830')
                          and pia.attr_id = '800013655' --亲情短号码属性ID
                          and (pir.prod_inst_rel_id = rec.prod_inst_rel_id or
                              pir.status_cd = '1000')
                          and pi.status_cd = '100000'
                        order by is_self desc) loop
            --对家庭成员发送短信通知
            if rec1.is_self = 1 then
              v_content      := '您的e家已开通亲情短号功能。e家内天翼成员拨打短号码' ||
                                rec1.short_nbr || '（固话成员拨打短号码' ||
                                rec1.short_nbr ||
                                '*）即可找到您。查看e家内其他成员亲情短号码请回复“cxdh”到10001，' ||
                                '查看短信管理指令请回复“亲情短号”到10001。';
              v_cy_acc_nbr   := rec1.acc_nbr;
              v_cy_short_nbr := rec1.short_nbr;
              --对其它家庭成员发送短信通知
            else
              v_content := v_cy_acc_nbr || '的亲情短号码为：' || v_cy_short_nbr ||
                           '。查看e家内其他家庭成员短号请回复“cxdh”到10001。';
            end if;
            if rec1.product_id = 800000002 then
              proc_send_sms_for_log(rec1.area_code,
                                    rec1.acc_nbr,
                                    rec1.product_id,
                                    rec1.prod_inst_id,
                                    I_ORDER_ITEM_ID,
                                    v_cust_so_number,
                                    v_content,
                                    v_time_wnd,
                                    o_err_code,
                                    o_err_msg);
            end if;
          end loop;
          --退网
        else
          for rec1 in (select 1 is_self,
                              pi.area_code,
                              pi.acc_nbr,
                              pi.product_id,
                              pi.prod_inst_id,
                              oipa.old_value short_nbr
                         from prod_inst_rel_his        pir,
                              prod_inst                pi,
                              order_item_his           oi,
                              order_item_proc_attr_his oipa
                        where 1 = 1
                          and pir.prod_inst_z_id = pi.prod_inst_id
                          and oi.order_item_obj_id = pi.prod_inst_id
                          and oi.order_item_id = oipa.order_item_id
                          and oi.cust_order_id = I_CUST_ORDER_ID
                          and oipa.operate = '12'
                          and pir.prod_inst_rel_id = rec.prod_inst_rel_id
                          and pir.prod_inst_a_id = v_qqdh_prod_inst_id
                          and pi.product_id in ('800000000', '800000002')
                          and pir.role_cd in ('829', '830')
                          and pi.status_cd = '100000'
                          and oipa.obj_attr_id = '800013655' --亲情短号码属性ID
                       union
                       select 0 is_self,
                              pi.area_code,
                              pi.acc_nbr,
                              pi.product_id,
                              pi.prod_inst_id,
                              pia.attr_value short_nbr
                         from prod_inst_rel  pir,
                              prod_inst      pi,
                              prod_inst_attr pia
                        where 1 = 1
                          and pir.prod_inst_z_id = pi.prod_inst_id
                          and pi.prod_inst_id = pia.prod_inst_id
                          and pir.status_cd = '1000'
                          and pir.prod_inst_a_id = v_qqdh_prod_inst_id
                          and pi.product_id in ('800000000', '800000002')
                          and pir.role_cd in ('829', '830')
                          and pia.attr_id = '800013655' --亲情短号码属性ID
                          and pi.status_cd = '100000'
                        order by is_self desc) loop
            --对家庭成员发送短信通知
            if rec1.is_self = 1 then
              v_content      := '您的亲情短号码' || rec1.short_nbr ||
                                '已被取消，您无法再与e家内其他成员用短号码进行相互拨打！';
              v_cy_acc_nbr   := rec1.acc_nbr;
              v_cy_short_nbr := rec1.short_nbr;
              --对其它家庭成员发送短信通知
            else
              v_content := v_cy_acc_nbr || '用户的亲情短号码' || v_cy_short_nbr ||
                           '已被取消。查看e家内其他成员亲情短号码请回复“cxdh”到10001。';
            end if;
            if rec1.product_id = 800000002 then
              proc_send_sms_for_log(rec1.area_code,
                                    rec1.acc_nbr,
                                    rec1.product_id,
                                    rec1.prod_inst_id,
                                    I_ORDER_ITEM_ID,
                                    v_cust_so_number,
                                    v_content,
                                    v_time_wnd,
                                    o_err_code,
                                    o_err_msg);
            end if;
          end loop;
        end if;
      end loop;
    end if;
  end proc_send_sms_for_qqdh;

  /*发送短信并记录日志*/
  procedure proc_send_sms_for_log(i_area_code      in varchar2,
                                  i_acc_nbr        in varchar2,
                                  i_product_id     in varchar2,
                                  i_prod_inst_id   in varchar2,
                                  i_order_item_id  in varchar2,
                                  i_cust_so_number in varchar2,
                                  i_content        in varchar2,
                                  i_time_wnd       in number,
                                  o_err_code       out number,
                                  o_err_msg        out varchar2) as
    /*
    Function  ：此过程是根据输入的地区编码，业务号码，产品规格，产品实例、订单项ID，订单流水号，短信内容通知短信系统并记录日志。
    Author　  ：Wangjianjun
    Date      : 2012-07-25
    Parameter :
               i_area_code        --地区编码
               i_acc_nbr          --业务号码
               i_product_id       --产品规格
               i_prod_inst_id     --产品实例
               i_order_item_id    --处理单号
               i_cust_so_number   --流水号
               i_content          --短信内容
               i_time_wnd        -- 时间窗口
                           0-立即发送（优先发送）
                           1-进入队列顺序发送
                           10-上午发送  11-下午发送
               o_err_code         --错误编码（1 成功 0 失败）
               o_err_msg          --错误信息
    */
    v_id          number;
    v_ext_prod_id product.ext_prod_id%type;
  begin
    o_err_code := 0; --默认失败
    o_err_msg  := '短信通知处理失败';
    begin
      -- 将产品规格ID转换成产品外部编码
      select a.ext_prod_id
        into v_ext_prod_id
        from product a
       where a.product_id = i_product_id;
      /**/
      PACKSMS_CRM.SP_SM_SEND_3G@LK_FJ_SMS(i_area_code,
                                          i_acc_nbr,
                                          i_content,
                                          v_ext_prod_id,
                                          i_time_wnd,
                                          o_err_code); --成功1 失败0
      o_err_msg := 'success';
    exception
      when others then
        o_err_code := 0;
        o_err_msg  := '调用短信系统处理失败,' || sqlerrm;
        rollback;
    end;

    /*
    记录短信发送日志
    */
    select SEQ_SEND_SMS_LOG_ID.Nextval into v_id from dual;
    insert into SEND_SMS_LOG
    values
      (i_area_code,
       i_acc_nbr,
       v_ext_prod_id,
       i_prod_inst_id,
       i_order_item_id,
       i_cust_so_number,
       i_content,
       i_time_wnd,
       o_err_code,
       o_err_msg,
       v_id,
       sysdate);
    commit;
  exception
    when others then
      o_err_code := 0;
      o_err_msg  := SQLERRM;
  end proc_send_sms_for_log;

  /*
  Function  ：判断销售品是否为单接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    :（1 是 0 否）
  */
  function is_simple_access_offer(i_prod_offer_id number) return number is
    v_rel_count number;
  begin
    select count(*)
      into v_rel_count
      from prod_offer a, offer_prod_rel b, product c
     where a.offer_sub_type = 'T01'
       and a.prod_offer_id = b.prod_offer_id
       and b.product_id = c.product_id
       and c.prod_func_type = '101'
       and b.status_cd = '1000'
       and nvl(b.eff_date, sysdate) <= sysdate
       and nvl(b.exp_date, sysdate) >= sysdate
       and b.max_count = 1
       and b.min_count = 1
       and b.prod_offer_id = i_prod_offer_id;
    if v_rel_count = 1 then
      return 1;
    else
      return 0;
    end if;

  end is_simple_access_offer;

  /*
  Function  ：判断销售品是否为多接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    : 结果（1 是 0 否）
  */
  function is_multi_access_offer(i_prod_offer_id number) return number is
    v_offer_sub_type prod_offer.offer_sub_type%type;
    v_result         number := 0;
  begin
    begin
      select a.offer_sub_type
        into v_offer_sub_type
        from prod_offer a
       where a.prod_offer_id = i_prod_offer_id;
    exception
      when no_data_found then
        return 0;
    end;
    if v_offer_sub_type = 'T01' then
      v_result := is_simple_access_offer(i_prod_offer_id);
      if v_result = 1 then
        return 0;
      else
        return 1;
      end if;
    else
      return 0;
    end if;
  end is_multi_access_offer;

END PKG_CRM;
/
