CREATE package body           PKG_GEJIE_KH is

  PROCEDURE MAIN as
  i_id      number(10);
  i_custId  number(10);
  i_count   number(10);
  begin
      i_count := 0;
      for yy in( select a.KHID aa, a.KHCY ab, a.KHQY ac, a.KHBM ad, a.CORRESPONDENT ae, a.MAIN_GROUP_ID af, b.CYID  id, b.CYMC  mc, b.CYJP jp, b.CYPM  pm, b.CYZL zl from kh@LK_CRM102 a, cy@LK_CRM102 b where a.khcy = b.cyid )LOOP

        --select max(PARTY_ID)+1  into i_id from  PARTY;
        select SEQ_PARTY_ID.nextval into i_id from  dual;
        insert into PARTY(PARTY_ID, PARTY_NAME, PARTY_ABBRNAME,ENGLISH_NAME,PARTY_TYPE)
        values(i_id, yy.mc, yy.jp, yy.pm, yy.zl);

        --select max(CUST_ID)+1  into i_custId from  cust;
        select SEQ_CUST_ID.NEXTVAL into i_custId from  dual;
        insert into cust(CUST_ID, PARTY_ID, COMMON_REGION_ID,CUST_NUMBER,CUST_ADDRESS, CUST_TYPE)
        values(i_custId, i_id, yy.ac,yy.ad,yy.ae,yy.af );

        insert into update_kh@LK_CRM102(cyNew_id, cyOld_id,khOld_id, khNew_id)
        values(i_id, yy.ab, yy.aa, i_custId);

        i_count := i_count+1;
        if i_count >10000 then
          i_count := 0;
          commit;
        end if;
      end loop;
    commit;
  end;

end PKG_GEJIE_KH;
/
