CREATE package body           PKG_JT_CHANNEL_UPLOAD is

  procedure prc_jt_channel_main(in_table_name  in varchar2,
                                in_key_id      in varchar2,
                                in_action      in varchar2,
                                in_modi_man    in varchar2,
                                in_modi_reason in varchar2) is
    o_xml        clob;
    err_msg      varchar2(100);
    v_seq_id     number(15);
    V_table_name VARCHAR2(50);
    V_STATUS_CD  VARCHAR2(20);
    V_ACTION     VARCHAR2(20);
  begin
    V_table_name := UPPER(in_table_name);
    V_ACTION     := in_action;
    V_STATUS_CD  := '1000';
    if V_table_name in ('CHANNEL_ATTR') THEN
      BEGIN
        SELECT STATUS_CD
          INTO V_STATUS_CD
          FROM CRMV2.CHANNEL_ATTR
         WHERE CHANNEL_ATTR_ID = in_key_id
           AND ROWNUM = 1;
      exception
        when others then
          SELECT STATUS_CD
            INTO V_STATUS_CD
            FROM CRMV2.CHANNEL_ATTR_HIS
           WHERE CHANNEL_ATTR_ID = in_key_id
             AND ROWNUM = 1;
      END;
    ELSIF V_table_name in ('STAFF_ATTR') THEN
      BEGIN
        SELECT STATUS_CD
          INTO V_STATUS_CD
          FROM CRMV2.STAFF_ATTR
         WHERE STAFF_ATTR_ID = in_key_id
           AND ROWNUM = 1;
      exception
        when others then
          SELECT STATUS_CD
            INTO V_STATUS_CD
            FROM CRMV2.STAFF_ATTR_HIS
           WHERE STAFF_ATTR_ID = in_key_id
             AND ROWNUM = 1;
      END;
    END IF;
    IF V_table_name IN ('CHANNEL_ATTR', 'STAFF_ATTR') AND
       V_STATUS_CD = '1100' THEN
      V_ACTION := 'DEL';
    END IF;

    if V_table_name = 'ORGANIZATION' THEN
      /*insert into basejk.intf_org_sync_queue@lk_crm2jk_weihu
        (INTF_ORG_SYNC_QUEUE_ID,
         ACTION,
         ORG_ID,
         EXT_ORG_ID,
         ORG_CODE,
         ORG_NAME,
         COMMON_REGION_ID,
         ORG_TYPE,
         ORG_CONTENT,
         ORG_SCALE,
         PARENT_ORG_ID,
         EXT_PARENT_ORG_ID,
         PRINCIPAL,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK)
        select seq_intf_org_sync_queue_id.nextval,
               SUBSTR(V_ACTION, 1, 1),
               org_id,
               '',
               org_code,
               org_name,
               common_region_id,
               org_type,
               org_content,
               org_scale,
               parent_org_id,
               parent_org_id,
               principal,
               '70A',
               '',
               CREATE_DATE,
               SYSDATE,
               '',
               '',
               in_modi_man
          from CRMV2.organization
         where org_id = in_key_id;*/
      insert into crmv2.linyx_channel_bak
      values
        (V_table_name,
         in_key_id,
         '',
         V_ACTION,
         SYSDATE,
         in_modi_man,
         in_modi_reason);
      commit;
    ELSE
      prc_jt_channel_XML(V_table_name, in_key_id, V_ACTION, o_xml, err_msg);
      if O_XML is not null then
        select crmv2.Seq_Intf_Up_Channel_Info_Id.nextval
          into v_seq_id
          from dual;
        insert into crmv2.intf_up_channel_info
          select v_seq_id,
                 O_XML,
                 '',
                 '101',
                 SYSDATE,
                 SYSDATE,
                 '',
                 '',
                 in_key_id
            from dual;
        insert into crmv2.linyx_channel_bak
        values
          (V_table_name,
           in_key_id,
           v_seq_id,
           V_ACTION,
           SYSDATE,
           in_modi_man,
           in_modi_reason);
        commit;
      end if;
    END IF;
  end prc_jt_channel_main;

  procedure prc_jt_channel_XML(in_table_name in varchar2,
                               in_key_id     in varchar2,
                               in_action     in varchar2,
                               o_xml         out clob,
                               err_msg       out varchar2) is
    V_TABLE_NAME       varchar2(30);
    v_action           varchar2(20);
    v_in_xml           clob;
    v_top              varchar2(500) := '<?xml version="1.0" encoding="UTF-8"?><ContractRoot>';
    v_ContractRoot_end varchar2(500) := '</CHANNEL_INFO></SvcCont></ContractRoot>';
    v_xml_tmp          varchar2(4000);
    --v_sub_xml_tmp          varchar2(4000);
    v_Transaction_ID varchar2(50);
    v_key_id         varchar2(30);
    v_day            varchar2(50) := to_char(sysdate, 'yyyymmdd');
    --v_cnt                  number(5);
    v_channel_nbr     varchar2(20);
    v_channel_name    varchar2(100);
    v_channel_class   varchar2(20);
    v_CHANNEL_TYPE_CD varchar2(20);
    --v_CHANNEL_SUBTYPE_CD   varchar2(20);
    v_ORG_ID               varchar2(20);
    v_COMMON_REGION_ID     varchar2(20);
    v_REGION_CODE          varchar2(20);
    v_STATUS_CD            varchar2(20);
    v_STATUS_DATE          varchar2(20);
    v_attr_id              varchar2(20);
    v_attr_value           varchar2(20);
    V_OPERATORS_NBR        varchar2(20);
    V_OPERATORS_NAME       varchar2(100);
    V_CERT_TYPE            varchar2(20);
    V_CERT_NUMBER          varchar2(30);
    V_MOBILE_PHONE         varchar2(50);
    V_E_MAIL               varchar2(30);
    V_OPERATORS_SNAME      varchar2(100);
    V_ADDRESS              varchar2(200);
    V_OPERATORS_AREA_GRADE varchar2(20);
    V_STAFF_CODE           varchar2(50);
    V_PARTY_ID             varchar2(20);
    V_STAFF_NAME           varchar2(100);
    V_CREATE_DATE          varchar2(20);
    V_STAFF_NBR            varchar2(20);
    v_rela_type            varchar2(20);
    v_RELA_CHANNEL_NBR     varchar2(20);
    v_PARENT_OPER_NBR      varchar2(20);
    v_cnt                  number(2);
    v_BIZ_ZONE_NAME        varchar2(100);
    v_BIZ_ZONE_NBR         varchar2(20);
    v_BIZ_ZONE_LEVER       varchar2(20);
    v_BIZ_ZONE_TYPE_CD     varchar2(10);
    v_IS_CORE              varchar2(10);
  begin
    begin
      v_xml_tmp := '<TcpCont>
    <TransactionID>6001050001201306131042075381</TransactionID>
    <ActionCode>0</ActionCode>
    <BusCode>BUS33001</BusCode>
    <ServiceCode>SVC33049</ServiceCode>
    <ServiceContractVer>SVC3304920121201</ServiceContractVer>
    <ServiceLevel>1</ServiceLevel>
		<SrcOrgID>600105</SrcOrgID>
		<SrcSysID>6001050001</SrcSysID>
		<SrcSysSign>jtdep60010500011031</SrcSysSign>
		<DstOrgID>100000</DstOrgID>
		<DstSysID>1000000045</DstSysID>
		<ReqTime>20130613104248</ReqTime>
	</TcpCont>
  <SvcCont>
		<CHANNEL_INFO>';
      select '6001050001' || v_day || crmv2.SEQ_INTF_TRANS.nextval
        into v_Transaction_ID
        from dual;

      v_xml_tmp := replace(v_xml_tmp,
                           '6001050001201306131042075381',
                           v_Transaction_ID);
      v_xml_tmp := replace(v_xml_tmp,
                           'jtdep60010500011031',
                           'jtdep60010500011031'); ---改密的时候要修改这边
      v_xml_tmp := replace(v_xml_tmp,
                           '20130613104248',
                           to_char(sysdate, 'yyyymmddhh24miss'));

      v_in_xml := v_top || v_xml_tmp;

      /*--------------------正文子节点---------------------------*/
      V_TABLE_NAME := UPPER(IN_TABLE_NAME);
      v_action     := UPPER(in_action);
      v_key_id     := IN_KEY_ID;
      ---CHANNEL
      if V_TABLE_NAME = 'CHANNEL' THEN
        begin
          select channel_nbr,
                 channel_name,
                 channel_class,
                 CHANNEL_TYPE_CD, /*
                                                                                                                                                         decode(CHANNEL_SUBTYPE_CD,
                                                                                                                                                                '130600',
                                                                                                                                                                '120300',
                                                                                                                                                                CHANNEL_SUBTYPE_CD),*/
                 ORG_ID,
                 COMMON_REGION_ID,
                 STATUS_CD,
                 to_char(STATUS_DATE, 'yyyymmddhh24miss'),
                 to_char(CREATE_DATE, 'yyyymmddhh24miss')
            into v_channel_nbr,
                 v_channel_name,
                 v_channel_class,
                 v_CHANNEL_TYPE_CD, /*
                                                                                                                                                         v_CHANNEL_SUBTYPE_CD,*/
                 v_ORG_ID,
                 v_COMMON_REGION_ID,
                 v_STATUS_CD,
                 v_STATUS_DATE,
                 v_CREATE_DATE
            from crmv2.channel
           where channel_id = v_key_id
             and status_cd not in ('1200', '3000')
             and channel_class is not null;
        exception
          when others then
            select channel_nbr,
                   channel_name,
                   channel_class,
                   CHANNEL_TYPE_CD, /*
                                                                                                                                                                           decode(CHANNEL_SUBTYPE_CD,
                                                                                                                                                                                  '130600',
                                                                                                                                                                                  '120300',
                                                                                                                                                                                  CHANNEL_SUBTYPE_CD),*/
                   ORG_ID,
                   COMMON_REGION_ID,
                   STATUS_CD,
                   to_char(STATUS_DATE, 'yyyymmddhh24miss'),
                   to_char(CREATE_DATE, 'yyyymmddhh24miss')
              into v_channel_nbr,
                   v_channel_name,
                   v_channel_class,
                   v_CHANNEL_TYPE_CD, /*
                                                                                                                                                                           v_CHANNEL_SUBTYPE_CD,*/
                   v_ORG_ID,
                   v_COMMON_REGION_ID,
                   v_STATUS_CD,
                   v_STATUS_DATE,
                   v_CREATE_DATE
              from crmv2.channel_his
             where channel_id = v_key_id
               and rownum = 1
               and status_cd = '1000'
               and channel_class is not null;
        end;

        if v_STATUS_CD IN
           ('1201', '1202', '1297', '1298', '1299', '1400', '1500') then
          select channel_nbr,
                 channel_name,
                 channel_class,
                 CHANNEL_TYPE_CD, /*
                                                                                                                                                         decode(CHANNEL_SUBTYPE_CD,
                                                                                                                                                                '130600',
                                                                                                                                                                '120300',
                                                                                                                                                                CHANNEL_SUBTYPE_CD),*/
                 ORG_ID,
                 COMMON_REGION_ID,
                 STATUS_CD,
                 to_char(STATUS_DATE, 'yyyymmddhh24miss'),
                 to_char(CREATE_DATE, 'yyyymmddhh24miss')
            into v_channel_nbr,
                 v_channel_name,
                 v_channel_class,
                 v_CHANNEL_TYPE_CD, /*
                                                                                                                                                         v_CHANNEL_SUBTYPE_CD,*/
                 v_ORG_ID,
                 v_COMMON_REGION_ID,
                 v_STATUS_CD,
                 v_STATUS_DATE,
                 v_CREATE_DATE
            from crmv2.channel_his
           where channel_id = v_key_id
             and status_cd in ('1000')
             and channel_class is not null
             and update_date in
                 (select max(update_date)
                    from crmv2.channel_his
                   where channel_id = v_key_id
                     and status_cd = '1000'
                     and channel_class is not null)
             and rownum = 1;
        end if;

        select region_code
          into v_REGION_CODE
          from crmv2.common_region
         where COMMON_REGION_ID = v_COMMON_REGION_ID;
        ----C5级需要做转换
        if v_REGION_CODE like '059%' then
          select region_code
            into v_REGION_CODE
            from common_region
           where common_region_id in
                 (select up_region_id
                    from common_region
                   where common_region_id = v_COMMON_REGION_ID);
        end if;
        v_COMMON_REGION_ID := v_REGION_CODE;
        ------判断是否有失效标示，有则状态为1001
        select count(*)
          into v_cnt
          from crmv2.channel_attr
         where channel_id = v_key_id
           and attr_id = 800057100
           and attr_value = 'sx'
           and status_cd = '1000';
        if v_cnt > 0 then
          v_STATUS_CD := '1001';
        end if;

        v_xml_tmp := '<CHANNEL>
        <CHANNEL_NBR>' || v_channel_nbr ||
                     '</CHANNEL_NBR>
				<CHANNEL_NAME>' || v_channel_name ||
                     '</CHANNEL_NAME>
				<CHANNEL_CLASS>' || v_channel_class ||
                     '</CHANNEL_CLASS>
				<CHANNEL_TYPE_CD>' || v_CHANNEL_TYPE_CD ||
                     '</CHANNEL_TYPE_CD>
				<ORG_ID>' || v_ORG_ID || '</ORG_ID>
				<COMMON_REGION_ID>' || v_COMMON_REGION_ID ||
                     '</COMMON_REGION_ID>
				<STATUS_CD>' || v_STATUS_CD || '</STATUS_CD>
				<STATUS_DATE>' || v_STATUS_DATE ||
                     '</STATUS_DATE>
        <CREATE_DATE>' || v_CREATE_DATE || '</CREATE_DATE>
				<ACTION>' || v_action || '</ACTION>
			  </CHANNEL>';
        err_msg   := '上传成功';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        ----------CHANNEL_ATTR循环

      ELSIF V_TABLE_NAME = 'CHANNEL_ATTR' THEN
        begin
          select b.group_cd, A.ATTR_VALUE, c.channel_nbr
            INTO v_attr_id, v_attr_value, v_channel_nbr
            from crmv2.channel_attr a, crmv2.attr_spec b, crmv2.channel c
           where a.Channel_Attr_Id = v_key_id
             and a.attr_id = b.attr_id
             and b.group_cd like '50000%'
             and b.class_id = 30
             and group_cd <> '50000031'
             and a.channel_id = c.channel_id
             and c.status_cd not in ('1200', '3000')
             and c.channel_class is not null;
        exception
          when others then
            select b.ext_attr_nbr, A.ATTR_VALUE, c.channel_nbr
              INTO v_attr_id, v_attr_value, v_channel_nbr
              from crmv2.channel_attr_his a,
                   crmv2.attr_spec        b,
                   crmv2.channel          c
             where a.Channel_Attr_Id = v_key_id
               and a.attr_id = b.attr_id
               and b.group_cd like '50000%'
               and b.class_id = 30
               and group_cd <> '50000031'
               and a.channel_id = c.channel_id
               and c.status_cd not in ('1200', '3000')
               and c.channel_class is not null
               AND A.STATUS_CD = '1100';
        end;
        ------如果是“初始合作时间”则做格式化转换
        select count(*)
          into v_cnt
          from crmv2.channel_attr
         where channel_attr_id = v_key_id
           and attr_id = 800075890;
        if v_cnt > 0 then
          v_attr_value := rpad(replace(v_attr_value, '-', ''), 14, 0);
        end if;
        v_xml_tmp :=  /*v_xml_tmp ||*/
         '<CHANNEL_ATTR>
				<CHANNEL_NBR>' || v_channel_nbr || '</CHANNEL_NBR>
				<ATTR_ITEMS>
        <ATTR_ITEM>
						<ATTR_ID>' || v_attr_id || '</ATTR_ID>
						<ATTR_VALUE>' || v_attr_value || '</ATTR_VALUE>
						<ACTION>' || v_action || '</ACTION>
					</ATTR_ITEM>
          </ATTR_ITEMS>
			</CHANNEL_ATTR>';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        err_msg := '上传成功';

        ----OPERATORS
      elsif V_TABLE_NAME = 'OPERATORS' then
        begin
          select OPERATORS_NBR,
                 OPERATORS_NAME,
                 CERT_TYPE,
                 CERT_NBR,
                 OPERATORS_SNAME,
                 ADDRESS,
                 OPERATORS_AREA_GRADE,
                 COMMON_REGION_ID,
                 STATUS_CD,
                 to_char(STATUS_DATE, 'yyyymmddhh24miss')
            into V_OPERATORS_NBR,
                 V_OPERATORS_NAME,
                 V_CERT_TYPE,
                 V_CERT_NUMBER,
                 V_OPERATORS_SNAME,
                 V_ADDRESS,
                 V_OPERATORS_AREA_GRADE,
                 V_COMMON_REGION_ID,
                 V_STATUS_CD,
                 V_STATUS_DATE
            from crmv2.OPERATORS
           where operators_id = v_key_id
             and operators_nbr not in ('J11000000001', 'J32010000002',
                  'J11000000004', 'J11000000003');
        exception
          when others then
            select OPERATORS_NBR,
                   OPERATORS_NAME,
                   CERT_TYPE,
                   CERT_NBR,
                   OPERATORS_SNAME,
                   ADDRESS,
                   OPERATORS_AREA_GRADE,
                   COMMON_REGION_ID,
                   STATUS_CD,
                   to_char(STATUS_DATE, 'yyyymmddhh24miss')
              into V_OPERATORS_NBR,
                   V_OPERATORS_NAME,
                   V_CERT_TYPE,
                   V_CERT_NUMBER,
                   V_OPERATORS_SNAME,
                   V_ADDRESS,
                   V_OPERATORS_AREA_GRADE,
                   V_COMMON_REGION_ID,
                   V_STATUS_CD,
                   V_STATUS_DATE
              from crmv2.OPERATORS_his
             where operators_id = v_key_id
               and operators_nbr not in ('J11000000001', 'J32010000002',
                    'J11000000004', 'J11000000003');
        end;
        select region_code
          into v_REGION_CODE
          from crmv2.common_region
         where COMMON_REGION_ID = v_COMMON_REGION_ID;
        ----C5级需要做转换
        if v_REGION_CODE like '059%' then
          select region_code
            into v_REGION_CODE
            from common_region
           where common_region_id in
                 (select up_region_id
                    from common_region
                   where common_region_id = v_COMMON_REGION_ID);
        end if;
        v_COMMON_REGION_ID := v_REGION_CODE;

        begin
          select b.operators_nbr
            into v_PARENT_OPER_NBR
            from crmv2.OPERATORS a, crmv2.OPERATORS b
           where a.operators_id = v_key_id
             and a.parent_oper_id = b.OPERATORS_id;
        exception
          when others then
            v_PARENT_OPER_NBR := '';
        end;
        v_xml_tmp := '<OPERATORS>
				<OPERATORS_NBR>' || V_OPERATORS_NBR ||
                     '</OPERATORS_NBR>
				<OPERATORS_NAME>' || V_OPERATORS_NAME ||
                     '</OPERATORS_NAME>
				<CERT_TYPE>' || V_CERT_TYPE || '</CERT_TYPE>
        <CERT_NBR>' || V_CERT_NUMBER ||
                     '</CERT_NBR>
				<OPERATORS_SNAME>' || V_OPERATORS_SNAME ||
                     '</OPERATORS_SNAME>
				<ADDRESS>' || V_ADDRESS ||
                     '</ADDRESS>
				<OPERATORS_AREA_GRADE>' || V_OPERATORS_AREA_GRADE ||
                     '</OPERATORS_AREA_GRADE>
        <PARENT_OPER_NBR>' || v_PARENT_OPER_NBR ||
                     '</PARENT_OPER_NBR>
				<COMMON_REGION_ID>' || V_COMMON_REGION_ID ||
                     '</COMMON_REGION_ID>
				<STATUS_CD>' || V_STATUS_CD || '</STATUS_CD>
				<STATUS_DATE>' || V_STATUS_DATE || '</STATUS_DATE>
				<ACTION>' || v_action || '</ACTION>
			</OPERATORS>';

        err_msg := '上传成功';
        -- v_in_xml  := v_in_xml || v_xml_tmp;
        ----------OPERATORS_ATTR循环
      ELSIF V_TABLE_NAME = 'OPERATORS_ATTR' THEN
        BEGIN
          select b.group_cd, A.ATTR_VALUE, C.OPERATORS_NBR
            INTO v_attr_id, v_attr_value, V_OPERATORS_NBR
            from crmv2.OPERATORS_ATTR a,
                 crmv2.attr_spec      b,
                 CRMV2.OPERATORS      C
           where a.OPERATORS_ATTR_id = v_key_id
             and a.attr_id = b.attr_id
             and b.group_cd like '50000%'
             and b.ext_attr_nbr <> to_char(b.attr_id)
             AND A.OPERATORS_ID = C.OPERATORS_ID;
        exception
          when others then
            null;
            select b.group_cd, A.ATTR_VALUE, C.OPERATORS_NBR
              INTO v_attr_id, v_attr_value, V_OPERATORS_NBR
              from crmv2.OPERATORS_ATTR_HIS a,
                   crmv2.attr_spec          b,
                   CRMV2.OPERATORS          C
             where a.OPERATORS_ATTR_id = v_key_id
               and a.attr_id = b.attr_id
               and b.group_cd like '50000%'
               and b.ext_attr_nbr <> to_char(b.attr_id)
               AND A.OPERATORS_ID = C.OPERATORS_ID;
        END;
        v_xml_tmp :=  /* v_xml_tmp || */
         '<OPERATORS_ATTR>
				<OPERATORS_NBR>' || v_OPERATORS_nbr ||
                     '</OPERATORS_NBR>
				<ATTR_ITEMS>
        <ATTR_ITEM>
						<ATTR_ID>' || v_attr_id || '</ATTR_ID>
						<ATTR_VALUE>' || v_attr_value || '</ATTR_VALUE>
						<ACTION>' || v_action || '</ACTION>
					</ATTR_ITEM>
          </ATTR_ITEMS>
			</OPERATORS_ATTR>';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        err_msg := '上传成功';

        ----STAFF
      elsif V_TABLE_NAME = 'STAFF' then
        BEGIN
          select (select staff_code
                    from crmv2.system_user
                   where staff_id = a.staff_id
                     and rownum = 1),
                 ORG_ID,
                 PARTY_ID,
                 nvl(nvl((select party_name
                           from party
                          where party_id = a.party_id
                            and rownum = 1),
                         a.staff_name),
                     '无名称'),
                 (select cert_number
                    from crmv2.party_certification
                   where party_id = a.party_id
                     AND STATUS_CD = '1000'
                     and rownum = 1),
                 (select mobile_phone
                    from party_contact_info
                   where party_id = a.party_id
                     AND STATUS_CD = '1000'
                     and rownum = 1),
                 (select e_mail
                    from party_contact_info
                   where party_id = a.party_id
                     AND STATUS_CD = '1000'
                     and rownum = 1),
                 STATUS_CD,
                 TO_CHAR(STATUS_DATE, 'YYYYMMDDHH24MISS'),
                 TO_CHAR(CREATE_DATE, 'YYYYMMDDHH24MISS'),
                 STAFF_NBR
            INTO V_STAFF_CODE,
                 V_ORG_ID,
                 V_PARTY_ID,
                 V_STAFF_NAME,
                 V_CERT_NUMBER,
                 V_MOBILE_PHONE,
                 V_E_MAIL,
                 V_STATUS_CD,
                 V_STATUS_DATE,
                 V_CREATE_DATE,
                 V_STAFF_NBR
            from CRMV2.STAFF a
           where STAFF_ID = v_key_id
             and a.staff_nbr is not null
                /*             and exists (select *
                                                                                    from crmv2.staff_channel_rela b
                                                                                   where a.staff_id = b.staff_id)*/
             AND STAFF_ID NOT IN ('5564734');
        exception
          when others then
            select (select staff_code
                      from crmv2.system_user
                     where staff_id = a.staff_id
                       and rownum = 1),
                   ORG_ID,
                   PARTY_ID,
                   nvl(nvl((select party_name
                             from party
                            where party_id = a.party_id
                              and rownum = 1),
                           a.staff_name),
                       '无名称'),
                   (select cert_number
                      from crmv2.party_certification
                     where party_id = a.party_id
                       AND STATUS_CD = '1000'
                       and rownum = 1),
                   (select mobile_phone
                      from party_contact_info
                     where party_id = a.party_id
                       AND STATUS_CD = '1000'
                       and rownum = 1),
                   (select e_mail
                      from party_contact_info
                     where party_id = a.party_id
                       AND STATUS_CD = '1000'
                       and rownum = 1),
                   STATUS_CD,
                   TO_CHAR(STATUS_DATE, 'YYYYMMDDHH24MISS'),
                   TO_CHAR(CREATE_DATE, 'YYYYMMDDHH24MISS'),
                   STAFF_NBR
              INTO V_STAFF_CODE,
                   V_ORG_ID,
                   V_PARTY_ID,
                   V_STAFF_NAME,
                   V_CERT_NUMBER,
                   V_MOBILE_PHONE,
                   V_E_MAIL,
                   V_STATUS_CD,
                   V_STATUS_DATE,
                   V_CREATE_DATE,
                   V_STAFF_NBR
              from CRMV2.STAFF_HIS A
             where STAFF_ID = v_key_id
               and a.staff_nbr is not null
            /*               and exists (select *
                                                                      from crmv2.staff_channel_rela b
                                                                     where a.staff_id = b.staff_id)*/
            ;
        END;
        --dbms_output.put_line('V_MOBILE_PHONE:'||V_MOBILE_PHONE);
        if V_MOBILE_PHONE is null or length(V_MOBILE_PHONE) <> 11 or
           SUBSTR(V_MOBILE_PHONE, 1, 2) NOT IN ('13', '15', '18', '17','14') then
          V_MOBILE_PHONE := '';
          V_STAFF_CODE   := '';
        end if;
        if V_STATUS_CD = '1100' then
          v_action       := 'MOD';
          V_STAFF_CODE   := '';
          V_MOBILE_PHONE := '';
          V_ORG_ID       := 2098059;
        end if;
        v_xml_tmp := '<STAFF>
				<STAFF_CODE>' || V_STAFF_CODE || '</STAFF_CODE>
				<ORG_ID>' || V_ORG_ID || '</ORG_ID>
				<PARTY_ID>' || V_PARTY_ID || '</PARTY_ID>
				<STAFF_NAME>' || V_STAFF_NAME ||
                     '</STAFF_NAME>
        <CERT_NUMBER>' || V_CERT_NUMBER ||
                     '</CERT_NUMBER>
        <MOBILE_PHONE>' || V_MOBILE_PHONE ||
                     '</MOBILE_PHONE>
        <E_MAIL>' || V_E_MAIL || '</E_MAIL>
				<STATUS_CD>' || V_STATUS_CD || '</STATUS_CD>
				<STATUS_DATE>' || V_STATUS_DATE ||
                     '</STATUS_DATE>
				<CREATE_DATE>' || V_CREATE_DATE || '</CREATE_DATE>
				<SALES_CODE>' || V_STAFF_NBR || '</SALES_CODE>
				<ACTION>' || v_action || '</ACTION>
			</STAFF>';
        err_msg   := '上传成功';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        ----------STAFF_ATTR循环
      ELSIF V_TABLE_NAME = 'STAFF_ATTR' THEN
        BEGIN
          select b.group_cd, A.ATTR_VALUE, C.STAFF_NBR
            INTO v_attr_id, v_attr_value, V_STAFF_NBR
            from crmv2.STAFF_ATTR a, crmv2.attr_spec b, CRMV2.STAFF C
           where a.STAFF_ATTR_id = v_key_id
             and a.attr_id = b.attr_id
             and b.group_cd like '50000%'
             AND A.STAFF_ID = C.STAFF_ID
             AND C.STAFF_NBR IS NOT NULL;
        exception
          when others then
            select b.group_cd, A.ATTR_VALUE, C.STAFF_NBR
              INTO v_attr_id, v_attr_value, V_STAFF_NBR
              from crmv2.STAFF_ATTR_HIS a, crmv2.attr_spec b, CRMV2.STAFF C
             where a.STAFF_ATTR_id = v_key_id
               and a.attr_id = b.attr_id
               and b.group_cd like '50000%'
               AND A.STAFF_ID = C.STAFF_ID
               AND C.STAFF_NBR IS NOT NULL;

        END;
        v_xml_tmp :=  /* v_xml_tmp ||*/
         '<STAFF_ATTR>
				<SALES_CODE>' || v_STAFF_nbr || '</SALES_CODE>
				<ATTR_ITEMS>
        <ATTR_ITEM>
						<ATTR_ID>' || v_attr_id || '</ATTR_ID>
						<ATTR_VALUE>' || v_attr_value || '</ATTR_VALUE>
						<ACTION>' || v_action || '</ACTION>
					</ATTR_ITEM>
          </ATTR_ITEMS>
			</STAFF_ATTR>';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        err_msg := '上传成功';

        ----CHANNEL_OPERATORS_RELA
      elsif V_TABLE_NAME = 'CHANNEL_OPERATORS_RELA' then
        select b.channel_nbr, c.operators_nbr, /*a.rela_type*/ '10'
          into v_channel_nbr, v_operators_nbr, v_rela_type
          from crmv2.channel_operators_rela a,
               crmv2.channel                b,
               crmv2.operators              c
         where a.channel_id = b.channel_id
           and a.operators_id = c.operators_id
           and a.rela_id = in_key_id;
        v_xml_tmp := '<CHANNEL_OPERATORS_RELAS>
				<CHANNEL_OPERATORS_RELA>
					<CHANNEL_NBR>' || v_channel_nbr ||
                     '</CHANNEL_NBR>
					<OPERATORS_NBR>' || v_operators_nbr ||
                     '</OPERATORS_NBR>
					<RELA_TYPE>' || v_rela_type || '</RELA_TYPE>
					<ACTION>' || v_action ||
                     '</ACTION>
				</CHANNEL_OPERATORS_RELA>
			</CHANNEL_OPERATORS_RELAS>';
        err_msg   := '上传成功';
        ----STAFF_OPERATORS_RELA
      elsif V_TABLE_NAME = 'STAFF_OPERATORS_RELA' then
        select b.staff_nbr, c.operators_nbr, /*a.rela_type*/ '10'
          into v_staff_nbr, v_operators_nbr, v_rela_type
          from crmv2.STAFF_OPERATORS_RELA a,
               crmv2.staff                b,
               crmv2.operators            c
         where a.staff_id = b.staff_id
           and a.operators_id = c.operators_id
           and a.rela_id = in_key_id
           and b.staff_nbr is not null;
        v_xml_tmp := '<STAFF_OPERATORS_RELAS>
				<STAFF_OPERATORS_RELA>
					<SALES_CODE>' || v_staff_nbr ||
                     '</SALES_CODE>
					<OPERATORS_NBR>' || v_operators_nbr ||
                     '</OPERATORS_NBR>
					<RELA_TYPE>' || v_rela_type || '</RELA_TYPE>
					<ACTION>' || v_action ||
                     '</ACTION>
				</STAFF_OPERATORS_RELA>
			</STAFF_OPERATORS_RELAS>';
        err_msg   := '上传成功';
        ----STAFF_CHANNEL_RELA
      elsif V_TABLE_NAME = 'STAFF_CHANNEL_RELA' then
        select b.staff_nbr, c.channel_nbr, a.rela_type
          into v_staff_nbr, v_channel_nbr, v_rela_type
          from crmv2.STAFF_CHANNEL_RELA a, crmv2.staff b, crmv2.channel c
         where a.staff_id = b.staff_id
           and a.channel_id = c.channel_id
           and a.rela_id = in_key_id
           and b.staff_nbr is not null;
        v_xml_tmp := '<STAFF_CHANNEL_RELAS>
				<STAFF_CHANNEL_RELA>
					<SALES_CODE>' || v_staff_nbr || '</SALES_CODE>
					<CHANNEL_NBR>' || v_channel_nbr ||
                     '</CHANNEL_NBR>
					<RELA_TYPE>' || v_rela_type || '</RELA_TYPE>
					<ACTION>' || v_action || '</ACTION>
				</STAFF_CHANNEL_RELA>
			</STAFF_CHANNEL_RELAS>';
        err_msg   := '上传成功';
        ----CHANNEL_RELA
      elsif V_TABLE_NAME = 'CHANNEL_RELA' then
        select b.channel_nbr, c.channel_nbr, a.rela_type
          into v_RELA_CHANNEL_NBR, v_CHANNEL_NBR, v_rela_type
          from CRMV2.CHANNEL_RELA a, crmv2.channel b, crmv2.channel c
         where a.rela_id = in_key_id
           and a.channel_id = b.channel_id
           and a.cha_channel_id = c.channel_id;
        v_xml_tmp := '<CHANNEL_RELA>
				<RELA_CHANNEL_NBR>' || v_RELA_CHANNEL_NBR ||
                     '</RELA_CHANNEL_NBR>
				<RELA_ITEMS>
					<RELA_ITEM>
						<CHANNEL_NBR>' || v_CHANNEL_NBR ||
                     '</CHANNEL_NBR>
						<RELA_TYPE>' || v_rela_type || '</RELA_TYPE>
						<ACTION>' || v_action || '</ACTION>
					</RELA_ITEM>
				</RELA_ITEMS>
			</CHANNEL_RELA>';
        err_msg   := '上传成功';
        ----商圈
      elsif V_TABLE_NAME = 'BIZ_ZONE' then
        begin
          select BIZ_ZONE_NAME,
                 BIZ_ZONE_NBR,
                 BIZ_ZONE_LEVER,
                 BIZ_ZONE_TYPE_CD,
                 IS_CORE,
                 COMMON_REGION_ID,
                 STATUS_CD,
                 TO_CHAR(STATUS_DATE, 'YYYYMMDDHH24MISS')
            into v_BIZ_ZONE_NAME,
                 v_BIZ_ZONE_NBR,
                 v_BIZ_ZONE_LEVER,
                 v_BIZ_ZONE_TYPE_CD,
                 v_IS_CORE,
                 v_COMMON_REGION_ID,
                 v_STATUS_CD,
                 v_STATUS_DATE
            from crmv2.BIZ_ZONE
           where BIZ_ZONE_ID = v_KEY_ID;

        exception
          when others then
            select BIZ_ZONE_NAME,
                   BIZ_ZONE_NBR,
                   BIZ_ZONE_LEVER,
                   BIZ_ZONE_TYPE_CD,
                   IS_CORE,
                   COMMON_REGION_ID,
                   STATUS_CD,
                   TO_CHAR(STATUS_DATE, 'YYYYMMDDHH24MISS')
              into v_BIZ_ZONE_NAME,
                   v_BIZ_ZONE_NBR,
                   v_BIZ_ZONE_LEVER,
                   v_BIZ_ZONE_TYPE_CD,
                   v_IS_CORE,
                   v_COMMON_REGION_ID,
                   v_STATUS_CD,
                   v_STATUS_DATE
              from crmv2.BIZ_ZONE_his
             where BIZ_ZONE_ID = v_KEY_ID;
            select region_code
              into v_REGION_CODE
              from crmv2.common_region
             where COMMON_REGION_ID = v_COMMON_REGION_ID;
        end;
        select region_code
          into v_REGION_CODE
          from crmv2.common_region
         where COMMON_REGION_ID = v_COMMON_REGION_ID;
        ----C5级需要做转换
        if v_REGION_CODE like '059%' then
          select region_code
            into v_REGION_CODE
            from common_region
           where common_region_id in
                 (select up_region_id
                    from common_region
                   where common_region_id = v_COMMON_REGION_ID);
        end if;
        v_COMMON_REGION_ID := v_REGION_CODE;
        v_xml_tmp          := '<BIZ_ZONE>
        <BIZ_ZONE_NAME>' || v_BIZ_ZONE_NAME ||
                              '</BIZ_ZONE_NAME>
        <BIZ_ZONE_NBR>' || v_BIZ_ZONE_NBR ||
                              '</BIZ_ZONE_NBR>
        <BIZ_ZONE_LEVER>' || v_BIZ_ZONE_LEVER ||
                              '</BIZ_ZONE_LEVER>
        <BIZ_ZONE_TYPE_CD>' ||
                              v_BIZ_ZONE_TYPE_CD || '</BIZ_ZONE_TYPE_CD>
        <IS_CORE>' || v_IS_CORE ||
                              '</IS_CORE>
        <COMMON_REGION_ID>' ||
                              v_COMMON_REGION_ID || '</COMMON_REGION_ID>
        <STATUS_CD>' || v_STATUS_CD ||
                              '</STATUS_CD>
        <STATUS_DATE>' || v_STATUS_DATE ||
                              '</STATUS_DATE>
        <ACTION>' || v_action ||
                              '</ACTION>
			</BIZ_ZONE>';
        err_msg            := '上传成功';
        -----BIZ_ZONE_ATTR
      elsif V_TABLE_NAME = 'BIZ_ZONE_ATTR' then
        begin
          select B.BIZ_ZONE_NBR, C.GROUP_CD, A.ATTR_VALUE
            INTO V_BIZ_ZONE_NBR, V_ATTR_ID, V_ATTR_VALUE
            from crmv2.BIZ_ZONE_ATTR A, CRMV2.BIZ_ZONE B, ATTR_SPEC C
           where A.BIZ_ZONE_ID = B.BIZ_ZONE_ID
             AND A.ATTR_ID = C.ATTR_ID
             AND A.BIZ_ZONE_ATTR_ID = v_KEY_ID;
        exception
          when others then
            select B.BIZ_ZONE_NBR, C.GROUP_CD, A.ATTR_VALUE
              INTO V_BIZ_ZONE_NBR, V_ATTR_ID, V_ATTR_VALUE
              from crmv2.BIZ_ZONE_ATTR_his A, CRMV2.BIZ_ZONE B, ATTR_SPEC C
             where A.BIZ_ZONE_ID = B.BIZ_ZONE_ID
               AND A.ATTR_ID = C.ATTR_ID
               AND A.BIZ_ZONE_ATTR_ID = v_KEY_ID;
        end;
        v_xml_tmp := '<BIZ_ZONE_ATTR>
         <BIZ_ZONE_NBR>' || v_BIZ_ZONE_NBR ||
                     '</BIZ_ZONE_NBR>
         <ATTR_ITEMS>
					<ATTR_ITEM>
						<ATTR_ID>' || V_ATTR_ID ||
                     '</ATTR_ID>
            <ATTR_VALUE>' || V_ATTR_VALUE ||
                     '</ATTR_VALUE>
            <DESCRIPTION></DESCRIPTION>
            <ACTION>' || V_ACTION ||
                     '</ACTION>
            </ATTR_ITEM>
				</ATTR_ITEMS>
			</BIZ_ZONE_ATTR>';
        err_msg   := '上传成功';
        -----CHANNEL_BIZ_ZONE_RELA
      elsif V_TABLE_NAME = 'CHANNEL_BIZ_ZONE_RELA' then
        select b.channel_nbr, c.biz_zone_nbr, a.rela_type
          into v_channel_nbr, v_BIZ_ZONE_NBR, v_rela_type
          from crmv2.CHANNEL_BIZ_ZONE_RELA a,
               crmv2.channel               b,
               crmv2.biz_zone              c
         where a.biz_zone_id = c.biz_zone_id
           and a.channel_id = b.channel_id
           AND b.status_cd not in ('3000', '1200', '1100', '1001')
           and not exists (select *
                  from crmv2.channel_attr d
                 where b.channel_id = d.channel_id
                   and d.attr_id = 800057100
                   and d.attr_value = 'sx'
                   and d.status_cd = '1000')
           and a.rela_id = v_key_id;
        v_xml_tmp := '<CHANNEL_BIZ_ZONE_RELAS>
				<CHANNEL_BIZ_ZONE_RELA>
					<BIZ_ZONE_NBR>' || v_BIZ_ZONE_NBR ||
                     '</BIZ_ZONE_NBR>
          <CHANNEL_NBR>' || v_CHANNEL_NBR ||
                     '</CHANNEL_NBR>
					<RELA_TYPE>' || v_RELA_TYPE || '</RELA_TYPE>
          <DESCRIPTION></DESCRIPTION>
          <ACTION>' || v_action ||
                     '</ACTION>
				</CHANNEL_BIZ_ZONE_RELA>
			</CHANNEL_BIZ_ZONE_RELAS>';
        err_msg   := '上传成功';
      elsif V_TABLE_NAME = 'STAFF_BIZ_ZONE_RELA' then
        select b.staff_nbr, c.biz_zone_nbr, a.rela_TYPE
          into v_staff_nbr, v_BIZ_ZONE_NBR, v_rela_type
          from crmv2.STAFF_BIZ_ZONE_RELA a, crmv2.staff b, crmv2.biz_zone c
         where a.biz_zone_id = c.biz_zone_id
           and a.staff_id = b.staff_id
           and a.rela_id = v_key_id;
        v_xml_tmp := '<STAFF_BIZ_ZONE_RELAS>
				<STAFF_BIZ_ZONE_RELA>
					<BIZ_ZONE_NBR>' || v_BIZ_ZONE_NBR ||
                     '</BIZ_ZONE_NBR>
          <SALES_CODE>' || v_STAFF_NBR ||
                     '</SALES_CODE>
					<RELA_TYPE>' || v_RELA_TYPE || '</RELA_TYPE>
          <DESCRIPTION></DESCRIPTION>
          <ACTION>' || v_action ||
                     '</ACTION>
				</STAFF_BIZ_ZONE_RELA>
			</STAFF_BIZ_ZONE_RELAS>';
        err_msg   := '上传成功';
      ELSE
        err_msg := '无需上传' || v_table_name;
      END IF;
      if err_msg = '上传成功' then
        O_xml := v_in_xml || v_xml_tmp || v_ContractRoot_end;
      end if;
      --v_in_xml   := v_in_xml || v_xml_tmp || v_ContractRoot_end;
      -- dbms_output.put_line(O_xml);
    exception
      when others then
        err_msg := '上传异常';
    end;

  end prc_jt_channel_XML;

  ------删除渠道主表同时删除关联表
  procedure prc_del_channel_and_rela(in_table_name IN VARCHAR2, --表名
                                     in_key_id     IN VARCHAR2, --主键id
                                     modi_staff    IN VARCHAR2, --修改人
                                     modi_reason   IN VARCHAR2, --修改备注
                                     o_msg         OUT VARCHAR2) --输出结果
   as
    --V_SQL varchar2(1000);
  begin

    if upper(in_table_name) = 'CHANNEL' then
      for rec in (select B.*
                    from crmv2.channel_attr b
                   where b.channel_id = in_key_id
                     and b.status_cd <> '1100') LOOP
        UPDATE crmv2.channel_attr
           SET STATUS_CD   = '1100',
               status_date = sysdate,
               update_date = sysdate
         where CHANNEL_ATTR_ID = REC.CHANNEL_ATTR_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('CHANNEL_ATTR',
                                                  REC.CHANNEL_ATTR_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;

      for rec in (select B.*
                    from crmv2.channel_rela b
                   where (b.channel_id = in_key_id or
                         cha_channel_id = in_key_id)
                     and b.status_cd <> '1100') LOOP
        UPDATE crmv2.channel_rela
           SET STATUS_CD = '1100', status_date = sysdate
         where RELA_ID = REC.RELA_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('CHANNEL_RELA',
                                                  REC.RELA_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;

      for rec in (select *
                    from crmv2.channel_operators_rela B
                   where b.status_cd <> '1100'
                     AND b.channel_id = in_key_id) LOOP
        UPDATE crmv2.channel_operators_rela
           SET STATUS_CD = '1100', status_date = sysdate
         where RELA_ID = REC.RELA_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('CHANNEL_OPERATORS_RELA',
                                                  REC.RELA_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;

      for rec in (select *
                    from crmv2.staff_channel_rela B
                   where b.status_cd <> '1100'
                     AND b.channel_id = in_key_id) LOOP
        UPDATE crmv2.staff_channel_rela
           SET STATUS_CD = '1100', status_date = sysdate
         where RELA_ID = REC.RELA_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('STAFF_CHANNEL_RELA',
                                                  REC.RELA_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);

      END LOOP;

      for rec in (select B.*
                    from crmv2.channel_org_rela b
                   where b.channel_id = in_key_id
                     and b.status_cd <> '1100') LOOP

        ----不上传集团
        insert into crmv2.channel_org_rela_his
          (RELA_ID,
           CHANNEL_ID,
           ORG_ID,
           RELA_TYPE,
           DESCRIPTION,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           AREA_ID,
           REGION_CD,
           CREATE_STAFF,
           UPDATE_DATE,
           UPDATE_STAFF,
           HIS_ID)
          select RELA_ID,
                 CHANNEL_ID,
                 ORG_ID,
                 RELA_TYPE,
                 modi_reason,
                 '1100',
                 STATUS_DATE,
                 CREATE_DATE,
                 AREA_ID,
                 REGION_CD,
                 CREATE_STAFF,
                 sysdate,
                 UPDATE_STAFF,
                 crmv2.seq_channel_org_rela_his_id.nextval
            from crmv2.channel_org_rela
           where rela_id = rec.rela_id;
        delete from crmv2.channel_org_rela where rela_id = rec.rela_id;
        commit;
      END LOOP;
      o_msg := '删除成功';
    elsif upper(in_table_name) = 'OPERATORS' then
      for rec in (select B.*
                    from crmv2.OPERATORS_ATTR b
                   where b.OPERATORS_ID = in_key_id
                     and b.status_cd <> '1100') LOOP
        UPDATE crmv2.OPERATORS_attr
           SET STATUS_CD = '1100', status_date = sysdate
         where OPERATORS_ATTR_ID = REC.OPERATORS_ATTR_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('OPERATORS_ATTR',
                                                  REC.OPERATORS_ATTR_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;

      for rec in (select *
                    from crmv2.channel_operators_rela B
                   where b.status_cd <> '1100'
                     AND b.OPERATORS_ID = in_key_id) LOOP
        UPDATE crmv2.channel_operators_rela
           SET STATUS_CD = '1100', status_date = sysdate
         where RELA_ID = REC.RELA_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('CHANNEL_OPERATORS_RELA',
                                                  REC.RELA_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;

      for rec in (select *
                    from crmv2.STAFF_operators_rela B
                   where b.status_cd <> '1100'
                     AND b.OPERATORS_ID = in_key_id) LOOP
        UPDATE crmv2.STAFF_OPERATORS_RELA
           SET STATUS_CD = '1100', status_date = sysdate
         where RELA_ID = REC.RELA_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('STAFF_OPERATORS_RELA',
                                                  REC.RELA_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;
      o_msg := '删除成功';
    elsif upper(in_table_name) = 'STAFF' then
      for rec in (select B.*
                    from crmv2.STAFF_ATTR b
                   where b.STAFF_ID = in_key_id
                     and b.status_cd <> '1100') LOOP
        UPDATE crmv2.STAFF_ATTR
           SET STATUS_CD = '1100', status_date = sysdate
         where STAFF_ATTR_ID = REC.STAFF_ATTR_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('STAFF_ATTR',
                                                  REC.STAFF_ATTR_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;
      for rec in (select *
                    from crmv2.STAFF_operators_rela B
                   where b.status_cd <> '1100'
                     AND b.STAFF_ID = in_key_id) LOOP
        UPDATE crmv2.STAFF_operators_rela
           SET STATUS_CD = '1100', status_date = sysdate
         where RELA_ID = REC.RELA_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('STAFF_OPERATORS_RELA',
                                                  REC.RELA_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);
      END LOOP;
      for rec in (select *
                    from crmv2.staff_channel_rela B
                   where b.status_cd <> '1100'
                     AND b.STAFF_ID = in_key_id) LOOP
        UPDATE crmv2.staff_channel_rela
           SET STATUS_CD = '1100', status_date = sysdate
         where RELA_ID = REC.RELA_ID;
        COMMIT;
        PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main('STAFF_CHANNEL_RELA',
                                                  REC.RELA_ID,
                                                  'DEL',
                                                  modi_staff,
                                                  modi_reason);

      END LOOP;
      ----不上传集团
      UPDATE crmv2.staff_position
         SET STATUS_CD = '1100', status_date = sysdate
       where STAFF_ID = in_key_id
         and status_cd <> '1100';
      update crmv2.party
         set STATUS_CD = '1100', status_date = sysdate
       where party_id in
             (select party_id from crmv2.staff where STAFF_ID = in_key_id)
         and status_cd <> '1100';
      update crmv2.system_user
         set STATUS_CD = '1100', status_date = sysdate
       where STAFF_ID = in_key_id
         and status_cd <> '1100';

      commit;

      o_msg := '删除成功';
    else
      o_msg := '非渠道类主表，不能删除！';
    end if;
    /*
    V_SQL := 'UPDATE CRMV2.' || IN_TABLE_NAME || ' SET STATUS_CD=''1100'' where ' ||
             IN_TABLE_NAME || '_ID=' || in_key_id;
    DBMS_OUTPUT.put_line(V_SQL);
    EXECUTE IMMEDIATE V_SQL;*/
    if o_msg = '删除成功' then
      EXECUTE IMMEDIATE 'UPDATE CRMV2.' || IN_TABLE_NAME ||
                        ' SET STATUS_CD=''1100'',status_date=sysdate where ' ||
                        IN_TABLE_NAME || '_ID=' || in_key_id;
      COMMIT;
      PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(IN_TABLE_NAME,
                                                in_key_id,
                                                'DEL',
                                                modi_staff,
                                                modi_reason);
    end if;
  end prc_del_channel_and_rela;

  /*procedure prc_jt_channel_xml_del(in_table_name in varchar2,
                                   in_key_id1    in varchar2,
                                   in_key_id2    in varchar2,
                                   in_action     in varchar2,
                                   o_xml         out clob,
                                   err_msg       out varchar2) is
    V_TABLE_NAME       varchar2(30);
    v_action           varchar2(20);
    v_in_xml           clob;
    v_top              varchar2(500) := '<?xml version="1.0" encoding="UTF-8"?><ContractRoot>';
    v_ContractRoot_end varchar2(500) := '</CHANNEL_INFO></SvcCont></ContractRoot>';
    v_xml_tmp          varchar2(4000);
    --v_sub_xml_tmp          varchar2(4000);
    v_Transaction_ID varchar2(50);
    v_key_id1        varchar2(30);
    v_key_id2        varchar2(30);
    v_day            varchar2(50) := to_char(sysdate, 'yyyymmdd');
    --v_cnt                  number(5);
    v_channel_nbr     varchar2(20);
    v_channel_name    varchar2(100);
    v_channel_class   varchar2(20);
    v_CHANNEL_TYPE_CD varchar2(20);
    --v_CHANNEL_SUBTYPE_CD   varchar2(20);
    v_ORG_ID               varchar2(20);
    v_COMMON_REGION_ID     varchar2(20);
    v_STATUS_CD            varchar2(20);
    v_STATUS_DATE          varchar2(20);
    v_attr_id              varchar2(20);
    v_attr_value           varchar2(20);
    V_OPERATORS_NBR        varchar2(20);
    V_OPERATORS_NAME       varchar2(100);
    V_CERT_TYPE            varchar2(20);
    V_CERT_NUMBER          varchar2(30);
    V_OPERATORS_SNAME      varchar2(100);
    V_ADDRESS              varchar2(200);
    V_OPERATORS_AREA_GRADE varchar2(20);
    V_STAFF_CODE           varchar2(20);
    V_PARTY_ID             varchar2(20);
    V_STAFF_NAME           varchar2(100);
    V_CREATE_DATE          varchar2(20);
    V_STAFF_NBR            varchar2(20);
    v_rela_type            varchar2(20);
    v_RELA_CHANNEL_NBR     varchar2(20);
    --V_CHANNEL_ID           varchar2(20);
    -- V_OPERATORS_ID         varchar2(20);
    --V_STAFF_ID             varchar2(20);
  begin
    begin
      v_xml_tmp := '<TcpCont>
    <TransactionID>6001050001201306131042075381</TransactionID>
    <ActionCode>0</ActionCode>
    <BusCode>BUS33001</BusCode>
    <ServiceCode>SVC33049</ServiceCode>
    <ServiceContractVer>SVC3304920121201</ServiceContractVer>
    <ServiceLevel>1</ServiceLevel>
    <SrcOrgID>600105</SrcOrgID>
    <SrcSysID>6001050001</SrcSysID>
    <SrcSysSign>jtdep60010500011031</SrcSysSign>
    <DstOrgID>100000</DstOrgID>
    <DstSysID>1000000045</DstSysID>
    <ReqTime>20130613104248</ReqTime>
  </TcpCont>
  <SvcCont>
    <CHANNEL_INFO>';
      select '6001050001' || v_day || crmv2.SEQ_INTF_TRANS.nextval
        into v_Transaction_ID
        from dual;

      v_xml_tmp := replace(v_xml_tmp,
                           '6001050001201306131042075381',
                           v_Transaction_ID);
      v_xml_tmp := replace(v_xml_tmp,
                           'jtdep60010500011031',
                           'jtdep60010500011031'); ---改密的时候要修改这边
      v_xml_tmp := replace(v_xml_tmp,
                           '20130613104248',
                           to_char(sysdate, 'yyyymmddhh24miss'));

      v_in_xml := v_top || v_xml_tmp;

      \*--------------------正文子节点---------------------------*\
      V_TABLE_NAME := UPPER(IN_TABLE_NAME);
      v_action     := UPPER(in_action);
      v_key_id1    := IN_KEY_ID1;
      v_key_id2    := IN_KEY_ID2;
      ---CHANNEL
      if V_TABLE_NAME = 'CHANNEL' THEN
        select channel_nbr,
               channel_name,
               channel_class,
               CHANNEL_TYPE_CD,
               '99999999',
               REGION_CODE,
               STATUS_CD,
               to_char(sysdate, 'yyyymmddhh24miss')
          into v_channel_nbr,
               v_channel_name,
               v_channel_class,
               v_CHANNEL_TYPE_CD,
               v_ORG_ID,
               v_COMMON_REGION_ID,
               v_STATUS_CD,
               v_STATUS_DATE
          from crmv2.jt_channel
         where channel_nbr = v_key_id1;

        v_xml_tmp := '<CHANNEL>
        <CHANNEL_NBR>' || v_channel_nbr ||
                     '</CHANNEL_NBR>
        <CHANNEL_NAME>' || v_channel_name ||
                     '</CHANNEL_NAME>
        <CHANNEL_CLASS>' || v_channel_class ||
                     '</CHANNEL_CLASS>
        <CHANNEL_TYPE_CD>' || v_CHANNEL_TYPE_CD ||
                     '</CHANNEL_TYPE_CD>
        <ORG_ID>' || v_ORG_ID ||
                     '</ORG_ID>
        <COMMON_REGION_ID>' || v_COMMON_REGION_ID ||
                     '</COMMON_REGION_ID>
        <STATUS_CD>' || v_STATUS_CD ||
                     '</STATUS_CD>
        <STATUS_DATE>' || v_STATUS_DATE ||
                     '</STATUS_DATE>
        <ACTION>' || v_action || '</ACTION>
        </CHANNEL>';
        err_msg   := '上传成功';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        ----------CHANNEL_ATTR循环

      ELSIF V_TABLE_NAME = 'CHANNEL_ATTR' THEN
        select b.channel_nbr, b.ext_attr_nbr, b.ATTR_VALUE
          INTO v_channel_nbr, v_attr_id, v_attr_value
          from jt_channel_attr b
         where b.channel_nbr = v_key_id1
           and b.ext_attr_nbr = v_key_id2;
        v_xml_tmp :=  \*v_xml_tmp ||*\
         '<CHANNEL_ATTR>
        <CHANNEL_NBR>' || v_channel_nbr ||
                     '</CHANNEL_NBR>
        <ATTR_ITEMS>
        <ATTR_ITEM>
            <ATTR_ID>' || v_attr_id ||
                     '</ATTR_ID>
            <ATTR_VALUE>' || v_attr_value ||
                     '</ATTR_VALUE>
            <ACTION>' || v_action ||
                     '</ACTION>
          </ATTR_ITEM>
          </ATTR_ITEMS>
      </CHANNEL_ATTR>';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        err_msg := '上传成功';

        ----OPERATORS
      elsif V_TABLE_NAME = 'OPERATORS' then
        select OPERATORS_NBR,
               OPERATORS_NAME,
               '',
               '',
               '',
               '',
               OPERATORS_AREA_GRADE,
               COMMON_REGION_ID,
               STATUS_CD,
               to_char(sysdate, 'yyyymmddhh24miss')
          into V_OPERATORS_NBR,
               V_OPERATORS_NAME,
               V_CERT_TYPE,
               V_CERT_NUMBER,
               V_OPERATORS_SNAME,
               V_ADDRESS,
               V_OPERATORS_AREA_GRADE,
               V_COMMON_REGION_ID,
               V_STATUS_CD,
               V_STATUS_DATE
          from jt_OPERATORS
         where operators_nbr = in_key_id1;

        v_xml_tmp := '<OPERATORS>
        <OPERATORS_NBR>' || V_OPERATORS_NBR ||
                     '</OPERATORS_NBR>
        <OPERATORS_NAME>' || V_OPERATORS_NAME ||
                     '</OPERATORS_NAME>
        <CERT_TYPE>' || V_CERT_TYPE ||
                     '</CERT_TYPE>
        <CERT_NBR>' || V_CERT_NUMBER ||
                     '</CERT_NBR>
        <OPERATORS_SNAME>' || V_OPERATORS_SNAME ||
                     '</OPERATORS_SNAME>
        <ADDRESS>' || V_ADDRESS ||
                     '</ADDRESS>
        <OPERATORS_AREA_GRADE>' ||
                     V_OPERATORS_AREA_GRADE || '</OPERATORS_AREA_GRADE>
        <COMMON_REGION_ID>' || V_COMMON_REGION_ID ||
                     '</COMMON_REGION_ID>
        <STATUS_CD>' || V_STATUS_CD ||
                     '</STATUS_CD>
        <STATUS_DATE>' || V_STATUS_DATE ||
                     '</STATUS_DATE>
        <ACTION>' || v_action || '</ACTION>
      </OPERATORS>';
        -- v_in_xml  := v_in_xml || v_xml_tmp;
        ----------OPERATORS_ATTR循环
      ELSIF V_TABLE_NAME = 'OPERATORS_ATTR' THEN
        select b.operators_nbr, b.ext_attr_nbr, b.ATTR_VALUE
          INTO v_operators_nbr, v_attr_id, v_attr_value
          from jt_operators_attr b
         where b.operators_nbr = v_key_id1
           and b.ext_attr_nbr = v_key_id2;
        v_xml_tmp :=  \* v_xml_tmp || *\
         '<OPERATORS_ATTR>
        <OPERATORS_NBR>' || v_operators_nbr ||
                     '</OPERATORS_NBR>
        <ATTR_ITEMS>
        <ATTR_ITEM>
            <ATTR_ID>' || v_attr_id ||
                     '</ATTR_ID>
            <ATTR_VALUE>' || v_attr_value ||
                     '</ATTR_VALUE>
            <ACTION>' || v_action ||
                     '</ACTION>
          </ATTR_ITEM>
          </ATTR_ITEMS>
      </OPERATORS_ATTR>';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        err_msg := '上传成功';

        ----STAFF
      elsif V_TABLE_NAME = 'STAFF' then
        select STAFF_CODE,
               ORG_ID,
               '',
               STAFF_NAME,
               STATUS_CD,
               TO_CHAR(sysdate, 'YYYYMMDDHH24MISS'),
               TO_CHAR(sysdate, 'YYYYMMDDHH24MISS'),
               STAFF_NBR
          INTO V_STAFF_CODE,
               V_ORG_ID,
               V_PARTY_ID,
               V_STAFF_NAME,
               V_STATUS_CD,
               V_STATUS_DATE,
               V_CREATE_DATE,
               V_STAFF_NBR
          from jt_STAFF
         where STAFF_nbr = v_key_id1;
        v_xml_tmp := '<STAFF>
        <STAFF_CODE>' || V_STAFF_CODE ||
                     '</STAFF_CODE>
        <ORG_ID>' || V_ORG_ID || '</ORG_ID>
        <PARTY_ID>' || V_PARTY_ID ||
                     '</PARTY_ID>
        <STAFF_NAME>' || V_STAFF_NAME ||
                     '</STAFF_NAME>
        <STATUS_CD>' || V_STATUS_CD ||
                     '</STATUS_CD>
        <STATUS_DATE>' || V_STATUS_DATE ||
                     '</STATUS_DATE>
        <CREATE_DATE>' || V_CREATE_DATE ||
                     '</CREATE_DATE>
        <SALES_CODE>' || V_STAFF_NBR ||
                     '</SALES_CODE>
        <ACTION>' || v_action || '</ACTION>
      </STAFF>';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        ----------STAFF_ATTR循环
      ELSIF V_TABLE_NAME = 'STAFF_ATTR' THEN
        select b.staff_nbr, b.ext_attr_nbr, b.ATTR_VALUE
          INTO v_staff_nbr, v_attr_id, v_attr_value
          from jt_staff_attr b
         where b.staff_nbr = v_key_id1
           and b.ext_attr_nbr = v_key_id2;
        v_xml_tmp :=  \* v_xml_tmp ||*\
         '<STAFF_ATTR>
        <SALES_CODE>' || v_STAFF_nbr ||
                     '</SALES_CODE>
        <ATTR_ITEMS>
        <ATTR_ITEM>
            <ATTR_ID>' || v_attr_id ||
                     '</ATTR_ID>
            <ATTR_VALUE>' || v_attr_value ||
                     '</ATTR_VALUE>
            <ACTION>' || v_action ||
                     '</ACTION>
          </ATTR_ITEM>
          </ATTR_ITEMS>
      </STAFF_ATTR>';
        --v_in_xml  := v_in_xml || v_xml_tmp;
        err_msg := '上传成功';

        ----CHANNEL_OPERATORS_RELA-OK
      elsif V_TABLE_NAME = 'CHANNEL_OPERATORS_RELA' then
        select channel_nbr, operators_nbr, \*a.rela_type*\ '10'
          into v_channel_nbr, v_operators_nbr, v_rela_type
          from JT_channel_operators_rela
         where channel_nbr = in_key_id1
           and operators_nbr = in_key_id2;
        v_xml_tmp := '<CHANNEL_OPERATORS_RELAS>
        <CHANNEL_OPERATORS_RELA>
          <CHANNEL_NBR>' || v_channel_nbr ||
                     '</CHANNEL_NBR>
          <OPERATORS_NBR>' || v_operators_nbr ||
                     '</OPERATORS_NBR>
          <RELA_TYPE>' || v_rela_type ||
                     '</RELA_TYPE>
          <ACTION>' || v_action ||
                     '</ACTION>
        </CHANNEL_OPERATORS_RELA>
      </CHANNEL_OPERATORS_RELAS>';

        ----STAFF_OPERATORS_RELA
      elsif V_TABLE_NAME = 'STAFF_OPERATORS_RELA' then
        select a.staff_nbr, a.operators_nbr, \*a.rela_type*\ '10'
          into v_staff_nbr, v_operators_nbr, v_rela_type
          from jt_STAFF_OPERATORS_RELA a
         where a.staff_nbr = in_key_id1
           and a.operators_nbr = in_key_id2;
        v_xml_tmp := '<STAFF_OPERATORS_RELAS>
        <STAFF_OPERATORS_RELA>
          <SALES_CODE>' || v_staff_nbr ||
                     '</SALES_CODE>
          <OPERATORS_NBR>' || v_operators_nbr ||
                     '</OPERATORS_NBR>
          <RELA_TYPE>' || v_rela_type ||
                     '</RELA_TYPE>
          <ACTION>' || v_action ||
                     '</ACTION>
        </STAFF_OPERATORS_RELA>
      </STAFF_OPERATORS_RELAS>';

        ----STAFF_CHANNEL_RELA -OK
      elsif V_TABLE_NAME = 'STAFF_CHANNEL_RELA' then
        select staff_nbr, channel_nbr, rela_type
          into v_staff_nbr, v_channel_nbr, v_rela_type
          from JT_STAFF_CHANNEL_RELA a
         where a.staff_nbr = in_key_id1
           and a.channel_nbr = in_key_id2;
        v_xml_tmp := '<STAFF_CHANNEL_RELAS>
        <STAFF_CHANNEL_RELA>
          <SALES_CODE>' || v_staff_nbr ||
                     '</SALES_CODE>
          <CHANNEL_NBR>' || v_channel_nbr ||
                     '</CHANNEL_NBR>
          <RELA_TYPE>' || v_rela_type ||
                     '</RELA_TYPE>
          <ACTION>' || v_action ||
                     '</ACTION>
        </STAFF_CHANNEL_RELA>
      </STAFF_CHANNEL_RELAS>';

        ----CHANNEL_RELA-ok
      elsif V_TABLE_NAME = 'CHANNEL_RELA' then
        select RELA_CHANNEL_nbr, CHANNEL_nbr, RELA_TYPE
          into v_RELA_CHANNEL_NBR, v_CHANNEL_NBR, v_rela_type
          from JT_CHANNEL_RELA A
         where a.RELA_CHANNEL_nbr = in_key_id1
           and a.channel_nbr = in_key_id2;
        v_xml_tmp := '<CHANNEL_RELA>
        <RELA_CHANNEL_NBR>' || v_RELA_CHANNEL_NBR ||
                     '</RELA_CHANNEL_NBR>
        <RELA_ITEMS>
          <RELA_ITEM>
            <CHANNEL_NBR>' || v_CHANNEL_NBR ||
                     '</CHANNEL_NBR>
            <RELA_TYPE>' || v_rela_type ||
                     '</RELA_TYPE>
            <ACTION>' || v_action ||
                     '</ACTION>
          </RELA_ITEM>
        </RELA_ITEMS>
      </CHANNEL_RELA>';
      ELSE
        err_msg := '无需上传' || v_table_name;
      END IF;
      O_xml := v_in_xml || v_xml_tmp || v_ContractRoot_end;
      --v_in_xml   := v_in_xml || v_xml_tmp || v_ContractRoot_end;
      err_msg := '上传成功';
      -- dbms_output.put_line(O_xml);
    exception
      when others then
        err_msg := '上传异常';
    end;

  end prc_jt_channel_xml_del;*/

 /* procedure prc_jt_channel_main_del(in_table_name  in varchar2,
                                    in_key_id1     in varchar2,
                                    in_key_id2     in varchar2,
                                    in_modi_man    in varchar2,
                                    in_modi_reason in varchar2) is
    o_xml    CLOB;
    err_msg  VARCHAR2(500);
    v_seq_id number(15);
  begin

    prc_jt_channel_xml_del(in_table_name,
                           in_key_id1,
                           in_key_id2,
                           'DEL',
                           o_xml,
                           err_msg);
    if O_XML is not null then
      select crmv2.Seq_Intf_Up_Channel_Info_Id.nextval
        into v_seq_id
        from dual;
      insert into crmv2.intf_up_channel_info
        select v_seq_id,
               O_XML,
               '',
               '101',
               SYSDATE,
               SYSDATE,
               '',
               '',
               '99999'
          from dual;
      insert into fflinyx.linyx_channel_bak
      values
        (in_table_name,
         in_key_id1 || ',' || in_key_id2,
         v_seq_id,
         'DEL',
         SYSDATE,
         in_modi_man,
         in_modi_reason);
      commit;
    END IF;
  end prc_jt_channel_main_del;*/
end PKG_JT_CHANNEL_UPLOAD;
/
