CREATE package           crmv2_rules is

  -- Author  : WANGZY
  -- Created : 2011/4/3 16:54:06
  -- Purpose : crm2.0 SQL动态规则

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;
  rule_result_pass  number(10) := 0;
  rule_result_error number(10) := 1;
  rule_result_warn  number(10) := 2;
  -- Public variable declarations
  --<VariableName> <Datatype>;

  -- Public function and procedure declarations
  function chk_lan_nbr_exists(in_product_id   in number,
                              in_acc_nbr      in varchar2,
                              in_prod_inst_id in number, out_result out varchar2) return number;
  -- Public function and procedure declarations
  --III类客户不能订购任何销售品。
  function chk_cust_so(in_cust_id   in number, in_offer_name in varchar2, out_result out varchar2) return number;
end crmv2_rules;
/
