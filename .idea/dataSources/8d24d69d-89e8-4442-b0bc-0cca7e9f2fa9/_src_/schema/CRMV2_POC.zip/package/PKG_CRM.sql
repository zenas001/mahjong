CREATE PACKAGE           PKG_CRM IS
  /*
  封顶断网
  Author  : g.caijx
  Created : 2012-8-3
  */
  PROCEDURE PROC_WIRELESS_BROAD_STOP;
  /*
  封顶断网开机
  Author  : g.caijx
  Created : 2012-8-31
  */
  PROCEDURE PROC_WIRELESS_BROAD_STOP_JOB;
  /*短信发送*/
  PROCEDURE PROC_FOR_SMS(I_ORDER_ITEM_ID IN NUMBER, --订单项ID
                         I_CUST_ORDER_ID IN NUMBER, --客户订单ID
                         O_ERR_CODE      OUT NUMBER, --错误编码（0--成功 1--失败）
                         O_ERR_MSG       OUT VARCHAR2 --错误信息
                         );

  /*--crm00013964 FJREQ_五期_天翼用户入网后自动发送宣传短信的需求
  1、请保留之前已提供的竣工短信通知等功能；
  2、本需求说列的入网包括：新装竣工 和 预开户的开通竣工两种情况；
  3、需求中的第1、第2点需要给189号码发两条短信，请分两次发送；
  4、需求中的第3点，要在竣工后24小时再发短信；
  */
  procedure proc_send_sms_crm00013946(i_area_code      in varchar2,
                                      i_acc_nbr        in varchar2,
                                      i_product_id     in varchar2,
                                      i_prod_inst_id   in varchar2,
                                      i_order_item_id  in varchar2,
                                      i_cust_so_number in varchar2,
                                      i_finish_time    date,
                                      i_time_wnd       in number,
                                      o_err_code       out number,
                                      o_err_msg        out varchar2);

  /*移动语音亲情短号变更短信发送逻辑*/
  procedure proc_send_sms_for_change_qqdhm(I_ORDER_ITEM_ID  IN NUMBER, --订单项ID
                                           I_CUST_ORDER_ID  IN NUMBER, --客户订单ID
                                           v_cust_so_number IN VARCHAR2, --订单流水号
                                           v_time_wnd       IN NUMBER, --时间窗口
                                           o_err_code       out number,
                                           o_err_msg        out varchar2);

  /*亲情短号短信发送逻辑*/
  procedure proc_send_sms_for_qqdh(I_ORDER_ITEM_ID  IN NUMBER, --订单项ID
                                   I_CUST_ORDER_ID  IN NUMBER, --客户订单ID
                                   v_cust_so_number IN VARCHAR2, --订单流水号
                                   v_time_wnd       IN NUMBER, --时间窗口
                                   o_err_code       out number,
                                   o_err_msg        out varchar2);

  /*发送短信并记录日志*/
  procedure proc_send_sms_for_log(i_area_code      in varchar2,
                                  i_acc_nbr        in varchar2,
                                  i_product_id     in varchar2,
                                  i_prod_inst_id   in varchar2,
                                  i_order_item_id  in varchar2,
                                  i_cust_so_number in varchar2,
                                  i_content        in varchar2,
                                  i_time_wnd       in number,
                                  o_err_code       out number,
                                  o_err_msg        out varchar2);

  /*
  Function  ：判断销售品是否为单接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    : 结果（1 是 0 否）
  */
  function is_simple_access_offer(i_prod_offer_id number) return number;

  /*
  Function  ：判断销售品是否为多接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    : 结果（1 是 0 否）
  */
  function is_multi_access_offer(i_prod_offer_id number) return number;
END PKG_CRM;
/
