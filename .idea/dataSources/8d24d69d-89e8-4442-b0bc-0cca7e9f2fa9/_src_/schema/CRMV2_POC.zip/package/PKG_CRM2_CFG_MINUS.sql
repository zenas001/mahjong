CREATE package           PKG_CRM2_CFG_MINUS is

  -- Author  : zhengcl
  -- Created : 2012-8-21 10:11:19
  -- Purpose : 比对2.0配置数据
  PROCEDURE p_allCfgTableMinus(str_msg out VARCHAR2);
  /*
     比对差异出差异表
  */
  PROCEDURE p_minusTable(i_tablename         in VARCHAR2, --2.0的表名
                         i_tablekey          in VARCHAR2, --2.0的表对应主键
                         o_minustablename    out VARCHAR2, --2.0比对表
                         o_bakminustablename out VARCHAR2, --2.0比对表备份
                         o_msg               out VARCHAR2);
  /*
     将差异表的数据导入本地表中
  */
  PROCEDURE p_minusJoinTable(i_tablename      in VARCHAR2, --2.0的表名
                             i_tablekey       in VARCHAR2, --2.0的表对应主键
                             i_minustablename in VARCHAR2, --2.0的比对表
                             o_msg            out VARCHAR2);
  /*
     增加本地网区域查询
  */
  function addAreaId return VARCHAR2;
  /*
    比对有Clob字段的表
  */
/*function minusClobTable(i_tablename      in VARCHAR2, --2.0的表名
                             i_tablekey       in VARCHAR2, --2.0的表对应主键
                             i_minustablename in VARCHAR2,) --2.0的比对表
                              return VARCHAR2;*/
end PKG_CRM2_CFG_MINUS;
/
