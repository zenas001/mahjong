CREATE PACKAGE BODY           PKG_MARK_FOR_WIRE_AND_CUST is

  PROCEDURE PKG_MARK_FOR_WIRE IS
    pi_attr_sign           NUMBER;
    actual_speed_num       NUMBER;
    not_ftth_num           NUMBER;
    hdtv_num               number;
    standard_num           number;
    IS_LESS_100M           BOOLEAN;
    actual_speed_name      varchar(300);
    resource_name          varchar(50);
    speed_value            varchar(50);
    seq_table              number;
    V_AREA_NBR             varchar(50);
    temp_prod_inst_attr_id number;
    standard_attr_num      number;
    CURSOR prod_inst IS
      select pi.prod_inst_id,
             pi.area_id,
             pi.common_region_id,
             pi.owner_cust_id,
             pi.acc_nbr,
             rownum
        from prod_inst pi
       where pi.product_id = 800000008
         and pi.area_code = '0591'
         and pi.status_cd = '100000'
         and pi.prod_inst_id in (7788361);
  begin
    for cur in prod_inst loop
      --区域
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
        FROM AREA_CODE A, COMMON_REGION B, PROD_INST C
       WHERE A.REGION_ID = B.COMMON_REGION_ID
         AND B.COMMON_REGION_ID = C.AREA_ID
         AND C.PROD_INST_ID = cur.prod_inst_id;
      --有实际速率800000283
      select count(1)
        into actual_speed_num
        from prod_inst_attr pia
       where pia.prod_inst_id = cur.prod_inst_id
         and pia.attr_id = 800000283;
      if actual_speed_num > 0 then
        --非ＦＴＴＨ
        select count(1)
          into not_ftth_num
          from prod_inst_attr pia
         where pia.prod_inst_id = cur.prod_inst_id
           and pia.attr_id = 800000324
           and pia.attr_value_id not in (900000707, 800000416);
        if not_ftth_num > 0 then
          select pia.attr_value
            into speed_value
            from prod_inst_attr pia
           where pia.prod_inst_id = cur.prod_inst_id
             and pia.attr_id = 800000283;
          IS_LESS_100M := FUNC_JUDGE_PEED(speed_value);
          --小于100M
          if IS_LESS_100M then
            select count(1)
              into pi_attr_sign
              from prod_inst_attr pia
             where pia.prod_inst_id = cur.prod_inst_id
               and pia.attr_id = 800082042;
            --无属性则添加
            if pi_attr_sign = 0 then
              --速率：20M, 资源类型：LAN’
              select av.attr_value_name
                into actual_speed_name
                from prod_inst_attr pia, attr_value av
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_value_id = av.attr_value_id
                 and av.attr_id = 800000283;
              select av.attr_value_name
                into resource_name
                from prod_inst_attr pia, attr_value av
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800000324
                 and pia.attr_value_id = av.attr_value_id;
              seq_table         := seq_prod_inst_attr_id.nextval;
              actual_speed_name := '速率：' || actual_speed_name || ',' ||
                                   '资源类型：' || resource_name;
              insert into prod_inst_attr
                (PROD_INST_ATTR_ID,
                 PROD_INST_ID,
                 ATTR_ID,
                 ATTR_VALUE,
                 STATUS_CD,
                 STATUS_DATE,
                 EFF_DATE,
                 EXP_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 AREA_ID,
                 REGION_CD)
              values
                (seq_table,
                 cur.prod_inst_id,
                 800082042,
                 actual_speed_name,
                 '1000',
                 sysdate,
                 to_date('2199-01-01', 'yyyy-MM-dd'),
                 sysdate,
                 sysdate,
                 sysdate,
                 cur.area_id,
                 cur.common_region_id);

              pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                      'PROD_INST_ATTR_ID',
                                                      seq_table,
                                                      '速率<100M资源类型非FTTH打标标签',
                                                      '1002',
                                                      '速率<100M资源类型非FTTH打标标签',
                                                      '',
                                                      V_AREA_NBR);

            end if;
          else
            --大于100M有属性，则删除
            select count(1)
              into pi_attr_sign
              from prod_inst_attr pia
             where pia.prod_inst_id = cur.prod_inst_id
               and pia.attr_id = 800082042;
            if pi_attr_sign > 0 then
              --存2表
              seq_table := seq_prod_inst_attr_his_id.nextval;
              insert into prod_inst_attr_his
                select pia.prod_inst_attr_id,
                       pia.prod_inst_id,
                       pia.attr_id,
                       pia.attr_value_id,
                       pia.attr_value,
                       '1100',
                       pia.status_date,
                       pia.eff_date,
                       pia.exp_date,
                       pia.create_date,
                       pia.update_date,
                       pia.proc_serial,
                       pia.area_id,
                       pia.region_cd,
                       pia.update_staff,
                       pia.create_staff,
                       seq_table,
                       pia.rec_update_date,
                       pia.version
                  from prod_inst_attr pia
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_id = 800082042;
              ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS',
                                           'HIS_ID',
                                           seq_table,
                                           'PROD_INST_ATTR_HIS 插入历史',
                                           '51447',
                                           'CREATE',
                                           '');
              --删1表
              select pia.prod_inst_attr_id
                into temp_prod_inst_attr_id
                from prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082042;
              delete from prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082042;
              pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                      'PROD_INST_ATTR_ID',
                                                      temp_prod_inst_attr_id,
                                                      '大于100M,删除速率<100M资源类型非FTTH打标标签',
                                                      '1002',
                                                      '大于100M,删除速率<100M资源类型非FTTH打标标签',
                                                      '',
                                                      V_AREA_NBR);
            end if;
          end if;
        else
          --FTTH
          select count(1)
            into pi_attr_sign
            from prod_inst_attr pia
           where pia.prod_inst_id = cur.prod_inst_id
             and pia.attr_id = 800082042;
          if pi_attr_sign > 0 then
            --存2表
            seq_table := seq_prod_inst_attr_his_id.nextval;
            insert into prod_inst_attr_his
              select pia.prod_inst_attr_id,
                     pia.prod_inst_id,
                     pia.attr_id,
                     pia.attr_value_id,
                     pia.attr_value,
                     pia.status_cd,
                     pia.status_date,
                     pia.eff_date,
                     pia.exp_date,
                     pia.create_date,
                     pia.update_date,
                     pia.proc_serial,
                     pia.area_id,
                     pia.region_cd,
                     pia.update_staff,
                     pia.create_staff,
                     seq_table,
                     pia.rec_update_date,
                     pia.version
                from prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082042;
            ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS',
                                         'HIS_ID',
                                         seq_table,
                                         'PROD_INST_ATTR_HIS 插入历史',
                                         '51447',
                                         'CREATE',
                                         '');
            --删1表
            select pia.prod_inst_attr_id
              into temp_prod_inst_attr_id
              from prod_inst_attr pia
             where pia.prod_inst_id = cur.prod_inst_id
               and pia.attr_id = 800082042;
            delete from prod_inst_attr pia
             where pia.prod_inst_id = cur.prod_inst_id
               and pia.attr_id = 800082042;
            pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                    'PROD_INST_ATTR_ID',
                                                    temp_prod_inst_attr_id,
                                                    '资源类型是FTTH,删除速率<100M资源类型非FTTH打标标签',
                                                    '1002',
                                                    '大于100M,删除速率<100M资源类型非FTTH打标标签',
                                                    '',
                                                    V_AREA_NBR);
          end if;
          --用户名下没有高清，只有标清的才打标
          select count(1)
            into hdtv_num
            from prod_inst pi
           where pi.owner_cust_id = cur.owner_cust_id
             and pi.product_id = 901296614;
          if hdtv_num = 0 then
            select count(1)
              into standard_num
              from prod_inst pi
             where pi.owner_cust_id = cur.owner_cust_id
               and pi.product_id = 800000091;
            if standard_num > 0 then
              select count(1)
                into standard_attr_num
                from crmv2.prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082043;
              --未打标，才打标
              if standard_attr_num = 0 then
                --800082043
                seq_table := seq_prod_inst_attr_id.nextval;
                insert into prod_inst_attr
                  (PROD_INST_ATTR_ID,
                   PROD_INST_ID,
                   ATTR_ID,
                   ATTR_VALUE,
                   STATUS_CD,
                   STATUS_DATE,
                   EFF_DATE,
                   EXP_DATE,
                   CREATE_DATE,
                   UPDATE_DATE,
                   AREA_ID,
                   REGION_CD)
                values
                  (seq_table,
                   cur.prod_inst_id,
                   800082043,
                   cur.acc_nbr,
                   '1000',
                   sysdate,
                   to_date('2199-01-01', 'yyyy-MM-dd'),
                   sysdate,
                   sysdate,
                   sysdate,
                   cur.area_id,
                   cur.common_region_id);
                pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                        'PROD_INST_ATTR_ID',
                                                        seq_table,
                                                        '用户名下没有高清,有装标清ITV，则打上有标清iTV且资源类型FTTH标签',
                                                        '1002',
                                                        '用户名下没有高清,有装标清ITV，则打上有标清iTV且资源类型FTTH标签',
                                                        '',
                                                        V_AREA_NBR);
              end if;

            else
              select count(1)
                into standard_attr_num
                from crmv2.prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082044;
              --未打标，才打标
              if standard_attr_num = 0 then
                seq_table := seq_prod_inst_attr_id.nextval;
                insert into prod_inst_attr
                  (PROD_INST_ATTR_ID,
                   PROD_INST_ID,
                   ATTR_ID,
                   ATTR_VALUE,
                   STATUS_CD,
                   STATUS_DATE,
                   EFF_DATE,
                   EXP_DATE,
                   CREATE_DATE,
                   UPDATE_DATE,
                   AREA_ID,
                   REGION_CD)
                values
                  (seq_table,
                   cur.prod_inst_id,
                   800082044,
                   cur.acc_nbr,
                   '1000',
                   sysdate,
                   to_date('2199-01-01', 'yyyy-MM-dd'),
                   sysdate,
                   sysdate,
                   sysdate,
                   cur.area_id,
                   cur.common_region_id);
                pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                        'PROD_INST_ATTR_ID',
                                                        seq_table,
                                                        '用户名下没有高清,没有装标清ITV，则打上资源类型FTTH且没装ITV标签',
                                                        '1002',
                                                        '用户名下没有高清,没有装标清ITV，则打上资源类型FTTH且没装ITV标签',
                                                        '',
                                                        V_AREA_NBR);
              end if;

            end if;
          end if;

        end if;

      else
        --有下行速率800000315
        select count(1)
          into actual_speed_num
          from prod_inst_attr pia
         where pia.prod_inst_id = cur.prod_inst_id
           and pia.attr_id = 800000315;
        if actual_speed_num > 0 then
          --非ＦＴＴＨ
          select count(1)
            into not_ftth_num
            from prod_inst_attr pia
           where pia.prod_inst_id = cur.prod_inst_id
             and pia.attr_id = 800000324
             and pia.attr_value_id not in (900000707, 800000416);
          if not_ftth_num > 0 then
            select pia.attr_value
              into speed_value
              from prod_inst_attr pia
             where pia.prod_inst_id = cur.prod_inst_id
               and pia.attr_id = 800000315;
            IS_LESS_100M := FUNC_JUDGE_PEED(speed_value);
            --小于100M
            if IS_LESS_100M then
              select count(1)
                into pi_attr_sign
                from prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082042;
              --无属性则添加
              if pi_attr_sign = 0 then
                --速率：20M, 资源类型：LAN’
                select av.attr_value_name
                  into actual_speed_name
                  from prod_inst_attr pia, attr_value av
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_value_id = av.attr_value_id
                   and av.attr_id = 800000315;
                select av.attr_value_name
                  into resource_name
                  from prod_inst_attr pia, attr_value av
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_id = 800000324
                   and pia.attr_value_id = av.attr_value_id;
                seq_table         := seq_prod_inst_attr_id.nextval;
                actual_speed_name := '速率：' || actual_speed_name || ',' ||
                                     '资源类型：' || resource_name;
                insert into prod_inst_attr
                  (PROD_INST_ATTR_ID,
                   PROD_INST_ID,
                   ATTR_ID,
                   ATTR_VALUE,
                   STATUS_CD,
                   STATUS_DATE,
                   EFF_DATE,
                   EXP_DATE,
                   CREATE_DATE,
                   UPDATE_DATE,
                   AREA_ID,
                   REGION_CD)
                values
                  (seq_table,
                   cur.prod_inst_id,
                   800082042,
                   actual_speed_name,
                   '1000',
                   sysdate,
                   to_date('2199-01-01', 'yyyy-MM-dd'),
                   sysdate,
                   sysdate,
                   sysdate,
                   cur.area_id,
                   cur.common_region_id);
                pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                        'PROD_INST_ATTR_ID',
                                                        seq_table,
                                                        '速率<100M资源类型非FTTH打标标签',
                                                        '1002',
                                                        '速率<100M资源类型非FTTH打标标签',
                                                        '',
                                                        V_AREA_NBR);
              end if;
            else
              --大于100M有属性，则删除
              select count(1)
                into pi_attr_sign
                from prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082042;
              if pi_attr_sign > 0 then
                --存2表
                seq_table := seq_prod_inst_attr_his_id.nextval;
                insert into prod_inst_attr_his
                  select pia.prod_inst_attr_id,
                         pia.prod_inst_id,
                         pia.attr_id,
                         pia.attr_value_id,
                         pia.attr_value,
                         '1100',
                         pia.status_date,
                         pia.eff_date,
                         pia.exp_date,
                         pia.create_date,
                         pia.update_date,
                         pia.proc_serial,
                         pia.area_id,
                         pia.region_cd,
                         pia.update_staff,
                         pia.create_staff,
                         seq_prod_inst_attr_his_id.nextval,
                         pia.rec_update_date,
                         pia.version
                    from prod_inst_attr pia
                   where pia.prod_inst_id = cur.prod_inst_id
                     and pia.attr_id = 800082042;
                ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS',
                                             'HIS_ID',
                                             seq_table,
                                             'PROD_INST_ATTR_HIS 插入历史',
                                             '51447',
                                             'CREATE',
                                             '');
                --删1表
                select pia.prod_inst_attr_id
                  into temp_prod_inst_attr_id
                  from prod_inst_attr pia
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_id = 800082042;
                delete from prod_inst_attr pia
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_id = 800082042;
                pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                        'PROD_INST_ATTR_ID',
                                                        temp_prod_inst_attr_id,
                                                        '大于100M,删除速率<100M资源类型非FTTH打标标签',
                                                        '1002',
                                                        '大于100M,删除速率<100M资源类型非FTTH打标标签',
                                                        '',
                                                        V_AREA_NBR);
              end if;
            end if;
          else
            --FTTP
            select count(1)
              into pi_attr_sign
              from prod_inst_attr pia
             where pia.prod_inst_id = cur.prod_inst_id
               and pia.attr_id = 800082042;
            if pi_attr_sign > 0 then
              --存2表
              seq_table := seq_prod_inst_attr_his_id.nextval;
              insert into prod_inst_attr_his
                select pia.prod_inst_attr_id,
                       pia.prod_inst_id,
                       pia.attr_id,
                       pia.attr_value_id,
                       pia.attr_value,
                       '1100',
                       pia.status_date,
                       pia.eff_date,
                       pia.exp_date,
                       pia.create_date,
                       pia.update_date,
                       pia.proc_serial,
                       pia.area_id,
                       pia.region_cd,
                       pia.update_staff,
                       pia.create_staff,
                       seq_table,
                       pia.rec_update_date,
                       pia.version
                  from prod_inst_attr pia
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_id = 800082042;
              ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS',
                                           'HIS_ID',
                                           seq_table,
                                           'PROD_INST_ATTR_HIS 插入历史',
                                           '51447',
                                           'CREATE',
                                           '');
              --删1表
              select pia.prod_inst_attr_id
                into temp_prod_inst_attr_id
                from prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082042;
              delete from prod_inst_attr pia
               where pia.prod_inst_id = cur.prod_inst_id
                 and pia.attr_id = 800082042;
              pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                      'PROD_INST_ATTR_ID',
                                                      temp_prod_inst_attr_id,
                                                      '大于100M,删除速率<100M资源类型非FTTH打标标签',
                                                      '1002',
                                                      '大于100M,删除速率<100M资源类型非FTTH打标标签',
                                                      '',
                                                      V_AREA_NBR);
            end if;
            --用户名下没有高清，只有标清的才打标
            select count(1)
              into hdtv_num
              from prod_inst pi
             where pi.owner_cust_id = cur.owner_cust_id
               and pi.product_id = 901296614;
            if hdtv_num = 0 then
              select count(1)
                into standard_num
                from prod_inst pi
               where pi.owner_cust_id = cur.owner_cust_id
                 and pi.product_id = 800000091;
              if standard_num > 0 then
                select count(1)
                  into standard_attr_num
                  from crmv2.prod_inst_attr pia
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_id = 800082043;
                --未打标，才打标
                if standard_attr_num = 0 then
                  --800082043
                  seq_table := seq_prod_inst_attr_id.nextval;
                  insert into prod_inst_attr
                    (PROD_INST_ATTR_ID,
                     PROD_INST_ID,
                     ATTR_ID,
                     ATTR_VALUE,
                     STATUS_CD,
                     STATUS_DATE,
                     EFF_DATE,
                     EXP_DATE,
                     CREATE_DATE,
                     UPDATE_DATE,
                     AREA_ID,
                     REGION_CD)
                  values
                    (seq_table,
                     cur.prod_inst_id,
                     800082043,
                     '',
                     '1000',
                     sysdate,
                     to_date('2199-01-01', 'yyyy-MM-dd'),
                     sysdate,
                     sysdate,
                     sysdate,
                     cur.area_id,
                     cur.common_region_id);
                  pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                          'PROD_INST_ATTR_ID',
                                                          seq_table,
                                                          '用户名下没有高清,有装标清ITV，则打上有标清iTV且资源类型FTTH标签',
                                                          '1002',
                                                          '用户名下没有高清,有装标清ITV，则打上有标清iTV且资源类型FTTH标签',
                                                          '',
                                                          V_AREA_NBR);
                end if;

              else
                select count(1)
                  into standard_attr_num
                  from crmv2.prod_inst_attr pia
                 where pia.prod_inst_id = cur.prod_inst_id
                   and pia.attr_id = 800082044;
                --未打标，才打标
                if standard_attr_num = 0 then
                  seq_table := seq_prod_inst_attr_id.nextval;
                  insert into prod_inst_attr
                    (PROD_INST_ATTR_ID,
                     PROD_INST_ID,
                     ATTR_ID,
                     ATTR_VALUE,
                     STATUS_CD,
                     STATUS_DATE,
                     EFF_DATE,
                     EXP_DATE,
                     CREATE_DATE,
                     UPDATE_DATE,
                     AREA_ID,
                     REGION_CD)
                  values
                    (seq_table,
                     cur.prod_inst_id,
                     800082044,
                     '',
                     '1000',
                     sysdate,
                     to_date('2199-01-01', 'yyyy-MM-dd'),
                     sysdate,
                     sysdate,
                     sysdate,
                     cur.area_id,
                     cur.common_region_id);
                  pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                                          'PROD_INST_ATTR_ID',
                                                          seq_table,
                                                          '用户名下没有高清,没有装标清ITV，则打上资源类型FTTH且没装ITV标签',
                                                          '1002',
                                                          '用户名下没有高清,没有装标清ITV，则打上资源类型FTTH且没装ITV标签',
                                                          '',
                                                          V_AREA_NBR);
                end if;

              end if;
            end if;
          end if;
        end if;
      end if;
      IF MOD(cur.rownum, 1000) = 0 then
        COMMIT;
      END if;
    end loop;
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  end PKG_MARK_FOR_WIRE;

  PROCEDURE PKG_MARK_FOR_CUST IS
    less_100_not_ftth_num  number;
    less_100_not_ftth_attr number;
    standard_ftth_num      number;
    standard_ftth_attr     number;
    ftth_not_itv_num       number;
    ftth_not_itv_attr      number;
    cust_has_flag          number;
    seq_table              number;
    V_AREA_NBR             varchar(50);
    CURSOR prod_inst IS
      select pi.prod_inst_id,
             pi.area_id,
             pi.common_region_id,
             pi.owner_cust_id,
             pi.acc_nbr,
             rownum
        from prod_inst pi
       where pi.product_id = 800000008
         and pi.area_code = '0591'
         and pi.status_cd = '100000'
         and pi.prod_inst_id in (7788361);
  begin
    for cur in prod_inst loop
      --区域
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
        FROM AREA_CODE A, COMMON_REGION B, CUST C
       WHERE A.REGION_ID = B.COMMON_REGION_ID
         AND B.COMMON_REGION_ID = C.AREA_ID
         AND C.CUST_ID = cur.Owner_Cust_Id;
      --速率<100M资源类型非FTTH 800082042
      select count(1)
        into less_100_not_ftth_num
        from prod_inst pi, prod_inst_attr pia
       where pi.prod_inst_id = pia.prod_inst_id
         and pi.owner_cust_id = cur.owner_cust_id
         and pia.attr_id = 800082042;
      if less_100_not_ftth_num > 0 then
        --判断客户上是否已经打过标
        select count(1)
          into cust_has_flag
          from cust_external_attr c
         where c.cust_id = cur.owner_cust_id
           and c.attr_id = 800082045;
        if cust_has_flag = 0 then
          for cur_prod_inst in (select pi.owner_cust_id,
                                       c.common_region_id,
                                       c.area_id,
                                       pi.acc_nbr,
                                       pia.attr_value
                                  from prod_inst      pi,
                                       prod_inst_attr pia,
                                       cust           c
                                 where pi.prod_inst_id = pia.prod_inst_id
                                   and pi.owner_cust_id = cur.owner_cust_id
                                   and c.cust_id = pi.owner_cust_id
                                   and pia.attr_id = 800082042) loop
            seq_table := seq_cust_external_attr_id.nextval;
            insert into cust_external_attr
              (CUST_EXTERNAL_ATTR_ID,
               CUST_ID,
               ATTR_ID,
               ATTR_VALUE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               ATTR_VALUE_ID,
               AREA_ID,
               REGION_CD)
            values
              (seq_table,
               cur_prod_inst.owner_cust_id,
               800082045,
               cur_prod_inst.acc_nbr || '：' || cur_prod_inst.attr_value,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               cur_prod_inst.area_id,
               cur_prod_inst.common_region_id);
            pkg_common.PROC_INTF_INS_BILLING_UPDATE('CUST_EXTERNAL_ATTR',
                                                    'CUST_EXTERNAL_ATTR_ID',
                                                    seq_table,
                                                    '宽带上有速率<100M资源类型非FTTH这个标签,则给客户打标',
                                                    '1002',
                                                    '宽带上有速率<100M资源类型非FTTH这个标签,则给客户打标',
                                                    '',
                                                    V_AREA_NBR);
            exit;
          end loop;
        end if;
      else
        select count(1)
          into less_100_not_ftth_attr
          from cust_external_attr c
         where c.cust_id = cur.owner_cust_id
           and c.attr_id = 800082045;
        if less_100_not_ftth_attr > 0 then
          --存2表
          seq_table := seq_cust_external_attr_his_id.nextval;
          insert into cust_external_attr_his
            select c.cust_external_attr_id,
                   c.cust_id,
                   c.attr_id,
                   c.attr_value,
                   '1100',
                   sysdate,
                   sysdate,
                   sysdate,
                   c.attr_value_id,
                   c.area_id,
                   c.region_cd,
                   c.update_staff,
                   c.create_staff,
                   seq_table
              from cust_external_attr c
             where c.cust_id = cur.owner_cust_id
               and c.attr_id = 800082045;
          ds_ins_intf_ins_ds_update_wh('CUST_EXTERNAL_ATTR_HIS',
                                       'HIS_ID',
                                       seq_table,
                                       'CUST_EXTERNAL_ATTR_HIS 插入历史',
                                       '51447',
                                       'CREATE',
                                       '');
          --删1表
          select c.cust_external_attr_id
            into seq_table
            from cust_external_attr c
           where c.cust_id = cur.owner_cust_id
             and c.attr_id = 800082045;
          delete from cust_external_attr c
           where c.cust_id = cur.owner_cust_id
             and c.attr_id = 800082045;
          pkg_common.PROC_INTF_INS_BILLING_UPDATE('CUST_EXTERNAL_ATTR',
                                                  'CUST_EXTERNAL_ATTR_ID',
                                                  seq_table,
                                                  '宽带上没有速率<100M资源类型非FTTH这个标签,则将客户标签删除',
                                                  '1002',
                                                  '宽带上没有速率<100M资源类型非FTTH这个标签,则将客户标签删除',
                                                  '',
                                                  V_AREA_NBR);
        end if;
      end if;
      --有标清iTV且资源类型FTTH 800082043
      select count(1)
        into standard_ftth_num
        from prod_inst pi, prod_inst_attr pia
       where pi.prod_inst_id = pia.prod_inst_id
         and pi.owner_cust_id = cur.owner_cust_id
         and pia.attr_id = 800082043;
      if standard_ftth_num > 0 then
        --判断客户上是否已经打过标
        select count(1)
          into cust_has_flag
          from cust_external_attr c
         where c.cust_id = cur.owner_cust_id
           and c.attr_id = 800082046;
        if cust_has_flag = 0 then
          for cur_prod_inst in (select pi.owner_cust_id,
                                       c.common_region_id,
                                       c.area_id,
                                       pi.acc_nbr,
                                       pia.attr_value
                                  from prod_inst      pi,
                                       prod_inst_attr pia,
                                       cust           c
                                 where pi.prod_inst_id = pia.prod_inst_id
                                   and pi.owner_cust_id = cur.owner_cust_id
                                   and c.cust_id = pi.owner_cust_id
                                   and pia.attr_id = 800082043) loop
            seq_table := seq_cust_external_attr_id.nextval;
            insert into cust_external_attr
              (CUST_EXTERNAL_ATTR_ID,
               CUST_ID,
               ATTR_ID,
               ATTR_VALUE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               ATTR_VALUE_ID,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF)
            values
              (seq_table,
               cur_prod_inst.owner_cust_id,
               800082046,
               cur_prod_inst.acc_nbr,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               cur_prod_inst.area_id,
               cur_prod_inst.common_region_id,
               null,
               null);
            pkg_common.PROC_INTF_INS_BILLING_UPDATE('CUST_EXTERNAL_ATTR',
                                                    'CUST_EXTERNAL_ATTR_ID',
                                                    seq_table,
                                                    '宽带上有标清iTV且资源类型FTTH这个标签,则给客户打标',
                                                    '1002',
                                                    '宽带上有标清iTV且资源类型FTTH这个标签,则给客户打标',
                                                    '',
                                                    V_AREA_NBR);
            exit;
          end loop;
        end if;
      else
        select count(1)
          into standard_ftth_attr
          from cust_external_attr c
         where c.cust_id = cur.owner_cust_id
           and c.attr_id = 800082046;
        if standard_ftth_attr > 0 then
          --存2表
          seq_table := seq_cust_external_attr_his_id.nextval;
          insert into cust_external_attr_his
            select c.cust_external_attr_id,
                   c.cust_id,
                   c.attr_id,
                   c.attr_value,
                   '1100',
                   sysdate,
                   sysdate,
                   sysdate,
                   c.attr_value_id,
                   c.area_id,
                   c.region_cd,
                   c.update_staff,
                   c.create_staff,
                   seq_table
              from cust_external_attr c
             where c.cust_id = cur.owner_cust_id
               and c.attr_id = 800082046;
          ds_ins_intf_ins_ds_update_wh('CUST_EXTERNAL_ATTR_HIS',
                                       'HIS_ID',
                                       seq_table,
                                       'CUST_EXTERNAL_ATTR_HIS 插入历史',
                                       '51447',
                                       'CREATE',
                                       '');
          --删1表
          select c.cust_external_attr_id
            into seq_table
            from cust_external_attr c
           where c.cust_id = cur.owner_cust_id
             and c.attr_id = 800082046;
          delete from cust_external_attr c
           where c.cust_id = cur.owner_cust_id
             and c.attr_id = 800082046;
          pkg_common.PROC_INTF_INS_BILLING_UPDATE('CUST_EXTERNAL_ATTR',
                                                  'CUST_EXTERNAL_ATTR_ID',
                                                  seq_table,
                                                  '宽带上没有标清iTV且资源类型FTTH这个标签,则将客户标签删除',
                                                  '1002',
                                                  '宽带上没有标清iTV且资源类型FTTH这个标签,则将客户标签删除',
                                                  '',
                                                  V_AREA_NBR);

        end if;
      end if;
      --资源类型FTTH且没装ITV 800082044
      select count(1)
        into ftth_not_itv_num
        from prod_inst pi, prod_inst_attr pia
       where pi.prod_inst_id = pia.prod_inst_id
         and pi.owner_cust_id = cur.owner_cust_id
         and pia.attr_id = 800082044;
      if ftth_not_itv_num > 0 then
        --判断客户上是否已经打过标
        select count(1)
          into cust_has_flag
          from cust_external_attr c
         where c.cust_id = cur.owner_cust_id
           and c.attr_id = 800082047;
        if cust_has_flag = 0 then
          for cur_prod_inst in (select pi.owner_cust_id,
                                       c.common_region_id,
                                       c.area_id,
                                       pi.acc_nbr,
                                       pia.attr_value
                                  from prod_inst      pi,
                                       prod_inst_attr pia,
                                       cust           c
                                 where pi.prod_inst_id = pia.prod_inst_id
                                   and pi.owner_cust_id = cur.owner_cust_id
                                   and c.cust_id = pi.owner_cust_id
                                   and pia.attr_id = 800082044) loop
            seq_table := seq_cust_external_attr_id.nextval;
            insert into cust_external_attr
              (CUST_EXTERNAL_ATTR_ID,
               CUST_ID,
               ATTR_ID,
               ATTR_VALUE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               ATTR_VALUE_ID,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF)
            values
              (seq_table,
               cur_prod_inst.owner_cust_id,
               800082047,
               cur_prod_inst.acc_nbr,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               cur_prod_inst.area_id,
               cur_prod_inst.common_region_id,
               null,
               null);
            pkg_common.PROC_INTF_INS_BILLING_UPDATE('CUST_EXTERNAL_ATTR',
                                                    'CUST_EXTERNAL_ATTR_ID',
                                                    seq_table,
                                                    '宽带上有资源类型FTTH且没装ITV这个标签,则给客户打标',
                                                    '1002',
                                                    '宽带上有资源类型FTTH且没装ITV这个标签,则给客户打标',
                                                    '',
                                                    V_AREA_NBR);
            exit;
          end loop;
        end if;
      else
        select count(1)
          into ftth_not_itv_attr
          from cust_external_attr c
         where c.cust_id = cur.owner_cust_id
           and c.attr_id = 800082047;
        if ftth_not_itv_attr > 0 then
          --存2表
          seq_table := seq_cust_external_attr_his_id.nextval;
          insert into cust_external_attr_his
            select c.cust_external_attr_id,
                   c.cust_id,
                   c.attr_id,
                   c.attr_value,
                   '1100',
                   sysdate,
                   sysdate,
                   sysdate,
                   c.attr_value_id,
                   c.area_id,
                   c.region_cd,
                   c.update_staff,
                   c.create_staff,
                   seq_table
              from cust_external_attr c
             where c.cust_id = cur.owner_cust_id
               and c.attr_id = 800082047;
          ds_ins_intf_ins_ds_update_wh('CUST_EXTERNAL_ATTR_HIS',
                                       'HIS_ID',
                                       seq_table,
                                       'CUST_EXTERNAL_ATTR_HIS 插入历史',
                                       '51447',
                                       'CREATE',
                                       '');
          --删1表
          select c.cust_external_attr_id
            into seq_table
            from cust_external_attr c
           where c.cust_id = cur.owner_cust_id
             and c.attr_id = 800082047;
          delete from cust_external_attr c
           where c.cust_id = cur.owner_cust_id
             and c.attr_id = 800082047;
          pkg_common.PROC_INTF_INS_BILLING_UPDATE('CUST_EXTERNAL_ATTR',
                                                  'CUST_EXTERNAL_ATTR_ID',
                                                  seq_table,
                                                  '宽带上没有资源类型FTTH且没装ITV这个标签,则将客户标签删除',
                                                  '1002',
                                                  '宽带上没有资源类型FTTH且没装ITV这个标签,则将客户标签删除',
                                                  '',
                                                  V_AREA_NBR);

        end if;
      end if;
      IF MOD(cur.rownum, 1000) = 0 then
        COMMIT;
      END if;
    end loop;
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  end PKG_MARK_FOR_CUST;

  FUNCTION FUNC_JUDGE_PEED(attr_value_var IN VARCHAR2) RETURN BOOLEAN IS
  begin
    FOR PZ_ATTR_VALUE IN (select av.attr_value
                            from attr_spec asp, attr_value av
                           where asp.attr_id = av.attr_id
                             and asp.java_code = 'more100M') LOOP
      if PZ_ATTR_VALUE.attr_value = attr_value_var then
        return false;
      end if;
    END LOOP;
    return true;
  END;

  PROCEDURE PROC_MAIN IS
  BEGIN
    PKG_MARK_FOR_WIRE;
    PKG_MARK_FOR_CUST;
  END PROC_MAIN;

END PKG_MARK_FOR_WIRE_AND_CUST;
/
