CREATE PACKAGE BODY           PKG_CRM2_SYNC_NEW_BAK IS
--生产差异数据
  PROCEDURE P_CREATESYNCDATA(I_SYNCID       IN NUMBER, --同步表ID
                                  I_ID           IN NUMBER, --销售品规格ID，产品规格ID
                                  I_AREAID       IN NUMBER, --配置区域
                                  I_LINK         IN VARCHAR2, --目标库的链接
                                  I_BATCH        IN VARCHAR2, --批次
                                  I_ITSM_CODE    IN varchar2, -- ITSM单号 用于remark模糊查询
                                  O_RESULT       OUT VARCHAR2, --返回标识
                                  O_TMPTABLENAME OUT VARCHAR2, --临时表名
                                  O_MSG          OUT VARCHAR2) IS
    V_CNT           NUMBER; --结果变量
    V_SYNCSQL       VARCHAR2(2000); --同步脚本语句
    V_TABLE         VARCHAR2(100); --同步表
    V_SEQ           NUMBER; --同步表顺序
    V_KEYCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_MAPCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_LINKINSTTABLE VARCHAR2(100); --外数据库链接的实例表
    V_EXECUTESQL    VARCHAR2(7000); --实时执行语句
    V_EXECUTESQL_FROM    VARCHAR2(2000); --源数据执行语句
    V_EXECUTESQL_TO   VARCHAR2(2000); --目标数据执行语句
    V_DATATYPE        VARCHAR2(20);   --数据类型
    --V_PRODUCT_ID      VARCHAR2(20);
    --V_OFFER_PROD_RELA_ID VARCHAR2(20);

  BEGIN
    O_RESULT   := 'FALSE';
    /*------------------------------------------------------------------------------------------
      步骤一：根据传入的同步表ID，以及主键和区域ID，拼装出要同步的表数据
    ------------------------------------------------------------------------------------------*/
    FOR COMSYNCCONF IN (SELECT *
                          FROM COM_SYNC_CONF
                         WHERE ID = I_SYNCID) LOOP
      V_SYNCSQL       := COMSYNCCONF.SYNC_SQL;
      V_TABLE         := COMSYNCCONF.TABLE_NAME;
      V_SEQ           := COMSYNCCONF.SEQ;
      V_KEYCOLUMN     := COMSYNCCONF.KEY_COLUMN;
      V_LINKINSTTABLE := COMSYNCCONF.INST_TABLE;
      V_DATATYPE      := COMSYNCCONF.DATA_TYPE;
    END LOOP;
    IF V_SYNCSQL IS NULL OR V_TABLE IS NULL OR V_KEYCOLUMN IS NULL THEN
      O_MSG := '根据ID' || TO_CHAR(I_SYNCID) || '查询com_sync_conf表数据异常,请检查是否Sync_Sql,Table_Name,Key_Column为空';
      RETURN;
    END IF;
    --可能对应实例表的字段与配置字段不同
    V_MAPCOLUMN := V_KEYCOLUMN;
    IF V_LINKINSTTABLE IS NOT NULL THEN
      V_CNT := INSTR(V_LINKINSTTABLE, '-', 1, 1);
      IF V_CNT > 0 THEN
        V_MAPCOLUMN     := SUBSTR(V_LINKINSTTABLE, V_CNT + 1);
        V_LINKINSTTABLE := SUBSTR(V_LINKINSTTABLE, 0, V_CNT - 1);
      END IF;
    END IF;

    --替换主键
    V_CNT := INSTR(V_SYNCSQL, ':id', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL := REPLACE(V_SYNCSQL, ':id', TO_CHAR(I_ID));
    END IF;
    --替换区域
    V_CNT := INSTR(V_SYNCSQL, ':cfgAreaId', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL := REPLACE(V_SYNCSQL, ':cfgAreaId', TO_CHAR(I_AREAID));
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤二： 取出本数据库中要同步表的数据，放入名为 SYNC_FROM_201207100945_1
      (该表名自动生成，字段与原表相同，SYNC_FROM+sysdate+表执行顺序)的表内，
    ------------------------------------------------------------------------------------------*/
    V_EXECUTESQL_FROM := REPLACE(V_SYNCSQL, '@');
    V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM, '#');

    V_CNT := INSTR(I_LINK, '.', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '@');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '#', I_LINK);
    ELSE
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '#');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '@', I_LINK);
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤三： mod by linxi 根据传入的ITSM_CODE模糊查询
    ------------------------------------------------------------------------------------------*/
    V_CNT := INSTR(V_SYNCSQL, '^', 1, 1);
    IF V_CNT > 0 THEN
       IF length(I_ITSM_CODE) >0 THEN
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^' ,' AND REMARK LIKE  ''%'||I_ITSM_CODE||'%''' );
         V_EXECUTESQL_TO := V_SYNCSQL;
         V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '@', I_LINK);
         V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM , '^' ,' AND REMARK LIKE  ''%'||I_ITSM_CODE||'%''' );
       ELSE
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^');
         V_EXECUTESQL_TO := REPLACE(V_EXECUTESQL_TO , '^');
         V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM , '^');
       END IF;
    END IF;
    dbms_output.put_line('OBJ_AREA_RELA: '||V_EXECUTESQL_TO);

    /*------------------------------------------------------------------------------------------
      步骤四：创建差异表,比对以上两个表，
      取出要变更的数据放入差异表中，该表字段为“KEY_ID”放置主键，“MINUS_OP”放置操作类型ADD,DEL,UPDATE。
    ------------------------------------------------------------------------------------------*/

    IF V_DATATYPE = 'PUB' THEN
      --公共数据只能修改
      V_EXECUTESQL := 'INSERT INTO SYNC_MINUSTABLE select SEQ_SYNC_MINUSTABLE_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,'|| V_KEYCOLUMN ||',''UPDATE'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''' from ('|| V_EXECUTESQL_FROM || ')';
      EXECUTE IMMEDIATE V_EXECUTESQL;
    ELSE
      --1.要新增的数据导入差异表
      V_EXECUTESQL := 'INSERT INTO SYNC_MINUSTABLE select SEQ_SYNC_MINUSTABLE_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,n.'|| V_KEYCOLUMN ||',''ADD'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''' from (' ||
                      V_EXECUTESQL_FROM || ') n where not exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' ||
                      V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ')';
      dbms_output.put_line('OBJ_AREA_RELA: '||V_EXECUTESQL);
      EXECUTE IMMEDIATE V_EXECUTESQL;
      --2.要删除的数据导入差异表
      V_EXECUTESQL := 'INSERT INTO SYNC_MINUSTABLE select SEQ_SYNC_MINUSTABLE_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,o.'|| V_KEYCOLUMN ||',''DEL'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||'''  from (' ||
                      V_EXECUTESQL_TO || ') o where not exists (select 1 from (' || V_EXECUTESQL_FROM || ') where ' ||
                      V_KEYCOLUMN || '=o.' || V_KEYCOLUMN || ')  and o.STATUS_CD != ''1100''';
      EXECUTE IMMEDIATE V_EXECUTESQL;
      --3.变更的数据导入差异表
      V_EXECUTESQL := 'INSERT INTO SYNC_MINUSTABLE select SEQ_SYNC_MINUSTABLE_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,'|| V_KEYCOLUMN ||',''UPDATE'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''' from
                      (select * from ('|| V_EXECUTESQL_FROM || ') n where exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' || V_KEYCOLUMN ||
                      '=n.' || V_KEYCOLUMN || ') minus select * from (' || V_EXECUTESQL_TO || '))';
      EXECUTE IMMEDIATE V_EXECUTESQL;
    END IF;

    /*------------------------------------------------------------------------------------------
     步骤五：针对DEL类型数据增加与目标库的实例数据判断，如果已经存在实例，则操作类型更改成DELUP
    ------------------------------------------------------------------------------------------*/
    IF V_LINKINSTTABLE IS NOT NULL THEN
      V_EXECUTESQL := 'select count(*) from SYNC_MINUSTABLE WHERE MINUS_OP = ''DEL'' AND BATCH_NO='''||I_BATCH||'''';
      EXECUTE IMMEDIATE V_EXECUTESQL
        INTO V_CNT;
      IF V_CNT > 0 THEN
        V_CNT := INSTR(I_LINK, '.', 1, 1);
        IF V_CNT > 0 THEN
          V_LINKINSTTABLE := I_LINK || V_LINKINSTTABLE;
        ELSE
          V_LINKINSTTABLE := V_LINKINSTTABLE || I_LINK;
        END IF;


        V_EXECUTESQL := 'UPDATE SYNC_MINUSTABLE SET MINUS_OP=''DELUP'' WHERE MINUS_OP=''DEL'' AND BATCH_NO='''||I_BATCH||''' AND exists (select 1 from ' || V_LINKINSTTABLE ||
                        ' where ' || V_MAPCOLUMN || '= SYNC_MINUSTABLE.KEY_ID)';
        EXECUTE IMMEDIATE V_EXECUTESQL;

      END IF;
    END IF;

    COMMIT;
    O_TMPTABLENAME := V_TABLE;
    O_MSG          := '获取'||V_TABLE||' 表增量数据成功';
    O_RESULT       := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'p_createSyncTempTable:' || SQLERRM;
  END;

--生成执行脚本
  PROCEDURE P_CREATESQL(I_BATCH        IN VARCHAR2, --批次
                        I_LINK         IN VARCHAR2, --目标库的链接
                        I_STAFF        IN VARCHAR2, --操作员工
                        I_LOGIN_IP     IN VARCHAR2, --登陆ip
                        O_RESULT       OUT VARCHAR2, --返回标识
                        O_MSG          OUT VARCHAR2) IS

     V_EXECUTESQL   VARCHAR2(6000); --实时执行语句
     V_SQL          VARCHAR2(4000); --生成的脚本
     V_TABLE_NAME   VARCHAR2(50);
     V_KEY_COLUMN   VARCHAR2(50);
     V_KEY_ID       NUMBER;
     V_CFG_ID       NUMBER;
     V_CNT          NUMBER;
     COLUMN_NAME    VARCHAR2(1000);
     V_MINUS_OP     VARCHAR2(10);

   BEGIN
     O_RESULT   := 'FALSE';
     V_CNT := INSTR(I_LINK, '.', 1, 1);
     --新增
     FOR COMSYNCCONF IN (SELECT distinct batch_no,table_name,key_id,minus_op,cfg_id,key_column,id
                          FROM SYNC_MINUSTABLE
                         WHERE BATCH_NO = I_BATCH order by id asc) LOOP
       V_TABLE_NAME := COMSYNCCONF.TABLE_NAME;
       V_KEY_ID := COMSYNCCONF.KEY_ID;
       V_CFG_ID := COMSYNCCONF.CFG_ID;
       V_KEY_COLUMN := COMSYNCCONF.KEY_COLUMN;
       V_MINUS_OP   := COMSYNCCONF.MINUS_OP;

       --获取列名
       COLUMN_NAME := '';
       for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE_NAME order by column_id) loop
         COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
       end loop;
       COLUMN_NAME := substr(COLUMN_NAME,1,length(COLUMN_NAME)-1);
 --新增
       if V_MINUS_OP='ADD' then
          --同步脚本
          if V_CNT>0 then
            V_SQL := 'insert into '|| V_TABLE_NAME || ' (' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from crmv2.'|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
          else
            V_SQL := 'insert into '|| V_TABLE_NAME || I_LINK || ' (' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from '|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
            EXECUTE IMMEDIATE V_SQL;
          end if;
          V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
          EXECUTE IMMEDIATE V_EXECUTESQL;

          --备份脚本
          V_SQL := 'delete from '||V_TABLE_NAME||' where '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
          V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''BACKUP'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
          EXECUTE IMMEDIATE V_EXECUTESQL;
        end if;
  --修改
        if V_MINUS_OP='UPDATE' then
          --同步脚本,修改采用先删除再新增
          if V_CNT>0 then
             V_SQL := 'delete from '||V_TABLE_NAME||' where '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
          else
             V_SQL := 'delete from '||V_TABLE_NAME|| I_LINK || ' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             EXECUTE IMMEDIATE V_SQL;
          end if;
          V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
          EXECUTE IMMEDIATE V_EXECUTESQL;

          if V_CNT>0 then
             V_SQL := 'insert into '|| V_TABLE_NAME || ' (' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from crmv2.'|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
          else
             V_SQL := 'insert into '|| V_TABLE_NAME || I_LINK || ' (' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from '|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             EXECUTE IMMEDIATE V_SQL;
          end if;
          V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
          EXECUTE IMMEDIATE V_EXECUTESQL;
        end if;
  --删除
        if V_MINUS_OP='DEL' then
           --同步脚本
          if V_CNT>0 then
             V_SQL := 'delete from '||V_TABLE_NAME||' where '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
          else
             V_SQL := 'delete from '||V_TABLE_NAME|| I_LINK || ' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             EXECUTE IMMEDIATE V_SQL;
          end if;
           V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
           EXECUTE IMMEDIATE V_EXECUTESQL;
        end if;

        if V_MINUS_OP='DELUP' then
           if V_CNT>0 then
              V_SQL := 'UPDATE '|| V_TABLE_NAME || ' SET STATUS_CD=''''1100'''' WHERE '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
           else
              V_SQL := 'UPDATE '|| V_TABLE_NAME ||  I_LINK || ' SET STATUS_CD=''''1100'''' WHERE '||V_KEY_COLUMN||'='||V_KEY_ID;
              EXECUTE IMMEDIATE V_SQL;
           end if;
           V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
           EXECUTE IMMEDIATE V_EXECUTESQL;
        end if;

     END LOOP;

     COMMIT;

     O_MSG          := '获取表执行脚本成功';
     O_RESULT       := 'TRUE';
    EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'P_CREATESQL:' || SQLERRM;
   END;
END PKG_CRM2_SYNC_NEW;
/
