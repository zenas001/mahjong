CREATE PACKAGE BODY           PKG_SYNC_VPN_DATA IS
  C_CHANNEL_NBR CONSTANT VARCHAR2(20) := '600105A113';
  C_JK_STAFF_ID CONSTANT STAFF.STAFF_ID%TYPE := 51447; --接口专用工号
  --同步VPN_GROUP表数据
  PROCEDURE PROC_SYNC_VPN_DATA(I_ORDER_ITEM_ID IN NUMBER, --定单项标识
                               O_RET_MSG       OUT VARCHAR2 --返回信息
                               ) IS

    V_EXISTS_FLAG        INT;
    V_GPI_EXISTS_FLAG    INT;
    V_ORDER_ITEM_CD      ORDER_ITEM.ORDER_ITEM_CD%TYPE;
    V_CUST_ORDER_ID      ORDER_ITEM.CUST_ORDER_ID%TYPE;
    V_GPI_ORDER_ITEM_ID  ORDER_ITEM.ORDER_ITEM_ID%TYPE;
    V_GROUP_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
    V_ORDER_ITEM_OBJ_ID  ORDER_ITEM.ORDER_ITEM_OBJ_ID%TYPE;
    V_PRODUCT_TYPE       PRODUCT.PRODUCT_TYPE%TYPE;
  BEGIN
    --初始化
    O_RET_MSG := 'SUCCESS';

    --查询订单信息
    BEGIN
      SELECT 2, ORDER_ITEM_CD, CUST_ORDER_ID, ORDER_ITEM_OBJ_ID
        INTO V_EXISTS_FLAG,
             V_ORDER_ITEM_CD,
             V_CUST_ORDER_ID,
             V_ORDER_ITEM_OBJ_ID
        FROM ORDER_ITEM_HIS
       WHERE ORDER_ITEM_ID = I_ORDER_ITEM_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT 1, ORDER_ITEM_CD, CUST_ORDER_ID, ORDER_ITEM_OBJ_ID
            INTO V_EXISTS_FLAG,
                 V_ORDER_ITEM_CD,
                 V_CUST_ORDER_ID,
                 V_ORDER_ITEM_OBJ_ID
            FROM ORDER_ITEM
           WHERE ORDER_ITEM_ID = I_ORDER_ITEM_ID;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            O_RET_MSG := '取不到订单信息';
            RETURN;
        END;
    END;

    /*
    销售品不做处理
    因为在定单竣工处理时,销售品可能不会产生intf_order表记录
    不采用销售品作为vpn_group表变动触发条件，用产品作为触发条件
    */
    IF V_ORDER_ITEM_CD = 1200 THEN
      O_RET_MSG := 'INVALID';
      RETURN;
    END IF;

    --------------------------------------------------------------------------------
    ------- 销售品产品实例关联关系 OFFER_PROD_INST_REL 从prod_inst_id出发处理-------
    --------------------------------------------------------------------------------
    FOR REC_PO IN (SELECT A.OBJ_INST_ID,
                          A.OPERATE,
                          A.ORDER_ITEM_PROC_ATTR_ID
                     FROM ORDER_ITEM_PROC_ATTR_HIS A
                    WHERE A.ORDER_ITEM_ID = I_ORDER_ITEM_ID
                      AND A.OBJ_ATTR = 'offerProdInstRels'
                      AND V_EXISTS_FLAG = 2
                   UNION ALL
                   SELECT A.OBJ_INST_ID,
                          A.OPERATE,
                          A.ORDER_ITEM_PROC_ATTR_ID
                     FROM ORDER_ITEM_PROC_ATTR A
                    WHERE A.ORDER_ITEM_ID = I_ORDER_ITEM_ID
                      AND A.OBJ_ATTR = 'offerProdInstRels'
                      AND V_EXISTS_FLAG = 1) LOOP

      PROC_DEAL_OPIR(I_ORDER_ITEM_ID           => I_ORDER_ITEM_ID,
                     I_ORDER_ITEM_PROC_ATTR_ID => REC_PO.ORDER_ITEM_PROC_ATTR_ID,
                     I_OBJ_INST_ID             => REC_PO.OBJ_INST_ID,
                     I_OPERATE                 => REC_PO.OPERATE);
    END LOOP;

    /*
     群组产品与单接入类的prodInstRelId一样，会造成两条重复的vpn_group记录
     不处理
    */
    IF V_ORDER_ITEM_CD = 1300 THEN
      BEGIN
        SELECT P.PRODUCT_TYPE
          INTO V_PRODUCT_TYPE
          FROM PROD_INST PI, PRODUCT P
         WHERE PI.PROD_INST_ID = V_ORDER_ITEM_OBJ_ID
           AND PI.PRODUCT_ID = P.PRODUCT_ID;
      EXCEPTION
        WHEN OTHERS THEN
          V_PRODUCT_TYPE := '';
      END;
      IF V_PRODUCT_TYPE != '10' THEN
        COMMIT;
        RETURN;
      END IF;
    END IF;

    --------------------------------------------------------------------------------
    ----------------------产品实例关联关系 PROD_INST_REL----------------------------
    --------------------------------------------------------------------------------
    FOR REC_PI IN (SELECT A.OBJ_INST_ID,
                          A.OPERATE,
                          A.ORDER_ITEM_PROC_ATTR_ID
                     FROM ORDER_ITEM_PROC_ATTR_HIS A
                    WHERE A.ORDER_ITEM_ID = I_ORDER_ITEM_ID
                      AND A.OBJ_ATTR = 'composeProdInstRelsZ'
                      AND V_EXISTS_FLAG = 2
                   UNION ALL
                   SELECT A.OBJ_INST_ID,
                          A.OPERATE,
                          A.ORDER_ITEM_PROC_ATTR_ID
                     FROM ORDER_ITEM_PROC_ATTR A
                    WHERE A.ORDER_ITEM_ID = I_ORDER_ITEM_ID
                      AND A.OBJ_ATTR = 'composeProdInstRelsZ'
                      AND V_EXISTS_FLAG = 1) LOOP

      PROC_DEAL_PIR(I_ORDER_ITEM_ID           => I_ORDER_ITEM_ID,
                    I_ORDER_ITEM_PROC_ATTR_ID => REC_PI.ORDER_ITEM_PROC_ATTR_ID,
                    I_OBJ_INST_ID             => REC_PI.OBJ_INST_ID,
                    I_OPERATE                 => REC_PI.OPERATE,
                    O_GROUP_PROD_INST_ID      => V_GROUP_PROD_INST_ID);
      -------------------------------------------------------------------------------
      --------------------------群组产品与销售品的关联关系---------------------------
      -------------------------------------------------------------------------------
      IF V_GROUP_PROD_INST_ID = 0 THEN
        CONTINUE;
      END IF;
      V_GPI_EXISTS_FLAG := 0;
      BEGIN
        SELECT ORDER_ITEM_ID, 2
          INTO V_GPI_ORDER_ITEM_ID, V_GPI_EXISTS_FLAG
          FROM ORDER_ITEM_HIS
         WHERE ORDER_ITEM_CD = 1300
           AND ORDER_ITEM_OBJ_ID = V_GROUP_PROD_INST_ID
           AND CUST_ORDER_ID = V_CUST_ORDER_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          SELECT ORDER_ITEM_ID, 1
            INTO V_GPI_ORDER_ITEM_ID, V_GPI_EXISTS_FLAG
            FROM ORDER_ITEM
           WHERE ORDER_ITEM_CD = 1300
             AND ORDER_ITEM_OBJ_ID = V_GROUP_PROD_INST_ID
             AND CUST_ORDER_ID = V_CUST_ORDER_ID;
      END;
      FOR REC_GPI IN (SELECT A.OBJ_INST_ID,
                             A.OPERATE,
                             A.ORDER_ITEM_PROC_ATTR_ID
                        FROM ORDER_ITEM_PROC_ATTR_HIS A
                       WHERE A.ORDER_ITEM_ID = V_GPI_ORDER_ITEM_ID
                         AND A.OBJ_ATTR = 'offerProdInstRels'
                         AND V_GPI_EXISTS_FLAG = 2
                      UNION ALL
                      SELECT A.OBJ_INST_ID,
                             A.OPERATE,
                             A.ORDER_ITEM_PROC_ATTR_ID
                        FROM ORDER_ITEM_PROC_ATTR A
                       WHERE A.ORDER_ITEM_ID = V_GPI_ORDER_ITEM_ID
                         AND A.OBJ_ATTR = 'offerProdInstRels'
                         AND V_GPI_EXISTS_FLAG = 1) LOOP
        PROC_DEAL_OPIR(I_ORDER_ITEM_ID           => V_GPI_ORDER_ITEM_ID,
                       I_ORDER_ITEM_PROC_ATTR_ID => REC_GPI.ORDER_ITEM_PROC_ATTR_ID,
                       I_OBJ_INST_ID             => REC_GPI.OBJ_INST_ID,
                       I_OPERATE                 => REC_GPI.OPERATE);

      END LOOP;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_RET_MSG := SUBSTR(SQLERRM, 1, 500);
  END;

  PROCEDURE PROC_DEAL_OPIR(I_ORDER_ITEM_ID           IN ORDER_ITEM.ORDER_ITEM_ID%TYPE,
                           I_ORDER_ITEM_PROC_ATTR_ID IN ORDER_ITEM_PROC_ATTR.ORDER_ITEM_PROC_ATTR_ID%TYPE,
                           I_OBJ_INST_ID             IN ORDER_ITEM_PROC_ATTR.OBJ_INST_ID%TYPE,
                           I_OPERATE                 IN ORDER_ITEM_PROC_ATTR.OPERATE%TYPE) IS
    V_VPN_GROUP VPN_GROUP%ROWTYPE;
  BEGIN
    --10 新增  11  更新  12  删除
    IF I_OPERATE = '10' OR I_OPERATE = '11' THEN
      V_VPN_GROUP := FUNC_GET_VPN_GROUP_OPIR(I_ORDER_ITEM_ID,
                                             I_ORDER_ITEM_PROC_ATTR_ID,
                                             I_OBJ_INST_ID);
      IF V_VPN_GROUP.OFFER_PROD_INST_REL_ID != 0 THEN
        BEGIN
          SELECT VPN_GROUP_ID
            INTO V_VPN_GROUP.VPN_GROUP_ID
            FROM VPN_GROUP
           WHERE OFFER_PROD_INST_REL_ID =
                 V_VPN_GROUP.OFFER_PROD_INST_REL_ID;
          IF FUNC_NEED_UPDATE_VPN_GROUP(V_VPN_GROUP) THEN
            PROC_VPN_GROUP_1TO2(V_VPN_GROUP.VPN_GROUP_ID);
            PROC_UPDATE_VPN_GROUP(V_VPN_GROUP);
            --上载计费内存处理
            PROC_INTF_INS_BILLING_UPDATE5(V_VPN_GROUP, I_ORDER_ITEM_ID);
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT CRMV2.SEQ_VPN_GROUP_ID.NEXTVAL
              INTO V_VPN_GROUP.VPN_GROUP_ID
              FROM DUAL;
            PROC_INSERT_VPN_GROUP(V_VPN_GROUP);
            --上载计费内存处理
            PROC_INTF_INS_BILLING_UPDATE5(V_VPN_GROUP, I_ORDER_ITEM_ID);
        END;
      END IF;
    ELSE
      --删除
      BEGIN
        SELECT *
          INTO V_VPN_GROUP
          FROM VPN_GROUP
         WHERE OFFER_PROD_INST_REL_ID = I_OBJ_INST_ID;
        PROC_VPN_GROUP_1TO2(V_VPN_GROUP.VPN_GROUP_ID);
        DELETE FROM VPN_GROUP
         WHERE VPN_GROUP_ID = V_VPN_GROUP.VPN_GROUP_ID;
        --上载计费内存处理
        PROC_INTF_INS_BILLING_UPDATE5(V_VPN_GROUP, I_ORDER_ITEM_ID);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;

  END;

  PROCEDURE PROC_DEAL_PIR(I_ORDER_ITEM_ID           IN ORDER_ITEM.ORDER_ITEM_ID%TYPE,
                          I_ORDER_ITEM_PROC_ATTR_ID IN ORDER_ITEM_PROC_ATTR.ORDER_ITEM_PROC_ATTR_ID%TYPE,
                          I_OBJ_INST_ID             IN ORDER_ITEM_PROC_ATTR.OBJ_INST_ID%TYPE,
                          I_OPERATE                 IN ORDER_ITEM_PROC_ATTR.OPERATE%TYPE,
                          O_GROUP_PROD_INST_ID      OUT PROD_INST.PROD_INST_ID%TYPE) IS
    V_VPN_GROUP VPN_GROUP%ROWTYPE;
  BEGIN
    O_GROUP_PROD_INST_ID := 0;
    --10 新增  11  更新  12  删除
    IF I_OPERATE = '10' OR I_OPERATE = '11' THEN
      V_VPN_GROUP          := FUNC_GET_VPN_GROUP_PIR(I_ORDER_ITEM_ID,
                                                     I_ORDER_ITEM_PROC_ATTR_ID,
                                                     I_OBJ_INST_ID);
      O_GROUP_PROD_INST_ID := V_VPN_GROUP.GROUP_PROD_INST_ID;
      IF V_VPN_GROUP.PROD_INST_REL_ID != 0 THEN
        BEGIN
          SELECT VPN_GROUP_ID
            INTO V_VPN_GROUP.VPN_GROUP_ID
            FROM VPN_GROUP
           WHERE PROD_INST_REL_ID = V_VPN_GROUP.PROD_INST_REL_ID;
          IF FUNC_NEED_UPDATE_VPN_GROUP(V_VPN_GROUP) THEN
            PROC_VPN_GROUP_1TO2(V_VPN_GROUP.VPN_GROUP_ID);
            PROC_UPDATE_VPN_GROUP(V_VPN_GROUP);
            --上载计费内存处理
            PROC_INTF_INS_BILLING_UPDATE5(V_VPN_GROUP, I_ORDER_ITEM_ID);
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT CRMV2.SEQ_VPN_GROUP_ID.NEXTVAL
              INTO V_VPN_GROUP.VPN_GROUP_ID
              FROM DUAL;
            PROC_INSERT_VPN_GROUP(V_VPN_GROUP);
            --上载计费内存处理
            PROC_INTF_INS_BILLING_UPDATE5(V_VPN_GROUP, I_ORDER_ITEM_ID);
        END;
      END IF;
    ELSE
      --删除
      BEGIN
        SELECT *
          INTO V_VPN_GROUP
          FROM VPN_GROUP
         WHERE PROD_INST_REL_ID = I_OBJ_INST_ID;
        PROC_VPN_GROUP_1TO2(V_VPN_GROUP.VPN_GROUP_ID);
        DELETE FROM VPN_GROUP
         WHERE VPN_GROUP_ID = V_VPN_GROUP.VPN_GROUP_ID;
        --上载计费内存处理
        PROC_INTF_INS_BILLING_UPDATE5(V_VPN_GROUP, I_ORDER_ITEM_ID);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    END IF;
  END;

  PROCEDURE PROC_INIT_VPN_GROUP_VAR(I_VPN_GROUP IN OUT VPN_GROUP%ROWTYPE) IS
  BEGIN
    I_VPN_GROUP.OFFER_PROD_INST_REL_ID := 0;
    I_VPN_GROUP.PROD_OFFER_INST_ID     := 0;
    I_VPN_GROUP.PROD_OFFER_ID          := 0;
    I_VPN_GROUP.PROD_INST_REL_ID       := 0;
    I_VPN_GROUP.GROUP_PROD_INST_ID     := 0;
    I_VPN_GROUP.PROD_INST_ID           := 0;
    I_VPN_GROUP.AREA_CODE              := NULL;
    I_VPN_GROUP.ACC_NBR                := NULL;
    I_VPN_GROUP.ROLE_CD                := NULL;
    I_VPN_GROUP.STATUS_CD              := NULL;
    I_VPN_GROUP.STATUS_DATE            := NULL;
    I_VPN_GROUP.EFF_DATE               := NULL;
    I_VPN_GROUP.EXP_DATE               := NULL;
    I_VPN_GROUP.AREA_ID                := NULL;
    I_VPN_GROUP.REC_UPDATE_DATE        := SYSDATE;
  END;

  PROCEDURE PROC_INSERT_VPN_GROUP(I_VPN_GROUP IN VPN_GROUP%ROWTYPE) IS
  BEGIN
    INSERT INTO VPN_GROUP
      (VPN_GROUP_ID,
       OFFER_PROD_INST_REL_ID,
       PROD_OFFER_INST_ID,
       PROD_OFFER_ID,
       PROD_INST_REL_ID,
       GROUP_PROD_INST_ID,
       PROD_INST_ID,
       AREA_CODE,
       ACC_NBR,
       ROLE_CD,
       STATUS_CD,
       STATUS_DATE,
       EFF_DATE,
       EXP_DATE,
       AREA_ID,
       REC_UPDATE_DATE,
       ORDER_ITEM_ID,
       ORDER_ITEM_PROC_ATTR_ID)
    VALUES
      (I_VPN_GROUP.VPN_GROUP_ID,
       I_VPN_GROUP.OFFER_PROD_INST_REL_ID,
       I_VPN_GROUP.PROD_OFFER_INST_ID,
       I_VPN_GROUP.PROD_OFFER_ID,
       I_VPN_GROUP.PROD_INST_REL_ID,
       I_VPN_GROUP.GROUP_PROD_INST_ID,
       I_VPN_GROUP.PROD_INST_ID,
       I_VPN_GROUP.AREA_CODE,
       I_VPN_GROUP.ACC_NBR,
       I_VPN_GROUP.ROLE_CD,
       I_VPN_GROUP.STATUS_CD,
       I_VPN_GROUP.STATUS_DATE,
       I_VPN_GROUP.EFF_DATE,
       I_VPN_GROUP.EXP_DATE,
       I_VPN_GROUP.AREA_ID,
       I_VPN_GROUP.REC_UPDATE_DATE,
       I_VPN_GROUP.ORDER_ITEM_ID,
       I_VPN_GROUP.ORDER_ITEM_PROC_ATTR_ID);
  END;

  PROCEDURE PROC_UPDATE_VPN_GROUP(I_VPN_GROUP IN VPN_GROUP%ROWTYPE) IS
  BEGIN
    UPDATE VPN_GROUP
       SET OFFER_PROD_INST_REL_ID  = I_VPN_GROUP.OFFER_PROD_INST_REL_ID,
           PROD_OFFER_INST_ID      = I_VPN_GROUP.PROD_OFFER_INST_ID,
           PROD_OFFER_ID           = I_VPN_GROUP.PROD_OFFER_ID,
           PROD_INST_REL_ID        = I_VPN_GROUP.PROD_INST_REL_ID,
           GROUP_PROD_INST_ID      = I_VPN_GROUP.GROUP_PROD_INST_ID,
           PROD_INST_ID            = I_VPN_GROUP.PROD_INST_ID,
           AREA_CODE               = I_VPN_GROUP.AREA_CODE,
           ACC_NBR                 = I_VPN_GROUP.ACC_NBR,
           ROLE_CD                 = I_VPN_GROUP.ROLE_CD,
           STATUS_CD               = I_VPN_GROUP.STATUS_CD,
           STATUS_DATE             = I_VPN_GROUP.STATUS_DATE,
           EFF_DATE                = I_VPN_GROUP.EFF_DATE,
           EXP_DATE                = I_VPN_GROUP.EXP_DATE,
           AREA_ID                 = I_VPN_GROUP.AREA_ID,
           REC_UPDATE_DATE         = SYSDATE,
           ORDER_ITEM_ID           = I_VPN_GROUP.ORDER_ITEM_ID,
           ORDER_ITEM_PROC_ATTR_ID = I_VPN_GROUP.ORDER_ITEM_PROC_ATTR_ID
     WHERE VPN_GROUP_ID = I_VPN_GROUP.VPN_GROUP_ID;
  END;

  PROCEDURE PROC_VPN_GROUP_1TO2(I_VPN_GROUP_ID IN VPN_GROUP.VPN_GROUP_ID%TYPE) IS
  BEGIN
    INSERT INTO VPN_GROUP_HIS
      (VPN_GROUP_ID,
       OFFER_PROD_INST_REL_ID,
       PROD_OFFER_INST_ID,
       PROD_OFFER_ID,
       PROD_INST_REL_ID,
       GROUP_PROD_INST_ID,
       PROD_INST_ID,
       AREA_CODE,
       ACC_NBR,
       ROLE_CD,
       STATUS_CD,
       STATUS_DATE,
       EFF_DATE,
       EXP_DATE,
       AREA_ID,
       REC_UPDATE_DATE,
       HIS_ID,
       ORDER_ITEM_ID,
       ORDER_ITEM_PROC_ATTR_ID)
      SELECT VPN_GROUP_ID,
             OFFER_PROD_INST_REL_ID,
             PROD_OFFER_INST_ID,
             PROD_OFFER_ID,
             PROD_INST_REL_ID,
             GROUP_PROD_INST_ID,
             PROD_INST_ID,
             AREA_CODE,
             ACC_NBR,
             ROLE_CD,
             STATUS_CD,
             STATUS_DATE,
             EFF_DATE,
             EXP_DATE,
             AREA_ID,
             SYSDATE,
             CRMV2.SEQ_VPN_GROUP_HIS_ID.NEXTVAL,
             ORDER_ITEM_ID,
             ORDER_ITEM_PROC_ATTR_ID
        FROM VPN_GROUP
       WHERE VPN_GROUP_ID = I_VPN_GROUP_ID;
  END;

  PROCEDURE PROC_INTF_INS_BILLING_UPDATE5(I_VPN_GROUP     IN VPN_GROUP%ROWTYPE,
                                          I_ORDER_ITEM_ID IN ORDER_ITEM.ORDER_ITEM_ID%TYPE) IS
  BEGIN
    BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'VPN_GROUP',
                                                   I_COLUMN_NAME => 'VPN_GROUP_ID',
                                                   I_KEY_ID      => I_VPN_GROUP.VPN_GROUP_ID,
                                                   I_TOPIC       => C_CHANNEL_NBR,
                                                   I_TYPE        => '1004',
                                                   I_REASON      => C_CHANNEL_NBR ||
                                                                    ' ORDER_ITEM_ID:' ||
                                                                    I_ORDER_ITEM_ID,
                                                   I_OPERATOR    => C_JK_STAFF_ID,
                                                   I_AREA_NBR    => I_VPN_GROUP.AREA_CODE);
  END;

  FUNCTION FUNC_GET_AREA_CODE(I_AREA_ID IN NUMBER) RETURN VARCHAR2 IS
    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;
  BEGIN
    BEGIN
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
        FROM AREA_CODE A, COMMON_REGION B
       WHERE A.REGION_ID = B.COMMON_REGION_ID
         AND B.COMMON_REGION_ID = I_AREA_ID;
    EXCEPTION
      WHEN OTHERS THEN
        V_AREA_NBR := '';
    END;
    RETURN V_AREA_NBR;
  END;

  FUNCTION FUNC_GET_VPN_GROUP_OPIR(I_ORDER_ITEM_ID           IN ORDER_ITEM.ORDER_ITEM_ID%TYPE,
                                   I_ORDER_ITEM_PROC_ATTR_ID IN ORDER_ITEM_PROC_ATTR.ORDER_ITEM_PROC_ATTR_ID%TYPE,
                                   I_OBJ_INST_ID             IN ORDER_ITEM_PROC_ATTR.OBJ_INST_ID%TYPE)
    RETURN VPN_GROUP%ROWTYPE IS
    V_ERRMSG    VARCHAR2(500);
    O_VPN_GROUP VPN_GROUP%ROWTYPE;
  BEGIN
    PROC_INIT_VPN_GROUP_VAR(O_VPN_GROUP);
    O_VPN_GROUP.ORDER_ITEM_PROC_ATTR_ID := I_ORDER_ITEM_PROC_ATTR_ID;
    O_VPN_GROUP.ORDER_ITEM_ID           := I_ORDER_ITEM_ID;
    BEGIN
      SELECT OPIR.OFFER_PROD_INST_REL_ID,
             OPIR.PROD_OFFER_INST_ID,
             OPIR.PROD_INST_ID,
             OPIR.ROLE_CD,
             OPIR.STATUS_CD,
             OPIR.STATUS_DATE,
             OPIR.EFF_DATE,
             OPIR.EXP_DATE,
             OPIR.AREA_ID,
             POI.PROD_OFFER_ID,
             PI.ACC_NBR
        INTO O_VPN_GROUP.OFFER_PROD_INST_REL_ID,
             O_VPN_GROUP.PROD_OFFER_INST_ID,
             O_VPN_GROUP.PROD_INST_ID,
             O_VPN_GROUP.ROLE_CD,
             O_VPN_GROUP.STATUS_CD,
             O_VPN_GROUP.STATUS_DATE,
             O_VPN_GROUP.EFF_DATE,
             O_VPN_GROUP.EXP_DATE,
             O_VPN_GROUP.AREA_ID,
             O_VPN_GROUP.PROD_OFFER_ID,
             O_VPN_GROUP.ACC_NBR
        FROM OFFER_PROD_INST_REL OPIR,
             CRMV2.PROD_INST     PI,
             PROD_OFFER_INST     POI,
             INTF_DEFINE_CONFIG  IDC_PI,
             INTF_DEFINE_CONFIG  IDC_POI,
             PRODUCT             P
       WHERE OPIR.OFFER_PROD_INST_REL_ID = I_OBJ_INST_ID
         AND OPIR.PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
         AND OPIR.PROD_INST_ID = PI.PROD_INST_ID
         AND PI.PRODUCT_ID = IDC_PI.PRODUCT_ID
         AND IDC_PI.CHANNEL_NBR = C_CHANNEL_NBR
         AND POI.PROD_OFFER_ID = IDC_POI.PROD_OFFER_ID
         AND IDC_POI.CHANNEL_NBR = C_CHANNEL_NBR
         AND IDC_PI.PRODUCT_ID = P.PRODUCT_ID
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT OPIR.OFFER_PROD_INST_REL_ID,
                 OPIR.PROD_OFFER_INST_ID,
                 OPIR.PROD_INST_ID,
                 OPIR.ROLE_CD,
                 OPIR.STATUS_CD,
                 OPIR.STATUS_DATE,
                 OPIR.EFF_DATE,
                 OPIR.EXP_DATE,
                 OPIR.AREA_ID,
                 POI.PROD_OFFER_ID,
                 PI.ACC_NBR
            INTO O_VPN_GROUP.OFFER_PROD_INST_REL_ID,
                 O_VPN_GROUP.PROD_OFFER_INST_ID,
                 O_VPN_GROUP.PROD_INST_ID,
                 O_VPN_GROUP.ROLE_CD,
                 O_VPN_GROUP.STATUS_CD,
                 O_VPN_GROUP.STATUS_DATE,
                 O_VPN_GROUP.EFF_DATE,
                 O_VPN_GROUP.EXP_DATE,
                 O_VPN_GROUP.AREA_ID,
                 O_VPN_GROUP.PROD_OFFER_ID,
                 O_VPN_GROUP.ACC_NBR
            FROM OFFER_PROD_INST_REL_HIS OPIR,
                 CRMV2.PROD_INST         PI,
                 PROD_OFFER_INST         POI,
                 INTF_DEFINE_CONFIG      IDC_PI,
                 INTF_DEFINE_CONFIG      IDC_POI,
                 PRODUCT                 P
           WHERE OPIR.OFFER_PROD_INST_REL_ID = I_OBJ_INST_ID
             AND OPIR.PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
             AND OPIR.PROD_INST_ID = PI.PROD_INST_ID
             AND PI.PRODUCT_ID = IDC_PI.PRODUCT_ID
             AND IDC_PI.CHANNEL_NBR = C_CHANNEL_NBR
             AND POI.PROD_OFFER_ID = IDC_POI.PROD_OFFER_ID
             AND IDC_POI.CHANNEL_NBR = C_CHANNEL_NBR
             AND IDC_PI.PRODUCT_ID = P.PRODUCT_ID
             AND OPIR.HIS_ID =
                 (SELECT HIS_ID
                    FROM OFFER_PROD_INST_REL_HIS H
                   WHERE H.OFFER_PROD_INST_REL_ID = I_OBJ_INST_ID
                     AND ROWNUM = 1)
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
          WHEN OTHERS THEN
            V_ERRMSG := SUBSTR(SQLERRM, 1, 500);
            RAISE_APPLICATION_ERROR(-20002,
                                    'OFFER_PROD_INST_REL_HIS根据offer_prod_inst_rel_id:' ||
                                    I_OBJ_INST_ID || '查数据出错。' || V_ERRMSG);
        END;
      WHEN OTHERS THEN
        V_ERRMSG := SUBSTR(SQLERRM, 1, 500);
        RAISE_APPLICATION_ERROR(-20003,
                                'OFFER_PROD_INST_REL根据offer_prod_inst_rel_id:' ||
                                I_OBJ_INST_ID || '查数据出错。' || V_ERRMSG);
    END;
    O_VPN_GROUP.AREA_CODE := FUNC_GET_AREA_CODE(O_VPN_GROUP.AREA_ID);
    RETURN O_VPN_GROUP;
  END;

  FUNCTION FUNC_GET_VPN_GROUP_PIR(I_ORDER_ITEM_ID           IN ORDER_ITEM.ORDER_ITEM_ID%TYPE,
                                  I_ORDER_ITEM_PROC_ATTR_ID IN ORDER_ITEM_PROC_ATTR.ORDER_ITEM_PROC_ATTR_ID%TYPE,
                                  I_OBJ_INST_ID             IN ORDER_ITEM_PROC_ATTR.OBJ_INST_ID%TYPE)
    RETURN VPN_GROUP%ROWTYPE IS
    V_ERRMSG    VARCHAR2(500);
    O_VPN_GROUP VPN_GROUP%ROWTYPE;
  BEGIN
    PROC_INIT_VPN_GROUP_VAR(O_VPN_GROUP);
    O_VPN_GROUP.ORDER_ITEM_PROC_ATTR_ID := I_ORDER_ITEM_PROC_ATTR_ID;
    O_VPN_GROUP.ORDER_ITEM_ID           := I_ORDER_ITEM_ID;
    BEGIN
      SELECT PIR.PROD_INST_REL_ID,
             PIR.PROD_INST_Z_ID,
             PIR.PROD_INST_A_ID,
             PIR.ROLE_CD,
             PIR.STATUS_CD,
             PIR.STATUS_DATE,
             PIR.EFF_DATE,
             PIR.EXP_DATE,
             PIR.AREA_ID,
             PIA.ACC_NBR
        INTO O_VPN_GROUP.PROD_INST_REL_ID,
             O_VPN_GROUP.PROD_INST_ID,
             O_VPN_GROUP.GROUP_PROD_INST_ID,
             O_VPN_GROUP.ROLE_CD,
             O_VPN_GROUP.STATUS_CD,
             O_VPN_GROUP.STATUS_DATE,
             O_VPN_GROUP.EFF_DATE,
             O_VPN_GROUP.EXP_DATE,
             O_VPN_GROUP.AREA_ID,
             O_VPN_GROUP.ACC_NBR
        FROM PROD_INST_REL      PIR,
             CRMV2.PROD_INST    PIA,
             CRMV2.PROD_INST    PIZ,
             INTF_DEFINE_CONFIG IDC_PIA,
             INTF_DEFINE_CONFIG IDC_PIZ
       WHERE PIR.PROD_INST_REL_ID = I_OBJ_INST_ID
         AND PIR.PROD_INST_A_ID = PIA.PROD_INST_ID
         AND PIR.PROD_INST_Z_ID = PIZ.PROD_INST_ID
         AND PIA.PRODUCT_ID = IDC_PIA.PRODUCT_ID
         AND IDC_PIA.CHANNEL_NBR = C_CHANNEL_NBR
         AND PIZ.PRODUCT_ID = IDC_PIZ.PRODUCT_ID
         AND IDC_PIZ.CHANNEL_NBR = C_CHANNEL_NBR
         AND ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT PIR.PROD_INST_REL_ID,
                 PIR.PROD_INST_Z_ID,
                 PIR.PROD_INST_A_ID,
                 PIR.ROLE_CD,
                 PIR.STATUS_CD,
                 PIR.STATUS_DATE,
                 PIR.EFF_DATE,
                 PIR.EXP_DATE,
                 PIR.AREA_ID,
                 PIA.ACC_NBR
            INTO O_VPN_GROUP.PROD_INST_REL_ID,
                 O_VPN_GROUP.GROUP_PROD_INST_ID,
                 O_VPN_GROUP.PROD_INST_ID,
                 O_VPN_GROUP.ROLE_CD,
                 O_VPN_GROUP.STATUS_CD,
                 O_VPN_GROUP.STATUS_DATE,
                 O_VPN_GROUP.EFF_DATE,
                 O_VPN_GROUP.EXP_DATE,
                 O_VPN_GROUP.AREA_ID,
                 O_VPN_GROUP.ACC_NBR
            FROM PROD_INST_REL_HIS  PIR,
                 CRMV2.PROD_INST    PIA,
                 CRMV2.PROD_INST    PIZ,
                 INTF_DEFINE_CONFIG IDC_PIA,
                 INTF_DEFINE_CONFIG IDC_PIZ
           WHERE PIR.PROD_INST_REL_ID = I_OBJ_INST_ID
             AND PIR.PROD_INST_A_ID = PIA.PROD_INST_ID
             AND PIR.PROD_INST_Z_ID = PIZ.PROD_INST_ID
             AND PIA.PRODUCT_ID = IDC_PIA.PRODUCT_ID
             AND IDC_PIA.CHANNEL_NBR = C_CHANNEL_NBR
             AND PIZ.PRODUCT_ID = IDC_PIZ.PRODUCT_ID
             AND IDC_PIZ.CHANNEL_NBR = C_CHANNEL_NBR
             AND PIR.HIS_ID = (SELECT HIS_ID
                                 FROM PROD_INST_REL_HIS H
                                WHERE H.PROD_INST_REL_ID = I_OBJ_INST_ID
                                  AND ROWNUM = 1)
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
          WHEN OTHERS THEN
            V_ERRMSG := SUBSTR(SQLERRM, 1, 500);
            RAISE_APPLICATION_ERROR(-20012,
                                    'PROD_INST_REL_HIS根据prod_inst_rel_id:' ||
                                    I_OBJ_INST_ID || '查数据出错。' || V_ERRMSG);
        END;
      WHEN OTHERS THEN
        V_ERRMSG := SUBSTR(SQLERRM, 1, 500);
        RAISE_APPLICATION_ERROR(-20013,
                                'PROD_INST_REL根据prod_inst_rel_id:' ||
                                I_OBJ_INST_ID || '查数据出错。' || V_ERRMSG);
    END;
    O_VPN_GROUP.AREA_CODE := FUNC_GET_AREA_CODE(O_VPN_GROUP.AREA_ID);
    RETURN O_VPN_GROUP;
  END;

  FUNCTION FUNC_NEED_UPDATE_VPN_GROUP(I_VPN_GROUP IN VPN_GROUP%ROWTYPE)
    RETURN BOOLEAN IS
    O_RESULT        BOOLEAN;
    V_CUR_VPN_GROUP VPN_GROUP%ROWTYPE;
    C_INT           NUMBER(12) := 0;
    C_STR           VARCHAR(12) := '0';
    C_DATE          DATE := TO_DATE('19000101 00:00:00',
                                    'YYYYMMDD HH24:MI:SS');
  BEGIN
    O_RESULT := TRUE;
    SELECT *
      INTO V_CUR_VPN_GROUP
      FROM VPN_GROUP
     WHERE VPN_GROUP_ID = I_VPN_GROUP.VPN_GROUP_ID;

    IF NVL(I_VPN_GROUP.OFFER_PROD_INST_REL_ID, C_INT) !=
       NVL(V_CUR_VPN_GROUP.OFFER_PROD_INST_REL_ID, C_INT) OR
       NVL(I_VPN_GROUP.PROD_OFFER_INST_ID, C_INT) !=
       NVL(V_CUR_VPN_GROUP.PROD_OFFER_INST_ID, C_INT) OR
       NVL(I_VPN_GROUP.PROD_OFFER_ID, C_INT) !=
       NVL(V_CUR_VPN_GROUP.PROD_OFFER_ID, C_INT) OR
       NVL(I_VPN_GROUP.PROD_INST_REL_ID, C_INT) !=
       NVL(V_CUR_VPN_GROUP.PROD_INST_REL_ID, C_INT) OR
       NVL(I_VPN_GROUP.GROUP_PROD_INST_ID, C_INT) !=
       NVL(V_CUR_VPN_GROUP.GROUP_PROD_INST_ID, C_INT) OR
       NVL(I_VPN_GROUP.PROD_INST_ID, C_INT) !=
       NVL(V_CUR_VPN_GROUP.PROD_INST_ID, C_INT) OR
       NVL(I_VPN_GROUP.AREA_CODE, C_STR) !=
       NVL(V_CUR_VPN_GROUP.AREA_CODE, C_STR) OR
       NVL(I_VPN_GROUP.ACC_NBR, C_STR) !=
       NVL(V_CUR_VPN_GROUP.ACC_NBR, C_STR) OR
       NVL(I_VPN_GROUP.ROLE_CD, C_INT) !=
       NVL(V_CUR_VPN_GROUP.ROLE_CD, C_INT) OR
       NVL(I_VPN_GROUP.STATUS_CD, C_INT) !=
       NVL(V_CUR_VPN_GROUP.STATUS_CD, C_INT) OR
       NVL(I_VPN_GROUP.STATUS_DATE, C_DATE) !=
       NVL(V_CUR_VPN_GROUP.STATUS_DATE, C_DATE) OR
       NVL(I_VPN_GROUP.EFF_DATE, C_DATE) !=
       NVL(V_CUR_VPN_GROUP.EFF_DATE, C_DATE) OR
       NVL(I_VPN_GROUP.EXP_DATE, C_DATE) !=
       NVL(V_CUR_VPN_GROUP.EXP_DATE, C_DATE) OR
       NVL(I_VPN_GROUP.AREA_ID, C_INT) !=
       NVL(V_CUR_VPN_GROUP.AREA_ID, C_INT) THEN
      O_RESULT := TRUE;
    ELSE
      O_RESULT := FALSE;
    END IF;
    RETURN O_RESULT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
      RETURN O_RESULT;
  END;

END PKG_SYNC_VPN_DATA;
/
