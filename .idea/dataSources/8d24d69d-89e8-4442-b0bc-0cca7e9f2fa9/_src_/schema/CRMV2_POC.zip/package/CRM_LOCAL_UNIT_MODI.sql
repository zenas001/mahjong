CREATE PACKAGE           CRM_LOCAL_UNIT_MODI IS

  -- Author  : jiangy
  -- Created : 2008-03-17 下午 05:02:16
  -- Purpose : 本地网维护系统数据修改
  PROCEDURE CRM_LOCAL_UNIT_MODI_MAIN(IN_LOG_ID    IN NUMBER,
                                     IN_CHECK_MAN IN VARCHAR2,
                                     IN_STATE     IN VARCHAR2,
                                     ERR_MSG      OUT VARCHAR2);
  PROCEDURE GET_COLUMN_VALUE(V_COLUMN    IN VARCHAR2,
                             V_TABLE     IN VARCHAR2,
                             OUT_V_STR   OUT VARCHAR2,
                             OUT_ERR_MSG OUT VARCHAR2);
  PROCEDURE MODI_CHECK_INTO_TEMP_LOG(IN_TABLE         IN VARCHAR2,
                                     IN_MODI_ENTITY   IN VARCHAR2,
                                     IN_COLUMN_KEY_ID IN VARCHAR2,
                                     IN_COLUMN        IN VARCHAR2,
                                     IN_REMARK        IN VARCHAR2,
                                     IN_MODI_MAN      IN VARCHAR2,
                                     IN_AREA_CODE     IN NUMBER,
                                     ERR_MSG          OUT VARCHAR2);
  FUNCTION GET_CHAR_CNT(IN_CHAR VARCHAR2, IN_CONDITION VARCHAR2)

   RETURN NUMBER;
  procedure exvalue(in_sql          varchar2,
                    in_statement_id varchar2,
                    exe_cost        out varchar);
END CRM_LOCAL_UNIT_MODI;
/
