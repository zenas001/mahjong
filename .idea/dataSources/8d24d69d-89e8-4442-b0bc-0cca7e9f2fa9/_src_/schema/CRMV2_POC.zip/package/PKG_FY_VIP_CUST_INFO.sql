CREATE PACKAGE           pkg_fy_vip_cust_info IS

  -- Author  : suzhs
  -- Created : 2013-4-20
  -- Purpose : 同步FY_VIP信息

  /*判断开关状态*/
  FUNCTION func_check_switch_state(table_name       IN VARCHAR2,
                                   o_begin_cycle_id OUT VARCHAR2)
    RETURN BOOLEAN; ----入参：表名,周期



  /*插入fy_vip信息表*/
  PROCEDURE proc_insert_fy_vip_info_all;

  /*主方法*/
  PROCEDURE proc_sync_fy_vip_info;

END pkg_fy_vip_cust_info;
/
