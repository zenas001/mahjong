CREATE PACKAGE           PKG_COMMON IS
  /*查询客户下在用的邮箱地址。*/
  PROCEDURE PROC_QUERY_MAIL_ADDR(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_RESULT      OUT VARCHAR2 --结果信息（成功时返回邮箱地址，失败时为空）
                                 );

  /*绑定或取消客户下在用的邮箱地址。*/
  PROCEDURE PROC_HANDLE_MAIL_ADDR(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                  I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                  I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                  I_MAIL_ADDR   IN VARCHAR2, --邮箱地址，如13305027420@189.cn
                                  I_USE_TYPE    IN VARCHAR2, --邮箱用途，如：账单推送、广告推送
                                  I_SOURCE      IN VARCHAR2, --来源，如网厅、掌厅、短厅等
                                  I_ACTION      IN VARCHAR2, --动作，A：绑定，R：取消
                                  O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                  O_ERR_MSG     OUT VARCHAR2 --错误信息
                                  );

  /************************************************************************
    Function    : 无线宽带关联主副卡查询
    Description ：以传入的接入号码为主卡（或副卡）查询关联的副卡（或主卡）
    Author　    ：wangjianjun
    Date        : 2012-05-04
    Parameter   :
                  I_ACC_NBR      -- 业务号码
                  I_AREA_CODE    -- 区号
                  O_ACCTYPE      -- 输入号码类型 1：主卡 2：副卡
                  O_RELA_ACC_NBR -- 输出关联的业务号码
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_DOUBLE_NUMBER(I_ACC_NBR      IN VARCHAR2,
                                     I_AREA_CODE    IN VARCHAR2,
                                     O_ACCTYPE      OUT VARCHAR2,
                                     O_RELA_ACC_NBR OUT VARCHAR2,
                                     O_ERR_CODE     OUT NUMBER,
                                     O_ERR_MSG      OUT VARCHAR2);

  /*-------------------------------------------------
  查询产品信息(宽带, 移动语音)

  Author  : g.caijx
  Created : 2012-05-28
  -------------------------------------------------*/
  PROCEDURE PROC_QUERY_PROD_INFO(I_TYPE           IN NUMBER, --1: CDMA; 2: 宽带
                                 I_SERVICE_NUMBER IN VARCHAR2, --CDMD: 18999034567; 宽带帐号: 480112717@fzlan
                                 I_AREA_CODE      IN VARCHAR2, --区号
                                 O_ACC_NBR        OUT VARCHAR2, --业务号码
                                 O_EXT_PROD_ID    OUT VARCHAR2, --产品规格id
                                 O_IS_STOP        OUT NUMBER, --CDMA或宽带是否停机. 0:是; 1: 不是
                                 O_IS_GMGN        OUT NUMBER, --CDMA或宽带是否公免公纳. 0:是; 1: 不是
                                 O_IS_E_HOME      OUT NUMBER, --CDMA或宽带是否是加入e8, e9. 0:是; 1: 不是
                                 O_FLAG           OUT NUMBER, --是否已经受理过在线电脑医生程控. 0:是; 1: 不是
                                 O_TC_FLAG        OUT NUMBER, --是否已经受理过电脑医生功能费(包年-套餐). 0:未受理; 1: 已受理
                                 O_E_HOME_NAME    OUT VARCHAR2, --e家套餐名
                                 O_SWLH_NAME      OUT VARCHAR2, --商务领航套餐名
                                 O_SERVICE_CODE   OUT VARCHAR2, --e家中的宽带帐号
                                 O_SERVICE_NUMBER OUT VARCHAR2, --e家中的手机号码
                                 O_ERR_CODE       OUT NUMBER, -- 处理结果（0--成功 1--失败）
                                 O_ERR_MSG        OUT VARCHAR2 -- 错误信息
                                 );

  /************************************************************************
    Function    : 亲情短号户主及家庭成员号码查询
    Description ：以传入的接入号码查询亲情亲情短号户主及家庭成员号码
    Author　    ：renli
    Date        : 2012-06-13
  ************************************************************************/
  PROCEDURE PROC_QUERY_QQDH_MEMBER(I_AREA_CODE        IN VARCHAR2, --区号，如：福州0591
                                   I_ACC_NBR          IN VARCHAR2, --接入号码，如：15359121897
                                   I_EXT_PROD_ID      IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                   O_ERR_CODE         OUT NUMBER, --错误编码（0--成功 1--失败）
                                   O_ERR_MSG          OUT VARCHAR2, --错误信息
                                   O_HOST_NBR         OUT VARCHAR2, --户主号码
                                   O_HOST_SHORT_NBR   OUT VARCHAR2, --户主短号
                                   O_HOST_STATUS_CD   OUT VARCHAR2, --户主号码状态
                                   O_MEMBER_NBR       OUT VARCHAR2, --家庭成员号码，多个时用逗号隔开
                                   O_MEMBER_SHORT_NBR OUT VARCHAR2, --家庭成员短号，多个时用逗号隔开，顺序与号码对应
                                   O_MEMBER_STATUS_CD OUT VARCHAR2, --家庭成员号码状态，多个时用逗号隔开，顺序与号码对应
                                   O_JTDH_NBR         OUT VARCHAR2 -- 家庭短号本身的号码
                                   );

  /************************************************************************
    Function    : 查询号码是否可受理一键通
    Description ：以传入的接入号码查询该号码是否可受理一键通
    Author　    ：renli
    Date        : 2012-06-13
  ************************************************************************/
  PROCEDURE PROC_QUERY_IS_ENABLE_YJT(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                     I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                     I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                     O_ERR_CODE    OUT NUMBER, --错误编码（0--成功(允许受理） 1--失败）
                                     O_ERR_MSG     OUT VARCHAR2, --错误信息
                                     O_RESULT      OUT VARCHAR2 --结果信息
                                     );

  /************************************************************************
    Function    : 查询业务号码的包类型及所在E家的基础包号码
    Description ：查询业务号码的包类型及所在E家的基础包号码
    Author　    ：renli
    Date        : 2012-08-22
  ************************************************************************/
  PROCEDURE PROC_QUERY_BASE_SHARE_PACK(I_AREA_CODE     IN VARCHAR2, --区号
                                       I_ACC_NBR       IN VARCHAR2, --接入号码
                                       I_EXT_PROD_ID   IN VARCHAR2, --产品外部编码
                                       O_ERR_CODE      OUT NUMBER, --错误编码（0--成功 1--失败）
                                       O_ERR_MSG       OUT VARCHAR2, --错误信息
                                       O_PACK_TYPE     OUT VARCHAR2, --1:基础包  2：共享包 0：两者均不是
                                       O_BASE_PACK_NBR OUT VARCHAR2, --E家的基础包的天翼号码和固话号码
                                       O_ALL_PACK_NBR  OUT VARCHAR2, --E家所有包的天翼号码和固话
                                       O_ALL_PACK_ROLE OUT VARCHAR2 --E家所有包与亲情短号关系中的角色(1表示户主、2表示家庭成员、0表示未加入亲情短号)
                                       );

  PROCEDURE PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  INTF_INS_BILLING_UPDATE.TABLE_NAME%TYPE,
                                         I_COLUMN_NAME INTF_INS_BILLING_UPDATE.COLUMN_NAME%TYPE,
                                         I_KEY_ID      INTF_INS_BILLING_UPDATE.KEY_ID%TYPE,
                                         I_TOPIC       INTF_INS_BILLING_UPDATE.TOPIC%TYPE,
                                         I_TYPE        INTF_INS_BILLING_UPDATE.TYPE%TYPE,
                                         I_REASON      INTF_INS_BILLING_UPDATE.REASON%TYPE,
                                         I_OPERATOR    INTF_INS_BILLING_UPDATE.OPERATOR%TYPE,
                                         I_AREA_NBR    INTF_INS_BILLING_UPDATE.AREA_NBR%TYPE)
  /*-------------------------------------------------
      功能: 插INTF_INS_BILLING_UPDATE表
    -------------------------------------------------*/
  ;

   PROCEDURE PROC_INTF_INS_BILLING_UPDATE_2(I_TABLE_NAME  INTF_INS_BILLING_UPDATE.TABLE_NAME%TYPE,--表名
                                         I_COLUMN_NAME INTF_INS_BILLING_UPDATE.COLUMN_NAME%TYPE,--主键字段
                                         I_KEY_ID      INTF_INS_BILLING_UPDATE.KEY_ID%TYPE,--主键值
                                         I_TOPIC       INTF_INS_BILLING_UPDATE.TOPIC%TYPE,--操作主题
                                         I_TYPE        INTF_INS_BILLING_UPDATE.TYPE%TYPE,--
                                         I_REASON      INTF_INS_BILLING_UPDATE.REASON%TYPE,--备注
                                         I_OPERATOR    INTF_INS_BILLING_UPDATE.OPERATOR%TYPE,--操作类型，可空，删除必传DELETE
                                         I_AREA_NBR    INTF_INS_BILLING_UPDATE.AREA_NBR%TYPE)--区域
  /*-------------------------------------------------
      功能: 插批量双写表表
    -------------------------------------------------*/
  ;

  FUNCTION FNC_IS_ON_ROAD(I_PROD_INST_ID IN PROD_INST.PROD_INST_ID%TYPE --产品实例id
                          ) RETURN BOOLEAN
  /*-------------------------------------------------
      功能: 判断产品实例是否在途
    -------------------------------------------------*/
  ;

  /************************************************************************
  Function  ：判断销售品是否为单接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    : 结果（TRUE 是 FALSE 否）
  ************************************************************************/
  FUNCTION FUNC_IS_SIMPLE_ACCESS_OFFER(I_PROD_OFFER_ID NUMBER) RETURN BOOLEAN;

  /************************************************************************
  Function  ：判断销售品是否为多接入类销售品
  Author　  ：Wangjianjun
  Date      : 2012-08-14
  Parameter : i_prod_offer_id        --销售品规格ID
  return    : 结果（TRUE 是 FALSE 否）
  ************************************************************************/
  FUNCTION FUNC_IS_MULTI_ACCESS_OFFER(I_PROD_OFFER_ID NUMBER) RETURN BOOLEAN;

  /************************************************************************
  Function  ：获取产品属性信息
  Author　  ：Ouzhifang
  Date      : 2012-09-24
  Parameter : I_PROD_INST_ID        --产品实例标识
  Parameter : I_EXT_ATTR_NBR        --属性规格编码
  return    : O_ATTR_VALUE          --属性值（T1返回属性值，T3返回属性值名称）
  ************************************************************************/
  PROCEDURE PROC_QUERY_PROD_ATTR(I_PROD_INST_ID IN NUMBER,
                                 I_EXT_ATTR_NBR IN VARCHAR2,
                                 O_ATTR_VALUE   OUT VARCHAR2,
                                 O_ERR_CODE     OUT NUMBER,
                                 O_ERR_MSG      OUT VARCHAR2);

  /************************************************************************
  Function  ：获取销售品属性信息
  Author　  ：Ouzhifang
  Date      : 2012-09-24
  Parameter : I_PROD_OFFER_INST_ID  --销售品实例标识
  Parameter : I_EXT_ATTR_NBR        --属性规格编码
  return    : O_ATTR_VALUE          --属性值（T1返回属性值，T3返回属性值ID）
  ************************************************************************/
  PROCEDURE PROC_QUERY_OFFER_ATTR(I_PROD_OFFER_INST_ID IN NUMBER,
                                  I_EXT_ATTR_NBR       IN VARCHAR2,
                                  O_ATTR_VALUE         OUT VARCHAR2,
                                  O_ERR_CODE           OUT NUMBER,
                                  O_ERR_MSG            OUT VARCHAR2);

  /*************************************************************************
  Function   : 根据区号、接入号码及外部产品规格编码查询非失效的产品信息（对于多条，返回主号）
  Author     : chaijinchun
  Date       : 2012-11-22
  Parameter  : I_AREA_CODE     IN VARCHAR2, --区号，比如厦门0592
               I_ACC_NBR       IN VARCHAR2, --业务号码
               I_EXT_PROD_ID   IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话, 594000248-小灵通
  Return     : O_PROD_INST_ID  OUT NUMBER, --产品实例ID
  ***************************************************************************/
  PROCEDURE PROC_MAIN_PROD_INST(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                            I_ACC_NBR     IN VARCHAR2, --业务号码
                            I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话, 594000248-小灵通
                            O_PROD_INST_ID OUT NUMBER, --产品实例ID
                            O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                            O_ERR_MSG     OUT VARCHAR2 --错误信息
                            );
  /*************************************************************************
  Function   : 通过PROD_OFFER_INST_ID查找PROD_INST_ID
  Author     : qiurl
  Date       : 2013-6-24
  Parameter  : I_PROD_OFFER_INST_ID     IN   NUMBER,
  Return     : PROD_INST_ID
  ***************************************************************************/
  FUNCTION FUNC_GET_PROD_INST_ID(I_PROD_OFFER_INST_ID NUMBER) RETURN NUMBER;
  FUNCTION FUNC_IS_OCS(I_PROD_INST_ID NUMBER) RETURN BOOLEAN;

  FUNCTION FUNC_GET_AREA_NBR(I_TABLE_NAME IN VARCHAR2,
                             I_KEY_ID     IN NUMBER) RETURN VARCHAR2;

END PKG_COMMON;
/
