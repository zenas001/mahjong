CREATE package           PKG_JT_CHANNEL_UPLOAD is

  -- Author  : linyx
  -- Created : 2013-10-14 11:01:28
  -- Purpose :

  ------上传集团
  procedure prc_jt_channel_main(in_table_name  in varchar2,
                                in_key_id      in varchar2,
                                in_action      in varchar2,
                                in_modi_man    in varchar2,
                                in_modi_reason in varchar2);
  ------上传拼包
  procedure prc_jt_channel_XML(in_table_name in varchar2,
                               in_key_id     in varchar2,
                               in_action     in varchar2,
                               o_xml         out clob,
                               err_msg       out varchar2);

  ------删除渠道主表同时删除关联表
  procedure prc_del_channel_and_rela(in_table_name IN VARCHAR2, --表名
                                     in_key_id     IN VARCHAR2, --主键id
                                     modi_staff    IN VARCHAR2, --修改人
                                     modi_reason   IN VARCHAR2, --修改备注
                                     o_msg         OUT VARCHAR2); --输出结果

  ----集团比省多拼包
/*  procedure prc_jt_channel_xml_del(in_table_name in varchar2,
                                   in_key_id1    in varchar2,
                                   in_key_id2    in varchar2,
                                   in_action     in varchar2,
                                   o_xml         out clob,
                                   err_msg       out varchar2);*/
  ------集团比省多上传集团
/*  procedure prc_jt_channel_main_del(in_table_name  in varchar2,
                                    in_key_id1     in varchar2,
                                    in_key_id2     in varchar2,
                                    in_modi_man    in varchar2,
                                    in_modi_reason in varchar2);*/
end PKG_JT_CHANNEL_UPLOAD;
/
