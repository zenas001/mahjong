CREATE package           PKG_CRM2_FOR_JF_COMPARE_PASSWD is
    function asciitohex(str_input in varchar2)  return varchar2;
  PROCEDURE PROC_user_encrypt(pass in varchar, encryption out varchar);
  PROCEDURE PROC_comparePasswd(str_areacode  IN VARCHAR2,
                          str_serv_acct IN VARCHAR2,
                          str_type      IN VARCHAR2,
                          l_flag        IN NUMBER,
                          str_passwd    IN VARCHAR2,
                          l_result      OUT NUMBER,
                          str_info      OUT VARCHAR2);
  PROCEDURE PROC_JudgmentWeakPasswords(in_pass in varchar,in_area_code in varchar2, out_AuthenticateRusult out varchar);
end PKG_CRM2_FOR_JF_COMPARE_PASSWD;
/
