CREATE package           PKG_procYDLK is
  /**
  * 包功能说明：
  *    海南预登录卡到期前短信提醒功能
  * author：zhenggw
  * Created：2014-7-4
  *
  **/

  /**
  * 功能说明：
  *    在激活有效期前30天系统以发展员工为单位统计，对发展员工联系人手机发送失效提醒短信。
  *    轮循执行时间：每天凌晨1点时跑一次
  * author：zhenggw
  * Created：2014-7-4
  **/
  PROCEDURE sendMsgForYDLK;

    /**
  * 功能说明：
  *    在激活有效期前30天系统以发展员工为单位统计，对发展员工联系人手机发送失效提醒短信。
  *    轮循执行时间：每天凌晨1点时跑一次
  * author：zhenggw
  * Created：2014-7-4
  **/
  PROCEDURE sendMsgForYDLK1;

  /**
  * 功能说明：
  *    保存日志
  * author：zhenggw
  * Created：2014-7-4
  * @params l_logId   日志id
  *                   更新日志时传入日志id
  *
  * @params str_message   日志内容
  **/
  function saveLogInfo(i_logId       in number,
                       v_method_name in varchar,
                       v_message     in varchar) return number;

end PKG_PROC_AUTO_H;

create or replace package body PKG_procYDLK is


  /**
  * 功能说明：
  *    在激活有效期前30天系统以发展员工为单位统计，对发展员工联系人手机发送失效提醒短信。
  *    轮循执行时间：每天凌晨1点时跑一次
  * author：zhenggw
  * Created：2014-7-4
  **/
  PROCEDURE sendMsgForYDLK is
      v_message varchar(4000);
    str_msg   varchar(2000);
    v_seq     number;
  begin
    v_seq := 0;
    v_message := v_message || 'Begin sendMsgForYDLK time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq,
                             'sendMsgForYDLK',
                             v_message);
    sendMsgForYDLK1(str_msg);
    v_message := v_message || 'End sendMsgForYDLK time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq,
                             'sendMsgForYDLK',
                             v_message);
  EXCEPTION
    WHEN OTHERS THEN
      v_message := v_message || to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') ||
                   'Error' || sqlerrm;
      v_seq     := saveLogInfo(v_seq, 'sendMsgForYDLK', v_message);
  end;

    /**
  * 功能说明：
  *    在激活有效期前30天系统以发展员工为单位统计，对发展员工联系人手机发送失效提醒短信。
  *    轮循执行时间：每天凌晨1点时跑一次
  * author：zhenggw
  * Created：2014-7-4
  **/
  PROCEDURE sendMsgForYDLK1(str_msg out varchar) is

  begin

  end;

  /**
  * 功能说明：
  *    保存日志
  * author：zhenggw
  * Created：2014-7-4
  * @params l_logId   日志id
  *                   更新日志时传入日志id
  *
  * @params str_message   日志内容
  **/
  function saveLogInfo(i_logId       in number,
                       v_method_name in varchar,
                       v_message     in varchar) return number is
    v_result number;
    --PRAGMA AUTONOMOUS_TRANSACTION; --实现自治事务处理
  begin
    v_result := i_logId;
    if i_logId <= 0 then
      select SEQ_INTER_LOG_ID.Nextval into v_result from dual;
      insert into intf_log
        (LOG_ID,
         CUST_SO_NUMBER,
         ORDER_ITEM_ID,
         MSG_TYPE,
         REQUEST_MESSAGE,
         RESPOND_MESSAGE,
         REQUESTER,
         REQUEST_DATE,
         RESPONDER,
         RESPOND_DATE,
         RESULT_FLAG,
         REMARK,
         CREATE_DATE,
         BUSI_CODE,
         SERVICE_CODE,
         METHOD_NAME,
         PROD_INST_ID,
         ACC_NBR,
         TRANSACTION_ID,
         TAGS,
         SERVER_MSG,
         CLIENT_MSG,
         DB_INST_ID,
         REQUEST_HEAD)
      values
        (v_result,
         '',
         '',
         'PKG_procYDLK',
         v_message,
         '',
         'CRM',
         sysdate,
         'CRM',
         sysdate,
         '1',
         '',
         sysdate,
         '',
         '',
         v_method_name,
         null,
         '',
         '',
         '',
         '',
         '',
         sys_context('USERENV', 'INSTANCE'), --表分区用
         '');

    else
      update intf_log
         set REQUEST_MESSAGE = v_message
       where log_id = i_logId;
    end if;
    commit;
    return v_result;
  exception
    WHEN OTHERS THEN
      v_result := 0;
      --ROLLBACK;
      return v_result;
  end;
  /
