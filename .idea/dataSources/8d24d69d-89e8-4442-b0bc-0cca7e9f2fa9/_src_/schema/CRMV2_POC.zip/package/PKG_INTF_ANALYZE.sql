CREATE package           PKG_INTF_ANALYZE is

  -- Author  : XIELY-FFCS
  -- Created : 2016/8/17 11:44:36
  -- Purpose :

 PROCEDURE PROC_ADD_INTF_ANALYZE_DATA;

end PKG_INTF_ANALYZE;
/
