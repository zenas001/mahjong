CREATE PACKAGE           PKG_HB IS

  -- Author  : g.caijx
  -- Created : 2012-02-07
  -- Purpose : 计费接口
  /*短期宽带未续约发起到期停*/
  PROCEDURE PROC_AUTO_BILL_CJT(I_AREA_CODE    IN VARCHAR2, --区号，比如福州0591
                               I_PROD_INST_ID IN VARCHAR2, --接入类产品实例标识
                               O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                               O_ERR_MSG      OUT VARCHAR2, --错误信息
                               O_SERIAL       OUT VARCHAR2); --处理序列号

  /*用于用户充值成功后，计费通知CRM系统*/
  PROCEDURE PROC_CHARGE_COMPLETET(I_AREA_CODE  IN VARCHAR2, --区号，比如福州0591
                                  I_ACC_NBR    IN VARCHAR2, --接入号码
                                  I_PRODUCT_ID IN NUMBER, --接入产品规格标识
                                  O_ERR_CODE   OUT NUMBER, --错误编码（0--成功 1--失败）
                                  O_ERR_MSG    OUT VARCHAR2); --错误信息

  /*套餐续缴或新装充值开通调用此过程插入接口表，生成申请单*/
  PROCEDURE PROC_PREFER_EXTEND(I_PROD_OFFER_INST_ID IN NUMBER, --续费对应的销售品实例标识
                               O_ERR_CODE           OUT NUMBER, --错误编码（0--成功 1--失败）
                               O_ERR_MSG            OUT VARCHAR2); --错误信息

  /*用于电话用户充值开通时计费判断需要收多少费用才运行开通*/
  PROCEDURE PROC_QUERY_CHARGE(I_AREA_CODE  IN VARCHAR2, --区号，比如福州0591
                              I_ACC_NBR    IN VARCHAR2, --接入号码
                              I_PRODUCT_ID IN NUMBER, --接入产品规格标识
                              O_CHARGE     OUT NUMBER, --充值金额（单位：分）
                              O_MODE_TYPE  OUT NUMBER, --开通类型（0--充值开通 1--固网开通  4--拨打开通、预开通）
                              O_PRE_FEE    OUT VARCHAR2, --预存金额（单位：分）
                              O_ERR_CODE   OUT NUMBER, --错误编码（0--成功 1--失败）
                              O_ERR_MSG    OUT VARCHAR2); --错误信息

  /*-------------------------------------------------
    欠费拆机拆机停到期拆。
    Author  : g.caijx
    Created : 2012-03-07
  -------------------------------------------------*/
  PROCEDURE PROC_AUTO_BILL_CJ(I_AREA_CODE    IN VARCHAR2, --区号，比如福州0591
                              I_PROD_INST_ID IN VARCHAR2, --接入类产品实例标识
                              I_ACTION_TYPE  IN VARCHAR2, --动作类型（1:自主拆机 2：欠费拆机）
                              O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                              O_ERR_MSG      OUT VARCHAR2, --错误信息
                              O_SERIAL       OUT VARCHAR2 --处理序列号
                              );
  /*-------------------------------------------------
    关联拆机
  -------------------------------------------------*/
  PROCEDURE PROC_RELA_CJ(I_PROD_INST_ID      IN PROD_INST.PROD_INST_ID%TYPE,
                         I_PARENT_SO_SERV_ID IN VARCHAR2, --父intf_so_serv_id
                         I_CHANNEL_NBR       IN INTF_SO_SERV.CHANNEL_NBR%TYPE
                         );
  /*-------------------------------------------------
    递归拆机
  -------------------------------------------------*/
  PROCEDURE PROC_BILL_CJ_JFGX(I_PROD_INST_ID      IN PROD_INST.PROD_INST_ID%TYPE,
                              I_PARENT_SO_SERV_ID IN VARCHAR2, --父intf_so_serv_id
                              I_CHANNEL_NBR       IN INTF_SO_SERV.CHANNEL_NBR%TYPE
                              );
  /*-------------------------------------------------
    执行拆机
  -------------------------------------------------*/
  PROCEDURE PROC_DO_CJ(I_PROD_INST_ID      IN PROD_INST.PROD_INST_ID%TYPE, --欲拆的产品实例id
                       I_PARENT_SO_SERV_ID IN VARCHAR2, --父intf_so_serv_id
                       I_IS_CHILD_CJ       IN BOOLEAN,  --是否为非计费发起号码拆机，包括融合套餐下其他号码拆机和对应的关联拆机和递归拆机
                       I_CHANNEL_NBR       IN INTF_SO_SERV.CHANNEL_NBR%TYPE,
                       O_SERIAL            OUT VARCHAR2 --INTF_SO_SERV_ID
                       );

  /*根据订单流水号, 判断是否可以划拨*/
  FUNCTION FUNC_CHECK_ORDER_ITEM_INFO(IN_ORDER_ITEM_ID IN NUMBER, --订单项标识
                                      OUT_ERR_MSG      OUT VARCHAR2) --错误信息
   RETURN NUMBER; --服务调用信息（0--成功/可划拨 1--失败）

  PROCEDURE PROC_INVOICE_UPDATE(I_INVOICE_CODE IN VARCHAR2, --发票代码
                                I_INVOICE_NUM  IN VARCHAR2, --发票号码
                                I_STATE        IN VARCHAR2, --状态
                                O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                                O_ERR_MSG      OUT VARCHAR2);

  FUNCTION FUNC_PASSWORD_CHECK(I_AREA_CODE  IN VARCHAR2, --区号，如福州0591
                               I_PRODUCT_ID IN NUMBER, --产品规格编码，如普通电话800000000，移动语音800000002
                               I_ACC_NBR    IN VARCHAR2, --业务号码，如有线宽带5910480051105、移动语音18959190160
                               I_PWD        IN VARCHAR2, --密码值（明文），验证顺序统一密码-->帐号密码-->密码，三个都未找到对应返回失败
                               O_ERR_MSG    OUT VARCHAR2) --错误信息
   RETURN NUMBER;

   FUNCTION FUNC_BILLCZKT_OFFER_CHECK(VO_PROD_OFFER_ID IN NUMBER)
   RETURN NUMBER;

   FUNCTION FUNC_BILLCZKT_EXP_MONTH(VO_PROD_OFFER_ID IN NUMBER)
   RETURN NUMBER;

  PROCEDURE PROC_CRM_IVPNNBR_UPDATE(I_REC_ID    IN NUMBER,
                                    I_OLD_STATE IN VARCHAR2,
                                    I_NEW_STATE IN VARCHAR2,
                                    O_ERR_CODE  OUT NUMBER, --错误编码（0--成功 1--失败）
                                    O_ERR_MSG   OUT VARCHAR2);

END PKG_HB;
/
