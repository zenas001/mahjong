CREATE package           PKG_QZ is

  -- Author  : ADMINISTRATOR
  -- Created : 2013-01-23 9:41:45
  -- Purpose : 提供泉州分公司数据修复包体

  --删除可选包：
  procedure delete_price(in_account    in varchar2,
                         in_offername  in varchar2,
                         i_exp_date    in varchar2, --失效时间
                         iremark       in varchar2, --修改备注
                         in_modi_staff in varchar2, --修改人
                         o_msg         out varchar2);

  --修改套餐参数
  /*（2） 入参：号码、套餐名、参数名、旧值、
  新值、流程id、修改人（根据登录工号自动获得传入）      */
  procedure change_offer_inst_attr(in_account    in varchar2,
                                   in_offername  in varchar2,
                                   in_attrname   in varchar2,
                                   in_oldvalue   in varchar2,
                                   in_newvalue   in varchar2,
                                   in_remark     in varchar2,
                                   in_modi_staff in varchar2,
                                   o_msg         out varchar2);

  ---  修改发展员工和发展团队
  /*（2）  入参：订单流水号、发展工号、发展团队名、
  流程id、修改人（根据登录工号自动获得传入）*/
  procedure change_DEV_STAFF_TEAM(in_custnumber in varchar2,
                                  in_staff      in varchar2,
                                  in_team       in varchar2,
                                  in_remark     in varchar2,
                                  in_modi_staff in varchar2,
                                  o_msg         out varchar);

  -- 、  释放串号
  /*  （1） 允许释放没有关联用户号码的串号
  （2） 入参：串号、流程id、修改人（根据登录工号自动获得传入）
      （3） 出参：是否成功，不成功要返回报错信息*/

  procedure release_TermKey(in_key        in varchar2,
                            in_remark     in varchar2,
                            in_modi_staff in varchar2,
                            o_msg         out varchar2);

end PKG_QZ;
/
