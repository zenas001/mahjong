CREATE PACKAGE           PKG_CRM_UTIL IS


  PROCEDURE PROC_GET_NEXTVAL_NEW(TABLENAME     IN VARCHAR2,
                                                        SEQNAME       IN VARCHAR2,
                                                        O_RESULT      OUT VARCHAR2,
                                                        O_MSG OUT VARCHAR2,
                                                        O_NEXTVAL_NEW OUT NUMBER);
  FUNCTION FUNC_GET_NEXTVAL_NEW(tableName in varchar2,
                                                seqName   in varchar2)
  RETURN NUMBER;
END PKG_CRM_UTIL;
/
