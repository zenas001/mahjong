CREATE PACKAGE BODY           PKG_10000 IS
  TYPE MYRCTYPE IS REF CURSOR;

  /************************************************************************
    Function    : 查询宽带套餐有效期
    Description ：
    Author　    ：wangjianjun
    Date        : 2012-05-03
    Parameter   :
                  I_ACC_NBR      -- 宽带业务号码，如：454309392
                  I_AREA_CODE    -- 区号，如：0591
                  O_EXP_DATE     -- 到期时间，字符串格式YYYYMMDD
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_KD_INFO(I_ACC_NBR   IN VARCHAR2,
                               I_AREA_CODE IN VARCHAR2,
                               O_EXP_DATE  OUT VARCHAR2,
                               O_ERR_CODE  OUT NUMBER,
                               O_ERR_MSG   OUT VARCHAR2) IS
    V_PROD_INST_ID       PROD_INST.PROD_INST_ID%TYPE;
    V_PROD_OFFER_INST_ID PROD_OFFER_INST.PROD_OFFER_INST_ID%TYPE;
  begin
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';
    if I_ACC_NBR is null then
      O_ERR_CODE := 1;
      O_ERR_MSG  := '宽带业务号码不能为空';
      return;
    end if;
    if I_AREA_CODE is null then
      O_ERR_CODE := 1;
      O_ERR_MSG  := '区号不能为空';
      return;
    end if;

    begin
      -- 查询产品实例
      select pi.prod_inst_id
        into V_PROD_INST_ID
        from prod_inst pi
       where pi.area_code = i_area_code
         and pi.acc_nbr = i_acc_nbr
         and pi.status_cd = '100000';
      -- 查询销售品实例
      select opir.prod_offer_inst_id
        into V_PROD_OFFER_INST_ID
        from offer_prod_inst_rel opir, offer_prod_rel opr
       where opir.prod_inst_id = V_PROD_INST_ID
         and opr.offer_prod_rela_id = opir.offer_prod_rel_id
         and opr.rule_type = 12;
    exception
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '档案不存在！';
        return;
    end;
    begin
      select TO_CHAR(poi.exp_date, 'YYYYMMDD')
        into O_EXP_DATE
        from prod_offer_inst_rel poir, prod_offer_inst poi
       where poir.rela_prod_offer_inst_id = V_PROD_OFFER_INST_ID
         and poir.related_prod_offer_inst_id = poi.prod_offer_inst_id
         and poi.status_cd = '1000'
         AND EXISTS (SELECT *
                      FROM PROD_OFFER_INST_ATTR A
                     WHERE A.PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
                       AND A.ATTR_ID = 800001918 --800001918: 年缴金额（元）
                       AND A.STATUS_CD = '1000'
                       )
         ;
    exception
      when others then
        O_ERR_CODE := 1;
        --应10000号测试人员要求，在非年缴套餐时返回失效时间为21990101 - renl 20120712
        O_EXP_DATE := '21990101';
        O_ERR_MSG  := '非年缴套餐！';
        return;
    end;
  end PROC_QUERY_KD_INFO;

  /************************************************************************
    Function    : 查询关联宽带信息
    Description ：根据传入的业务号码、区号、产品规格编码，查询产品做为计费号码关联的有线宽带业务号码和帐号
    Author　    ：wangjianjun
    Date        : 2012-05-03
    Parameter   :
                  I_ACC_NBR       -- 业务号码
                  I_AREA_CODE     -- 区号
                  I_EXT_PROD_ID   -- 转入接入号码对应产品的外部产品规格编码（1.0产品编码）
                  O_PROD_INST_ID  -- 产品实例标识（关联多个时，产品实例标识之间通过','号分隔）
                  O_ACC_NBR       -- 宽带业务号码（关联多个时，业务号码之间通过','号分隔）
                  O_ACCOUNT       -- 宽带帐号（关联多个时，帐号之间通过','号分隔）
                  O_ERR_CODE      -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG       -- 错误信息
    Modification :
                  应10000要求增加输出参数O_PROD_INST_ID --renl 20120621
  ************************************************************************/
  PROCEDURE PROC_QUERY_RELA_KD_INFO(I_ACC_NBR      IN VARCHAR2,
                                    I_AREA_CODE    IN VARCHAR2,
                                    I_EXT_PROD_ID  IN VARCHAR2,
                                    O_PROD_INST_ID OUT VARCHAR2,
                                    O_ACC_NBR      OUT VARCHAR2,
                                    O_ACCOUNT      OUT VARCHAR2,
                                    O_ERR_CODE     OUT NUMBER,
                                    O_ERR_MSG      OUT VARCHAR2) IS
    V_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
    P_RC           MYRCTYPE;
  BEGIN
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';
    -- 入参校验
    IF I_ACC_NBR IS NULL OR I_AREA_CODE IS NULL OR I_EXT_PROD_ID IS NULL THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '业务号码、区号、产品规格编码 不能为空';
      RETURN;
    END IF;
    BEGIN
      -- 查询产品实例
      SELECT PI.PROD_INST_ID
        INTO V_PROD_INST_ID
        FROM PROD_INST PI, PRODUCT P
       WHERE P.PRODUCT_ID = PI.PRODUCT_ID
         AND P.EXT_PROD_ID = I_EXT_PROD_ID
         AND PI.ACC_NBR = I_ACC_NBR
         AND PI.AREA_CODE = I_AREA_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '通过业务号码、区号、外部产品编码为找到相应的产品实例';
        RETURN;
    END;
    BEGIN
      FOR P_RC IN (SELECT PI.PROD_INST_ID, PI.ACC_NBR, PI.ACCOUNT
                     FROM PROD_INST_REL PIR, PROD_INST PI
                    WHERE PIR.PROD_INST_Z_ID = V_PROD_INST_ID
                      AND PIR.PROD_INST_A_ID = PI.PROD_INST_ID
                      AND PIR.RELATION_TYPE_CD = '109930'
                      AND PI.PRODUCT_ID = 800000008) LOOP
        O_PROD_INST_ID := O_PROD_INST_ID || ',' || P_RC.PROD_INST_ID;
        O_ACC_NBR      := O_ACC_NBR || ',' || P_RC.ACC_NBR;
        O_ACCOUNT      := O_ACCOUNT || ',' || P_RC.ACCOUNT;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '执行存储过程出错!' || SQLERRM;
        RETURN;
    END;
    O_PROD_INST_ID := SUBSTR(O_PROD_INST_ID, 2);
    O_ACCOUNT      := SUBSTR(O_ACCOUNT, 2);
    O_ACC_NBR      := SUBSTR(O_ACC_NBR, 2);
    if O_PROD_INST_ID is null or O_ACCOUNT is null or O_ACC_NBR is null then
      O_ERR_CODE := 1;
      O_ERR_MSG  := '没有档案!';
    end if;
  END PROC_QUERY_RELA_KD_INFO;

  /************************************************************************
    Function    : 号码信息查询
    Description ：根据号码、区号（可选）、产品规格编码（可选）查询号码的产品规格编码、产品规格名称、区号、业务号码、接入帐号。
    Author　    ：wangjianjun
    Date        : 2012-05-03
    Parameter   :
                  I_ACC_NBR     -- 业务号码
                  I_AREA_CODE   -- 区号（可选）
                  I_EXT_PROD_ID -- 产品规格编码（可选）
                  O_NBR_INFO    -- 号码信息格式：产品编码，产品规格名称，区号，业务号码，接入帐号，是否小灵通超无标识（标识为主(A)、副(Z)、非(0)）。当记录有多条时，用‘；’隔开
                  O_ERR_CODE    -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG     -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_NBR_INFO(I_ACC_NBR     IN VARCHAR2,
                                I_AREA_CODE   IN VARCHAR2,
                                I_EXT_PROD_ID IN VARCHAR2,
                                O_NBR_INFO    OUT VARCHAR2,
                                O_ERR_CODE    OUT NUMBER,
                                O_ERR_MSG     OUT VARCHAR2) IS
    V_XLTCW        VARCHAR2(10);
  BEGIN
    O_ERR_CODE := 1;

    IF I_ACC_NBR IS NULL THEN
      O_ERR_MSG := '业务号码不能为空';
      RETURN;
    END IF;

    FOR REC IN (SELECT P.EXT_PROD_ID,
                       P.PRODUCT_NAME,
                       PI.PROD_INST_ID,
                       PI.AREA_CODE,
                       PI.ACC_NBR,
                       PI.ACCOUNT
                  FROM PROD_INST PI, PRODUCT P
                 WHERE PI.PRODUCT_ID = P.PRODUCT_ID
                   AND PI.ACC_NBR = I_ACC_NBR
                   AND PI.STATUS_CD <> '110000') LOOP

      IF ((REC.AREA_CODE = I_AREA_CODE OR I_AREA_CODE IS NULL) AND
         (REC.EXT_PROD_ID = I_EXT_PROD_ID OR I_EXT_PROD_ID IS NULL)) THEN

        SELECT NVL((SELECT DECODE(PIA.ATTR_VALUE, REC.PROD_INST_ID, 'A', 'Z')
                     FROM PROD_INST_REL PIR, PROD_INST_ATTR PIA
                    WHERE PIA.PROD_INST_ID = PIR.PROD_INST_Z_ID
                      AND PIR.PROD_INST_A_ID = REC.PROD_INST_ID
                      AND PIR.PRODUCT_REL_ID IN (18224, 17586)
                      AND PIA.ATTR_ID = 800004083),
                   '0')
          INTO V_XLTCW
          FROM DUAL;

        O_NBR_INFO := O_NBR_INFO || ';' || REC.EXT_PROD_ID || ',' ||
                      REC.PRODUCT_NAME || ',' || REC.AREA_CODE || ',' ||
                      REC.ACC_NBR || ',' || REC.ACCOUNT || ',' || V_XLTCW;
      END IF;
    END LOOP;

    O_NBR_INFO := SUBSTR(O_NBR_INFO, 2);
    IF O_NBR_INFO IS NULL THEN
      O_ERR_MSG := '没有档案!';
      RETURN;
    END IF;

    O_ERR_CODE := 0;
  END PROC_QUERY_NBR_INFO;

  /************************************************************************
  Function    : 订单竣工查询
  Description ：订单是否竣工查询
  Author　    ：wangjianjun
  Date        : 2012-05-03
  Parameter   :
                I_CUST_SO_NUMBER    -- 订单流水号
                O_RESULT            -- 0 未竣工; 1 已竣工
                O_ERR_CODE          -- 处理结果（0--成功 1--失败）
                O_ERR_MSG           -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_ORDER_INFO(I_CUST_SO_NUMBER IN VARCHAR2,
                                  O_RESULT         OUT VARCHAR2,
                                  O_ERR_CODE       OUT NUMBER,
                                  O_ERR_MSG        OUT VARCHAR2) IS
    V_FLAG1 NUMBER;
    V_FLAG2 NUMBER;
  BEGIN
    BEGIN
      -- 查询订单历史表是否存在状态为竣工的订单
      SELECT COUNT(CO.CUST_ORDER_ID)
        INTO V_FLAG1
        FROM CUSTOMER_ORDER_HIS CO
       WHERE CO.CUST_SO_NUMBER = I_CUST_SO_NUMBER
         AND CO.STATUS_CD = '300000';
      -- 历史表不存在报竣记录时，查询订单表是否有记录
      IF V_FLAG1 = 0 THEN
        SELECT COUNT(CO.CUST_ORDER_ID)
          INTO V_FLAG2
          FROM CUSTOMER_ORDER CO
         WHERE CO.CUST_SO_NUMBER = I_CUST_SO_NUMBER;
        IF V_FLAG2 = 0 THEN
          O_ERR_CODE := 1;
          O_ERR_MSG  := '订单不存在';
        ELSE
          O_RESULT   := 0;
          O_ERR_CODE := 0;
        END IF;
      ELSE
        O_RESULT   := 1;
        O_ERR_CODE := 0;
      END IF;
    END;
  END PROC_QUERY_ORDER_INFO;

  /************************************************************************
    Function    : 小灵通携号转网查询
    Description ：判断若输入小灵通号码为携号转网的旧号码，返回天翼号码给10000号系统；若不是携号转网的小灵通，则返回号码为空；
    Author　    ：wangjianjun
    Date        : 2012-05-04
    Parameter   :
                  I_ACC_NBR      -- 业务号码
                  I_AREA_CODE    -- 区号
                  O_CDMA_ACC_NBR -- 天翼业务号码
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_XHZW(I_ACC_NBR      IN VARCHAR2,
                            I_AREA_CODE    IN VARCHAR2,
                            O_CDMA_ACC_NBR OUT VARCHAR2,
                            O_ERR_CODE     OUT NUMBER,
                            O_ERR_MSG      OUT VARCHAR2) IS
    V_PRODUCT_REL_ID PRODUCT_RELATION.PRODUCT_REL_ID%TYPE;
    V_PROD_INST_Z_ID PROD_INST.PROD_INST_ID%TYPE;
  BEGIN
    O_ERR_CODE     := 0;
    O_CDMA_ACC_NBR := '';

    -- 查询小灵通带号转网程控做为Z端的主从关系
    BEGIN
      SELECT PRODUCT_REL_ID
        INTO V_PRODUCT_REL_ID
        FROM PRODUCT_RELATION PR
       WHERE PR.PRODUCT_Z_ID = 800000570
         AND PR.PRODUCT_A_ID = 800000002
         AND PR.RELATION_TYPE_CD = '100600';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '天翼与小灵通带号转网功能产品的主从关系未配置';
        RETURN;
    END;
    -- 查询业务号码及区号对应的小灵通带号转网程控ID
    BEGIN
      SELECT PI.PROD_INST_ID
        INTO V_PROD_INST_Z_ID
        FROM PROD_INST PI, PROD_INST_ATTR PIA
       WHERE PIA.PROD_INST_ID = PI.PROD_INST_ID
         AND PIA.ATTR_ID = 800001385
         AND PI.AREA_CODE = I_AREA_CODE
         AND PIA.ATTR_VALUE = I_ACC_NBR;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '通过业务号码与区号未找到小灵通带号转网功能产品';
        RETURN;
    END;
    -- 查询A端业务号码
    BEGIN
      SELECT PA.ACC_NBR
        INTO O_CDMA_ACC_NBR
        FROM PROD_INST PA, PROD_INST_REL PIR
       WHERE PIR.PROD_INST_A_ID = PA.PROD_INST_ID
         AND PIR.PRODUCT_REL_ID = V_PRODUCT_REL_ID
         AND PIR.PROD_INST_Z_ID = V_PROD_INST_Z_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '通过业务号码与区号未找到小灵通带号转网功能产品关联的天翼';
        RETURN;
    END;
  END PROC_QUERY_XHZW;

  /************************************************************************
    Function    : 无线宽带关联主副卡查询
    Description ：以传入的接入号码为主卡（或副卡）查询关联的副卡（或主卡）
    Author　    ：wangjianjun
    Date        : 2012-05-04
    Parameter   :
                  I_ACC_NBR      -- 业务号码
                  I_AREA_CODE    -- 区号
                  O_ACCTYPE      -- 输入号码类型 1：主卡 2：副卡
                  O_RELA_ACC_NBR -- 输出关联的业务号码
                  O_ERR_CODE     -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG      -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_DOUBLE_NUMBER(I_ACC_NBR      IN VARCHAR2,
                                     I_AREA_CODE    IN VARCHAR2,
                                     O_ACCTYPE      OUT VARCHAR2,
                                     O_RELA_ACC_NBR OUT VARCHAR2,
                                     O_ERR_CODE     OUT NUMBER,
                                     O_ERR_MSG      OUT VARCHAR2) IS
    --变量定义
    V_IN_PROD_INST_ID  PROD_INST.PROD_INST_ID%TYPE;
    V_FUN_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
    V_MAN_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
  BEGIN
    --变量初始化
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    BEGIN
      -- 通过业务号码和区号查询传入的接入类产品实例ID
      SELECT PI.PROD_INST_ID
        INTO V_IN_PROD_INST_ID
        FROM PROD_INST PI
       WHERE PI.ACC_NBR = I_ACC_NBR
         AND PI.AREA_CODE = I_AREA_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '通过业务号码与区号未找到对应产品实例';
        RETURN;
    END;
    BEGIN
      -- 通过传入的产品实例ID查询Z端一卡双芯实例ID
      SELECT PIR.PROD_INST_Z_ID
        INTO V_FUN_PROD_INST_ID
        FROM PRODUCT_RELATION PR, PROD_INST_REL PIR
       WHERE PR.PRODUCT_REL_ID = PIR.PRODUCT_REL_ID
         AND PIR.PROD_INST_A_ID = V_IN_PROD_INST_ID
         AND PR.PRODUCT_Z_ID = 800551826
         AND PR.RELATION_TYPE_CD = '100600';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '数据异常，通过业务号码与区号未找到一卡双芯功能产品';
        RETURN;
    END;
    BEGIN
      -- 通过一卡双芯实例ID查询非转入的A端产品实例信息
      SELECT PI.ACC_NBR
        INTO O_RELA_ACC_NBR
        FROM PRODUCT_RELATION PR, PROD_INST_REL PIR, PROD_INST PI
       WHERE PR.PRODUCT_REL_ID = PIR.PRODUCT_REL_ID
         AND PIR.PROD_INST_A_ID = PI.PROD_INST_ID
         AND PIR.PROD_INST_Z_ID = V_FUN_PROD_INST_ID
         AND PIR.PROD_INST_A_ID <> V_IN_PROD_INST_ID
         AND PR.PRODUCT_Z_ID = 800551826
         AND PR.RELATION_TYPE_CD = '100600';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '数据异常，一卡双芯未关联另一端产品';
        RETURN;
    END;
    BEGIN
      -- 查询一卡双芯实例的主号码ID属性值
      SELECT PIA.ATTR_VALUE
        INTO V_MAN_PROD_INST_ID
        FROM PROD_INST_ATTR PIA
       WHERE PIA.PROD_INST_ID = V_FUN_PROD_INST_ID
         AND PIA.ATTR_ID = 800004083;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '数据异常，一卡双芯实例为设置主号码ID属性值';
        RETURN;
    END;
    IF V_MAN_PROD_INST_ID = V_IN_PROD_INST_ID THEN
      O_ACCTYPE := '1';
    ELSE
      O_ACCTYPE := '2';
    END IF;
  END PROC_QUERY_DOUBLE_NUMBER;

  /************************************************************************
    Function    : 档案信息查询
    Description ：根据输入号码查询该业务号码的信息
    Author　    ：wangjianjun
    Date        : 2012-05-04
    Parameter   :
                  IO_ACC_NBR               -- 业务号码
                  I_AREA_CODE              -- 区号
                  I_EXT_PROD_ID            -- 产品规格编码
                  O_CUSTiCUST_NAME         --用户名称
                  O_SERViSTATE             --业务号码状态
                  O_ADDRiWHOLE_ADDR        --用户地址
                  O_CUSTiCUST_KIND_ID      --用户性质 (2.0中已废弃,返回空)
                  O_CUSTiINDUS_CAT_ID      --行业划分
                  O_SERViPROD_ID           --销售品规格
                  O_ACCTiACCT_NBR          --合同号
                  O_CUSTiCERT_NBR          --身份证号
                  O_SERViCREA_DATE         --装机时间（yyyymmddhh24miss)
                  O_EXCHiEXCH_CODE         --局向
                  O_SERV_TYPEiSERV_TYPE_ID --服务类型编码（2.0中已废弃，返回空）
                  O_SOiAREA_ID             --号码区域信息
                  O_CUSTiCUST_GRADE_ID     --用户重要等级（重要、普通）
                  O_CUSTiCUST_SORT_ID      --用户大类 (与用户等级重复 返回空)
                  O_CUSTiSTATE             --是否有绑定宽带（ADSL，LAN）帐号(0：没有  1:有)
                  O_CUSTiCUST_CODE         --是否有高级密码 (0：没有  1:有)
                  O_CUSTiVIP               --是否有超级无绳 (0：没有  1:有)
                  O_CUSTiCUST_GH           --是否是公话 （2.0中已废弃，返回空）
                  O_CUSTiLTBL              --是否有灵通伴侣标识(0：没有  1:有)
                  O_FEEiPACKAGE            --资费套餐说明 （返回空）
                  O_PAYiTYPE               --支付方式
                  O_MAIN_GROUP_ID          --战略分群
                  O_ZJLX                   --证件类型
                  O_DX_STATE               --是否有短信功能(0：没有  1:有)
                  O_KH_BRAND_ID            --客户品牌ID
                  O_KH_BRAND               --客户品牌
                  O_CUSTTYCW               --是否有天翼超无(0：没有  1:有)
                  O_ERR_CODE               -- 处理结果（0--成功 1--失败）
                  O_ERR_MSG                -- 错误信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_ARCHIVE_INFO(IO_ACC_NBR               IN OUT VARCHAR2, -- 业务号码
                                    I_AREA_CODE              IN VARCHAR2, -- 区号
                                    I_EXT_PROD_ID            IN VARCHAR2, -- 产品规格编码
                                    O_CUSTiCUST_NAME         OUT varchar2, --用户名称
                                    O_SERViSTATE             OUT varchar2, --业务号码状态
                                    O_ADDRiWHOLE_ADDR        OUT varchar2, --用户地址
                                    O_CUSTiCUST_KIND_ID      OUT varchar2, --用户性质 (2.0中已废弃,返回空)
                                    O_CUSTiINDUS_CAT_ID      OUT varchar2, --行业划分
                                    O_SERViPROD_ID           OUT varchar2, --销售品规格
                                    O_ACCTiACCT_NBR          OUT varchar2, --合同号
                                    O_CUSTiCERT_NBR          OUT varchar2, --身份证号
                                    O_SERViCREA_DATE         OUT varchar2, --装机时间（yyyymmddhh24miss)
                                    O_EXCHiEXCH_CODE         OUT varchar2, --局向
                                    O_SERV_TYPEiSERV_TYPE_ID OUT varchar2, --服务类型编码（2.0中已废弃，返回空）
                                    O_SOiAREA_ID             OUT varchar2, --号码区域信息
                                    O_CUSTiCUST_GRADE_ID     OUT varchar2, --用户重要等级（重要、普通）
                                    O_CUSTiCUST_SORT_ID      OUT varchar2, --用户大类 (与用户等级重复 返回空)
                                    O_CUSTiSTATE             OUT varchar2, --是否有绑定宽带（ADSL，LAN）帐号(0：没有  1:有)
                                    O_CUSTiCUST_CODE         OUT varchar2, --是否有高级密码 (0：没有  1:有)
                                    O_CUSTiVIP               OUT varchar2, --是否有超级无绳 (0：没有  1:有)
                                    O_CUSTiCUST_GH           OUT varchar2, --是否是公话 （2.0中已废弃，返回空）
                                    O_CUSTiLTBL              OUT varchar2, --是否有灵通伴侣标识(0：没有  1:有)
                                    O_FEEiPACKAGE            OUT VARCHAR2, --资费套餐说明 （返回空）
                                    O_PAYiTYPE               OUT VARCHAR2, --支付方式
                                    O_MAIN_GROUP_ID          OUT VARCHAR2, --战略分群
                                    O_ZJLX                   OUT VARCHAR2, --证件类型
                                    O_DX_STATE               OUT VARCHAR2, --是否有短信功能(0：没有  1:有)
                                    O_KH_BRAND_ID            OUT VARCHAR2, --客户品牌ID
                                    O_KH_BRAND               OUT VARCHAR2, --客户品牌
                                    O_CUSTTYCW               OUT varchar2, --是否有天翼超无(0：没有  1:有)
                                    O_ERR_CODE               OUT NUMBER, -- 处理结果（0--成功 1--失败）
                                    O_ERR_MSG                OUT VARCHAR2 -- 错误信息
                                    ) IS
    -- 变量定义
    V_PROD_INST_ID       PROD_INST.PROD_INST_ID%TYPE;
    V_CUST_ID            CUST.CUST_ID%TYPE;
    v_prod_offer_inst_id prod_offer_inst.prod_offer_inst_id%type;
    v_number             number;
    v_temp               varchar2(100);
    v_payment_method_id  payment_plan.payment_method_id%type;
  BEGIN
    --变量初始化
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';
    IF IO_ACC_NBR IS NULL THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '业务号码不能为空';
      RETURN;
    END IF;
    IF I_AREA_CODE IS NULL THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '区号不能为空';
      RETURN;
    END IF;
    IF I_EXT_PROD_ID IS NULL THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '产品规格编码不能为空';
      RETURN;
    END IF;

    -- 产品信息
    begin
      select pi.prod_inst_id,
             pi.owner_cust_id,
             pi.address_desc, --装机地址
             pi.exch_id, --局向ID
             a.account_number, --合同号
             TO_CHAR(pi.create_date, 'YYYYMMDDHH24MISS'), -- 装机时间
             pi.common_region_id, --号码区域信息
             pi.status_cd, --产品状态
             pp.payment_method_id --帐户支付类型
        into V_PROD_INST_ID,
             V_CUST_ID,
             O_ADDRiWHOLE_ADDR,
             O_EXCHiEXCH_CODE,
             O_ACCTiACCT_NBR,
             O_SERViCREA_DATE,
             O_SOiAREA_ID,
             O_SERViSTATE,
             v_payment_method_id
        from product        p,
             prod_inst      pi,
             account  a,
             prod_inst_acct pia,
             payment_plan   pp
       where p.product_id = pi.product_id
         and pia.prod_inst_id = pi.prod_inst_id
         and pia.account_id = a.account_id
         and pi.acc_nbr = IO_ACC_NBR
         and pi.area_code = I_AREA_CODE
         and p.ext_prod_id = I_EXT_PROD_ID
         and pp.account_id = a.account_id
         AND pia.def_acct_flag = 'T'
         AND pp.status_cd = '1000'
         AND pia.status_cd = '1000'
         AND pi.status_cd <> '110000' --拆机
         AND ROWNUM = 1
         ;
    exception
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '产品实例不存在';
        RETURN;
    end;
    -- 销售品信息
    begin
      select po.ext_offer_nbr, poi.prod_offer_inst_id
        into O_SERViPROD_ID, v_prod_offer_inst_id
        from prod_offer po, prod_offer_inst poi, offer_prod_inst_rel rel
       where rel.prod_offer_inst_id = poi.prod_offer_inst_id
         and poi.prod_offer_id = po.prod_offer_id
         and po.offer_type in ('10', '11')
         and rel.prod_inst_id = V_PROD_INST_ID
         and poi.status_cd = 1000 ;
    exception
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查询销售品失败';
        RETURN;
    end;
    -- 客户信息
    begin
      select pa.party_name, --客户名称
             c.cust_type, --战略分群
             c.important_level, --重要等级
             c.industry_cd, --行业分类
             pc.cert_type, --证件类型
             pc.cert_number, --证件号码
             cbl.brand_cd --客户品牌ID
        into O_CUSTiCUST_NAME,
             O_MAIN_GROUP_ID,
             O_CUSTiCUST_GRADE_ID,
             O_CUSTiINDUS_CAT_ID,
             O_ZJLX,
             O_CUSTiCERT_NBR,
             O_KH_BRAND_ID
        from cust c, party pa, party_certification pc, cust_brand_label cbl
       where c.party_id = pa.party_id
         and pc.party_id = pa.party_id
         and c.cust_id = cbl.cust_id(+)
         and c.cust_id = V_CUST_ID
         and rownum = 1;
    exception
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查询客户信息失败';
        RETURN;
    end;

    -- 客户品牌
    if O_KH_BRAND_ID is not null then
      begin
        select b.brand_name
          into O_KH_BRAND
          from brand b
         where brand_cd = O_KH_BRAND_ID;
      exception
        when others then
          O_KH_BRAND := '其它品牌';
      end;
    else
      O_KH_BRAND_ID := '-1';
      O_KH_BRAND    := '无客户品牌';
    end if;

    -- 是否有超级无绳 0表示没有  1表示有
    begin
      select count(*)
        into v_number
        from prod_inst_rel pir
       where pir.product_rel_id in (18224, 17586)
         and prod_inst_a_id = V_PROD_INST_ID;
      if v_number = 0 then
        O_CUSTiVIP := '0';
      else
        O_CUSTiVIP := '1';
      end if;
    end;

    --是否有高级密码  0表示没有  1表示有
    begin
      select pia.attr_value
        into v_temp
        from prod_inst_attr pia, attr_spec a
       where pia.prod_inst_id = v_prod_inst_id
         and pia.attr_id = a.attr_id
         and a.java_code = 'M';
      if v_temp is not null then
        O_CUSTiCUST_CODE := '1';
      else
        O_CUSTiCUST_CODE := '0';
      end if;
    exception
      when others then
        O_CUSTiCUST_CODE := '0';
    end;

    --是否有灵通伴侣标识 0表示没有  1表示有
    begin
      select count(*)
        into v_number
        from prod_inst_rel pir, prod_inst pi, product p
       where pir.prod_inst_z_id = pi.prod_inst_id
         and pi.product_id = p.product_id
         and p.ext_prod_id = '800567110'
         and pir.prod_inst_a_id = v_prod_inst_id;
      if v_number = 0 then
        O_CUSTiLTBL := '0';
      else
        O_CUSTiLTBL := '1';
      end if;
    end;

    --是否有绑定宽带（ADSL，LAN）帐号0为没有1表示为有
    begin
      select count(pi.prod_inst_id)
        into v_number
        from product p, prod_inst pi, prod_inst_rel pir
       where pi.prod_inst_id = pir.prod_inst_z_id
         and pi.product_id = p.product_id
         and p.ext_prod_id in
             ('594000255', '594000258', '594000262', '594000263',
              '594000264', '594000861', '594000257', '610007605',
              '610007606', '610007607')
         and pir.relation_type_cd in ('109950', '109930')
         and pir.prod_inst_a_id = V_PROD_INST_ID;
      if v_number > 0 then
        O_CUSTiSTATE := '1';
      else
        select count(pi.prod_inst_id)
          into v_number
          from product p, prod_inst pi, prod_inst_rel pir
         where pi.prod_inst_id = pir.prod_inst_a_id
           and pi.product_id = p.product_id
           and p.ext_prod_id in
               ('594000255', '594000258', '594000262', '594000263',
                '594000264', '594000861', '594000257', '610007605',
                '610007606', '610007607')
           and pir.relation_type_cd in ('109950', '109930')
           and pir.prod_inst_z_id = V_PROD_INST_ID;
        if v_number = 0 then
          O_CUSTiSTATE := '0';
        else
          O_CUSTiSTATE := '1';
        end if;
      end if;
    exception
      when others then
        O_CUSTiSTATE := '0';
    end;

    --短信功能
    begin
      select count(pi.prod_inst_id)
        into v_number
        from product p, prod_inst pi, prod_inst_rel pir
       where pi.prod_inst_id = pir.prod_inst_z_id
         and pi.product_id = p.product_id
         and p.product_nbr in ('35201002112000000001', '600004605')
         and pir.prod_inst_a_id = V_PROD_INST_ID;
      if v_number > 0 then
        O_DX_STATE := '1';
      else
        O_DX_STATE := '0';
      end if;
    end;

    --天翼超无
    begin
      select count(*)
        into v_number
        from prod_inst_rel pir
       where pir.product_rel_id in ('17493', '17495')
         and prod_inst_a_id = V_PROD_INST_ID;
      if v_number > 0 then
        O_CUSTTYCW := '1';
      else
        O_CUSTTYCW := '0';
      end if;
    end;
    --O_CUSTiCUST_GH  是否是公话      0是公话    1不是公话

    --支付类型
    begin
      if v_payment_method_id is not null then
        select a.attr_value_name
          into O_PAYiTYPE
          from attr_value a
         where a.attr_id = 8461
           and a.attr_value = v_payment_method_id;
      end if;
    exception
      when others then
        O_PAYiTYPE := '';
    end;
  END PROC_QUERY_ARCHIVE_INFO;
  PROCEDURE PROC_JTDH_MEMBER_QUERY(I_AREA_CODE        IN VARCHAR2, --区域，如：福州0591
                                   I_ACC_NBR          IN VARCHAR2, --接入号码，如：15359121897
                                   I_EXT_PROD_ID      IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                   O_ERR_CODE         OUT NUMBER, --错误编码（0--成功 1--失败）
                                   O_ERR_MSG          OUT VARCHAR2, --错误信息
                                   O_HOST_NBR         OUT VARCHAR2, --户主号码
                                   O_HOST_SHORT_NBR   OUT VARCHAR2, --户主短号
                                   O_HOST_STATUS_CD   OUT VARCHAR2, --户主号码状态
                                   O_MEMBER_NBR       OUT VARCHAR2, --家庭成员号码，多个时用逗号隔开
                                   O_MEMBER_SHORT_NBR OUT VARCHAR2, --家庭成员短号，多个时用逗号隔开，顺序与号码对应
                                   O_MEMBER_STATUS_CD OUT VARCHAR2, --家庭成员号码状态，多个时用逗号隔开，顺序与号码对应
                                   O_JTDH_NBR         OUT VARCHAR2 -- 家庭短号本身的号码
                                   ) IS

  BEGIN
    PKG_COMMON.PROC_QUERY_QQDH_MEMBER(I_AREA_CODE        => I_AREA_CODE,
                                      I_ACC_NBR          => I_ACC_NBR,
                                      I_EXT_PROD_ID      => I_EXT_PROD_ID,
                                      O_ERR_CODE         => O_ERR_CODE,
                                      O_ERR_MSG          => O_ERR_MSG,
                                      O_HOST_NBR         => O_HOST_NBR,
                                      O_HOST_SHORT_NBR   => O_HOST_SHORT_NBR,
                                      O_HOST_STATUS_CD   => O_HOST_STATUS_CD,
                                      O_MEMBER_NBR       => O_MEMBER_NBR,
                                      O_MEMBER_SHORT_NBR => O_MEMBER_SHORT_NBR,
                                      O_MEMBER_STATUS_CD => O_MEMBER_STATUS_CD,
                                      O_JTDH_NBR         => O_JTDH_NBR);
  END PROC_JTDH_MEMBER_QUERY;

  PROCEDURE PROC_QUERY_IS_YJT(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                              I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                              I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                              I_TYPE        IN VARCHAR2, --1为一键通判断，2为亲情短号判断，3 e家成员判断，4当前号码所在的E家是否有开通亲情短号功能
                              O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                              O_ERR_MSG     OUT VARCHAR2, --错误信息
                              O_RESULT      OUT VARCHAR2 --结果信息，是否是(一键通、 亲情短号、e家成员)用户 0：不是；1：是
                              ) IS
    V_PROD_INST_ID       PROD_INST.PROD_INST_ID%TYPE;
    V_PROD_OFFER_INST_ID PROD_OFFER_INST.PROD_OFFER_INST_ID%TYPE;
    V_YJT_COUNT          NUMBER;
    V_QQDH_COUNT         NUMBER;
  BEGIN
    --变量初始化
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';
    O_RESULT   := '0';

    --判断产品实例是否有效存在
    BEGIN
      select pi.prod_inst_id
        into V_PROD_INST_ID
        from product p, prod_inst pi
       where 1 = 1
         and p.product_id = pi.product_id
         and pi.area_code = I_AREA_CODE
         and pi.acc_nbr = I_ACC_NBR
         and p.ext_prod_id = I_EXT_PROD_ID
         and pi.status_cd = '100000';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '无效号码';
        RETURN;
    END;

    BEGIN
      --判断号码是否有“一键通”程控
      IF I_TYPE = '1' THEN
        select count(*)
          into O_RESULT
          from prod_inst pi_z, product p_z, prod_inst_rel pir
         where pi_z.product_id = p_z.product_id
           and pi_z.prod_inst_id = pir.prod_inst_z_id
           and pir.prod_inst_a_id = V_PROD_INST_ID
           and p_z.product_id = '800779329'; --一键通产品外部编码
      END IF;

      --判断号码是否关联”亲情短号“接入类产品
      IF I_TYPE = '2' THEN
        select count(*)
          into O_RESULT
          from prod_inst pi_a, product p_a, prod_inst_rel pir
         where pi_a.product_id = p_a.product_id
           and pi_a.prod_inst_id = pir.prod_inst_a_id
           and pir.prod_inst_z_id = V_PROD_INST_ID
           and p_a.ext_prod_id = '610007885'; --亲情短号产品外部编码
      END IF;

      --判断号码是否关联E家套餐销售品（判断E家的条件待确定）
      IF I_TYPE = '3' THEN
        select count(*)
          into O_RESULT
          from offer_prod_inst_rel opir, prod_offer_inst poi, prod_offer po
         where opir.prod_inst_id = V_PROD_INST_ID
           and opir.prod_offer_inst_id = poi.prod_offer_inst_id
           and poi.prod_offer_id = po.prod_offer_id
           and po.prod_offer_name like '%e%'
           and po.status_cd = '1000'
           and po.offer_type in ('11');
      END IF;

      IF I_TYPE = '4' THEN
        BEGIN
          select poi.prod_offer_inst_id
            into V_PROD_OFFER_INST_ID
            from offer_prod_inst_rel opir,
                 prod_offer_inst     poi,
                 prod_offer          po
           where opir.prod_inst_id = V_PROD_INST_ID
             and opir.prod_offer_inst_id = poi.prod_offer_inst_id
             and poi.prod_offer_id = po.prod_offer_id
             and po.prod_offer_name like '%e%'
             and po.status_cd = '1000'
             and po.offer_type in ('11');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RETURN;
        END;

        select count(*)
          into O_RESULT
          from offer_prod_inst_rel opir,
               prod_inst           pi_z,
               prod_inst_rel       pir,
               prod_inst           pi_a,
               product             p_a
         where opir.prod_offer_inst_id = V_PROD_OFFER_INST_ID
           and opir.prod_inst_id = pi_z.prod_inst_id
           and pi_z.prod_inst_id = pir.prod_inst_z_id
           and pir.prod_inst_a_id = pi_a.prod_inst_id
           and pi_a.product_id = p_a.product_id
           and p_a.ext_prod_id = '610007885';

      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '未知错误';
        RETURN;
    END;
  END PROC_QUERY_IS_YJT;
 /* 亲情网查询 */
  PROCEDURE PROC_QUERY_OFFER_REL_INFO(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR     IN VARCHAR2, --业务号码
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_ZHU_HAO   OUT VARCHAR2, --主号
                                 O_ZHU_HAO_AREA  OUT VARCHAR2, --主号区域
                                 O_FU_HAO OUT VARCHAR2,---副号
                                 O_FU_HAO_AREA OUT VARCHAR2 --副号区域
                                 ) is

 V_PROD_INST_ID PROD_INST.PROD_INST_ID%TYPE;
 V_PROD_OFFER_INST_ID OFFER_PROD_INST_REL.PROD_OFFER_INST_ID%TYPE;
 V_PROD_OFFER_ID PROD_OFFER_INST.PROD_OFFER_ID%TYPE;
  begin
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

--判断传入的号码
    begin
      select pi.PROD_INST_ID
        into V_PROD_INST_ID
        from product p, prod_inst pi
       where p.product_id = pi.product_id
         and pi.acc_nbr = I_ACC_NBR
         and p.ext_prod_id = I_EXT_PROD_ID
         and pi.area_code= I_AREA_CODE
         and pi.status_cd != '110000';
    exception
      when no_data_found then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '号码不存在';
        return;
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查询号码出错:'||SUBSTR(SQLERRM,1,500);
        return;
    end;
    ---判断是否存在亲情网销售品
    begin
        select A1.PROD_OFFER_INST_ID,A2.PROD_OFFER_ID
        into V_PROD_OFFER_INST_ID ,V_PROD_OFFER_ID
        from OFFER_PROD_INST_REL A1,PROD_OFFER_INST A2
       where A1.PROD_INST_ID=V_PROD_INST_ID AND A1.PROD_OFFER_INST_ID=A2.PROD_OFFER_INST_ID
       and a2.prod_offer_id='900670469' and a2.status_cd != '1100';
exception
      when no_data_found then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '亲情网销售品不存在';
        return;
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查询号码出错:'||SUBSTR(SQLERRM,1,500);
        return;
    end;
---取主号信息
    if (V_PROD_OFFER_ID =900670469)  then
      begin
        select pi.acc_nbr,pi.area_code
          into O_ZHU_HAO,O_ZHU_HAO_AREA
          from OFFER_PROD_INST_REL A1,prod_inst pi
         where A1.PROD_OFFER_INST_ID=V_PROD_OFFER_INST_ID
         and pi.prod_inst_id=a1.prod_inst_id
           AND A1.ROLE_CD='12186';
      exception
        when no_data_found then
          O_ERR_CODE :=1;
          O_ERR_MSG  := '主号为空';
          return;
      end;
      --取副号信息
      begin
SELECT a1.prod_offer_inst_id,to_char(wmsys.wm_concat(pi.acc_nbr)),to_char(wmsys.wm_concat(pi.area_code))
          into V_PROD_OFFER_ID,O_FU_HAO ,O_FU_HAO_AREA
              from OFFER_PROD_INST_REL A1,prod_inst pi
         where A1.PROD_OFFER_INST_ID=V_PROD_OFFER_INST_ID
         and pi.prod_inst_id=a1.prod_inst_id
           AND A1.ROLE_CD='12187'
 GROUP BY a1.prod_offer_inst_id;
      exception
        when no_data_found then
          O_ERR_MSG  := '该亲情网下未有副号角色';
          return;
      end;
    end if ;
    end PROC_QUERY_OFFER_REL_INFO;
END PKG_10000;
/
