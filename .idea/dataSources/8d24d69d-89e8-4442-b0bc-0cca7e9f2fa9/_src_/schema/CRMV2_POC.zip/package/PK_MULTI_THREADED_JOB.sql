CREATE PACKAGE           PK_MULTI_THREADED_JOB IS
  /**  PRO_NULL
  *一个空的存储过程，不执行任何操作
  *add by zhengzhh  2013-02-01
  */
  PROCEDURE PRO_NULL;
  /**
  *读取任务日志，只处理自动类型的任务
  * add by zhengzhh 20130207
  */
  PROCEDURE PRO_EXEC_AUTO_TASK;
  /**
  *读取任务日志，只处理手动类型的任务
  * add by zhengzhh 20130207
  *参数：I_TASK_ID 任务id;I_EXEC_DATE 执行时间 为空时，当前时间加30s
  */
  PROCEDURE PRO_EXEC_MANUAL_TASK(I_TASK_ID NUMBER,
                                 I_EXEC_DATE DATE DEFAULT 'null');
  /**  PRO_JOB_SCHEDULE_MAIN
  *通过外围调用传入参数，实现参数中需要执行的语句与job捆绑
  *add by zhengzhh  2013-02-01
  *I_EXEC_SQL 传入sql语句，存储过程，函数等
  *I_NEXT_DATE 传入指定执行时间
  */
  PROCEDURE PRO_JOB_SCHEDULE_MAIN(I_TASK_ID NUMBER, I_EXEC_SQL VARCHAR2,
                                  I_NEXT_DATE DATE);
  /**  PRO_JOB_EXECUTE_MAIN
  *子线程 执行过程
  *所有与job捆绑的语句，都通过该存储过程执行
  *add by zhengzhh  2013-02-01
  *EXEC_SQL 传入sql语句，存储过程，函数等
  *PJOBNUM 传入JOB 唯一标识id
  *TSEK_ID 传入任务日志表主键
  */
  PROCEDURE PRO_JOB_EXECUTE_MAIN(EXEC_SQL VARCHAR2, PJOBNUM NUMBER,
                                 I_LOG_ID NUMBER);
  /**  INIT_JOB
  *用于初始job，捆绑一个空的存储过程
  *add by zhengzhh  2013-02-01
  *MAX_JOB_INSTANCE 定义需要初始化多少job
  */
  PROCEDURE INIT_JOB(MAX_JOB_INSTANCE NUMBER);
  PROCEDURE REMOVE_JOB;

  PROCEDURE PRO_VALIDITY_OF_SQL(I_JOB_ID NUMBER, I_SQL VARCHAR2,
                                O_RESULT OUT BOOLEAN, O_MSG OUT VARCHAR2);

  FUNCTION F_WRITE_ZZH_JOB_INFO(OPFLAG VARCHAR2, JOB_ID NUMBER,
                                I_ISBUSY NUMBER DEFAULT 'null')
    RETURN BOOLEAN;

  FUNCTION F_WRITE_ZZH_TASK_LOG(OPFLAG VARCHAR2, I_ID NUMBER,
                                I_TASK_ID NUMBER, I_JOB_ID NUMBER,
                                I_STATUS NUMBER,
                                I_SQL VARCHAR2 DEFAULT 'null',
                                I_MSG VARCHAR2 DEFAULT 'null') RETURN BOOLEAN;

  /**
    *子线程 执行过程 动态sql，取模方式update分片键字段
    *所有与job捆绑的语句，都通过该存储过程执行
    *add by zhengzhh  2016-11-07
    *I_TASK_ID 任务id
    *I_TABLE_NAME 表名
    *I_PARIMY_COL 表对应主键
    *I_MOD_NUM 取模的参数
    *I_MOD_TOTAL 取模的参数
  */
  PROCEDURE P_UPDATE_SHARDING(I_TASK_ID NUMBER, I_TABLE_NAME VARCHAR2,
                              I_PARIMY_COL VARCHAR2,
                              I_PARTITION VARCHAR2 DEFAULT 'null');

  PROCEDURE P_UPDATE_REL_SHARDING(I_TASK_ID NUMBER, I_TABLE_NAME VARCHAR2,
                                  I_PARIMY_COL VARCHAR2,
                                  I_PARTITION VARCHAR2 DEFAULT 'null');
END PK_MULTI_THREADED_JOB;
/
