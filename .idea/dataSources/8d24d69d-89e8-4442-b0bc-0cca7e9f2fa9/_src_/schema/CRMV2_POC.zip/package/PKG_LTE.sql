CREATE package           PKG_LTE is

  -- Author  : chenjy
  -- Created : 2014/8/22
  -- Purpose : LTE


  /* lte 两级编码映射 */
  PROCEDURE PROC_INSERT_MAP(
                      I_OBJECT_TYPE   IN VARCHAR2,
                      I_OBJECT_NAME IN VARCHAR2,
                      I_CHANNEL_NBR IN VARCHAR2,
                      I_SOURCE_SYSTEM IN VARCHAR2,
                      I_SOURCE_CODE IN VARCHAR2,
                      I_SOURCE_NAME IN VARCHAR2,
                      I_TARGET_SYSTEM IN VARCHAR2,
                      I_TARGET_CODE IN VARCHAR2,
                      I_TARGET_NAME IN VARCHAR2,
                      I_REMARK IN VARCHAR2,
                      I_IS_DEFAULT IN VARCHAR2,
                      I_OBJECT_NBR IN VARCHAR2
                     );

end PKG_LTE;
/
