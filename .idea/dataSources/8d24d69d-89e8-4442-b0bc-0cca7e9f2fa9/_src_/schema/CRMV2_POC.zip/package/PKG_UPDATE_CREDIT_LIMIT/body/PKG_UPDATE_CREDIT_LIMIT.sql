CREATE PACKAGE BODY           PKG_UPDATE_CREDIT_LIMIT is


  FUNCTION INSERT_INTO_LOG(OBJ_ID   IN NUMBER,
                           MSG      IN VARCHAR2,
                           ERR_INFO IN CLOB) RETURN BOOLEAN IS
  BEGIN
    INSERT INTO CREDIT_LIMIT_SYNC_LOG
      (LOG_ID, OBJ_ID, MSG, ERROR_INFO, CREATE_DATE)
    VALUES
      (SEQ_CREDIT_LIMIT_SYNC_LOG_ID.NEXTVAL,
       OBJ_ID,
       MSG,
       ERR_INFO,
       SYSDATE);
    RETURN TRUE;
  END INSERT_INTO_LOG;
  /*更新前先插入历史表
  CREDIT_LIMIT_HIS
  TEMP_CREDIT_LIMIT_HIS
  */
  FUNCTION INSERT_INTO_HIS(V2_CUST_ID IN NUMBER) RETURN BOOLEAN IS
    ERROR_INFO CLOB;
    RET        BOOLEAN;
  BEGIN
    INSERT INTO CREDIT_LIMIT_HIS
      (CREDIT_LIMIT_ID,
       CUST_ID,
       CREDIT_OBJECT,
       CREDIT_OBJECT_ID,
       CREDIT_LIMIT_FEE,
       AVALABLE_CREDIT_LIMIT_FEE,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       CREDIT_LEVEL,
       ATRI_CREDIT_LEVEL,
       EFF_TYPE,
       REMARK,
       HIS_ID)
      SELECT A.CREDIT_LIMIT_ID,
             a.CUST_ID,
             a.CREDIT_OBJECT,
             a.CREDIT_OBJECT_ID,
             a.CREDIT_LIMIT_FEE,
             a.AVALABLE_CREDIT_LIMIT_FEE,
             a.STATUS_CD,
             a.STATUS_DATE,
             a.CREATE_DATE,
             a.UPDATE_DATE,
             a.AREA_ID,
             a.REGION_CD,
             a.UPDATE_STAFF,
             a.CREATE_STAFF,
             a.CREDIT_LEVEL,
             a.ATRI_CREDIT_LEVEL,
             a.EFF_TYPE,
             a.REMARK,
             SEQ_CREDIT_LIMIT_HIS_ID.NEXTVAL
        FROM CREDIT_LIMIT A
       WHERE A.CUST_ID = V2_CUST_ID;
    INSERT INTO TEMP_CREDIT_LIMIT_HIS
      (TEMP_CREDIT_LIMIT,
       CREDIT_LIMIT_ID,
       CREDIT_LIMIT_FEE,
       AVALABLE_CREDIT_LIMIT_FEE,
       CREATE_DATE,
       EFF_DATE,
       EXP_DATE,
       STATUS_CD,
       STATUS_DATE,
       UPDATE_DATE,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       CREDIT_LEVEL,
       MOD_REASON,
       REMARK,
       HIS_ID)
      SELECT a.TEMP_CREDIT_LIMIT,
             a.CREDIT_LIMIT_ID,
             a.CREDIT_LIMIT_FEE,
             a.AVALABLE_CREDIT_LIMIT_FEE,
             a.CREATE_DATE,
             a.EFF_DATE,
             a.EXP_DATE,
             a.STATUS_CD,
             a.STATUS_DATE,
             a.UPDATE_DATE,
             a.AREA_ID,
             a.REGION_CD,
             a.UPDATE_STAFF,
             a.CREATE_STAFF,
             a.CREDIT_LEVEL,
             a.MOD_REASON,
             a.REMARK,
             SEQ_TEMP_CREDIT_LIMIT_HIS_ID.NEXTVAL
        FROM TEMP_CREDIT_LIMIT A, CREDIT_LIMIT B
       WHERE A.CREDIT_LIMIT_ID = B.CREDIT_LIMIT_ID
         AND B.CUST_ID = V2_CUST_ID;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      ERROR_INFO := SQLERRM;
      RET        := INSERT_INTO_LOG(V2_CUST_ID,
                                    '临时授信额度生失效移入历史表',
                                    ERROR_INFO);
      COMMIT;
      RETURN FALSE;
  END INSERT_INTO_HIS;
  --手动失效时，先插入历史表
  FUNCTION INSERT_INTO_CREDIT_LIMIT_HIS(V2_CUST_ID IN NUMBER) RETURN BOOLEAN IS
    ERROR_INFO CLOB;
    RET        BOOLEAN;
  BEGIN
    INSERT INTO CREDIT_LIMIT_HIS
      (CREDIT_LIMIT_ID,
       CUST_ID,
       CREDIT_OBJECT,
       CREDIT_OBJECT_ID,
       CREDIT_LIMIT_FEE,
       AVALABLE_CREDIT_LIMIT_FEE,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       CREDIT_LEVEL,
       ATRI_CREDIT_LEVEL,
       EFF_TYPE,
       REMARK,
       HIS_ID)
      SELECT A.CREDIT_LIMIT_ID,
             a.CUST_ID,
             a.CREDIT_OBJECT,
             a.CREDIT_OBJECT_ID,
             a.CREDIT_LIMIT_FEE,
             a.AVALABLE_CREDIT_LIMIT_FEE,
             a.STATUS_CD,
             a.STATUS_DATE,
             a.CREATE_DATE,
             a.UPDATE_DATE,
             a.AREA_ID,
             a.REGION_CD,
             a.UPDATE_STAFF,
             a.CREATE_STAFF,
             a.CREDIT_LEVEL,
             a.ATRI_CREDIT_LEVEL,
             a.EFF_TYPE,
             a.REMARK,
             SEQ_CREDIT_LIMIT_HIS_ID.NEXTVAL
        FROM CREDIT_LIMIT A
       WHERE A.CUST_ID = V2_CUST_ID;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      ERROR_INFO := SQLERRM;
      RET        := INSERT_INTO_LOG(V2_CUST_ID,
                                    '手动授信额度失效移入历史表',
                                    ERROR_INFO);
      COMMIT;
      RETURN FALSE;
  END INSERT_INTO_CREDIT_LIMIT_HIS;
  --送计费批量接口
  PROCEDURE SYNC_CREDIT_LIMIT_DATA_2_JF(V2_CREDIT_LIMIT_ID IN NUMBER) IS
  BEGIN
    --调用接口过程
    BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CREDIT_LIMIT',
                                                               'CREDIT_LIMIT_ID',
                                                               V2_CREDIT_LIMIT_ID,
                                                               'PKG_UPDATE_CREDIT_LIMIT 修改授信额度',
                                                               '1002',
                                                               'PKG_UPDATE_CREDIT_LIMIT 修改授信额度',
                                                               '',
                                                               '590');

    --2013-03-27 欧确认，计费不需要临时授信
    --如果有临时授信额度，也要送计费
    --SELECT NVL(A.TEMP_CREDIT_LIMIT, 0)
    --  INTO TEMP_CREDIT_LIMIT_ID
    --  FROM TEMP_CREDIT_LIMIT A, CREDIT_LIMIT B
    -- WHERE A.CREDIT_LIMIT_ID = B.CREDIT_LIMIT_ID
    --   AND B.CUST_ID = V2_CUSTID;
    --IF TEMP_CREDIT_LIMIT_ID > 0 THEN
    --  BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('TEMP_CREDIT_LIMIT', 'TEMP_CREDIT_LIMIT', TEMP_CREDIT_LIMIT_ID, 'PKG_UPDATE_CREDIT_LIMIT 修改临时授信额度', '1002', 'PKG_UPDATE_CREDIT_LIMIT 修改临时授信额度', '', '590');
    --END IF;
  END SYNC_CREDIT_LIMIT_DATA_2_JF;

  --临时授信额度生效处理
  PROCEDURE UPDATE_EFF_TEMP_CREDIT_LIMIT IS
    V_LOOPCOUNTER     INTEGER;
    STR_YYYYMMDD      VARCHAR2(8);
    V_CUST_ID         NUMBER(12);
    V_CREDIT_LIMIT_ID NUMBER(12);
    RELT              BOOLEAN;
    RET               BOOLEAN;
    ERROR_INFO        CLOB;
    CURSOR AA IS
      SELECT CUST_ID,
             A.CREDIT_LIMIT_ID,
             A.CREDIT_LEVEL,
             A.CREDIT_LIMIT_FEE,
             A.ATRI_CREDIT_LEVEL,
             B.CREDIT_LEVEL AS TEMP_CREDIT_LEVEL,
             TO_CHAR(B.EFF_DATE, 'YYYYMMDD') EFFDATE,
             TO_CHAR(B.EXP_DATE, 'YYYYMMDD') EXPDATE
        FROM CREDIT_LIMIT A, TEMP_CREDIT_LIMIT B
       WHERE A.CREDIT_LIMIT_ID = B.CREDIT_LIMIT_ID
         AND B.EFF_DATE IS NOT NULL
         AND B.EXP_DATE IS NOT NULL
         AND TO_CHAR(B.EFF_DATE, 'YYYYMMDD') = TO_CHAR(SYSDATE, 'YYYYMMDD');
    --  AND  A.CUST_ID = 37562220;
    -- AND B.EFF_DATE = TO_DATE(STR_YYYYMMDD, 'YYYYMMDD');
  BEGIN
    V_LOOPCOUNTER := 0; --每次循环提交的记录数
    --查询时直接过滤当天的数据
    --SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') INTO STR_YYYYMMDD FROM DUAL;
    FOR REC IN AA LOOP
      V_CUST_ID         := REC.CUST_ID;
      V_CREDIT_LIMIT_ID := REC.CREDIT_LIMIT_ID;
      V_LOOPCOUNTER     := V_LOOPCOUNTER + 1;
      --生效时间生效
      --如果有手动授信额度的话，不做任何更新
      ----1.0没有判断是否有0元档授信额度 2.0增加此判断  经过刘壮飞确认
      --IF REC.EFFDATE >= STR_YYYYMMDD AND
      --优先级 手动授信额度（永久）》临时授信》初始授信，如果有手动，则不允许修改当前授信
      IF REC.ATRI_CREDIT_LEVEL = '590011' OR REC.ATRI_CREDIT_LEVEL = '0' THEN
        BEGIN
          RELT := INSERT_INTO_HIS(REC.CUST_ID);
          UPDATE CREDIT_LIMIT A
             SET A.CREDIT_LEVEL = REC.TEMP_CREDIT_LEVEL,
                 A.UPDATE_DATE  = SYSDATE
           WHERE A.CUST_ID = REC.CUST_ID;
          --1.0此处有写日志
          --送计费批量接口
          SYNC_CREDIT_LIMIT_DATA_2_JF(REC.CREDIT_LIMIT_ID);
        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK;
            ERROR_INFO := SQLERRM;
            RET        := INSERT_INTO_LOG(V_CUST_ID,
                                          '临时授信额度生效处理',
                                          ERROR_INFO);
            COMMIT;
        END;
      END IF;
      IF V_LOOPCOUNTER = 100 THEN
        --满100条数据提交一次
        V_LOOPCOUNTER := 0;
        COMMIT;
      END IF;
    END LOOP;
  END UPDATE_EFF_TEMP_CREDIT_LIMIT; --UPDATE_EFFQUOTA_NEWER

  --临时授信额度失效处理
  PROCEDURE UPDATE_EXP_TEMP_CREDIT_LIMIT IS
    V_LOOPCOUNTER INTEGER;
    STR_YYYYMMDD  VARCHAR2(8);
    V_CUST_ID     NUMBER(12);
    VISVIP        INTEGER;
    ERROR_INFO    CLOB;
    RELT          BOOLEAN;
    RET           BOOLEAN;
    CURSOR AA IS
      SELECT CUST_ID,
             A.CREDIT_LIMIT_ID,
             A.EFF_TYPE,
             A.CREDIT_LEVEL,
             A.CREDIT_LIMIT_FEE,
             A.ATRI_CREDIT_LEVEL,
             B.CREDIT_LEVEL AS TEMP_CREDIT_LEVEL,
             TO_CHAR(B.EFF_DATE, 'YYYYMMDD') EFFDATE,
             TO_CHAR(B.EXP_DATE, 'YYYYMMDD') EXPDATE
        FROM CREDIT_LIMIT A, TEMP_CREDIT_LIMIT B
       WHERE A.CREDIT_LIMIT_ID = B.CREDIT_LIMIT_ID
         AND B.EFF_DATE IS NOT NULL
         AND B.EXP_DATE IS NOT NULL
            --直接过滤当前前一天失效的数据
         AND TO_CHAR(B.EXP_DATE, 'YYYYMMDD') =
             TO_CHAR((SYSDATE - 1), 'YYYYMMDD');
    --AND A.CUST_ID = 37562220;
    -- AND B.EFF_DATE = TO_DATE(STR_YYYYMMDD, 'YYYYMMDD');

  BEGIN
    VISVIP        := 0; --是否VIP
    V_LOOPCOUNTER := 0; --每次循环提交的记录数

    FOR REC IN AA LOOP
      V_CUST_ID     := REC.CUST_ID;
      V_LOOPCOUNTER := V_LOOPCOUNTER + 1;

      --插入历史
      RELT := INSERT_INTO_HIS(REC.CUST_ID);

      IF REC.EFF_TYPE = '0' AND NVL(REC.ATRI_CREDIT_LEVEL, 0) <> 0 AND
         REC.ATRI_CREDIT_LEVEL <> '590011' THEN
        --1、手动授信额度长期有效的且非0或空的 直接更新客户授信额度为手动授信额度

        UPDATE CREDIT_LIMIT A
           SET A.CREDIT_LEVEL = REC.ATRI_CREDIT_LEVEL,
               A.UPDATE_DATE  = SYSDATE
         WHERE A.CUST_ID = REC.CUST_ID;

        UPDATE TEMP_CREDIT_LIMIT A
           SET A.CREDIT_LEVEL = '',
               A.EFF_DATE     = NULL,
               A.EXP_DATE     = NULL,
               A.UPDATE_DATE  = SYSDATE
         WHERE A.CREDIT_LIMIT_ID = REC.CREDIT_LIMIT_ID;

      ELSIF REC.EFF_TYPE = '1' AND NVL(REC.ATRI_CREDIT_LEVEL, 0) <> 0 AND
            REC.ATRI_CREDIT_LEVEL <> '590011' THEN
        --2、手动授信额度为退出VIP失效的，如果为VIP的也更新客户授信额度为手动授信

        --钻石卡，金卡，银卡
        SELECT COUNT(*)
          INTO VISVIP
          FROM CLUB_MEMBER B
         WHERE B.MEMBERSHIP_LEVEL IN ('1000', '1100', '1200')
           AND B.STATUS_CD = '1000'
           AND B.CUST_ID = REC.CUST_ID;

        --若是VIP
        IF VISVIP > 0 THEN
          UPDATE CREDIT_LIMIT A
             SET A.CREDIT_LEVEL = REC.ATRI_CREDIT_LEVEL,
                 A.UPDATE_DATE  = SYSDATE
           WHERE A.CUST_ID = REC.CUST_ID;

          UPDATE TEMP_CREDIT_LIMIT A
             SET A.CREDIT_LEVEL = '',
                 A.EFF_DATE     = NULL,
                 A.EXP_DATE     = NULL,
                 A.UPDATE_DATE  = SYSDATE
           WHERE A.CREDIT_LIMIT_ID = REC.CREDIT_LIMIT_ID;

        ELSE
          --退出VIP手动授信失效
          --已经退出VIP，则更新为初始授信额度
          UPDATE CREDIT_LIMIT A
             SET A.CREDIT_LEVEL = TO_CHAR(REC.CREDIT_LIMIT_FEE),
                 A.UPDATE_DATE  = SYSDATE
           WHERE A.CUST_ID = REC.CUST_ID;

          UPDATE TEMP_CREDIT_LIMIT A
             SET A.CREDIT_LEVEL = '',
                 A.EFF_DATE     = NULL,
                 A.EXP_DATE     = NULL,
                 A.UPDATE_DATE  = SYSDATE
           WHERE A.CREDIT_LIMIT_ID = REC.CREDIT_LIMIT_ID;

        END IF;
        --手动授信额度为空，或没有值时，更新为初始授信额度
      ELSE
        UPDATE CREDIT_LIMIT A
           SET A.CREDIT_LEVEL = TO_CHAR(REC.CREDIT_LIMIT_FEE),
               A.UPDATE_DATE  = SYSDATE
         WHERE A.CUST_ID = REC.CUST_ID;

        UPDATE TEMP_CREDIT_LIMIT A
           SET A.CREDIT_LEVEL = '',
               A.EFF_DATE     = NULL,
               A.EXP_DATE     = NULL,
               A.UPDATE_DATE  = SYSDATE
         WHERE A.CREDIT_LIMIT_ID = REC.CREDIT_LIMIT_ID;
      END IF;

      --1.0此处有写日志

      --送计费批量接口
      SYNC_CREDIT_LIMIT_DATA_2_JF(REC.CREDIT_LIMIT_ID);

      IF V_LOOPCOUNTER = 100 THEN
        --满100条数据提交一次
        V_LOOPCOUNTER := 0;
        COMMIT;
      END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      ERROR_INFO := SQLERRM;
      RET        := INSERT_INTO_LOG(V_CUST_ID,
                                    '临时授信额度失效处理',
                                    ERROR_INFO);

      COMMIT;
  END; -- UPDATE_EXPQUOTA_NEWER
  --手动授信失效处理
  PROCEDURE UPDATE_EXP_CREDIT_LIMIT IS
    V_LOOPCOUNTER INTEGER;
    STR_YYYYMMDD  VARCHAR2(8);
    V_CUST_ID     NUMBER(12);
    VISVIP        INTEGER;
    ERROR_INFO    CLOB;
    RELT          BOOLEAN;
    RET           BOOLEAN;
    TEMP_CREDIT_LEVEL        VARCHAR2(18);
    TEMP_CREDIT_NUM INTEGER;
    CURSOR AA IS
      select cl.cust_id,
             cl.credit_limit_id,
             cl.credit_limit_fee,
             cl.credit_level
        from credit_limit cl
       where cl.eff_type = '0'
         and cl.exp_date is not null
         AND TO_CHAR(cl.EXP_DATE, 'YYYYMMDD') =
             TO_CHAR((SYSDATE - 1), 'YYYYMMDD');
  BEGIN
    V_LOOPCOUNTER := 0; --每次循环提交的记录数

    FOR REC IN AA LOOP
      V_CUST_ID     := REC.CUST_ID;
      V_LOOPCOUNTER := V_LOOPCOUNTER + 1;

      --插入历史
      RELT := INSERT_INTO_CREDIT_LIMIT_HIS(REC.CUST_ID);
      select count(*) into TEMP_CREDIT_NUM from temp_credit_limit tcl where tcl.credit_limit_id = REC.credit_limit_id;
     if TEMP_CREDIT_NUM>0 then
       select tcl.credit_level into TEMP_CREDIT_LEVEL from temp_credit_limit tcl where tcl.credit_limit_id = REC.credit_limit_id;
       IF NVL(TEMP_CREDIT_LEVEL, 0) <> 0 AND TEMP_CREDIT_LEVEL <> '590011' THEN
        UPDATE CREDIT_LIMIT A
           SET A.CREDIT_LEVEL = TEMP_CREDIT_LEVEL,
               A.EFF_DATE     = NULL,
               A.EXP_DATE     = NULL,
               A.UPDATE_DATE  = SYSDATE,
               A.Remark       = '手动授信失效处理：将临时授信额度更新到手动授信额度'
        WHERE A.CUST_ID = REC.CUST_ID;

      ELSE
        UPDATE CREDIT_LIMIT A
           SET A.CREDIT_LEVEL = REC.credit_limit_fee,
               A.EFF_DATE     = NULL,
               A.EXP_DATE     = NULL,
               A.UPDATE_DATE  = SYSDATE,
               A.Remark       = '手动授信失效处理：将初始授信额度更新到手动授信额度'
        WHERE A.CUST_ID = REC.CUST_ID;
      END IF;
     else
        UPDATE CREDIT_LIMIT A
           SET A.CREDIT_LEVEL = REC.credit_limit_fee,
               A.EFF_DATE     = NULL,
               A.EXP_DATE     = NULL,
               A.UPDATE_DATE  = SYSDATE,
               A.Remark       = '手动授信失效处理：将初始授信额度更新到手动授信额度'
        WHERE A.CUST_ID = REC.CUST_ID;
         end if;
      --1.0此处有写日志

      --送计费批量接口
      SYNC_CREDIT_LIMIT_DATA_2_JF(REC.CREDIT_LIMIT_ID);

      IF V_LOOPCOUNTER = 100 THEN
        --满100条数据提交一次
        V_LOOPCOUNTER := 0;
        COMMIT;
      END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      ERROR_INFO := SQLERRM;
      RET        := INSERT_INTO_LOG(V_CUST_ID,
                                    '手动授信额度失效处理',
                                    ERROR_INFO);

      COMMIT;
  END;
  --按临时授信额度生失效时间更新授信额度
  PROCEDURE PROC_MAIN IS
    ERROR_INFO CLOB;
    RET        BOOLEAN;
  BEGIN
    RET := INSERT_INTO_LOG(0, '临时授信额度生失效处理开始', ERROR_INFO);
    UPDATE_EFF_TEMP_CREDIT_LIMIT;
    UPDATE_EXP_TEMP_CREDIT_LIMIT;
    RET := INSERT_INTO_LOG(0, '临时授信额度生失效处理结束', ERROR_INFO);
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      ERROR_INFO := SQLERRM;
      RET        := INSERT_INTO_LOG(0,

                                    '临时授信额度生失效处理异常',
                                    ERROR_INFO);
      COMMIT;
  END PROC_MAIN;

END PKG_UPDATE_CREDIT_LIMIT;
/
