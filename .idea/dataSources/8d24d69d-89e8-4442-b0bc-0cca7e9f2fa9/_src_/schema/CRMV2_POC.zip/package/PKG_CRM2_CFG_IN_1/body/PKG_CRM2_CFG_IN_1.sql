CREATE package body           PKG_CRM2_CFG_IN_1 is
  PROCEDURE p_mdseSpecPriceRelaIn(prod_offer_sql in VARCHAR2,
                                  v_remark       in VARCHAR2,
                                  str_msg        out VARCHAR2) is

    /*
     单接入类基础销售品（排除群组产品对应的销售品）全量输入脚本：
      select a.*
        from prod_offer a, offer_prod_rel b, product c
       where a.status_cd <> '1100'
         and a.offer_sub_type <> 'T02'
         and a.offer_type = '10'
         and a.prod_offer_id = b.prod_offer_id
         and b.product_id = c.product_id
         and b.status_cd <> '1100'
         and c.product_type = '10'
         and c.prod_func_type = '101'
         and c.status_cd <> '1100';
    */
    v_cnt number; --是否存在数据

    v_sel_prod_offer_rela_id number; --销售品关联规格id
    v_status_cd              number; -- 记录状态
    v_prod_offer_a_id        number; -- A端销售品规格id
    v_prod_offer_z_id        number; -- Z端销售品规格id

    v_exp_date      DATE; --记录失效时间
    exist_exp_date  date;
    exist_status_cd number;
    exist_v_area_id number;

    type t_pm_extend_restrict1 is ref cursor;
    c1 t_pm_extend_restrict1;
    r1 prod_offer%rowtype;

    cursor c2 is
      select pm.*
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             mdse_ys_lisy_new                     my,
             mdse_ys_lisy_new                     my1
       where pm.mdse_spec_id = my.id_v1
         and my.id_v2 = v_prod_offer_a_id
         and pm.price_id = my1.id_v1
         and my1.id_v2 = v_prod_offer_z_id
         and pm.cfg_area_id <> 1;
    cursor c3 is
      select id
        from p_area@lk_crmv1
       where super = '1'
      minus
      select pm.cfg_area_id
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             mdse_ys_lisy_new                     my,
             mdse_ys_lisy_new                     my1
       where pm.mdse_spec_id = my.id_v1
         and my.id_v2 = v_prod_offer_a_id
         and pm.price_id = my1.id_v1
         and my1.id_v2 = v_prod_offer_z_id;

  begin

    if (prod_offer_sql is null) then
      str_msg := '请输入2.0销售品规格查询脚本!';
      return;
    end if;
    if (v_remark is null) then
      str_msg := '请输入备注信息!';
      return;
    end if;

    open c1 for prod_offer_sql;
    fetch c1
      into r1;
    while (c1%found) loop
      -- 接入类销售品
      if r1.offer_type = '10' then
        select count(*)
          into v_cnt
          from prod_offer a, offer_prod_rel b, product c
         where a.prod_offer_id = r1.prod_offer_id
           and a.status_cd <> '1100'
           and a.offer_sub_type <> 'T02' -- 非功能销售品
           and a.prod_offer_id = b.prod_offer_id
           and b.product_id = c.product_id
           and b.status_cd <> '1100'
           and c.product_type = '10' -- 原子产品
           and c.prod_func_type = '101' -- 接入类产品
           and c.status_cd <> '1100';

        -- 接入类原子产品对应的销售品
        if v_cnt <> 0 then
          FOR KX IN (select distinct pm.mdse_spec_id,
                                     pm.price_id,
                                     my.id_v2 prod_offer_a_id,
                                     my1.id_v2 prod_offer_z_id,
                                     po.area_id
                       from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                            --price_plan@lk_crmv1                  pp,
                            mdse_ys_lisy_new my,
                            mdse_ys_lisy_new my1,
                            prod_offer       po
                      where pm.state in ('70A', '70I')
                        and pm.mdse_spec_id = my.id_v1
                        and my.id_v2 = r1.prod_offer_id
                        and pm.price_id = my1.id_v1
                        and my1.id_v2 = po.prod_offer_id
                        and po.status_cd <> '1100'
                     --and po.prod_offer_id = 800005825
                     --and r1.prod_offer_id = 800006801
                      order by my.id_v2, po.area_id, my1.id_v2) loop

            v_sel_prod_offer_rela_id := '';
            v_status_cd              := '';
            v_exp_date               := '';

            select count(*)
              into v_cnt
              from prod_offer_rel por
             where por.offer_a_id = r1.prod_offer_id
               and por.offer_z_id = kx.prod_offer_z_id
               and por.relation_type_cd = '100000'
               and area_id = kx.area_id;

            -- 存在与可选包同v_area_id的配置记录
            if v_cnt <> 0 then
              select max(prod_offer_rela_id)
                into v_sel_prod_offer_rela_id
                from prod_offer_rel
               where offer_a_id = r1.prod_offer_id
                 and offer_z_id = kx.prod_offer_z_id
                 and relation_type_cd = '100000'
                 and area_id = kx.area_id;

            end if;
            -- 不存在与可选包同v_area_id的配置记录
            if v_cnt = 0 then
              select count(*)
                into v_cnt
                from prod_offer_rel por
               where por.offer_a_id = r1.prod_offer_id
                 and por.offer_z_id = kx.prod_offer_z_id
                 and por.relation_type_cd = '100000'
                 and area_id <> kx.area_id;
              -- 存在与可选包不同v_area_id的配置记录
              if v_cnt <> 0 then
                select max(prod_offer_rela_id)
                  into v_sel_prod_offer_rela_id
                  from prod_offer_rel
                 where offer_a_id = r1.prod_offer_id
                   and offer_z_id = kx.prod_offer_z_id
                   and relation_type_cd = '100000'
                   and area_id <> kx.area_id;
                /*str_msg := r1.prod_offer_id || ',' || kx.prod_offer_z_id || ',' ||
                v_sel_prod_offer_rela_id || ',' || kx.v_area_id;*/
              end if;
              -- 不存在省级和本地记录
              if v_cnt = 0 then
                v_sel_prod_offer_rela_id := 0;
              end if;
            end if;

            -- 已存在2.0关联关系配置
            if v_sel_prod_offer_rela_id <> 0 then
              select count(*)
                into v_cnt
                from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                     mdse_ys_lisy_new                     my,
                     mdse_ys_lisy_new                     my1
               where pm.mdse_spec_id = my.id_v1
                 and my.id_v2 = r1.prod_offer_id
                 and pm.price_id = my1.id_v1
                 and my1.id_v2 = kx.prod_offer_z_id
                 and pm.state = '70A'
                 and pm.exp_date is null;
              -- 1.0存在有效记录
              if v_cnt <> 0 then
                v_status_cd := '1000';
                v_exp_date  := '';
              end if;
              -- 1.0不存在有效记录
              if v_cnt = 0 then
                v_status_cd := '1000';
                select max(pm.exp_date)
                  into v_exp_date
                  from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                       mdse_ys_lisy_new                     my,
                       mdse_ys_lisy_new                     my1
                 where pm.mdse_spec_id = my.id_v1
                   and my.id_v2 = r1.prod_offer_id
                   and pm.price_id = my1.id_v1
                   and my1.id_v2 = kx.prod_offer_z_id;
                -- 失效时间为空，状态为70I，2.0记录失效时间设置为系统时间
                if v_exp_date is null then
                  v_exp_date := sysdate;
                end if;
              end if;

              select exp_date
                into exist_exp_date
                from prod_offer_rel por
               where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
              select status_cd
                into exist_status_cd
                from prod_offer_rel por
               where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
              select area_id
                into exist_v_area_id
                from prod_offer_rel por
               where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;

              if exist_exp_date <> v_exp_date or
                 exist_status_cd <> v_status_cd or
                 exist_v_area_id <> kx.area_id then
                insert into fjruanh_prod_offer_rel_bak
                  select por.*,
                         sysdate,
                         '修改',
                         v_remark || '(修正2.0已有记录字段值)'
                    from prod_offer_rel por
                   where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
                update prod_offer_rel
                   set exp_date  = v_exp_date,
                       status_cd = v_status_cd,
                       area_id   = kx.area_id
                 where prod_offer_rela_id = v_sel_prod_offer_rela_id;
              else
                insert into fjruanh_prod_offer_rel_bak
                  select por.*, sysdate, '已审核，无改动', v_remark
                    from prod_offer_rel por
                   where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
              end if;

            end if;
            -- 不存在2.0关联关系配置
            if v_sel_prod_offer_rela_id = 0 then
              select SEQ_prod_offer_rel_id.Nextval
                into v_sel_prod_offer_rela_id
                from dual;
              insert into PROD_OFFER_REL
              values
                (v_sel_prod_offer_rela_id,
                 r1.prod_offer_id,
                 kx.prod_offer_z_id,
                 null,
                 '100000',
                 sysdate,
                 null,
                 '1000',
                 sysdate,
                 sysdate,
                 null,
                 null,
                 kx.area_id,
                 null,
                 '104488',
                 '104488',
                 null,
                 null,
                 null,
                 null,
                 null,
                 v_remark || '(新增记录)');

              insert into fjruanh_prod_offer_rel_bak
                select por.*, sysdate, '新增', v_remark || '(新增记录)'
                  from prod_offer_rel por
                 where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
            end if;

            v_prod_offer_a_id := r1.prod_offer_id;
            v_prod_offer_z_id := kx.prod_offer_z_id;

            -- 处理obj_area_rela表 (省级可选包)
            if kx.area_id = 1 then
              -- 1.0存在有效记录
              if v_exp_date is null then
                -- 适用区域是全省9地市，可不添加适用区域
                select count(*)
                  into v_cnt
                  from (select id
                          from p_area@lk_crmv1
                         where super = 1
                        minus
                        select pm.cfg_area_id
                          from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                               mdse_ys_lisy_new                     my,
                               mdse_ys_lisy_new                     my1
                         where pm.mdse_spec_id = my.id_v1
                           and my.id_v2 = v_prod_offer_a_id
                           and pm.price_id = my1.id_v1
                           and my1.id_v2 = v_prod_offer_z_id
                           and state = '70A'
                           and (exp_date is null or exp_date > sysdate));

                if v_cnt <> 0 then
                  for rec in c2 loop
                    -- 1.0有效记录处理适用区域，失效记录不处理
                    if rec.state = '70A' and
                       (rec.exp_date is null or rec.exp_date > sysdate) then
                      select count(*)
                        into v_cnt
                        from obj_area_rela
                       where obj_id = v_sel_prod_offer_rela_id
                         and rela_area_id = rec.cfg_area_id;

                      if v_cnt <> 0 then
                        select count(*)
                          into v_cnt
                          from obj_area_rela
                         where obj_id = v_sel_prod_offer_rela_id
                           and rela_area_id = rec.cfg_area_id
                           and status_cd = '1000';
                        if v_cnt = 0 then
                          update obj_area_rela
                             set status_cd = '1000',
                                 remark    = remark || ';' || v_remark
                           where obj_id = v_sel_prod_offer_rela_id
                             and rela_area_id = rec.cfg_area_id
                             and status_cd <> '1000';
                        end if;
                      end if;

                      if v_cnt = 0 then
                        insert into obj_area_rela
                        values
                          (seq_obj_area_rela_id.nextval,
                           '51',
                           v_sel_prod_offer_rela_id,
                           rec.cfg_area_id,
                           '10',
                           1,
                           1,
                           '1000',
                           sysdate,
                           sysdate,
                           '104488',
                           '',
                           '104488',
                           v_remark);
                      end if;
                    end if;
                  end loop;

                  -- 处理本地没有配置关联时是否配置适用区域
                  select count(*)
                    into v_cnt
                    from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                   where mdse_spec_id = kx.mdse_spec_id
                        --and price_id = kx.price_id
                     and cfg_area_id <> 1;
                  -- kx销售品1.0存在本地关联配置；
                  -- 如果不存在任何本地的配置（如“天翼”），可不配置适用区域
                  if v_cnt <> 0 then

                    -- 处理本地没有配置关联时是否配置适用区域
                    for rec1 in c3 loop
                      select count(*)
                        into v_cnt
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                       where mdse_spec_id = kx.mdse_spec_id
                         and cfg_area_id = rec1.id;
                      -- 销售品本地没有配置关联
                      if v_cnt = 0 then
                        select count(*)
                          into v_cnt
                          from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                         where mdse_spec_id = kx.mdse_spec_id
                           and price_id = kx.price_id
                           and cfg_area_id = 1;
                        -- 省级存在关联
                        if v_cnt <> 0 then
                          insert into obj_area_rela
                          values
                            (seq_obj_area_rela_id.nextval,
                             '51',
                             v_sel_prod_offer_rela_id,
                             rec1.id,
                             '10',
                             1,
                             1,
                             '1000',
                             sysdate,
                             sysdate,
                             '104488',
                             '',
                             '104488',
                             v_remark);
                        end if;
                      end if;
                    end loop;
                  end if;
                end if;
              end if;
              -- 1.0不存在有效记录
              if v_exp_date is not null then
                -- 适用区域是全省9地市，可不添加适用区域
                select count(*)
                  into v_cnt
                  from (select id
                          from p_area@lk_crmv1
                         where super = 1
                        minus
                        select pm.cfg_area_id
                          from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                               mdse_ys_lisy_new                     my,
                               mdse_ys_lisy_new                     my1
                         where pm.mdse_spec_id = my.id_v1
                           and my.id_v2 = v_prod_offer_a_id
                           and pm.price_id = my1.id_v1
                           and my1.id_v2 = v_prod_offer_z_id);

                if v_cnt <> 0 then
                  for rec in c2 loop
                    -- 所有1.0记录都处理适用区域
                    select count(*)
                      into v_cnt
                      from obj_area_rela
                     where obj_id = v_sel_prod_offer_rela_id
                       and rela_area_id = rec.cfg_area_id;

                    if v_cnt <> 0 then
                      select count(*)
                        into v_cnt
                        from obj_area_rela
                       where obj_id = v_sel_prod_offer_rela_id
                         and rela_area_id = rec.cfg_area_id
                         and status_cd = '1000';
                      if v_cnt = 0 then
                        update obj_area_rela
                           set status_cd = '1000',
                               remark    = remark || ';' || v_remark
                         where obj_id = v_sel_prod_offer_rela_id
                           and rela_area_id = rec.cfg_area_id
                           and status_cd <> '1000';
                      end if;
                    end if;

                    if v_cnt = 0 then
                      insert into obj_area_rela
                      values
                        (seq_obj_area_rela_id.nextval,
                         '51',
                         v_sel_prod_offer_rela_id,
                         rec.cfg_area_id,
                         '10',
                         1,
                         1,
                         '1000',
                         sysdate,
                         sysdate,
                         '104488',
                         '',
                         '1044881',
                         v_remark);
                    end if;
                  end loop;
                  -- 处理本地没有配置关联时是否配置适用区域
                  select count(*)
                    into v_cnt
                    from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                   where mdse_spec_id = kx.mdse_spec_id
                        --and price_id = kx.price_id
                     and cfg_area_id <> 1;
                  -- kx销售品1.0存在本地关联配置；
                  -- 如果不存在任何本地的配置（如“天翼”），可不配置适用区域
                  if v_cnt <> 0 then
                    for rec1 in c3 loop
                      select count(*)
                        into v_cnt
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                       where mdse_spec_id = kx.mdse_spec_id
                         and cfg_area_id = rec1.id;
                      -- 销售品本地没有配置关联
                      if v_cnt = 0 then
                        select count(*)
                          into v_cnt
                          from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                         where mdse_spec_id = kx.mdse_spec_id
                           and price_id = kx.price_id
                           and cfg_area_id = 1;
                        -- 省级存在关联
                        if v_cnt <> 0 then
                          insert into obj_area_rela
                          values
                            (seq_obj_area_rela_id.nextval,
                             '51',
                             v_sel_prod_offer_rela_id,
                             rec1.id,
                             '10',
                             1,
                             1,
                             '1000',
                             sysdate,
                             sysdate,
                             '104488',
                             '',
                             '1044881',
                             v_remark);
                        end if;
                      end if;
                    end loop;
                  end if;
                end if;
              end if;
            end if;

            -- 处理obj_area_rela表 (本地可选包，删除适用区域配置)
            if kx.area_id <> 1 then
              delete obj_area_rela where obj_id = v_sel_prod_offer_rela_id;
            end if;

            update prod_offer_rel_restrict
               set update_staff = prod_offer_rel_id
             where prod_offer_rel_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update prod_offer_rel_restrict
               set prod_offer_rel_id = v_sel_prod_offer_rela_id
             where prod_offer_rel_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update OFFER_REL_RESTRICT_PROD
               set update_staff = prod_offer_rela_id
             where prod_offer_rela_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update OFFER_REL_RESTRICT_PROD
               set prod_offer_rela_id = v_sel_prod_offer_rela_id
             where prod_offer_rela_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update PROD_REL_OFFER_RESTRICT
               set update_staff = prod_offer_rela_id
             where prod_offer_rela_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update PROD_REL_OFFER_RESTRICT
               set prod_offer_rela_id = v_sel_prod_offer_rela_id
             where prod_offer_rela_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update obj_rel_value_restrict
               set remark = rela_id
             where rela_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update obj_rel_value_restrict
               set rela_id = v_sel_prod_offer_rela_id
             where rela_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update obj_rel_cfg
               set remark = obj_id
             where obj_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update obj_rel_cfg
               set obj_id = v_sel_prod_offer_rela_id
             where obj_id in
                   (select prod_offer_rela_id
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update attr_group_item
               set remark = attr_value
             where attr_value in
                   (select to_char(prod_offer_rela_id)
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            update attr_group_item
               set attr_value = to_char(v_sel_prod_offer_rela_id)
             where attr_value in
                   (select to_char(prod_offer_rela_id)
                      from prod_offer_rel
                     where offer_a_id = v_prod_offer_a_id
                       and offer_z_id = v_prod_offer_z_id
                       and relation_type_cd = '100000'
                       and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

            insert into fjruanh_prod_offer_rel_bak
              select por.*,
                     sysdate,
                     '删除',
                     v_remark || '(删除2.0已有记录)'
                from prod_offer_rel por
               where por.offer_a_id = r1.prod_offer_id
                 and por.offer_z_id = kx.prod_offer_z_id
                 and por.relation_type_cd = '100000'
                 and por.prod_offer_rela_id <> v_sel_prod_offer_rela_id;

            delete prod_offer_rel por
             where por.offer_a_id = r1.prod_offer_id
               and por.offer_z_id = kx.prod_offer_z_id
               and por.relation_type_cd = '100000'
               and por.prod_offer_rela_id <> v_sel_prod_offer_rela_id;

          end loop;
        end if;
      end if;
      fetch c1
        into r1;
    end loop;
    close c1;
  end;

  PROCEDURE p_mdseSpecCDMAPriceRelaIn(prod_offer_sql in VARCHAR2,
                                      v_remark       in VARCHAR2,
                                      str_msg        out VARCHAR2) is

    /*
    全量输入脚本
    select *
           from prod_offer a
          where a.status_cd <> '1100'
            and a.offer_sub_type <> 'T02'
            and a.offer_type = '11'
            and a.prod_offer_name not like '%e%'
            and prod_offer_id not in
                (800001798, 800006844);
     */
    v_cnt number; --是否存在数据
    -- v_cnt1                   number; --是否存在数据
    v_sel_prod_offer_rela_id number; --销售品关联规格id
    v_status_cd              number; -- 记录状态
    v_prod_offer_a_id        number; -- A端销售品规格id
    v_prod_offer_z_id        number; -- Z端销售品规格id

    v_exp_date      DATE; --记录失效时间
    exist_exp_date  date;
    exist_status_cd number;
    exist_v_area_id number;

    type t_pm_extend_restrict1 is ref cursor;
    c1 t_pm_extend_restrict1;
    r1 prod_offer%rowtype;

    cursor c2 is
      select pm.*
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             mdse_ys_lisy_new                     my,
             mdse_ys_lisy_new                     my1
       where pm.mdse_spec_id = my.id_v1
         and my.id_v2 = v_prod_offer_a_id
         and pm.price_id = my1.id_v1
         and my1.id_v2 = v_prod_offer_z_id
         and pm.cfg_area_id <> 1;
    cursor c3 is
      select id
        from p_area@lk_crmv1
       where super = '1'
      minus
      select pm.cfg_area_id
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             mdse_ys_lisy_new                     my,
             mdse_ys_lisy_new                     my1
       where pm.mdse_spec_id = my.id_v1
         and my.id_v2 = v_prod_offer_a_id
         and pm.price_id = my1.id_v1
         and my1.id_v2 = v_prod_offer_z_id;

  begin

    if (prod_offer_sql is null) then
      str_msg := '请输入2.0销售品规格查询脚本!';
      return;
    end if;
    if (v_remark is null) then
      str_msg := '请输入备注信息!';
      return;
    end if;

    open c1 for prod_offer_sql;
    fetch c1
      into r1;
    while (c1%found) loop

      -- 接入类销售品
      if r1.offer_type = '11' and r1.prod_offer_name not like '%e%' then
        select count(*)
          into v_cnt
          from prod_offer a, offer_prod_rel b, product c
         where a.prod_offer_id = r1.prod_offer_id
           and a.status_cd <> '1100'
           and a.offer_sub_type <> 'T02' -- 非功能销售品
           and a.prod_offer_id = b.prod_offer_id
           and b.product_id = c.product_id
           and b.status_cd <> '1100'
           and c.product_type = '10' -- 原子产品
           and c.prod_func_type = '101' -- 接入类产品
           and c.status_cd <> '1100';

        -- 接入类原子产品对应的销售品
        if v_cnt <> 0 then
          FOR KX IN (select distinct pm.mdse_spec_id,
                                     pm.price_id,
                                     --my.id_v2 prod_offer_a_id,
                                     my1.id_v2 prod_offer_z_id,
                                     po.area_id
                       from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                            --price_plan@lk_crmv1                  pp,
                            --mdse_ys_lisy_new my,
                            mdse_ys_lisy_new my1,
                            prod_offer       po
                      where pm.state in ('70A', '70I')
                        and pm.mdse_spec_id = 610290109 --my.id_v1
                           --and my.id_v2 = r1.prod_offer_id
                        and pm.price_id = my1.id_v1
                        and my1.id_v2 = po.prod_offer_id
                        and po.status_cd <> '1100'
                        and po.offer_type <> '11'
                        and po.offer_sub_type = 'T04'
                     --and po.prod_offer_id = 800011613
                     --and r1.prod_offer_id = 800006801
                      order by /*my.id_v2,*/ po.area_id, my1.id_v2) loop

            -- 判断是否存在互斥关系，存在则不处理
            select count(*)
              into v_cnt
              from mdse_spec_rela@lk_crmv1
             where rela_type = '102'
               and state = '70A'
               and (mdse_spec_ida in
                   (select id_v1
                       from mdse_ys_lisy_new
                      where id_v2 = r1.prod_offer_id) and
                   mdse_spec_idb = kx.price_id)
                or (mdse_spec_idb in
                   (select id_v1
                       from mdse_ys_lisy_new
                      where id_v2 = r1.prod_offer_id) and
                   mdse_spec_ida = kx.price_id);

            if v_cnt = 0 then
              v_sel_prod_offer_rela_id := '';
              v_status_cd              := '';
              v_exp_date               := '';

              select count(*)
                into v_cnt
                from prod_offer_rel por
               where por.offer_a_id = r1.prod_offer_id
                 and por.offer_z_id = kx.prod_offer_z_id
                 and por.relation_type_cd = '100000'
                 and area_id = kx.area_id;

              -- 存在与可选包同v_area_id的配置记录
              if v_cnt <> 0 then
                select max(prod_offer_rela_id)
                  into v_sel_prod_offer_rela_id
                  from prod_offer_rel
                 where offer_a_id = r1.prod_offer_id
                   and offer_z_id = kx.prod_offer_z_id
                   and relation_type_cd = '100000'
                   and area_id = kx.area_id;
              end if;

              -- 不存在省级和本地记录
              if v_cnt = 0 then
                v_sel_prod_offer_rela_id := 0;
              end if;
              /*
              -- 不存在与可选包同v_area_id的配置记录
              if v_cnt = 0 then
                select count(*)
                  into v_cnt
                  from prod_offer_rel por
                 where por.offer_a_id = r1.prod_offer_id
                   and por.offer_z_id = kx.prod_offer_z_id
                   and por.relation_type_cd = '100000'
                   and v_area_id <> kx.area_id;
                -- 存在与可选包不同v_area_id的配置记录
                if v_cnt <> 0 then
                  select max(prod_offer_rela_id)
                    into v_sel_prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = r1.prod_offer_id
                     and offer_z_id = kx.prod_offer_z_id
                     and relation_type_cd = '100000'
                     and v_area_id <> kx.area_id;
                end if;
                -- 不存在省级和本地记录
                if v_cnt = 0 then
                  v_sel_prod_offer_rela_id := 0;
                end if;
              end if;
              */

              -- 已存在2.0关联关系配置
              if v_sel_prod_offer_rela_id <> 0 then
                --str_msg:=v_sel_prod_offer_rela_id;
                select count(*)
                  into v_cnt
                  from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                       mdse_ys_lisy_new                     my,
                       mdse_ys_lisy_new                     my1
                 where pm.mdse_spec_id = my.id_v1
                   and my.id_v2 = r1.prod_offer_id
                   and pm.price_id = my1.id_v1
                   and my1.id_v2 = kx.prod_offer_z_id
                   and pm.state = '70A'
                   and pm.exp_date is null;
                -- 1.0存在有效记录
                if v_cnt <> 0 then
                  v_status_cd := '1000';
                  v_exp_date  := '';
                end if;
                -- 1.0不存在有效记录
                if v_cnt = 0 then
                  v_status_cd := '1000';
                  select max(pm.exp_date)
                    into v_exp_date
                    from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                         mdse_ys_lisy_new                     my,
                         mdse_ys_lisy_new                     my1
                   where pm.mdse_spec_id = my.id_v1
                     and my.id_v2 = r1.prod_offer_id
                     and pm.price_id = my1.id_v1
                     and my1.id_v2 = kx.prod_offer_z_id;
                  -- 失效时间为空，状态为70I，2.0记录失效时间设置为系统时间
                  if v_exp_date is null then
                    v_exp_date := sysdate;
                  end if;
                end if;

                select exp_date
                  into exist_exp_date
                  from prod_offer_rel por
                 where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
                select status_cd
                  into exist_status_cd
                  from prod_offer_rel por
                 where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
                select area_id
                  into exist_v_area_id
                  from prod_offer_rel por
                 where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;

                if exist_exp_date <> v_exp_date or
                   exist_status_cd <> v_status_cd or
                   exist_v_area_id <> kx.area_id then
                  insert into fjruanh_prod_offer_rel_bak
                    select por.*,
                           sysdate,
                           '修改',
                           v_remark || '(修正2.0已有记录字段值)'
                      from prod_offer_rel por
                     where por.prod_offer_rela_id =
                           v_sel_prod_offer_rela_id;
                  update prod_offer_rel
                     set exp_date  = v_exp_date,
                         status_cd = v_status_cd,
                         area_id   = kx.area_id
                   where prod_offer_rela_id = v_sel_prod_offer_rela_id;
                else
                  insert into fjruanh_prod_offer_rel_bak
                    select por.*, sysdate, '已审核，无改动', v_remark
                      from prod_offer_rel por
                     where por.prod_offer_rela_id =
                           v_sel_prod_offer_rela_id;
                end if;

              end if;
              -- 不存在2.0关联关系配置
              if v_sel_prod_offer_rela_id = 0 then
                select SEQ_prod_offer_rel_id.Nextval
                  into v_sel_prod_offer_rela_id
                  from dual;
                insert into PROD_OFFER_REL
                values
                  (v_sel_prod_offer_rela_id,
                   r1.prod_offer_id,
                   kx.prod_offer_z_id,
                   null,
                   '100000',
                   sysdate,
                   null,
                   '1000',
                   sysdate,
                   sysdate,
                   null,
                   null,
                   kx.area_id,
                   null,
                   '104488',
                   '104488',
                   null,
                   null,
                   null,
                   null,
                   null,
                   v_remark || '(新增记录)');

                insert into fjruanh_prod_offer_rel_bak
                  select por.*, sysdate, '新增', v_remark || '(新增记录)'
                    from prod_offer_rel por
                   where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
              end if;

              v_prod_offer_a_id := r1.prod_offer_id;
              v_prod_offer_z_id := kx.prod_offer_z_id;
              /*
                -- 处理obj_area_rela表 (省级可选包)
                if kx.area_id = 1 then
                  -- 1.0存在有效记录
                  if v_exp_date is null then
                    -- 适用区域是全省9地市，可不添加适用区域
                    select count(*)
                      into v_cnt
                      from (select id
                              from p_area@lk_crmv1
                             where super = 1
                            minus
                            select pm.cfg_area_id
                              from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                                   mdse_ys_lisy_new                     my,
                                   mdse_ys_lisy_new                     my1
                             where pm.mdse_spec_id = my.id_v1
                               and my.id_v2 = v_prod_offer_a_id
                               and pm.price_id = my1.id_v1
                               and my1.id_v2 = v_prod_offer_z_id
                               and state = '70A'
                               and (exp_date is null or exp_date > sysdate));

                    if v_cnt <> 0 then
                      for rec in c2 loop
                        -- 1.0有效记录处理适用区域，失效记录不处理
                        if rec.state = '70A' and
                           (rec.exp_date is null or rec.exp_date > sysdate) then
                          select count(*)
                            into v_cnt
                            from obj_area_rela
                           where obj_id = v_sel_prod_offer_rela_id
                             and rela_v_area_id = rec.cfg_area_id;

                          if v_cnt <> 0 then
                            select count(*)
                              into v_cnt
                              from obj_area_rela
                             where obj_id = v_sel_prod_offer_rela_id
                               and rela_v_area_id = rec.cfg_area_id
                               and status_cd = '1000';
                            if v_cnt = 0 then
                              update obj_area_rela
                                 set status_cd = '1000',
                                     remark    = remark || ';' || v_remark
                               where obj_id = v_sel_prod_offer_rela_id
                                 and rela_v_area_id = rec.cfg_area_id
                                 and status_cd <> '1000';
                            end if;
                          end if;

                          if v_cnt = 0 then
                            insert into obj_area_rela
                            values
                              (seq_obj_area_rela_id.nextval,
                               '51',
                               v_sel_prod_offer_rela_id,
                               rec.cfg_area_id,
                               '10',
                               1,
                               1,
                               '1000',
                               sysdate,
                               sysdate,
                               '104488',
                               '',
                               '104488',
                               v_remark);
                          end if;
                        end if;
                      end loop;

                      -- 处理本地没有配置关联时是否配置适用区域
                      select count(*)
                        into v_cnt
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                       where mdse_spec_id = kx.mdse_spec_id
                            --and price_id = kx.price_id
                         and cfg_area_id <> 1;
                      -- kx销售品1.0存在本地关联配置；
                      -- 如果不存在任何本地的配置（如“天翼”），可不配置适用区域
                      if v_cnt <> 0 then
                        for rec1 in c3 loop
                          select count(*)
                            into v_cnt
                            from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                           where mdse_spec_id = kx.mdse_spec_id
                             and cfg_area_id = rec1.id;
                          -- 销售品本地没有配置关联
                          if v_cnt = 0 then
                            select count(*)
                              into v_cnt
                              from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                             where mdse_spec_id = kx.mdse_spec_id
                               and price_id = kx.price_id
                               and cfg_area_id = 1;
                            -- 省级存在关联
                            if v_cnt <> 0 then
                              insert into obj_area_rela
                              values
                                (seq_obj_area_rela_id.nextval,
                                 '51',
                                 v_sel_prod_offer_rela_id,
                                 rec1.id,
                                 '10',
                                 1,
                                 1,
                                 '1000',
                                 sysdate,
                                 sysdate,
                                 '104488',
                                 '',
                                 '104488',
                                 v_remark);
                            end if;
                          end if;
                        end loop;
                      end if;
                    end if;
                  end if;
                  -- 1.0不存在有效记录
                  if v_exp_date is not null then
                    -- 适用区域是全省9地市，可不添加适用区域
                    select count(*)
                      into v_cnt
                      from (select id
                              from p_area@lk_crmv1
                             where super = 1
                            minus
                            select pm.cfg_area_id
                              from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                                   mdse_ys_lisy_new                     my,
                                   mdse_ys_lisy_new                     my1
                             where pm.mdse_spec_id = my.id_v1
                               and my.id_v2 = v_prod_offer_a_id
                               and pm.price_id = my1.id_v1
                               and my1.id_v2 = v_prod_offer_z_id);

                    if v_cnt <> 0 then
                      for rec in c2 loop
                        -- 所有1.0记录都处理适用区域
                        select count(*)
                          into v_cnt
                          from obj_area_rela
                         where obj_id = v_sel_prod_offer_rela_id
                           and rela_v_area_id = rec.cfg_area_id;

                        if v_cnt <> 0 then
                          select count(*)
                            into v_cnt
                            from obj_area_rela
                           where obj_id = v_sel_prod_offer_rela_id
                             and rela_v_area_id = rec.cfg_area_id
                             and status_cd = '1000';
                          if v_cnt = 0 then
                            update obj_area_rela
                               set status_cd = '1000',
                                   remark    = remark || ';' || v_remark
                             where obj_id = v_sel_prod_offer_rela_id
                               and rela_v_area_id = rec.cfg_area_id
                               and status_cd <> '1000';
                          end if;
                        end if;

                        if v_cnt = 0 then
                          insert into obj_area_rela
                          values
                            (seq_obj_area_rela_id.nextval,
                             '51',
                             v_sel_prod_offer_rela_id,
                             rec.cfg_area_id,
                             '10',
                             1,
                             1,
                             '1000',
                             sysdate,
                             sysdate,
                             '104488',
                             '',
                             '1044881',
                             v_remark);
                        end if;
                      end loop;
                      -- 处理本地没有配置关联时是否配置适用区域
                      select count(*)
                        into v_cnt
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                       where mdse_spec_id = kx.mdse_spec_id
                            --and price_id = kx.price_id
                         and cfg_area_id <> 1;
                      -- kx销售品1.0存在本地关联配置；
                      -- 如果不存在任何本地的配置（如“天翼”），可不配置适用区域
                      if v_cnt <> 0 then
                        for rec1 in c3 loop
                          select count(*)
                            into v_cnt
                            from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                           where mdse_spec_id = kx.mdse_spec_id
                             and cfg_area_id = rec1.id;
                          -- 销售品本地没有配置关联
                          if v_cnt = 0 then
                            select count(*)
                              into v_cnt
                              from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                             where mdse_spec_id = kx.mdse_spec_id
                               and price_id = kx.price_id
                               and cfg_area_id = 1;
                            -- 省级存在关联
                            if v_cnt <> 0 then
                              insert into obj_area_rela
                              values
                                (seq_obj_area_rela_id.nextval,
                                 '51',
                                 v_sel_prod_offer_rela_id,
                                 rec1.id,
                                 '10',
                                 1,
                                 1,
                                 '1000',
                                 sysdate,
                                 sysdate,
                                 '104488',
                                 '',
                                 '1044881',
                                 v_remark);
                            end if;
                          end if;
                        end loop;
                      end if;
                    end if;
                  end if;
                end if;

                -- 处理obj_area_rela表 (本地可选包，删除适用区域配置)
                if kx.area_id <> 1 then
                  delete obj_area_rela where obj_id = v_sel_prod_offer_rela_id;
                end if;
              */
              update prod_offer_rel_restrict
                 set update_staff = prod_offer_rel_id
               where prod_offer_rel_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update prod_offer_rel_restrict
                 set prod_offer_rel_id = v_sel_prod_offer_rela_id
               where prod_offer_rel_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update OFFER_REL_RESTRICT_PROD
                 set update_staff = prod_offer_rela_id
               where prod_offer_rela_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update OFFER_REL_RESTRICT_PROD
                 set prod_offer_rela_id = v_sel_prod_offer_rela_id
               where prod_offer_rela_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update PROD_REL_OFFER_RESTRICT
                 set update_staff = prod_offer_rela_id
               where prod_offer_rela_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update PROD_REL_OFFER_RESTRICT
                 set prod_offer_rela_id = v_sel_prod_offer_rela_id
               where prod_offer_rela_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update obj_rel_value_restrict
                 set remark = rela_id
               where rela_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update obj_rel_value_restrict
                 set rela_id = v_sel_prod_offer_rela_id
               where rela_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update obj_rel_cfg
                 set remark = obj_id
               where obj_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update obj_rel_cfg
                 set obj_id = v_sel_prod_offer_rela_id
               where obj_id in
                     (select prod_offer_rela_id
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update attr_group_item
                 set remark = attr_value
               where attr_value in
                     (select to_char(prod_offer_rela_id)
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              update attr_group_item
                 set attr_value = to_char(v_sel_prod_offer_rela_id)
               where attr_value in
                     (select to_char(prod_offer_rela_id)
                        from prod_offer_rel
                       where offer_a_id = v_prod_offer_a_id
                         and offer_z_id = v_prod_offer_z_id
                         and relation_type_cd = '100000'
                         and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

              insert into fjruanh_prod_offer_rel_bak
                select por.*,
                       sysdate,
                       '删除',
                       v_remark || '(删除2.0已有记录)'
                  from prod_offer_rel por
                 where por.offer_a_id = r1.prod_offer_id
                   and por.offer_z_id = kx.prod_offer_z_id
                   and por.relation_type_cd = '100000'
                   and por.prod_offer_rela_id <> v_sel_prod_offer_rela_id;

              delete prod_offer_rel por
               where por.offer_a_id = r1.prod_offer_id
                 and por.offer_z_id = kx.prod_offer_z_id
                 and por.relation_type_cd = '100000'
                 and por.prod_offer_rela_id <> v_sel_prod_offer_rela_id;
            end if;
          end loop;
        end if;
      end if;
      fetch c1
        into r1;
    end loop;
    close c1;
  end;

  PROCEDURE p_eHomePriceRelaIn(prod_offer_sql in VARCHAR2,
                               v_remark       in VARCHAR2,
                               str_msg        out VARCHAR2) is

    /*
     e家构成的销售品关联全量输入脚本：
    select *
      from prod_offer
     where offer_type = '11'
       and (prod_offer_name like '%e%' or
           prod_offer_id in (800001798, 800006844))
       and status_cd <> '1100'
       and offer_sub_type = 'T01';
    */

    /*
    offer_rel_restrict_prod表update_staff的更新：
    1、1044881：表示销售品关联关系存在适用角色配置，但该限制记录要取消；
    2、1044882：表示销售品关联关系无需配置适用角色，删除该限制记录；
    */
    v_cnt  number; --是否存在数据
    v_cnt1 number;
    v_cnt2 number;

    v_sel_prod_offer_rela_id number; --销售品关联规格id
    v_status_cd              number; -- 记录状态
    v_prod_offer_a_id        number; -- A端销售品规格id
    v_prod_offer_z_id        number; -- Z端销售品规格id
    v_mdse_spec_id           number; -- 1.0e家规格id
    v_price_id               number; -- 1.0套餐规格id
    v_product_id             number;

    v_area_id  number;
    v_group_id number;

    v_exp_date      DATE; --记录失效时间
    exist_exp_date  date;
    exist_status_cd number;
    exist_v_area_id number;

    type t_pm_extend_restrict1 is ref cursor;
    c1 t_pm_extend_restrict1;
    r1 prod_offer%rowtype;

    cursor c2 is
    -- 1.0有效记录
      select pm.*
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             prefer_mdse_spec_rela@lk_crmv1       pms,
             mdse_ys_lisy_new                     my,
             mdse_ys_lisy_new                     my1
       where pm.rela_mdse_id = pms.rela_id
         and pms.prefer_spec_id = my.id_v1
         and my.id_v2 =v_prod_offer_a_id  --800006801
         and pm.price_id = my1.id_v1
         and my1.id_v2 = v_prod_offer_z_id  -- 800010897
         and pm.cfg_area_id <> 1
         and pm.state = '70A'
         and (pm.exp_date is null or pm.exp_date > sysdate)
         and pms.rela_id in
             (select role_id_v1 from fjruanh_ehome_role_mapping);

    cursor c3 is
    -- 1.0没有配置或只存在70X记录
      select id
        from p_area@lk_crmv1
       where super = '1'
      minus
      -- 1.0有效和无效的记录
      select pm.cfg_area_id
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             PREFER_MDSE_SPEC_RELA@lk_crmv1       pms,
             mdse_ys_lisy_new                     my,
             mdse_ys_lisy_new                     my1
       where pm.rela_mdse_id = pms.rela_id
         and pms.prefer_spec_id = my.id_v1
         and my.id_v2 = v_prod_offer_a_id
         and pm.price_id = my1.id_v1
         and my1.id_v2 = v_prod_offer_z_id
         and pm.state in ('70A', '70I')
            -- and (pm.exp_date is null or pm.exp_date > sysdate)
         and pms.rela_id in
             (select role_id_v1 from fjruanh_ehome_role_mapping);
    cursor c4 is
      select distinct b.ehome_group
        from crm.fjruanh_ehome_price_group@lk_crmv1 a,
             fjruanh_ehome_role_mapping             b
       where a.price_id = v_price_id
         and a.group_id = b.ehome_group
         and b.id_v2 = v_prod_offer_a_id
         and b.role_name_v1 = '基础包'
      union
      select distinct ehome_group
        from fjruanh_ehome_role_mapping
       where role_id_v1 in
             (select rela_mdse_id
                from prefer_mdse_price_spec_rela@lk_crmv1
               where price_id = v_price_id
                 and rela_mdse_id in (select rela_id
                                        from prefer_mdse_spec_rela@lk_crmv1
                                       where prefer_spec_id = v_mdse_spec_id
                                         and state <> '70X'
                                         and name <> '基础包')
                 and state in ('70A', '70I')
                 and cfg_area_id = v_area_id)
         and id_v2 = v_prod_offer_a_id;
    cursor c5 is
      select distinct b.id_v2, b.role_id_v2, pm.state, pm.exp_date
        from crm.fjruanh_ehome_price_group@lk_crmv1 a,
             fjruanh_ehome_role_mapping             b,
             PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1   pm
       where a.price_id = v_price_id
         and a.group_id = b.ehome_group
         and b.id_v2 = v_prod_offer_a_id
         and b.role_name_v1 = '基础包'
         and a.price_id = pm.price_id
         and pm.rela_mdse_id = b.role_id_v1
         and pm.cfg_area_id = v_area_id
         and pm.state in ('70A', '70I')
         and b.ehome_group = v_group_id
      union
      select distinct erm.id_v2, erm.role_id_v2, pm.state, pm.exp_date
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             prefer_mdse_spec_rela@lk_crmv1       pms,
             fjruanh_ehome_role_mapping           erm
       where pm.rela_mdse_id = pms.rela_id
         and pms.prefer_spec_id = v_mdse_spec_id
         and pm.price_id = v_price_id
         and pm.cfg_area_id = v_area_id
         and pm.state in ('70A', '70I')
         and pm.rela_mdse_id = erm.role_id_v1
         and erm.role_name_v1 <> '基础包'
         and erm.ehome_group = v_group_id
         and erm.id_v2=v_prod_offer_a_id;

    cursor c6 is
    -- 1.0有效记录
      select pm.*
        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
             prefer_mdse_spec_rela@lk_crmv1       pms,
             mdse_ys_lisy_new                     my,
             mdse_ys_lisy_new                     my1
       where pm.rela_mdse_id = pms.rela_id
         and pms.prefer_spec_id = my.id_v1
         and my.id_v2 = v_prod_offer_a_id
         and pm.price_id = my1.id_v1
         and my1.id_v2 = v_prod_offer_z_id
         and pm.cfg_area_id <> 1
         and pm.state in ('70A', '70I')
         and pms.rela_id in
             (select role_id_v1 from fjruanh_ehome_role_mapping);

  begin

    if (prod_offer_sql is null) then
      str_msg := '请输入2.0销售品规格查询脚本!';
      return;
    end if;
    if (v_remark is null) then
      str_msg := '请输入备注信息!';
      return;
    end if;

    open c1 for prod_offer_sql;
    fetch c1
      into r1;
    while (c1%found) loop
      -- e家销售品
      if r1.offer_type = '11' and
         (r1.prod_offer_name like '%e%' or
         r1.prod_offer_id in (800001798, 800006844)) and
         r1.status_cd <> '1100' and r1.offer_sub_type = 'T01' then

        FOR KX IN (select distinct pms.prefer_spec_id mdse_spec_id,
                                   pm.price_id,
                                   my.id_v2 prod_offer_a_id,
                                   my1.id_v2 prod_offer_z_id,
                                   po.area_id
                     from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                          prefer_mdse_spec_rela@lk_crmv1       pms,
                          mdse_ys_lisy_new                     my,
                          mdse_ys_lisy_new                     my1,
                          prod_offer                           po
                    where pm.state in ('70A', '70I')
                      and pm.rela_mdse_id = pms.rela_id
                      and pms.prefer_spec_id = my.id_v1
                      and pms.state <> '70X'
                      and my.id_v2 = r1.prod_offer_id
                      and pm.price_id = my1.id_v1
                      and my1.id_v2 = po.prod_offer_id
                      and po.offer_type<>'11'
                      and po.offer_sub_type='T04'
                      and po.status_cd <> '1100'
                      and pms.rela_id in
                          (select role_id_v1 from fjruanh_ehome_role_mapping)
                      and po.prod_offer_id = 800011613 --800009048
                   --and r1.prod_offer_id = 800006801
                    order by my.id_v2, po.area_id, my1.id_v2) loop

          v_sel_prod_offer_rela_id := '';
          v_status_cd              := '';
          v_exp_date               := '';

          select count(*)
            into v_cnt
            from prod_offer_rel por
           where por.offer_a_id = r1.prod_offer_id
             and por.offer_z_id = kx.prod_offer_z_id
             and por.relation_type_cd = '100000'
             and area_id = kx.area_id;

          -- 存在与可选包同v_area_id的配置记录
          if v_cnt <> 0 then
            select max(prod_offer_rela_id)
              into v_sel_prod_offer_rela_id
              from prod_offer_rel
             where offer_a_id = r1.prod_offer_id
               and offer_z_id = kx.prod_offer_z_id
               and relation_type_cd = '100000'
               and area_id = kx.area_id;

          end if;
          -- 不存在与可选包同v_area_id的配置记录
          if v_cnt = 0 then
            select count(*)
              into v_cnt
              from prod_offer_rel por
             where por.offer_a_id = r1.prod_offer_id
               and por.offer_z_id = kx.prod_offer_z_id
               and por.relation_type_cd = '100000'
               and area_id <> kx.area_id;
            -- 存在与可选包不同v_area_id的配置记录
            if v_cnt <> 0 then
              select max(prod_offer_rela_id)
                into v_sel_prod_offer_rela_id
                from prod_offer_rel
               where offer_a_id = r1.prod_offer_id
                 and offer_z_id = kx.prod_offer_z_id
                 and relation_type_cd = '100000'
                 and area_id <> kx.area_id;
              /*str_msg := r1.prod_offer_id || ',' || kx.prod_offer_z_id || ',' ||
              v_sel_prod_offer_rela_id || ',' || kx.area_id;*/
            end if;
            -- 不存在省级和本地记录
            if v_cnt = 0 then
              v_sel_prod_offer_rela_id := 0;
            end if;
          end if;

          select count(*)
            into v_cnt
            from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                 prefer_mdse_spec_rela@lk_crmv1       pms
           where pm.rela_mdse_id = pms.rela_id
             and pms.prefer_spec_id = kx.mdse_spec_id
             and pm.price_id = kx.price_id
             and pm.state = '70A'
             and pm.exp_date is null
             and pms.rela_id in
                 (select role_id_v1 from fjruanh_ehome_role_mapping);

          -- 1.0存在有效记录
          if v_cnt <> 0 then
            v_status_cd := '1000';
            v_exp_date  := '';
          end if;
          -- 1.0不存在有效记录
          if v_cnt = 0 then
            v_status_cd := '1000';
            select max(pm.exp_date)
              into v_exp_date
              from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                   prefer_mdse_spec_rela@lk_crmv1       pms
             where pm.rela_mdse_id = pms.rela_id
               and pms.prefer_spec_id = kx.mdse_spec_id
               and pm.price_id = kx.price_id
               and pm.state in ('70A', '70I')
               and pms.rela_id in
                   (select role_id_v1 from fjruanh_ehome_role_mapping);
            -- 失效时间为空，状态为70I，2.0记录失效时间设置为系统时间
            if v_exp_date is null then
              v_exp_date := sysdate;
            end if;
          end if;

          -- 已存在2.0关联关系配置
          if v_sel_prod_offer_rela_id <> 0 then
          --str_msg:=v_sel_prod_offer_rela_id;
            select exp_date
              into exist_exp_date
              from prod_offer_rel por
             where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
            select status_cd
              into exist_status_cd
              from prod_offer_rel por
             where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
            select area_id
              into exist_v_area_id
              from prod_offer_rel por
             where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;

            if exist_exp_date <> v_exp_date or
               exist_status_cd <> v_status_cd or
               exist_v_area_id <> kx.area_id then
              insert into fjruanh_prod_offer_rel_bak
                select por.*,
                       sysdate,
                       '修改',
                       v_remark || '(修正2.0已有记录字段值)'
                  from prod_offer_rel por
                 where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
              update prod_offer_rel
                 set exp_date  = v_exp_date,
                     status_cd = v_status_cd,
                     area_id   = kx.area_id
               where prod_offer_rela_id = v_sel_prod_offer_rela_id;

            else
           /* str_msg:=exist_exp_date||','||exist_status_cd||','||exist_v_area_id||','||v_sel_prod_offer_rela_id||','||
           v_exp_date||','||v_status_cd||','||kx.area_id;*/
              insert into fjruanh_prod_offer_rel_bak
                select por.*, sysdate, '已审核，无改动', v_remark
                  from prod_offer_rel por
                 where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
            end if;
          end if;
          -- 不存在2.0关联关系配置
          if v_sel_prod_offer_rela_id = 0 then
            select SEQ_prod_offer_rel_id.Nextval
              into v_sel_prod_offer_rela_id
              from dual;
            insert into PROD_OFFER_REL
            values
              (v_sel_prod_offer_rela_id,
               r1.prod_offer_id,
               kx.prod_offer_z_id,
               null,
               '100000',
               sysdate,
               v_exp_date,
               '1000',
               sysdate,
               sysdate,
               null,
               null,
               kx.area_id,
               null,
               '104488',
               '104488',
               null,
               null,
               null,
               null,
               null,
               v_remark || '(新增记录)');

            insert into fjruanh_prod_offer_rel_bak
              select por.*, sysdate, '新增', v_remark || '(新增记录)'
                from prod_offer_rel por
               where por.prod_offer_rela_id = v_sel_prod_offer_rela_id;
          end if;

          v_prod_offer_a_id := r1.prod_offer_id;
          v_prod_offer_z_id := kx.prod_offer_z_id;
          v_mdse_spec_id    := kx.mdse_spec_id;
          v_price_id        := kx.price_id;

          -- 处理obj_area_rela表 (省级可选包)
          if kx.area_id = 1 then
            -- 1.0存在有效记录
            if v_exp_date is null then
              -- 适用区域是全省9地市，可不添加适用区域
              select count(*)
                into v_cnt
                from (select id
                        from p_area@lk_crmv1
                       where super = 1
                      minus
                      select pm.cfg_area_id
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                             prefer_mdse_spec_rela@lk_crmv1       pms
                       where pm.rela_mdse_id = pms.rela_id
                         and pms.prefer_spec_id = kx.mdse_spec_id
                         and pm.price_id = kx.price_id
                         and pm.state = '70A' --in ('70A','70I')
                         and (pm.exp_date is null or pm.exp_date > sysdate)
                         and pms.rela_id in
                             (select role_id_v1
                                from fjruanh_ehome_role_mapping));

              if v_cnt <> 0 then
                --str_msg := str_msg || ',' || v_cnt;
                for rec in c2 loop
                  -- 1.0有效记录处理适用区域，失效记录不处理
                  select count(*)
                    into v_cnt
                    from obj_area_rela
                   where obj_id = v_sel_prod_offer_rela_id
                     and rela_area_id = rec.cfg_area_id;

                  if v_cnt <> 0 then
                    select count(*)
                      into v_cnt
                      from obj_area_rela
                     where obj_id = v_sel_prod_offer_rela_id
                       and rela_area_id = rec.cfg_area_id
                       and status_cd = '1000';
                    if v_cnt = 0 then
                      update obj_area_rela
                         set status_cd = '1000',
                             remark    = remark || ';' || v_remark
                       where obj_id = v_sel_prod_offer_rela_id
                         and rela_area_id = rec.cfg_area_id
                         and status_cd <> '1000';
                    end if;
                  end if;

                  if v_cnt = 0 then
                    insert into obj_area_rela
                    values
                      (seq_obj_area_rela_id.nextval,
                       '51',
                       v_sel_prod_offer_rela_id,
                       rec.cfg_area_id,
                       '10',
                       1,
                       1,
                       '1000',
                       sysdate,
                       sysdate,
                       '104488',
                       '',
                       '104488',
                       v_remark);
                  end if;
                end loop;

                -- 处理本地没有配置关联时是否配置适用区域
                select count(*)
                  into v_cnt
                  from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 a,
                       prefer_mdse_spec_rela@lk_crmv1       b
                 where a.rela_mdse_id = b.rela_id
                   and b.prefer_spec_id = kx.mdse_spec_id
                      --and price_id = kx.price_id
                   and a.cfg_area_id <> 1
                   and b.rela_id in
                       (select role_id_v1 from fjruanh_ehome_role_mapping);
                -- kx销售品1.0存在本地关联配置；
                -- 如果不存在任何本地的配置（如“天翼”），可不配置适用区域
                if v_cnt <> 0 then

                  -- 处理本地没有配置关联时是否配置适用区域
                  for rec1 in c3 loop
                    select count(*)
                      into v_cnt
                      from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                     where mdse_spec_id = kx.mdse_spec_id
                       and cfg_area_id = rec1.id;
                    -- 销售品本地没有配置关联
                    if v_cnt = 0 then
                      select count(*)
                        into v_cnt
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                       where mdse_spec_id = kx.mdse_spec_id
                         and price_id = kx.price_id
                         and cfg_area_id = 1;
                      -- 省级存在关联
                      if v_cnt <> 0 then
                        insert into obj_area_rela
                        values
                          (seq_obj_area_rela_id.nextval,
                           '51',
                           v_sel_prod_offer_rela_id,
                           rec1.id,
                           '10',
                           1,
                           1,
                           '1000',
                           sysdate,
                           sysdate,
                           '104488',
                           '',
                           '104488',
                           v_remark);
                      end if;
                    end if;
                  end loop;
                end if;
              end if;
            end if;
            -- 1.0不存在有效记录
            if v_exp_date is not null then
              -- 适用区域是全省9地市，可不添加适用区域
              select count(*)
                into v_cnt
                from (select id
                        from p_area@lk_crmv1
                       where super = 1
                      minus
                      select pm.cfg_area_id
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                             mdse_ys_lisy_new                     my,
                             mdse_ys_lisy_new                     my1
                       where pm.mdse_spec_id = my.id_v1
                         and my.id_v2 = v_prod_offer_a_id
                         and pm.price_id = my1.id_v1
                         and my1.id_v2 = v_prod_offer_z_id
                         and pm.state in ('70A', '70I'));

              if v_cnt <> 0 then
                for rec in c6 loop
                  -- 所有1.0记录都处理适用区域
                  select count(*)
                    into v_cnt
                    from obj_area_rela
                   where obj_id = v_sel_prod_offer_rela_id
                     and rela_area_id = rec.cfg_area_id;

                  if v_cnt <> 0 then
                    select count(*)
                      into v_cnt
                      from obj_area_rela
                     where obj_id = v_sel_prod_offer_rela_id
                       and rela_area_id = rec.cfg_area_id
                       and status_cd = '1000';
                    if v_cnt = 0 then
                      update obj_area_rela
                         set status_cd = '1000',
                             remark    = remark || ';' || v_remark
                       where obj_id = v_sel_prod_offer_rela_id
                         and rela_area_id = rec.cfg_area_id
                         and status_cd <> '1000';
                    end if;
                  end if;

                  if v_cnt = 0 then
                    insert into obj_area_rela
                    values
                      (seq_obj_area_rela_id.nextval,
                       '51',
                       v_sel_prod_offer_rela_id,
                       rec.cfg_area_id,
                       '10',
                       1,
                       1,
                       '1000',
                       sysdate,
                       sysdate,
                       '104488',
                       '',
                       '1044881',
                       v_remark);
                  end if;
                end loop;
                -- 处理本地没有配置关联时是否配置适用区域
                select count(*)
                  into v_cnt
                  from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                 where mdse_spec_id = kx.mdse_spec_id
                      --and price_id = kx.price_id
                   and cfg_area_id <> 1;
                -- kx销售品1.0存在本地关联配置；
                -- 如果不存在任何本地的配置（如“天翼”），可不配置适用区域
                if v_cnt <> 0 then
                  for rec1 in c3 loop
                    select count(*)
                      into v_cnt
                      from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                     where mdse_spec_id = kx.mdse_spec_id
                       and cfg_area_id = rec1.id;
                    -- 销售品本地没有配置关联
                    if v_cnt = 0 then
                      select count(*)
                        into v_cnt
                        from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
                       where mdse_spec_id = kx.mdse_spec_id
                         and price_id = kx.price_id
                         and cfg_area_id = 1;
                      -- 省级存在关联
                      if v_cnt <> 0 then
                        insert into obj_area_rela
                        values
                          (seq_obj_area_rela_id.nextval,
                           '51',
                           v_sel_prod_offer_rela_id,
                           rec1.id,
                           '10',
                           1,
                           1,
                           '1000',
                           sysdate,
                           sysdate,
                           '104488',
                           '',
                           '1044881',
                           v_remark);
                      end if;
                    end if;
                  end loop;
                end if;
              end if;
            end if;
          end if;

          -- 处理obj_area_rela表 (本地可选包，删除适用区域配置)
          if kx.area_id <> 1 then
            delete obj_area_rela where obj_id = v_sel_prod_offer_rela_id;
          end if;

          update prod_offer_rel_restrict
             set update_staff = prod_offer_rel_id
           where prod_offer_rel_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update prod_offer_rel_restrict
             set prod_offer_rel_id = v_sel_prod_offer_rela_id
           where prod_offer_rel_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update OFFER_REL_RESTRICT_PROD
             set update_staff = prod_offer_rela_id
           where prod_offer_rela_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update OFFER_REL_RESTRICT_PROD
             set prod_offer_rela_id = v_sel_prod_offer_rela_id
           where prod_offer_rela_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update PROD_REL_OFFER_RESTRICT
             set update_staff = prod_offer_rela_id
           where prod_offer_rela_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update PROD_REL_OFFER_RESTRICT
             set prod_offer_rela_id = v_sel_prod_offer_rela_id
           where prod_offer_rela_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update obj_rel_value_restrict
             set remark = rela_id
           where rela_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update obj_rel_value_restrict
             set rela_id = v_sel_prod_offer_rela_id
           where rela_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update obj_rel_cfg
             set remark = obj_id
           where obj_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update obj_rel_cfg
             set obj_id = v_sel_prod_offer_rela_id
           where obj_id in
                 (select prod_offer_rela_id
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update attr_group_item
             set remark = attr_value
           where attr_value in
                 (select to_char(prod_offer_rela_id)
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          update attr_group_item
             set attr_value = to_char(v_sel_prod_offer_rela_id)
           where attr_value in
                 (select to_char(prod_offer_rela_id)
                    from prod_offer_rel
                   where offer_a_id = v_prod_offer_a_id
                     and offer_z_id = v_prod_offer_z_id
                     and relation_type_cd = '100000'
                     and prod_offer_rela_id <> v_sel_prod_offer_rela_id);

          insert into fjruanh_prod_offer_rel_bak
            select por.*, sysdate, '删除', v_remark || '(删除2.0已有记录)'
              from prod_offer_rel por
             where por.offer_a_id = r1.prod_offer_id
               and por.offer_z_id = kx.prod_offer_z_id
               and por.relation_type_cd = '100000'
               and por.prod_offer_rela_id <> v_sel_prod_offer_rela_id;

          delete prod_offer_rel por
           where por.offer_a_id = r1.prod_offer_id
             and por.offer_z_id = kx.prod_offer_z_id
             and por.relation_type_cd = '100000'
             and por.prod_offer_rela_id <> v_sel_prod_offer_rela_id;

          -- 以下代码处理销售品关联适用接入类产品的配置
          --------------------------------------------------------
          -- 省级可选包
          if kx.area_id = 1 then
            select count(*)
              into v_cnt
              from (select distinct cfg_area_id
                      from prefer_mdse_price_spec_rela@lk_crmv1
                     where price_id = kx.price_id
                       and rela_mdse_id in
                           (select rela_id
                              from prefer_mdse_spec_rela@lk_crmv1
                             where prefer_spec_id = kx.mdse_spec_id
                               and state <> '70X')
                       and state <> '70X'
                       and cfg_area_id <> 1);
            select count(*)
              into v_cnt1
              from (select distinct cfg_area_id
                      from prefer_mdse_price_spec_rela@lk_crmv1
                     where price_id = kx.price_id
                       and rela_mdse_id in
                           (select rela_id
                              from prefer_mdse_spec_rela@lk_crmv1
                             where prefer_spec_id = kx.mdse_spec_id
                               and state <> '70X')
                       and state <> '70X'
                       and cfg_area_id = 1);
            -- 除省级外，其他只有一个本地网配置适用套餐(省级无配置)，认为是本地可选包，取本地配置
            if v_cnt = 1 and v_cnt1 = 0 then
              select distinct cfg_area_id
                into v_area_id
                from prefer_mdse_price_spec_rela@lk_crmv1
               where price_id = kx.price_id
                 and rela_mdse_id in
                     (select rela_id
                        from prefer_mdse_spec_rela@lk_crmv1
                       where prefer_spec_id = kx.mdse_spec_id
                         and state <> '70X')
                 and state <> '70X'
                 and cfg_area_id <> 1;
            else
              v_area_id := 1; -- 取省级配置
            end if;
          end if;
          -- 本地可选包，取本地配置
          if kx.area_id <> 1 then
            v_area_id := kx.area_id;
          end if;
          -- 按不同分组处理（如手机组、电话组等），一个分组对应一个产品分类
          for rec4 in c4 loop
            -- 指定分组里，e家构成关系的配置记录数量
            select count(*)
              into v_cnt1
              from fjruanh_ehome_role_mapping
             where id_v2 = kx.prod_offer_a_id
               and ehome_group = rec4.ehome_group;
            -- 指定分组里，1.0存在与可选包配置的角色记录数量
            select count(*)
              into v_cnt2
              from (select b.role_id_v2
                      from crm.fjruanh_ehome_price_group@lk_crmv1 a,
                           fjruanh_ehome_role_mapping             b
                     where a.price_id = v_price_id
                       and a.group_id = b.ehome_group
                       and b.id_v2 = v_prod_offer_a_id
                       and b.role_name_v1 = '基础包'
                       and ehome_group = rec4.ehome_group
                    union
                    select role_id_v2
                      from fjruanh_ehome_role_mapping
                     where role_id_v1 in
                           (select rela_mdse_id
                              from prefer_mdse_price_spec_rela@lk_crmv1
                             where price_id = kx.price_id
                               and rela_mdse_id in
                                   (select rela_id
                                      from prefer_mdse_spec_rela@lk_crmv1
                                     where prefer_spec_id = kx.mdse_spec_id
                                       and state <> '70X'
                                       and name <> '基础包')
                               and state <> '70X'
                               and cfg_area_id = v_area_id)
                       and ehome_group = rec4.ehome_group
                       and id_v2 = kx.prod_offer_a_id);

            -- str_msg := str_msg || rec4.ehome_group || ',' || v_cnt1 || ',' ||
            --            v_cnt2;
            /*str_msg := v_area_id || ',' || v_group_id || ',' || v_cnt1 || ',' ||
            v_cnt2;*/

            -- 两者数量不相同，需要限制适用角色
            if v_cnt1 <> v_cnt2 then
              v_group_id := rec4.ehome_group;
              for rec5 in c5 loop
                select count(*)
                  into v_cnt
                  from OFFER_REL_RESTRICT_PROD a, offer_prod_rel b
                 where a.prod_offer_rela_id = v_sel_prod_offer_rela_id
                   and a.offer_prod_rela_id = b.offer_prod_rela_id
                   and b.prod_offer_id = rec5.id_v2
                   and b.role_cd = rec5.role_id_v2;

                /*str_msg := str_msg || ',' || v_sel_prod_offer_rela_id || ',' ||
                           rec5.id_v2 || ',' || rec5.role_id_v2 || ',' ||
                           v_cnt;*/
                /* if v_cnt <> 0 then
                  update OFFER_REL_RESTRICT_PROD
                     set create_staff = '104488', update_staff = ''
                   where prod_offer_rela_id = v_sel_prod_offer_rela_id;
                end if;*/

                -- 不存在相关限制，需要添加
                if v_cnt = 0 then
                  if rec5.state = '70A' and
                     (rec5.exp_date > sysdate or rec5.exp_date is null) then
                    insert into OFFER_REL_RESTRICT_PROD
                      select Seq_Offer_Rel_Restrict_Prod_Id.Nextval,
                             offer_prod_rela_id,
                             v_sel_prod_offer_rela_id,
                             '',
                             '16',
                             sysdate,
                             v_area_id,
                             '',
                             '1000',
                             sysdate,
                             '104488',
                             sysdate,
                             '',
                             '12'
                        from offer_prod_rel
                       where prod_offer_id = rec5.id_v2
                         and role_cd = rec5.role_id_v2;
                  end if;

                  if rec5.state = '70I' or rec5.exp_date < sysdate then
                    insert into OFFER_REL_RESTRICT_PROD
                      select Seq_Offer_Rel_Restrict_Prod_Id.Nextval,
                             offer_prod_rela_id,
                             v_sel_prod_offer_rela_id,
                             '',
                             '16',
                             sysdate,
                             v_area_id,
                             '',
                             '1299',
                             sysdate,
                             '104488',
                             sysdate,
                             '',
                             '12'
                        from offer_prod_rel
                       where prod_offer_id = rec5.id_v2
                         and role_cd = rec5.role_id_v2;
                  end if;
                end if;
              end loop;
              update OFFER_REL_RESTRICT_PROD
                 set update_staff = '1044881'
               where prod_offer_rela_id = v_sel_prod_offer_rela_id
                 and create_staff <> '104488';
            end if;

            -- 两者数量相同，无需限制适用角色
            if v_cnt1 = v_cnt2 then
              update OFFER_REL_RESTRICT_PROD
                 set update_staff = '1044882'
               where prod_offer_rela_id = v_sel_prod_offer_rela_id;
              --str_msg := str_msg || ';' || v_sel_prod_offer_rela_id;
            end if;

            ----- 处理可选包与产品的引用关系 -----
            -- 判断是否跟功能产品配置强制选择或默认选择(非引用关系)
            /*select count(*)
              into v_cnt
              from offer_prod_rel a
             where a.prod_offer_id = kx.prod_offer_z_id
               and a.rule_type <> '14'
               and a.status_cd = '1000';
            -- str_msg := v_cnt;
            -- 不存在与功能产品的关联
            if v_cnt = 0 then*/
              select count(*)
                into v_cnt
                from offer_prod_rel a, fjruanh_ehome_role_mapping b
               where a.prod_offer_id = kx.prod_offer_z_id
                 and a.rule_type = '14'
                 and a.status_cd = '1000'
                 and a.product_id = b.product_id
                 and b.ehome_group = rec4.ehome_group
                 and b.id_v2 = kx.prod_offer_a_id;
              -- str_msg := str_msg || ',' || v_cnt;

              -- 不存在与分组相同产品的引用关系，需添加
              if v_cnt = 0 then
                select distinct product_id
                  into v_product_id
                  from fjruanh_ehome_role_mapping
                 where ehome_group = rec4.ehome_group
                   and id_v2 = kx.prod_offer_a_id;
                -- str_msg := str_msg || ',' || v_product_id;
                insert into offer_prod_rel
                values
                  (seq_offer_prod_rel_id.nextval,
                   v_product_id,
                   kx.prod_offer_z_id,
                   '',
                   '',
                   '',
                   '14',
                   '1000',
                   sysdate,
                   sysdate,
                   sysdate,
                   '',
                   v_area_id,
                   '',
                   '104488',
                   '104488',
                   '',
                   '',
                   '',
                   '',
                   '',
                   '',
                   '',
                   v_remark,
                   '',
                   '');
              end if;
            --end if;

          end loop;
        end loop;
      end if;
      fetch c1
        into r1;
    end loop;
    close c1;
  end;

end PKG_CRM2_CFG_IN_1;
/
