CREATE PACKAGE           PKG_XM20170 IS

  -- Author  : chaijinchun
  -- Created : 2012-11-20
  -- Purpose : 提供给厦门20170系统查询使用,根据业务号码进行普通电话、小灵通、移动语音的产品规格信息信息。
  /*号码信息查询*/
  PROCEDURE PROC_NBR_INFO_QUERY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                                I_ACC_NBR     IN VARCHAR2, --业务号码
                                O_EXT_PROD_ID OUT VARCHAR2, --外部产品规格编码（失败为空），比如：594000276-普通电话, 610003886-移动语音， 594000248-小灵通
                                O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                O_ERR_MSG     OUT VARCHAR2 --错误信息
                                );

  -- Author  : chaijinchun
  -- Created : 2012-11-20
  -- Purpose : 提供给厦门20170系统查询使用,根据业务号码返回固定电话的改号通知音信息。
  /*改号通知音信息查询*/
  PROCEDURE PROC_GHTZY_INFO_QUERY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                                  I_ACC_NBR_OLD IN VARCHAR2, --旧业务号码
                                  I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话
                                  O_ACC_NBR_NEW OUT VARCHAR2, --新业务号码（失败为空）
                                  O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                  O_ERR_MSG     OUT VARCHAR2 --错误信息
                                  );

  -- Author  : chaijinchun
  -- Created : 2012-11-20
  -- Purpose : 提供给厦门20170系统查询使用,根据业务号码返回对应号码的呼叫限制（800303464）密码（590000366）信息。
  /*呼叫限制密码查询*/
  PROCEDURE PROC_HJXZ_INFO_QUERY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                                 I_ACC_NBR     IN VARCHAR2, --业务号码
                                 I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话
                                 O_HJXZ_PWD    OUT VARCHAR2, --呼叫限制密码（失败为空）
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2 --错误信息
                                 );

  -- Author  : chaijinchun
  -- Created : 2012-11-20
  -- Purpose : 提供给厦门20170系统查询使用，验证固定电话、小灵通的密码（590000366）是否正确。
  /*业务密码验证*/
  PROCEDURE PROC_PWD_VERIFY(I_AREA_CODE   IN VARCHAR2, --区号，比如厦门0592
                            I_ACC_NBR     IN VARCHAR2, --业务号码
                            I_EXT_PROD_ID IN VARCHAR2, --外部产品规格编码，比如：594000276-普通电话, 594000248-小灵通
                            I_PWD         IN Varchar2, --密码值（明文）
                            O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                            O_ERR_MSG     OUT VARCHAR2 --错误信息
                            );

END PKG_XM20170;
/
