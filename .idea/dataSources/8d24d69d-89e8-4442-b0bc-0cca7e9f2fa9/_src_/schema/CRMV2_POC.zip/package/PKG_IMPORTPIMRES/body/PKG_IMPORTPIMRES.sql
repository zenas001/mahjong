CREATE package body           PKG_IMPORTPIMRES is



----------------------------------------------------------------------

  Function fun_saveNewPimRes(  v_PESN          in varchar2,
                               v_PROD_SPEC_ID in varchar2,
                               v_CARD_TYPE    in varchar2,
                               v_ACC_NBR      in varchar2,
                               v_AREA_CODE    in varchar2,
                               v_CAPABILITY   in varchar2,
                               v_UPIN2   in varchar2,
                               v_UPIN1   in varchar2,
                               v_PIN2    in varchar2,
                               v_PIN1    in varchar2,
                               v_PASSWD  in varchar2,
                               v_PSNM    in varchar2,
                               v_ICCID   in varchar2,
                               v_ICCS    in varchar2,
                               v_iccid_sub in varchar2,
                                v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
                               v_JTZK in varchar2, --增加节点 by lixj
             v_physicalSize in varchar2,---物理尺寸 by fangj
       v_cWSJ in varchar2,---C网数据 by fangj
             v_cGSM in varchar2,---C-G双模 by fangj
             v_nearFieldPaye in varchar2,---近场支付 by fangj
                               v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId  out varchar2,
                               o_msg     out varchar2
                         )return number is
    v_ret         number;
    v_prodspecid  number;
    v_count       number;
    v_ICCSEXT     varchar2(50);
    v_mdsespecid  varchar2(50);
    v_storageid2  varchar2(50);
    v_state       varchar2(10);
    l_hascheck    number;
    v_Param1      varchar2(500);
    v_MKT_RESO_ID varchar2(20);
    v_MktResoSpecId varchar2(20);
    v_storageid     number;--add by suzhs
    v_usage_count   number;--add by suzhs
    v_region_code   varchar2(10); --add by linyzh 2015-02-15 crm00060700
    v_count2        number;--add by chenlf
    v_feaSpecId     number;--add by chenlinfang crm00064263

  begin
    v_ret := 0;
    select  count(*) into  v_count from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'JKFL_PROD';
    --add by linyzh 2015-02-15 crm00060700
    select a.code into v_region_code from crmv1.p_area a where a.SPECIFICATION = 'C3' and a.STANDARDCODE = v_AREA_CODE;
    if v_count = 1 then
      select  zbgs into  v_prodspecid from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'JKFL_PROD';
    else
      --其余的全部取厦门
      select  zbgs into  v_prodspecid from crmv1.zb where zbbm =  '0592' and  zbfl = 'JKFL_PROD';
    end if;

    select count(*) into v_count from  crmv1.MKT_RESOURCE
     WHERE MKT_RESO_KEY = v_ICCID AND MKT_RESO_SPEC_TYPE = v_prodspecid;
    if v_count > 0 then
      o_msg := '此USIM卡号已存在!';
      return v_ret;
    end if;

    if v_ACC_NBR  is null then

      select count(*) into v_count from  crmv1.zb where  zbbm = v_Capability and  zbfl = 'WHM_USIM' and zbgs = v_CARD_TYPE;
      if v_count = 1 then
        select zbzs into v_MktResoSpecId  from  crmv1.zb where  zbbm = v_Capability and  zbfl = 'WHM_USIM' and zbgs = v_CARD_TYPE;
      else
        o_msg := 'zb表对应WHM_USIM找不到' || v_CARD_TYPE || '的无号码USIM卡商品规格';
        return v_ret;
      end if;
    else
      select count(*) into v_count from  crmv1.zb where  zbbm = v_Capability and  zbfl = 'YHM_USIM' and zbgs = v_CARD_TYPE;
      if v_count = 1 then
        select zbzs into v_MktResoSpecId from  crmv1.zb where  zbbm = v_Capability and  zbfl = 'YHM_USIM' and zbgs = v_CARD_TYPE;
        --select  a.attr_value into  v_MktResoSpecId from attr_value a where  attr_id  = '写死id YHM_USIM'  and attr_desc  = v_CARD_TYPE;
      else
        o_msg := 'zb表对应YHM_USIM找不到' || v_CARD_TYPE || '的无号码USIM卡商品规格';
        return v_ret;
      end if;
    end if;


      select crmv1.MKT_RESO_ID_seq.nextval into v_MKT_RESO_ID  from dual;
       --add by suzhs -开始 集团制卡直接入库
       select to_number(a.zbzs) into v_storageid from crmv1.zb a where a.zbfl ='AREACODE_MAP_TO_STORE' and a.zbbm=v_AREA_CODE;
       if v_JTZK='1' then
         --add by chenlf 查集团卡管可自动入库的卡细类ID配置
         select count(*) into v_count2 from attr_value a where a.attr_id = 950023009 and a.attr_value = v_MktResoSpecId;
         if v_count2=1 then
           insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
             values ( v_MKT_RESO_ID,v_storageid, v_MktResoSpecId, v_ICCID, '0', '70A', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveNewPimRes', '', null, '');
           --变更库存
           select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
           if v_count=1 then
             select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
             v_usage_count:=v_usage_count+1;
             update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
           else
             insert into mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
             values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_MktResoSpecId, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
           end if;
           --add by chenlf
           --在每张USIM卡上落一个属性‘UIM卡单价’，属性取值=0
           insert into crmv1.mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
           values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,802653178,'0','',0,'','','',sysdate,'70A',sysdate,sysdate);
          -- 不在 集团卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
          else
           insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
           values ( v_MKT_RESO_ID,0, v_MktResoSpecId, v_ICCID, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveNewPimRes', '', null, '');
          end if;
       elsif v_JTZK='0' then
         --add by chenlf 省内卡管可自动入库的卡细类ID配置
         select count(*) into v_count2 from attr_value a where a.attr_id = 950023010 and a.attr_value = v_MktResoSpecId;
         if v_count2=1 then
             insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
             values ( v_MKT_RESO_ID,v_storageid, v_MktResoSpecId, v_ICCID, '0', '70A', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveNewPimRes', '', null, '');
             --变更库存
             select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
             if v_count=1 then
               select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
               v_usage_count:=v_usage_count+1;
               update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
             else
               insert into mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
               values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_MktResoSpecId, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
             end if;
         -- 不在 省内卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
         else
            insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
            values ( v_MKT_RESO_ID,0, v_MktResoSpecId, v_ICCID, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveNewPimRes', '', null, '');
         end if;
       else
          insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
           values ( v_MKT_RESO_ID,0, v_MktResoSpecId, v_ICCID, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveNewPimRes', '', null, '');
       end if;
       --add by suzhs--结束 集团制卡直接入库

       --begin : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
       if v_NFC_GJ is not null and v_NFC_GJ <>'0'then
         if v_NFC_GJ = '1' then
           --新增实例属性
           --判断区域
            select  count(*) into  v_count from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            if v_count = 1 then
              select  zbgs  into  v_feaSpecId from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            end if;
            insert into crmv1.mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
            values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,v_feaSpecId,v_NFC_GJ,'',0,'','','',sysdate,'70A',sysdate,sysdate);
         end if;
       end if;
       --end : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263

      if  SQL%FOUND then
       v_ret := 1;
      else
       o_msg := 'insert into MKT_RESOURCE 出错4';
       return v_ret;
      end if;

      if v_ret = 0 then
         o_msg := 'insert MKT_RESOURCE  错误请检查数据';
        return v_ret;
      end if;

     for SP in(
     select code , fea_spec_id
           from crmv1.prod_fea_spec a
          WHERE prod_spec_id = v_prodspecid)LOOP

          l_hascheck := 0;
          if SP.CODE = 'QEFeaPSNM' then
             v_Param1 := v_PSNM;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaPASSWD'  then
             v_Param1 := v_PASSWD;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaPIN1' then
             v_Param1 := v_PIN1;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaPIN2' then
             v_Param1 := v_PIN2;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaUPIN1'  then
             v_Param1 := v_UPIN1;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaUPIN2' then
             v_Param1 := v_UPIN2;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaCAPABI' then
             v_Param1 := v_CAPABILITY;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaACCNBR' then
             v_Param1 := v_ACC_NBR;
             l_hascheck := 1;
          elsif SP.CODE = 'QE0001'  then
             v_Param1 := v_ICCID;
             l_hascheck := 1;
             elsif SP.CODE = 'IMSI-G' then--增加节点 by huff
             v_Param1 := v_IMSIG;
             l_hascheck := 1;
              elsif SP.CODE = 'IMSI-LTE' then--增加节点 by huff
             v_Param1 := v_IMSILTE;
             l_hascheck := 1;
              elsif SP.CODE = 'UimFor4g' then--增加节点 by lixj
             v_Param1 := v_JTZK;
             l_hascheck := 1;

        elsif SP.CODE = 'PhysicalSize' then--增加节点 by fangj
             v_Param1 := v_physicalSize;
             l_hascheck := 1;

        elsif SP.CODE = 'CGSM' then--增加节点 by fangj
             v_Param1 := v_cGSM;
             l_hascheck := 1;

        elsif SP.CODE = 'NearFieldPay' then--增加节点 by fangj
             v_Param1 := v_nearFieldPaye;
             l_hascheck := 1;

        elsif SP.CODE = 'CWSJ' then--增加节点 by fangj
             v_Param1 := v_cWSJ;
             l_hascheck := 1;

        elsif SP.CODE = 'YzfCardNumber' then --翼支付卡号 add by linyzh 2014-11-03 crm00058242
             v_Param1 := v_YZF_CARD;
             l_hascheck := 1;

        elsif SP.CODE = 'PhysicalCard' then --物理卡号 add by linyzh 2014-11-03 crm00058242
             v_Param1 := v_WLK_CARD;
             l_hascheck := 1;

        elsif SP.CODE = 'CardMainType' then --卡大类 add by linyzh 2014-11-24 crm00058242
             v_Param1 := v_CARD_KIND;
             l_hascheck := 1;

        elsif SP.CODE = 'regionCode' then -- 区域 add by linyzh 2015-02-15 crm00060700
             v_Param1 := v_region_code;
             l_hascheck := 1;
          end if;

          if v_Param1 is not null  and l_hascheck = 1  then

          if SP.fea_spec_id = '620029411' then -------add by chenth 2015-09-07 crm00063668
             select  count(*) into v_count from crmv1.Mkt_Reso_Fea WHERE FEA_SPEC_ID= SP.fea_spec_id  AND PARAM1=v_Param1;
              if  v_count >0 then
                    v_ret := 0;
                   o_msg := '此机身码已存在,不允许导入!';
                   return v_ret;
              else
                 insert into Mkt_Reso_Fea (RESO_FEA_ID, MKT_RESO_ID, FEA_SPEC_ID, PARAM1, PARAM2, PARENT_ID, OP_MODE, SOURCE, MODIFY_CAUSE, REAL_MODIFY_DATE, STATE, MODIFY_DATE, CREATE_DATE)
                 values (crmv1.Mkt_Reso_Fea_ID_seq.nextval, v_MKT_RESO_ID, SP.fea_spec_id, v_Param1, '', 0, '', '', '', sysdate, '70A', sysdate, sysdate);
              end if;
             else
             insert into Mkt_Reso_Fea (RESO_FEA_ID, MKT_RESO_ID, FEA_SPEC_ID, PARAM1, PARAM2, PARENT_ID, OP_MODE, SOURCE, MODIFY_CAUSE, REAL_MODIFY_DATE, STATE, MODIFY_DATE, CREATE_DATE)
             values (crmv1.Mkt_Reso_Fea_ID_seq.nextval, v_MKT_RESO_ID, SP.fea_spec_id, v_Param1, '', 0, '', '', '', sysdate, '70A', sysdate, sysdate);
             end if;
          end if;
      end LOOP;
    if v_Acc_Nbr  is not null then
        select  crmv1.PRODUCT_ID_SEQ.NEXTVAL into o_prodId from  dual;  --预占id
    end if;
    return v_ret;
  end;


  Function fun_saveUSIMRes(  v_PESN          in varchar2,
                             v_PROD_SPEC_ID in varchar2,
                             v_CARD_TYPE    in varchar2,
                             v_ACC_NBR      in varchar2,
                             v_AREA_CODE    in varchar2,
                             v_CAPABILITY   in varchar2,
                             v_UPIN2   in varchar2,
                             v_UPIN1   in varchar2,
                             v_PIN2    in varchar2,
                             v_PIN1    in varchar2,
                             v_PASSWD  in varchar2,
                             v_PSNM    in varchar2,
                             v_ICCID   in varchar2,
                             v_ICCS    in varchar2,
                             v_iccid_sub in varchar2,
                             v_UPIN1_AGENT    in varchar2,
                              v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
                               v_JTZK in varchar2, --增加节点 by lixj
             v_physicalSize in varchar2,---物理尺寸 by fangj
       v_cWSJ in varchar2,---C网数据 by fangj
             v_cGSM in varchar2,---C-G双模 by fangj
             v_nearFieldPaye in varchar2,---近场支付 by fangj
                             v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                             v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                             v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                             v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                             o_prodId  out varchar2,
                             o_msg     out varchar2
                         )return number is
    v_ret         number;
    v_prodspecid  number;
    v_count       number;
    v_ICCSEXT     varchar2(50);
    v_mdsespecid  varchar2(50);
    v_storageid2  varchar2(50);
    v_state       varchar2(10);
    l_hascheck    number;
    v_Param1      varchar2(500);
    v_MKT_RESO_ID varchar2(20);
    v_iccid_sub2   varchar2(200);
    v_MktResoSpecId varchar2(50);
    v_isCardType  number;
    v_flag        number;
    v_ICCS_TEMP     varchar2(50);
    v_storageid     number;--add by suzhs
    v_usage_count   number;--add by suzhs
    v_region_code   varchar2(10);--add by linyzh 2015-02-15 crm00060700
    v_count2       number;--add by chenlf
    v_feaSpecId    number;--add by chenlinfang crm00064263
  begin
    v_ret := 0;
    v_flag := 0;
   -- 从配置获取 USIM卡 的规格 610003985
   v_prodspecid :=  610003985;  --因为只有一个 就不加配置了
   --add by linyzh 2015-02-15 crm00060700
    select a.code into v_region_code from crmv1.p_area a where a.SPECIFICATION = 'C3' and a.STANDARDCODE = v_AREA_CODE;
    if length(v_ICCID) > 19  then
       select substr(v_ICCID,0,19)  into v_iccid_sub2  from  dual;
       --v_iccid_sub := v_iccid_sub2;
    else
      v_iccid_sub2 := v_ICCID;
    end if;

    select count(*) into v_count from   crmv1.MKT_RESOURCE
     WHERE MKT_RESO_KEY=v_iccid_sub2 AND MKT_RESO_SPEC_TYPE = v_prodspecid;
    if v_count > 0 then
      o_msg := '此USIM卡号已存在!';
      return v_ret;
    end if;

    select count(*) into v_count from   crmv1.MKT_RESOURCE   WHERE ICCS = v_ICCS;
    select  count(*)  into   v_isCardType from crmv1.zb where zbfl = 'CARTYPE' and zbbm = v_CARD_TYPE;

    if v_isCardType > 0 then
      v_ICCS_TEMP := v_PSNM;  --转成iccs节点上面
      if length(v_ICCS_TEMP) >= 2  then
        v_ICCSEXT := substr(v_ICCS_TEMP, length(v_ICCS_TEMP) - 1 , 2);
      end if;

      v_mdsespecid :=  611208667;   --1.0配置中的。因为只有一个 所以可以写死
      --insert 结束.
      select count(*) into v_count from   crmv1.MKT_RESOURCE
       WHERE MKT_RESO_KEY=v_ICCS_TEMP AND MKT_RESO_SPEC_TYPE = v_prodspecid;
      if v_count > 0 then
        o_msg := '此USIM卡号已存在!';
        return v_ret;
      end if;

      select crmv1.MKT_RESO_ID_seq.nextval into v_MKT_RESO_ID  from dual;
      --add by suzhs -开始 集团制卡直接入库
      select to_number(a.zbzs) into v_storageid from crmv1.zb a where a.zbfl ='AREACODE_MAP_TO_STORE' and a.zbbm=v_AREA_CODE;
      if v_JTZK='1' then
         --add by chenlf 查集团卡管可自动入库的卡细类ID配置
         select count(*) into v_count2 from attr_value a where a.attr_id = 950023009 and a.attr_value = v_mdsespecid;
         if v_count2=1 then
           insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
             values ( v_MKT_RESO_ID,v_storageid, v_mdsespecid, v_ICCS_TEMP, '0', '70A', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, v_ICCS_TEMP, v_ICCSEXT, '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
           --变更库存
           select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
           if v_count=1 then
              select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
              v_usage_count:=v_usage_count+1;
              update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid;
           else
              insert into crmv1.mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
                values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_mdsespecid, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
           end if;
           --add by chenlf
           --在每张USIM卡上落一个属性‘UIM卡单价’，属性取值=0
           insert into crmv1.mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
           values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,802653178,'0','',0,'','','',sysdate,'70A',sysdate,sysdate);
           -- 不在 集团卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
          else
           insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
           values ( v_MKT_RESO_ID,0, v_mdsespecid, v_ICCS_TEMP, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, v_ICCS_TEMP, v_ICCSEXT, '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
          end if;
       elsif v_JTZK='0' then
         --add by chenlf 省内卡管可自动入库的卡细类ID配置
         select count(*) into v_count2 from attr_value a where a.attr_id = 950023010 and a.attr_value = v_mdsespecid;
         if v_count2=1 then
             insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
             values ( v_MKT_RESO_ID,v_storageid, v_mdsespecid, v_ICCS_TEMP, '0', '70A', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
             --变更库存
             select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
             if v_count=1 then
               select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
               v_usage_count:=v_usage_count+1;
               update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid;
             else
               insert into mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
               values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_mdsespecid, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
             end if;
         -- 不在 省内卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
         else
            insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
            values ( v_MKT_RESO_ID,0, v_mdsespecid, v_ICCS_TEMP, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
         end if;
      else
          insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
          values ( v_MKT_RESO_ID,0, v_mdsespecid, v_ICCS_TEMP, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, v_ICCS_TEMP, v_ICCSEXT, '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
      end if;
      --add by suzhs--结束 集团制卡直接入库

      --begin : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
      if v_NFC_GJ is not null and v_NFC_GJ <>'0'then
         if v_NFC_GJ = '1' then
           --新增实例属性
           --判断区域
            select  count(*) into  v_count from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            if v_count = 1 then
              select  zbgs  into  v_feaSpecId from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            end if;
            insert into crmv1.mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
            values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,v_feaSpecId,v_NFC_GJ,'',0,'','','',sysdate,'70A',sysdate,sysdate);
         end if;
      end if;
      --end : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263

     --是否插入成功.
     if  SQL%FOUND then
       v_ret := 1;
     end if;

    elsif  v_count > 0 then
      update crmv1.MKT_RESOURCE  set mkt_reso_key = v_iccid_sub2, MODI_TIME =sysdate where ICCS = v_ICCS;

      if  SQL%FOUND then
       v_ret := 1;
      else
       o_msg := 'insert into MKT_RESOURCE 出错3';
       return v_ret;
      end if;

      select count(*) into v_count from crmv1.MKT_RESOURCE  where ICCS = v_ICCS;
      if  v_count = 1 then
       select  MKT_RESO_ID into v_MKT_RESO_ID from crmv1.MKT_RESOURCE  where ICCS = v_ICCS;
      else
       o_msg := 'select MKT_RESO_ID into v_MKT_RESO_ID from MKT_RESOURCE where ICCS = v_ICCS出错3';
       return v_ret;
      end if;
      --v_flag := 1;
      --更新数据
    else

      select  count(*) into v_count from   crmv1.zb where zbfl =  'EZF_USIM' and   instr(v_CARD_TYPE, zbgs)>0;
      if v_count = 1 then
        select  zbzs into v_MktResoSpecId from   crmv1.zb where zbfl =  'EZF_USIM' and  instr(v_CARD_TYPE, zbgs)>0;
      end if;

      select  count(*) into v_count from   crmv1.zb where zbfl =  'XHM_USIM' and  instr(v_CARD_TYPE, zbgs)>0;
      if v_count = 1 then
        select  zbzs into v_MktResoSpecId from   crmv1.zb where zbfl =  'XHM_USIM' and  instr(v_CARD_TYPE, zbgs)>0;
      end if;

      select  count(*) into v_count from   crmv1.zb where zbfl =  'MKT_USIM_YZFGJSMK' and  instr(v_CARD_TYPE, zbgs)>0;
      if v_count = 1 then
        select  zbzs into v_MktResoSpecId from  crmv1.zb where zbfl =  'MKT_USIM_YZFGJSMK' and  instr(v_CARD_TYPE, zbgs)>0;
      end if;

      if v_MktResoSpecId is null  then
        if v_Acc_Nbr  is null then

          select count(*) into v_count from   crmv1.zb where  zbbm = v_Capability and  zbfl = 'WHM_USIM' and zbgs = v_CARD_TYPE;
          if v_count = 1 then
            select zbzs into v_MktResoSpecId  from   crmv1.zb where  zbbm = v_Capability and  zbfl = 'WHM_USIM' and zbgs = v_CARD_TYPE;
          else
            o_msg := 'zb表对应WHM_USIM找不到' || v_CARD_TYPE || '的无号码USIM卡商品规格';
            return v_ret;
          end if;
        else

          select count(*) into v_count from   crmv1.zb where  zbbm = v_Capability and  zbfl = 'YHM_USIM' and zbgs = v_CARD_TYPE;
          if v_count = 1 then
            select zbzs into v_MktResoSpecId  from   crmv1.zb where  zbbm = v_Capability and  zbfl = 'YHM_USIM' and zbgs = v_CARD_TYPE;
          else
            o_msg := 'zb表对应YHM_USIM找不到' || v_CARD_TYPE || '的无号码USIM卡商品规格';
            return v_ret;
          end if;

        end if;
      end if;

      if  v_ICCS  is not null then
        v_storageid2 := '290';  --  读取配置中的数据
        v_state := '70A';
      else
        v_storageid2 := '0';
        v_state := '70D';
      end if;

      select crmv1.MKT_RESO_ID_seq.nextval into v_MKT_RESO_ID  from dual;
      --add by suzhs -开始 集团制卡直接入库
      select to_number(a.zbzs) into v_storageid from  crmv1.zb a where a.zbfl ='AREACODE_MAP_TO_STORE' and a.zbbm=v_AREA_CODE;
      if v_JTZK='1' then
         --add by chenlf 查集团卡管可自动入库的卡细类ID配置
         select count(*) into v_count2 from attr_value a where a.attr_id = 950023009 and a.attr_value = v_MktResoSpecId;
         if v_count2=1 then
           insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
             values ( v_MKT_RESO_ID,v_storageid, v_MktResoSpecId, v_iccid_sub2, '0', '70A', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
           --变更库存
           select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
           if v_count=1 then
              select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
              v_usage_count:=v_usage_count+1;
              update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
           else
              insert into crmv1.mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
                values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_MktResoSpecId, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
           end if;
           --add by chenlf
           --在每张USIM卡上落一个属性‘UIM卡单价’，属性取值=0
           insert into mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
           values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,802653178,'0','',0,'','','',sysdate,'70A',sysdate,sysdate);
          -- 不在 集团卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
          else
          insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
            values ( v_MKT_RESO_ID,0, v_MktResoSpecId, v_iccid_sub2, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
         end if;
       elsif v_JTZK='0' then
         --add by chenlf 省内卡管可自动入库的卡细类ID配置
         select count(*) into v_count2 from attr_value a where a.attr_id = 950023010 and a.attr_value = v_MktResoSpecId;
         if v_count2=1 then
             insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
             values ( v_MKT_RESO_ID,v_storageid, v_MktResoSpecId, v_iccid_sub2, '0', '70A', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
             --变更库存
             select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
             if v_count=1 then
               select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
               v_usage_count:=v_usage_count+1;
               update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_MktResoSpecId and a.store_type='1';
             else
               insert into mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
               values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_MktResoSpecId, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
             end if;
         -- 不在 省内卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
         else
            insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
            values ( v_MKT_RESO_ID,0, v_MktResoSpecId, v_iccid_sub2, '0', '70D', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
         end if;
      else
          insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
      values (v_MKT_RESO_ID,  v_storageid2, v_MktResoSpecId, v_iccid_sub2, '0', v_state, sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveUSIMRes', '', null, '');
      end if;
      --add by suzhs--结束 集团制卡直接入库

      --begin : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
       if v_NFC_GJ is not null and v_NFC_GJ <>'0'then
         if v_NFC_GJ = '1' then
           --新增实例属性
           --判断区域
            select  count(*) into  v_count from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            if v_count = 1 then
              select  zbgs  into  v_feaSpecId from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            end if;
            insert into crmv1.mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
            values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,v_feaSpecId,v_NFC_GJ,'',0,'','','',sysdate,'70A',sysdate,sysdate);
         end if;
       end if;
       --end : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263

      if  SQL%FOUND then
       v_ret := 1;
      else
       o_msg := 'insert into MKT_RESOURCE 出错1';
       return v_ret;
      end if;
    end if;

    if  v_flag = 0 and  v_isCardType <= 0  and v_MKT_RESO_ID is not null then

     for SP in(
      select code , fea_spec_id
           from crmv1.prod_fea_spec a
          WHERE prod_spec_id = '610003985')LOOP

          l_hascheck := 0;
          if SP.CODE = 'QEFeaPSNM' then
             v_Param1 := v_PSNM;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaPASSWD'  then
             v_Param1 := v_PASSWD;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaPIN1' then
             v_Param1 := v_PIN1;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaPIN2' then
             v_Param1 := v_PIN2;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaUPIN1'  then
             v_Param1 := v_UPIN1;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaUPIN2' then
             v_Param1 := v_UPIN2;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaCAPABI' then
             v_Param1 := v_Capability;
             l_hascheck := 1;
          elsif SP.CODE = 'QEFeaACCNBR' then
             v_Param1 := v_Acc_Nbr;
             l_hascheck := 1;
          elsif SP.CODE = 'Z'  then
             v_Param1 := v_iccid_sub2;
             l_hascheck := 1;
          elsif SP.CODE = 'ICCIDYZM'  then
             v_Param1 := v_ICCID;
             l_hascheck := 1;
          elsif SP.CODE = 'PESN'  then
             v_Param1 := v_PESN;
             l_hascheck := 1;
          elsif SP.CODE = 'KXPUK' then
             v_Param1 := v_UPIN1_AGENT;
             l_hascheck := 1;
             elsif SP.CODE = 'IMSI-G' then--增加节点 by huff
             v_Param1 := v_IMSIG;
             l_hascheck := 1;
              elsif SP.CODE = 'IMSI-LTE' then--增加节点 by huff
             v_Param1 := v_IMSILTE;
             l_hascheck := 1;
               elsif SP.CODE = 'UimFor4g' then--增加节点 by lixj
             v_Param1 := v_JTZK;
             l_hascheck := 1;

        elsif SP.CODE = 'PhysicalSize' then--增加节点 by fangj
             v_Param1 := v_physicalSize;
             l_hascheck := 1;

        elsif SP.CODE = 'CGSM' then--增加节点 by fangj
             v_Param1 := v_cGSM;
             l_hascheck := 1;

        elsif SP.CODE = 'NearFieldPay' then--增加节点 by fangj
             v_Param1 := v_nearFieldPaye;
             l_hascheck := 1;

        elsif SP.CODE = 'CWSJ' then--增加节点 by fangj
             v_Param1 := v_cWSJ;
             l_hascheck := 1;

        elsif SP.CODE = 'YzfCardNumber' then --翼支付卡号 add by linyzh 2014-11-03 crm00058242
             v_Param1 := v_YZF_CARD;
             l_hascheck := 1;

        elsif SP.CODE = 'PhysicalCard' then --物理卡号 add by linyzh 2014-11-03 crm00058242
             v_Param1 := v_WLK_CARD;
             l_hascheck := 1;

        elsif SP.CODE = 'CardMainType' then --卡大类 add by linyzh 2014-11-24 crm00058242
             v_Param1 := v_CARD_KIND;
             l_hascheck := 1;

        elsif SP.CODE = 'regionCode' then -- 区域 add by linyzh 2015-02-15 crm00060700
             v_Param1 := v_region_code;
             l_hascheck := 1;
          end if;

          if v_Param1 is not null  and l_hascheck = 1  then

          if SP.fea_spec_id = '620029411' then -------add by chenth 2015-09-07 crm00063668
             select  count(*) into v_count from crmv1.Mkt_Reso_Fea WHERE FEA_SPEC_ID= SP.fea_spec_id  AND PARAM1=v_Param1;
              if  v_count >0 then
                v_ret := 0;
                o_msg := '此机身码已存在,不允许导入!';
                return v_ret;
              else
                 insert into Mkt_Reso_Fea (RESO_FEA_ID, MKT_RESO_ID, FEA_SPEC_ID, PARAM1, PARAM2, PARENT_ID, OP_MODE, SOURCE, MODIFY_CAUSE, REAL_MODIFY_DATE, STATE, MODIFY_DATE, CREATE_DATE)
                 values (crmv1.Mkt_Reso_Fea_ID_seq.nextval, v_MKT_RESO_ID, SP.fea_spec_id, v_Param1, '', 0, '', '', '', sysdate, '70A', sysdate, sysdate);
              end if;
             else
             insert into Mkt_Reso_Fea (RESO_FEA_ID, MKT_RESO_ID, FEA_SPEC_ID, PARAM1, PARAM2, PARENT_ID, OP_MODE, SOURCE, MODIFY_CAUSE, REAL_MODIFY_DATE, STATE, MODIFY_DATE, CREATE_DATE)
             values (crmv1.Mkt_Reso_Fea_ID_seq.nextval, v_MKT_RESO_ID, SP.fea_spec_id, v_Param1, '', 0, '', '', '', sysdate, '70A', sysdate, sysdate);
             end if;
          end if;
      end LOOP;
    end if;
    if v_Acc_Nbr  is not null then
      select  crmv1.PRODUCT_ID_SEQ.NEXTVAL into o_prodId from  dual;  --预占id
    end if;

    return v_ret;
  end;

  Function fun_saveJKFLWGRes(  v_PESN          in varchar2,
                             v_PROD_SPEC_ID in varchar2,
                             v_CARD_TYPE    in varchar2,
                             v_ACC_NBR      in varchar2,
                             v_AREA_CODE    in varchar2,
                             v_CAPABILITY   in varchar2,
                             v_UPIN2   in varchar2,
                             v_UPIN1   in varchar2,
                             v_PIN2    in varchar2,
                             v_PIN1    in varchar2,
                             v_PASSWD  in varchar2,
                             v_PSNM    in varchar2,
                             v_ICCID   in varchar2,
                             v_ICCS    in varchar2,
                             v_iccid_sub in varchar2,
                             v_akey in varchar2,
                              v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
                               v_JTZK in varchar2, --增加节点 by lixj
             v_physicalSize in varchar2,---物理尺寸 by fangj
       v_cWSJ in varchar2,---C网数据 by fangj
             v_cGSM in varchar2,---C-G双模 by fangj
             v_nearFieldPaye in varchar2,---近场支付 by fangj
                             v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                             v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                             v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                             v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                             o_prodId  out varchar2,
                             o_msg     out varchar2
                         )return number is
    v_ret         number;
    v_prodspecid  number;
    v_count       number;
    v_ICCSEXT     varchar2(50);
    v_mdsespecid  varchar2(50);
    v_storageid2  varchar2(50);
    v_state       varchar2(10);
    l_hascheck    number;
    v_Param1      varchar2(500);
    v_MKT_RESO_ID varchar2(20);
    v_iccid_sub2   varchar2(200);
    v_MktResoSpecId varchar2(50);
    v_storageid     number;--add by suzhs
    v_usage_count   number;--add by suzhs
    v_region_code   varchar2(10);--add by linyzh 2015-02-15 crm00060700
    v_count2        number;--add by chenlf
    v_feaSpecId     number;--add by chenlinfang crm00064263
  begin
    v_ret := 0;

   select count(*) into v_count from   crmv1.zb where zbfl = 'JKFLWG_PROD' and zbbm  = 'JKFLWG_PROD';
   --add by linyzh 2015-02-15 crm00060700
    select a.code into v_region_code from crmv1.p_area a where a.SPECIFICATION = 'C3' and a.STANDARDCODE = v_AREA_CODE;

   if v_count = 1 then
     select zbzs, zbgs into v_prodspecid, v_mdsespecid from   crmv1.zb where zbfl = 'JKFLWG_PROD' and zbbm  = 'JKFLWG_PROD';
   else
     o_msg := 'zb配置有问题zbfl = JKFLWG_PROD';
     return v_ret;
   end if;

   select  count(*) into v_count from crmv1.Mkt_Resource WHERE MKT_RESO_KEY=  v_ICCID AND MKT_RESO_SPEC_TYPE=v_prodspecid;
   if  v_count >0 then
     o_msg := '此机卡分离家庭网关卡卡号已存在!';
     return v_ret;
   end if;


    select crmv1.MKT_RESO_ID_seq.nextval into v_MKT_RESO_ID  from dual;
    --add by suzhs -开始 集团制卡直接入库
    select to_number(a.zbzs) into v_storageid from  crmv1.zb a where a.zbfl ='AREACODE_MAP_TO_STORE' and a.zbbm=v_AREA_CODE;
    if v_JTZK='1' then
      --add by chenlf 集团卡管可自动入库的卡细类ID配置
      select count(*) into v_count2 from attr_value a where a.attr_id = 950023009 and a.attr_value = v_mdsespecid;
      if v_count2=1 then
        insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
          values ( v_MKT_RESO_ID,v_storageid, v_mdsespecid, v_ICCID, '0', '70A', null, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveJKFLWGRes', '', null, '');
        --变更库存
        select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
        if v_count=1 then
          select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
          v_usage_count:=v_usage_count+1;
          update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid;
        else
          insert into mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
            values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_mdsespecid, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
        end if;
        --add by chenlf
        --在每张USIM卡上落一个属性‘UIM卡单价’，属性取值=0
                   insert into crmv1.mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
        values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,802653178,'0','',0,'','','',sysdate,'70A',sysdate,sysdate);
        -- 不在 集团卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
       else
          insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
          values ( v_MKT_RESO_ID,0, v_mdsespecid, v_ICCID, '0', '70D', null, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveJKFLWGRes', '', null, '');
       end if;
     elsif v_JTZK='0' then
         --add by chenlf 省内卡管可自动入库的卡细类ID配置
         select count(*) into v_count2 from attr_value a where a.attr_id = 950023010 and a.attr_value = v_mdsespecid;
         if v_count2=1 then
             insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
             values ( v_MKT_RESO_ID,v_storageid, v_mdsespecid, v_ICCID, '0', '70A', sysdate, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveJKFLWGRes', '', null, '');
             --变更库存
             select count(*) into v_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
             if v_count=1 then
               select a.usage_count into v_usage_count from mkt_store_item a where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid and a.store_type='1';
               v_usage_count:=v_usage_count+1;
               update mkt_store_item a set a.usage_count=v_usage_count,a.modi_time=sysdate where a.store_id=v_storageid and a.mkt_reso_spec_id=v_mdsespecid;
             else
               insert into mkt_store_item (STORE_ITEM_ID, STORE_ID, MKT_RESO_SPEC_ID, USAGE_COUNT, MOVING_COUNT, BAD_COUNT, STATE, MODI_TIME, CREA_TIME, ARV_PRICE, STORE_TYPE, UP_LIMIT, LOW_LIMIT, OLD_SEND_DATE, DEL_COUNT, REAL_MODIFY_DATE)
               values (crmv1.mkt_store_item_id_seq.nextval, v_storageid, v_mdsespecid, 1, 0, 0, '70A', sysdate, sysdate, null, '1', null, null, null, null, sysdate);
             end if;
         -- 不在 省内卡管可自动入库的卡细类ID配置 中 ,则入成 70D 且无仓库
         else
            insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
            values ( v_MKT_RESO_ID,0, v_mdsespecid, v_ICCID, '0', '70D', null, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveJKFLWGRes', '', null, '');
         end if;
    else
        insert into crmv1.MKT_RESOURCE (MKT_RESO_ID, STORAGE_ID, MKT_RESO_SPEC_ID, MKT_RESO_KEY, BATCH_ID, STATE, MODI_TIME, CREA_TIME, MKT_RESO_SPEC_TYPE, MKT_SOURCE, STORE_TYPE, ORDER_PAY, BACK_STATE, BACK_TYPE, REAL_MODIFY_DATE, ICCS, ICCS_EXT, SALESTATE, REMARKS, TO_STAFF_ID, TO_STAFF_DATE, STATE_REMARK)
        values ( v_MKT_RESO_ID,0, v_mdsespecid, v_ICCID, '0', '70D', null, sysdate, v_prodspecid, '', '', '', '', '', sysdate, '', '', '', 'PROC_importPimRes.fun_saveJKFLWGRes', '', null, '');
    end if;
      --add by suzhs--结束 集团制卡直接入库

      --begin : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
      if v_NFC_GJ is not null and v_NFC_GJ <>'0'then
         if v_NFC_GJ = '1' then
           --新增实例属性
           --判断区域
            select  count(*) into  v_count from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            if v_count = 1 then
              select  zbgs  into  v_feaSpecId from crmv1.zb where zbbm = v_Area_Code and  zbfl = 'BUS_NFC';
            end if;
            insert into crmv1.mkt_reso_fea (RESO_FEA_ID,MKT_RESO_ID,FEA_SPEC_ID,PARAM1,PARAM2,PARENT_ID,OP_MODE,SOURCE,MODIFY_CAUSE,REAL_MODIFY_DATE,STATE,MODIFY_DATE,CREATE_DATE)
            values (crmv1.mkt_reso_fea_id_seq.nextval,v_MKT_RESO_ID,v_feaSpecId,v_NFC_GJ,'',0,'','','',sysdate,'70A',sysdate,sysdate);
         end if;
       end if;
       --end : USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263

     if  SQL%FOUND then
       v_ret := 1;
     else
       o_msg := 'insert into MKT_RESOURCE 出错2';
       return v_ret;
     end if;

     for SP in(
      select code , fea_spec_id
           from crmv1.prod_fea_spec a
          WHERE prod_spec_id = v_prodspecid)LOOP

          l_hascheck := 0;
          if SP.CODE = 'LOID' then
             v_Param1 := v_PSNM;
             l_hascheck := 1;
          elsif SP.CODE = 'MY'  then
             v_Param1 :=  v_akey;
             l_hascheck := 1;
             elsif SP.CODE = 'IMSI-G' then--增加节点 by huff
             v_Param1 := v_IMSIG;
             l_hascheck := 1;
              elsif SP.CODE = 'IMSI-LTE' then--增加节点 by huff
             v_Param1 := v_IMSILTE;
             l_hascheck := 1;
               elsif SP.CODE = 'UimFor4g' then--增加节点 by lixj
             v_Param1 := v_JTZK;
             l_hascheck := 1;

        elsif SP.CODE = 'PhysicalSize' then--增加节点 by fangj
             v_Param1 := v_physicalSize;
             l_hascheck := 1;

        elsif SP.CODE = 'CGSM' then--增加节点 by fangj
             v_Param1 := v_cGSM;
             l_hascheck := 1;

        elsif SP.CODE = 'NearFieldPay' then--增加节点 by fangj
             v_Param1 := v_nearFieldPaye;
             l_hascheck := 1;

        elsif SP.CODE = 'CWSJ' then--增加节点 by fangj
             v_Param1 := v_cWSJ;
             l_hascheck := 1;

        elsif SP.CODE = 'YzfCardNumber' then --翼支付卡号 add by linyzh 2014-11-03 crm00058242
             v_Param1 := v_YZF_CARD;
             l_hascheck := 1;

        elsif SP.CODE = 'PhysicalCard' then --物理卡号 add by linyzh 2014-11-03 crm00058242
             v_Param1 := v_WLK_CARD;
             l_hascheck := 1;

        elsif SP.CODE = 'CardMainType' then --卡大类 add by linyzh 2014-11-24 crm00058242
             v_Param1 := v_CARD_KIND;
             l_hascheck := 1;

        elsif SP.CODE = 'regionCode' then -- 区域 add by linyzh 2015-02-15 crm00060700
             v_Param1 := v_region_code;
             l_hascheck := 1;
          end if;

          if v_Param1 is not null  and l_hascheck = 1  then

             insert into Mkt_Reso_Fea (RESO_FEA_ID, MKT_RESO_ID, FEA_SPEC_ID, PARAM1, PARAM2, PARENT_ID, OP_MODE, SOURCE, MODIFY_CAUSE, REAL_MODIFY_DATE, STATE, MODIFY_DATE, CREATE_DATE)
             values (crmv1.Mkt_Reso_Fea_ID_seq.nextval, v_MKT_RESO_ID, SP.fea_spec_id, v_Param1, '', 0, '', '', '', sysdate, '70A', sysdate, sysdate);

          end if;
      end LOOP;

    if v_Acc_Nbr  is not null then
      select  crmv1.PRODUCT_ID_SEQ.NEXTVAL into o_prodId from  dual;  --预占id
    end if;

    return v_ret;
  end;


  PROCEDURE PROC_importPimRes( v_PESN          in varchar2,
                               v_PROD_SPEC_ID in varchar2,
                               v_CARD_TYPE    in varchar2,
                               v_ACC_NBR      in varchar2,
                               v_AREA_CODE    in varchar2,
                               v_CAPABILITY   in varchar2,
                               v_UPIN1   in varchar2,
                               v_UPIN2   in varchar2,
                               v_PIN2    in varchar2,
                               v_PIN1    in varchar2,
                               v_PASSWD  in varchar2,
                               v_PSNM    in varchar2,
                               v_ICCID   in varchar2,
                               i_ICCS    in varchar2,
                               v_UPIN1_AGENT   in varchar2,  -- 代理商 "UPIN1_AGENT"
                               v_akey in varchar2,        -- e8-C机卡分离  "MY"
                               v_IMSIG in varchar2,--增加节点 by huff
                               v_IMSILTE in varchar2, --增加节点 by huff
                               v_JTZK in varchar2, --增加节点 by lixj
             v_physicalSize in varchar2,---物理尺寸 by fangj
       v_cWSJ in varchar2,---C网数据 by fangj
             v_cGSM in varchar2,---C-G双模 by fangj
             v_nearFieldPaye in varchar2,---近场支付 by fangj
                               v_YZF_CARD in varchar2, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD in varchar2, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND in varchar2, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ in varchar2, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId  out varchar2,
                               o_result            out varchar2,  --校验编码
                               o_msg               out varchar2 --错误信息的返回
                           ) as     -- 返回协议id

   v_ICCS           varchar2(100);
   v_isWriteCardBack number;
   v_isBlankCard     number;
   v_iccid_sub       varchar2(100);
   v_count          number;
   o_prodId_temp    varchar2(20);
   n_ret            number;
   v_err            varchar2(1000);
  begin
    o_result := '1';
    v_ICCS := i_ICCS;
    v_isWriteCardBack := 0;
   -- v_prodFea := i_prodFea;


    if v_ICCS is not null then
       v_isWriteCardBack := 1;
    end if;


    if v_CARD_TYPE = '0006' and  v_PSNM is null  then
      v_err := '白卡导入时，ICCS（空卡序列号）不能为空!';
      o_result := '0';
    end if;

    if v_CARD_TYPE = '0006'  then
      v_isBlankCard := 1;
      v_ICCS := v_PSNM;
      v_iccid_sub := v_PSNM;
    end if;

    if v_ICCID is null and  v_isBlankCard = 0 then
      v_err := 'PIM卡号不能为空!';
      o_result := '0';
    end if;

    if o_result = '1' then
      -- select count(*) into v_count from zb  where zbfl = 'PHS_CDMA_PROD' and zbbm = '3886';  --是否是天翼
      if v_PROD_SPEC_ID = '610003886' then   -- 是否是天翼
        v_count := 1;
      elsif v_PROD_SPEC_ID = '610007525'  then
        v_count := 2;
      else
        v_count := 0;
      end if;

      if v_count = 1  or v_isBlankCard = 1 then

         n_ret := fun_saveUSIMRes(     v_PESN ,
                               v_PROD_SPEC_ID ,
                               v_CARD_TYPE    ,
                               v_ACC_NBR      ,
                               v_AREA_CODE    ,
                               v_CAPABILITY   ,
                               v_UPIN2   ,
                               v_UPIN1   ,
                               v_PIN2    ,
                               v_PIN1    ,
                               v_PASSWD  ,
                               v_PSNM    ,
                               v_ICCID   ,
                               v_ICCS    ,
                               v_iccid_sub ,
                               v_UPIN1_AGENT    ,
                               v_IMSIG,--增加的新节点  by huff
                               v_IMSILTE, -- 增加的新节点  by huff
                               v_JTZK, --增加节点 by lixj
                               v_physicalSize,---物理尺寸 by fangj
             v_cWSJ,---C网数据 by fangj
                               v_cGSM,---C-G双模 by fangj
                               v_nearFieldPaye,---近场支付 by fangj
                               v_YZF_CARD, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId_temp  ,
                               v_err
                           );

      elsif v_count = 2 then

        n_ret := fun_saveJKFLWGRes(     v_PESN         ,
                               v_PROD_SPEC_ID ,
                               v_CARD_TYPE    ,
                               v_ACC_NBR      ,
                               v_AREA_CODE    ,
                               v_CAPABILITY   ,
                               v_UPIN2   ,
                               v_UPIN1   ,
                               v_PIN2    ,
                               v_PIN1    ,
                               v_PASSWD  ,
                               v_PSNM    ,
                               v_ICCID   ,
                               v_ICCS    ,
                               v_iccid_sub ,
                               v_akey,        --DIFF_NBR
                               v_IMSIG,--增加的新节点  by huff
                               v_IMSILTE,--增加的新节点  by huff
                               v_JTZK, --增加节点 by lixj
                               v_physicalSize,---物理尺寸 by fangj
             v_cWSJ,---C网数据 by fangj
                               v_cGSM,---C-G双模 by fangj
                               v_nearFieldPaye,---近场支付 by fangj
                               v_YZF_CARD, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                               v_WLK_CARD, --物理卡号 add by linyzh 2014-11-03 crm00058242
                               v_CARD_KIND, --卡大类 add by linyzh 2014-11-24 crm00058242
                               v_NFC_GJ, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                               o_prodId_temp  ,
                               v_err
                           );

      else

        n_ret :=  fun_saveNewPimRes(v_PESN,
                         v_PROD_SPEC_ID ,
                         v_CARD_TYPE    ,
                         v_ACC_NBR      ,
                         v_AREA_CODE    ,
                         v_CAPABILITY   ,
                         v_UPIN2   ,
                         v_UPIN1   ,
                         v_PIN1    ,
                         v_PIN2    ,
                         v_PASSWD  ,
                         v_PSNM    ,
                         v_ICCID   ,
                         v_ICCS    ,
                         v_iccid_sub ,
                         v_IMSIG,--增加的新节点  by huff
                         v_IMSILTE,--增加的新节点  by huff
                          v_JTZK, --增加节点 by lixj
                               v_physicalSize,---物理尺寸 by fangj
             v_cWSJ,---C网数据 by fangj
                               v_cGSM,---C-G双模 by fangj
                               v_nearFieldPaye,---近场支付 by fangj
                         v_YZF_CARD, --翼支付卡号 add by linyzh 2014-11-03 crm00058242
                         v_WLK_CARD, --物理卡号 add by linyzh 2014-11-03 crm00058242
                         v_CARD_KIND, --卡大类 add by linyzh 2014-11-24 crm00058242
                         v_NFC_GJ, --USIM卡大类，是否支持公交NFC add by chenlinfang crm00064263
                         o_prodId_temp  ,
                         v_err
                     );

      end if;
    end if;
    o_prodId := o_prodId_temp;
    if n_ret > 0 then
      o_result := '1';
      o_msg := '操作成功';
    else
      o_result := '0';
      o_msg := v_err;
    end if;

  EXCEPTION
  WHEN OTHERS THEN
    v_err := 'PROC_importPimRes过程错误';
    o_result := '0';
    o_msg := 'PROC_importPimRes过程错误';
  end PROC_importPimRes;
end PKG_IMPORTPIMRES;
/
