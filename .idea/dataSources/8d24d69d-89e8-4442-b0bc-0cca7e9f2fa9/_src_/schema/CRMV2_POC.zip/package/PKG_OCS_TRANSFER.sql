CREATE PACKAGE           PKG_OCS_TRANSFER IS

  OCS_TRANSFER_CHANNEL_NBR VARCHAR2(20) := '600105A102';

  /*-------------------------------------------------
      功能: 从计费系统把OCS变化数据搬到CRM接口表中。
    -------------------------------------------------*/
  PROCEDURE PROC_EXTRACT_BILL_OCS_TRANSFER ;

  PROCEDURE PROC_LOAD_CRM_OCS_TRANSFER(I_RET_ID           IN NUMBER,  --TFJ_ACC_NBR表的主键
                                       I_PROD_INST_ID     IN NUMBER, --产品实例
                                       I_TRANSFER_TYPE    IN VARCHAR2, --转换类型 O2H –从OCS卸载；H2O –加载到OCS；
                                       I_BATCH_NBR        IN NUMBER  --轮询处理批次号
                                );
  PROCEDURE SP_OCS_TRANSFER_REQUEST(I_RET_ID           IN NUMBER,
                                    I_PROD_INST_ID        IN NUMBER, --产品实例
                                    I_TRANSFER_TYPE       IN VARCHAR2, --转换类型
                                    O_CUST_ORDER_ID       OUT NUMBER ) ;
  PROCEDURE PROC_PROD_INST(I_PROD_INST         IN   PROD_INST%ROWTYPE, --产品实例
                                   I_PAYMENT_MODE_CD   IN   VARCHAR2,  --产品状态, 该参数为NULL时, 不修改产品实例状态
                                   I_STATUS_CD         IN   PROD_INST.STATUS_CD%TYPE ) ;
  PROCEDURE PROC_PROD_INST_ATTR(I_PROD_INST_ATTR   IN   PROD_INST_ATTR%ROWTYPE,  --产品实例
                                I_OPERATE          IN   VARCHAR2
                                    ) ;
  PROCEDURE PROC_PROD_INST_REL (I_PROD_INST_REL IN   PROD_INST_REL%ROWTYPE  --产品实例
                                   ) ;
  PROCEDURE PROC_OFFER_PROD_INST_REL (I_OFFER_PROD_INST_REL IN   OFFER_PROD_INST_REL%ROWTYPE  --产品实例
                                   ) ;
  PROCEDURE PROC_PROD_OFFER_INST (I_PROD_OFFER_INST IN   PROD_OFFER_INST%ROWTYPE  --销售品实例
                                   ) ;

  PROCEDURE PROC_CUSTOMER_ORDER_HIS(I_CUSTOMER_ORDER_HIS  IN OUT CUSTOMER_ORDER_HIS%ROWTYPE,
                                        I_PROD_INST           IN PROD_INST%ROWTYPE );

  PROCEDURE PROC_ORDER_ITEM_HIS(I_ORDER_ITEM_HIS      IN OUT  ORDER_ITEM_HIS%ROWTYPE,
                                    I_ORDER_ITEM_CD   IN      ORDER_ITEM_HIS.ORDER_ITEM_CD%TYPE,
                                    I_SERVICE_OFFER_ID IN     ORDER_ITEM_HIS.SERVICE_OFFER_ID%TYPE,
                                    I_PROD_OFFER_INST IN      PROD_OFFER_INST%ROWTYPE,
                                    I_PROD_INST       IN      PROD_INST%ROWTYPE);
  PROCEDURE PROC_ORDER_ITEM_ACT_RELA_HIS(I_ORDER_ITEM_HIS      IN   ORDER_ITEM_HIS%ROWTYPE,
                                         I_SERVICE_OFFER_ID IN     ORDER_ITEM_HIS.SERVICE_OFFER_ID%TYPE,
                                         I_TARGET           IN     ORDER_ITEM_ACT_RELA.TARGET%TYPE);
  PROCEDURE PROC_ORDER_ITEM_PROC_ATTR_HIS(I_ORDER_ITEM_HIS  IN   ORDER_ITEM_HIS%ROWTYPE,
                                          I_OPERATE         IN     ORDER_ITEM_PROC_ATTR_HIS.OPERATE%TYPE,
                                          I_NEW_VALUE       IN     ORDER_ITEM_PROC_ATTR_HIS.NEW_VALUE%TYPE,
                                          I_OLD_VALUE       IN     ORDER_ITEM_PROC_ATTR_HIS.OLD_VALUE%TYPE,
                                          I_OBJ_ATTR_ID       IN     ORDER_ITEM_PROC_ATTR_HIS.OBJ_ATTR_ID%TYPE );

  PROCEDURE PROC_PF_OCS_TRANSFER_LOG(I_REC_ID        IN PF_OCS_TRANSFER_LOG.REC_ID%TYPE,
                                     I_PROD_INST     IN PROD_INST%ROWTYPE,
                                     I_TAR_PAYMENT_MODE_CD IN PF_OCS_TRANSFER_LOG.TAR_PAYMENT_MODE_CD%TYPE,
                                     I_TRANSFER_TYPE       IN VARCHAR2);

  PROCEDURE PROC_IVPN_NBR(I_REC_ID        IN PF_OCS_TRANSFER_LOG.REC_ID%TYPE,
                          I_PROD_INST     IN PROD_INST%ROWTYPE,
                          I_ORDER_ITEM_ID IN ORDER_ITEM.ORDER_ITEM_ID%TYPE,
                          I_TRANSFER_TYPE       IN VARCHAR2);   --转换类型

END PKG_OCS_TRANSFER;
/
