CREATE PACKAGE BODY           pkg_fy_vip_cust_info IS

FUNCTION func_check_switch_state(table_name       IN VARCHAR2,
                                   o_begin_cycle_id OUT VARCHAR2)
    RETURN BOOLEAN IS
    /*
    功能说明：判断传入的表名在开关表中对应的状态，如果为3则返回True
    编写日期：2013/4/20
    编写人：苏贞森
    */

    i_flag           NUMBER;
    str_msg          VARCHAR2(2000);
    i_begin_cycle_id VARCHAR2(40);
  BEGIN
    BEGIN
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO i_begin_cycle_id
        FROM doone_int_status@lk_fj_vip a
       WHERE lower(a.src_table_name) = lower(table_name)
         AND a.INT_NAME = 'FY_VIP_INFO_TO_CRM';

      o_begin_cycle_id := i_begin_cycle_id;

      SELECT a.flag
        INTO i_flag
        FROM doone_int_status@lk_fj_vip a
       WHERE lower(a.src_table_name) = lower(table_name)
         AND a.flag = 3
         AND a.begin_cycle_id = i_begin_cycle_id
         AND a.INT_NAME = 'FY_VIP_INFO_TO_CRM';
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO fy_vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_fy_vip_info_log_id.nextval, 'fy查询开关状态' || table_name, str_msg, SYSDATE);
        COMMIT;
        RETURN FALSE;
    END;

    IF i_flag = 3
    THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END;
  PROCEDURE proc_insert_fy_vip_info_all is
    /*
    功能说明：插入fy_vip信息表
    编写日期：2013/4/20
    编写人：苏贞森
    */
    str_msg VARCHAR2(2000);
    i_count NUMBER := 0;
  BEGIN
    BEGIN
      /**先清空会员信息表**/
      EXECUTE IMMEDIATE 'truncate table FY_VIP_CUST_INFO_ALL';

      INSERT INTO FY_VIP_CUST_INFO_ALL
        (VIP_NBR, PROD_ID, CUST_ID, ID_CARD, VIP_LEVEL, ANURE_TIME, ABATE_TIME, INTEGRAL_GROUP, EVALUE, USED_INTEGR, YEAR_USED_INTEGR,
         CURR_INTEGR, OPTER_TYPE, AREACODE, AREA_ID, CYCLE_CURR_INTEGRAL, CYCLE_USED_INTEGRAL, CYCLE_NEW_INTEGRAL, ETL_DATE)
        SELECT to_char(FY_VIP_NBR), PROD_ID,to_char(CUST_ID), CERTIFICATE_NO, VIP_LEVEL,to_date(ANURE_TIME, 'yyyymmddhh24miss'),to_date(ABATE_TIME, 'yyyymmddhh24miss'), INTEGRAL_GROUP, to_char(MVALUE), USED_GOLD, THIS_YEAR_USED_GOLD,
         CURR_GOLD,OPTER_TYPE,AREACODE, nvl(to_char(AREA_ID), '00'), to_char(CYCLE_CURR_GOLD), to_char(CYCLE_USED_GOLD), to_char(CYCLE_ADD_GOLD),sysdate
          FROM jf4q.fy_vip_cust_info_all@lk_fj_fy_vip
         WHERE
         1 = 1
        MINUS
        SELECT to_char(VIP_NBR),PROD_ID,to_char(CUST_ID), ID_CARD,VIP_LEVEL,ANURE_TIME,ABATE_TIME, INTEGRAL_GROUP,to_char(EVALUE), USED_INTEGR, YEAR_USED_INTEGR,
         CURR_INTEGR,OPTER_TYPE,AREACODE,nvl(to_char(AREA_ID), '00'),to_char(CYCLE_CURR_INTEGRAL),to_char(CYCLE_USED_INTEGRAL), to_char(CYCLE_NEW_INTEGRAL),sysdate
          FROM FY_VIP_CUST_INFO_ALL
         WHERE
         1 = 1;
      COMMIT;
      SELECT COUNT(*) INTO i_count FROM FY_VIP_CUST_INFO_ALL;
      INSERT INTO fy_vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_fy_vip_info_log_id.nextval, '更新fy_vip信息记录数' || i_count, '', SYSDATE);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO fy_vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_fy_vip_info_log_id.nextval, '插入fy_vip信息表', str_msg, SYSDATE);
        COMMIT;

        NULL;
    END;
  END;


  PROCEDURE proc_sync_fy_vip_info is
  /*
    功能说明：同步数据到CRM
    编写日期：2013/4/20
    编写人：苏贞森
    */
    i_result  BOOLEAN;
    o_begin_cycle_id VARCHAR2(40);
  BEGIN

    INSERT INTO fy_vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_fy_vip_info_log_id.nextval, 'fy同步开始', '', SYSDATE);
    COMMIT;

    i_result := func_check_switch_state('FY_VIP_CUST_INFO_ALL', o_begin_cycle_id);

    IF i_result = TRUE
    THEN
      /**同步数据**/
      proc_insert_fy_vip_info_all;

      /**修改开关表状态**/
      UPDATE doone_int_status@lk_fj_vip a
         SET a.flag = 4, a.crm_end_time = SYSDATE
       WHERE lower(a.src_table_name) = lower('FY_VIP_CUST_INFO_ALL')
         AND a.flag = 3
         AND a.begin_cycle_id = o_begin_cycle_id
         AND a.INT_NAME = 'FY_VIP_INFO_TO_CRM';
      COMMIT;
    END IF;

    INSERT INTO fy_vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_fy_vip_info_log_id.nextval, 'fy同步结束', '', SYSDATE);
    COMMIT;

  END;

END pkg_fy_vip_cust_info;
/
