CREATE PACKAGE           PKG_GG_523  IS

  -- Author  : QIURL
  -- Created : 2013/5/13
  -- Purpose :集团数据增量脚本

  PROCEDURE PROC_DATA_SYNC;

  FUNCTION  FUNC_CALC_BATCH_NBR RETURN VARCHAR2;

  PROCEDURE PROC_JOB_SUBMIT(V_BATCH_NBR VARCHAR2);

  --同步 CUST 表数据
  PROCEDURE PROC_BUS26001_R_FZ(IN_BATCH_NBR VARCHAR2)  ;

  --同步 PARTY_CONTACT_INFO 表数据
  PROCEDURE PROC_BUS26002_R(IN_BATCH_NBR VARCHAR2)  ;

  --同步 PARTY_CERTIFICATION 表数据
  PROCEDURE PROC_BUS26003_R(IN_BATCH_NBR VARCHAR2)  ;

  --同步 ACCOUNT 表数据
  PROCEDURE PROC_BUS26008_R(IN_BATCH_NBR VARCHAR2)  ;

  --同步 PAYMENT_PLAN 表数据
  PROCEDURE PROC_BUS26009_R(IN_BATCH_NBR VARCHAR2)  ;

  --同步 PROD_INST_ATTR 表数据
  PROCEDURE PROC_BUS26012_R_FZ(IN_BATCH_NBR VARCHAR2)  ;

  --同步 PROD_INST_ACCT 表数据
  PROCEDURE PROC_BUS26013_R(IN_BATCH_NBR VARCHAR2)  ;

  --同步 PROD_INST 表数据
  PROCEDURE PROC_BUS26010_R (I_BATCH_NBR VARCHAR2,I_PARTITION_NAME VARCHAR2)  ;
  PROCEDURE PROC_BUS26010_R_101_IU (I_BATCH_NBR      IN VARCHAR2,
                                    I_PARTITION_NAME IN VARCHAR2,
                                    I_PROCEDURE_NAME IN VARCHAR2,
                                    I_ACTION_TYPE    IN VARCHAR2,
                                    O_SUCC_CNT       OUT NUMBER,
                                    O_FAIL_CNT       OUT NUMBER )  ;
  PROCEDURE PROC_BUS26010_R_101_IU_HIS (I_BATCH_NBR      IN VARCHAR2,
                                        I_PARTITION_NAME IN VARCHAR2,
                                        I_PROCEDURE_NAME IN VARCHAR2,
                                        I_ACTION_TYPE    IN VARCHAR2,
                                        O_SUCC_CNT       OUT NUMBER,
                                        O_FAIL_CNT       OUT NUMBER )  ;
  PROCEDURE PROC_BUS26010_R_102_IU (I_BATCH_NBR      IN VARCHAR2,
                                    I_PARTITION_NAME IN VARCHAR2,
                                    I_PROCEDURE_NAME IN VARCHAR2,
                                    I_ACTION_TYPE    IN VARCHAR2,
                                    O_SUCC_CNT       OUT NUMBER,
                                    O_FAIL_CNT       OUT NUMBER )  ;


  --同步 PROD_OFFER_INST 表数据
  PROCEDURE PROC_BUS26027_R(I_BATCH_NBR VARCHAR2,I_PARTITION_NAME VARCHAR2)  ;
  PROCEDURE PROC_BUS26027_R_IU (I_BATCH_NBR      IN VARCHAR2,
                                  I_PARTITION_NAME IN VARCHAR2,
                                  I_PROCEDURE_NAME IN VARCHAR2,
                                  I_ACTION_TYPE    IN VARCHAR2,
                                  O_SUCC_CNT       OUT NUMBER,
                                  O_FAIL_CNT       OUT NUMBER )  ;
  PROCEDURE PROC_BUS26027_R_D (I_BATCH_NBR      IN VARCHAR2,
                                  I_PARTITION_NAME IN VARCHAR2,
                                  I_PROCEDURE_NAME IN VARCHAR2,
                                  I_ACTION_TYPE    IN VARCHAR2,
                                  O_SUCC_CNT       OUT NUMBER,
                                  O_FAIL_CNT       OUT NUMBER )  ;

  --同步 PROD_OFFER_INST 表数据
  PROCEDURE PROC_BUS26014_R_FZ(IN_BATCH_NBR VARCHAR2)  ;



END PKG_GG_523;
/
