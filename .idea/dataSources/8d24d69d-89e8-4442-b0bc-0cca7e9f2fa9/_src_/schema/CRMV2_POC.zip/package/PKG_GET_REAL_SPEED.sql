CREATE package           PKG_GET_REAL_SPEED is

  -- Author  : fzn
  -- Created : 2013-3-19 14:38:36
  -- Purpose : 网龄自动提速

  -- 网龄自动提速
  function getGXNetAgeUpSpeed(i_prodInstId   In number,
                              old_sjslspecid In number,
                              o_result       out varchar2) --收集报错信息
   return number; --光纤网龄提速计算

  PROCEDURE getProdRealSpeed(i_prodInstId    IN NUMBER, -- 产品对应的实例id
                             o_realfeaspecid out NUMBER, -- 若返回0，表示不需要做任何操作，-1 为错误
                             o_result        out varchar2 --如果有错，返回错误信息
                             );
  --自动提速 job自动跑
  procedure autoNetAgeUpSpeed;

end PKG_GET_REAL_SPEED;
/
