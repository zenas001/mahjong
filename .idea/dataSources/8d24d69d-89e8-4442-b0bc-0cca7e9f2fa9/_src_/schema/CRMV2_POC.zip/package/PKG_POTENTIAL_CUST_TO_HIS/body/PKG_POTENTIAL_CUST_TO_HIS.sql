CREATE PACKAGE body           pkg_potential_cust_to_his IS
PROCEDURE insert_log(i_msg        IN VARCHAR2,
                       i_err        IN VARCHAR2,
                       i_key_id     IN NUMBER,
                       i_table_name IN VARCHAR2) IS
  BEGIN
    BEGIN
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval, i_msg, i_err, SYSDATE);
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  END;
  ---判断客户是否符合潜在或者离网的条件
  FUNCTION check_cust_cond(i_cust_id IN NUMBER, i_status_cd IN VARCHAR2)
    RETURN BOOLEAN IS
    str_msg VARCHAR2(2000);
    v_cnt   NUMBER := 0;

  BEGIN
    BEGIN
      IF i_status_cd = '1100'
      THEN
        ---非产权客户
        SELECT COUNT(*)
          INTO v_cnt
          FROM prod_inst pi
         WHERE pi.owner_cust_id = i_cust_id
           AND pi.status_cd != '110000';

        IF v_cnt > 0
        THEN
          RETURN FALSE;
        END IF;

        SELECT COUNT(*)
          INTO v_cnt
          FROM prod_offer_inst poi
         WHERE poi.cust_id = i_cust_id
           AND poi.status_cd != '1100';

        IF v_cnt > 0
        THEN
          RETURN FALSE;
        END IF;

        ---非使用客户
        SELECT COUNT(*)
          INTO v_cnt
          FROM prod_inst p
         WHERE p.use_cust_id = i_cust_id
           AND p.status_cd != '110000';

        IF v_cnt > 0
        THEN
          RETURN FALSE;
        END IF;

        ---没有支付账户
        SELECT COUNT(*)
          INTO v_cnt
          FROM account ac, prod_inst_acct pia
         WHERE ac.status_cd != '1100'
           AND pia.status_cd != '1100'
           AND ac.cust_id = i_cust_id
           AND ac.account_id = pia.account_id;

        IF v_cnt > 0
        THEN
          RETURN FALSE;
        END IF;
      END IF;
      ----没有在途单
      SELECT COUNT(*)
        INTO v_cnt
        FROM customer_order co
       WHERE co.cust_id = i_cust_id;

      IF v_cnt > 0
      THEN
        RETURN FALSE;
      END IF;

      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        insert_log('查询客户是否符合条件失败', str_msg, i_cust_id, 'CUST');
        NULL;
        RETURN FALSE;
    END;
  END;
  ---将客户数据移到2表
  FUNCTION move_to_his(i_cust_id IN NUMBER, i_rec_update_date IN DATE)
    RETURN BOOLEAN IS
    str_msg VARCHAR2(2000);

  BEGIN
    BEGIN
      ---插入数据到2表
      INSERT INTO cust_his
        (cust_id, common_region_id, party_id, cust_number, cust_address, cust_type, cust_sub_type, cust_area_grade, group_cust_seq, important_level, enter_date, create_date, status_cd, status_date, mod_date, staff_id, industry_cd, update_date, proc_serial, area_id, region_cd, update_staff, create_staff, his_id, cust_address_id, rec_update_date, cur_year_type)
        SELECT cust_id, common_region_id, party_id, cust_number, cust_address, cust_type, cust_sub_type, cust_area_grade, group_cust_seq, important_level, enter_date, create_date, status_cd, status_date, mod_date, staff_id, industry_cd, update_date, proc_serial, area_id, region_cd, update_staff, create_staff, seq_cust_his_id.nextval, cust_address_id, i_rec_update_date, cur_year_type
          FROM cust a
         WHERE a.cust_id = i_cust_id;
        delete crmv2.cust a where a.cust_id=i_cust_id;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        insert_log('插入客户记录到2表失败', str_msg, i_cust_id, 'CUST');
        NULL;
        RETURN FALSE;
    END;
  END;
  --移动潜在客户到二表
  PROCEDURE move_potential_cust_to_his IS

    v_result BOOLEAN;
    str_msg  VARCHAR2(2000);
    v_date   DATE;

  BEGIN
    insert_log('开始把潜在客户移入二表', 'move_potential_cust_to_his', '', 'CUST');

    FOR rec IN (SELECT * FROM cust a WHERE a.status_cd = '1000' and a.create_date<(select add_months(sysdate,-12) from dual))
    LOOP
      BEGIN
          v_result := check_cust_cond(rec.cust_id, rec.status_cd);
          IF v_result
          THEN
          v_date   := SYSDATE;
          v_result := move_to_his(rec.cust_id, v_date);
          IF v_result = TRUE
          THEN
            BEGIN
              ---送批量计费接口
              basejk.pkg_common.proc_intf_ins_billing_update('CUST', 'CUST_ID', rec.cust_id, 'pkg_potential_cust_to_his  一年内未使用的潜在客户移入二表', '1002', 'pkg_potential_cust_to_his  一年内未使用的潜在客户移入二表', '', '590');
            EXCEPTION
              WHEN OTHERS THEN
                str_msg := substr(SQLERRM, 0, 1000);
                insert_log('把潜在客户移入二表失败', str_msg, rec.cust_id, 'CUST');
                NULL;

            END;

           END IF;

        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          insert_log('提交失败', str_msg, '', 'CUST');
          --COMMIT;
          NULL;

      END;

    END LOOP;

    BEGIN
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);

        insert_log('提交失败', str_msg, '', 'CUST');
        NULL;

    END;

    insert_log('结束把潜在客户移入二表失败', 'move_potential_cust_to_his', '', 'CUST');

  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);

      insert_log('执行失败-move_potential_cust_to_his', str_msg, '', 'CUST');

  END;


    ---主存储过程
  PROCEDURE main IS
  BEGIN
    insert_log('开始把潜在客户移入二表', 'main', '', 'CUST');

    move_potential_cust_to_his;

    insert_log('结束把潜在客户移入二表', 'main', '', 'CUST');

    COMMIT;
  END;


END pkg_potential_cust_to_his;
/
