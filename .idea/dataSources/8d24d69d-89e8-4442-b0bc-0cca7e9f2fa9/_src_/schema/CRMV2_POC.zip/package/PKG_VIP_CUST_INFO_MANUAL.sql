CREATE PACKAGE           pkg_vip_cust_info_manual IS

  -- Author  : linzhiqiang
  -- Created : 2012-5-31 15:01:04
  -- Purpose : 同步VIP信息

  /*判断开关状态*/
  FUNCTION func_check_switch_state(table_name       IN VARCHAR2,
                                   i_begin_cycle_id IN VARCHAR2)
    RETURN BOOLEAN; ----入参：表名,周期

  /*插入记录到二表*/
  FUNCTION func_insert_member_info_his(i_member_code IN VARCHAR2)
    RETURN BOOLEAN; ----入参：vip_Nbr

  /*插入记录到二表*/
  FUNCTION func_insert_club_member_his(i_member_code IN VARCHAR2,
                                       i_party_id    IN NUMBER,
                                       i_cust_id     IN NUMBER)
    RETURN BOOLEAN; ----入参：vip_Nbr

  /*转换等级主数据*/
  FUNCTION func_convert_meta_data(i_vip_level IN VARCHAR2) RETURN VARCHAR2; ----入参：vip级别

  /*插入积分关联数据到临时表*/
  PROCEDURE proc_insert_vip_rela_info2temp;

  /*插入积分数据到临时表*/
  PROCEDURE proc_insert_vip_info2temp;

  /*更新club_member_info记录*/
  PROCEDURE proc_update_club_member_info;

  /*更新关联表记录*/
  PROCEDURE proc_update_club_member;

  /*主方法*/
  PROCEDURE proc_sync_vip_info(i_begin_cycle IN VARCHAR2);

END pkg_vip_cust_info_manual;
/
