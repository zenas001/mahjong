CREATE package           pkg_grid is

  --模块：渠道子域（网格）
  --时间：2011-03-22
  --功能：
  ----1、产品实例自动划配到网格
  ------prodinstgridrel
  ----2、规则变更后产品实例自动重新划配到新网格
  ------update_grid_rule_inst
  ----3、客户自动划配到客户经理
  ------custassignrel

  -------------------按产品地址取网格-------------------
  procedure p_prod_address_grid(i_prod_inst_id       in number,
                                o_grid_rule_inst_lst out t_grid_rule_inst_lst);

  -------------------按产品设备取网格-------------------
  procedure p_prod_device_grid(i_prod_inst_id       in number,
                               o_grid_rule_inst_lst out t_grid_rule_inst_lst);

  -------------------按号段取网格-------------------
  procedure p_prod_sec_grid(i_prod_inst_id       in number,
                            o_grid_rule_inst_lst out t_grid_rule_inst_lst);

  -------------------按待划配取网格-------------------
  procedure p_prod_dhp_grid(i_prod_inst_id       in number,
                            o_grid_rule_inst_lst out t_grid_rule_inst_lst);

  -------------------产品实例自动划配到网格
  procedure p_prod_inst_grid_rel(i_prod_inst_id in number,
                                 o_state        out number,
                                 o_msg          out varchar2);

  -------------------客户自动划配到客户经理
  procedure p_cust_grid_rel(i_cust_id in number,
                            o_state   out number,
                            o_msg     out varchar2);

  ----1、订单接口进行产品实例客户划配到网格
  procedure p_main_customer_order;

  ----2、规则变更后产品实例自动重新划配到新网格
  procedure p_main_update_grid_rule_inst;

  ----3、人工划配产品到网格后，客户重新划配到新网格
  procedure p_main_grid_reassign;

  ----4、客户、产品营销和维系关系
  procedure p_main_cust_prod_inst_rel;

end;
/
