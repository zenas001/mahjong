CREATE PACKAGE BODY           DELETE_INST_HIS_DATA_PACK IS

  PROCEDURE DELETE_INST_HIS_DATA IS
    B_PROD_INST  BOOLEAN;
    B_OFFER_INST BOOLEAN;
  BEGIN
    B_PROD_INST := FUNC_HIS_PROD_INTF(ADD_MONTHS(SYSDATE, -6),
                                      ADD_MONTHS(SYSDATE, -6) - 3);
    /*
    B_PROD_INST := FUNC_HIS_PROD_INTF(to_date('06-12-2014 00:00:00', 'dd-mm-yyyy hh24:mi:ss'),
                                      to_date('04-12-2014 00:00:00', 'dd-mm-yyyy hh24:mi:ss'));
                                      */
    COMMIT;
  END;


  PROCEDURE DELETE_OFFER_INST_HIS_DATA IS
    B_PROD_INST  BOOLEAN;
    B_OFFER_INST BOOLEAN;
  BEGIN
    B_PROD_INST := FUNC_HIS_PROD_OFFER_INTF(ADD_MONTHS(SYSDATE, -6),
                                            ADD_MONTHS(SYSDATE, -6) - 3);
    /*
    B_PROD_INST := FUNC_HIS_PROD_INTF(to_date('06-12-2014 00:00:00', 'dd-mm-yyyy hh24:mi:ss'),
                                      to_date('04-12-2014 00:00:00', 'dd-mm-yyyy hh24:mi:ss'));
                                      */
    COMMIT;
  END;

  FUNCTION FUNC_HIS_PROD_OFFER_INTF(BEGIN_ITEM  IN DATE,
                                    FINISH_TIME IN DATE) RETURN BOOLEAN IS

    D_BEGIN_ITEM          DATE;
    D_FINISH_TIME         DATE;
    B_OFFER_INST_ADD      BOOLEAN;
    B_OFFER_INST_ATTR_ADD BOOLEAN;
    B_OFFER_INST_DEL      BOOLEAN;
    B_OFFER_INST_ATTR_DEL BOOLEAN;

    CURSOR PROD_OFFER_INST_HIS_ID IS
      select POI.PROD_OFFER_INST_ID,
             rownum,
             POI.UPDATE_DATE,
             POI.PROC_SERIAL
        from PROD_OFFER_INST POI
       where POI.STATUS_CD = '1100'
         AND POI.UPDATE_DATE < D_BEGIN_ITEM
         AND POI.UPDATE_DATE > D_FINISH_TIME
         AND NOT EXISTS
       (select oi.order_item_id
                from order_item oi
               where oi.order_item_id = POI.PROC_SERIAL);
  BEGIN
    D_BEGIN_ITEM  := BEGIN_ITEM;
    D_FINISH_TIME := FINISH_TIME;
    FOR CUR IN PROD_OFFER_INST_HIS_ID LOOP
      BEGIN
        B_OFFER_INST_ADD      := DELETE_HIS_PROD_OFFER_INST(CUR.Prod_Offer_Inst_Id);
        B_OFFER_INST_ATTR_ADD := DELETE_HIS_POI_ATTR(CUR.Prod_Offer_Inst_Id);
        B_OFFER_INST_DEL      := DELETE_PROD_OFFER_INST(CUR.Prod_Offer_Inst_Id);
        B_OFFER_INST_ATTR_DEL := DELETE_PROD_OFFER_INST_ATTR(CUR.Prod_Offer_Inst_Id);
        IF MOD(CUR.rownum, 1000) = 0 then
          COMMIT;
        END if;
      END;
    END LOOP;
    COMMIT;
    RETURN TRUE;
  END;

  FUNCTION FUNC_HIS_PROD_INTF(BEGIN_ITEM IN DATE, FINISH_TIME IN DATE)
    RETURN BOOLEAN IS
    D_BEGIN_ITEM         DATE;
    D_FINISH_TIME        DATE;
    B_PROD_INST_ADD      BOOLEAN;
    B_PROD_INST_ATTR_ADD BOOLEAN;
    B_PROD_INST_DEL      BOOLEAN;
    B_PROD_INST_ATTR_DEL BOOLEAN;
    CURSOR PROD_INST_HIS_ID IS
      select PI.PROD_INST_ID, rownum, PI.UPDATE_DATE, PI.PROC_SERIAL
        from PROD_INST PI
       where PI.STATUS_CD = '110000'
         AND PI.UPDATE_DATE < D_BEGIN_ITEM
         AND PI.UPDATE_DATE > D_FINISH_TIME
         AND NOT EXISTS
       (select oi.order_item_id
                from order_item oi
               where oi.order_item_id = PI.PROC_SERIAL);

  BEGIN
    D_BEGIN_ITEM  := BEGIN_ITEM;
    D_FINISH_TIME := FINISH_TIME;
    FOR CUR IN PROD_INST_HIS_ID LOOP
      BEGIN
        B_PROD_INST_ADD      := DELETE_HIS_PROD_INST(CUR.PROD_INST_ID);
        B_PROD_INST_DEL      := DELETE_PROD_INST(CUR.PROD_INST_ID);
        B_PROD_INST_ATTR_ADD := DELETE_HIS_PROD_INST_ATTR(CUR.PROD_INST_ID);
        B_PROD_INST_ATTR_DEL := DELETE_PROD_INST_ATTR(CUR.PROD_INST_ID);

        IF MOD(CUR.rownum, 1000) = 0 then
          COMMIT;
        END if;
      END;
    END LOOP;
    COMMIT;

    RETURN TRUE;
  END;

  FUNCTION DELETE_PROD_INST(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;
    DELETE from prod_inst pi where pi.prod_inst_id = I_ID;
    RETURN TRUE;
  END;

  FUNCTION DELETE_PROD_OFFER_INST(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;
    DELETE from PROD_OFFER_INST poi where poi.prod_offer_inst_id = I_ID;
    RETURN TRUE;
  END;
  FUNCTION DELETE_PROD_INST_ATTR(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;
    delete from PROD_INST_ATTR pia where pia.prod_inst_id = I_ID;
    RETURN TRUE;
  END;
  FUNCTION DELETE_PROD_OFFER_INST_ATTR(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;
    delete from PROD_OFFER_INST_ATTR poia
     where poia.prod_offer_inst_id = I_ID;
    RETURN TRUE;
  END;

  FUNCTION DELETE_HIS_PROD_INST(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;

    insert into prod_inst_third
      (PROD_INST_ID,
       PRODUCT_ID,
       ACC_PROD_INST_ID,
       ADDRESS_ID,
       OWNER_CUST_ID,
       PAYMENT_MODE_CD,
       PRODUCT_PASSWORD,
       IMPORTANT_LEVEL,
       AREA_CODE,
       ACC_NBR,
       EXCH_ID,
       COMMON_REGION_ID,
       REMARK,
       PAY_CYCLE,
       BEGIN_RENT_TIME,
       STOP_RENT_TIME,
       FINISH_TIME,
       STOP_STATUS,
       STATUS_CD,
       CREATE_DATE,
       STATUS_DATE,
       UPDATE_DATE,
       PROC_SERIAL,
       USE_CUST_ID,
       EXT_PROD_INST_ID,
       ADDRESS_DESC,
       AREA_ID,
       UPDATE_STAFF,
       CREATE_STAFF,
       REC_UPDATE_DATE,
       ACCOUNT,
       VERSION,
       COMMUNITY_ID,
       EXT_ACC_PROD_INST_ID,
       DISTRIBUTOR_ID)
      (select PROD_INST_ID,
              PRODUCT_ID,
              ACC_PROD_INST_ID,
              ADDRESS_ID,
              OWNER_CUST_ID,
              PAYMENT_MODE_CD,
              PRODUCT_PASSWORD,
              IMPORTANT_LEVEL,
              AREA_CODE,
              ACC_NBR,
              EXCH_ID,
              COMMON_REGION_ID,
              REMARK,
              PAY_CYCLE,
              BEGIN_RENT_TIME,
              STOP_RENT_TIME,
              FINISH_TIME,
              STOP_STATUS,
              STATUS_CD,
              CREATE_DATE,
              STATUS_DATE,
              UPDATE_DATE,
              PROC_SERIAL,
              USE_CUST_ID,
              EXT_PROD_INST_ID,
              ADDRESS_DESC,
              AREA_ID,
              UPDATE_STAFF,
              CREATE_STAFF,
              REC_UPDATE_DATE,
              ACCOUNT,
              VERSION,
              COMMUNITY_ID,
              EXT_ACC_PROD_INST_ID,
              DISTRIBUTOR_ID
         from prod_inst pi
        where pi.prod_inst_id = I_ID);

    RETURN TRUE;
  END;

  FUNCTION DELETE_HIS_PROD_OFFER_INST(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;
    insert into PROD_OFFER_INST_THIRD
      (PROD_OFFER_INST_ID,
       PROD_OFFER_ID,
       CUST_ID,
       CHANNEL_ID,
       CREATE_DATE,
       STATUS_CD,
       STATUS_DATE,
       EFF_DATE,
       EXP_DATE,
       REGION,
       UPDATE_DATE,
       PROC_SERIAL,
       EXT_PROD_OFFER_INST_ID,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       TRIAL_EFF_DATE,
       TRIAL_EXP_DATE,
       REC_UPDATE_DATE,
       SERVICE_NBR,
       VERSION,
       END_AUTO,
       REMARK,
       WH_REMARK,
       EXT_FLAG1,
       EXT_FLAG2,
       DISTRIBUTOR_ID)
      (select PROD_OFFER_INST_ID,
              PROD_OFFER_ID,
              CUST_ID,
              CHANNEL_ID,
              CREATE_DATE,
              STATUS_CD,
              STATUS_DATE,
              EFF_DATE,
              EXP_DATE,
              REGION,
              UPDATE_DATE,
              PROC_SERIAL,
              EXT_PROD_OFFER_INST_ID,
              AREA_ID,
              REGION_CD,
              UPDATE_STAFF,
              CREATE_STAFF,
              TRIAL_EFF_DATE,
              TRIAL_EXP_DATE,
              REC_UPDATE_DATE,
              SERVICE_NBR,
              VERSION,
              END_AUTO,
              REMARK,
              WH_REMARK,
              EXT_FLAG1,
              EXT_FLAG2,
              DISTRIBUTOR_ID
         from prod_offer_inst poi
        where poi.prod_offer_inst_id = I_ID);
    RETURN TRUE;
  END;

  FUNCTION DELETE_HIS_PROD_INST_ATTR(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;
    insert into PROD_INST_ATTR_THIRD
      (PROD_INST_ATTR_ID,
       PROD_INST_ID,
       ATTR_ID,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       STATUS_CD,
       STATUS_DATE,
       EFF_DATE,
       EXP_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       PROC_SERIAL,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       REC_UPDATE_DATE,
       VERSION)
      (select PROD_INST_ATTR_ID,
              PROD_INST_ID,
              ATTR_ID,
              ATTR_VALUE_ID,
              ATTR_VALUE,
              STATUS_CD,
              STATUS_DATE,
              EFF_DATE,
              EXP_DATE,
              CREATE_DATE,
              UPDATE_DATE,
              PROC_SERIAL,
              AREA_ID,
              REGION_CD,
              UPDATE_STAFF,
              CREATE_STAFF,
              REC_UPDATE_DATE,
              VERSION
         from PROD_INST_ATTR pia
        where pia.prod_inst_id = I_ID);
    RETURN TRUE;
  END;

  FUNCTION DELETE_HIS_POI_ATTR(ID IN NUMBER) RETURN BOOLEAN IS
    I_ID NUMBER;
  BEGIN
    I_ID := ID;
    insert into PROD_OFFER_INST_ATTR_THIRD
      (PROD_OFFER_INST_ATTR_ID,
       PROD_OFFER_INST_ID,
       ATTR_ID,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE,
       EXP_DATE,
       EFF_DATE,
       STATUS_DATE,
       STATUS_CD,
       UPDATE_DATE,
       PROC_SERIAL,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       REC_UPDATE_DATE,
       VERSION)
      (select PROD_OFFER_INST_ATTR_ID,
              PROD_OFFER_INST_ID,
              ATTR_ID,
              ATTR_VALUE_ID,
              ATTR_VALUE,
              CREATE_DATE,
              EXP_DATE,
              EFF_DATE,
              STATUS_DATE,
              STATUS_CD,
              UPDATE_DATE,
              PROC_SERIAL,
              AREA_ID,
              REGION_CD,
              UPDATE_STAFF,
              CREATE_STAFF,
              REC_UPDATE_DATE,
              VERSION
         from PROD_OFFER_INST_ATTR poia
        where poia.prod_offer_inst_id = I_ID);
    RETURN TRUE;
  END;
END DELETE_INST_HIS_DATA_PACK;
/
