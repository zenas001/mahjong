CREATE package body           PKG_NX_INTF_WEIHU is
  /*
    -- Author  : chenjiangyuan
    -- Created : 2013/10/20
    -- Purpose : 集团漏送数据重送集团
    --modified : liufengzhen 20131026
    --modified : Hehuang 20131127 修改内容：1、修改intf_orer_resend_time结构，作为日志表使用2、时间连续性修正
  */
  procedure proc_intf_resend_data is
    v_end_deal_time   date; --记录处理截止时间
    v_begin_deal_time date; --记录处理开始时间
    v_err_msg         VARCHAR2(4000);
    v_result          VARCHAR2(4000) := '操作成功';
  begin
    /*设置查询开始及结束时间*/
    --本次处理截止时间为系统时间
    v_end_deal_time := sysdate;
    --本次处理开始时间为上一次处理截止时间
    select max(end_deal_time)
      into v_begin_deal_time
      from intf_orer_resend_time;
    IF v_begin_deal_time IS NULL THEN
       --重置处理时间
        insert into basejk.intf_orer_resend_time
          (resend_id, begin_deal_time, end_deal_time, err_msg)
        values
          (basejk.seq_intf_orer_resend_time_id.nextval,
           v_end_deal_time,
           v_end_deal_time,
           '找不到处理截止时间！重置处理时间为系统时间');
        commit;
        return;
    END IF;
    for aa in (
               --1、 针对销售品,产品拆情况
               select distinct a.channel_nbr,
                                f.intf_all_id,
                                f.acc_nbr,
                                b.cust_so_number
                 from crmv2.intf_define_config  a,
                       crmv2.customer_order_his  b,
                       crmv2.order_item_his      c,
                       crmv2.prod_offer_inst_his d,
                       crmv2.prod_offer          e,
                       basejk.intf_all           f,
                       crmv2.service_offer       g
                where b.create_date between v_begin_deal_time and
                      v_end_deal_time
                  and b.cust_order_id = c.cust_order_id
                  and c.order_item_cd = '1200' --销售品订单项
                  and c.order_item_obj_id = d.prod_offer_inst_id
                  and d.prod_offer_id = e.prod_offer_id
                  and a.prod_offer_id = d.prod_offer_id
                  and a.service_offer_code = '3030100000' --目前只发现拆机漏送
                  and to_char(a.service_offer_code) = g.standard_cd
                  and g.service_offer_id = c.service_offer_id
                  and b.cust_so_number = f.cust_so_number
                  and f.service_offer_id = '101'
                  and (a.product_id is null or exists
                       (select 1
                          from crmv2.offer_prod_inst_rel_his opirh,
                               crmv2.prod_inst_his           pih
                         where d.prod_offer_inst_id = opirh.prod_offer_inst_id
                           and opirh.prod_inst_id = pih.prod_inst_id
                           and pih.product_id = a.product_id))
                  and not exists
                (select 1
                         from basejk.intf_all kk
                        where kk.acc_nbr = f.acc_nbr
                          and kk.intf_all_id = f.intf_all_id
                          and kk.acc_nbr = '999' || to_char(order_item_id))
                  and not exists ( --没有送外围的单子
                       select 1
                         from basejk.intf_order g
                        where g.intf_all_id = f.intf_all_id
                          and g.channel_nbr = a.channel_nbr
                          and g.acc_nbr = f.acc_nbr)
               --2、针对产品拆情况
               union
               select distinct a.channel_nbr,
                               f.intf_all_id,
                               f.acc_nbr,
                               b.cust_so_number
                 from crmv2.intf_define_config a,
                      crmv2.customer_order_his b,
                      crmv2.order_item_his     c,
                      crmv2.prod_inst_his      d,
                      crmv2.product            e,
                      basejk.intf_all          f,
                      crmv2.service_offer      g
                where b.create_date between v_begin_deal_time and
                      v_end_deal_time
                  and b.cust_order_id = c.cust_order_id
                  and c.order_item_cd = '1300' --产品订单项
                  and c.order_item_obj_id = d.prod_inst_id
                  and d.product_id = e.product_id
                  and a.product_id = d.product_id
                  and a.service_offer_code = '4020100000' --目前只发现拆机漏送
                  and b.cust_so_number = f.cust_so_number
                  and to_char(a.service_offer_code) = g.standard_cd
                  and g.service_offer_id = c.service_offer_id
                  and (a.prod_offer_id is null or exists
                       (select 1
                          from crmv2.offer_prod_inst_rel_his opirh,
                               crmv2.prod_offer_inst         poi
                         where d.prod_inst_id = opirh.prod_inst_id
                           and poi.prod_offer_inst_id =
                               opirh.prod_offer_inst_id
                           and a.prod_offer_id = poi.prod_offer_id))
                  and f.service_offer_id = '101'
                  and not exists
                (select 1
                         from basejk.intf_all kk
                        where kk.acc_nbr = f.acc_nbr
                          and kk.intf_all_id = f.intf_all_id
                          and kk.acc_nbr = '999' || to_char(order_item_id))
                  and not exists ( --没有送外围的单子
                       select 1
                         from basejk.intf_order g
                        where g.intf_all_id = f.intf_all_id
                          and g.channel_nbr = a.channel_nbr
                          and g.acc_nbr = f.acc_nbr)) LOOP
      BEGIN
        insert into basejk.intf_order --插入重送的数据
        values
          (basejk.seq_intf_order_id.nextval,
           aa.intf_all_id,
           '1',
           aa.acc_nbr,
           aa.channel_nbr,
           '70A',
           sysdate,
           sysdate,
           sysdate,
           0,
           sysdate,
           null,
           null);
        insert into basejk.intf_log
          (log_id,
           cust_so_number,
           --order_item_id,
           msg_type,
           REQUESTER,
           request_date,
           RESPONDER,
           respond_date,
           busi_code,
           method_name,
           acc_nbr,
           service_code,
           CREATE_DATE,
           DB_INST_ID)
          select seq_intf_log_id.nextval,
                 aa.cust_so_number,
                 --  aa.order_item_id,
                 '订单拆机重送接口表intf_order',
                 'CRM',
                 SYSDATE,
                 'INTER',
                 sysdate,
                 aa.channel_nbr,
                 'PKG_NX_INTF_WEIHU',
                 aa.acc_nbr,
                 null,
                 sysdate,
                 '1'
            from dual;
            COMMIT;
      EXCEPTION
      WHEN OTHERS THEN
           v_err_msg := v_err_msg || '|' || SQLERRM;
           /*insert into crmv2.intf_log
          (log_id,
           cust_so_number,
           --order_item_id,
           msg_type,
           REQUESTER,
           request_date,
           respond_date,
           method_name,
           CREATE_DATE,
           DB_INST_ID)
          select seq_intf_log_id.nextval,
                 aa.cust_so_number,
                 --  aa.order_item_id,
                 '订单拆机重送接口表intf_order',
                 'CRM',
                 SYSDATE,
                 sysdate,
                 'PKG_NX_INTF_WEIHU',
                 sysdate,
                 '1'
            from dual;
            COMMIT;*/
      END;
    end loop;
    IF v_err_msg IS NOT NULL AND length(v_err_msg) != 0 THEN
       v_result := v_err_msg;
    END IF;
    insert into basejk.intf_orer_resend_time
      (resend_id, begin_deal_time, end_deal_time,err_msg)
    values
      (basejk.seq_intf_orer_resend_time_id.nextval,
       v_begin_deal_time,
       v_end_deal_time,
       v_result);
    commit;
  end;

end PKG_NX_INTF_WEIHU;
/
