CREATE PACKAGE BODY           PKG_CRM2_SQL_monitor IS
/*
1.从生产导份sqlarea到用侧，crmv2.MONITOR_SQLAREA_EXISTS
2.提取新增的sqlarea
*/
PROCEDURE p_get_day_sql IS
  v_cnt NUMBER(10):=0;
BEGIN

--1.备份之前的sql
INSERT INTO monitor_sqlarea_all
  SELECT sql_text, sql_fulltext, sql_id, sql_text_new, trunc(SYSDATE, 'dd')
    FROM monitor_sqlarea_incre;
DELETE FROM monitor_sqlarea_incre;
COMMIT;

  --2.抽取增量的sqlarea
  DELETE FROM monitor_sqlarea_incre_pre;
  INSERT INTO monitor_sqlarea_incre_pre
    (sql_text,
     sql_fulltext,
     sql_id,
     first_load_time,
     parsing_schema_name,
     module)
    SELECT a.sql_text,
           a.sql_fulltext,
           sql_id,
           a.first_load_time,
           a.parsing_schema_name,
           a.module
      FROM gv$sqlarea a
     WHERE a.parsing_schema_name IN ('CRMV1', 'CRMV2')
       AND a.module = 'JDBC Thin Client'
       AND upper(a.sql_text) NOT LIKE 'DELETE%'
      AND upper(a.sql_text) NOT LIKE 'INSERT%'
      AND upper(a.sql_text) NOT LIKE 'UPDATE%'
      AND upper(a.sql_text) NOT LIKE '%HIS%'
      AND upper(a.sql_text) NOT LIKE '%.NEXTVAL FROM DUAL%'
       AND NOT EXISTS (SELECT 1
              FROM monitor_sqlarea_all b
             WHERE a.sql_text = b.sql_text);
  COMMIT;

  UPDATE monitor_sqlarea_incre_pre a
     SET a.sql_text_new = remove_constants(substr(a.Sql_Fulltext,1,3500));
  COMMIT;

 INSERT INTO  monitor_sqlarea_incre
SELECT a.*
  FROM monitor_sqlarea_incre_pre a
 WHERE  NOT EXISTS (SELECT 1
          FROM monitor_sqlarea_all b
         WHERE a.sql_text_new = b.sql_text_new);

Select Count(DISTINCT a.Sql_Text_New) INTO v_cnt From monitor_sqlarea_incre a;

--告警信息
 pkg_itsm.PROC_PUSH_MSG_TO_RTX_DIRECT@lk_crm2cq('mal,zhoujf,zhengzy,chendzh', '用测数据库新增历史表查询语句提醒', '用测数据库新增历史表查询语句共：'||v_cnt||' 条，请设计组评估该语句的可行性，详见crmv2.monitor_sqlarea_incre');

END p_get_day_sql;

function remove_constants( p_query in varchar2 ) return varchar2
as
    l_query long;
    l_char  varchar2(10);
    l_in_quotes boolean default FALSE;
begin
    for i in 1 .. length( p_query )
    loop
        l_char := substr(p_query,i,1);
        if ( l_char = '''' and l_in_quotes )
        then
            l_in_quotes := FALSE;
        elsif ( l_char = '''' and NOT l_in_quotes )
        then
            l_in_quotes := TRUE;
            l_query := l_query || '''#';
        end if;
        if ( NOT l_in_quotes ) then
            l_query := l_query || l_char;
        end if;
    end loop;
    l_query := translate( l_query, '0123456789', '@@@@@@@@@@' );
    for i in 0 .. 8 loop
        l_query := replace( l_query, lpad('@',10-i,'@'), '@' );
        l_query := replace( l_query, lpad(' ',10-i,' '), ' ' );
    end loop;
    return upper(l_query);
end;
END ;
/
