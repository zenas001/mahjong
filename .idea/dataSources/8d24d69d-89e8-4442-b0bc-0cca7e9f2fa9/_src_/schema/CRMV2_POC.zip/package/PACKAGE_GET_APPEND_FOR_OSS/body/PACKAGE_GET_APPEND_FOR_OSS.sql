CREATE package body           package_get_append_for_oss is
 procedure get_append_for_oss(IN_PROD_INST_ID           IN NUMBER,
                                               OUT_PROD_SPEC_CODE        out VARCHAR2,
                                               OUT_SERVICE_CODE          out VARCHAR2,
                                               APPEND_PROD_SPEC_CODE     out VARCHAR2,
                                               HAVING_APPEND_PROD_OR_NOT out VARCHAR2,
                                               LOCAL_NET_ID              out VARCHAR2,
                                               AREA_ID                   out VARCHAR2,
                                               BILL_TYPE                 out VARCHAR2,
                                               c_err_msg                 OUT VARCHAR2,
                                               n_ERR_NO                  OUT NUMBER) is
  v_count        number(2);
  v_region_cd    number(4);
  v_int_i        number(2);
  v_product_id   number(10);

begin
  begin
    select acc_nbr,
           AREA_CODE,
           common_region_id,
           payment_mode_cd,
           product_id
      INTO OUT_SERVICE_CODE,
           LOCAL_NET_ID,
           v_region_cd,
           BILL_TYPE,
           v_product_id
      from prod_inst
     where prod_inst_id = IN_PROD_INST_ID;
     select product_nbr
      into OUT_PROD_SPEC_CODE
      from product
     where product_id = v_product_id;
  exception
    when others then
      n_ERR_NO  := -1;
      c_err_msg := '查无数据';
      return;
  end;
  select region_name
    into AREA_ID
    from common_region
   where common_region_id = v_region_cd;
  select count(1)
    into v_count
    from prod_inst a, prod_inst b, product c
   where a.prod_inst_id = IN_PROD_INST_ID
     and a.prod_inst_id = b.acc_prod_inst_id
     and b.product_id = c.product_id
     and c.prod_func_type = '102';
  if v_count = 0 then
    HAVING_APPEND_PROD_OR_NOT := 'NO';
  else
    HAVING_APPEND_PROD_OR_NOT := 'YES';
  end if;
  v_int_i               := 1;
  APPEND_PROD_SPEC_CODE := '';

  for rec_prod_marg in (select c.product_nbr
                          from prod_inst a, prod_inst b, product c
                         where a.prod_inst_id = IN_PROD_INST_ID
                           and a.prod_inst_id = b.acc_prod_inst_id
                           and b.product_id = c.product_id
                           and c.prod_func_type = '102') loop
    if (v_int_i = 1) then
      APPEND_PROD_SPEC_CODE := rec_prod_marg.product_nbr;
    else
      APPEND_PROD_SPEC_CODE := APPEND_PROD_SPEC_CODE || ',' ||
                               rec_prod_marg.product_nbr;
    end if;
    v_int_i := v_int_i + 1;

  end loop;
  n_ERR_NO := 1;

exception
  when others then
    c_err_msg := '未知错误';
    n_ERR_NO  := -1;
end;



end package_get_append_for_oss;
/
