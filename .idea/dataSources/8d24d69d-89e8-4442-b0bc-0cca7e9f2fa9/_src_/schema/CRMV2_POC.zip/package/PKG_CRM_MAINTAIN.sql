CREATE PACKAGE           PKG_CRM_MAINTAIN IS
  /*-------------------------------------------------
    INTF_ORDER
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_ORDER_HIS;

  /*-------------------------------------------------
    INTF_SO_SERV
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_SO_SERV_HIS;

  /*-------------------------------------------------
    INTF_ALL
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_ALL_HIS;

  /*-------------------------------------------------
    INTF_SMS_QUEUE
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_SMS_QUEUE_HIS;

  /*-------------------------------------------------
    INTF_REGION_UPDATE_QUEUE
    Author  : ouzhf
    Created : 2012-12-9
  -------------------------------------------------*/
  PROCEDURE PROC_REGION_UPDATE_QUEUE_HIS;

  /*-------------------------------------------------
    INTF_UIM_INFO
    Author  : ouzhf
    Created : 2013-1-5
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_UIM_INFO_HIS;

  /*-------------------------------------------------
    INTF_INS_BILLING_UPDATE_HIS
    Author  : g.caijx
    Created : 2012-09-20
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_INS_BILL_UPDATE_HIS;

  /*-------------------------------------------------
    PROC_WORK_ORDER_HIS
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER_HIS;

  /*-------------------------------------------------
    PROC_WORK_ORDER_CDMA_HIS
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER_CDMA_HIS;

  /*-------------------------------------------------
    PROC_TFJ_ACC_NBR_HIS
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR_HIS;

  /*-------------------------------------------------
    TFJ_ACC_NBR_RELA_HIS
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR_RELA_HIS;

  /*-------------------------------------------------
    INTF_SO_SERV
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_SO_SERV;

  /*-------------------------------------------------
    PROC_INTF_ORDER
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_ORDER;

  /*-------------------------------------------------
    PROC_TFJ_ACC_NBR
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR;

  /*-------------------------------------------------
    PROC_TFJ_ACC_NBR_RELA
    Author  : ouzhf
    Created : 2012-10-9
  -------------------------------------------------*/
  PROCEDURE PROC_TFJ_ACC_NBR_RELA;

  /*-------------------------------------------------
    PROC_WORK_ORDER
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER;

  /*-------------------------------------------------
    PROC_WORK_ORDER_CDMA
    Author  : ouzhf
    Created : 2012-10-12
  -------------------------------------------------*/
  PROCEDURE PROC_WORK_ORDER_CDMA;

  /*-------------------------------------------------
    INTF_INS_BILLING_UPDATE
    Author  : ouzhf
    Created : 2012-10-29
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_INS_BILL_UPDATE;

END PKG_CRM_MAINTAIN;
/
