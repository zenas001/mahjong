CREATE PACKAGE           PKG_CRM2_SYNC_NEW IS
--生产差异数据
  PROCEDURE P_CREATESYNCDATA(I_SYNCID       IN NUMBER, --同步表ID
                             I_ID           IN NUMBER, --销售品规格ID，产品规格ID
                             I_AREAID       IN NUMBER, --配置区域
                             I_LINK         IN VARCHAR2, --目标库的链接
                             I_BATCH        IN VARCHAR2, --批次
                             I_ITSM_CODE    IN varchar2, -- ITSM单号 用于remark模糊查询
                             O_RESULT       OUT VARCHAR2, --返回标识
                             O_TMPTABLENAME OUT VARCHAR2, --临时表名
                             O_MSG          OUT VARCHAR2);

--生成执行脚本
  PROCEDURE P_CREATESQL(I_BATCH        IN VARCHAR2, --批次
                        I_LINK         IN VARCHAR2, --目标库的链接
            I_STAFF        IN VARCHAR2, --操作员工
                        I_LOGIN_IP     IN VARCHAR2, --登陆ip
                        O_RESULT       OUT VARCHAR2, --返回标识
                        O_MSG          OUT VARCHAR2);
--比较差异存入日志表
  PROCEDURE P_CREATESYNCLOG(I_SYNCID       IN NUMBER, --同步表ID
                            I_ID           IN NUMBER, --销售品规格ID，产品规格ID
                            I_LINK         IN VARCHAR2, --目标库的链接
                            I_BATCH        IN VARCHAR2, --批次
                            I_ITSM_CODE    IN varchar2, -- ITSM单号 用于remark模糊查询
                            I_LOCAL_DBA    IN VARCHAR2,--源库
                            I_COM_SYNC_DBA IN VARCHAR2,--目标库
                            O_RESULT       OUT VARCHAR2, --返回标识
                            O_MSG          OUT VARCHAR2);
--比较主数据差异存入日志表
  PROCEDURE P_CREATEMETADATASYNCLOG(I_TABLENAME    IN VARCHAR2, --表名
                            I_LINK         IN VARCHAR2, --目标库的链接
                            I_BATCH        IN VARCHAR2, --批次
                            I_ITSM_CODE    IN varchar2, -- ITSM单号 用于remark模糊查询
                            I_LOCAL_DBA    IN VARCHAR2,--源库
                            I_COM_SYNC_DBA IN VARCHAR2,--目标库
                            O_RESULT       OUT VARCHAR2, --返回标识
                            O_MSG          OUT VARCHAR2);
END PKG_CRM2_SYNC_NEW;
/
