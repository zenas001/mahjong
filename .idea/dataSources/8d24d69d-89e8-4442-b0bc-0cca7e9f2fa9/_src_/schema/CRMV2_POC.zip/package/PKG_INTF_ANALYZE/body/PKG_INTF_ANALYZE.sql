CREATE package body           PKG_INTF_ANALYZE is

  PROCEDURE PROC_ADD_INTF_ANALYZE_DATA is
    V_SERVICE_NAME       VARCHAR(500);
    V_METHOD_NAME        VARCHAR(500);
    V_MSG_TYPE           VARCHAR(500);
    V_CHANNEL_NBR        VARCHAR(500);
    V_BUSINESS_TYPE      VARCHAR(500);
    V_SUCSESS_AMOUNT     VARCHAR(500);
    V_FAILURE_AMOUNT     VARCHAR(500);
    V_MAX_SPEDN_TIME     VARCHAR(500);
    V_MIN_SPEDN_TIME     VARCHAR(500);
    V_AVERAGE_SPEND_TIME VARCHAR(500);
    V_COUNT              NUMBER(15);
    V_FAILURE_RATE       VARCHAR(500);

  begin
    execute immediate 'truncate table crmv2.intf_analyze_data';--清空表数据
  --根据msgtype来识别
    FOR rec IN (SELECT distinct msg_type
                  FROM crmv2.intf_analyze_log
                 where 1 = 1) LOOP
      BEGIN
        V_MSG_TYPE := rec.msg_type;

        select i.service_name,
               i.method_name,
               i.channel_nbr,
               i.business_type
          into V_SERVICE_NAME,
               V_METHOD_NAME,
               V_CHANNEL_NBR,
               V_BUSINESS_TYPE
          from crmv2.intf_analyze_log i
         where i.msg_type = V_MSG_TYPE
           and rownum < 2;
      --获取成功量
        select count(*)
          into V_SUCSESS_AMOUNT
          from crmv2.intf_analyze_log i
         where i.msg_type = V_MSG_TYPE
           and i.result_flag = '0';
      --获取失败量
        select count(*)
          into V_FAILURE_AMOUNT
          from crmv2.intf_analyze_log i
         where i.msg_type = V_MSG_TYPE
           and i.result_flag <> '0';
      --最大处理时间
        select max(i.spend_time)
          into V_MAX_SPEDN_TIME
          from crmv2.intf_analyze_log i
         where i.msg_type = V_MSG_TYPE;
      --最小处理时间
        select min(i.spend_time)
          into V_MIN_SPEDN_TIME
          from crmv2.intf_analyze_log i
         where i.msg_type = V_MSG_TYPE;
      --平均处理时间
        select  round(avg(i.spend_time),4)
          into V_AVERAGE_SPEND_TIME
          from crmv2.intf_analyze_log i
         where i.msg_type = V_MSG_TYPE;
      --同一个msgType对应的下发总量
        select count(*)
          into V_COUNT
          from crmv2.intf_analyze_log i
         where i.msg_type = V_MSG_TYPE;
      --计算失败率
        IF nvl(V_COUNT, 0) <> 0 THEN
          V_FAILURE_RATE := round(nvl(V_FAILURE_AMOUNT, 0) / V_COUNT, 4) * 100 || '%';
        END IF;

      --插入intf_analyze_data表
        insert into crmv2.intf_analyze_data
          (INTF_ANALYZE_DATA_ID,
           SERVICE_NAME,
           METHOD_NAME,
           MSG_TYPE,
           CHANNEL_NBR,
           BUSINESS_TYPE,
           REQUEST_DATE,
           SUCSESS_AMOUNT,
           FAILURE_AMOUNT,
           MAX_SPEDN_TIME,
           MIN_SPEDN_TIME,
           AVERAGE_SPEND_TIME,
           FAILURE_RATE)
        values
          (seq_INTF_ANALYZE_DATA_ID.nextval,
           V_SERVICE_NAME,
           V_METHOD_NAME,
           V_MSG_TYPE,
           V_CHANNEL_NBR,
           V_BUSINESS_TYPE,
           sysdate,
           V_SUCSESS_AMOUNT,
           V_FAILURE_AMOUNT,
           V_MAX_SPEDN_TIME,
           V_MIN_SPEDN_TIME,
           V_AVERAGE_SPEND_TIME,
           V_FAILURE_RATE);
        COMMIT;

      end;
    END LOOP;

  end;
end PKG_INTF_ANALYZE;
/
