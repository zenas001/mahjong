CREATE package body           PKG_CRM2_FOR_JF_COMPARE_PASSWD is


function asciitohex(str_input in varchar2)
/**********************************
  把ASCII转换为十六进制输出
  **********************************/
 return varchar2 as
  n_temp    int := 0;
  sz_output varchar2(1000) := '';
  v_temp    varchar2(10) := '';
begin
  for i in 1 .. length(str_input) loop
    n_temp := ascii(substr(str_input, i, 1));
    select chr(n_temp / 16 + 48) into v_temp from dual;
    sz_output := sz_output || v_temp;
    --n_temp := n_temp mod 16;
    select mod(n_temp, 16) into n_temp from dual;
    if n_temp < 10 then
      sz_output := sz_output || chr(n_temp + 48);
    elsif n_temp = 10 then
      sz_output := sz_output || 'A';
    elsif n_temp = 11 then
      sz_output := sz_output || 'B';
    elsif n_temp = 12 then
      sz_output := sz_output || 'C';
    elsif n_temp = 13 then
      sz_output := sz_output || 'D';
    elsif n_temp = 14 then
      sz_output := sz_output || 'E';
    elsif n_temp = 15 then
      sz_output := sz_output || 'F';
    end if;
  end loop;
  return sz_output;
end;

  PROCEDURE PROC_user_encrypt(pass in varchar, encryption out varchar) IS
    /**********************************
    本程序通过一定的加密算法对输入的用户密码
    进行加密处理，最终形成用户加密后的数据
    **********************************/
    --当前版本号为2.01
  BEGIN
    DECLARE
      /*以下定义为用户密码的每位的分解*/
      nSub1 number(2);
      nSub2 number(2);
      nSub3 number(2);
      nSub4 number(2);
      nSub5 number(2);
      nSub6 number(2);
      /*以下定义为最终用户密码的每位的定义*/
      nEnd1 number(4);
      nEnd2 number(4);
      nEnd3 number(4);
      nEnd4 number(4);
      nEnd5 number(4);
      nEnd6 number(4);
      nEnd7 number(4);
      nEnd8 number(4);
      nEnd9 number(4);
      /*以下定义为转化后的ascii码值*/
      asci1 number(2);
      asci2 number(2);
      asci3 number(2);
      asci4 number(2);
      asci5 number(2);
      asci6 number(2);
      asci7 number(2);
      asci8 number(2);
      asci9 number(2);

    BEGIN
      /*对用户密码的每位进行分解处理*/
      nSub1 := to_number(substr(pass, 1, 1)) + 60;
      nSub2 := to_number(substr(pass, 2, 1)) + 50;
      nSub3 := to_number(substr(pass, 3, 1)) + 40;
      nSub4 := to_number(substr(pass, 4, 1)) + 30;
      nSub5 := to_number(substr(pass, 5, 1)) + 20;
      nSub6 := to_number(substr(pass, 6, 1)) + 10;
      /*对分解后的数据进行矩阵运算*/
      nEnd1 := nSub1 * nSub1 + nSub4 * nSub2;
      nEnd2 := nSub1 * nSub3 + nSub4 * nSub4;
      nEnd3 := nSub1 * nSub5 + nSub4 * nSub6;
      nEnd4 := nSub2 * nSub1 + nSub5 * nSub2;
      nEnd5 := nSub2 * nSub3 + nSub5 * nSub4;
      nEnd6 := nSub2 * nSub5 + nSub5 * nSub6;
      nEnd7 := nSub3 * nSub1 + nSub6 * nSub2;
      nEnd8 := nSub3 * nSub3 + nSub6 * nSub4;
      nEnd9 := nSub3 * nSub5 + nSub6 * nSub6;
      /*对得到的新的矩阵进行处理*/

      select decode(mod(nEnd1, 11), 0, 65, mod(nEnd1, 11))
        into asci1
        from dual;
      select decode(mod(nEnd2, 29), 0, 70, mod(nEnd2, 29))
        into asci2
        from dual;
      select decode(mod(nEnd3, 37), 0, 75, mod(nEnd3, 37))
        into asci3
        from dual;
      select decode(mod(nEnd6, 43), 0, 79, mod(nEnd6, 43))
        into asci4
        from dual;
      select decode(mod(nEnd9, 59), 0, 86, mod(nEnd9, 59))
        into asci5
        from dual;
      select decode(mod(nEnd8, 67), 0, 89, mod(nEnd8, 67))
        into asci6
        from dual;
      select decode(mod(nEnd7, 73), 0, 94, mod(nEnd7, 73))
        into asci7
        from dual;
      select decode(mod(nEnd4, 83), 0, 83, mod(nEnd4, 83))
        into asci8
        from dual;
      select decode(mod(nEnd5, 97), 0, 69, mod(nEnd5, 97))
        into asci9
        from dual;

      /*如果转换后的字符是“回车”，则改为其他的字符*/
      if asci1 In (10, 26) then
        asci1 := 61;
      end if;
      if asci2 In (10, 26) then
        asci2 := 61;
      end if;
      if asci3 In (10, 26) then
        asci3 := 61;
      end if;
      if asci4 in (10, 26) then
        asci4 := 61;
      end if;
      if asci5 in (10, 26) then
        asci5 := 61;
      end if;
      if asci6 in (10, 26) then
        asci6 := 61;
      end if;
      if asci7 in (10, 26) then
        asci7 := 61;
      end if;
      if asci8 in (10, 26) then
        asci8 := 61;
      end if;
      if asci9 in (10, 26) then
        asci9 := 61;
      end if;

      /*得到输出结果*/

      select chr(asci1) || chr(asci2) || chr(asci3) || chr(asci4) ||
             chr(asci5) || chr(asci6) || chr(asci7) || chr(asci8) ||
             chr(asci9)
        into encryption
        from dual;
      encryption := asciitohex(encryption);
    END;
  EXCEPTION
    WHEN OTHERS THEN
      encryption := '';
  END;

  Function Get_Prod_Id(in_area_id  In Varchar2,
                       in_account  In Varchar2,
                       in_str_flag In Varchar2) Return Number Is
    n_prod_id       number(10);
    cnt             number(3);
    in_prod_spec_id number(3);
    v_account       varchar2(40);
  begin

    if (in_str_flag = 'TEL') THEN
      in_prod_spec_id := 1;
    else
      in_prod_spec_id := 9;
    end if;

    --福州地区
    -- mal_20071217 修改 新oss上线
    -- if in_area_id = '0591' then
    if in_str_flag = 'CDMA' then

        select count(*)
            into cnt
            from prod_inst
           where account = in_account
             and area_code = in_area_id
             and product_id = 800000002
             and status_cd not in('130000');

         if cnt = 1 then

             select prod_inst_id
               into n_prod_id
               from prod_inst
              where account = in_account
                and area_code = in_area_id
                and product_id = 800000002
                and status_cd not in('130000');


         end if;

    elsif in_area_id = '0000' then  -- 设置另类条件以实现屏蔽该段代码的功能

      v_account := in_account;/*
      if upper(in_account) like 'X%' then
        v_account := substr(in_account, 2);
      end if;
      select count(1)
        into cnt
        from prod
       where account = v_account
         and area_code = in_area_id
         and prod_spec_id in (1, 9, 200205)
         and state not in ('70N', '70X');

      --如果是从机
      if upper(in_account) like 'X%' then
        --无此电话号码
        if cnt = 0 then
          n_prod_id := -1;
          --没有超无，但有一条记录，报错
        elsif cnt = 1 then
          n_prod_id := -3;
          --有超无
        elsif cnt > 1 then
          --n_prod_id := '0';
          begin
            if in_prod_spec_id = '1' then
              select a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.area_code = in_area_id
                 and a.prod_spec_id = 1
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_idb
                 and c.rela_type in ('118', '121');
            else
              select a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.area_code = in_area_id
                 and a.prod_spec_id in (9, 200205)
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_idb
                 and c.rela_type in ('118', '121');
            end if;
          exception
            --其它异常
            when others then
              n_prod_id := -2;
          end;
        end if;
        --如果是主机
      else
        --无此电话号码
        if cnt = 0 then
          n_prod_id := -1;
          --没有超无，但有一条记录
        elsif cnt = 1 then
          --n_prod_id := '0';
          begin
            if in_prod_spec_id = '1' then
              select prod_id
                into n_prod_id
                from prod
               where account = v_account
                 and area_code = in_area_id
                 and prod_spec_id = 1
                 and state not in ('70N', '70X');
            else
              select prod_id
                into n_prod_id
                from prod
               where account = v_account
                 and area_code = in_area_id
                 and prod_spec_id in (9, 200205)
                 and state not in ('70N', '70X');
            end if;
          exception
            --其它异常
            when others then
              n_prod_id := -2;
          end;
        elsif cnt > 1 then
          --v_result := '0';
          begin
            if in_prod_spec_id = '1' then
              select distinct a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.prod_spec_id = 1
                 and a.area_code = in_area_id
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_ida
                 and c.rela_type in ('118', '121'); --121是超级无绳主从关系，118是固话一号双机主从关系
            else
              select distinct a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.prod_spec_id in (9, 200205)
                 and a.area_code = in_area_id
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_ida
                 and c.rela_type in ('118', '121');
            end if;
          exception
            --其它异常
            when others then
              n_prod_id := -2;
          end;
          --有超无
        end if;
      end if;*/

    --elsif in_area_id = '0594' then  -- 全省都走原来莆田的判断

    else
      v_account := in_account;
      if upper(in_account) like '%X' OR upper(in_account) like '%x' then
        v_account := substr(in_account, 1, length(in_account) - 1);
      end if;
      if upper(in_account) like 'X%' OR upper(in_account) like 'x%'  then
        v_account := substr(in_account, 2);
      end if;
      /*
      select count(1)
        into cnt
        from prod
       where account = v_account
         and area_code = in_area_id
         and prod_spec_id in (594000238,594000239,594000242,594000244,594000245,594000246,594000247,594000276,594000277,594001185,600001881,594000248,594000006)
         and state not in ('70N', '70X')
         and region > 10;*/
      select count(1)
        into cnt
        from prod_inst
       where account = v_account
         and area_code = in_area_id
         and  product_id in  ('800298306', '800298301', '800000001', '800003976',
            '800298421', '800003975', '800298362', '800000003',
            '800000000', '800298429', '800298304', '800298351')
         and status_cd not in('130000', '110000')
         and common_region_id > 10;

      --如果是从机
      if upper(in_account) like '%X' OR upper(in_account) like 'X%' OR upper(in_account) like '%x' OR upper(in_account) like 'x%' then
        --无此电话号码
        if cnt = 0 then
          n_prod_id := -1;
          --没有超无，但有一条记录，报错
        elsif cnt = 1 then
          n_prod_id := -3;
          --有超无
        elsif cnt > 1 then
          --n_prod_id := '0';
          begin
            if in_prod_spec_id = '1' then
              select a.prod_inst_id
                into n_prod_id
                from prod_inst a, prod_inst_rel b
               where a.account = v_account
                 and a.area_code = in_area_id
                 and  a.product_id in  ('800298306', '800298301', '800000001', '800003976',
                    '800298421', '800003975', '800298362', '800000003',
                    '800000000', '800298429', '800298304', '800298351')
                 and a.status_cd not in('130000', '110000')
                 and b.prod_inst_a_id = a.prod_inst_id
                 and b.relation_type_cd = '109920'   --主副关系
                 and a.common_region_id > 10;

              /*
              select a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.area_code = in_area_id
                 and a.prod_spec_id in (594000238,594000239,594000242,594000244,594000245,594000246,594000247,594000276,594000277,594001185,600001881,594000006)
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_idb
                 and c.rela_type in ('118', '121');*/
            else
              select a.prod_inst_id
                into n_prod_id
                from prod_inst a, prod_inst_rel b
               where a.account = v_account
                 and a.area_code = in_area_id
                 and  a.product_id = 800000003
                 and a.status_cd not in('130000', '110000')
                 and b.prod_inst_a_id = a.prod_inst_id
                 and b.relation_type_cd = '109920'   --主副关系
                 and a.common_region_id > 10;
              /*
              select a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.area_code = in_area_id
                 and a.prod_spec_id = 594000248
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_idb
                 and c.rela_type in ('118', '121');*/
            end if;
          exception
            --其它异常
            when others then
              n_prod_id := -2;
          end;
        end if;
        --如果是主机
      else
        --无此电话号码
        if cnt = 0 then
          n_prod_id := -1;
          --没有超无，但有一条记录
        elsif cnt = 1 then
          --n_prod_id := '0';
          begin
            if in_prod_spec_id = '1' then
              /*
              select prod_id
                into n_prod_id
                from prod
               where account = v_account
                 and area_code = in_area_id
                 and prod_spec_id in (594000238,594001395,594000239,594000242,594000244,594000245,594000246,594000247,594000276,594000277,594001185,600001881,594000006)--mal_20080623 添加一机商品规格
                 and state not in ('70N', '70X')
                 and region > 10;*/
              select a.prod_inst_id
                into n_prod_id
                from prod_inst a
               where a.account = v_account
                 and a.area_code = in_area_id
                 and  a.product_id in  ('800298306', '800298301', '800000001', '800003976',
                    '800298421', '800003975', '800298362', '800000003',
                    '800000000', '800298429', '800298304', '800298351')
                 and a.status_cd not in('130000', '110000')
                 and a.common_region_id > 10;
            else
              /*
              select prod_id
                into n_prod_id
                from prod
               where account = v_account
                 and area_code = in_area_id
                 and prod_spec_id = 594000248
                 and state not in ('70N', '70X')
                 and region > 10;*/
              select a.prod_inst_id
                into n_prod_id
                from prod_inst a
               where a.account = v_account
                 and a.area_code = in_area_id
                 and  a.product_id = 800000003
                 and a.status_cd not in('130000', '110000')
                 and a.common_region_id > 10;
            end if;
          exception
            --其它异常
            when others then
              n_prod_id := -2;
          end;
        elsif cnt > 1 then
          --n_prod_id := '0';
          begin
            if in_prod_spec_id = '1' then
              /*
              select distinct a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.prod_spec_id in (594000238,594001395,594000239,594000242,594000244,594000245,594000246,594000247,594000276,594000277,594001185,600001881,594000006)
                 and a.area_code = in_area_id
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_ida
                 and c.rela_type in ('118', '121'); --121是超级无绳主从关系，118是固话一号双机主从关系*/
               select a.prod_inst_id
                into n_prod_id
                from prod_inst a, prod_inst_rel b
               where a.account = v_account
                 and a.area_code = in_area_id
                 and  a.product_id in  ('800298306', '800298301', '800000001', '800003976',
                    '800298421', '800003975', '800298362', '800000003',
                    '800000000', '800298429', '800298304', '800298351')
                 and a.status_cd not in('130000', '110000')
                 and b.prod_inst_z_id = a.prod_inst_id
                 and b.relation_type_cd = '109920'   --主副关系
                 and a.common_region_id > 10;

            else
              /*
              select distinct a.prod_id
                into n_prod_id
                from prod a, mdse b, mdse_rela c
               where a.account = v_account
                 and a.prod_spec_id = 594000248
                 and a.area_code = in_area_id
                 and a.state not in ('70N', '70X')
                 and a.prod_id = b.prod_id
                 and b.mdse_id = c.mdse_ida
                 and c.rela_type in ('118', '121');*/
              select a.prod_inst_id
                into n_prod_id
                from prod_inst a, prod_inst_rel b
               where a.account = v_account
                 and a.area_code = in_area_id
                 and  a.product_id = 800000003
                 and b.prod_inst_z_id = a.prod_inst_id
                 and b.relation_type_cd = '109920'   --主副关系
                 and a.common_region_id > 10;

               end if;

          exception
            --其它异常
            when others then
              n_prod_id := -2;
          end;
          --有超无
        end if;
      end if;
    end if;
    return n_prod_id;

  end Get_Prod_Id;

  --根据传入的标识:1为业务号码,2为帐号 查询产品数据
  --比较传入密码是否与指定的产品配置的高级密码或者初级密码一致,若有多个产品,其中一个密码匹配就返回成功
  PROCEDURE PROC_comparePasswd(str_areacode  IN VARCHAR2, -- 区域编码 比如福州是0591
                          str_serv_acct IN VARCHAR2, -- 业务号码或者帐号
                          str_type      IN VARCHAR2, -- PHS TEL 分别表示小灵通或者固话  CDMA 表示查询CDMA对应产品
                          l_flag        IN NUMBER,  -- 1表示业务号码 2表示帐号
                          str_passwd    IN VARCHAR2,--密码串
                          l_result      OUT NUMBER,-- 0：匹配密码成功 1：查询产品失败 2：密码匹配失败 3；发生异常 4：产品停机保号
                          str_info      OUT VARCHAR2) IS
     PRAGMA AUTONOMOUS_TRANSACTION;

    l_prodid            PROD_INST.PROD_INST_ID%TYPE; --产品ID
    str_passwdcrm       PROD_INST_ATTR.Attr_Value%TYPE; --CRM中密码串
    str_passwdencrypted PROD_INST_ATTR.Attr_Value%TYPE; --CRM中密码串
    i                   NUMBER := 0; --变量
    cnt                 NUMBER := 0; --变量
    tingbaocnt          NUMBER := 0; --变量,标识是否有停保特性
    areacode            PROD_INST.AREA_CODE%TYPE;

  BEGIN
    l_result := -1;
    l_prodid := 0;

    areacode := str_areacode;

    if str_type = 'CDMA' then

      if l_flag = 1 then
        --select count(*) into cnt from prod a where a.account = str_serv_acct;
        select count(*) into cnt from  prod_inst a where a.account = str_serv_acct and a.product_id = '800000002';

        if cnt = 1 then
            --select area_code into areacode from prod a where a.account = str_serv_acct;
            select area_code into areacode from  prod_inst a where a.account = str_serv_acct and a.product_id = '800000002';
        end if;

      elsif l_flag = 2 then
        --select count(*) into cnt from prod a where a.service_code = str_serv_acct;
        select count(*) into cnt from  prod_inst a where a.acc_nbr = str_serv_acct and a.product_id = '800000002';

        if cnt = 1 then
           --select area_code into areacode from prod a where a.service_code = str_serv_acct;
           select area_code into areacode from  prod_inst a where a.acc_nbr = str_serv_acct and a.product_id = '800000002';
        end if;
      end if;
    end if;

    --根据业务号码和区域号码装载产品记录
    IF (l_flag = 1) THEN
      l_prodid := Get_Prod_Id(areacode,str_serv_acct,str_type);
    ELSIF (l_flag = 2) THEN
      /*
      SELECT count(*)
        INTO i
        FROM prod
       WHERE area_code = areacode
         and service_code = str_serv_acct;
      if i = 1 then
        SELECT prod_id
          INTO l_prodid
          FROM prod
         WHERE area_code = areacode
           and service_code = str_serv_acct;
      end if;*/
      SELECT count(*)
        INTO i
        FROM prod_inst
       WHERE area_code = areacode
         and acc_nbr = str_serv_acct;
      if i = 1 then
        SELECT prod_inst_id
          INTO l_prodid
          FROM prod_inst
         WHERE area_code = areacode
           and acc_nbr = str_serv_acct;
      end if;
    END IF;

    /*
    select count(*)
      into tingbaocnt
      from prod_fea a, prod_fea_spec b
     where a.fea_spec_id = b.fea_spec_id
       and a.prod_id = l_prodid
       and b.code = 'SO_SERViSTOP_USER';*/
    select count(*)
      into tingbaocnt
      from prod_inst_attr a, attr_spec b
     where a.attr_id = b.attr_id
       and a.prod_inst_id = l_prodid
       and b.java_code = 'SO_SERViSTOP_USER';

    -- 带 'X' 且只有一条记录 mal_20070119
    -- IF (l_prodid = -5 OR l_prodid = -6) THEN
    IF (l_prodid < 0) THEN
      l_result := 1;
      str_info := '查询失败!';
    END IF;

    --加密传入明码
    PROC_user_encrypt(str_passwd, str_passwdencrypted);

    IF (l_prodid > 0 AND l_flag = 1) THEN

      --查找高级密码
      /*
      select count(b.param1)
        into i
        from prod_fea b, prod_fea_spec c
       where b.prod_id = l_prodid
         and b.fea_spec_id = c.fea_spec_id
         and c.state = '70A'
         and c.sort = '5'
         and c.code = 'M';*/
      select count(*)
        into i
        from prod_inst_attr a, attr_spec b
       where a.attr_id = b.attr_id
         and a.prod_inst_id = l_prodid
         and b.java_code = 'M';

      IF (i > 0) THEN
        --匹配高级密码
        /*
        select b.param1
          into str_passwdcrm
          from prod_fea b, prod_fea_spec c
         where b.prod_id = l_prodid
           and b.fea_spec_id = c.fea_spec_id
           and c.state = '70A'
           and c.sort = '5'
           and c.code = 'M'
           and rownum < 2;*/
         select a.attr_value
          into str_passwdcrm
          from prod_inst_attr a, attr_spec b
         where a.attr_id = b.attr_id
           and a.prod_inst_id = l_prodid
           and b.java_code = 'M'
           and rownum < 2;
        IF (str_passwdencrypted = str_passwdcrm) THEN
          str_info := '20';
          l_result := 0;
        END IF;
      END IF;
      /*
      --匹配高级密码失败则匹配初级密码
      IF (l_result != 0) THEN
        --查找初级密码
        select count(b.param1)
          into i
          from prod_fea b, prod_fea_spec c
         where b.prod_id = l_prodid
           and b.fea_spec_id = c.fea_spec_id
           and c.state = '70A'
           and c.sort = '5'
           and c.code = 'Q';
        IF (i > 0) THEN
          --匹配初级密码
          select b.param1
            into str_passwdcrm
            from prod_fea b, prod_fea_spec c
           where b.prod_id = l_prodid
             and b.fea_spec_id = c.fea_spec_id
             and c.state = '70A'
             and c.sort = '5'
             and c.code = 'Q'
             and rownum < 2;
          IF (str_passwdencrypted = str_passwdcrm) THEN
            str_info := '10';
            l_result := 0;
          END IF;
        END IF;
      END IF;*/

      --密码不匹配时返回 2
      IF (l_result != 0) THEN
        str_info := '密码不匹配!';
        l_result := 2;
      END IF;

      --根据帐号和区域号码装载产品记录
    ELSIF (i > 0 AND l_flag = 2) THEN

      --查找高级密码
      /*
      select count(b.param1)
        into i
        from prod a, prod_fea b, prod_fea_spec c
       where a.prod_id = b.prod_id
         and b.fea_spec_id = c.fea_spec_id
         and c.state = '70A'
         and c.sort = '5'
         and c.code = 'M'
         and a.area_code = areacode
         and a.service_code = str_serv_acct;*/

      select count(*)
        into i
        from prod_inst_attr a, attr_spec b, prod_inst c
       where a.attr_id = b.attr_id
         and a.prod_inst_id = c.prod_inst_id
         and c.area_code = areacode
         and c.acc_nbr = str_serv_acct
         and b.java_code = 'M';

      IF (i > 0) THEN
        --匹配高级密码
        /*
        select b.param1
          into str_passwdcrm
          from prod a, prod_fea b, prod_fea_spec c
         where a.prod_id = b.prod_id
           and b.fea_spec_id = c.fea_spec_id
           and c.state = '70A'
           and c.sort = '5'
           and c.code = 'M'
           and a.area_code = areacode
           and a.service_code = str_serv_acct
           and rownum < 2;*/
        select a.attr_value
          into str_passwdcrm
          from prod_inst_attr a, attr_spec b, prod_inst c
         where a.attr_id = b.attr_id
           and a.prod_inst_id = c.prod_inst_id
           and c.area_code = areacode
           and c.acc_nbr = str_serv_acct
           and b.java_code = 'M'
           and rownum < 2;

        IF (str_passwdencrypted = str_passwdcrm) THEN
          str_info := '20';
          l_result := 0;
        END IF;
      END IF;
      /*
      --匹配高级密码失败则匹配初级密码
      IF (l_result != 0) THEN
        --查找初级密码
        select count(b.param1)
          into i
          from prod a, prod_fea b, prod_fea_spec c
         where a.prod_id = b.prod_id
           and b.fea_spec_id = c.fea_spec_id
           and c.state = '70A'
           and c.sort = '5'
           and c.code = 'Q'
           and a.area_code = areacode
           and a.service_code = str_serv_acct;
        IF (i > 0) THEN
          --匹配初级密码
          select b.param1
            into str_passwdcrm
            from prod a, prod_fea b, prod_fea_spec c
           where a.prod_id = b.prod_id
             and b.fea_spec_id = c.fea_spec_id
             and c.state = '70A'
             and c.sort = '5'
             and c.code = 'Q'
             and a.area_code = areacode
             and a.service_code = str_serv_acct
             and rownum < 2;
          IF (str_passwdencrypted = str_passwdcrm) THEN
            str_info := '10';
            l_result := 0;
          END IF;
        END IF;
      END IF;*/

      --密码不匹配时返回 2
      IF (l_result != 0) THEN
        str_info := '密码不匹配!';
        l_result := 2;
      END IF;

      --无产品记录时返回 1
    ELSIF i = i THEN
      l_result := 1;
      str_info := '根据输入条件查询不到产品记录!';
    END IF;

    if tingbaocnt = 1 then
      l_result := 4;
      str_info := '产品状态:用户申请停机!';
    end if;

    -- save the log info 20070309
    --INSERT INTO CRM.PASSWD_LOG(ID,PROD_ID,FLAG,ERR_MSG,DATETIME,LOG_TYPE,CHANNEL,AREA_CODE)
    --SELECT CRM.PASSWD_LOG_ID_SEQ.NEXTVAL,l_prodid,TO_CHAR(l_result),str_info,sysdate,'ODS','NET',str_areacode FROM DUAL;
    commit;

  --处理异常: 异常时返回 3
  EXCEPTION
    WHEN OTHERS THEN
      str_info := '调用发生异常!'||SQLERRM;
      l_result := 3;

      -- save the log info 20070309
      --INSERT INTO CRM.PASSWD_LOG(ID,PROD_ID,FLAG,ERR_MSG,DATETIME,LOG_TYPE,CHANNEL,AREA_CODE)
      --SELECT CRM.PASSWD_LOG_ID_SEQ.NEXTVAL,l_prodid,TO_CHAR(l_result),str_info,sysdate,'ODS','NET',str_areacode FROM DUAL;
      commit;

  END PROC_comparePasswd;

  PROCEDURE PROC_JudgmentWeakPasswords(in_pass                in varchar,
                                  in_area_code           in varchar2,
                                  out_AuthenticateRusult out varchar) IS
    /*******************************************************************************
      后台组处理：将ODS系统该存储过程建到CRM用户下，并编译通过；然后再改造：在验证密码前，增加弱密码验证，弱密码规则如下，若判断传入密码是弱密码，则AuthenticateRusult返回参数：-2 弱密码：
    ? 业务密码和宽带登录密码的弱密码规则为：
    1、  连续相同的数字或字符
    2、  连续的数字或字母(包括倒序的)
    5、  连续的叠数(如:112233,aabbcc等)
    6、  初始业务密码，
    ? 各地市宽带初始化密码如下：
    ? 福州：a123456。
    ? 厦门：abcd1234。
    ? 宁德：a123456。
    ? 莆田：a123456。
    ? 泉州：需要用户能过本机拨打10000直接修改。
    ? 漳州：a123456 。
    ? 龙岩：自动台：a123456  人工台：宽带帐号@前的号码。
    ? 三明：需要用户能过本机拨打10000直接修改。
    ? 南平：a123456。
    ? 各地市固话、小灵通和手机用户初始化密码如下：
    ? 福州：123456。
    ? 厦门：123456。
    ? 宁德：123456。
    ? 莆田：123456。
    ? 泉州：需要用户带身份证到营业厅办理。
    ? 漳州：123456 。
    ? 龙岩：用户通过10000直接进行修改。
    ? 三明：固话和小灵通用户需要带身份证到营业厅办理，手机用户通过拨打10000直接修改。
    ? 南平：用户需要带身份证到营业厅办理。
    （注：初始密码使用配置表来维护，允许管理人员在后台增加拒绝登录的密码）
         配置弱密码：
      1. 2011年5月新增 统一弱密码配置： ab1234
      *********************************************************************************/
    v_continuation  number := 1; --1、 连续相同的数字或字符  0为不连续 1为连续
    v_invertedOrder number := 1; --2、 连续的数字或字母(包括倒序的) 0为不连续 1为连续
    v_iteration     number := 1; --3、连续的叠数(如:112233,aabbcc等)
    v_iterNum       number := 0; --迭代数目。
    v_iterOne       number := 1; --第一次进入
    v_frontIter     number := 0;
    v_curIter       number := 0;

    v_sub      number := 0;
    v_frontSub number := 0;

    v_length number := 0;
    v_cnt    number := 0;
    v_value  number := 0;

  BEGIN
    out_AuthenticateRusult := '1';

    select length(in_pass) into v_length from dual;
    if v_length > 0 then

      while v_cnt < v_length loop
        --循环字符串

        v_cnt := v_cnt + 1;
        v_sub := ascii(substr(in_pass, v_cnt, 1));

        if v_cnt > 1 then
          --第一个字符不处理

          v_value := v_sub - v_frontSub;
          if v_value = 1 and v_continuation = 1 then
            v_continuation := 1;
          else
            v_continuation := 0; -- 无正序
          end if;

          if v_value = -1 and v_invertedOrder = 1 then
            v_invertedOrder := 1;
          else
            v_invertedOrder := 0; --无逆序
          end if;

          --3、连续的叠数(如:112233,aabbcc等)
          if v_frontSub != v_sub and v_iterOne = 0 and v_iteration = 1 then
            v_value   := v_sub - v_frontSub;
            v_curIter := v_cnt - 1;
            if v_value = 1 and v_iterNum = v_curIter - v_frontIter then
              v_iteration := 1;
            else
              v_iteration := 0;
            end if;
            v_frontIter := v_cnt - 1;
          end if;

          if v_cnt = v_length and v_iteration = 1 then
            if v_iterNum <> v_cnt - v_frontIter then
              v_iteration := 0; --
            end if;
          end if;

          if v_frontSub != v_sub and v_iterOne = 1 then
            v_iterNum   := v_cnt - 1;
            v_frontIter := v_cnt - 1; --几个数是一样的。
            v_iterOne   := 0;
            v_value   := v_sub - v_frontSub;
            if v_value != 1 then
              v_iteration := 0;
            end if;
          end if;
          --3、连续的叠数(如:112233,aabbcc等)

        end if;

        v_frontSub := v_sub; --记载前一个数
      end loop;
      --end 1、 连续相同的数字或字符

    end if;

    --密码初始化校验配置
    select count(*)
      into v_cnt
      from crmv1.zb
     where zbfl = 'MMCSHJYPZ'
       and zbbm = in_pass
       and (area_id = in_area_code or area_id = '1');
    if v_cnt > 0 then
      out_AuthenticateRusult := '-2';
    end if;

    --规则
    if v_continuation = 1 or v_invertedOrder = 1 or v_iteration = 1 then
      out_AuthenticateRusult := '-2';
    end if;
    --长度小于2
    if v_length < 2 then
      out_AuthenticateRusult := '1';
    end if;

  END PROC_JudgmentWeakPasswords;

end PKG_CRM2_FOR_JF_COMPARE_PASSWD;
/
