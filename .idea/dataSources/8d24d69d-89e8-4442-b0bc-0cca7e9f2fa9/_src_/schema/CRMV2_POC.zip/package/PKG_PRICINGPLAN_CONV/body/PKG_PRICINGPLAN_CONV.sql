CREATE PACKAGE BODY           PKG_PRICINGPLAN_CONV IS
  -- AUTHOR  : TIANSHM
  -- CREATED : 2014/5/12
  -- MODIFY  :
  -- PURPOSE : 转售定价转换省内定价
  --功    能： 获得集团ID
  FUNCTION F_GET_REF_VALUE(SPROD_OFFER_ID   NUMBER,
                           SPROD_OFFER_NAME VARCHAR2) RETURN NUMBER IS
    SREF_VALUE_ID          NUMBER(12);
    NREF_VALUE_ID          NUMBER(12);
    SPRICING_REF_OBJECT_ID NUMBER(12);
  BEGIN
    SELECT REF_VALUE_ID_SEQ.NEXTVAL INTO NREF_VALUE_ID FROM DUAL;
    INSERT INTO REF_VALUE
      (REF_VALUE_ID,
       REF_VALUE_TYPE,
       REF_VALUE_NAME,
       VALUE_TYPE,
       PRICING_REF_OBJECT_ID,
       VALUE_STRING,
       PRICING_PRARM_ID,
       PRICING_PARAM_VALUE_ID,
       RATE_PRECISION,
       CALC_PRECISION,
       RULE_ID,
       IF_CRM_TEST_GET_FLAG,
       IF_CRM_ACT_GET_FLAG,
       IF_JF_TEST_GET_FLAG,
       IF_JF_ACT_GET_FLAG,
       REF_VALUE_CONST_TYPE_ID)
      SELECT NREF_VALUE_ID,
             REF_VALUE_TYPE,
             SPROD_OFFER_NAME || '_转售' REF_VALUE_NAME,
             VALUE_TYPE,
             PRICING_REF_OBJECT_ID,
             SPROD_OFFER_ID VALUE_STRING,
             PRICING_PRARM_ID,
             PRICING_PARAM_VALUE_ID,
             RATE_PRECISION,
             CALC_PRECISION,
             RULE_ID,
             IF_CRM_TEST_GET_FLAG,
             IF_CRM_ACT_GET_FLAG,
             IF_JF_TEST_GET_FLAG,
             IF_JF_ACT_GET_FLAG,
             REF_VALUE_CONST_TYPE_ID
        FROM REF_VALUE
       WHERE REF_VALUE_ID = 807187243;

    SELECT PRICING_REF_OBJECT_ID_SEQ.NEXTVAL
      INTO SPRICING_REF_OBJECT_ID
      FROM DUAL;
    INSERT INTO PRICING_REF_OBJECT
      (PRICING_REF_OBJECT_ID,
       PRICING_REF_OBJECT_NAME,
       OWNER_ID,
       PROPERTY_TYPE,
       PROPERTY_DEFINE_ID,
       EXTERN_PROPERTY_STRING,
       MEASURE_METHOD_ID,
       HISTORY_TIME_TYPE,
       HISTORY_TIME_DURATION,
       HISTORY_TIME_QUANTITY,
       RULE_ID,
       PRICING_REF_OBJECT_TYPE,
       REF_OBJECT_ATTR_ID)
      SELECT SPRICING_REF_OBJECT_ID,
             SPROD_OFFER_NAME || '_转售' PRICING_REF_OBJECT_NAME,
             OWNER_ID,
             PROPERTY_TYPE,
             PROPERTY_DEFINE_ID,
             EXTERN_PROPERTY_STRING,
             MEASURE_METHOD_ID,
             HISTORY_TIME_TYPE,
             HISTORY_TIME_DURATION,
             HISTORY_TIME_QUANTITY,
             RULE_ID,
             PRICING_REF_OBJECT_TYPE,
             REF_OBJECT_ATTR_ID
        FROM PRICING_REF_OBJECT
       WHERE PRICING_REF_OBJECT_ID = 50152332;

    INSERT INTO PRICING_REF_OBJECT_ATTR
      (PRICING_REF_OBJECT_ID, ATTR_ID, REF_VALUE_ID, IF_SPECIFY_VALUE)
      SELECT SPRICING_REF_OBJECT_ID,
             ATTR_ID,
             NREF_VALUE_ID REF_VALUE_ID,
             IF_SPECIFY_VALUE
        FROM PRICING_REF_OBJECT_ATTR
       WHERE PRICING_REF_OBJECT_ID = 50152332;

    SELECT REF_VALUE_ID_SEQ.NEXTVAL INTO SREF_VALUE_ID FROM DUAL;
    INSERT INTO REF_VALUE
      (REF_VALUE_ID,
       REF_VALUE_TYPE,
       REF_VALUE_NAME,
       VALUE_TYPE,
       PRICING_REF_OBJECT_ID,
       VALUE_STRING,
       PRICING_PRARM_ID,
       PRICING_PARAM_VALUE_ID,
       RATE_PRECISION,
       CALC_PRECISION,
       RULE_ID,
       IF_CRM_TEST_GET_FLAG,
       IF_CRM_ACT_GET_FLAG,
       IF_JF_TEST_GET_FLAG,
       IF_JF_ACT_GET_FLAG,
       REF_VALUE_CONST_TYPE_ID)
      SELECT SREF_VALUE_ID,
             REF_VALUE_TYPE,
             SPROD_OFFER_NAME || '_转售' REF_VALUE_NAME,
             VALUE_TYPE,
             SPRICING_REF_OBJECT_ID PRICING_REF_OBJECT_ID,
             VALUE_STRING,
             PRICING_PRARM_ID,
             PRICING_PARAM_VALUE_ID,
             RATE_PRECISION,
             CALC_PRECISION,
             RULE_ID,
             IF_CRM_TEST_GET_FLAG,
             IF_CRM_ACT_GET_FLAG,
             IF_JF_TEST_GET_FLAG,
             IF_JF_ACT_GET_FLAG,
             REF_VALUE_CONST_TYPE_ID
        FROM REF_VALUE
       WHERE REF_VALUE_ID = 807187313;

    RETURN SREF_VALUE_ID;
  END F_GET_REF_VALUE;

  --功    能：获得费率参考值
  FUNCTION F_GET_RATE_REF_VALUE(SVALUE VARCHAR2) RETURN NUMBER IS
    SREF_VALUE_ID NUMBER(12);
    COUNTS        NUMBER(3);
  BEGIN
    SELECT COUNT(1)
      INTO COUNTS
      FROM REF_VALUE
     WHERE VALUE_STRING = 'SVALUE';
    IF COUNTS = 0 THEN
      SELECT REF_VALUE_ID_SEQ.NEXTVAL INTO SREF_VALUE_ID FROM DUAL;
      INSERT INTO REF_VALUE
        (REF_VALUE_ID,
         REF_VALUE_TYPE,
         REF_VALUE_NAME,
         VALUE_TYPE,
         PRICING_REF_OBJECT_ID,
         VALUE_STRING,
         PRICING_PRARM_ID,
         PRICING_PARAM_VALUE_ID,
         RATE_PRECISION,
         CALC_PRECISION,
         RULE_ID,
         IF_CRM_TEST_GET_FLAG,
         IF_CRM_ACT_GET_FLAG,
         IF_JF_TEST_GET_FLAG,
         IF_JF_ACT_GET_FLAG,
         REF_VALUE_CONST_TYPE_ID)
        SELECT SREF_VALUE_ID,
               REF_VALUE_TYPE,
               SVALUE                  REF_VALUE_NAME,
               VALUE_TYPE,
               PRICING_REF_OBJECT_ID,
               SVALUE                  VALUE_STRING,
               PRICING_PRARM_ID,
               PRICING_PARAM_VALUE_ID,
               RATE_PRECISION,
               CALC_PRECISION,
               RULE_ID,
               IF_CRM_TEST_GET_FLAG,
               IF_CRM_ACT_GET_FLAG,
               IF_JF_TEST_GET_FLAG,
               IF_JF_ACT_GET_FLAG,
               REF_VALUE_CONST_TYPE_ID
          FROM REF_VALUE
         WHERE REF_VALUE_ID = 807187318;
    ELSE
      SELECT REF_VALUE_ID
        INTO SREF_VALUE_ID
        FROM REF_VALUE
       WHERE VALUE_STRING = 'SVALUE'
         AND ROWNUM < 2;
    END IF;
    RETURN SREF_VALUE_ID;
  END F_GET_RATE_REF_VALUE;

  --功    能：复制转售租费
  PROCEDURE P_MVNO_RENT_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    CREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 1;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN


        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);
        CREFVALUEID := F_GET_REF_VALUE(CR.PROD_OFFER_ID, CR.PROD_OFFER_NAME);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_套餐费收取' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_套餐费收取' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087455;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087455
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087455';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087455,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            807187318,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     DECODE(COMPARE_REF_VALUE_ID,
                            807187313,
                            CREFVALUEID,
                            COMPARE_REF_VALUE_ID),
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;
    COMMIT;
  END P_MVNO_RENT_STRATEGY;

  --功    能：国内流量赠送
  PROCEDURE P_MVNO_GN_RATABLE_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 2;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 2;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 2;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000);
    FOR CR IN CUR LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087177;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087177
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087177';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130486,
                            '送' || to_number(CR.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087177,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10810262,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);
        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087180;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087180
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087180';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130506,
                            '送' || to_number(CR_2.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087180,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10810262,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);
        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /* DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087182;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087182
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087182';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130519,
                            '送' || to_number(CR_3.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087182,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10810262,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;
  END P_MVNO_GN_RATABLE_STRATEGY;

  --功    能：国内流量赠送_首月
  PROCEDURE P_MVNO_GN_RATABLE_SY_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 3;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 3;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 3;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    FOR CR IN CUR LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_国内流量赠送_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_国内流量赠送_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087179;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087179
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087179';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130499,
                            '送' || to_number(CR.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087179,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10810262,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_国内流量赠送_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_国内流量赠送_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087181;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087181
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087181';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130513,
                            '送' || to_number(CR_2.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087181,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10810262,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_国内流量赠送_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_国内流量赠送_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087183;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087183
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087183';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130526,
                            '送' || to_number(CR_3.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087183,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10810262,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;
  END P_MVNO_GN_RATABLE_SY_STRATEGY;

  --功    能：上网超出资费
  PROCEDURE P_MVNO_RATABLE_CH_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 4;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 4;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 4;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_上网超出资费' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_上网超出资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087186;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087186
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087186';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130535,
                            to_number(CR.VPARAM) || '/10K',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087186,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821130535,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_上网超出资费' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_上网超出资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087184;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087184
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087184';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087184,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821130529,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_上网超出资费' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_上网超出资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087185;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087185
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087185';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087185,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821130532,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;
  END P_MVNO_RATABLE_CH_STRATEGY;

  --功    能：赠送短信（新模式）
  PROCEDURE P_MVNO_RATABLE_SMS_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 5;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_赠送短信（新模式）' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_赠送短信（新模式）' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087198;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087198
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087198';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130598,
                            to_number(CR.VPARAM) || '条',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087198,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            354,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    COMMIT;
  END P_MVNO_RATABLE_SMS_STRATEGY;

  --功    能：赠送短信（新模式）
  PROCEDURE P_MVNO_RATABLE_SMS_SY_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 6;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_赠送短信_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_赠送短信_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087199;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087199
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087199';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130602,
                            to_number(CR.VPARAM) || '条',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087199,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            354,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    COMMIT;
  END P_MVNO_RATABLE_SMS_SY_STRATEGY;

  --功    能：短信超出资费
  PROCEDURE P_MVNO_SMS_CY_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 7;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN
        NPARENT_SECTION_ID := NULL;
        OPARENT_SECTION_ID := NULL;

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_短信超出资费' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_短信超出资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087017;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087017
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087017';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821129609,
                            '短信每条' || to_number(CR.VPARAM) || '厘',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087017,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     DECODE(PRICING_SECTION_ID,
                            821129609,
                            PREFVALUEID,
                            FIXED_RATE_VALUE_ID) FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;
    COMMIT;
  END P_MVNO_SMS_CY_STRATEGY;

  --功    能：赠送通话时长
  PROCEDURE P_MVNO_RATABLE_VOICE_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 8;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 8;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 8;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000);
    FOR CR IN CUR LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_赠送通话时长' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_赠送通话时长' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087192;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087192
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087192';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130560,
                            '送' || to_number(CR.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087192,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            21064,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);
        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_赠送通话时长' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_赠送通话时长' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087193;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087193
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087193';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130566,
                            '送' || to_number(CR_2.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087193,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            21064,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);
        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*    DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_赠送通话时长' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_赠送通话时长' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087195;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087195
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087195';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130579,
                            '送' || to_number(CR_3.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087195,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            21064,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;
    COMMIT;
  END P_MVNO_RATABLE_VOICE_STRATEGY;

  --功    能：赠送通话时长_首月
  PROCEDURE P_MVNO_RATABLE_VOICE_SY_STY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 9;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 9;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 9;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000);
    FOR CR IN CUR LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*       DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087191;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087191
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087191';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130551,
                            '送' || to_number(CR.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087191,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            21064,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);
        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*    DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087196;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087196
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087196';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130584,
                            '送' || to_number(CR_2.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087196,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            21064,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);
        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*        DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087197;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087197
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087197';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130591,
                            '送' || to_number(CR_3.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087197,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            21064,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;
  END P_MVNO_RATABLE_VOICE_SY_STY;

  --功    能：语音超出资费
  PROCEDURE P_MVNO_VOICE_CH_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    i                          number(3);
    TYPE TPRICINGSECTIONIDMAP IS RECORD(
      NEWPRICINGSECTIONID NUMBER,
      OLDPRICINGSECTIONID NUMBER);

    TYPE TPRICINGSECTIONIDARY IS TABLE OF TPRICINGSECTIONIDMAP;
    LPRICINGSECTIONIDARY TPRICINGSECTIONIDARY := TPRICINGSECTIONIDARY();

    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 10;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 10;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 10;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_语音超出资费' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_语音超出资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087194;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087194
             AND ROWNUM <= 1;
        LPRICINGSECTIONIDARY.delete;
        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087194';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              /*SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;*/
              i                  := 1;
              NPARENT_SECTION_ID := NULL;

              FOR I IN 1 .. LPRICINGSECTIONIDARY.COUNT LOOP
                IF LPRICINGSECTIONIDARY(I)
                 .OLDPRICINGSECTIONID = CR2.PARENT_SECTION_ID THEN
                  NPARENT_SECTION_ID := LPRICINGSECTIONIDARY(I)
                                        .NEWPRICINGSECTIONID;
                  EXIT;
                END IF;
              END LOOP;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;

            LPRICINGSECTIONIDARY.EXTEND;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).OLDPRICINGSECTIONID := CR2.PRICING_SECTION_ID;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).NEWPRICINGSECTIONID := NPRICING_SECTION_ID;

            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130574,
                            '费用1：' || to_number(CR.VPARAM) || '厘/分钟',
                            821130573,
                            '费用2：' || to_number(CR.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087194,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(/*SCALED_RATE_VALUE_ID,
                            162,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID*/
                            PRICING_SECTION_ID,
                            821130574,
                            PREFVALUEID,
                            821130573,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_语音超出资费' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_语音超出资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087187;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087187
             AND ROWNUM <= 1;
        LPRICINGSECTIONIDARY.delete;
        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087187';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130540,
                            '费用1：' || to_number(CR_2.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087187,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821130540,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_语音超出资费' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_语音超出资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820087188;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820087188
             AND ROWNUM <= 1;
        LPRICINGSECTIONIDARY.delete;
        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820087188';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821130545,
                            '费用1：' || to_number(CR_3.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820087188,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821130545,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;

  END P_MVNO_VOICE_CH_STRATEGY;

  --功    能：语音被叫
  PROCEDURE P_MVNO_VOICE_BJ_STRATEGY AS
    COUNTS NUMBER(2);
    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 11;
  BEGIN
    FOR CR IN CUR LOOP
      SELECT COUNT(1)
        INTO COUNTS
        FROM PRICING_PLAN
       WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

      IF COUNTS = 0 THEN
        INSERT INTO PRICING_PLAN
          (PRICING_PLAN_ID,
           PRICING_PLAN_NAME,
           PRICING_PLAN_CLASS,
           PRICING_DESC,
           PARAM_DESC,
           LBS_BILL_CATALOG_ID,
           PRICING_POLICY_DESC,
           LBS_CATALOG_NAME,
           LATN_ID,
           LBS_STANDARD_CODE,
           STATE,
           IF_BALANCE_INVALID,
           PRIORITY)
          SELECT CR.PRICING_PLAN_ID,
                 CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                 PRICING_PLAN_CLASS,
                 PRICING_DESC,
                 PARAM_DESC,
                 LBS_BILL_CATALOG_ID,
                 PRICING_POLICY_DESC,
                 LBS_CATALOG_NAME,
                 LATN_ID,
                 LBS_STANDARD_CODE,
                 STATE,
                 IF_BALANCE_INVALID,
                 PRIORITY
            FROM PRICING_PLAN
           WHERE PRICING_PLAN_ID = 53455;
      END IF;

      INSERT INTO PRICING_COMBINE
        (PRICING_COMBINE_ID,
         PRICING_PLAN_ID,
         EVENT_PRICING_STRATEGY_ID,
         LIFE_CYCLE_ID,
         PRICING_OBJECT_ID,
         CALC_PRIORITY,
         EFF_DATE,
         EXP_DATE,
         LBS_BILL_RULE_ID,
         LBS_RULE_NAME)
        SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
               CR.PRICING_PLAN_ID,
               EVENT_PRICING_STRATEGY_ID,
               LIFE_CYCLE_ID,
               PRICING_OBJECT_ID,
               CALC_PRIORITY,
               EFF_DATE,
               EXP_DATE,
               LBS_BILL_RULE_ID,
               LBS_RULE_NAME
          FROM PRICING_COMBINE
         WHERE EVENT_PRICING_STRATEGY_ID = 820088302
           AND ROWNUM <= 1;

      INSERT INTO PRICING_COMBINE
        (PRICING_COMBINE_ID,
         PRICING_PLAN_ID,
         EVENT_PRICING_STRATEGY_ID,
         LIFE_CYCLE_ID,
         PRICING_OBJECT_ID,
         CALC_PRIORITY,
         EFF_DATE,
         EXP_DATE,
         LBS_BILL_RULE_ID,
         LBS_RULE_NAME)
        SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
               CR.PRICING_PLAN_ID,
               EVENT_PRICING_STRATEGY_ID,
               LIFE_CYCLE_ID,
               PRICING_OBJECT_ID,
               CALC_PRIORITY,
               EFF_DATE,
               EXP_DATE,
               LBS_BILL_RULE_ID,
               LBS_RULE_NAME
          FROM PRICING_COMBINE
         WHERE EVENT_PRICING_STRATEGY_ID = 820087189
           AND ROWNUM <= 1;

      INSERT INTO PRICING_COMBINE
        (PRICING_COMBINE_ID,
         PRICING_PLAN_ID,
         EVENT_PRICING_STRATEGY_ID,
         LIFE_CYCLE_ID,
         PRICING_OBJECT_ID,
         CALC_PRIORITY,
         EFF_DATE,
         EXP_DATE,
         LBS_BILL_RULE_ID,
         LBS_RULE_NAME)
        SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
               CR.PRICING_PLAN_ID,
               EVENT_PRICING_STRATEGY_ID,
               LIFE_CYCLE_ID,
               PRICING_OBJECT_ID,
               CALC_PRIORITY,
               EFF_DATE,
               EXP_DATE,
               LBS_BILL_RULE_ID,
               LBS_RULE_NAME
          FROM PRICING_COMBINE
         WHERE EVENT_PRICING_STRATEGY_ID = 820087190
           AND ROWNUM <= 1;

      UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
         SET STATE = '00H'
       WHERE SEQ = CR.SEQ;

    END LOOP;
    COMMIT;
  END P_MVNO_VOICE_BJ_STRATEGY;

  --功    能：语音被叫（费用不为0）
  PROCEDURE P_MVNO_VOICE_BJ2_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 12;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 12;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 12;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 EVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088302
             AND ROWNUM <= 1;

        /*SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_被叫免费' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_被叫免费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088302;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088302
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088302';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088302,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;*/

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_被叫收费' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_被叫收费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088299;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088299
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088299';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821135842,
                            '省内漫游被叫' || to_number(CR_2.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088299,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821135842,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_被叫收费' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_被叫收费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088300;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088300
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088300';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821135843,
                            '省内漫游被叫' || to_number(CR_3.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088300,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821135843,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;

  END P_MVNO_VOICE_BJ2_STRATEGY;

  --功    能：转售租费(非首月)
  PROCEDURE P_MVNO_RENT2_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    CREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 13;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);
        CREFVALUEID := F_GET_REF_VALUE(CR.PROD_OFFER_ID, CR.PROD_OFFER_NAME);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_套餐费收取' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_套餐费收取' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820089073;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820089073
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820089073';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;
            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820089073,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            266,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     DECODE(COMPARE_REF_VALUE_ID,
                            807187933,
                            CREFVALUEID,
                            COMPARE_REF_VALUE_ID) COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    COMMIT;

  END P_MVNO_RENT2_STRATEGY;

  --功    能：国内流量赠送(非首月)
  PROCEDURE P_MVNO_GN_RATABLE2_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 14;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 14;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 14;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000);
    FOR CR IN CUR LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820089055;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820089055
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820089055';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821142288,
                            '送' || to_number(CR.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820089055,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10815154,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820089056;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820089056
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820089056';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821142294,
                            '送' || to_number(CR_2.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820089056,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10815154,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /* DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_国内流量赠送' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820089057;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820089057
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820089057';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821142320,
                            '送' || to_number(CR_3.VPARAM) / 1024 || 'M',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820089057,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            10815154,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;

  END P_MVNO_GN_RATABLE2_STRATEGY;

  --功    能：赠送通话时长(首月不折算)
  PROCEDURE P_MVNO_RATABLE_VOICE_BSY_STY AS
  SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    SPARENT_SECTION_ID         NUMBER(12);
    OPARENT_SECTION_ID         NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 15;

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 15;


    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000);
    FOR CR IN CUR LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*       DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088305;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088305
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088305';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821135871,
                            '送' || to_number(CR.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088305,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            862,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;

    FOR CR_2 IN CUR_2 LOOP
      BEGIN
        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);
        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;
        /*    DBMS_OUTPUT.PUT_LINE('SEVENT_PRICING_STRATEGY_ID' ||
        SEVENT_PRICING_STRATEGY_ID);*/
        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_赠送通话时长_首月' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088304;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088304
             AND ROWNUM <= 1;

        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088304';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;
            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821135865,
                            '送' || to_number(CR_2.VPARAM) || '分钟',
                            PRICING_SECTION_NAME),
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088304,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     DECODE(RESULT_REF_VALUE_ID,
                            862,
                            PREFVALUEID,
                            RESULT_REF_VALUE_ID),
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    COMMIT;
  END P_MVNO_RATABLE_VOICE_BSY_STY;

  --功    能：主叫资费
  PROCEDURE P_MVNO_VOICE_ZJ_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    i                          number(3);
    TYPE TPRICINGSECTIONIDMAP IS RECORD(
      NEWPRICINGSECTIONID NUMBER,
      OLDPRICINGSECTIONID NUMBER);

    TYPE TPRICINGSECTIONIDARY IS TABLE OF TPRICINGSECTIONIDMAP;
    LPRICINGSECTIONIDARY TPRICINGSECTIONIDARY := TPRICINGSECTIONIDARY();

    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

   /* CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 16;*/

    CURSOR CUR_2 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 16;

    CURSOR CUR_3 IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 16;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    /*FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088301;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088301
             AND ROWNUM <= 1;
        LPRICINGSECTIONIDARY.delete;
        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088301';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              \*SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;*\
              i                  := 1;
              NPARENT_SECTION_ID := NULL;

              FOR I IN 1 .. LPRICINGSECTIONIDARY.COUNT LOOP
                IF LPRICINGSECTIONIDARY(I)
                 .OLDPRICINGSECTIONID = CR2.PARENT_SECTION_ID THEN
                  NPARENT_SECTION_ID := LPRICINGSECTIONIDARY(I)
                                        .NEWPRICINGSECTIONID;
                  EXIT;
                END IF;
              END LOOP;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;

            LPRICINGSECTIONIDARY.EXTEND;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).OLDPRICINGSECTIONID := CR2.PRICING_SECTION_ID;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).NEWPRICINGSECTIONID := NPRICING_SECTION_ID;

            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821135849,
                            '费用1：' || to_number(CR.VPARAM) || '厘/分钟',
                            821135850,
                            '费用2：' || to_number(CR.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088301,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(SCALED_RATE_VALUE_ID,
                            162,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;*/

    FOR CR_2 IN CUR_2 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_2.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_2.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_2.PRICING_PLAN_ID,
                   CR_2.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_2.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_NAME,
                 CR_2.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088298;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_2.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088298
             AND ROWNUM <= 1;
        LPRICINGSECTIONIDARY.delete;
        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088298';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              /*SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;*/
              i                  := 1;
              NPARENT_SECTION_ID := NULL;

              FOR I IN 1 .. LPRICINGSECTIONIDARY.COUNT LOOP
                IF LPRICINGSECTIONIDARY(I)
                 .OLDPRICINGSECTIONID = CR2.PARENT_SECTION_ID THEN
                  NPARENT_SECTION_ID := LPRICINGSECTIONIDARY(I)
                                        .NEWPRICINGSECTIONID;
                  EXIT;
                END IF;
              END LOOP;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;

            LPRICINGSECTIONIDARY.EXTEND;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).OLDPRICINGSECTIONID := CR2.PRICING_SECTION_ID;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).NEWPRICINGSECTIONID := NPRICING_SECTION_ID;


            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821136660,
                            '费用1：' || to_number(CR_2.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088298,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821136660,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_2.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_2.SEQ);
      END;
    END LOOP;

    FOR CR_3 IN CUR_3 LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR_3.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR_3.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR_3.PRICING_PLAN_ID,
                   CR_3.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR_3.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_NAME,
                 CR_3.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088297;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR_3.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088297
             AND ROWNUM <= 1;
        LPRICINGSECTIONIDARY.delete;
        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088297';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              /*SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;*/
              i                  := 1;
              NPARENT_SECTION_ID := NULL;

              FOR I IN 1 .. LPRICINGSECTIONIDARY.COUNT LOOP
                IF LPRICINGSECTIONIDARY(I)
                 .OLDPRICINGSECTIONID = CR2.PARENT_SECTION_ID THEN
                  NPARENT_SECTION_ID := LPRICINGSECTIONIDARY(I)
                                        .NEWPRICINGSECTIONID;
                  EXIT;
                END IF;
              END LOOP;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;

            LPRICINGSECTIONIDARY.EXTEND;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).OLDPRICINGSECTIONID := CR2.PRICING_SECTION_ID;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).NEWPRICINGSECTIONID := NPRICING_SECTION_ID;

            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821136657,
                            '费用1：' || to_number(CR_3.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088297,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(PRICING_SECTION_ID,
                            821130545,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',
               COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR_3.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR_3.SEQ);
      END;
    END LOOP;

    COMMIT;

  END P_MVNO_VOICE_ZJ_STRATEGY;

  --功    能：主叫资费
  PROCEDURE P_MVNO_VOICE_ZJ2_STRATEGY AS
    SEVENT_PRICING_STRATEGY_ID NUMBER(12);
    NPRICING_SECTION_ID        NUMBER(12);
    SPRICING_SECTION_ID        NUMBER(12);
    NPARENT_SECTION_ID         NUMBER(12);
    SDISCOUNT_EXPRESS_ID       NUMBER(12);
    COUNTS                     NUMBER(3);
    PREFVALUEID                NUMBER(12);
    V_SQL                      VARCHAR2(4000);
    i                          number(3);
    TYPE TPRICINGSECTIONIDMAP IS RECORD(
      NEWPRICINGSECTIONID NUMBER,
      OLDPRICINGSECTIONID NUMBER);

    TYPE TPRICINGSECTIONIDARY IS TABLE OF TPRICINGSECTIONIDMAP;
    LPRICINGSECTIONIDARY TPRICINGSECTIONIDARY := TPRICINGSECTIONIDARY();

    TYPE STRATEGY_CURSOR IS REF CURSOR;
    V_STRATEGY_CURSOR STRATEGY_CURSOR;

    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 18;

    CURSOR CUR2(SPRICING_SECTION_ID NUMBER) IS
      SELECT PRICING_SECTION_ID, PARENT_SECTION_ID, LEVEL
        FROM PRICING_SECTION
       WHERE 1 = 1
       START WITH PRICING_SECTION_ID = SPRICING_SECTION_ID
      CONNECT BY PRIOR PRICING_SECTION_ID = PARENT_SECTION_ID;

    CURSOR CUR3(SPRICING_SECTION_ID NUMBER) IS
      SELECT DISCOUNT_EXPRESS_ID
        FROM DISCOUNT_EXPRESS
       WHERE PRICING_SECTION_ID = SPRICING_SECTION_ID;
  BEGIN
    DBMS_OUTPUT.ENABLE(1000000000000000);
    FOR CR IN CUR LOOP
      BEGIN

        PREFVALUEID := F_GET_RATE_REF_VALUE(CR.VPARAM);

        SELECT COUNT(1)
          INTO COUNTS
          FROM PRICING_PLAN
         WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

        IF COUNTS = 0 THEN
          INSERT INTO PRICING_PLAN
            (PRICING_PLAN_ID,
             PRICING_PLAN_NAME,
             PRICING_PLAN_CLASS,
             PRICING_DESC,
             PARAM_DESC,
             LBS_BILL_CATALOG_ID,
             PRICING_POLICY_DESC,
             LBS_CATALOG_NAME,
             LATN_ID,
             LBS_STANDARD_CODE,
             STATE,
             IF_BALANCE_INVALID,
             PRIORITY)
            SELECT CR.PRICING_PLAN_ID,
                   CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                   PRICING_PLAN_CLASS,
                   PRICING_DESC,
                   PARAM_DESC,
                   LBS_BILL_CATALOG_ID,
                   PRICING_POLICY_DESC,
                   LBS_CATALOG_NAME,
                   LATN_ID,
                   LBS_STANDARD_CODE,
                   STATE,
                   IF_BALANCE_INVALID,
                   PRIORITY
              FROM PRICING_PLAN
             WHERE PRICING_PLAN_ID = 53455;
        END IF;

        SELECT EVENT_PRICING_STRATEGY_ID_SEQ.NEXTVAL
          INTO SEVENT_PRICING_STRATEGY_ID
          FROM DUAL;

        INSERT INTO EVENT_PRICING_STRATEGY
          (EVENT_PRICING_STRATEGY_ID,
           EVENT_TYPE_ID,
           EVENT_PRICING_STRATEGY_NAME,
           EVENT_PRICING_STRATEGY_DESC,
           EVENT_PRICING_STRATEGY_TYPE,
           PRICING_TEMPLATE_INSTANCE_ID,
           STATE)
          SELECT SEVENT_PRICING_STRATEGY_ID,
                 EVENT_TYPE_ID,
                 CR.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_NAME,
                 CR.PROD_OFFER_NAME || '_语音主叫资费' EVENT_PRICING_STRATEGY_DESC,
                 EVENT_PRICING_STRATEGY_TYPE,
                 PRICING_TEMPLATE_INSTANCE_ID,
                 STATE
            FROM EVENT_PRICING_STRATEGY A
           WHERE A.EVENT_PRICING_STRATEGY_ID = 820088301;

        INSERT INTO PRICING_COMBINE
          (PRICING_COMBINE_ID,
           PRICING_PLAN_ID,
           EVENT_PRICING_STRATEGY_ID,
           LIFE_CYCLE_ID,
           PRICING_OBJECT_ID,
           CALC_PRIORITY,
           EFF_DATE,
           EXP_DATE,
           LBS_BILL_RULE_ID,
           LBS_RULE_NAME)
          SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
                 CR.PRICING_PLAN_ID,
                 SEVENT_PRICING_STRATEGY_ID,
                 LIFE_CYCLE_ID,
                 PRICING_OBJECT_ID,
                 CALC_PRIORITY,
                 EFF_DATE,
                 EXP_DATE,
                 LBS_BILL_RULE_ID,
                 LBS_RULE_NAME
            FROM PRICING_COMBINE
           WHERE EVENT_PRICING_STRATEGY_ID = 820088301
             AND ROWNUM <= 1;
        LPRICINGSECTIONIDARY.delete;
        V_SQL := 'SELECT PRICING_SECTION_ID FROM PRICING_SECTION WHERE EVENT_PRICING_STRATEGY_ID=820088301';

        OPEN V_STRATEGY_CURSOR FOR V_SQL;
        LOOP
          FETCH V_STRATEGY_CURSOR
            INTO SPRICING_SECTION_ID;
          EXIT WHEN V_STRATEGY_CURSOR%NOTFOUND;

          FOR CR2 IN CUR2(SPRICING_SECTION_ID) LOOP
            IF CR2.LEVEL = 1 THEN
              NPARENT_SECTION_ID := NULL;
            ELSE
              /*SELECT PARENT_SECTION_ID
                INTO SPARENT_SECTION_ID
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;
              IF NVL(OPARENT_SECTION_ID, 1) <> SPARENT_SECTION_ID THEN
                NPARENT_SECTION_ID := NPRICING_SECTION_ID;
                OPARENT_SECTION_ID := SPARENT_SECTION_ID;
              END IF;*/
              i                  := 1;
              NPARENT_SECTION_ID := NULL;

              FOR I IN 1 .. LPRICINGSECTIONIDARY.COUNT LOOP
                IF LPRICINGSECTIONIDARY(I)
                 .OLDPRICINGSECTIONID = CR2.PARENT_SECTION_ID THEN
                  NPARENT_SECTION_ID := LPRICINGSECTIONIDARY(I)
                                        .NEWPRICINGSECTIONID;
                  EXIT;
                END IF;
              END LOOP;

            END IF;

            SELECT PRICING_SECTION_ID_SEQ.NEXTVAL
              INTO NPRICING_SECTION_ID
              FROM DUAL;

            LPRICINGSECTIONIDARY.EXTEND;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).OLDPRICINGSECTIONID := CR2.PRICING_SECTION_ID;
            LPRICINGSECTIONIDARY(LPRICINGSECTIONIDARY.COUNT).NEWPRICINGSECTIONID := NPRICING_SECTION_ID;

            INSERT INTO PRICING_SECTION
              (PRICING_SECTION_ID,
               SECTION_TYPE_ID,
               SECTION_CALC_TYPE,
               PRICING_SECTION_NAME,
               PARENT_SECTION_ID,
               PRICING_REF_OBJECT_ID,
               ZONE_ITEM_ID,
               CYCLE_SECTION_BEGIN,
               CYCLE_SECTION_DURATION,
               START_REF_VALUE_ID,
               END_REF_VALUE_ID,
               JUDGE_RESULT,
               EVENT_PRICING_STRATEGY_ID,
               CALC_PRIORITY,
               MANAGE_REGION_ID,
               STATE)
              SELECT NPRICING_SECTION_ID,
                     SECTION_TYPE_ID,
                     SECTION_CALC_TYPE,
                     DECODE(PRICING_SECTION_ID,
                            821135849,
                            '费用1：' || to_number(CR.VPARAM) || '厘/分钟',
                            821135850,
                            '费用2：' || to_number(CR.VPARAM) || '厘/分钟',
                            PRICING_SECTION_NAME) PRICING_SECTION_NAME,
                     NPARENT_SECTION_ID PARENT_SECTION_ID,
                     PRICING_REF_OBJECT_ID,
                     ZONE_ITEM_ID,
                     CYCLE_SECTION_BEGIN,
                     CYCLE_SECTION_DURATION,
                     START_REF_VALUE_ID,
                     END_REF_VALUE_ID,
                     JUDGE_RESULT,
                     DECODE(EVENT_PRICING_STRATEGY_ID,
                            820088301,
                            SEVENT_PRICING_STRATEGY_ID,
                            EVENT_PRICING_STRATEGY_ID),
                     CALC_PRIORITY,
                     MANAGE_REGION_ID,
                     STATE
                FROM PRICING_SECTION
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_VARIABLE_CALC
              (VARIABLE_CALC_ID,
               VARIABLE_REF_VALUE_ID,
               RESULT_REF_VALUE_ID,
               PRICING_SECTION_ID,
               CALC_PRIORITY)
              SELECT PRICING_VARIABLE_CALC_ID_SEQ.NEXTVAL,
                     VARIABLE_REF_VALUE_ID,
                     RESULT_REF_VALUE_ID,
                     NPRICING_SECTION_ID,
                     CALC_PRIORITY
                FROM PRICING_VARIABLE_CALC
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO PRICING_RULE
              (PRICING_RULE_ID,
               PRICING_SECTION_ID,
               COMPARE_REF_VALUE_ID,
               OPERATOR_ID,
               RESULT_REF_VALUE_ID,
               GROUP_ID,
               COMMENTS)
              SELECT PRICING_RULE_ID_SEQ.NEXTVAL,
                     NPRICING_SECTION_ID,
                     COMPARE_REF_VALUE_ID,
                     OPERATOR_ID,
                     RESULT_REF_VALUE_ID,
                     GROUP_ID,
                     COMMENTS
                FROM PRICING_RULE PR
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            INSERT INTO TARIFF
              (TARIFF_ID,
               TARIFF_TYPE,
               PRICING_SECTION_ID,
               RESOURCE_ID,
               ACTION_ID,
               ACCT_ITEM_SOURCE_ID,
               ACCT_ITEM_TYPE_ID,
               SUB_PRODUCT_ID,
               TARIFF_UNIT_ID,
               CALC_METHOD_ID,
               FIXED_RATE_VALUE_ID,
               SCALED_SOURCE_VALUE_ID,
               RATE_UNIT,
               SCALED_RATE_VALUE_ID,
               CALC_PRIORITY,
               BELONG_CYCLE_DURATION,
               CHARGE_PARTY_ID,
               RESULT_ITEM_TYPE,
               REPLACE_FLAG,
               ACCT_ITEM_TYPE_ATTR,
               ACCT_ITEM_CLASS,
               IF_DEDUCT_OLD_OWE,
               IF_GET_PARTNER_ID,
               CAL_MODE_TYPE,
               BELONG_OBJECT_TYPE,
               TARIFF_UNIT_CALC_METHOD,
               CALC_UNIT_CALC_METHOD,
               CALC_RESULT_CALC_METHOD,
               RESOURCE_LIMIT_VALUE_ID,
               SPECIFY_OWNERID_VALUE_ID,
               SPECIFY_PRICEID_VALUE_ID,
               RESOURCE_LOW_LIMIT_VALUE_ID)
              SELECT TARIFF_ID_SEQ.NEXTVAL,
                     TARIFF_TYPE,
                     NPRICING_SECTION_ID,
                     RESOURCE_ID,
                     ACTION_ID,
                     ACCT_ITEM_SOURCE_ID,
                     ACCT_ITEM_TYPE_ID,
                     SUB_PRODUCT_ID,
                     TARIFF_UNIT_ID,
                     CALC_METHOD_ID,
                     FIXED_RATE_VALUE_ID,
                     SCALED_SOURCE_VALUE_ID,
                     RATE_UNIT,
                     DECODE(/*SCALED_RATE_VALUE_ID,
                            162,
                            PREFVALUEID,*/
                            PRICING_SECTION_ID,
                            821135849,
                            PREFVALUEID,
                            821135850,
                            PREFVALUEID,
                            SCALED_RATE_VALUE_ID) SCALED_RATE_VALUE_ID,
                     CALC_PRIORITY,
                     BELONG_CYCLE_DURATION,
                     CHARGE_PARTY_ID,
                     RESULT_ITEM_TYPE,
                     REPLACE_FLAG,
                     ACCT_ITEM_TYPE_ATTR,
                     ACCT_ITEM_CLASS,
                     IF_DEDUCT_OLD_OWE,
                     IF_GET_PARTNER_ID,
                     CAL_MODE_TYPE,
                     BELONG_OBJECT_TYPE,
                     TARIFF_UNIT_CALC_METHOD,
                     CALC_UNIT_CALC_METHOD,
                     CALC_RESULT_CALC_METHOD,
                     RESOURCE_LIMIT_VALUE_ID,
                     SPECIFY_OWNERID_VALUE_ID,
                     SPECIFY_PRICEID_VALUE_ID,
                     RESOURCE_LOW_LIMIT_VALUE_ID
                FROM TARIFF
               WHERE PRICING_SECTION_ID = CR2.PRICING_SECTION_ID;

            FOR CR3 IN CUR3(CR2.PRICING_SECTION_ID) LOOP

              SELECT DISCOUNT_EXPRESS_ID_SEQ.NEXTVAL
                INTO SDISCOUNT_EXPRESS_ID
                FROM DUAL;

              INSERT INTO DISCOUNT_EXPRESS
                (DISCOUNT_EXPRESS_ID,
                 PRICING_SECTION_ID,
                 DISCOUNT_METHOD_ID,
                 RATABLE_RESOURCE_ID,
                 START_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 DISCOUNT_RATE_VALUE_ID,
                 FIXED_VALUE_ID,
                 CALC_PRIORITY,
                 ACTION_ID)
                SELECT SDISCOUNT_EXPRESS_ID,
                       NPRICING_SECTION_ID,
                       DE.DISCOUNT_METHOD_ID,
                       DE.RATABLE_RESOURCE_ID,
                       DE.START_REF_VALUE_ID,
                       DE.END_REF_VALUE_ID,
                       DE.DISCOUNT_RATE_VALUE_ID,
                       DE.FIXED_VALUE_ID,
                       DE.CALC_PRIORITY,
                       DE.ACTION_ID
                  FROM DISCOUNT_EXPRESS DE
                 WHERE DE.DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TIME_LIMIT
                (DISCOUNT_TIME_LIMIT_ID,
                 DISCOUNT_EXPRESS_ID,
                 DISCOUNT_CYCLE_TYPE,
                 BEGIN_REF_VALUE_ID,
                 BEGIN_OFFSET_REF_VALUE_ID,
                 END_REF_VALUE_ID,
                 END_OFFSET_REF_VALUE_ID)
                SELECT DISCOUNT_TIME_LIMIT_ID_SEQ.NEXTVAL,
                       SDISCOUNT_EXPRESS_ID,
                       DISCOUNT_CYCLE_TYPE,
                       BEGIN_REF_VALUE_ID,
                       BEGIN_OFFSET_REF_VALUE_ID,
                       END_REF_VALUE_ID,
                       END_OFFSET_REF_VALUE_ID
                  FROM DISCOUNT_TIME_LIMIT DTL
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_TARGET_OBJECT
                (DISCOUNT_EXPRESS_ID,
                 PRICING_REF_OBJECT_ID,
                 REPATITION_TYPE_ID,
                 INSTALLMENT_REF_VALUE_ID,
                 TARGET_ACCT_ITEM_TYPE)
                SELECT SDISCOUNT_EXPRESS_ID,
                       PRICING_REF_OBJECT_ID,
                       REPATITION_TYPE_ID,
                       INSTALLMENT_REF_VALUE_ID,
                       TARGET_ACCT_ITEM_TYPE
                  FROM DISCOUNT_TARGET_OBJECT
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

              INSERT INTO DISCOUNT_CALC_REF_VALUE
                (DISCOUNT_EXPRESS_ID, REF_VALUE_ID)
                SELECT SDISCOUNT_EXPRESS_ID, REF_VALUE_ID
                  FROM DISCOUNT_CALC_REF_VALUE
                 WHERE DISCOUNT_EXPRESS_ID = CR3.DISCOUNT_EXPRESS_ID;

            END LOOP;
          END LOOP;
        END LOOP;

        UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
           SET STATE    = '00H',COMMENTS = COMMENTS || ';' || SEVENT_PRICING_STRATEGY_ID
         WHERE SEQ = CR.SEQ;

      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 4000) || ';seq:' ||
                               CR.SEQ);
      END;
    END LOOP;



    COMMIT;

  END P_MVNO_VOICE_ZJ2_STRATEGY;

  --功    能：转售赠送来显
  PROCEDURE P_MVNO_RATE_ZS_STRATEGY AS
  COUNTS NUMBER(2);
    CURSOR CUR IS
      SELECT *
        FROM MVNO_LTE_PRICING_PLAN_CONFIG
       WHERE STATE = '00A'
         AND STYPE = 17;
  BEGIN
    FOR CR IN CUR LOOP
      SELECT COUNT(1)
        INTO COUNTS
        FROM PRICING_PLAN
       WHERE PRICING_PLAN_ID = CR.PRICING_PLAN_ID;

      IF COUNTS = 0 THEN
        INSERT INTO PRICING_PLAN
          (PRICING_PLAN_ID,
           PRICING_PLAN_NAME,
           PRICING_PLAN_CLASS,
           PRICING_DESC,
           PARAM_DESC,
           LBS_BILL_CATALOG_ID,
           PRICING_POLICY_DESC,
           LBS_CATALOG_NAME,
           LATN_ID,
           LBS_STANDARD_CODE,
           STATE,
           IF_BALANCE_INVALID,
           PRIORITY)
          SELECT CR.PRICING_PLAN_ID,
                 CR.PROD_OFFER_NAME || '_转售' PRICING_PLAN_NAME,
                 PRICING_PLAN_CLASS,
                 PRICING_DESC,
                 PARAM_DESC,
                 LBS_BILL_CATALOG_ID,
                 PRICING_POLICY_DESC,
                 LBS_CATALOG_NAME,
                 LATN_ID,
                 LBS_STANDARD_CODE,
                 STATE,
                 IF_BALANCE_INVALID,
                 PRIORITY
            FROM PRICING_PLAN
           WHERE PRICING_PLAN_ID = 53455;
      END IF;

      INSERT INTO PRICING_COMBINE
        (PRICING_COMBINE_ID,
         PRICING_PLAN_ID,
         EVENT_PRICING_STRATEGY_ID,
         LIFE_CYCLE_ID,
         PRICING_OBJECT_ID,
         CALC_PRIORITY,
         EFF_DATE,
         EXP_DATE,
         LBS_BILL_RULE_ID,
         LBS_RULE_NAME)
        SELECT PRICING_COMBINE_ID_SEQ.NEXTVAL,
               CR.PRICING_PLAN_ID,
               EVENT_PRICING_STRATEGY_ID,
               LIFE_CYCLE_ID,
               PRICING_OBJECT_ID,
               CALC_PRIORITY,
               EFF_DATE,
               EXP_DATE,
               LBS_BILL_RULE_ID,
               LBS_RULE_NAME
          FROM PRICING_COMBINE
         WHERE EVENT_PRICING_STRATEGY_ID = 820089973
           AND ROWNUM <= 1;

      UPDATE MVNO_LTE_PRICING_PLAN_CONFIG
         SET STATE = '00H'
       WHERE SEQ = CR.SEQ;

    END LOOP;
    COMMIT;

  END P_MVNO_RATE_ZS_STRATEGY;

  --主过程
  PROCEDURE P_MVNO_PRICING_PLAN_QL AS
  BEGIN
    P_MVNO_RENT_STRATEGY;
    P_MVNO_GN_RATABLE_STRATEGY;
    P_MVNO_GN_RATABLE_SY_STRATEGY;
    P_MVNO_RATABLE_CH_STRATEGY;
    P_MVNO_RATABLE_SMS_STRATEGY;
    P_MVNO_RATABLE_SMS_SY_STRATEGY;
    P_MVNO_SMS_CY_STRATEGY;
    P_MVNO_RATABLE_VOICE_STRATEGY;
    P_MVNO_RATABLE_VOICE_SY_STY;
    P_MVNO_VOICE_CH_STRATEGY;
    P_MVNO_VOICE_BJ_STRATEGY;
    P_MVNO_VOICE_BJ2_STRATEGY;
    P_MVNO_RENT2_STRATEGY;
    P_MVNO_GN_RATABLE2_STRATEGY;
    P_MVNO_RATABLE_VOICE_BSY_STY;
    P_MVNO_VOICE_ZJ_STRATEGY;
    P_MVNO_VOICE_ZJ2_STRATEGY;
    P_MVNO_RATE_ZS_STRATEGY;
    COMMIT;
  END P_MVNO_PRICING_PLAN_QL;

END PKG_PRICINGPLAN_CONV;
/
