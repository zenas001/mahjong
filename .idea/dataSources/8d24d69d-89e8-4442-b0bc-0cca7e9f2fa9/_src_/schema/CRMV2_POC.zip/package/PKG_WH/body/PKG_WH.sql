CREATE PACKAGE BODY           pkg_wh IS
  PROCEDURE new_p_ins_billing_update(i_table_name  IN VARCHAR2,
                                     i_column_name IN VARCHAR2,
                                     i_key_id      IN NUMBER,
                                     i_remark      IN VARCHAR2,
                                     in_modi_staff IN VARCHAR2,
                                     o_msg         OUT VARCHAR2) IS
    --功　　能：手工变动数据送计费接口表（INTF_INS_BILLING_UPDATE）,INS_ODS_UPDATE_CRMV2,INS_UAM_UPDATE进行更新数据
    --创建时间：2012-8-2
    --参    数：
    /*i_table_name :表示送计费接口的表名
    i_column_name ：表示字段名
    i_key_id     :表示送计费接口的表名对应的主键ID
    i_remark     :表示送计费接口的原因
    i_modify_man :表示修改数据的操作人*/
    o_result        VARCHAR2(200);
    v_boolean       BOOLEAN := TRUE;
    v_i_table_name  itsc_crmv2.intf_ins_billing_update.table_name%TYPE;
    v_i_column_name itsc_crmv2.intf_ins_billing_update.column_name%TYPE;
    --  V_NUM1          NUMBER(10) DEFAULT 0;
    v_num2        NUMBER(10) DEFAULT 0;
    v_num3        NUMBER(10) DEFAULT 0;
    v_in_modi_man VARCHAR2(100);
    i_modify_man  VARCHAR2(100);
    v_count       NUMBER;
  BEGIN
    i_modify_man := in_modi_staff;
    --去掉空格，并转化为大写
    v_i_table_name  := upper(TRIM(i_table_name));
    v_i_column_name := upper(TRIM(i_column_name));
    v_in_modi_man   := upper(TRIM(i_modify_man));

    IF v_in_modi_man IN ('CRM', 'WH', 'NULL') OR v_in_modi_man IS NULL THEN
      raise_application_error(-20203, '修改人请勿用CRM/WH,请输具体修改人');
    ELSIF i_key_id IS NULL THEN
      raise_application_error(-20203, 'I_KEY_ID 不能为空');
    END IF;
    --add zzy 20120911 记录送接口的信息
    --itsc_crmv2.p_ins_log(I_REMARK);
    --表的判断
    IF v_i_table_name = 'CUST' AND v_i_column_name = 'CUST_ID' THEN
      UPDATE crmv2.cust
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE cust_id = i_key_id;
      UPDATE crmv2.cust_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE cust_id = i_key_id;

      SELECT COUNT(*) INTO v_num2 FROM crmv2.cust WHERE cust_id = i_key_id;
      SELECT COUNT(*)
        INTO v_num3
        FROM crmv2.cust_his
       WHERE cust_id = i_key_id;

      --UAM
      INSERT INTO crmv2.ins_uam_update_crmv2
      VALUES
        (crmv2.ins_uam_update_crmv2_id_seq.nextval,
         'CUST',
         i_key_id,
         '10A',
         'CUST_ID',
         SYSDATE);

      COMMIT;
      NULL;
      --------------
    ELSIF v_i_table_name = 'PARTY' AND v_i_column_name = 'PARTY_ID' THEN
      UPDATE crmv2.party
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE party_id = i_key_id;
      UPDATE crmv2.party_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE party_id = i_key_id;
      --

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.party
       WHERE party_id = i_key_id;
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.party_his
       WHERE party_id = i_key_id;

      ---------------
    ELSIF v_i_table_name = 'PAYMENT_PLAN' AND
          v_i_column_name = 'PAYMENT_PLAN' THEN
      UPDATE crmv2.payment_plan
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE payment_plan = i_key_id;
      UPDATE crmv2.payment_plan_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE payment_plan = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.payment_plan
       WHERE payment_plan = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.payment_plan_his
       WHERE payment_plan = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'ACCOUNT' AND v_i_column_name = 'ACCOUNT_ID' THEN
      UPDATE crmv2.account
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE account_id = i_key_id;
      UPDATE crmv2.account_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE account_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.account
       WHERE account_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.account_his
       WHERE account_id = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'PROD_INST_ACCT' AND
          v_i_column_name = 'PROD_INST_ACCT_ID' THEN
      UPDATE crmv2.prod_inst_acct
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_acct_id = i_key_id;
      UPDATE crmv2.prod_inst_acct_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_acct_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.prod_inst_acct
       WHERE prod_inst_acct_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.prod_inst_acct_his
       WHERE prod_inst_acct_id = i_key_id;
      -------------------
    ELSIF v_i_table_name = 'PROD_INST' AND v_i_column_name = 'PROD_INST_ID' THEN
      UPDATE crmv2.prod_inst
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_id = i_key_id;
      UPDATE crmv2.prod_inst_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_id = i_key_id;

      SELECT COUNT(*)
        INTO v_num2
        FROM crmv2.prod_inst
       WHERE prod_inst_id = i_key_id
         AND status_cd <> '130000';
      SELECT COUNT(*)
        INTO v_num3
        FROM crmv2.prod_inst_his
       WHERE prod_inst_id = i_key_id;

      --UAM
      INSERT INTO crmv2.ins_uam_update_crmv2
      VALUES
        (crmv2.ins_uam_update_crmv2_id_seq.nextval,
         'PROD_INST',
         i_key_id,
         '10A',
         'PROD_INST_ID',
         SYSDATE);

      COMMIT;
      NULL;
      ---------------
    ELSIF v_i_table_name = 'PROD_INST_ATTR' AND
          v_i_column_name = 'PROD_INST_ATTR_ID' THEN

      --linsong begin
      --产品属性在计费那边有,则上传
    /*  SELECT COUNT(1)
        INTO v_count
        FROM (SELECT a.attr_id
                FROM prod_inst_attr a
               WHERE a.attr_id IN
                     (SELECT attr_id
                        FROM ofcs_cfg_rel.v_pr_tpr_prod_attr_spec@lk_fj_jfin)
                 AND a.prod_inst_attr_id = i_key_id
              UNION ALL
              SELECT a.attr_id
                FROM prod_inst_attr_his a
               WHERE a.attr_id IN
                     (SELECT attr_id
                        FROM ofcs_cfg_rel.v_pr_tpr_prod_attr_spec@lk_fj_jfin)
                 AND a.prod_inst_attr_id = i_key_id);

      IF v_count = 0 THEN
        o_msg := '产品属性不在计费上传范围,无需上传';
        INSERT INTO itsc_crmv2.crm_wh_bak
          (tal_name,
           key_id,
           modi_column,
           modi_area,
           old_value,
           new_value,
           modi_action,
           modi_spec,
           offer_spec,
           proce,
           modi_staff,
           staff_area,
           modi_reason,
           modi_time,
           reason,
           modi_type)
        VALUES
          ('PROD_INST_ATTR',
           i_key_id,
           '',
           '',
           '',
           '',
           '',
           '',
           '',
           'NEW_P_INS_BILLING_UPDATE',
           in_modi_staff,
           '',
           o_msg,
           SYSDATE,
           i_remark,
           '产品属性');
        RETURN;
      END IF;*/
      --linsong end

      UPDATE crmv2.prod_inst_attr
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_attr_id = i_key_id;
      UPDATE crmv2.prod_inst_attr_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_attr_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.prod_inst_attr
       WHERE prod_inst_attr_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.prod_inst_attr_his
       WHERE prod_inst_attr_id = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'PROD_INST_REL' AND
          v_i_column_name = 'PROD_INST_REL_ID' THEN
      UPDATE crmv2.prod_inst_rel
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_rel_id = i_key_id;
      UPDATE crmv2.prod_inst_rel_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_inst_rel_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.prod_inst_rel
       WHERE prod_inst_rel_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.prod_inst_rel_his
       WHERE prod_inst_rel_id = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'OFFER_PROD_INST_REL' AND
          v_i_column_name = 'OFFER_PROD_INST_REL_ID' THEN
      UPDATE crmv2.offer_prod_inst_rel
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE offer_prod_inst_rel_id = i_key_id;
      UPDATE crmv2.offer_prod_inst_rel_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE offer_prod_inst_rel_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.offer_prod_inst_rel
       WHERE offer_prod_inst_rel_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.offer_prod_inst_rel_his
       WHERE offer_prod_inst_rel_id = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'PROD_OFFER_INST' AND
          v_i_column_name = 'PROD_OFFER_INST_ID' THEN
      UPDATE crmv2.prod_offer_inst
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_offer_inst_id = i_key_id;
      UPDATE crmv2.prod_offer_inst_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_offer_inst_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.prod_offer_inst
       WHERE prod_offer_inst_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.prod_offer_inst_his
       WHERE prod_offer_inst_id = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'PROD_OFFER_INST_REL' AND
          v_i_column_name = 'PROD_OFFER_INST_REL_ID' THEN
      UPDATE crmv2.prod_offer_inst_rel
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_offer_inst_rel_id = i_key_id;
      UPDATE crmv2.prod_offer_inst_rel_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_offer_inst_rel_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.prod_offer_inst_rel
       WHERE prod_offer_inst_rel_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.prod_offer_inst_rel_his
       WHERE prod_offer_inst_rel_id = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'PROD_OFFER_INST_ATTR' AND
          v_i_column_name = 'PROD_OFFER_INST_ATTR_ID' THEN
      --linsong begin
      --销售品属性
    /*  SELECT COUNT(1)
        INTO v_count
        FROM (SELECT a.attr_id
                FROM prod_offer_inst_attr a
               WHERE attr_id IN
                     (SELECT attr_id
                        FROM ofcs_cfg_rel.v_pr_tpr_prod_offer_attr_spec@lk_fj_jfin
                      UNION
                      SELECT attr_id FROM attr_spec WHERE class_id = -6)
                 AND a.prod_offer_inst_attr_id = i_key_id
              UNION ALL
              SELECT a.attr_id
                FROM prod_offer_inst_attr_his a
               WHERE attr_id IN
                     (SELECT attr_id
                        FROM ofcs_cfg_rel.v_pr_tpr_prod_offer_attr_spec@lk_fj_jfin
                      UNION
                      SELECT attr_id FROM attr_spec WHERE class_id = -6)
                 AND a.prod_offer_inst_attr_id = i_key_id);
      IF v_count = 0 THEN
        o_msg := '销售品属性不在计费上传范围,无需上传';
        INSERT INTO itsc_crmv2.crm_wh_bak
          (tal_name,
           key_id,
           modi_column,
           modi_area,
           old_value,
           new_value,
           modi_action,
           modi_spec,
           offer_spec,
           proce,
           modi_staff,
           staff_area,
           modi_reason,
           modi_time,
           reason,
           modi_type)
        VALUES
          ('PROD_OFFER_INST_ATTR',
           i_key_id,
           '',
           '',
           '',
           '',
           '',
           '',
           '',
           'NEW_P_INS_BILLING_UPDATE',
           in_modi_staff,
           '',
           o_msg,
           SYSDATE,
           i_remark,
           '销售品属性');
        RETURN;
      END IF;*/
      --linsong end

      UPDATE crmv2.prod_offer_inst_attr
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_offer_inst_attr_id = i_key_id;
      UPDATE crmv2.prod_offer_inst_attr_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE prod_offer_inst_attr_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.prod_offer_inst_attr
       WHERE prod_offer_inst_attr_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.prod_offer_inst_attr_his
       WHERE prod_offer_inst_attr_id = i_key_id;
      ---------------
    ELSIF v_i_table_name = 'PROD_OFFER_MEMBER_INST' AND
          v_i_column_name = 'MEMBER_INST_ID' THEN
      UPDATE crmv2.prod_offer_member_inst
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE member_inst_id = i_key_id;
      UPDATE crmv2.prod_offer_member_inst_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE member_inst_id = i_key_id;

      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.prod_offer_member_inst
       WHERE member_inst_id = i_key_id
         AND status_cd <> '1299';
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.prod_offer_member_inst_his
       WHERE member_inst_id = i_key_id;

    ELSIF v_i_table_name = 'VPN_PHS2CDMA' AND v_i_column_name = 'MEMBER_ID' THEN

      UPDATE crmv2.vpn_phs2cdma
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE member_id = i_key_id;
      UPDATE crmv2.vpn_phs2cdma_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE member_id = i_key_id;
      ---
      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.vpn_phs2cdma
       WHERE member_id = i_key_id;
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.vpn_phs2cdma_his
       WHERE member_id = i_key_id;

      /*ELSIF V_I_TABLE_NAME = 'CUST_EXTERNAL_ATTR' AND--20120805 彭晶与计费确认该表无需上传
          V_I_COLUMN_NAME = 'CUST_EXTERNAL_ATTR_ID' THEN

      UPDATE CRMV2.CUST_EXTERNAL_ATTR
         SET UPDATE_DATE = TRUNC(SYSDATE + 1 / 24, 'HH24')
       WHERE CUST_EXTERNAL_ATTR_ID = I_KEY_ID;
      UPDATE CRMV2.CUST_EXTERNAL_ATTR_HIS
         SET UPDATE_DATE = TRUNC(SYSDATE + 1 / 24, 'HH24')
       WHERE CUST_EXTERNAL_ATTR_ID = I_KEY_ID;
      ---
      SELECT COUNT(1)
        INTO V_NUM2
        FROM CRMV2.CUST_EXTERNAL_ATTR
       WHERE CUST_EXTERNAL_ATTR_ID = I_KEY_ID;
      SELECT COUNT(1)
        INTO V_NUM3
        FROM CRMV2.CUST_EXTERNAL_ATTR_HIS
       WHERE CUST_EXTERNAL_ATTR_ID = I_KEY_ID;*/

      -------------------------------------------------------------
    ELSIF v_i_table_name = 'CLUB_MEMBER' AND --20120805 彭晶与计费确认该表需上传
          v_i_column_name = 'MEMBER_ID' THEN

      UPDATE crmv2.club_member
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE member_id = i_key_id;
      UPDATE crmv2.club_member_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE member_id = i_key_id;
      ---
      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.club_member
       WHERE member_id = i_key_id;
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.club_member_his
       WHERE member_id = i_key_id;
      ---------------------------------------------------------------
    ELSIF v_i_table_name = 'CREDIT_LIMIT' AND --20120805 彭晶与计费确认该表需上传
          v_i_column_name = 'CREDIT_LIMIT_ID' THEN

      UPDATE crmv2.credit_limit
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE credit_limit_id = i_key_id;
      UPDATE crmv2.credit_limit_his
         SET update_date = trunc(SYSDATE + 1 / 24, 'HH24')
       WHERE credit_limit_id = i_key_id;
      ---
      SELECT COUNT(1)
        INTO v_num2
        FROM crmv2.credit_limit
       WHERE credit_limit_id = i_key_id;
      SELECT COUNT(1)
        INTO v_num3
        FROM crmv2.credit_limit_his
       WHERE credit_limit_id = i_key_id;
      ---------------------------------------------------------------------------

    ELSIF v_i_table_name = 'IVPN_NBR' AND v_i_column_name = 'REC_ID' THEN
      NULL;

    ELSE
      v_boolean := FALSE;
      raise_application_error(-20203,
                              '送的表名  "' || i_table_name || '"  或列表  "' ||
                               i_column_name || '"  出错,请检查');
    END IF;

    IF v_num2 = 0 AND v_num3 = 0 THEN
      new_ins_ods_update(v_i_table_name, v_i_column_name, i_key_id,
                         i_modify_man);
    END IF;

    IF v_boolean THEN
      IF NOT f_insert_billing_update(i_table_name, i_key_id, i_remark,
                                     i_modify_man) THEN
        o_result := i_table_name || '.' || i_column_name || '=' || i_key_id ||
                    ',送计费接口表失败！';
        --DBMS_OUTPUT.PUT_LINE(O_RESULT);
      ELSE
        o_result := '送计费接口表成功';
      END IF;
    ELSE
      o_result := i_table_name || '.' || i_column_name || '=' || i_key_id ||
                  ',送计费接口表失败（传入表名不正确或无需送接口）！';
      --DBMS_OUTPUT.PUT_LINE(O_RESULT);
    END IF;

    proc_intf_ins_billing_update(i_table_name, i_column_name, i_key_id,
                                 i_remark, i_modify_man);
    /*  O_RESULT := itsc_itsc_crmv2.fun_INS_BILL_UPDATE_OCS(I_TABLE_NAME,
    V_I_COLUMN_NAME,
    I_KEY_ID,
    I_MODIFY_MAN);*/

    --DBMS_OUTPUT.PUT_LINE(O_RESULT);
    o_msg := o_result;
  END new_p_ins_billing_update;

  /*PROCEDURE table_1_to_his(in_table  IN VARCHAR2,
                           in_key    IN VARCHAR2,
                           in_reason IN VARCHAR2,
                           in_staff  IN VARCHAR2,
                           in_exp    IN VARCHAR2,
                           o_result  OUT VARCHAR2) IS
    v_table   VARCHAR2(100);
    v_exp     DATE;
    v_keyname VARCHAR2(100);
    v_ip      VARCHAR2(100);
    v_host    VARCHAR2(100);
    v_user    VARCHAR2(100);
    v_staff   VARCHAR2(100);

    ---备份表中需要的字段
    \* v_bstaff varchar2(100);*\
    -- v_btable varchar2(100);
  BEGIN

    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_staff, 'lud') > 0 OR instr(in_reason, 'lud') > 0) THEN

      v_staff := v_ip;
    END IF;

    \*
    --备份数据提取

    select SYS_CONTEXT('USERENV', 'SESSION_USER') into v_bstaff from dual;

    if v_bstaff = 'CRMV2' then
      v_bstaff := v_staff;
    end if;*\

    v_table := upper(in_table);
    v_exp   := to_date(in_exp, 'yyyy-mm-dd');

    IF v_table = 'OFFER_PROD_INST_REL' THEN
      v_keyname := 'OFFER_PROD_INST_REL_ID';

      INSERT INTO crmv2.offer_prod_inst_rel_his
        (offer_prod_inst_rel_id,
         prod_inst_id,
         prod_offer_inst_id,
         role_cd,
         offer_prod_inst_rel_role_id,
         status_cd,
         status_date,
         create_date,
         eff_date,
         exp_date,
         update_date,
         proc_serial,
         offer_prod_rel_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date,
         ext_flag)
        SELECT offer_prod_inst_rel_id,
               prod_inst_id,
               prod_offer_inst_id,
               role_cd,
               offer_prod_inst_rel_role_id,
               decode(status_cd, 1000, 1100, status_cd),
               status_date,
               create_date,
               eff_date,
               nvl(v_exp, exp_date),
               update_date,
               proc_serial,
               offer_prod_rel_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_prod_inst_rel_his_id.nextval,
               SYSDATE,
               ext_flag
          FROM crmv2.offer_prod_inst_rel a
         WHERE a.offer_prod_inst_rel_id = in_key;
      DELETE FROM crmv2.offer_prod_inst_rel a
       WHERE a.offer_prod_inst_rel_id = in_key;

    ELSIF v_table = 'PROD_OFFER_INST_REL' THEN
      v_keyname := 'PROD_OFFER_INST_REL_ID';

      INSERT INTO crmv2.prod_offer_inst_rel_his
        (prod_offer_inst_rel_id,
         rela_prod_offer_inst_id,
         related_prod_offer_inst_id,
         role_cd,
         prod_offer_inst_rel_role_id,
         relation_type_cd,
         status_cd,
         eff_date,
         exp_date,
         create_date,
         status_date,
         region_a,
         region_b,
         update_date,
         proc_serial,
         prod_offer_rela_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date)
        SELECT prod_offer_inst_rel_id,
               rela_prod_offer_inst_id,
               related_prod_offer_inst_id,
               role_cd,
               prod_offer_inst_rel_role_id,
               relation_type_cd,
               decode(status_cd, 1000, 1100, status_cd),
               eff_date,
               nvl(v_exp, exp_date),
               create_date,
               status_date,
               region_a,
               region_b,
               update_date,
               proc_serial,
               prod_offer_rela_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_rel_his_id.nextval,
               SYSDATE
          FROM crmv2.prod_offer_inst_rel a
         WHERE a.prod_offer_inst_rel_id = in_key;
      DELETE FROM crmv2.prod_offer_inst_rel
       WHERE prod_offer_inst_rel_id = in_key;
    ELSIF v_table = 'PROD_OFFER_INST' THEN
      v_keyname := 'PROD_OFFER_INST_ID';
      INSERT INTO crmv2.prod_offer_inst_his
        (prod_offer_inst_id,

         prod_offer_id,
         cust_id,
         channel_id,
         create_date,
         status_cd,
         status_date,
         eff_date,
         exp_date,
         region,
         update_date,
         proc_serial,
         ext_prod_offer_inst_id,
         lan_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date,
         trial_eff_date,
         trial_exp_date,
         service_nbr,
         version)
        SELECT prod_offer_inst_id,
               prod_offer_id,
               cust_id,
               channel_id,
               create_date,
               decode(status_cd, 1000, 1100, status_cd),
               status_date,
               eff_date,
               nvl(v_exp, exp_date),
               region,
               update_date,
               proc_serial,
               ext_prod_offer_inst_id,
               NULL,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_his_id.nextval,
               SYSDATE,
               trial_eff_date,
               trial_exp_date,
               service_nbr,
               version
          FROM crmv2.prod_offer_inst
         WHERE prod_offer_inst_id = in_key;
      DELETE FROM crmv2.prod_offer_inst WHERE prod_offer_inst_id = in_key;

    ELSIF v_table = 'PROD_INST' THEN
      v_keyname := 'PROD_INST_ID';

      INSERT INTO crmv2.prod_inst_his
        (prod_inst_id,
         product_id,
         acc_prod_inst_id,
         address_id,
         owner_cust_id,
         payment_mode_cd,
         product_password,
         important_level,
         area_code,
         acc_nbr,
         exch_id,
         common_region_id,
         remark,
         pay_cycle,
         begin_rent_time,
         stop_rent_time,
         finish_time,
         stop_status,
         status_cd,
         create_date,
         status_date,
         update_date,
         proc_serial,
         use_cust_id,
         ext_prod_inst_id,
         address_desc,
         area_id,
         update_staff,
         create_staff,
         his_id,
         rec_update_date,
         account,
         community_id)
        SELECT prod_inst_id,
               product_id,
               acc_prod_inst_id,
               address_id,
               owner_cust_id,
               payment_mode_cd,
               product_password,
               important_level,
               area_code,
               acc_nbr,
               exch_id,
               common_region_id,
               remark,
               pay_cycle,
               begin_rent_time,
               stop_rent_time,
               finish_time,
               stop_status,
               '110000',
               create_date,
               status_date,
               SYSDATE,
               '000000000',
               use_cust_id,
               ext_prod_inst_id,
               address_desc,
               area_id,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_his_id.nextval,
               SYSDATE,
               account,
               community_id
          FROM crmv2.prod_inst
         WHERE prod_inst_id = in_key;

      DELETE FROM crmv2.prod_inst WHERE prod_inst_id = in_key;

    ELSIF v_table = 'PROD_INST_REL' THEN
      v_keyname := 'PROD_INST_REL_ID';
      INSERT INTO crmv2.prod_inst_rel_his
        (prod_inst_rel_id,
         prod_inst_a_id,
         prod_inst_z_id,
         relation_type_cd,
         prod_inst_rel_role_id,
         role_cd,
         eff_date,
         exp_date,
         create_date,
         status_cd,
         status_date,
         update_date,
         proc_serial,
         product_rel_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date)
        SELECT prod_inst_rel_id,
               prod_inst_a_id,
               prod_inst_z_id,
               relation_type_cd,
               prod_inst_rel_role_id,
               role_cd,
               eff_date,
               v_exp,
               create_date,
               '1100',
               status_date,
               SYSDATE,
               proc_serial,
               product_rel_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_rel_his_id.nextval,
               SYSDATE
          FROM crmv2.prod_inst_rel a
         WHERE prod_inst_rel_id = in_key
           AND NOT EXISTS
         (SELECT 1
                  FROM crmv2.prod_inst b
                 WHERE a.prod_inst_a_id = b.prod_inst_id
                   AND b.product_id IN ('800299131', '800000343'));

      DELETE FROM crmv2.prod_inst_rel a
       WHERE prod_inst_rel_id = in_key
         AND NOT EXISTS
       (SELECT 1
                FROM crmv2.prod_inst b
               WHERE a.prod_inst_a_id = b.prod_inst_id
                 AND b.product_id IN ('800299131', '800000343'));

    ELSIF v_table = 'PROD_INST_ACCT' THEN

      v_keyname := 'PROD_INST_ACCT_ID';
      INSERT INTO crmv2.prod_inst_acct_his
        (prod_inst_acct_id,
         account_id,
         acct_item_type_group_id,
         prod_inst_id,
         payment_limit_type,
         payment_limit,
         priority,
         status_cd,
         status_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         update_date,
         create_date,
         eff_date,
         exp_date,
         def_acct_flag,
         charge_type,
         invoice_formart_flag,
         rec_update_date,
         group_prod_inst_acct_id)
        SELECT prod_inst_acct_id,
               account_id,
               acct_item_type_group_id,
               prod_inst_id,
               payment_limit_type,
               payment_limit,
               priority,
               '1100',
               status_date,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_acct_his_id.nextval,
               SYSDATE,
               create_date,
               eff_date,
               SYSDATE,
               def_acct_flag,
               charge_type,
               invoice_formart_flag,
               SYSDATE rec_update_date,
               group_prod_inst_acct_id
          FROM crmv2.prod_inst_acct a
         WHERE a.prod_inst_acct_id = in_key
           AND charge_type NOT IN ('30080002', '30080003', '30080004');

      DELETE crmv2.prod_inst_acct a
       WHERE a.prod_inst_acct_id = in_key
         AND charge_type NOT IN ('30080002', '30080003', '30080004');

    ELSIF v_table = 'PROD_OFFER_INST_ATTR' THEN

      v_keyname := 'PROD_OFFER_INST_ATTR_ID';
      INSERT INTO crmv2.prod_offer_inst_attr_his
        (prod_offer_inst_attr_id,
         prod_offer_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         create_date,
         exp_date,
         eff_date,
         status_date,
         status_cd,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date,
         version)
        SELECT prod_offer_inst_attr_id,
               prod_offer_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               create_date,
               v_exp,
               eff_date,
               status_date,
               decode(status_cd, 1000, 1100, status_cd),
               update_date,
               '000000000',
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_attr_2_id.nextval,
               SYSDATE,
               version
          FROM crmv2.prod_offer_inst_attr a
         WHERE a.prod_offer_inst_attr_id = in_key;

      DELETE FROM crmv2.prod_offer_inst_attr a
       WHERE a.prod_offer_inst_attr_id = in_key;

    ELSIF v_table = 'PROD_INST_ATTR' THEN

      v_keyname := 'PROD_INST_ATTR_ID';
      INSERT INTO crmv2.prod_inst_attr_his
        (prod_inst_attr_id,
         prod_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         status_cd,
         status_date,
         eff_date,
         exp_date,
         create_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date)
        SELECT prod_inst_attr_id,
               prod_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               decode(status_cd, 1000, 1100, status_cd),
               status_date,
               eff_date,
               SYSDATE,
               create_date,
               update_date,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_attr_his_id.nextval,
               SYSDATE
          FROM crmv2.prod_inst_attr a
         WHERE a.prod_inst_attr_id = in_key;

      DELETE FROM crmv2.prod_inst_attr a
       WHERE a.prod_inst_attr_id = in_key;

    ELSIF v_table = 'OFFER_RES_INST_REL' THEN
      INSERT INTO crmv2.offer_res_inst_rel_his
        SELECT offer_res_inst_rel_id,
               mkt_res_inst_id,
               prod_offer_inst_id,
               use_prod_inst_id,
               create_date,
               decode(status_cd, '1000', '1100', '1299', '1299'),
               status_date,
               SYSDATE update_date,
               '000000000',
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_res_inst_rel_his_id.nextval his_id,
               property_type
          FROM crmv2.offer_res_inst_rel
         WHERE offer_res_inst_rel_id = in_key;

      DELETE FROM crmv2.offer_res_inst_rel a
       WHERE offer_res_inst_rel_id = in_key;

    ELSIF v_table = 'PROD_RES_INST_REL' THEN
      INSERT INTO crmv2.prod_res_inst_rel_his
        SELECT prod_res_inst_rel_id,
               prod_inst_id,
               mkt_res_inst_id,
               type_cd,
               property_type,
               create_date,
               decode(status_cd, '1000', '1100', '1299', '1299'),
               status_date,
               SYSDATE update_date,
               '000000000' proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_res_inst_rel_his_id.nextval his_id
          FROM crmv2.prod_res_inst_rel
         WHERE prod_res_inst_rel_id = in_key;

      DELETE FROM crmv2.prod_res_inst_rel a
       WHERE prod_res_inst_rel_id = in_key;

    ELSIF v_table = 'PROD_OFFER_MEMBER_INST' THEN
      v_keyname := 'MEMBER_INST_ID';

      INSERT INTO crmv2.prod_offer_member_inst_his
        SELECT member_inst_id,
               prod_offer_inst_id,
               member_id,
               prod_offer_member_id,
               decode(status_cd, '1000', '1100', '1299', '1299'),
               status_date,
               create_date,
               eff_date,
               nvl(v_exp, exp_date),
               area_id,
               region_cd,
               create_staff,
               update_date,
               update_staff,
               role_cd,
               crmv2.seq_prod_offer_member_inst_his.nextval,
               SYSDATE,
               bank_id,
               bank_account
          FROM crmv2.prod_offer_member_inst
         WHERE member_inst_id = in_key;

      DELETE FROM crmv2.prod_offer_member_inst
       WHERE member_inst_id = in_key;
    ELSIF v_table = 'PROD_INST_ACC_NBR' THEN
      v_keyname := 'PROD_INST_ACC_NBR_ID';

      INSERT INTO crmv2.prod_inst_acc_nbr_his
        SELECT prod_inst_acc_nbr_id,
               acc_nbr_type_cd,
               acc_nbr,
               create_date,
               decode(status_cd, '1000', '1100', '1299', '1299'),
               status_date,
               SYSDATE update_date,
               proc_serial,
               prod_inst_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_acc_nbr_his_id.nextval,
               area_code
          FROM crmv2.prod_inst_acc_nbr
         WHERE prod_inst_acc_nbr_id = in_key;

      DELETE FROM crmv2.prod_inst_acc_nbr
       WHERE prod_inst_acc_nbr_id = in_key;
    END IF;
    o_result := 'SUCCESS';

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT v_table,
             in_key,
             '',
             '',
             '',
             '',
             'DELETE',
             '',
             '',
             'CRMV2.PKG_WH.TABLE_1_TO_HIS',
             v_staff,
             f_check_modi_staff(v_staff),
             in_reason,
             SYSDATE,
             '档案从1表删除到2表',
             '销售品类'
        FROM dual;

    IF v_table NOT IN
       ('OFFER_RES_INST_REL', 'PROD_RES_INST_REL', 'PROD_INST_ACC_NBR') THEN
      itsc_crmv2.new_p_ins_billing_update(v_table, v_keyname, in_key,
                                          in_reason, v_staff);
    END IF;
  END;

  PROCEDURE prod_offer_inst_his_to_1(in_inst_id IN NUMBER,
                                     in_exp     IN VARCHAR2,
                                     in_reason  IN VARCHAR2,
                                     in_staff   IN VARCHAR2,
                                     o_result   OUT VARCHAR2) IS
    ---2012.11.1 修改 修复只能拉1表有1100记录的问题，只要2表有1100的记录即可恢复
    v_date  DATE;
    v_n     NUMBER(10);
    v_n2    NUMBER(10);
    v_id    NUMBER(10);
    v_id2   NUMBER(10);
    v_ida   NUMBER(10);
    v_cd    NUMBER(10);
    v_n3    NUMBER(10);
    v_staff VARCHAR2(100);

    ---备份表中需要的字段
    v_bstaff VARCHAR2(100);
    v_areaid NUMBER(10);

    v_context VARCHAR2(1000);
    v_name    VARCHAR2(100);
    CURSOR c IS
      SELECT b.default_time_period, a.*
        FROM crmv2.prod_offer_inst_his a, crmv2.prod_offer b
       WHERE a.prod_offer_id = b.prod_offer_id
         AND a.prod_offer_inst_id = in_inst_id
         AND a.status_cd = '1100'
         AND rownum = 1;
    v_ip   VARCHAR2(100);
    v_host VARCHAR2(100);
    v_user VARCHAR2(100);

  BEGIN

    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_staff, 'lud') > 0 OR instr(in_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;

    --备份数据提取

    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;

    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := v_staff;
    END IF;

    FOR rec IN c LOOP

      IF in_exp IS NULL THEN
        IF rec.default_time_period IS NULL THEN
          v_date := to_date('21990101', 'yyyymmdd');
        ELSE
          v_date := add_months(rec.eff_date, rec.default_time_period);
        END IF;
      ELSE
        v_date := to_date(in_exp, 'yyyy-mm-dd');
      END IF;

      IF v_date > SYSDATE THEN

        --恢复PROD_OFFER_iNST
        --判断1表是否有记录
        SELECT COUNT(1)
          INTO v_n3
          FROM crmv2.prod_offer_inst a
         WHERE a.prod_offer_inst_id = in_inst_id;

        IF v_n3 > 0 THEN
          --有的话直接恢复
          UPDATE crmv2.prod_offer_inst a
             SET a.status_cd   = '1000',
                 a.exp_date    = v_date,
                 a.status_date =
                 (SELECT MAX(rec_update_date)
                    FROM crmv2.prod_offer_inst_his b
                   WHERE a.prod_offer_inst_id = b.prod_offer_inst_id)
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

        ELSE
          --没有从2表拉回
          INSERT INTO crmv2.prod_offer_inst
            (prod_offer_inst_id,
             prod_offer_id,
             cust_id,
             channel_id,
             create_date,
             status_cd,
             status_date,
             eff_date,
             exp_date,
             region,
             update_date,
             proc_serial,
             ext_prod_offer_inst_id,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             trial_eff_date,
             trial_exp_date,
             rec_update_date,
             service_nbr,
             version,
             remark,
             wh_remark,
             ext_flag1,
             ext_flag2)
            SELECT prod_offer_inst_id,
                   prod_offer_id,
                   cust_id,
                   channel_id,
                   create_date,
                   '1000',
                   status_date,
                   eff_date,
                   v_date,
                   region,
                   update_date,
                   proc_serial,
                   ext_prod_offer_inst_id,
                   area_id,
                   region_cd,
                   update_staff,
                   create_staff,
                   trial_eff_date,
                   trial_exp_date,
                   '',
                   service_nbr,
                   version,
                   remark,
                   wh_remark,
                   ext_flag1,
                   ext_flag2
              FROM crmv2.prod_offer_inst_his a
             WHERE a.his_id = rec.his_id;

        END IF;

        DELETE FROM crmv2.prod_offer_inst_his
         WHERE prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        --恢复PROD_OFFER_INST_ATTR
        UPDATE crmv2.prod_offer_inst_attr b
           SET b.status_cd = '1000', exp_date = ''
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id;

        DELETE FROM crmv2.prod_offer_inst_attr b
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100';

        --恢复OFFER_PROD_INST_REL
        INSERT INTO crmv2.offer_prod_inst_rel b
          SELECT offer_prod_inst_rel_id,
                 prod_inst_id,
                 prod_offer_inst_id,
                 role_cd,
                 offer_prod_inst_rel_role_id,
                 '1000',
                 status_date,
                 create_date,
                 eff_date,
                 to_date('21990101', 'yyyymmdd'),
                 SYSDATE,
                 proc_serial,
                 offer_prod_rel_id,
                 area_id,
                 region_cd,
                 update_staff,
                 create_staff,
                 '',
                 ext_flag
            FROM crmv2.offer_prod_inst_rel_his
           WHERE prod_offer_inst_id = rec.prod_offer_inst_id
             AND status_cd = '1100';

        DELETE FROM crmv2.offer_prod_inst_rel_his
         WHERE prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        --恢复PROD_OFFER_iNST_REL

        FOR rec2 IN (SELECT *
                       FROM (SELECT a.his_id,
                                    a.prod_offer_inst_rel_id,
                                    a.rela_prod_offer_inst_id,
                                    a.rec_update_date,
                                    row_number() over(PARTITION BY related_prod_offer_inst_id ORDER BY rec_update_date DESC) AS row_num
                               FROM crmv2.prod_offer_inst_rel_his a
                              WHERE a.related_prod_offer_inst_id =
                                    rec.prod_offer_inst_id
                                AND a.status_cd = '1100')
                      WHERE row_num = 1) LOOP

          BEGIN
            --A存在时恢复
            SELECT COUNT(1)
              INTO v_n
              FROM crmv2.prod_offer_inst a
             WHERE a.prod_offer_inst_id = rec2.rela_prod_offer_inst_id
               AND a.status_cd = '1000';

            IF v_n > 0 THEN
              INSERT INTO crmv2.prod_offer_inst_rel
                SELECT prod_offer_inst_rel_id,
                       rela_prod_offer_inst_id,
                       related_prod_offer_inst_id,
                       role_cd,
                       prod_offer_inst_rel_role_id,
                       relation_type_cd,
                       '1000',
                       eff_date,
                       to_date('21990101', 'yyyymmdd'),
                       create_date,
                       status_date,
                       region_a,
                       region_b,
                       SYSDATE,
                       proc_serial,
                       prod_offer_rela_id,
                       area_id,
                       region_cd,
                       update_staff,
                       create_staff,
                       ''
                  FROM crmv2.prod_offer_inst_rel_his a
                 WHERE a.his_id = rec2.his_id;

              DELETE FROM crmv2.prod_offer_inst_rel_his a
               WHERE a.his_id = rec2.his_id;

              itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_rel',
                                                  'prod_offer_inst_rel_id',
                                                  rec2.prod_offer_inst_rel_id,
                                                  in_reason, v_staff);

            ELSE
              --如果不存在，并且是T01的销售品，则与新的T01销售品做关系
              SELECT COUNT(1)
                INTO v_n2
                FROM crmv2.prod_offer_inst a, crmv2.prod_offer b
               WHERE a.prod_offer_inst_id = rec2.rela_prod_offer_inst_id
                 AND a.prod_offer_id = b.prod_offer_id
                 AND b.offer_sub_type = 'T01';
              -- select * from crmv2.prod_offer_inst_rel;
              IF v_n2 > 0 THEN
                SELECT g.prod_offer_rela_id,
                       d.prod_offer_inst_id,
                       g.relation_type_cd
                  INTO v_id, v_ida, v_cd
                  FROM crmv2.offer_prod_inst_rel a,
                       crmv2.prod_inst           b,
                       crmv2.offer_prod_inst_rel c,
                       crmv2.prod_offer_inst     d,
                       crmv2.prod_offer          f,
                       crmv2.prod_offer_rel      g
                 WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
                   AND a.prod_inst_id = b.prod_inst_id
                   AND b.prod_inst_id = c.prod_inst_id
                   AND c.prod_offer_inst_id = d.prod_offer_inst_id
                   AND d.prod_offer_id = f.prod_offer_id
                   AND f.offer_sub_type = 'T01'
                   AND f.prod_offer_id = g.offer_a_id
                   AND g.offer_z_id = rec.prod_offer_id
                   AND d.status_cd = '1000';

                SELECT crmv2.seq_prod_offer_inst_rel_id.nextval
                  INTO v_id2
                  FROM dual;

                INSERT INTO crmv2.prod_offer_inst_rel
                  SELECT v_id2,
                         v_ida,
                         rec.prod_offer_inst_id,
                         '',
                         '',
                         v_cd,
                         '1000',
                         create_date,
                         to_date('2199/1/1', 'yyyy/mm/dd'),
                         create_date,
                         create_date,
                         region_cd,
                         region_cd,
                         SYSDATE,
                         '',
                         v_id,
                         area_id,
                         region_cd,
                         update_staff,
                         create_staff,
                         ''
                    FROM crmv2.prod_offer_inst
                   WHERE prod_offer_inst_id = v_ida;

                itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_rel',
                                                    'prod_offer_inst_rel_id',
                                                    v_ida, in_reason,
                                                    v_staff);
              END IF;

            END IF;

          EXCEPTION
            WHEN OTHERS THEN
              NULL;

          END;
        END LOOP;

        --取账号地区
        IF instr(v_bstaff, 'fz') = 1 THEN
          v_areaid := 2;
        ELSIF instr(v_bstaff, 'xm') = 1 THEN
          v_areaid := 3;
        ELSIF instr(v_bstaff, 'nd') = 1 THEN
          v_areaid := 4;
        ELSIF instr(v_bstaff, 'pt') = 1 THEN
          v_areaid := 5;
        ELSIF instr(v_bstaff, 'qz') = 1 THEN
          v_areaid := 6;
        ELSIF instr(v_bstaff, 'zz') = 1 THEN
          v_areaid := 7;
        ELSIF instr(v_bstaff, 'ly') = 1 THEN
          v_areaid := 8;
        ELSIF instr(v_bstaff, 'sm') = 1 THEN
          v_areaid := 9;
        ELSIF instr(v_bstaff, 'np') = 1 THEN
          v_areaid := 10;
        ELSE

          v_areaid := 1;
        END IF;

        INSERT INTO itsc_crmv2.crm_wh_bak
          (tal_name,
           key_id,
           modi_column,
           modi_area,
           old_value,
           new_value,
           modi_action,
           modi_spec,
           offer_spec,
           proce,
           modi_staff,
           staff_area,
           modi_reason,
           modi_time,
           reason,
           modi_type)
          SELECT 'PROD_OFFER_INST',
                 in_inst_id,
                 '',
                 area_id,
                 '',
                 '',
                 'MODIFY',
                 prod_offer_id,
                 prod_offer_id,
                 'CRMV2.PKG_WH.PROD_OFFER_INST_HIS_TO_1',
                 v_staff,
                 v_areaid,
                 in_reason,
                 SYSDATE,
                 '可选包历史拉在用',
                 '销售品类'
            FROM crmv2.prod_offer_inst a
           WHERE a.prod_offer_inst_id = in_inst_id;

        itsc_crmv2.new_p_ins_billing_update('prod_offer_Inst',
                                            'prod_offer_Inst_id',
                                            rec.prod_offer_inst_id,
                                            in_reason, v_staff);

        FOR rec3 IN (SELECT *
                       FROM crmv2.prod_offer_inst_attr a
                      WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
          itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_attr',
                                              'prod_offer_inst_attr_id',
                                              rec3.prod_offer_inst_attr_id,
                                              in_reason, v_staff);
        END LOOP;

        FOR rec4 IN (SELECT *
                       FROM crmv2.offer_prod_inst_rel a
                      WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
          itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
                                              'offer_prod_inst_rel_id',
                                              rec4.offer_prod_inst_rel_id,
                                              in_reason, v_staff);
        END LOOP;

      END IF;

      SELECT po.prod_offer_name
        INTO v_name
        FROM crmv2.prod_offer po
       WHERE po.prod_offer_id = rec.prod_offer_id;

      v_context := '销售品[' || v_name || ']从拆除恢复在用，失效时间为' ||
                   to_char(in_exp, 'yyyymmdd');

      FOR rec5 IN (SELECT b.prod_inst_id
                     FROM crmv2.offer_prod_inst_rel a,
                          crmv2.prod_inst           b,
                          crmv2.product             p
                    WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.prod_inst_id = b.prod_inst_id
                      AND b.product_id = p.product_id
                      AND rownum = 1) LOOP

        crmv2.proc_create_order(rec5.prod_inst_id,
                                --产品实例ID
                                'CRMV2.PKG_WH.PROD_OFFER_INST_HIS_TO_1',
                                --存储过程名称
                                '被拆除的销售品恢复在用',
                                --调用过程的作用
                                in_reason,
                                --备注，调用这个存储过程的原因
                                v_staff, v_context
                                --存储过程操作的工号
                                );

      END LOOP;

    END LOOP;
    o_result := 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  --
  PROCEDURE add_or_change_prod_inst_attr(in_prodinst    IN NUMBER,
                                         in_attr_spec   IN NUMBER,
                                         in_param       IN VARCHAR2,
                                         in_modi_staff  IN VARCHAR2,
                                         in_modi_reason IN VARCHAR2,
                                         o_result       OUT VARCHAR2)
  --功　　能：增加产品特性，已经存在的按照新的参数更新
    --创建时间：2012-8-14
    --开山始祖：lud
    --参    数：
    \*
    IN_PRODINST : prod_inst_id
    IN_ATTR_SPEC:  属性规格ID
    IN_PARAM ： 属性值，如果有ATTR_VALUE表中有记录的，需要填ATTR_VALUE_NAME
    O_RESULT : 返回结果
      *\

   IS
    v_param VARCHAR2(100);

    v_attr_id NUMBER(10);
    -- v_err           varchar2(100);
    v_n             NUMBER(10);
    v_n1            NUMBER(10);
    v_n2            NUMBER(10);
    v_paramb        VARCHAR2(100);
    v_attr_value_id VARCHAR2(100);
    v_ip            VARCHAR2(100);
    v_host          VARCHAR2(100);
    v_user          VARCHAR2(100);
    v_staff         VARCHAR2(100);
    v_cnt_area_id   NUMBER(10);
    v_n3            NUMBER(10);

    v_context VARCHAR2(1000);
    -- v_name    varchar2(100);
    --  v_type varchar2(100);
    v_oldvalue VARCHAR2(100);
    --v_newvalue varchar2(100);
    v_attrname VARCHAR2(100);
  BEGIN
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_modi_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_modi_staff, 'lud') > 0 OR instr(in_modi_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_inst a
     WHERE a.prod_inst_id = in_prodinst
       AND a.area_id = f_check_modi_staff(in_modi_staff);

    IF f_check_modi_staff(in_modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(in_modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    v_param := REPLACE(TRIM(in_param), 'bps', '');
    SELECT COUNT(1)
      INTO v_n2
      FROM crmv2.prod_inst a, crmv2.product_attr b
     WHERE a.prod_inst_id = in_prodinst
       AND a.product_id = b.product_id
       AND b.attr_id = in_attr_spec
       AND b.status_cd = '1000';

    IF v_n2 = 0 THEN
      o_result := '参数规格不适用该产品规格';
      RETURN;
    END IF;

    SELECT a.attr_name
      INTO v_attrname
      FROM crmv2.attr_spec a
     WHERE a.attr_id = in_attr_spec;

    SELECT COUNT(1)
      INTO v_n
      FROM crmv2.attr_value      d,
           crmv2.prod_attr_value a,
           crmv2.product_attr    c,
           crmv2.prod_inst       b
     WHERE b.prod_inst_id = in_prodinst
       AND b.product_id = c.product_id
       AND c.attr_id = in_attr_spec
       AND c.product_attr_id = a.product_attr_id
       AND a.attr_value_id = d.attr_value_id
       AND REPLACE(d.attr_value_name, 'bps', '') =
           REPLACE(v_param, 'bps', '')
       AND a.status_cd = '1000'
       AND c.status_cd = '1000'
       AND d.status_cd = '1000';
    --modi zzy 20130417
    \*  SELECT COUNT(1)
     INTO v_n
     FROM crmv2.prod_attr_value a, crmv2.product_attr c, crmv2.prod_inst b
    WHERE b.prod_inst_id = in_prodinst
      AND b.product_id = c.product_id
      AND c.attr_id = in_attr_spec
      AND c.product_attr_id = a.product_attr_id
      AND a.status_cd = '1000';*\

    --产品属性配置，下拉框的选择先看prod_attr_value，再看attr_value
    SELECT COUNT(1)
      INTO v_n3
      FROM crmv2.attr_value d, crmv2.product_attr c, crmv2.prod_inst b
     WHERE b.prod_inst_id = in_prodinst
       AND b.product_id = c.product_id
       AND c.attr_id = in_attr_spec
       AND c.attr_id = d.attr_id
       AND REPLACE(d.attr_value_name, 'bps', '') =
           REPLACE(v_param, 'bps', '')
       AND c.status_cd = '1000'
       AND d.status_cd = '1000';
    --modi zzy 20130417
    \*    SELECT COUNT(1)
     INTO v_n3
     FROM crmv2.product_attr c, crmv2.prod_inst b, crmv2.attr_value a
    WHERE b.prod_inst_id = in_prodinst
      AND b.product_id = c.product_id
      AND c.attr_id = in_attr_spec
      AND c.Attr_Id = a.Attr_Id
      AND a.status_cd = '1000';*\

    --是否符合配置
    IF v_n > 0 THEN
      BEGIN
        SELECT d.attr_value, d.attr_value_id
          INTO v_paramb, v_attr_value_id
          FROM crmv2.attr_value      d,
               crmv2.prod_attr_value a,
               crmv2.product_attr    c,
               crmv2.prod_inst       b
         WHERE b.prod_inst_id = in_prodinst
           AND b.product_id = c.product_id
           AND c.attr_id = in_attr_spec
           AND c.product_attr_id = a.product_attr_id
           AND a.attr_value_id = d.attr_value_id
           AND REPLACE(d.attr_value_name, 'bps', '') =
               REPLACE(v_param, 'bps', '')
           AND a.status_cd = '1000'
           AND c.status_cd = '1000'
           AND d.status_cd = '1000';
      EXCEPTION
        WHEN OTHERS THEN
          o_result := '参数取值不在ATTR_VALUE范围内';
          RETURN;
      END;

    ELSIF v_n3 > 0 THEN
      BEGIN
        SELECT d.attr_value, d.attr_value_id
          INTO v_paramb, v_attr_value_id
          FROM crmv2.attr_value d, crmv2.product_attr c, crmv2.prod_inst b
         WHERE b.prod_inst_id = in_prodinst
           AND b.product_id = c.product_id
           AND c.attr_id = in_attr_spec
           AND c.attr_id = d.attr_id
           AND REPLACE(d.attr_value_name, 'bps', '') =
               REPLACE(v_param, 'bps', '')
           AND c.status_cd = '1000'
           AND d.status_cd = '1000';
      EXCEPTION
        WHEN OTHERS THEN
          o_result := '参数取值不在ATTR_VALUE范围内';
          RETURN;
      END;
    ELSE
      v_paramb        := v_param;
      v_attr_value_id := '';
    END IF;

    --是否已存在
    SELECT COUNT(1)
      INTO v_n1
      FROM crmv2.prod_inst_attr a
     WHERE a.prod_inst_id = in_prodinst
       AND a.attr_id = in_attr_spec;

    IF v_n1 > 0 THEN
      --已存在的修改
      \* o_result := '参数已存在';
      RETURN;*\
      --v_type := '修改';
      BEGIN
        v_oldvalue := '';

        SELECT a.prod_inst_attr_id, a.attr_value
          INTO v_attr_id, v_oldvalue
          FROM crmv2.prod_inst_attr a
         WHERE a.prod_inst_id = in_prodinst
           AND a.attr_id = in_attr_spec
           AND a.status_cd = '1000';

        UPDATE crmv2.prod_inst_attr b
           SET b.attr_value_id = v_attr_value_id, b.attr_value = v_paramb
         WHERE b.prod_inst_attr_id = v_attr_id;
        --有多个的删入2表
      EXCEPTION
        WHEN OTHERS THEN
          INSERT INTO itsc_crmv2.obj_update_bill_bak
            (table_name,
             col_name,
             key_id,
             modi_reason,
             modi_staff,
             modi_date,
             area_id)
            SELECT 'PROD_INST_ATTR',
                   'prod_inst_attr_id',
                   prod_inst_attr_id,
                   in_modi_reason,
                   v_staff,
                   SYSDATE,
                   area_id
              FROM crmv2.prod_inst_attr a
             WHERE a.prod_inst_id = in_prodinst
               AND a.attr_id = in_attr_spec;

          INSERT INTO crmv2.prod_inst_attr_his
            (prod_inst_attr_id,
             prod_inst_id,
             attr_id,
             attr_value_id,
             attr_value,
             status_cd,
             status_date,
             eff_date,
             exp_date,
             create_date,
             update_date,
             proc_serial,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             his_id,
             rec_update_date)
            SELECT prod_inst_attr_id,
                   prod_inst_id,
                   attr_id,
                   attr_value_id,
                   attr_value,
                   status_cd,
                   status_date,
                   eff_date,
                   SYSDATE,
                   create_date,
                   update_date + 2,
                   '000000000',
                   area_id,
                   region_cd,
                   update_staff,
                   create_staff,
                   crmv2.seq_prod_inst_attr_his_id.nextval,
                   SYSDATE
              FROM crmv2.prod_inst_attr a
             WHERE a.prod_inst_id = in_prodinst
               AND a.attr_id = in_attr_spec
               AND a.status_cd = '1000';

          DELETE FROM crmv2.prod_inst_attr a
           WHERE a.prod_inst_id = in_prodinst
             AND a.attr_id = in_attr_spec
             AND a.status_cd = '1000';

          SELECT crmv2.seq_prod_inst_attr_id.nextval
            INTO v_attr_id
            FROM dual;
          INSERT INTO crmv2.prod_inst_attr
            (prod_inst_attr_id,
             prod_inst_id,
             attr_id,
             attr_value_id,
             attr_value,
             status_cd,
             status_date,
             eff_date,
             exp_date,
             create_date,
             update_date,
             proc_serial,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             rec_update_date)
            SELECT v_attr_id,
                   in_prodinst,
                   in_attr_spec,
                   v_attr_value_id,
                   v_paramb,
                   '1000',
                   SYSDATE,
                   SYSDATE,
                   to_date('21990101', 'yyyymmdd'),
                   SYSDATE,
                   SYSDATE + 2,
                   '',
                   area_id,
                   a.common_region_id,
                   '',
                   '',
                   ''
              FROM crmv2.prod_inst a
             WHERE a.prod_inst_id = in_prodinst;
      END;

      v_context := '产品属性【' || v_attrname || '】修改属性值，旧值【' || v_oldvalue ||
                   '】; 新值【' || v_paramb || '】';

    ELSE
      --没有的新增

      SELECT crmv2.seq_prod_inst_attr_id.nextval INTO v_attr_id FROM dual;
      INSERT INTO crmv2.prod_inst_attr
        (prod_inst_attr_id,
         prod_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         status_cd,
         status_date,
         eff_date,
         exp_date,
         create_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         rec_update_date)
        SELECT v_attr_id,
               in_prodinst,
               in_attr_spec,
               v_attr_value_id,
               v_paramb,
               '1000',
               SYSDATE,
               SYSDATE,
               to_date('21990101', 'yyyymmdd'),
               SYSDATE,
               SYSDATE + 2,
               '',
               area_id,
               a.common_region_id,
               '',
               '',
               ''
          FROM crmv2.prod_inst a
         WHERE a.prod_inst_id = in_prodinst;

      v_context := '新增产品属性【' || v_attrname || '】，属性值【' || v_paramb || '】';
    END IF;
    INSERT INTO itsc_crmv2.obj_update_bill_bak
      (table_name,
       col_name,
       key_id,
       modi_reason,
       modi_staff,
       modi_date,
       area_id)
      SELECT 'PROD_INST_ATTR',
             'prod_inst_attr_id',
             prod_inst_attr_id,
             in_modi_reason,
             v_staff,
             SYSDATE,
             area_id
        FROM crmv2.prod_inst_attr a
       WHERE a.prod_inst_attr_id = v_attr_id;

    \* INSERT INTO itsc_crmv2.intf_ins_billing_update
    (ins_id,
     table_name,
     column_name,
     key_id,
     topic,
     TYPE,
     reason,
     operator,
     state,
     state_date,
     create_date,
     update_date,
     deal_num,
     next_deal_time,
     err_msg,
     remark,
     area_nbr)
    SELECT itsc_crmv2.seq_intf_ins_billing_update_id.nextval,
           upper(table_name),
           upper(col_name),
           key_id,
           in_modi_reason,
           '1003',
           in_modi_reason,
           v_staff,
           '70A',
           NULL,
           SYSDATE,
           NULL,
           0,
           NULL,
           NULL,
           NULL,
           area_nbr
      FROM itsc_crmv2.obj_update_bill_bak a, crmv2.area_code b
     WHERE modi_reason = in_modi_reason
       AND a.area_id = b.area_code_id;*\
    FOR rec_intf IN (SELECT *
                       FROM itsc_crmv2.obj_update_bill_bak a
                      WHERE modi_reason = in_modi_reason
                        AND modi_staff = v_staff) LOOP
      itsc_crmv2.new_p_ins_billing_update(upper(rec_intf.table_name),
                                          upper(rec_intf.col_name),
                                          rec_intf.key_id,
                                          rec_intf.modi_reason, v_staff);

    END LOOP;

    o_result := '添加成功';

    INSERT INTO itsc_crmv2.obj_update_bill_bak_his
      SELECT * FROM itsc_crmv2.obj_update_bill_bak;

    DELETE FROM itsc_crmv2.obj_update_bill_bak;

    COMMIT;

    crmv2.proc_create_order(in_prodinst,
                            --产品实例ID
                            'CRMV2.PKG_WH.ADD_OR_CHANGE_PROD_INST_ATTR',
                            --存储过程名称
                            '新增或修改产品属性',
                            --调用过程的作用
                            in_modi_reason,
                            --备注，调用这个存储过程的原因
                            v_staff, v_context
                            --存储过程操作的工号
                            );

  END;
  --
  PROCEDURE add_prod_inst_attr(in_prodinst    IN NUMBER,
                               in_attr_spec   IN NUMBER,
                               in_param       IN VARCHAR2,
                               in_modi_staff  IN VARCHAR2,
                               in_modi_reason IN VARCHAR2,
                               o_result       OUT VARCHAR2)
  --功　　能：增加产品特性
    --创建时间：2012-8-13
    --开山始祖：lud
    --参    数：
    \*
    IN_PRODINST : prod_inst_id
    IN_ATTR_SPEC:  属性规格ID
    IN_PARAM ： 属性值，如果有ATTR_VALUE表中有记录的，需要填ATTR_VALUE_NAME
    O_RESULT : 返回结果
      *\

   IS

    v_param   VARCHAR2(100) := TRIM(in_param);
    v_attr_id NUMBER(10);
    -- v_err           varchar2(100);
    v_n             NUMBER(10);
    v_n1            NUMBER(10);
    v_n2            NUMBER(10);
    v_n2b           NUMBER(10);
    v_paramb        VARCHAR2(100);
    v_attr_value_id VARCHAR2(100);
    v_ip            VARCHAR2(100);
    v_host          VARCHAR2(100);
    v_user          VARCHAR2(100);
    -- v_staff         VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
    v_bstaff      VARCHAR2(100);
  BEGIN

    IF 1 = 2 THEN
      itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
      --v_staff := in_modi_staff;
      \*  IF v_ip != '134.130.254.23' AND
         (instr(in_modi_staff, 'lud') > 0 OR instr(in_modi_reason, 'lud') > 0) THEN
        v_staff := v_ip;
      END IF;*\

      SELECT sys_context('USERENV', 'SESSION_USER')
        INTO v_bstaff
        FROM dual;

      IF v_bstaff = 'CRMV2' THEN
        v_bstaff := in_modi_staff;
      END IF;

      SELECT COUNT(1)
        INTO v_cnt_area_id
        FROM crmv2.prod_inst a
       WHERE a.prod_inst_id = in_prodinst
         AND a.area_id = f_check_modi_staff(in_modi_staff);

      IF f_check_modi_staff(in_modi_staff) = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      ELSIF f_check_modi_staff(in_modi_staff) > 1 THEN
        IF v_cnt_area_id = 0 THEN
          o_result := '修改人不准确';
          RETURN;
        END IF;
      END IF;

      SELECT COUNT(1)
        INTO v_n1
        FROM crmv2.prod_inst_attr a
       WHERE a.prod_inst_id = in_prodinst
         AND a.attr_id = in_attr_spec
         AND a.status_cd = '1000';

      IF v_n1 > 0 THEN
        o_result := '参数已存在';
        RETURN;
      END IF;

      SELECT COUNT(1)
        INTO v_n2
        FROM crmv2.prod_inst a, crmv2.product_attr b
       WHERE a.prod_inst_id = in_prodinst
         AND a.product_id = b.product_id
         AND b.attr_id = in_attr_spec
         AND b.status_cd = '1000';

      SELECT COUNT(1)
        INTO v_n2b
        FROM crmv2.attr_spec a
       WHERE a.attr_id = in_attr_spec
         AND a.status_cd = '1000'
         AND a.class_id = '4';

      IF v_n2 = 0 AND v_n2b = 0 THEN
        o_result := '参数规格不适用该产品规格';
        RETURN;
      END IF;

      SELECT crmv2.seq_prod_inst_attr_id.nextval INTO v_attr_id FROM dual;

      IF v_n2 > 0 THEN
        SELECT COUNT(1)
          INTO v_n
          FROM crmv2.prod_attr_value a,
               crmv2.product_attr    c,
               crmv2.prod_inst       b
         WHERE b.prod_inst_id = in_prodinst
           AND b.product_id = c.product_id
           AND c.attr_id = in_attr_spec
           AND c.product_attr_id = a.product_attr_id;

      ELSE
        SELECT COUNT(1)
          INTO v_n
          FROM crmv2.attr_spec a, crmv2.attr_value b
         WHERE a.attr_id = in_attr_spec
           AND a.class_id = '4'
           AND a.attr_id = b.attr_id
           AND b.status_cd = '1000'
           AND b.attr_value_name = in_param;

      END IF;

      IF v_n > 0 THEN
        BEGIN
          SELECT d.attr_value, d.attr_value_id
            INTO v_paramb, v_attr_value_id
            FROM crmv2.attr_value      d,
                 crmv2.prod_attr_value a,
                 crmv2.product_attr    c,
                 crmv2.prod_inst       b
           WHERE b.prod_inst_id = in_prodinst
             AND b.product_id = c.product_id
             AND c.attr_id = in_attr_spec
             AND c.product_attr_id = a.product_attr_id
             AND a.attr_value_id = d.attr_value_id
             AND REPLACE(d.attr_value_name, 'bps', '') =
                 REPLACE(v_param, 'bps', '')
             AND a.status_cd = '1000'
             AND c.status_cd = '1000';
        EXCEPTION
          WHEN OTHERS THEN

            BEGIN
              SELECT d.attr_value, d.attr_value_id
                INTO v_paramb, v_attr_value_id
                FROM crmv2.attr_value d
               WHERE d.attr_id = in_attr_spec
                 AND REPLACE(d.attr_value_name, 'bps', '') =
                     REPLACE(v_param, 'bps', '')
                 AND d.status_cd = '1000';

            EXCEPTION
              WHEN OTHERS THEN
                o_result := '参数取值不在ATTR_VALUE范围内';
                RETURN;

            END;
        END;
      ELSE
        v_paramb        := v_param;
        v_attr_value_id := '';
      END IF;

      INSERT INTO crmv2.prod_inst_attr
        (prod_inst_attr_id,
         prod_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         status_cd,
         status_date,
         eff_date,
         exp_date,
         create_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         rec_update_date)
        SELECT v_attr_id,
               in_prodinst,
               in_attr_spec,
               v_attr_value_id,
               v_paramb,
               '1000',
               SYSDATE,
               SYSDATE,
               to_date('21990101', 'yyyymmdd'),
               SYSDATE,
               SYSDATE,
               '',
               area_id,
               a.common_region_id,
               '',
               '',
               ''
          FROM crmv2.prod_inst a
         WHERE a.prod_inst_id = in_prodinst;
      COMMIT;
      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PROD_INST_ATTR',
               v_attr_id,
               'PROD_INST_ATTR_ID',
               a.area_id,
               '',
               in_attr_spec,
               'ADD',
               in_attr_spec,
               '',
               'CRMV2.PKG_WH.ADD_PROD_INST_ATTR',
               v_bstaff,
               f_check_modi_staff(in_modi_staff),
               in_modi_reason,
               SYSDATE,
               '增加产品实例属性',
               '产品类'
          FROM crmv2.prod_inst a
         WHERE a.prod_inst_id = in_prodinst;

      o_result := '添加成功';
      \* o_result := v_err;*\

      itsc_crmv2.new_p_ins_billing_update('prod_inst_attr',
                                          'prod_inst_attr_id', v_attr_id,
                                          in_modi_reason, in_modi_staff);

    END IF;
  END;

  --
  \*procedure CHANGE_OFFER_DATE(IN_offer_id IN number,
                              modi_eff    IN date,
                              modi_exp    IN date,
                              modi_type   IN varchar2,
                              modi_staff  IN varchar2,
                              modi_reason IN varchar2) is
    --功　　能：修改销售品规格为T01, T04, T05的生失效时间
    --创建时间：2012-8-5
    --开山始祖：lud
    --参    数：
    \*
    in_offer_id :销售品实例ID
    modi_eff ：表示字段名
    modi_exp :表示送计费接口的表名对应的主键ID
    modi_type     :表示送计费接口的原因
    modi_staff :表示修改数据的操作人
    modi_reason: 修改原因
    *\

    v_type varchar2(100);
    -- V_OFFTYPE VARCHAR2(100);
  begin
   v_type := UPPER(trim(modi_type));

  FOR REC IN (select po.offer_sub_type, a.*
                from crmv2.prod_offer_inst a, crmv2.prod_offer po
               where a.prod_offer_inst_id = IN_OFFER_ID
                 and a.prod_offer_id = po.prod_offer_id) LOOP

    --
    if v_type = 'EFF' THEN

      -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
      --PROD_OFFER_INST_ATTR
      \*  if MODI_EFF < rec.status_date then*\
      --修改时间小于STATUS_DATE， 需要修改status_date
      --销售品
      update crmv2.prod_offer_inst a
         set eff_date = modi_eff, a.status_date = create_date
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_offer_inst
        select *
          from crmv2.prod_offer_inst_his
         where prod_offer_inst_id = rec.prod_offer_inst_id
           and status_cd != '1299';

      delete from crmv2.prod_offer_inst_his
       where prod_offer_inst_id = rec.prod_offer_inst_id
         and status_cd != '1299';

      \*  --销售品历史表
      update crmv2.prod_offer_inst_his a
         set a.rec_update_date = modi_eff
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.rec_update_date =
             (select max(rec_update_date)
                from crmv2.prod_offer_inst_his b
               where b.prod_offer_inst_id = rec.prod_offer_inst_id
                 and status_cd != '1299');*\

      --销售品产品关联
      update crmv2.offer_prod_inst_rel a
         set a.eff_date = modi_eff, a.status_date = create_date
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_offer_rel
        select *
          from crmv2.offer_prod_inst_rel_his a
         where a.prod_offer_inst_id = rec.prod_offer_inst_id
           and status_cd != '1299';

      delete from crmv2.offer_prod_inst_rel_his a
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and status_cd != '1299';

      --销售品属性
      update crmv2.PROD_OFFER_INST_ATTR a
         set a.eff_date = modi_eff, a.status_date = create_date
       where A.prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_offer_attr
        select *
          from crmv2.PROD_OFFER_INST_ATTR_his a
         where A.prod_offer_inst_id = rec.prod_offer_inst_id
           and a.status_cd != '1299';

      delete from crmv2.PROD_OFFER_INST_ATTR_his a
       where A.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.status_cd != '1299';

      ---    PROD_OFFER_INST_REL

      update crmv2.PROD_OFFER_INST_REL b
         set b.eff_date = modi_eff, b.status_date = create_date
       where b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

      update crmv2.PROD_OFFER_INST_REL b
         set b.eff_date = modi_eff, b.status_date = create_date
       where b.rela_prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_prodoffer_rel
        select *
          from crmv2.PROD_OFFER_INST_REL_his b
         where (b.related_prod_offer_inst_id = rec.prod_offer_inst_id or
               b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
           and b.status_cd != '1299';

      delete from crmv2.PROD_OFFER_INST_REL_his b
       where (b.related_prod_offer_inst_id = rec.prod_offer_inst_id or
             b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
         and b.status_cd != '1299';

      \*        else
            --修改时间大于status_date, 只需要修改生效时间
            update crmv2.prod_offer_inst a
               set eff_date = modi_eff
             where a.prod_offer_inst_id = rec.prod_offer_inst_id;

              update crmv2.prod_offer_inst_his a
               set eff_date = modi_eff
             where a.prod_offer_inst_id = rec.prod_offer_inst_id
               and a.eff_date = rec.eff_date
              and a.status_cd = '1000';

      --
            update crmv2.offer_prod_inst_rel a
               set a.eff_date = modi_eff
             where a.prod_offer_inst_id = rec.prod_offer_inst_id;

             update crmv2.offer_prod_inst_rel_his a
               set a.eff_date = modi_eff
             where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.eff_date = rec.eff_date
              and a.status_cd = '1000';
      --

            update crmv2.PROD_OFFER_INST_ATTR a
               set a.eff_date = modi_eff
             where a.prod_offer_inst_id = rec.prod_offer_inst_id;

              update crmv2.PROD_OFFER_INST_ATTR_his a
               set a.eff_date = modi_eff
             where a.prod_offer_inst_id = rec.prod_offer_inst_id
               and a.eff_date = rec.eff_dae
                and a.status_cd = '1000';

      --
           update crmv2.prod_offer_inst_rel a
              set a.eff_date = modi_eff
            where a.rela_prod_offer_inst_id = rec.rela_prod_offer_inst_id
               or a.related_prod_offer_inst_id = rec.rela_prod_offer_inst_id;

          \*
            update crmv2.prod_offer_inst_rel_his b
             set *\
          end if;
      *\
    ELSIF V_TYPE = 'EXP' THEN

      -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
      --PROD_OFFER_INST_ATTR

      --销售品
      update crmv2.prod_offer_inst a
         set exp_date = modi_exp
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      update crmv2.prod_offer_Inst_his a
         set exp_date = modi_exp
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.status_cd = '1000';
      --销售品产品关联
      update crmv2.offer_prod_inst_rel a
         set a.exp_date = modi_exp
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      update crmv2.offer_prod_inst_rel_his a
         set exp_date = modi_exp
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.status_cd = '1000';

      ----prod_offer_Inst_attr
      update crmv2.prod_offer_Inst_attr a
         set a.exp_date = ''
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      update crmv2.prod_offer_Inst_attr_his a
         set a.exp_date = ''
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.status_cd = '1000'
         and a.exp_date < to_date('20200101', 'yyyymmdd');

      --销售品关联
      update crmv2.PROD_OFFER_INST_REL b
         set exp_date = modi_exp
       where b.rela_prod_offer_inst_id = rec.prod_offer_inst_id;

      update crmv2.PROD_OFFER_INST_REL b
         set exp_date = modi_exp
       where b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

      update crmv2.prod_offer_Inst_rel_his b
         set exp_date = modi_exp
       where (b.rela_prod_offer_inst_id = rec.prod_offer_inst_id or
             b.related_prod_offer_inst_id = rec.prod_offer_inst_id)
         and b.status_cd = '1000';

    ELSIF V_TYPE = 'ALL' THEN

      -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel, PROD_OFFER_INST_ATTR
      \* if MODI_EFF < rec.status_date then*\
      --修改时间小于STATUS_DATE， 需要修改status_date
      --销售品
      update crmv2.prod_offer_inst a
         set eff_date      = modi_eff,
             a.status_date = modi_eff,
             exp_date      = modi_exp
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_offer_inst
        select *
          from crmv2.prod_offer_inst_his
         where prod_offer_inst_id = rec.prod_offer_inst_id
           and status_cd != '1299';

      delete from crmv2.prod_offer_inst_his
       where prod_offer_inst_id = rec.prod_offer_inst_id
         and status_cd != '1299';
      \*

      --销售品历史表
      update crmv2.prod_offer_inst_his a
         set a.rec_update_date = modi_eff
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.rec_update_date =
             (select max(rec_update_date)
                from crmv2.prod_offer_inst_his b
               where b.prod_offer_inst_id = rec.prod_offer_inst_id
                 and status_cd != '1299');*\

      --销售品产品关联
      update crmv2.offer_prod_inst_rel a
         set a.eff_date    = modi_eff,
             a.status_date = create_date,
             exp_date      = modi_exp
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_offer_rel
        select *
          from crmv2.offer_prod_inst_rel_his a
         where a.prod_offer_inst_id = rec.prod_offer_inst_id
           and a.status_cd != '1299';

      delete from crmv2.offer_prod_inst_rel_his a
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.status_cd != '1299';

      ---- PROD_OFFER_INST_ATTR
      update crmv2.PROD_OFFER_INST_ATTR a
         set a.eff_date    = modi_eff,
             a.status_date = create_date,
             a.exp_date    = ''
       where a.prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_offer_attr
        select *
          from crmv2.PROD_OFFER_INST_ATTR_his a
         where a.prod_offer_inst_id = rec.prod_offer_inst_id
           and a.status_cd != '1299';

      delete from crmv2.PROD_OFFER_INST_ATTR_his a
       where a.prod_offer_inst_id = rec.prod_offer_inst_id
         and a.status_cd != '1299';

      --销售品关联
      update crmv2.PROD_OFFER_INST_REL b
         set b.eff_date    = modi_eff,
             b.status_date = create_date,
             exp_date      = modi_exp
       where b.rela_prod_offer_inst_id = rec.prod_offer_inst_id;

      update crmv2.PROD_OFFER_INST_REL b
         set b.eff_date    = modi_eff,
             b.status_date = create_date,
             exp_date      = modi_exp
       where b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

      insert into fjlud_proced_del_prodoffer_rel
        select *
          from crmv2.PROD_OFFER_INST_REL_his b
         where (b.related_prod_offer_inst_id = rec.prod_offer_inst_id or
               b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
           and b.status_cd != '1299';

      delete from crmv2.PROD_OFFER_INST_REL_his b
       where (b.related_prod_offer_inst_id = rec.prod_offer_inst_id or
             b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
         and b.status_cd != '1299';

      \* else
            --修改时间大于status_date, 只需要修改生效时间
            update crmv2.prod_offer_inst a
               set eff_date = modi_eff, exp_date = modi_exp
             where a.prod_offer_inst_id = rec.prod_offer_inst_id;

               update crmv2.prod_offer_inst_his a
               set eff_date = modi_eff, exp_date = modi_exp
             where a.prod_offer_inst_id = rec.prod_offer_inst_id
              and a.status_cd = '1000';

            update crmv2.offer_prod_inst_rel a
               set a.eff_date = modi_eff, exp_date = modi_exp
             where a.prod_offer_inst_id = rec.prod_offer_inst_id;

            update crmv2.PROD_OFFER_INST_ATTR a
               set a.eff_date = modi_eff, a.exp_date = ''
             where a.prod_offer_inst_id = rec.prod_offer_inst_id;


              update crmv2.PROD_OFFER_INST_REL b
               set b.eff_date    = modi_eff,
                   b.status_date = modi_eff,
                   exp_date      = modi_exp
             where b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

          end if;
      *\
      ---itsc_crmv2.NEW_P_INS_BILLING_UPDATE

    END IF;

    --itsc_crmv2.NEW_P_INS_BILLING_UPDATE
    --prod_offer_inst
    ITSC_CRMV2.NEW_P_INS_BILLING_UPDATE('prod_offer_inst',
                                        'PROD_OFFER_INST_ID',
                                        REC.PROD_OFFER_INST_ID,
                                        MODI_STAFF,
                                        MODI_REASON);
    -- 产品销售品
    FOR REC2 IN (select a.offer_prod_inst_rel_id
                   from crmv2.offer_prod_inst_rel a
                  where a.prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
      ITSC_CRMV2.NEW_P_INS_BILLING_UPDATE('offer_prod_inst_rel',
                                          'offer_prod_inst_rel_id',
                                          REC2.offer_prod_inst_rel_id,
                                          MODI_STAFF,
                                          MODI_REASON);
    END LOOP;

    --销售品属性
    FOR REC3 IN (select a.prod_offer_inst_attr_id
                   from crmv2.PROD_OFFER_INST_ATTR a
                  where a.prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
      ITSC_CRMV2.NEW_P_INS_BILLING_UPDATE('PROD_OFFER_INST_ATTR',
                                          'prod_offer_inst_attr_id',
                                          REC3.prod_offer_inst_attr_id,
                                          MODI_STAFF,
                                          MODI_REASON);
    END LOOP;

    --销售品，销售品
    for rec4 in (select a.prod_offer_inst_rel_id
                   from crmv2.PROD_OFFER_INST_REL a
                  where a.rela_prod_offer_inst_id = rec.prod_offer_inst_id) loop
      ITSC_CRMV2.NEW_P_INS_BILLING_UPDATE('PROD_OFFER_INST_REL',
                                          'prod_offer_inst_rel_id',
                                          REC4.prod_offer_inst_rel_id,
                                          MODI_STAFF,
                                          MODI_REASON);
    end loop;

    for rec5 in (select a.prod_offer_inst_rel_id
                   from crmv2.PROD_OFFER_INST_REL a
                  where a.related_prod_offer_inst_id =
                        rec.prod_offer_inst_id) loop
      ITSC_CRMV2.NEW_P_INS_BILLING_UPDATE('PROD_OFFER_INST_REL',
                                          'prod_offer_inst_rel_id',
                                          REC5.prod_offer_inst_rel_id,
                                          MODI_STAFF,
                                          MODI_REASON);
    end loop;
  END LOOP;

  end;*\

  PROCEDURE change_offer_date(in_prod_inst_id IN NUMBER,
                              in_offer_id     IN NUMBER,
                              modi_eff        IN VARCHAR2,
                              modi_exp        IN VARCHAR2,
                              modi_type       IN VARCHAR2,
                              modi_staff      IN VARCHAR2,
                              modi_reason     IN VARCHAR2,
                              o_result        OUT VARCHAR2) IS
    --功　　能：修改销售品规格为T01, T04, T05的生失效时间
    --创建时间：2012-8-5
    --开山始祖：lud
    --参    数：
    \*
    in_offer_id :销售品实例ID
    modi_eff ：表示字段名
    modi_exp :表示送计费接口的表名对应的主键ID
    modi_type     :表示送计费接口的原因
    modi_staff :表示修改数据的操作人
    modi_reason: 修改原因
    *\

    v_type VARCHAR2(100);
    -- V_OFFTYPE VARCHAR2(100);
    v_ip    VARCHAR2(100);
    v_host  VARCHAR2(100);
    v_user  VARCHAR2(100);
    v_staff VARCHAR2(100);

    ---备份表中需要的字段
    v_bstaff VARCHAR2(100);
    -- v_btable varchar2(100);
    -- v_areaid      number(10);
    v_oldvalue    VARCHAR2(100);
    v_newvalue    VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
    v_context     VARCHAR2(1000);
    v_name        VARCHAR2(100);
    v_b           VARCHAR2(100);
  BEGIN

    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := modi_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(modi_staff, 'lud') > 0 OR instr(modi_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_offer_inst a, crmv2.prod_offer po
     WHERE a.prod_offer_inst_id = in_offer_id
       AND a.prod_offer_id = po.prod_offer_id
       AND a.area_id = f_check_modi_staff(modi_staff);

    IF f_check_modi_staff(modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    --备份数据提取

    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;

    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := lower(v_staff);
    END IF;

    v_type := upper(TRIM(modi_type));

    FOR rec IN (SELECT po.offer_sub_type, a.*
                  FROM crmv2.prod_offer_inst a, crmv2.prod_offer po
                 WHERE a.prod_offer_inst_id = in_offer_id
                   AND a.prod_offer_id = po.prod_offer_id) LOOP

      --
      IF v_type = 'EFF' THEN
        v_oldvalue := to_char(rec.eff_date, 'yyyymmdd');
        v_newvalue := modi_eff;
        -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
        --PROD_OFFER_INST_ATTR
        IF to_date(modi_eff, 'yyyy-mm-dd') < rec.status_date THEN
          --修改时间小于STATUS_DATE， 需要修改status_date
          --销售品
          UPDATE crmv2.prod_offer_inst a
             SET eff_date      = to_date(modi_eff, 'yyyy-mm-dd'),
                 a.status_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          INSERT INTO itsc_crmv2.fjlud_proced_del_offer_inst
            SELECT prod_offer_inst_id,
                   prod_offer_id,
                   cust_id,
                   channel_id,
                   create_date,
                   status_cd,
                   status_date,
                   eff_date,
                   exp_date,
                   region,
                   update_date,
                   proc_serial,
                   ext_prod_offer_inst_id,
                   lan_id,
                   area_id,
                   region_cd,
                   update_staff,
                   create_staff,
                   his_id,
                   rec_update_date,
                   trial_eff_date,
                   trial_exp_date,
                   service_nbr,
                   version
              FROM crmv2.prod_offer_inst_his
             WHERE prod_offer_inst_id = rec.prod_offer_inst_id
               AND status_cd != '1299';

          DELETE FROM crmv2.prod_offer_inst_his
           WHERE prod_offer_inst_id = rec.prod_offer_inst_id
             AND status_cd != '1299';

          \*  --销售品历史表
          update crmv2.prod_offer_inst_his a
             set a.rec_update_date = modi_eff
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.rec_update_date =
                 (select max(rec_update_date)
                    from crmv2.prod_offer_inst_his b
                   where b.prod_offer_inst_id = rec.prod_offer_inst_id
                     and status_cd != '1299');*\

          --销售品产品关联
          UPDATE crmv2.offer_prod_inst_rel a
             SET a.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 a.status_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          INSERT INTO itsc_crmv2.fjlud_proced_del_offer_rel
            SELECT *
              FROM crmv2.offer_prod_inst_rel_his a
             WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
               AND status_cd != '1299';

          DELETE FROM crmv2.offer_prod_inst_rel_his a
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND status_cd != '1299';

          --销售品属性
          UPDATE crmv2.prod_offer_inst_attr a
             SET a.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 a.status_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          INSERT INTO itsc_crmv2.fjlud_proced_del_offer_attr
            SELECT *
              FROM crmv2.prod_offer_inst_attr_his a
             WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
               AND a.status_cd != '1299';

          DELETE FROM crmv2.prod_offer_inst_attr_his a
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND a.status_cd != '1299';

          ---    PROD_OFFER_INST_REL

          UPDATE crmv2.prod_offer_inst_rel b
             SET b.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 b.status_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_rel b
             SET b.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 b.status_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE b.rela_prod_offer_inst_id = rec.prod_offer_inst_id;

          INSERT INTO itsc_crmv2.fjlud_proced_del_prodoffer_rel
            SELECT *
              FROM crmv2.prod_offer_inst_rel_his b
             WHERE (b.related_prod_offer_inst_id = rec.prod_offer_inst_id OR
                   b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
               AND b.status_cd != '1299';

          DELETE FROM crmv2.prod_offer_inst_rel_his b
           WHERE (b.related_prod_offer_inst_id = rec.prod_offer_inst_id OR
                 b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
             AND b.status_cd != '1299';

        ELSE
          --修改时间大于status_date, 只需要修改生效时间
          UPDATE crmv2.prod_offer_inst a
             SET eff_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_his a
             SET eff_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND a.eff_date = rec.eff_date
             AND a.status_cd = '1000';

          --
          UPDATE crmv2.offer_prod_inst_rel a
             SET a.eff_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.offer_prod_inst_rel_his a
             SET a.eff_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND a.eff_date = rec.eff_date
             AND a.status_cd = '1000';
          --

          UPDATE crmv2.prod_offer_inst_attr a
             SET a.eff_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_attr_his a
             SET a.eff_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND a.status_cd = '1000';

          --
          UPDATE crmv2.prod_offer_inst_rel a
             SET a.eff_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.rela_prod_offer_inst_id = rec.prod_offer_inst_id
              OR a.related_prod_offer_inst_id = rec.prod_offer_inst_id;

          \*
          update crmv2.prod_offer_inst_rel_his b
           set *\
        END IF;

      ELSIF v_type = 'EXP' THEN
        v_oldvalue := to_char(rec.exp_date, 'yyyymmdd');
        v_newvalue := modi_exp;
        -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
        --PROD_OFFER_INST_ATTR

        --销售品
        UPDATE crmv2.prod_offer_inst a
           SET exp_date = to_date(modi_exp, 'yyyy-mm-dd')
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

        UPDATE crmv2.prod_offer_inst_his a
           SET exp_date = to_date(modi_exp, 'yyyy-mm-dd')
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND a.status_cd = '1000';
        --销售品产品关联
        UPDATE crmv2.offer_prod_inst_rel a
           SET a.exp_date = to_date('21990101', 'yyyymmdd')
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

        UPDATE crmv2.offer_prod_inst_rel_his a
           SET exp_date = to_date('21990101', 'yyyymmdd')
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND a.status_cd = '1000';

        ----prod_offer_Inst_attr 过滤 xm_宽带续约标识专用   add 20140317
        UPDATE crmv2.prod_offer_inst_attr a
           SET a.exp_date = to_date(modi_exp, 'yyyy-mm-dd')
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND attr_id <> '800002919';

        UPDATE crmv2.prod_offer_inst_attr_his a
           SET a.exp_date = to_date(modi_exp, 'yyyy-mm-dd')
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND a.status_cd = '1000'
           AND a.exp_date > SYSDATE
           AND attr_id <> '800002919';

        --销售品关联
        UPDATE crmv2.prod_offer_inst_rel b
           SET exp_date = to_date('21990101', 'yyyymmdd')
         WHERE b.rela_prod_offer_inst_id = rec.prod_offer_inst_id;

        UPDATE crmv2.prod_offer_inst_rel b
           SET exp_date = to_date('21990101', 'yyyymmdd')
         WHERE b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

        UPDATE crmv2.prod_offer_inst_rel_his b
           SET exp_date = to_date('21990101', 'yyyymmdd')
         WHERE (b.rela_prod_offer_inst_id = rec.prod_offer_inst_id OR
               b.related_prod_offer_inst_id = rec.prod_offer_inst_id)
           AND b.status_cd = '1000';

      ELSIF v_type = 'ALL' THEN

        v_oldvalue := to_char(rec.eff_date, 'yyyymmdd') || ';' ||
                      to_char(rec.exp_date, 'yyyymmdd');
        v_newvalue := modi_eff || ';' || modi_exp;

        -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel, PROD_OFFER_INST_ATTR
        IF to_date(modi_eff, 'yyyy-mm-dd') < rec.status_date THEN
          --修改时间小于STATUS_DATE， 需要修改status_date
          --销售品
          UPDATE crmv2.prod_offer_inst a
             SET eff_date      = to_date(modi_eff, 'yyyy-mm-dd'),
                 a.status_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date      = to_date(modi_exp, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          INSERT INTO itsc_crmv2.fjlud_proced_del_offer_inst
            SELECT prod_offer_inst_id,
                   prod_offer_id,
                   cust_id,
                   channel_id,
                   create_date,
                   status_cd,
                   status_date,
                   eff_date,
                   exp_date,
                   region,
                   update_date,
                   proc_serial,
                   ext_prod_offer_inst_id,
                   lan_id,
                   area_id,
                   region_cd,
                   update_staff,
                   create_staff,
                   his_id,
                   rec_update_date,
                   trial_eff_date,
                   trial_exp_date,
                   service_nbr,
                   version
              FROM crmv2.prod_offer_inst_his
             WHERE prod_offer_inst_id = rec.prod_offer_inst_id
               AND status_cd != '1299';

          DELETE FROM crmv2.prod_offer_inst_his
           WHERE prod_offer_inst_id = rec.prod_offer_inst_id
             AND status_cd != '1299';
          \*

          --销售品历史表
          update crmv2.prod_offer_inst_his a
             set a.rec_update_date = modi_eff
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.rec_update_date =
                 (select max(rec_update_date)
                    from crmv2.prod_offer_inst_his b
                   where b.prod_offer_inst_id = rec.prod_offer_inst_id
                     and status_cd != '1299');*\

          --销售品产品关联
          UPDATE crmv2.offer_prod_inst_rel a
             SET a.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 a.status_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date      = to_date('21990101', 'yyyymmdd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          INSERT INTO itsc_crmv2.fjlud_proced_del_offer_rel
            SELECT *
              FROM crmv2.offer_prod_inst_rel_his a
             WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
               AND a.status_cd != '1299';

          DELETE FROM crmv2.offer_prod_inst_rel_his a
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND a.status_cd != '1299';

          ---- PROD_OFFER_INST_ATTR
          UPDATE crmv2.prod_offer_inst_attr a
             SET a.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 a.status_date = to_date(modi_eff, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_attr a
             SET a.exp_date = to_date(modi_exp, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND attr_id <> '800002919';

          INSERT INTO itsc_crmv2.fjlud_proced_del_offer_attr
            SELECT *
              FROM crmv2.prod_offer_inst_attr_his a
             WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
               AND a.status_cd != '1299';

          DELETE FROM crmv2.prod_offer_inst_attr_his a
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND a.status_cd != '1299';

          --销售品关联
          UPDATE crmv2.prod_offer_inst_rel b
             SET b.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 b.status_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date      = to_date('21990101', 'yyyymmdd')
           WHERE b.rela_prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_rel b
             SET b.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 b.status_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date      = to_date('21990101', 'yyyymmdd')
           WHERE b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

          INSERT INTO itsc_crmv2.fjlud_proced_del_prodoffer_rel
            SELECT *
              FROM crmv2.prod_offer_inst_rel_his b
             WHERE (b.related_prod_offer_inst_id = rec.prod_offer_inst_id OR
                   b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
               AND b.status_cd != '1299';

          DELETE FROM crmv2.prod_offer_inst_rel_his b
           WHERE (b.related_prod_offer_inst_id = rec.prod_offer_inst_id OR
                 b.rela_prod_offer_inst_id = rec.prod_offer_inst_id)
             AND b.status_cd != '1299';

        ELSE
          --修改时间大于status_date, 只需要修改生效时间
          UPDATE crmv2.prod_offer_inst a
             SET eff_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date = to_date(modi_exp, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_his a
             SET eff_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date = to_date(modi_exp, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
             AND a.status_cd = '1000';

          UPDATE crmv2.offer_prod_inst_rel a
             SET a.eff_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date   = to_date(modi_exp, 'yyyy-mm-dd')
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_attr a
             SET a.eff_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 a.exp_date = ''
           WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id;

          UPDATE crmv2.prod_offer_inst_rel b
             SET b.eff_date    = to_date(modi_eff, 'yyyy-mm-dd'),
                 b.status_date = to_date(modi_eff, 'yyyy-mm-dd'),
                 exp_date      = to_date(modi_exp, 'yyyy-mm-dd')
           WHERE b.related_prod_offer_inst_id = rec.prod_offer_inst_id;

        END IF;

        ---itsc_crmv2.NEW_P_INS_BILLING_UPDATE

      END IF;

      --itsc_crmv2.NEW_P_INS_BILLING_UPDATE
      --prod_offer_inst
      itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
                                          'PROD_OFFER_INST_ID',
                                          rec.prod_offer_inst_id,
                                          modi_reason, v_staff);
      -- 产品销售品
      FOR rec2 IN (SELECT a.offer_prod_inst_rel_id
                     FROM crmv2.offer_prod_inst_rel a
                    WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
        itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
                                            'offer_prod_inst_rel_id',
                                            rec2.offer_prod_inst_rel_id,
                                            modi_reason, v_staff);
      END LOOP;

      --销售品属性
      FOR rec3 IN (SELECT a.prod_offer_inst_attr_id
                     FROM crmv2.prod_offer_inst_attr a
                    WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_ATTR',
                                            'prod_offer_inst_attr_id',
                                            rec3.prod_offer_inst_attr_id,
                                            modi_reason, v_staff);
      END LOOP;

      --销售品，销售品
      FOR rec4 IN (SELECT a.prod_offer_inst_rel_id
                     FROM crmv2.prod_offer_inst_rel a
                    WHERE a.rela_prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_REL',
                                            'prod_offer_inst_rel_id',
                                            rec4.prod_offer_inst_rel_id,
                                            modi_reason, v_staff);
      END LOOP;

      FOR rec5 IN (SELECT a.prod_offer_inst_rel_id
                     FROM crmv2.prod_offer_inst_rel a
                    WHERE a.related_prod_offer_inst_id =
                          rec.prod_offer_inst_id) LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_REL',
                                            'prod_offer_inst_rel_id',
                                            rec5.prod_offer_inst_rel_id,
                                            modi_reason, v_staff);
      END LOOP;

      \*if instr(v_bstaff, 'fz') = 1 then
        v_areaid := 2;
      elsif instr(v_bstaff, 'xm') = 1 then
        v_areaid := 3;
      elsif instr(v_bstaff, 'nd') = 1 then
        v_areaid := 4;
      elsif instr(v_bstaff, 'pt') = 1 then
        v_areaid := 5;
      elsif instr(v_bstaff, 'qz') = 1 then
        v_areaid := 6;
      elsif instr(v_bstaff, 'zz') = 1 then
        v_areaid := 7;
      elsif instr(v_bstaff, 'ly') = 1 then
        v_areaid := 8;
      elsif instr(v_bstaff, 'sm') = 1 then
        v_areaid := 9;
      elsif instr(v_bstaff, 'np') = 1 then
        v_areaid := 10;
      else

        v_areaid := 1;
      end if;*\

      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PROD_OFFER_INST',
               rec.prod_offer_inst_id,
               v_type,
               rec.area_id,
               v_oldvalue,
               v_newvalue,
               'MODIFY',
               rec.prod_offer_id,
               rec.prod_offer_id,
               'CRMV2.PKG_WH.CHANGE_OFFER_DATE',
               v_bstaff,
               f_check_modi_staff(v_bstaff),
               modi_reason,
               SYSDATE,
               '修改销售品生失效时间',
               '销售品类'
          FROM dual;

      o_result := '修改成功';
      COMMIT;

      BEGIN
        SELECT b.prod_offer_name
          INTO v_name
          FROM crmv2.prod_offer b
         WHERE b.prod_offer_id = rec.prod_offer_id;

        SELECT decode(v_type, 'EFF', '生效时间;', 'EXP', '失效时间;', 'ALL',
                      '生失效时间;')
          INTO v_b
          FROM dual;

        v_context := '修改' || '销售品:' || '[' || v_name || ']' || '的' || v_b || ';' ||
                     '旧值：' || v_oldvalue || ',' || '新值：' || v_newvalue;

        crmv2.proc_create_order(in_prod_inst_id,
                                --产品实例ID
                                'CHANGE_OFFER_DATE',
                                --存储过程名称
                                '修改销售品的生失效时间',
                                --调用过程的作用
                                modi_reason,
                                --备注，调用这个存储过程的原因
                                modi_staff,
                                --存储过程操作的工号
                                v_context);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      o_result := SQLERRM;

  END;

  PROCEDURE change_offer_expdate_his(in_his_id   IN NUMBER,
                                     modiexp     IN VARCHAR2,
                                     modi_staff  IN VARCHAR2,
                                     modi_reason IN VARCHAR2,
                                     o_result    OUT VARCHAR2) IS
    --功　　能：修改销售品规格为T01, T04, T05的历史失效时间
    --创建时间：2012-8-5
    --开山始祖：lud
    --参    数：
    \*
    in_offer_id :销售品实例
    modi_exp :表示送计费接口的表名对应的主键ID
    modi_staff :表示修改数据的操作人
    modi_reason: 修改原因
    *\

    -- V_OFFTYPE VARCHAR2(100);
    v_ip          VARCHAR2(100);
    v_host        VARCHAR2(100);
    v_user        VARCHAR2(100);
    v_staff       VARCHAR2(100);
    modi_exp      DATE;
    v_cnt_area_id NUMBER(10);
  BEGIN
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := modi_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(modi_staff, 'lud') > 0 OR instr(modi_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;
    modi_exp := to_date(modiexp, 'yyyy-mm-dd');

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_offer_inst a, crmv2.prod_offer po
     WHERE a.prod_offer_inst_id = in_his_id
       AND a.prod_offer_id = po.prod_offer_id
       AND a.status_cd = '1100'
       AND a.area_id = f_check_modi_staff(modi_staff);

    IF v_cnt_area_id = 0 THEN
      SELECT COUNT(1)
        INTO v_cnt_area_id
        FROM crmv2.prod_offer_inst_his a, crmv2.prod_offer po
       WHERE a.prod_offer_inst_id = in_his_id
         AND a.prod_offer_id = po.prod_offer_id
         AND a.status_cd = '1100'
         AND a.area_id = f_check_modi_staff(modi_staff);
    END IF;
    IF f_check_modi_staff(modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    FOR rec IN (SELECT po.offer_sub_type, a.*
                  FROM crmv2.prod_offer_inst_his a, crmv2.prod_offer po
                 WHERE a.prod_offer_inst_id = in_his_id
                   AND a.prod_offer_id = po.prod_offer_id
                   AND a.status_cd = '1100') LOOP
      UPDATE crmv2.prod_offer_inst_his a
         SET exp_date = modi_exp
       WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
         AND status_cd = '1100';
      --
      \*    IF REC.PROC_SERIAL IS NOT NULL THEN*\
      --处理单为非空
      IF rec.offer_sub_type = 'T01' THEN
        -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
        --PROD_OFFER_INST_ATTR

        --销售品
        UPDATE crmv2.prod_offer_inst_his a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        UPDATE crmv2.prod_offer_inst a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        --属性

        UPDATE crmv2.prod_offer_inst_attr_his b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.proc_serial = rec.proc_serial;

        UPDATE crmv2.prod_offer_inst_attr b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100';

        --销售品产品关联
        UPDATE crmv2.offer_prod_inst_rel_his a
           SET a.exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND a.status_cd = '1100'
           AND a.proc_serial = rec.proc_serial;

      ELSIF rec.offer_sub_type = 'T04' OR rec.offer_sub_type = 'T05' THEN
        --可选类销售品, 可选类组合销售品，组合类销售品修改整个销售品的时间
        --prod_off_inst, offer_prod_inst_rel, PROD_OFFER_INST_ATTR
        -- select * from PROD_OFFER_INST_REL;
        --修改方式同T01

        --销售品
        UPDATE crmv2.prod_offer_inst_his a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        UPDATE crmv2.prod_offer_inst a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';
        UPDATE crmv2.prod_offer_inst_attr b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100';

        UPDATE crmv2.prod_offer_inst_attr_his b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.proc_serial = rec.proc_serial;

        --销售品产品关联
        UPDATE crmv2.offer_prod_inst_rel_his a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND a.status_cd = '1100'
           AND a.proc_serial = rec.proc_serial;

        --销售品关联
        UPDATE crmv2.prod_offer_inst_rel_his b
           SET exp_date = modi_exp
         WHERE b.rela_prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100'
           AND b.proc_serial = rec.proc_serial;

        UPDATE crmv2.prod_offer_inst_rel_his b
           SET exp_date = modi_exp
         WHERE b.related_prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100'
           AND b.proc_serial = rec.proc_serial;
      END IF;
      \* else
        --从1.0割接过来的数据：

        if rec.offer_sub_type = 'T01' then
          -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
          --PROD_OFFER_INST_ATTR

          --销售品
          update crmv2.prod_offer_inst_his a
             set exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.his_id = rec.his_Id;

          --属性

          update crmv2.prod_offer_inst_attr_his b
             set b.exp_date = modi_exp
           where b.prod_offer_inst_id = rec.prod_offer_inst_id
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;

          --销售品产品关联
          update crmv2.offer_prod_inst_rel_his a
             set a.exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.status_cd = '1100'
             and a.proc_serial is null
             and a.exp_date = rec.exp_date;

        elsif rec.offer_sub_type = 'T04' or rec.offer_sub_type = 'T05' then
          --可选类销售品, 可选类组合销售品，组合类销售品修改整个销售品的时间
          --prod_off_inst, offer_prod_inst_rel, PROD_OFFER_INST_ATTR
          -- select * from PROD_OFFER_INST_REL;
          --修改方式同T01

          --销售品
          update crmv2.prod_offer_inst_his a
             set exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and his_id = rec.his_id;

          update crmv2.prod_offer_inst_attr_his b
             set b.exp_date = modi_exp
           where b.prod_offer_inst_id = rec.prod_offer_inst_id
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;

          --销售品产品关联
          update crmv2.offer_prod_inst_rel_his a
             set exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.status_cd = '1100'
             and a.proc_serial is null
             and a.exp_date = rec.exp_date;

          --销售品关联
          update crmv2.PROD_OFFER_INST_REL_his b
             set exp_date = modi_exp
           where b.rela_prod_offer_inst_id = rec.prod_offer_inst_id
             and b.status_cd = '1100'
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;

          update crmv2.PROD_OFFER_INST_REL_his b
             set exp_date = modi_exp
           where b.related_prod_offer_inst_id = rec.prod_offer_inst_id
             and b.status_cd = '1100'
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;
        end if;

      end if;*\
      --itsc_crmv2.NEW_P_INS_BILLING_UPDATE
      --prod_offer_inst
      itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
                                          'PROD_OFFER_INST_ID',
                                          rec.prod_offer_inst_id,

                                          modi_reason, v_staff);
      -- 产品销售品
      FOR rec2 IN (SELECT a.offer_prod_inst_rel_id
                     FROM crmv2.offer_prod_inst_rel_his a
                    WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.status_cd = '1100'
                      AND a.proc_serial = rec.proc_serial) LOOP
        itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
                                            'offer_prod_inst_rel_id',
                                            rec2.offer_prod_inst_rel_id,

                                            modi_reason, v_staff);
      END LOOP;

      --销售品属性
      FOR rec3 IN (SELECT a.prod_offer_inst_attr_id
                     FROM crmv2.prod_offer_inst_attr a
                    WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.status_cd = '1100') LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_ATTR',
                                            'prod_offer_inst_attr_id',
                                            rec3.prod_offer_inst_attr_id,

                                            modi_reason, v_staff);
      END LOOP;

      --销售品，销售品
      FOR rec4 IN (SELECT a.prod_offer_inst_rel_id
                     FROM crmv2.prod_offer_inst_rel_his a
                    WHERE a.rela_prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.status_cd = '1100'
                      AND a.proc_serial = rec.proc_serial) LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_REL',
                                            'prod_offer_inst_rel_id',
                                            rec4.prod_offer_inst_rel_id,

                                            modi_reason, v_staff);
      END LOOP;

      FOR rec5 IN (SELECT a.prod_offer_inst_rel_id
                     FROM crmv2.prod_offer_inst_rel_his a
                    WHERE a.related_prod_offer_inst_id =
                          rec.prod_offer_inst_id
                      AND a.status_cd = '1100'
                      AND a.proc_serial = rec.proc_serial) LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_REL',
                                            'prod_offer_inst_rel_id',
                                            rec5.prod_offer_inst_rel_id,

                                            modi_reason, v_staff);
      END LOOP;
    END LOOP;
    o_result := '修改成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_result := SQLERRM;
  END;

  ---
  PROCEDURE change_offer_expdate_his_temp(in_his_id   IN NUMBER,
                                          modi_exp    IN DATE,
                                          modi_staff  IN VARCHAR2,
                                          modi_reason IN VARCHAR2,
                                          o_result    OUT VARCHAR2) IS
    --功　　能：修改销售品规格为T01, T04, T05的历史失效时间
    --创建时间：2012-8-5
    --开山始祖：lud
    --参    数：
    \*
    in_offer_id :销售品实例
    modi_exp :表示送计费接口的表名对应的主键ID
    modi_staff :表示修改数据的操作人
    modi_reason: 修改原因
    *\

    -- V_OFFTYPE VARCHAR2(100);
    v_ip          VARCHAR2(100);
    v_host        VARCHAR2(100);
    v_user        VARCHAR2(100);
    v_staff       VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
  BEGIN
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := modi_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(modi_staff, 'lud') > 0 OR instr(modi_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_offer_inst_his a, crmv2.prod_offer po
     WHERE a.prod_offer_inst_id = in_his_id
       AND a.prod_offer_id = po.prod_offer_id
       AND a.status_cd = '1100'
       AND a.area_id = f_check_modi_staff(modi_staff);

    IF f_check_modi_staff(modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    FOR rec IN (SELECT po.offer_sub_type, a.*
                  FROM crmv2.prod_offer_inst_his a, crmv2.prod_offer po
                 WHERE a.prod_offer_inst_id = in_his_id
                   AND a.prod_offer_id = po.prod_offer_id
                   AND a.status_cd = '1100') LOOP

      --
      \*    IF REC.PROC_SERIAL IS NOT NULL THEN*\
      --处理单为非空
      IF rec.offer_sub_type = 'T01' THEN
        -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
        --PROD_OFFER_INST_ATTR

        --销售品
        UPDATE crmv2.prod_offer_inst_his a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        UPDATE crmv2.prod_offer_inst a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        --属性

        UPDATE crmv2.prod_offer_inst_attr_his b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.proc_serial = rec.proc_serial
           AND b.status_cd = '1100';

        UPDATE crmv2.prod_offer_inst_attr b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100';

        --销售品产品关联
        UPDATE crmv2.offer_prod_inst_rel_his a
           SET a.exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND a.status_cd = '1100';

      ELSIF rec.offer_sub_type = 'T04' OR rec.offer_sub_type = 'T05' THEN
        --可选类销售品, 可选类组合销售品，组合类销售品修改整个销售品的时间
        --prod_off_inst, offer_prod_inst_rel, PROD_OFFER_INST_ATTR
        -- select * from PROD_OFFER_INST_REL;
        --修改方式同T01

        --销售品
        UPDATE crmv2.prod_offer_inst_his a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';

        UPDATE crmv2.prod_offer_inst a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND status_cd = '1100';
        UPDATE crmv2.prod_offer_inst_attr b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100';

        UPDATE crmv2.prod_offer_inst_attr_his b
           SET b.exp_date = modi_exp
         WHERE b.prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.proc_serial = rec.proc_serial
           AND b.status_cd = '1100';

        --销售品产品关联
        UPDATE crmv2.offer_prod_inst_rel_his a
           SET exp_date = modi_exp
         WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
           AND a.proc_serial = rec.proc_serial;

        --销售品关联
        UPDATE crmv2.prod_offer_inst_rel_his b
           SET exp_date = modi_exp
         WHERE b.rela_prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100';

        UPDATE crmv2.prod_offer_inst_rel_his b
           SET exp_date = modi_exp
         WHERE b.related_prod_offer_inst_id = rec.prod_offer_inst_id
           AND b.status_cd = '1100';
      END IF;
      \* else
        --从1.0割接过来的数据：

        if rec.offer_sub_type = 'T01' then
          -- 主套餐类修改, 修改prod_off_inst, offer_prod_inst_rel,
          --PROD_OFFER_INST_ATTR

          --销售品
          update crmv2.prod_offer_inst_his a
             set exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.his_id = rec.his_Id;

          --属性

          update crmv2.prod_offer_inst_attr_his b
             set b.exp_date = modi_exp
           where b.prod_offer_inst_id = rec.prod_offer_inst_id
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;

          --销售品产品关联
          update crmv2.offer_prod_inst_rel_his a
             set a.exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.status_cd = '1100'
             and a.proc_serial is null
             and a.exp_date = rec.exp_date;

        elsif rec.offer_sub_type = 'T04' or rec.offer_sub_type = 'T05' then
          --可选类销售品, 可选类组合销售品，组合类销售品修改整个销售品的时间
          --prod_off_inst, offer_prod_inst_rel, PROD_OFFER_INST_ATTR
          -- select * from PROD_OFFER_INST_REL;
          --修改方式同T01

          --销售品
          update crmv2.prod_offer_inst_his a
             set exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and his_id = rec.his_id;

          update crmv2.prod_offer_inst_attr_his b
             set b.exp_date = modi_exp
           where b.prod_offer_inst_id = rec.prod_offer_inst_id
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;

          --销售品产品关联
          update crmv2.offer_prod_inst_rel_his a
             set exp_date = modi_exp
           where a.prod_offer_inst_id = rec.prod_offer_inst_id
             and a.status_cd = '1100'
             and a.proc_serial is null
             and a.exp_date = rec.exp_date;

          --销售品关联
          update crmv2.PROD_OFFER_INST_REL_his b
             set exp_date = modi_exp
           where b.rela_prod_offer_inst_id = rec.prod_offer_inst_id
             and b.status_cd = '1100'
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;

          update crmv2.PROD_OFFER_INST_REL_his b
             set exp_date = modi_exp
           where b.related_prod_offer_inst_id = rec.prod_offer_inst_id
             and b.status_cd = '1100'
             and b.proc_serial is null
             and b.exp_date = rec.exp_date;
        end if;

      end if;*\
      --itsc_crmv2.NEW_P_INS_BILLING_UPDATE
      --prod_offer_inst
      itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
                                          'PROD_OFFER_INST_ID',
                                          rec.prod_offer_inst_id,

                                          modi_reason, v_staff);
      -- 产品销售品
      FOR rec2 IN (SELECT a.offer_prod_inst_rel_id
                     FROM crmv2.offer_prod_inst_rel_his a
                    WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.status_cd = '1100'
                      AND a.proc_serial = rec.proc_serial) LOOP
        itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
                                            'offer_prod_inst_rel_id',
                                            rec2.offer_prod_inst_rel_id,

                                            modi_reason, v_staff);
      END LOOP;

      --销售品属性
      FOR rec3 IN (SELECT a.prod_offer_inst_attr_id
                     FROM crmv2.prod_offer_inst_attr a
                    WHERE a.prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.status_cd = '1100') LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_ATTR',
                                            'prod_offer_inst_attr_id',
                                            rec3.prod_offer_inst_attr_id,

                                            modi_reason, v_staff);
      END LOOP;

      --销售品，销售品
      FOR rec4 IN (SELECT a.prod_offer_inst_rel_id
                     FROM crmv2.prod_offer_inst_rel_his a
                    WHERE a.rela_prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.status_cd = '1100'
                      AND a.proc_serial = rec.proc_serial) LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_REL',
                                            'prod_offer_inst_rel_id',
                                            rec4.prod_offer_inst_rel_id,

                                            modi_reason, v_staff);
      END LOOP;

      FOR rec5 IN (SELECT a.prod_offer_inst_rel_id
                     FROM crmv2.prod_offer_inst_rel_his a
                    WHERE a.related_prod_offer_inst_id =
                          rec.prod_offer_inst_id
                      AND a.status_cd = '1100'
                      AND a.proc_serial = rec.proc_serial) LOOP
        itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_REL',
                                            'prod_offer_inst_rel_id',
                                            rec5.prod_offer_inst_rel_id,

                                            modi_reason, v_staff);
      END LOOP;
    END LOOP;

  END;

  PROCEDURE create_offer_info(in_p_inst      IN NUMBER,
                              in_offer_id    IN NUMBER,
                              in_eff_date    IN VARCHAR2 DEFAULT '2199-01-01',
                              in_exp_date    IN VARCHAR2 DEFAULT '2199-01-01',
                              in_modi_staff  IN VARCHAR2,
                              in_modi_reason IN VARCHAR2,
                              in_rolecd      IN NUMBER,
                              o_offer_inst   OUT VARCHAR2)
  --LUD
    --2012.08.06
    -- T04,T05增加可选包，不增加参数
    --2012.10.  修改，不判断T04，T05关于OFFER_PROD_iNST_REL和PROD_OFFER_iNST_REL的限制，只读取配置
   IS
    v_type    VARCHAR2(100);
    v_subid   NUMBER(10);
    v_id      NUMBER(10);
    v_rela    NUMBER(10);
    v_offspec NUMBER(10);
    --  v_exp     DATE;
    v_id2   NUMBER(10);
    v_n     NUMBER(10);
    v_ip    VARCHAR2(100);
    v_host  VARCHAR2(100);
    v_user  VARCHAR2(100);
    v_staff VARCHAR2(100);
    --  in_eff    DATE;
    -- v_err Varchar2(100);
    v_eff_date DATE;
    v_exp_date DATE;

    v_context VARCHAR2(1000);
    v_name    VARCHAR2(100);
    v_role    NUMBER(10);

  BEGIN
    v_role := nvl(in_rolecd, 1234567);
    BEGIN
      v_eff_date := to_date(in_eff_date, 'yyyy-mm-dd');
      v_exp_date := to_date(in_exp_date, 'yyyy-mm-dd');
    EXCEPTION
      WHEN OTHERS THEN
        o_offer_inst := '0';
        RETURN;
    END;

    -- in_eff := nvl(ineff, to_date('21990101', 'yyyymmdd'));

    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_modi_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_modi_staff, 'lud') > 0 OR instr(in_modi_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;

    --判断是否是集团套餐
    SELECT COUNT(1)
      INTO v_n
      FROM prod_offer
     WHERE prod_offer_id IN
           (SELECT destination_code
              FROM crmv2.intf_code_mapping
             WHERE source_system = 'GROUP'
               AND object_type = 'PROD_OFFER_CODE'
               AND object_name = '集团IVPN套餐')
       AND prod_offer_id = in_offer_id;

    IF v_n > 0 THEN

      o_offer_inst := '集团套餐不允许后台添加，请转本地政企到集团CRM受理';
      RETURN;
    END IF;

    SELECT COUNT(1)
      INTO v_n
      FROM crmv2.prod_offer_inst a, crmv2.offer_prod_inst_rel b
     WHERE b.prod_inst_id = in_p_inst
       AND b.prod_offer_inst_id = a.prod_offer_inst_id
       AND a.prod_offer_id = in_offer_id;

    IF v_n > 0 THEN
      o_offer_inst := '销售品已存在';
      RETURN;
    END IF;
    -- v_exp := nvl(in_exp, to_date('21990101', 'yyyymmdd'));
    SELECT po.offer_sub_type
      INTO v_type
      FROM crmv2.prod_offer po
     WHERE po.prod_offer_id = in_offer_id;

    BEGIN
      SELECT a.prod_offer_inst_id, b.prod_offer_id
        INTO v_subid, v_offspec
        FROM crmv2.offer_prod_inst_rel a,
             crmv2.offer_prod_rel      b,
             crmv2.prod_offer          po,
             crmv2.prod_offer_inst     c
       WHERE a.prod_inst_id = in_p_inst
         AND a.offer_prod_rel_id = b.offer_prod_rela_id
         AND b.rule_type IN ('12', '10')
         AND a.prod_offer_inst_id = c.prod_offer_inst_id
         AND c.prod_offer_id = po.prod_offer_id
         AND po.offer_sub_type = 'T01'
         AND c.status_cd = '1000'; --排除延期生效2个主套餐的

    EXCEPTION
      WHEN OTHERS THEN
        SELECT a.prod_offer_inst_id, b.prod_offer_id
          INTO v_subid, v_offspec
          FROM crmv2.offer_prod_inst_rel a,
               crmv2.offer_prod_rel      b,
               crmv2.offer_prod_rel_role c
         WHERE a.prod_inst_id = in_p_inst
           AND a.offer_prod_rel_id = b.offer_prod_rela_id
           AND b.rule_type IN ('10')
           AND a.role_cd = c.role_cd
           AND (c.role_name LIKE '%共享%' OR c.role_name LIKE '乐享%' OR
               c.role_name LIKE '%基础%');
    END;

    --判断是否有关联主销售品
    IF v_type = 'T04' THEN
      SELECT COUNT(1)
        INTO v_n
        FROM crmv2.prod_offer_rel b
       WHERE b.offer_a_id = v_offspec
         AND b.offer_z_id = in_offer_id
         AND b.relation_type_cd = '100000';

      IF v_n = 0 THEN
        o_offer_inst := '未配置销售品关联表';
        RETURN;
      END IF;
    END IF;

    -- 新增prod_offer_inst
    SELECT crmv2.seq_prod_offer_inst_id.nextval INTO v_id FROM dual;

    INSERT INTO crmv2.prod_offer_inst
      (prod_offer_inst_id,
       prod_offer_id,
       cust_id,
       channel_id,
       create_date,
       status_cd,
       status_date,
       eff_date,
       exp_date,
       region,
       update_date,
       proc_serial,
       ext_prod_offer_inst_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       trial_eff_date,
       trial_exp_date,
       rec_update_date,
       service_nbr,
       version,
       end_auto)
      SELECT v_id,
             in_offer_id,
             cust_id,
             channel_id,
             SYSDATE,
             '1000',
             v_eff_date,
             v_eff_date,
             v_exp_date,
             region_cd,
             SYSDATE,
             '',
             '',
             \* '',*\
             area_id,
             region_cd,
             '',
             '',
             '',
             '',
             '',
             '',
             '0',
             ''
        FROM crmv2.prod_offer_inst a
       WHERE a.prod_offer_inst_id = v_subid;

    SELECT po.offer_sub_type
      INTO v_type
      FROM crmv2.prod_offer po
     WHERE po.prod_offer_id = in_offer_id;

    --新增销售品关联表
    SELECT crmv2.seq_prod_offer_inst_rel_id.nextval INTO v_rela FROM dual;

    INSERT INTO crmv2.prod_offer_inst_rel
      (prod_offer_inst_rel_id,
       rela_prod_offer_inst_id,
       related_prod_offer_inst_id,
       role_cd,
       prod_offer_inst_rel_role_id,
       relation_type_cd,
       status_cd,
       eff_date,
       exp_date,
       create_date,
       status_date,
       region_a,
       region_b,
       update_date,
       proc_serial,
       prod_offer_rela_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       rec_update_date)
      SELECT v_rela,
             v_subid,
             v_id,
             b.role_cd,
             '',
             b.relation_type_cd,
             '1000',

             v_eff_date,
             v_exp_date,
             v_eff_date,
             v_eff_date,
             a.region_cd,
             a.region_cd,
             SYSDATE,
             '',
             b.prod_offer_rela_id,
             a.area_id,
             a.region_cd,
             '',
             '',
             ''
        FROM crmv2.prod_offer_inst a, crmv2.prod_offer_rel b
       WHERE a.prod_offer_inst_id = v_subid
         AND a.prod_offer_id = b.offer_a_id
            \*       AND B.Status_Cd <>'1100'*\
         AND b.offer_z_id = in_offer_id;

    \*   IF v_type = 'T04' THEN*\
    ---新增产品关联表：
    SELECT crmv2.seq_offer_prod_inst_rel_id.nextval INTO v_id2 FROM dual;

    INSERT INTO crmv2.offer_prod_inst_rel
      (offer_prod_inst_rel_id,
       prod_inst_id,
       prod_offer_inst_id,
       role_cd,
       offer_prod_inst_rel_role_id,
       status_cd,
       status_date,
       create_date,
       eff_date,
       exp_date,
       update_date,
       proc_serial,
       offer_prod_rel_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       rec_update_date,
       ext_flag)
      SELECT v_id2,
             in_p_inst,
             v_id,
             role_cd,
             '',

             '1000',
             v_eff_date,
             v_eff_date,
             v_eff_date,
             to_date('21990101', 'yyyymmdd'),
             v_eff_date,
             '',
             b.offer_prod_rela_id,
             a.area_id,
             a.common_region_id,
             '',
             '',
             '',
             ''
        FROM crmv2.prod_inst a, crmv2.offer_prod_rel b
       WHERE a.prod_inst_id = in_p_inst
         AND a.product_id = b.product_id
         AND b.prod_offer_id = in_offer_id
         AND nvl(b.role_cd, 1234567) = v_role;

    \*  ELSIF v_type = 'T05' THEN
      --新增产品关联
      SELECT crmv2.seq_offer_prod_inst_rel_id.nextval INTO v_id2 FROM dual;

      INSERT INTO crmv2.offer_prod_inst_rel
        (offer_prod_inst_rel_id,
         prod_inst_id,
         prod_offer_inst_id,
         role_cd,
         offer_prod_inst_rel_role_id,
         status_cd,
         status_date,
         create_date,
         eff_date,
         exp_date,
         update_date,
         proc_serial,
         offer_prod_rel_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         rec_update_date,
         ext_flag)
        SELECT v_id2,
               in_p_inst,
               v_id,
               role_cd,
               '',

               '1000',
               v_eff_date,
               v_eff_date,
               v_eff_date,
               v_exp_date,
               v_eff_date,
               '',
               b.offer_prod_rela_id,
               a.area_id,
               a.common_region_id,
               '',
               '',
               '',
               ''
          FROM crmv2.prod_inst a, crmv2.offer_prod_rel b
         WHERE a.prod_inst_id = in_p_inst
           AND a.product_id = b.product_id
           AND b.prod_offer_id = in_offer_id
           AND b.role_cd = in_rolecd;

    END IF;*\

    itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
                                        'offer_prod_inst_rel_ID', v_id2,
                                        in_modi_reason, v_staff);

    itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_rel',
                                        'prod_offer_inst_rel_ID', v_rela,
                                        in_modi_reason, v_staff);

    itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
                                        'prod_offer_inst_id', v_id,
                                        in_modi_reason, v_staff);

    o_offer_inst := v_id;
    SELECT po.prod_offer_name
      INTO v_name
      FROM crmv2.prod_offer po
     WHERE po.prod_offer_id = in_offer_id;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'PROD_OFFER_INST',
             o_offer_inst,
             '',
             area_id,
             '',
             '',
             'INSERT',
             in_offer_id,
             in_offer_id,
             'CRMV2.PKG_WH.CREATE_OFFER_INFO',
             v_staff,
             f_check_modi_staff(v_staff),
             in_modi_reason,
             SYSDATE,
             '新增销售品',
             '销售品类'
        FROM crmv2.prod_offer_inst a
       WHERE a.prod_offer_inst_id = o_offer_inst;
    COMMIT;
    v_context := '新增销售品【' || v_name || '】，生效时间：' ||
                 to_char(v_eff_date, 'yyyy-mm-dd') || ', 失效时间' ||
                 to_char(v_exp_date, 'yyyy-mm-dd');

    crmv2.proc_create_order(in_p_inst,
                            --产品实例ID
                            'CRMV2.PKG_WH.CREATE_OFFER_INFO',
                            --存储过程名称
                            '新增销售品',
                            --调用过程的作用
                            in_modi_reason,
                            --备注，调用这个存储过程的原因
                            v_staff, v_context
                            --存储过程操作的工号
                            );
  EXCEPTION
    WHEN OTHERS THEN
      o_offer_inst := '取T01失败';
      ROLLBACK;
  END;

  PROCEDURE insert_offer_attr(in_offer_id    IN NUMBER,
                              in_attr_spec   IN NUMBER,
                              in_attr_val    IN VARCHAR2,
                              in_modi_staff  IN VARCHAR2,
                              in_modi_reason IN VARCHAR2,
                              o_result       OUT VARCHAR2) IS
    --功　　能：添加销售品参数
    --创建时间：2012-8-7
    --开山始祖：lud
    --参    数：
    \*
    in_offer_id :销售品实例ID
    in_attr_spec ：属性 规格
    in_attr_val : 属性值
    o_result : 返回结果
    modi_staff :表示修改数据的操作人
    modi_reason: 修改原因
    *\

    v_err VARCHAR2(100);
    --  v_n1       number(10);
    v_n2          NUMBER(10);
    v_n3          NUMBER(10);
    v_n4          NUMBER(10);
    v_id          NUMBER(10);
    v_value_id    NUMBER(10);
    v_ip          VARCHAR2(100);
    v_host        VARCHAR2(100);
    v_user        VARCHAR2(100);
    v_staff       VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
  BEGIN
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_modi_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_modi_staff, 'lud') > 0 OR instr(in_modi_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;
    \*select count(1)
      into v_n1
      from crmv2.prod_offer_inst a, crmv2.prod_offer_attr c
     where a.prod_offer_inst_id = in_offer_id
       and a.prod_offer_id = c.prod_offer_id
       and c.attr_id = in_attr_spec
       and c.status_cd = '1000';

    if v_n1 = 0 then

      v_err := '套餐规格没有需要添加的这个特性';
      return;
    end if;*\

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_offer_inst a
     WHERE a.prod_offer_inst_id = in_offer_id
       AND area_id = f_check_modi_staff(in_modi_staff);

    IF f_check_modi_staff(in_modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(in_modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    SELECT COUNT(1)
      INTO v_n2
      FROM crmv2.attr_value a
     WHERE a.attr_id = in_attr_spec;

    IF v_n2 > 0 THEN

      SELECT COUNT(1)
        INTO v_n3
        FROM crmv2.attr_value a
       WHERE a.attr_id = in_attr_spec
         AND a.attr_value = in_attr_val;

      IF v_n3 = 0 THEN
        v_err := '属性取值在规格中不存在';
        RETURN;
      END IF;

    END IF;

    SELECT COUNT(1)
      INTO v_n4
      FROM crmv2.prod_offer_inst_attr a
     WHERE a.prod_offer_inst_id = in_offer_id
       AND a.attr_id = in_attr_spec;

    IF v_n4 > 0 THEN
      v_err := '属性在实例中已存在';
      RETURN;
    ELSE
      BEGIN
        SELECT a.attr_value_id
          INTO v_value_id
          FROM crmv2.attr_value a
         WHERE a.attr_id = in_attr_spec
           AND a.attr_value = in_attr_val;
      EXCEPTION
        WHEN OTHERS THEN
          v_value_id := NULL;
      END;

      SELECT crmv2.seq_prod_offer_inst_attr_id.nextval INTO v_id FROM dual;
      INSERT INTO crmv2.prod_offer_inst_attr
        (prod_offer_inst_attr_id,
         prod_offer_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         create_date,
         exp_date,
         eff_date,
         status_date,
         status_cd,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         rec_update_date,
         version)
        SELECT v_id,
               in_offer_id,
               in_attr_spec,
               v_value_id,
               TRIM(in_attr_val),
               (CASE
                 WHEN SYSDATE > = eff_date THEN
                  eff_date
                 ELSE
                  SYSDATE
               END),
               exp_date,
               eff_date,
               status_date,
               status_cd,
               (CASE
                 WHEN SYSDATE > = eff_date THEN
                  eff_date
                 ELSE
                  SYSDATE
               END),
               '',
               area_id,
               region_cd,
               '',
               '',
               '',
               '0'
          FROM crmv2.prod_offer_inst a
         WHERE a.prod_offer_inst_id = in_offer_id;

      INSERT INTO crmv2.prod_offer_inst_attr_his
        (prod_offer_inst_attr_id,
         prod_offer_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         create_date,
         exp_date,
         eff_date,
         status_date,
         status_cd,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date)
        SELECT prod_offer_inst_attr_id,
               prod_offer_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               create_date,
               exp_date,
               eff_date,
               status_date,
               status_cd,
               update_date,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_his_id.nextval,
               rec_update_date
          FROM crmv2.prod_offer_inst_attr a
         WHERE a.prod_offer_inst_attr_id = v_id
           AND a.status_cd = '1100';

      itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_attr',
                                          'PROD_OFFER_INST_ATTR_ID', v_id,
                                          in_modi_reason, v_staff);

      v_err := '添加成功';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      v_err    := '其他异常';
      o_result := v_err;
  END;

  PROCEDURE prod_inst_to_ykt(in_prod   IN NUMBER,
                             in_reason IN VARCHAR2,
                             in_staff  IN VARCHAR2,
                             o_result  OUT VARCHAR2) IS

    v_date        DATE := to_date('21990101', 'yyyymmdd');
    v_o           VARCHAR2(100);
    v_ip          VARCHAR2(100);
    v_host        VARCHAR2(100);
    v_user        VARCHAR2(100);
    v_staff       VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
  BEGIN
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_staff, 'lud') > 0 OR instr(in_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_inst a
     WHERE a.prod_inst_id = in_prod
       AND area_id = f_check_modi_staff(in_staff);

    IF f_check_modi_staff(in_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(in_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    --产品表
    UPDATE crmv2.prod_inst a
       SET status_cd         = '140000',
           a.status_date     = a.create_date,
           a.begin_rent_time = a.create_date,
           a.update_date     = SYSDATE + 1 / 24
     WHERE a.prod_inst_id = in_prod;

    --删除历史表，保持时间连续性
    DELETE FROM crmv2.prod_inst_his WHERE prod_inst_id = in_prod;

    INSERT INTO itsc_crmv2.obj_update_bill_bak
      SELECT 'PROD_INST',
             'PROD_INST_ID',
             in_prod,
             in_reason,
             in_staff,
             SYSDATE,
             area_id
        FROM crmv2.prod_inst
       WHERE prod_inst_id = in_prod;

    --产品与商品关系：
    FOR rec2 IN (SELECT a.*
                   FROM crmv2.offer_prod_inst_rel a,
                        crmv2.prod_offer_inst     b,
                        crmv2.prod_offer          c
                  WHERE a.prod_inst_id = in_prod
                    AND a.prod_offer_inst_id = b.prod_offer_inst_id
                    AND b.prod_offer_id = c.prod_offer_id
                    AND c.offer_sub_type IN ('T01', 'T04')) LOOP

      UPDATE crmv2.prod_offer_inst a
         SET a.eff_date    = v_date,
             a.exp_date    = v_date,
             a.status_date = create_date,
             update_date   = SYSDATE
       WHERE a.prod_offer_inst_id = rec2.prod_offer_inst_id;

      DELETE FROM crmv2.prod_offer_inst_his
       WHERE prod_offer_inst_id = rec2.prod_offer_inst_id
         AND status_cd != '1299';

      INSERT INTO itsc_crmv2.obj_update_bill_bak
        SELECT 'prod_offer_inst',
               'prod_offer_inst_id',
               rec2.prod_offer_inst_id,
               in_reason,
               v_staff,
               SYSDATE,
               area_id
          FROM crmv2.prod_inst
         WHERE prod_inst_id = in_prod;

    END LOOP;

    INSERT INTO itsc_crmv2.intf_ins_billing_update
      (ins_id,
       table_name,
       column_name,
       key_id,
       topic,
       TYPE,
       reason,
       operator,
       state,
       state_date,
       create_date,
       update_date,
       deal_num,
       next_deal_time,
       err_msg,
       remark,
       area_nbr)
      SELECT itsc_crmv2.seq_intf_ins_billing_update_id.nextval,
             upper(table_name),
             upper(col_name),
             key_id,
             modi_reason,
             '1003',
             modi_reason,
             modi_staff,
             '70A',
             NULL,
             SYSDATE,
             NULL,
             0,
             NULL,
             NULL,
             NULL,
             area_nbr
        FROM itsc_crmv2.obj_update_bill_bak a, crmv2.area_code b
       WHERE modi_reason = in_reason
         AND a.area_id = b.area_code_id;

    INSERT INTO itsc_crmv2.obj_update_bill_bak_his
      SELECT * FROM itsc_crmv2.obj_update_bill_bak;

    DELETE FROM itsc_crmv2.obj_update_bill_bak
     WHERE modi_reason = in_reason;
    COMMIT;

    itsc_crmv2.fjlud_wh_proceduce.add_prod_inst_attr(in_prod, 800000280,
                                                     '1', v_staff, in_reason,
                                                     v_o);

  END;

  PROCEDURE delete_price_t04(v_prod_offer_inst_id IN NUMBER, --mdse_price_rela.rela_id
                             i_exp_date           IN VARCHAR2, --失效时间
                             iremark              IN VARCHAR2, --修改备注
                             modi_staff           IN VARCHAR2, --修改人
                             o_msg                OUT VARCHAR2) IS
    --执行过程返回信息
    iexp_date     DATE;
    v_offer_type  crmv2.prod_offer.offer_type%TYPE;
    v_date        DATE := SYSDATE + 1 / 120;
    v_ip          VARCHAR2(100);
    v_host        VARCHAR2(100);
    v_user        VARCHAR2(100);
    v_staff       VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
    modi_man      VARCHAR2(100);
    v_bstaff      VARCHAR2(100);
    v_n           NUMBER(10);
    v_context     VARCHAR2(1000);
    v_name        VARCHAR2(100);
    v_prod        NUMBER(10);

  BEGIN
    modi_man := modi_staff;
    pkg_wh.recode_modi_log(v_ip, v_host, v_user);
    v_staff := modi_man;
    IF v_ip != '134.130.254.23' AND
       (instr(modi_man, 'lud') > 0 OR instr(iremark, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;
    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;

    IF v_bstaff IN ('CRMV2', 'ITSC_CRMV2') THEN
      v_bstaff := modi_staff;
    END IF;

    iexp_date := to_date(i_exp_date, 'yyyy-mm-dd');
    BEGIN
      SELECT c.offer_type
        INTO v_offer_type
        FROM crmv2.prod_offer_inst b, crmv2.prod_offer c
       WHERE b.prod_offer_inst_id = v_prod_offer_inst_id
         AND b.status_cd IN (1299, 1000)
         AND b.prod_offer_id = c.prod_offer_id
         AND c.offer_sub_type = 'T04';
    EXCEPTION
      WHEN OTHERS THEN
        o_msg := v_prod_offer_inst_id || '销售品ID不存在!!';
        RETURN;
    END;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM prod_offer_inst a
     WHERE prod_offer_inst_id = v_prod_offer_inst_id
       AND status_cd IN (1299, 1000)
       AND area_id = crmv2.pkg_wh.f_check_modi_staff(modi_man);

    IF crmv2.pkg_wh.f_check_modi_staff(modi_man) = 0 THEN
      o_msg := '修改人不准确';
      RETURN;
    ELSIF crmv2.pkg_wh.f_check_modi_staff(modi_man) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_msg := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    --判断是否是集团套餐
    SELECT count（1)
      INTO v_n
      FROM crmv2.prod_offer_inst pi
     WHERE pi.prod_offer_inst_id = v_prod_offer_inst_id
       AND pi.prod_offer_id IN
           (SELECT prod_offer_id
              FROM prod_offer
             WHERE prod_offer_id IN
                   (SELECT destination_code
                      FROM crmv2.intf_code_mapping
                     WHERE source_system = 'GROUP'
                       AND object_type = 'PROD_OFFER_CODE'
                       AND object_name = '集团IVPN套餐'));

    IF v_n > 0 THEN

      o_msg := '集团IVPN套餐不允许后台拆除，请转本地政企到集团CRM受理';
      RETURN;
    END IF;
    ---
    \********************判断失效集团套餐是否有问题单号* 20151015 ADD BY LINYX*******************\
    SELECT count（1)
      INTO v_n
      FROM crmv2.prod_offer_inst pi
     WHERE pi.prod_offer_inst_id = v_prod_offer_inst_id
       AND ext_prod_offer_inst_id IS NOT NULL
       AND length(ext_prod_offer_inst_id) < 30
       AND prod_offer_id IN (SELECT DISTINCT target_code
                               FROM crmv2.intf_dep_code_map
                              WHERE object_type = '0200');

    IF v_n > 0 AND instr(iremark, 'INC') = 0 AND instr(iremark, 'PRO') = 0 AND
       instr(iremark, 'DEM') = 0 AND instr(iremark, 'REQ') = 0 THEN
      o_msg := '集团套餐后台拆除请提供问题单号或需求单号！';
      RETURN;
    END IF;

    BEGIN
      SELECT c.prod_inst_id, po.prod_offer_name
        INTO v_prod, v_name
        FROM crmv2.offer_prod_inst_rel a,
             crmv2.prod_offer_inst     b,
             crmv2.prod_inst           c,
             crmv2.product             p,
             crmv2.prod_offer          po
       WHERE b.prod_offer_inst_id = a.prod_offer_inst_id
         AND b.prod_offer_id = po.prod_offer_id
         AND a.prod_inst_id = c.prod_inst_id
         AND c.product_id = p.product_id
         AND p.prod_func_type = '101'
         AND b.prod_offer_inst_id = v_prod_offer_inst_id
         AND rownum = 1;

    EXCEPTION
      WHEN OTHERS THEN
        v_prod := 0;
    END;
    --删除销售品
    INSERT INTO itsc_crmv2.obj_update_bill_bak
      (table_name,
       col_name,
       key_id,
       modi_reason,
       modi_staff,
       modi_date,
       area_id)
      SELECT 'prod_offer_inst',
             'prod_offer_inst_id',
             prod_offer_inst_id,
             iremark,
             v_staff,
             SYSDATE,
             area_id
        FROM prod_offer_inst a
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd IN (1299, 1000);

    v_date := SYSDATE + 1 / 120;
    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'PROD_OFFER_INST',
             a.prod_offer_inst_id,
             '',
             a.area_id,
             '',
             '',
             'DELETE',
             a.prod_offer_id,
             a.prod_offer_id,
             'CRMV2.PKG_WH.DELETE_PRICE',
             v_bstaff,
             crmv2.pkg_wh.f_check_modi_staff(modi_staff),
             iremark,
             SYSDATE,
             '删除销售品实例',
             '销售品类'
        FROM crmv2.prod_offer_inst a
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd IN (1299, 1000);

    INSERT INTO crmv2.prod_offer_inst_his
      (prod_offer_inst_id,
       prod_offer_id,
       cust_id,
       channel_id,
       create_date,
       status_cd,
       status_date,
       eff_date,
       exp_date,
       region,
       update_date,
       proc_serial,
       ext_prod_offer_inst_id,
       lan_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       his_id,
       rec_update_date,
       trial_eff_date,
       trial_exp_date,
       service_nbr,
       version)
      SELECT prod_offer_inst_id,
             prod_offer_id,
             cust_id,
             channel_id,
             create_date,
             decode(status_cd, 1299, 1299, 1100),
             status_date,
             eff_date,
             iexp_date,
             region,
             SYSDATE + 1 / 24,
             proc_serial,
             ext_prod_offer_inst_id,
             NULL,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             crmv2.seq_prod_offer_inst_his_id.nextval,
             v_date,
             trial_eff_date,
             trial_exp_date,
             service_nbr,
             version
        FROM crmv2.prod_offer_inst
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd IN (1299, 1000);

    UPDATE crmv2.prod_offer_inst
       SET exp_date    = iexp_date,
           status_date = v_date,
           status_cd   = '1100',
           update_date = SYSDATE + 1 / 24
     WHERE prod_offer_inst_id = v_prod_offer_inst_id
       AND status_cd IN (1299, 1000);

    \*
    new_p_ins_billing_update('prod_offer_inst',
                             'prod_offer_inst_id',
                             v_prod_offer_inst_id,
                             iremark,
                             modi_man);*\

    --删除销售品属性
    FOR rec IN (SELECT *
                  FROM crmv2.prod_offer_inst_attr
                 WHERE prod_offer_inst_id = v_prod_offer_inst_id
                   AND status_cd IN (1299, 1000)) LOOP

      INSERT INTO itsc_crmv2.obj_update_bill_bak
        (table_name,
         col_name,
         key_id,
         modi_reason,
         modi_staff,
         modi_date,
         area_id)
        SELECT 'prod_offer_inst_attr',
               'prod_offer_inst_attr_id',
               prod_offer_inst_attr_id,
               iremark,
               v_staff,
               SYSDATE,
               area_id
          FROM prod_offer_inst_attr a
         WHERE prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id
           AND status_cd IN (1299, 1000);

      INSERT INTO crmv2.prod_offer_inst_attr_his
        SELECT prod_offer_inst_attr_id,
               prod_offer_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               create_date,
               iexp_date,
               eff_date,
               status_date,
               decode(status_cd, 1299, 1299, 1100),
               SYSDATE + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_attr_2_id.nextval,
               v_date,
               version
          FROM crmv2.prod_offer_inst_attr
         WHERE prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id
           AND status_cd IN (1299, 1000);

      UPDATE crmv2.prod_offer_inst_attr b
         SET b.status_cd   = '1100',
             b.exp_date    = iexp_date,
             b.status_date = v_date,
             b.update_date = SYSDATE + 1 / 24
       WHERE b.prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id;

    \*  delete from crmv2.prod_offer_inst_attr
                                                                                                                                                                                               where prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id
                                                                                                                                                                                                 and status_cd = 1000;*\

    \*   new_p_ins_billing_update('prod_offer_inst_attr',
                                                                                                                                                                                                                                                                     'prod_offer_inst_attr_id',
                                                                                                                                                                                                                                                                     rec.prod_offer_inst_attr_id,
                                                                                                                                                                                                                                                                     iremark,
                                                                                                                                                                                                                                                                     modi_man);*\

    END LOOP;
    --删除销售品关联
    FOR rec IN (SELECT *
                  FROM crmv2.prod_offer_inst_rel
                 WHERE related_prod_offer_inst_id = v_prod_offer_inst_id
                   AND status_cd IN (1299, 1000)) LOOP

      INSERT INTO itsc_crmv2.obj_update_bill_bak
        (table_name,
         col_name,
         key_id,
         modi_reason,
         modi_staff,
         modi_date,
         area_id)
        SELECT 'prod_offer_inst_rel',
               'prod_offer_inst_rel_id',
               prod_offer_inst_rel_id,
               iremark,
               v_staff,
               SYSDATE,
               area_id
          FROM crmv2.prod_offer_inst_rel a
         WHERE related_prod_offer_inst_id = v_prod_offer_inst_id
           AND status_cd IN (1299, 1000);

      INSERT INTO crmv2.prod_offer_inst_rel_his
        SELECT prod_offer_inst_rel_id,
               rela_prod_offer_inst_id,
               related_prod_offer_inst_id,
               role_cd,
               prod_offer_inst_rel_role_id,
               relation_type_cd,
               decode(status_cd, 1299, 1299, 1100),
               eff_date,
               iexp_date,
               create_date,
               status_date,
               region_a,
               region_b,
               SYSDATE + 1 / 24,
               proc_serial,
               prod_offer_rela_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_rel_his_id.nextval,
               SYSDATE
          FROM crmv2.prod_offer_inst_rel
         WHERE prod_offer_inst_rel_id = rec.prod_offer_inst_rel_id
           AND status_cd IN (1299, 1000);
      DELETE FROM crmv2.prod_offer_inst_rel
       WHERE prod_offer_inst_rel_id = rec.prod_offer_inst_rel_id
         AND status_cd IN (1299, 1000);

    \*new_p_ins_billing_update('prod_offer_inst_rel',
                                                                                                                                                                                                                                                                     'prod_offer_inst_rel_id',
                                                                                                                                                                                                                                                                     rec.prod_offer_inst_rel_id,
                                                                                                                                                                                                                                                                     iremark,
                                                                                                                                                                                                                                                                     modi_man);
                                                                                                                                                                                                                                          *\
    END LOOP;

    --删除产品销售品关联
    FOR rec IN (SELECT *
                  FROM crmv2.offer_prod_inst_rel
                 WHERE prod_offer_inst_id = v_prod_offer_inst_id
                   AND status_cd IN (1299, 1000)) LOOP

      INSERT INTO itsc_crmv2.obj_update_bill_bak
        (table_name,
         col_name,
         key_id,
         modi_reason,
         modi_staff,
         modi_date,
         area_id)
        SELECT 'offer_prod_inst_rel',
               'offer_prod_inst_rel_id',
               offer_prod_inst_rel_id,
               iremark,
               v_staff,
               SYSDATE,
               area_id
          FROM crmv2.offer_prod_inst_rel a
         WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           AND status_cd IN (1299, 1000);

      INSERT INTO crmv2.offer_prod_inst_rel_his
        SELECT offer_prod_inst_rel_id,
               prod_inst_id,
               prod_offer_inst_id,
               role_cd,
               offer_prod_inst_rel_role_id,
               decode(status_cd, 1299, 1299, 1100),
               status_date,
               create_date,
               eff_date,
               iexp_date,
               SYSDATE + 1 / 24,
               proc_serial,
               offer_prod_rel_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_prod_inst_rel_his_id.nextval,
               SYSDATE,
               ext_flag
          FROM crmv2.offer_prod_inst_rel
         WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           AND status_cd IN (1299, 1000);
      DELETE FROM crmv2.offer_prod_inst_rel
       WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
         AND status_cd IN (1299, 1000);

    \*    new_p_ins_billing_update('offer_prod_inst_rel',
                                                                                                                                                                                                                                                                     'offer_prod_inst_rel_id',
                                                                                                                                                                                                                                                                     rec.offer_prod_inst_rel_id,
                                                                                                                                                                                                                                                                     iremark,
                                                                                                                                                                                                                                                                     modi_man);*\

    END LOOP;

    BEGIN
      FOR rec IN (SELECT * FROM itsc_crmv2.obj_update_bill_bak) LOOP
        itsc_crmv2.new_p_ins_billing_update(upper(rec.table_name),
                                            upper(rec.col_name), rec.key_id,
                                            iremark, modi_staff);
      END LOOP;
    END;

    INSERT INTO itsc_crmv2.obj_update_bill_bak_his
      SELECT * FROM itsc_crmv2.obj_update_bill_bak;

    DELETE FROM itsc_crmv2.obj_update_bill_bak;

    COMMIT;

    \********************集团套餐备份 20151014 add by linyx ****************\
    INSERT INTO crmv2.prod_offer_inst_jtsg
      (prod_offer_inst_id,
       ext_prod_offer_inst_id,
       ext_prod_offer_id,
       ext_date,
       modify_man,
       modify_reason,
       modify_date,
       state)
      SELECT v_prod_offer_inst_id,
             a.ext_prod_offer_inst_id,
             b.source_code,
             iexp_date,
             modi_staff,
             iremark,
             SYSDATE,
             '70A'
        FROM prod_offer_inst a, crmv2.intf_dep_code_map b
       WHERE a.prod_offer_inst_id = v_prod_offer_inst_id
         AND ext_prod_offer_inst_id IS NOT NULL
         AND a.prod_offer_id = b.target_code
         AND b.object_type = '0200';
    COMMIT;
    \*************************************************************************\

    o_msg := '修改成功！';

    v_context := '删除销售品【' || v_name || '】, 失效时间:' ||
                 to_char(iexp_date, 'yyyy-mm-dd');
    IF v_prod != 0 THEN
      crmv2.proc_create_order(v_prod,
                              --产品实例ID
                              'CRMV2.PKG_WH.DELETE_PRICE_T04',
                              --存储过程名称
                              '删除销售品',
                              --调用过程的作用
                              iremark,
                              --备注，调用这个存储过程的原因
                              modi_staff, v_context
                              --存储过程操作的工号
                              );
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_msg := v_prod_offer_inst_id || SQLERRM;
  END;

  PROCEDURE delete_price_t05(v_prod_offer_inst_id IN NUMBER, --mdse_price_rela.rela_id
                             i_exp_date           IN VARCHAR2, --失效时间
                             iremark              IN VARCHAR2, --修改备注
                             modi_staff           IN VARCHAR2, --修改人
                             o_msg                OUT VARCHAR2) IS
    --执行过程返回信息
    iexp_date     DATE;
    v_offer_type  crmv2.prod_offer.offer_type%TYPE;
    v_date        DATE := SYSDATE + 1 / 120;
    v_ip          VARCHAR2(100);
    v_host        VARCHAR2(100);
    v_user        VARCHAR2(100);
    v_staff       VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
    modi_man      VARCHAR2(100);
    v_bstaff      VARCHAR2(100);

    v_context VARCHAR2(1000);
    v_name    VARCHAR2(100);
    v_prod    NUMBER(10);

  BEGIN
    modi_man := modi_staff;
    pkg_wh.recode_modi_log(v_ip, v_host, v_user);
    v_staff := modi_man;
    IF v_ip != '134.130.254.23' AND
       (instr(modi_man, 'lud') > 0 OR instr(iremark, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;
    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;

    IF v_bstaff IN ('CRMV2', 'ITSC_CRMV2') THEN
      v_bstaff := modi_staff;
    END IF;

    iexp_date := to_date(i_exp_date, 'yyyy-mm-dd');
    BEGIN
      SELECT c.offer_type
        INTO v_offer_type
        FROM crmv2.prod_offer_inst b, crmv2.prod_offer c
       WHERE b.prod_offer_inst_id = v_prod_offer_inst_id
         AND b.status_cd IN (1299, 1000)
         AND b.prod_offer_id = c.prod_offer_id
         AND c.offer_sub_type = 'T05';
    EXCEPTION
      WHEN OTHERS THEN
        o_msg := v_prod_offer_inst_id || '销售品ID不存在!!';
        RETURN;
    END;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM prod_offer_inst a
     WHERE prod_offer_inst_id = v_prod_offer_inst_id
       AND status_cd IN (1299, 1000)
       AND area_id = f_check_modi_staff(modi_man);

    IF f_check_modi_staff(modi_man) = 0 THEN
      o_msg := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_man) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_msg := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    BEGIN
      SELECT c.prod_inst_id, po.prod_offer_name
        INTO v_prod, v_name
        FROM crmv2.offer_prod_inst_rel a,
             crmv2.prod_offer_inst     b,
             crmv2.prod_inst           c,
             crmv2.product             p,
             crmv2.prod_offer          po
       WHERE b.prod_offer_inst_id = a.prod_offer_inst_id
         AND b.prod_offer_id = po.prod_offer_id
         AND a.prod_inst_id = c.prod_inst_id
         AND c.product_id = p.product_id
         AND p.prod_func_type = '101'
         AND b.prod_offer_inst_id = v_prod_offer_inst_id
         AND rownum = 1;

    EXCEPTION
      WHEN OTHERS THEN
        v_prod := 0;
    END;
    --删除销售品
    INSERT INTO itsc_crmv2.obj_update_bill_bak
      (table_name,
       col_name,
       key_id,
       modi_reason,
       modi_staff,
       modi_date,
       area_id)
      SELECT 'prod_offer_inst',
             'prod_offer_inst_id',
             prod_offer_inst_id,
             iremark,
             v_staff,
             SYSDATE,
             area_id
        FROM prod_offer_inst a
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd IN (1299, 1000);

    v_date := SYSDATE + 1 / 120;
    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'PROD_OFFER_INST',
             a.prod_offer_inst_id,
             '',
             a.area_id,
             '',
             '',
             'DELETE',
             a.prod_offer_id,
             a.prod_offer_id,
             'CRMV2.PKG_WH.DELETE_PRICE',
             v_bstaff,
             f_check_modi_staff(modi_staff),
             iremark,
             SYSDATE,
             '删除销售品实例',
             '销售品类'
        FROM crmv2.prod_offer_inst a
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd IN (1299, 1000);

    INSERT INTO crmv2.prod_offer_inst_his
      (prod_offer_inst_id,
       prod_offer_id,
       cust_id,
       channel_id,
       create_date,
       status_cd,
       status_date,
       eff_date,
       exp_date,
       region,
       update_date,
       proc_serial,
       ext_prod_offer_inst_id,
       lan_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       his_id,
       rec_update_date,
       trial_eff_date,
       trial_exp_date,
       service_nbr,
       version)
      SELECT prod_offer_inst_id,
             prod_offer_id,
             cust_id,
             channel_id,
             create_date,
             decode(status_cd, 1299, 1299, 1100),
             status_date,
             eff_date,
             iexp_date,
             region,
             SYSDATE + 1 / 24,
             proc_serial,
             ext_prod_offer_inst_id,
             NULL,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             crmv2.seq_prod_offer_inst_his_id.nextval,
             v_date,
             trial_eff_date,
             trial_exp_date,
             service_nbr,
             version
        FROM crmv2.prod_offer_inst
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd IN (1299, 1000);

    UPDATE crmv2.prod_offer_inst
       SET exp_date    = iexp_date,
           status_date = v_date,
           status_cd   = '1100',
           update_date = SYSDATE + 1 / 24
     WHERE prod_offer_inst_id = v_prod_offer_inst_id
       AND status_cd IN (1299, 1000);

    \*
    new_p_ins_billing_update('prod_offer_inst',
                             'prod_offer_inst_id',
                             v_prod_offer_inst_id,
                             iremark,
                             modi_man);*\

    --删除销售品属性
    FOR rec IN (SELECT *
                  FROM crmv2.prod_offer_inst_attr
                 WHERE prod_offer_inst_id = v_prod_offer_inst_id
                   AND status_cd IN (1299, 1000)) LOOP

      INSERT INTO itsc_crmv2.obj_update_bill_bak
        (table_name,
         col_name,
         key_id,
         modi_reason,
         modi_staff,
         modi_date,
         area_id)
        SELECT 'prod_offer_inst_attr',
               'prod_offer_inst_attr_id',
               prod_offer_inst_attr_id,
               iremark,
               v_staff,
               SYSDATE,
               area_id
          FROM prod_offer_inst_attr a
         WHERE prod_offer_inst_id = v_prod_offer_inst_id
           AND status_cd IN (1299, 1000);

      INSERT INTO crmv2.prod_offer_inst_attr_his
        SELECT prod_offer_inst_attr_id,
               prod_offer_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               create_date,
               iexp_date,
               eff_date,
               status_date,
               decode(status_cd, 1299, 1299, 1100),
               SYSDATE + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_attr_2_id.nextval,
               v_date,
               version
          FROM crmv2.prod_offer_inst_attr
         WHERE prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id
           AND status_cd IN (1299, 1000);

      UPDATE crmv2.prod_offer_inst_attr b
         SET b.status_cd   = '1100',
             b.exp_date    = iexp_date,
             b.status_date = v_date,
             b.update_date = SYSDATE + 1 / 24
       WHERE b.prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id;

    \*  delete from crmv2.prod_offer_inst_attr
                                                                                                                                                                                       where prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id
                                                                                                                                                                                         and status_cd = 1000;*\

    \*   new_p_ins_billing_update('prod_offer_inst_attr',
                                                                                                                                                                                                                                                             'prod_offer_inst_attr_id',
                                                                                                                                                                                                                                                             rec.prod_offer_inst_attr_id,
                                                                                                                                                                                                                                                             iremark,
                                                                                                                                                                                                                                                             modi_man);*\

    END LOOP;
    --删除销售品关联
    FOR rec IN (SELECT *
                  FROM crmv2.prod_offer_inst_rel
                 WHERE related_prod_offer_inst_id = v_prod_offer_inst_id
                   AND status_cd IN (1299, 1000)) LOOP

      INSERT INTO itsc_crmv2.obj_update_bill_bak
        (table_name,
         col_name,
         key_id,
         modi_reason,
         modi_staff,
         modi_date,
         area_id)
        SELECT 'prod_offer_inst_rel',
               'prod_offer_inst_rel_id',
               prod_offer_inst_rel_id,
               iremark,
               v_staff,
               SYSDATE,
               area_id
          FROM crmv2.prod_offer_inst_rel a
         WHERE related_prod_offer_inst_id = v_prod_offer_inst_id
           AND status_cd IN (1299, 1000);

      INSERT INTO crmv2.prod_offer_inst_rel_his
        SELECT prod_offer_inst_rel_id,
               rela_prod_offer_inst_id,
               related_prod_offer_inst_id,
               role_cd,
               prod_offer_inst_rel_role_id,
               relation_type_cd,
               decode(status_cd, 1299, 1299, 1100),
               eff_date,
               iexp_date,
               create_date,
               status_date,
               region_a,
               region_b,
               SYSDATE + 1 / 24,
               proc_serial,
               prod_offer_rela_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_rel_his_id.nextval,
               SYSDATE
          FROM crmv2.prod_offer_inst_rel
         WHERE prod_offer_inst_rel_id = rec.prod_offer_inst_rel_id
           AND status_cd IN (1299, 1000);
      DELETE FROM crmv2.prod_offer_inst_rel
       WHERE prod_offer_inst_rel_id = rec.prod_offer_inst_rel_id
         AND status_cd IN (1299, 1000);

    \*new_p_ins_billing_update('prod_offer_inst_rel',
                                                                                                                                                                                                                                                             'prod_offer_inst_rel_id',
                                                                                                                                                                                                                                                             rec.prod_offer_inst_rel_id,
                                                                                                                                                                                                                                                             iremark,
                                                                                                                                                                                                                                                             modi_man);
                                                                                                                                                                                                                                  *\
    END LOOP;

    --删除产品销售品关联
    FOR rec IN (SELECT *
                  FROM crmv2.offer_prod_inst_rel
                 WHERE prod_offer_inst_id = v_prod_offer_inst_id
                   AND status_cd IN (1299, 1000)) LOOP

      INSERT INTO itsc_crmv2.obj_update_bill_bak
        (table_name,
         col_name,
         key_id,
         modi_reason,
         modi_staff,
         modi_date,
         area_id)
        SELECT 'offer_prod_inst_rel',
               'offer_prod_inst_rel_id',
               offer_prod_inst_rel_id,
               iremark,
               v_staff,
               SYSDATE,
               area_id
          FROM crmv2.offer_prod_inst_rel a
         WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           AND status_cd IN (1299, 1000);

      INSERT INTO crmv2.offer_prod_inst_rel_his
        SELECT offer_prod_inst_rel_id,
               prod_inst_id,
               prod_offer_inst_id,
               role_cd,
               offer_prod_inst_rel_role_id,
               decode(status_cd, 1299, 1299, 1100),
               status_date,
               create_date,
               eff_date,
               iexp_date,
               SYSDATE + 1 / 24,
               proc_serial,
               offer_prod_rel_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_prod_inst_rel_his_id.nextval,
               SYSDATE,
               ext_flag
          FROM crmv2.offer_prod_inst_rel
         WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           AND status_cd IN (1299, 1000);
      DELETE FROM crmv2.offer_prod_inst_rel
       WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
         AND status_cd IN (1299, 1000);

    \*    new_p_ins_billing_update('offer_prod_inst_rel',
                                                                                                                                                                                                                                                             'offer_prod_inst_rel_id',
                                                                                                                                                                                                                                                             rec.offer_prod_inst_rel_id,
                                                                                                                                                                                                                                                             iremark,
                                                                                                                                                                                                                                                             modi_man);*\

    END LOOP;

    INSERT INTO itsc_crmv2.intf_ins_billing_update
      (ins_id,
       table_name,
       column_name,
       key_id,
       topic,
       TYPE,
       reason,
       operator,
       state,
       state_date,
       create_date,
       update_date,
       deal_num,
       next_deal_time,
       err_msg,
       remark,
       area_nbr)
      SELECT itsc_crmv2.seq_intf_ins_billing_update_id.nextval,
             upper(table_name),
             upper(col_name),
             key_id,
             iremark,
             '1003',
             modi_reason,
             modi_staff,
             '70A',
             NULL,
             SYSDATE,
             NULL,
             0,
             NULL,
             NULL,
             NULL,
             area_nbr
        FROM itsc_crmv2.obj_update_bill_bak a, crmv2.area_code b
       WHERE modi_reason = iremark
         AND a.area_id = b.area_code_id;

    INSERT INTO itsc_crmv2.obj_update_bill_bak_his
      SELECT * FROM itsc_crmv2.obj_update_bill_bak;

    DELETE FROM itsc_crmv2.obj_update_bill_bak;

    COMMIT;

    o_msg := '修改成功！';

    v_context := '删除销售品【' || v_name || '】, 失效时间:' ||
                 to_char(iexp_date, 'yyyy-mm-dd');
    IF v_prod != 0 THEN
      crmv2.proc_create_order(v_prod,
                              --产品实例ID
                              'CRMV2.PKG_WH.DELETE_PRICE_T05',
                              --存储过程名称
                              '删除销售品',
                              --调用过程的作用
                              iremark,
                              --备注，调用这个存储过程的原因
                              modi_staff, v_context
                              --存储过程操作的工号
                              );
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_msg := v_prod_offer_inst_id || SQLERRM;
  END;

  PROCEDURE delete_prod_inst_attr(in_inst_attr_id IN NUMBER,
                                  in_reason       IN VARCHAR2,
                                  in_staff        IN VARCHAR2,
                                  o_result        OUT VARCHAR2) IS
    v_ip          VARCHAR2(100);
    v_host        VARCHAR2(100);
    v_user        VARCHAR2(100);
    v_staff       VARCHAR2(100);
    v_cnt_area_id NUMBER(10);
  BEGIN
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_staff, 'lud') > 0 OR instr(in_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_inst_attr a
     WHERE a.prod_inst_attr_id = in_inst_attr_id
       AND area_id = f_check_modi_staff(in_staff);

    IF f_check_modi_staff(in_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(in_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    FOR rec IN (SELECT *
                  FROM crmv2.prod_inst_attr a
                 WHERE a.prod_inst_attr_id = in_inst_attr_id) LOOP
      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PROD_INST_ATTR',
               rec.prod_inst_attr_id,
               'PROD_INST_ATTR_ID',
               rec.area_id,
               '',
               '',
               'DELETE',
               rec.attr_id,
               '',
               'CRMV2.PKG_WH.DELETE_PROD_INST_ATTR',
               in_staff,
               f_check_modi_staff(in_staff),
               in_reason,
               SYSDATE,
               '删除产品实例属性',
               '产品类'
          FROM dual;

      INSERT INTO crmv2.prod_inst_attr_his
        (prod_inst_attr_id,
         prod_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         status_cd,
         status_date,
         eff_date,
         exp_date,
         create_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         rec_update_date)
        SELECT prod_inst_attr_id,
               prod_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               '1100' status_cd,
               status_date,
               eff_date,
               SYSDATE,
               create_date,
               update_date,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_attr_his_id.nextval,
               SYSDATE
          FROM crmv2.prod_inst_attr a
         WHERE a.prod_inst_attr_id = rec.prod_inst_attr_id;

      DELETE FROM crmv2.prod_inst_attr a
       WHERE a.prod_inst_attr_id = rec.prod_inst_attr_id;

      itsc_crmv2.new_p_ins_billing_update('prod_inst_attr',
                                          'prod_inst_attr_id',
                                          rec.prod_inst_attr_id, in_reason,
                                          v_staff);
      o_result := '修改成功';
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      o_result := SQLERRM;
  END;

  PROCEDURE prod_offer_t01_err(in_prod_inst_id    IN NUMBER,
                               in_prodofferinstid IN NUMBER,
                               in_reason          IN VARCHAR2,
                               in_staff           IN VARCHAR2,
                               o_result           OUT VARCHAR2) IS
    v_exp     DATE;
    v_n       NUMBER(10);
    v_n2      NUMBER(10);
    v_offerid NUMBER(10);
    v_o       VARCHAR2(100);
    v_staff   VARCHAR2(100);
    CURSOR c IS
      SELECT c.*
        FROM crmv2.offer_prod_inst_rel a,
             crmv2.prod_offer_inst     c,
             crmv2.prod_offer          d
       WHERE a.prod_inst_id = in_prod_inst_id
         AND a.status_cd = '1000'
         AND a.prod_offer_inst_id = c.prod_offer_inst_id
         AND c.prod_offer_id = d.prod_offer_id
         AND d.offer_sub_type = 'T01'
         AND a.prod_offer_inst_id != in_prodofferinstid;
    v_ip   VARCHAR2(100);
    v_host VARCHAR2(100);
    v_user VARCHAR2(100);
  BEGIN
    o_result := '';
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_staff, 'lud') > 0 OR instr(in_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;
    --取留着的生效时间
    SELECT a.eff_date, a.prod_offer_id
      INTO v_exp, v_offerid
      FROM crmv2.prod_offer_inst a
     WHERE a.prod_offer_inst_id = in_prodofferinstid
       AND a.status_cd = '1000';

    FOR rec IN c LOOP
      --可选包转到保留的可选包中去
      FOR rec2 IN (SELECT c.offer_sub_type, a.prod_offer_inst_rel_id, b.*
                     FROM crmv2.prod_offer_inst_rel a,
                          crmv2.prod_offer_inst     b,
                          crmv2.prod_offer          c
                    WHERE a.rela_prod_offer_inst_id = rec.prod_offer_inst_id
                      AND a.status_cd = '1000'
                      AND a.relation_type_cd = '100000'
                      AND a.related_prod_offer_inst_id =
                          b.prod_offer_inst_id
                      AND b.prod_offer_id = c.prod_offer_id) LOOP
        --是否配置有
        SELECT COUNT(1)
          INTO v_n
          FROM crmv2.prod_offer_rel b
         WHERE b.offer_a_id = v_offerid
           AND b.offer_z_id = rec2.prod_offer_id
           AND b.status_cd = '1000'
           AND b.relation_type_cd = '100000';

        --如果没配置，可选包拆除
        IF v_n = 0 THEN

          --T04的删可选包
          IF rec2.offer_sub_type = 'T04' THEN
            itsc_crmv2.fjlud_wh_proceduce.delete_price(rec2.prod_offer_inst_id,
                                                       to_char(v_exp,
                                                                'yyyymmdd'),
                                                       in_reason, v_staff,
                                                       v_o);

            --组合类的删除关系，其他不处理
          ELSIF rec2.offer_sub_type = 'T05' THEN

            INSERT INTO crmv2.prod_offer_inst_rel_his
              SELECT prod_offer_inst_rel_id,
                     rela_prod_offer_inst_id,
                     related_prod_offer_inst_id,
                     role_cd,
                     prod_offer_inst_rel_role_id,
                     relation_type_cd,
                     1100,
                     eff_date,
                     v_exp,
                     create_date,
                     status_date,
                     region_a,
                     region_b,
                     SYSDATE + 1 / 24,
                     proc_serial,
                     prod_offer_rela_id,
                     area_id,
                     region_cd,
                     update_staff,
                     create_staff,
                     crmv2.seq_prod_offer_inst_rel_his_id.nextval,
                     SYSDATE
                FROM crmv2.prod_offer_inst_rel
               WHERE prod_offer_inst_rel_id = rec2.prod_offer_inst_rel_id;

            DELETE FROM crmv2.prod_offer_inst_rel
             WHERE prod_offer_inst_rel_id = rec2.prod_offer_inst_rel_id;

            itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_rel',
                                                'prod_offer_Inst_rel_Id',
                                                rec2.prod_offer_inst_rel_id,
                                                in_reason, v_staff);

          END IF;
          --有配置， 则转移到新的T01套餐上
        ELSE
          SELECT COUNT(1)
            INTO v_n2
            FROM crmv2.prod_offer_inst_rel b
           WHERE b.rela_prod_offer_inst_id = in_prodofferinstid
             AND b.related_prod_offer_inst_id = rec2.prod_offer_inst_id;

          IF v_n2 = 0 THEN
            UPDATE crmv2.prod_offer_inst_rel b
               SET (b.rela_prod_offer_inst_id, b.role_cd,
                    b.prod_offer_rela_id) =
                   (SELECT in_prodofferinstid,
                           c.role_cd,
                           c.prod_offer_rela_id
                      FROM crmv2.prod_offer_rel c
                     WHERE c.offer_z_id = rec2.prod_offer_id
                       AND c.offer_a_id = v_offerid
                       AND c.status_cd = '1000'
                       AND c.relation_type_cd = '100000')
             WHERE b.prod_offer_inst_rel_id = rec2.prod_offer_inst_rel_id;

            itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_rel',
                                                'prod_offer_Inst_rel_Id',
                                                rec2.prod_offer_inst_rel_id,
                                                in_reason, in_staff);

          ELSE
            INSERT INTO crmv2.prod_offer_inst_rel_his
              SELECT prod_offer_inst_rel_id,
                     rela_prod_offer_inst_id,
                     related_prod_offer_inst_id,
                     role_cd,
                     prod_offer_inst_rel_role_id,
                     relation_type_cd,
                     1100,
                     eff_date,
                     v_exp,
                     create_date,
                     status_date,
                     region_a,
                     region_b,
                     SYSDATE + 1 / 24,
                     proc_serial,
                     prod_offer_rela_id,
                     area_id,
                     region_cd,
                     update_staff,
                     create_staff,
                     crmv2.seq_prod_offer_inst_rel_his_id.nextval,
                     SYSDATE
                FROM crmv2.prod_offer_inst_rel
               WHERE prod_offer_inst_rel_id = rec2.prod_offer_inst_rel_id;

            DELETE FROM crmv2.prod_offer_inst_rel
             WHERE prod_offer_inst_rel_id = rec2.prod_offer_inst_rel_id;

            itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_rel',
                                                'prod_offer_Inst_rel_Id',
                                                rec2.prod_offer_inst_rel_id,
                                                in_reason, v_staff);
          END IF;
        END IF;

      END LOOP;

      itsc_crmv2.fjlud_wh_proceduce.delete_price(rec.prod_offer_inst_id,
                                                 to_char(v_exp, 'yyyymmdd'),
                                                 in_reason, v_staff, v_o);
    END LOOP;
  END;

  PROCEDURE create_offer_info_t01(in_p_inst      IN NUMBER,
                                  in_offer_id    IN NUMBER,
                                  ineff          IN VARCHAR2,
                                  in_exp         IN VARCHAR2,
                                  in_modi_staff  IN VARCHAR2,
                                  in_modi_reason IN VARCHAR2,
                                  o_offer_inst   OUT VARCHAR2)
  --LUD
    --2012.08.06
    -- 增加t01，不增加参数
   IS
    \*    v_type    varchar2(100);
    v_subid   number(10);*\
    v_id NUMBER(10);
    \*    v_rela    number(10);
    v_offspec number(10)*\
    v_exp   DATE;
    in_eff  DATE;
    v_id2   NUMBER(10);
    v_n     NUMBER(10);
    v_ip    VARCHAR2(100);
    v_host  VARCHAR2(100);
    v_user  VARCHAR2(100);
    v_staff VARCHAR2(100);
  BEGIN
    itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_modi_staff;
    IF v_ip != '134.130.254.23' AND
       (instr(in_modi_staff, 'lud') > 0 OR instr(in_modi_reason, 'lud') > 0) THEN
      v_staff := v_ip;
    END IF;
    SELECT COUNT(1)
      INTO v_n
      FROM crmv2.prod_offer_inst     a,
           crmv2.offer_prod_inst_rel b,
           crmv2.prod_offer          c
     WHERE b.prod_inst_id = in_p_inst
       AND b.prod_offer_inst_id = a.prod_offer_inst_id
       AND a.prod_offer_id = c.prod_offer_id
       AND c.offer_sub_type = 'T01';

    IF v_n > 0 THEN
      o_offer_inst := '已有在用或者在途的T01销售品';
      RETURN;
    END IF;

    --判断是否是集团套餐
    SELECT COUNT(1)
      INTO v_n
      FROM prod_offer
     WHERE prod_offer_id IN
           (SELECT destination_code
              FROM crmv2.intf_code_mapping
             WHERE source_system = 'GROUP'
               AND object_type = 'PROD_OFFER_CODE'
               AND object_name = '集团IVPN套餐')
       AND prod_offer_id = in_offer_id;

    IF v_n > 0 THEN

      o_offer_inst := '集团套餐不允许后台添加，请转本地政企到集团CRM受理';
      RETURN;
    END IF;

    v_exp  := nvl(to_date(in_exp, 'yyyy-mm-dd'),
                  to_date('21990101', 'yyyymmdd'));
    in_eff := nvl(to_date(ineff, 'yyyy-mm-dd'),
                  to_date('21990101', 'yyyymmdd'));

    \* select po.offer_sub_type
        into v_type
        from crmv2.prod_offer po
       where po.prod_offer_id = in_offer_id;
    *\
    \*  select a.prod_offer_inst_id, b.prod_offer_id
        into v_subid, v_offspec
        from crmv2.offer_prod_inst_rel a, crmv2.offer_prod_rel b
       where a.prod_inst_id = in_p_inst
         and a.offer_prod_rel_id = b.offer_prod_rela_id
         and b.rule_type = '12';
    *\
    -- 新增prod_offer_inst
    SELECT crmv2.seq_prod_offer_inst_id.nextval
    \*   itsc_crmv2.wh_common_process.qry_seq('prod_offer_inst')*\
      INTO v_id
      FROM dual;

    INSERT INTO crmv2.prod_offer_inst
      (prod_offer_inst_id,
       prod_offer_id,
       cust_id,
       channel_id,
       create_date,
       status_cd,
       status_date,
       eff_date,
       exp_date,
       region,
       update_date,
       proc_serial,
       ext_prod_offer_inst_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       trial_eff_date,
       trial_exp_date,
       rec_update_date,
       service_nbr,
       version,
       end_auto)
      SELECT v_id,
             in_offer_id,
             a.owner_cust_id,
             '',
             SYSDATE,
             '1000',
             in_eff,
             in_eff,
             v_exp,
             common_region_id,
             SYSDATE,
             '',
             '',
             \* '',*\
             area_id,
             a.common_region_id,
             '',
             '',
             '',
             '',
             '',
             '',
             '0',
             ''
        FROM crmv2.prod_inst a
       WHERE a.prod_inst_id = in_p_inst;

    SELECT crmv2.seq_offer_prod_inst_rel_id.nextval INTO v_id2 FROM dual;

    INSERT INTO crmv2.offer_prod_inst_rel
      (offer_prod_inst_rel_id,
       prod_inst_id,
       prod_offer_inst_id,
       role_cd,
       offer_prod_inst_rel_role_id,
       status_cd,
       status_date,
       create_date,
       eff_date,
       exp_date,
       update_date,
       proc_serial,
       offer_prod_rel_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       rec_update_date,
       ext_flag)
      SELECT v_id2,
             in_p_inst,
             v_id,
             role_cd,
             '',

             '1000',
             in_eff,
             in_eff,
             in_eff,
             to_date('21990101', 'yyyymmdd'),
             in_eff,
             '',
             b.offer_prod_rela_id,
             a.area_id,
             a.common_region_id,
             '',
             '',
             '',
             ''
        FROM crmv2.prod_inst a, crmv2.offer_prod_rel b
       WHERE a.prod_inst_id = in_p_inst
         AND a.product_id = b.product_id
         AND b.prod_offer_id = in_offer_id
         AND b.status_cd = '1000';

    itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
                                        'offer_prod_inst_rel_ID', v_id2,
                                        in_modi_reason, v_staff);

    itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
                                        'prod_offer_inst_id', v_id,
                                        in_modi_reason, v_staff);

    o_offer_inst := v_id;

  EXCEPTION
    WHEN OTHERS THEN
      o_offer_inst := '异常退出';
  END;

  PROCEDURE change_cust_group(in_custid   IN NUMBER,
                              in_group    IN NUMBER,
                              in_subgroup IN VARCHAR2,
                              in_reason   IN VARCHAR2,
                              in_staff    IN VARCHAR2,
                              o_result    OUT VARCHAR2) IS

    v_subid NUMBER(10);
    v_ip    VARCHAR2(100);
    v_host  VARCHAR2(100);
    v_user  VARCHAR2(100);
    v_staff VARCHAR2(100);
  BEGIN
    o_result := '';
    IF 1 = 2 THEN
      --过程先屏蔽
      itsc_crmv2.fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
      v_staff := in_staff;
      IF v_ip != '134.130.254.23' AND
         (instr(in_staff, 'lud') > 0 OR instr(in_reason, 'lud') > 0) THEN
        v_staff := v_ip;
      END IF;
      BEGIN
        SELECT val.attr_value
          INTO v_subid
          FROM crmv2.sys_class  tab,
               crmv2.attr_spec  col,
               crmv2.attr_value val
         WHERE tab.class_id = col.class_id
           AND col.attr_id = val.attr_id(+)
           AND tab.table_name = upper('CUST')
           AND attr_cd = upper('CUST_SUB_TYPE')
           AND col.attr_name = in_subgroup;

      EXCEPTION
        WHEN OTHERS THEN
          v_subid := '';
      END;
      UPDATE crmv2.cust
         SET cust_type = in_group, cust_sub_type = v_subid
       WHERE cust_id = in_custid;
      itsc_crmv2.new_p_ins_billing_update('cust', 'cust_id', in_custid,
                                          in_reason, v_staff);

    END IF;
  END;
  PROCEDURE p_dev_staff_team_proc_attr(in_order_item_id IN NUMBER,
                                       in_table_name    IN VARCHAR2,
                                       in_remark        IN VARCHAR2,
                                       in_modi_staff    IN VARCHAR2) IS
    v_his_id                  NUMBER(20);
    v_order_item_proc_attr_id NUMBER(20);
  BEGIN
    IF upper(in_table_name) = 'ORDER_ITEM_PROC_ATTR_HIS' THEN

      SELECT crmv2.seq_or_item_proc_attr_his_id.nextval
        INTO v_his_id
        FROM dual;

      INSERT INTO crmv2.order_item_proc_attr_his
        (order_item_proc_attr_id,
         order_item_id,
         class_id,
         obj_inst_id,
         obj_attr,
         operate,
         new_value,
         old_value,
         status,
         create_date,
         status_date,
         remark,
         obj_attr_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         update_date,
         db_inst_id,
         version)
        SELECT crmv2.seq_order_item_proc_attr_id.nextval order_item_proc_attr_id,
               order_item_id,
               110 class_id,
               b.order_item_obj_id obj_inst_id,
               'updateDevStaffReason' obj_attr,
               '10' operate,
               in_modi_staff || ' 于 ' ||
               to_char(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') || ' 因 ' ||
               in_remark || ' 修改发展员工信息' new_value,
               '' old_value,
               1000 status,
               SYSDATE create_date,
               SYSDATE status_date,
               in_modi_staff || ' 于 ' ||
               to_char(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') || ' 因 ' ||
               in_remark || ' 修改发展员工信息' remark,
               (SELECT attr_id
                  FROM crmv2.attr_spec
                 WHERE java_code = 'updateDevStaffReason') obj_attr_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               v_his_id,
               SYSDATE update_date,
               db_inst_id,
               '1' version
          FROM crmv2.order_item_his b
         WHERE b.order_item_id = in_order_item_id;

      crmv2.ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR_HIS',
                                         'HIS_ID', v_his_id,
                                         'p_dev_staff_team_proc_attr', '维护',
                                         'CREATE', NULL);

    ELSIF upper(in_table_name) = 'ORDER_ITEM_PROC_ATTR' THEN

      SELECT crmv2.seq_order_item_proc_attr_id.nextval
        INTO v_order_item_proc_attr_id
        FROM dual;

      INSERT INTO crmv2.order_item_proc_attr
        (order_item_proc_attr_id,
         order_item_id,
         class_id,
         obj_inst_id,
         obj_attr,
         operate,
         new_value,
         old_value,
         status,
         create_date,
         status_date,
         remark,
         obj_attr_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         update_date,
         db_inst_id,
         version)
        SELECT v_order_item_proc_attr_id,
               order_item_id,
               110 class_id,
               b.order_item_obj_id obj_inst_id,
               'updateDevStaffReason' obj_attr,
               '10' operate,
               in_modi_staff || ' 于 ' ||
               to_char(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') || ' 因 ' ||
               in_remark || ' 修改发展员工信息' new_value,
               '' old_value,
               1000 status,
               SYSDATE create_date,
               SYSDATE status_date,
               in_modi_staff || ' 于 ' ||
               to_char(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') || ' 因 ' ||
               in_remark || ' 修改发展员工信息' remark,
               (SELECT attr_id
                  FROM crmv2.attr_spec
                 WHERE java_code = 'updateDevStaffReason') obj_attr_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               SYSDATE update_date,
               db_inst_id,
               '1' version
          FROM crmv2.order_item b
         WHERE b.order_item_id = in_order_item_id;

      crmv2.ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR',
                                         'ORDER_ITEM_PROC_ATTR_ID',
                                         v_order_item_proc_attr_id,
                                         'p_dev_staff_team_proc_attr', '维护',
                                         'CREATE', NULL);

    END IF;
  END p_dev_staff_team_proc_attr;

  PROCEDURE change_dev_staff_team(in_custnumber IN VARCHAR2,
                                  in_staff_code IN VARCHAR2,
                                  in_team       IN NUMBER,
                                  modi_staff    IN VARCHAR2, --修改人
                                  modi_reason   IN VARCHAR2, --修改备注
                                  o_result      OUT VARCHAR) IS
    v_staffid                  NUMBER(10);
    v_n                        NUMBER(10);
    v_his_id                   NUMBER(20);
    v_his_id1                  NUMBER(20);
    v_order_item_proc_attr_id  NUMBER(20);
    v_order_item_proc_attr_id1 NUMBER(20);
    v_order_item_proc_attr_id2 NUMBER(20);
  BEGIN
    \* fjlud_wh_proceduce.recode_modi_log(v_ip, v_host, v_user);
    v_staff := in_staff_code;
    if v_ip != '134.130.254.23' and instr(in_staff_code, 'lud') >0 then
       v_staff := v_ip;
    end if;*\
    \*
    10131 DEV_STAFF 发展员工
    10132 DEV_TEAM  发展团队
    *\
    --修改发展人
    -- select * from crmv2.staff;
    IF in_staff_code IS NOT NULL THEN
      BEGIN
        SELECT ss.staff_id
          INTO v_staffid
          FROM crmv2.system_user ss
         WHERE ss.staff_code = in_staff_code
           AND status_cd = '1000';
      EXCEPTION
        WHEN OTHERS THEN
          o_result := '输入的工号异常';
          RETURN;
      END;

      --已竣工
      ---modify by lud 20130319 添加接入类和T01销售品判断
      IF in_staff_code IS NOT NULL THEN
        FOR rec IN (SELECT a.*
                      FROM crmv2.order_item_his     a,
                           crmv2.customer_order_his b,
                           crmv2.prod_offer_inst    poi,
                           crmv2.prod_offer         po
                     WHERE b.cust_so_number = TRIM(in_custnumber)
                       AND b.cust_order_id = a.cust_order_id
                       AND a.order_item_cd = '1200'
                       AND a.order_item_obj_id = poi.prod_offer_inst_id
                       AND poi.prod_offer_id = po.prod_offer_id
                       AND po.offer_sub_type = 'T01') LOOP
          SELECT COUNT(1)
            INTO v_n
            FROM crmv2.order_item_proc_attr_his c
           WHERE c.order_item_id = rec.order_item_id
             AND c.class_id = 6
             AND c.obj_attr_id = 10131;
          p_dev_staff_team_proc_attr(rec.order_item_id,
                                     'ORDER_ITEM_PROC_ATTR_HIS', modi_reason,
                                     modi_staff);

          IF v_n > 0 THEN

            UPDATE crmv2.order_item_proc_attr_his c
               SET new_value = v_staffid, update_date = SYSDATE + 1 / 24
             WHERE c.order_item_id = rec.order_item_id
               AND c.class_id = 6
               AND c.obj_attr_id = 10131;
          ELSE
            SELECT crmv2.seq_or_item_proc_attr_his_id.nextval
              INTO v_his_id
              FROM dual;

            INSERT INTO crmv2.order_item_proc_attr_his
              (order_item_proc_attr_id,
               order_item_id,
               class_id,
               obj_inst_id,
               obj_attr,
               operate,
               new_value,
               old_value,
               status,
               create_date,
               status_date,
               remark,
               obj_attr_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               update_date,
               db_inst_id,
               his_id,
               version)
              SELECT crmv2.seq_order_item_proc_attr_id.nextval,
                     rec.order_item_id,
                     6,
                     rec.order_item_obj_id,
                     'devStaff',
                     '10',
                     v_staffid,
                     '',
                     '1000',
                     SYSDATE,
                     SYSDATE,
                     '',
                     10131,
                     rec.area_id,
                     rec.region_cd,
                     '',
                     '',
                     SYSDATE + 1 / 24,
                     1,
                     v_his_id,
                     '0'
                FROM dual;

            crmv2.ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR_HIS',
                                               'HIS_ID', v_his_id,
                                               'p_dev_staff_team_proc_attr',
                                               '维护', 'CREATE', NULL);

          END IF;
        END LOOP;

        ---在途
        FOR rec IN (SELECT a.*
                      FROM crmv2.order_item_his  a,
                           crmv2.customer_order  b,
                           crmv2.prod_offer_inst poi,
                           crmv2.prod_offer      po
                     WHERE b.cust_so_number = TRIM(in_custnumber)
                       AND b.cust_order_id = a.cust_order_id
                       AND a.order_item_cd = '1200'
                       AND a.order_item_obj_id = poi.prod_offer_inst_id
                       AND poi.prod_offer_id = po.prod_offer_id
                       AND po.offer_sub_type = 'T01') LOOP
          SELECT COUNT(1)
            INTO v_n
            FROM crmv2.order_item_proc_attr c
           WHERE c.order_item_id = rec.order_item_id
             AND c.class_id = 6
             AND c.obj_attr_id = 10131;
          p_dev_staff_team_proc_attr(rec.order_item_id,
                                     'ORDER_ITEM_PROC_ATTR', modi_reason,
                                     modi_staff);

          IF v_n > 0 THEN

            UPDATE crmv2.order_item_proc_attr c
               SET new_value = v_staffid, update_date = SYSDATE + 1 / 24
             WHERE c.order_item_id = rec.order_item_id
               AND c.class_id = 6
               AND c.obj_attr_id = 10131;
          ELSE
            SELECT crmv2.seq_order_item_proc_attr_id.nextval
              INTO v_order_item_proc_attr_id
              FROM dual;
            -- select * from crmv2.order_item_proc_attr
            INSERT INTO crmv2.order_item_proc_attr
              (order_item_proc_attr_id,
               order_item_id,
               class_id,
               obj_inst_id,
               obj_attr,
               operate,
               new_value,
               old_value,
               status,
               create_date,
               status_date,
               remark,
               obj_attr_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               update_date,
               db_inst_id,
               version)
              SELECT v_order_item_proc_attr_id,
                     rec.order_item_id,
                     6,
                     rec.order_item_obj_id,
                     'devStaff',
                     '10',
                     v_staffid,
                     '',
                     '1000',
                     SYSDATE,
                     SYSDATE,
                     '',
                     10131,
                     rec.area_id,
                     rec.region_cd,
                     '',
                     '',
                     SYSDATE + 1 / 24,
                     1,
                     '0'
                FROM dual;

            crmv2.ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR',
                                               'ORDER_ITEM_PROC_ATTR_ID',
                                               v_order_item_proc_attr_id,
                                               'p_dev_staff_team_proc_attr',
                                               '维护', 'CREATE', NULL);

          END IF;
        END LOOP;
        o_result := '发展人修改成功';
        ---在途
        FOR rec IN (SELECT a.*
                      FROM crmv2.order_item      a,
                           crmv2.customer_order  b,
                           crmv2.prod_offer_inst poi,
                           crmv2.prod_offer      po
                     WHERE b.cust_so_number = TRIM(in_custnumber)
                       AND b.cust_order_id = a.cust_order_id
                       AND a.order_item_cd = '1200'
                       AND a.order_item_obj_id = poi.prod_offer_inst_id
                       AND poi.prod_offer_id = po.prod_offer_id
                       AND po.offer_sub_type = 'T01') LOOP
          SELECT COUNT(1)
            INTO v_n
            FROM crmv2.order_item_proc_attr c
           WHERE c.order_item_id = rec.order_item_id
             AND c.class_id = 6
             AND c.obj_attr_id = 10131;
          p_dev_staff_team_proc_attr(rec.order_item_id,
                                     'ORDER_ITEM_PROC_ATTR', modi_reason,
                                     modi_staff);

          IF v_n > 0 THEN

            UPDATE crmv2.order_item_proc_attr c
               SET new_value = v_staffid, update_date = SYSDATE + 1 / 24
             WHERE c.order_item_id = rec.order_item_id
               AND c.class_id = 6
               AND c.obj_attr_id = 10131;
          ELSE

            SELECT crmv2.seq_order_item_proc_attr_id.nextval
              INTO v_order_item_proc_attr_id1
              FROM dual;

            -- select * from crmv2.order_item_proc_attr
            INSERT INTO crmv2.order_item_proc_attr
              (order_item_proc_attr_id,
               order_item_id,
               class_id,
               obj_inst_id,
               obj_attr,
               operate,
               new_value,
               old_value,
               status,
               create_date,
               status_date,
               remark,
               obj_attr_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               update_date,
               db_inst_id,
               version)
              SELECT v_order_item_proc_attr_id1,
                     rec.order_item_id,
                     6,
                     rec.order_item_obj_id,
                     'devStaff',
                     '10',
                     v_staffid,
                     '',
                     '1000',
                     SYSDATE,
                     SYSDATE,
                     '',
                     10131,
                     rec.area_id,
                     rec.region_cd,
                     '',
                     '',
                     SYSDATE + 1 / 24,
                     1,
                     '0'
                FROM dual;

            crmv2.ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR',
                                               'ORDER_ITEM_PROC_ATTR_ID',
                                               v_order_item_proc_attr_id1,
                                               'p_dev_staff_team_proc_attr',
                                               '维护', 'CREATE', NULL);

          END IF;
        END LOOP;
        o_result := '发展人修改成功';

      END IF;

    END IF;
    IF in_team IS NOT NULL THEN
      --已竣工
      FOR rec IN (SELECT a.*
                    FROM crmv2.order_item_his     a,
                         crmv2.customer_order_his b,
                         crmv2.prod_offer_inst    poi,
                         crmv2.prod_offer         po
                   WHERE b.cust_so_number = TRIM(in_custnumber)
                     AND b.cust_order_id = a.cust_order_id
                     AND a.order_item_cd = '1200'
                     AND a.order_item_obj_id = poi.prod_offer_inst_id
                     AND poi.prod_offer_id = po.prod_offer_id
                     AND po.offer_sub_type = 'T01') LOOP
        SELECT COUNT(1)
          INTO v_n
          FROM crmv2.order_item_proc_attr_his c
         WHERE c.order_item_id = rec.order_item_id
           AND c.class_id = 6
           AND c.obj_attr_id = 10132;
        p_dev_staff_team_proc_attr(rec.order_item_id,
                                   'ORDER_ITEM_PROC_ATTR_HIS', modi_reason,
                                   modi_staff);

        IF v_n > 0 THEN

          UPDATE crmv2.order_item_proc_attr_his c
             SET new_value = in_team, update_date = SYSDATE + 1 / 24
           WHERE c.order_item_id = rec.order_item_id
             AND c.class_id = 6
             AND c.obj_attr_id = 10132;
        ELSE
          SELECT crmv2.seq_or_item_proc_attr_his_id.nextval
            INTO v_his_id1
            FROM dual;

          INSERT INTO crmv2.order_item_proc_attr_his
            (order_item_proc_attr_id,
             order_item_id,
             class_id,
             obj_inst_id,
             obj_attr,
             operate,
             new_value,
             old_value,
             status,
             create_date,
             status_date,
             remark,
             obj_attr_id,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             update_date,
             db_inst_id,
             his_id,
             version)
            SELECT crmv2.seq_order_item_proc_attr_id.nextval,
                   rec.order_item_id,
                   6,
                   rec.order_item_obj_id,
                   'devTeam',
                   '10',
                   in_team,
                   '',
                   '1000',
                   SYSDATE,
                   SYSDATE,
                   '',
                   10132,
                   rec.area_id,
                   rec.region_cd,
                   '',
                   '',
                   SYSDATE + 1 / 24,
                   1,
                   v_his_id1,
                   '0'
              FROM dual;

          crmv2.ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR_HIS',
                                             'HIS_ID', v_his_id1,
                                             'p_dev_staff_team_proc_attr',
                                             '维护', 'CREATE', NULL);

        END IF;
      END LOOP;

      ---在途
      FOR rec IN (SELECT a.*
                    FROM crmv2.order_item_his  a,
                         crmv2.customer_order  b,
                         crmv2.prod_offer_inst poi,
                         crmv2.prod_offer      po
                   WHERE b.cust_so_number = TRIM(in_custnumber)
                     AND b.cust_order_id = a.cust_order_id
                     AND a.order_item_cd = '1200'
                     AND a.order_item_obj_id = poi.prod_offer_inst_id
                     AND poi.prod_offer_id = po.prod_offer_id
                     AND po.offer_sub_type = 'T01') LOOP
        SELECT COUNT(1)
          INTO v_n
          FROM crmv2.order_item_proc_attr c
         WHERE c.order_item_id = rec.order_item_id
           AND c.class_id = 6
           AND c.obj_attr_id = 10132;
        p_dev_staff_team_proc_attr(rec.order_item_id,
                                   'ORDER_ITEM_PROC_ATTR_HIS', modi_reason,
                                   modi_staff);

        IF v_n > 0 THEN

          UPDATE crmv2.order_item_proc_attr c
             SET new_value = v_staffid, update_date = SYSDATE + 1 / 24
           WHERE c.order_item_id = rec.order_item_id
             AND c.class_id = 6
             AND c.obj_attr_id = 10132;
        ELSE

          SELECT crmv2.seq_order_item_proc_attr_id.nextval
            INTO v_order_item_proc_attr_id2
            FROM dual;
          -- select * from crmv2.order_item_proc_attr
          INSERT INTO crmv2.order_item_proc_attr
            (order_item_proc_attr_id,
             order_item_id,
             class_id,
             obj_inst_id,
             obj_attr,
             operate,
             new_value,
             old_value,
             status,
             create_date,
             status_date,
             remark,
             obj_attr_id,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             update_date,
             db_inst_id,
             version)
            SELECT v_order_item_proc_attr_id2,
                   rec.order_item_id,
                   6,
                   rec.order_item_obj_id,
                   'devStaff',
                   '10',
                   in_team,
                   '',
                   '1000',
                   SYSDATE,
                   SYSDATE,
                   '',
                   10132,
                   rec.area_id,
                   rec.region_cd,
                   '',
                   '',
                   SYSDATE + 1 / 24,
                   1,
                   '0'
              FROM dual;

          crmv2.ds_ins_intf_ins_ds_update_wh('ORDER_ITEM_PROC_ATTR',
                                             'ORDER_ITEM_PROC_ATTR_ID',
                                             v_order_item_proc_attr_id2,
                                             'p_dev_staff_team_proc_attr',
                                             '维护', 'CREATE', NULL);

        END IF;
      END LOOP;

      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'CUSTOMER_ORDER',
               '',
               in_custnumber,
               f_check_modi_staff(modi_staff),
               '',
               '',
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.CHANGE_DEV_STAFF_TEAM',
               modi_staff,
               f_check_modi_staff(modi_staff),
               modi_reason,
               SYSDATE,
               '修改发展员工和团队信息',
               '订单类'
          FROM dual;
      o_result := o_result || ',发展团队修改成功';
    END IF;
    COMMIT;
  END;


  PROCEDURE delete_product_order_item(in_prod_inst_id IN NUMBER,
                                      o_result        OUT VARCHAR2) IS
    v_id NUMBER(10);
  BEGIN
    v_id := in_prod_inst_id;
    dbms_output.put_line(v_id);
    o_result := '';
    NULL;
  END;

  \*  procedure delete_prod_inst_101(in_prod_id in number,
                                 in_reason  in varchar2,
                                 in_staff   in varchar2,
                                 in_exp     in date,
                                 in_type    in number) is
    v_id number(10);
  begin
    v_id := in_prod_id;
    dbms_output.put_line(v_id);
    null;
  end;*\
  PROCEDURE recode_modi_log(o_ip   OUT VARCHAR2,
                            o_host OUT VARCHAR2,
                            o_user OUT VARCHAR2) IS
    \*        v_ip varchar2(100);
    v_host varchar2(100);
    v_user varchar2(100);*\
  BEGIN

    SELECT sys_context('userenv', 'ip_address'),
           sys_context('USERENV', 'HOST'),
           sys_context('USERENV', 'SESSION_USER')
      INTO o_ip, o_host, o_user
      FROM dual;
  END;

  PROCEDURE release_termkey(in_termkey   IN VARCHAR2,
                            in_mkt_spec  IN NUMBER,
                            in_phone_nbr IN VARCHAR2,
                            modi_staff   IN VARCHAR,
                            iremark      IN VARCHAR,
                            out_err_msg  OUT VARCHAR2) IS
    -- Local variables here
    v_mkt_occupy_id    VARCHAR2(20);
    v_xml_content      VARCHAR2(3000);
    v_storage_id       NUMBER;
    v_mkt_reso_spec_id NUMBER;
    v_mkt_reso_id      NUMBER;
    v_state_date       VARCHAR2(40);
    v_req_date         VARCHAR2(40);
    v_xml_id           NUMBER;
    v_mkt_type         NUMBER;
    v_mkt_typeb        NUMBER;
    v_remark           VARCHAR2(100);
    v_modify_name      VARCHAR2(100);
    i                  NUMBER;
    num_esn            NUMBER;
    num_esn1           NUMBER;
    num_hflq           NUMBER;
    num_gjq            NUMBER;
    --  v_state              VARCHAR2(10);
    v_mkt_reso_spec_type NUMBER(10);
    modi_man             VARCHAR2(100);
    v_state              VARCHAR2(100);
  BEGIN
    modi_man := modi_staff;
    i        := 10;
    IF iremark IS NULL OR modi_man IS NULL OR in_phone_nbr IS NULL OR
       in_termkey IS NULL THEN
      out_err_msg := 'in_remark、in_modify_name、in_phone_nbr、in_termkey , in_mkt_spec 不允许为空';
      RETURN;
    END IF;
    i := 0;
    BEGIN
      SELECT a.mkt_reso_spec_type
        INTO v_mkt_type
        FROM crmv1.mkt_resource a
       WHERE a.mkt_reso_key = in_termkey;

      IF v_mkt_type IN
         ('610005325', '610006165', '610007508', '610004005', '610006585',
          '610007985', '610006166') THEN

        IF in_mkt_spec IS NULL THEN
          out_err_msg := '实物类型为旧实物大类，新实物细类不能为空，请重填';
          RETURN;
        ELSE
          SELECT a.mkt_res_type_id
            INTO v_mkt_type
            FROM crmv2.mkt_resource a
           WHERE a.mkt_res_id = in_mkt_spec;

          IF v_mkt_type NOT IN (63, 65, 67) THEN
            out_err_msg := '实物类型为旧实物大类，实物细类填写错误，请重填';
            RETURN;
          END IF;
        END IF;

      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        out_err_msg := '实物细类填写错误';
        RETURN;

    END;
    BEGIN
      SELECT to_char(b.mkt_occupy_id),
             a.mkt_reso_id,
             a.storage_id,
             a.mkt_reso_spec_id,
             a.mkt_reso_spec_type,
             a.state
        INTO v_mkt_occupy_id,
             v_mkt_reso_id,
             v_storage_id,
             v_mkt_reso_spec_id,
             v_mkt_reso_spec_type,
             v_state
        FROM crmv1.mkt_resource a, crmv1.mkt_occupy b
       WHERE a.mkt_reso_key = in_termkey
         AND a.mkt_reso_id = b.mkt_reso_id
         AND (b.buy_prod_id =
             (SELECT prod_inst_id
                 FROM crmv2.prod_inst
                WHERE acc_nbr = in_phone_nbr
                  AND product_id IN (800000002, 800000007)) OR
             b.buy_prod_id IN
             (SELECT prod_inst_id
                 FROM crmv2.prod_inst_his
                WHERE acc_nbr = in_phone_nbr
                  AND product_id IN (800000002, 800000007)))
         AND a.state IN ('70Z', '70I');
    EXCEPTION
      WHEN OTHERS THEN
        SELECT to_char(b.mkt_occupy_id),
               a.mkt_reso_id,
               a.storage_id,
               a.mkt_reso_spec_id,
               mkt_reso_spec_type
          INTO v_mkt_occupy_id,
               v_mkt_reso_id,
               v_storage_id,
               v_mkt_reso_spec_id,
               v_mkt_reso_spec_type
          FROM crmv1.mkt_resource a, crmv1.mkt_occupy_his b
         WHERE a.mkt_reso_key = in_termkey
           AND a.mkt_reso_id = b.mkt_reso_id
           AND (b.buy_prod_id =
               (SELECT prod_inst_id
                   FROM crmv2.prod_inst
                  WHERE acc_nbr = in_phone_nbr
                    AND product_id IN (800000002, 800000007)) OR
               b.buy_prod_id IN
               (SELECT prod_inst_id
                   FROM crmv2.prod_inst_his
                  WHERE acc_nbr = in_phone_nbr
                    AND product_id IN (800000002, 800000007)))
           AND a.state IN ('70Z', '70I')
           AND b.mkt_occupy_id =
               (SELECT MAX(mkt_occupy_id)
                  FROM crmv1.mkt_occupy_his
                 WHERE mkt_reso_id = a.mkt_reso_id);
    END;
    IF v_mkt_reso_spec_type = 610007585 THEN
      out_err_msg := '龙终端请走返销冲正流程进行释放';
      RETURN;
    END IF;
    i        := 1;
    num_esn  := 0;
    num_hflq := 0;
    num_gjq  := 0;
    SELECT \*+index(a,IDX_MKT_RESO_KEY)*\
     COUNT(*)
      INTO num_esn
      FROM crmv2.intf_mkt_xml a
     WHERE mkt_reso_key = in_termkey
       AND xml_type = '20';
    SELECT \*+index(a,IDX_ESN_INDEX)*\
     COUNT(*)
      INTO num_esn1
      FROM crmv2.intf_mkt_xml a
     WHERE esn = in_termkey
       AND xml_type = '20';

    SELECT \*+index(a,IDX_MKT_RESO_KEY)*\
     COUNT(*)
      INTO num_hflq
      FROM crmv2.intf_mkt_xml a, crmv1.mkt_resource b, crmv1.mkt_reso_fea c
     WHERE a.mkt_reso_key = c.param1
       AND b.mkt_reso_id = c.mkt_reso_id
       AND b.mkt_reso_key = in_termkey
       AND xml_type = '20';

    SELECT \*+index(a,IDX_MKT_RESO_KEY)*\
     COUNT(*)
      INTO num_gjq
      FROM crmv2.intf_mkt_xml a, crmv1.mkt_resource b, crmv1.mkt_reso_fea c
     WHERE a.mkt_reso_key = c.param1
       AND b.mkt_reso_id = c.mkt_reso_id
       AND b.mkt_reso_key = in_termkey
       AND xml_type = '20';

    IF num_esn + num_hflq + num_gjq + num_esn1 = 0 THEN
      out_err_msg := '该串号未上传集团';
    ELSE
      i           := 2;
      out_err_msg := '该串号已上传集团';
      --return;
      SELECT \*+index(a,IDX_MKT_INTF_XML_UNIQUE_01)*\
       to_char(a.xml_content), intf_mkt_xml_id
        INTO v_xml_content, v_xml_id
        FROM crmv2.intf_mkt_xml a
       WHERE a.xml_type = '20'
         AND a.xml_ref_id = v_mkt_occupy_id
         AND a.mdn = in_phone_nbr
         AND state = '70C'
         AND to_char(a.xml_content) LIKE '%<ActionCD>10</ActionCD>%'
         AND intf_mkt_xml_id =
             (SELECT \*+index(b,IDX_MKT_INTF_XML_UNIQUE_01)*\
               MAX(intf_mkt_xml_id)
                FROM crmv2.intf_mkt_xml b
               WHERE b.xml_type = '20'
                 AND b.xml_ref_id = v_mkt_occupy_id
                 AND state = '70C'
                 AND b.mdn = in_phone_nbr
                 AND to_char(b.xml_content) LIKE '%<ActionCD>10</ActionCD>%');

      SELECT REPLACE(v_xml_content, '<ActionCD>10</ActionCD>',
                     '<ActionCD>12</ActionCD>')
        INTO v_xml_content
        FROM dual;

      SELECT substr(v_xml_content, instr(v_xml_content, '<SalesDate>'), 31)
        INTO v_state_date
        FROM dual;

      SELECT REPLACE(v_xml_content, v_state_date,
                     '<SalesDate>' || to_char(SYSDATE, 'yyyymmdd') ||
                      '</SalesDate>')
        INTO v_xml_content
        FROM dual;
      SELECT substr(v_xml_content, instr(v_xml_content, '<BindExpTime>'), 35)
        INTO v_state_date
        FROM dual;

      SELECT REPLACE(v_xml_content, v_state_date,
                     '<BindExpTime>' || to_char(SYSDATE, 'yyyymmdd') ||
                      '</BindExpTime>')
        INTO v_xml_content
        FROM dual;

      SELECT substr(v_xml_content, instr(v_xml_content, '<ReqTime>'), 33)
        INTO v_req_date
        FROM dual;

      SELECT REPLACE(v_xml_content, v_req_date,
                     '<ReqTime>' || to_char(SYSDATE, 'yyyymmddhh24miss') ||
                      '</ReqTime>')
        INTO v_xml_content
        FROM dual;

      i := 3;

      INSERT INTO crmv2.intf_mkt_xml c
        (intf_mkt_xml_id,
         xml_ref_id,
         xml_type,
         xml_come,
         xml_go,
         xml_content,
         crea_time,
         modi_time,
         state,
         serial,
         remark,
         real_modify_date,
         service_code,
         transaction_id,
         mdn,
         mkt_reso_key,
         esn)
        SELECT crmv2.seq_intf_mkt_xml_id.nextval,
               v_mkt_occupy_id,
               '21',
               'MKT',
               'JT',
               v_xml_content,
               SYSDATE,
               SYSDATE,
               '70A',
               '',
               '',
               SYSDATE,
               'SVC16021',
               '',
               in_phone_nbr,
               in_termkey,
               in_termkey
          FROM dual;
    END IF;
    UPDATE crmv1.mkt_resource c
       SET state                = '70A',
           real_modify_date     = SYSDATE,
           c.mkt_reso_spec_id   = in_mkt_spec,
           c.mkt_reso_spec_type = v_mkt_type
     WHERE mkt_reso_id = v_mkt_reso_id;
    INSERT INTO crmv1.mkt_occupy_his
      SELECT * FROM crmv1.mkt_occupy WHERE mkt_occupy_id = v_mkt_occupy_id;
    UPDATE crmv1.mkt_occupy_his a
       SET a.remark         = modi_man || '于' ||
                              to_char(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') ||
                              '释放:' || iremark,
           real_modify_date = SYSDATE
     WHERE mkt_occupy_id = v_mkt_occupy_id;
    BEGIN
      INSERT INTO crmv2.prod_res_inst_rel_his
        (prod_res_inst_rel_id,
         prod_inst_id,
         mkt_res_inst_id,
         type_cd,
         property_type,
         create_date,
         status_cd,
         status_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id)
        SELECT prod_res_inst_rel_id,
               prod_inst_id,
               mkt_res_inst_id,
               type_cd,
               property_type,
               create_date,
               status_cd,
               status_date,
               SYSDATE + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_res_inst_rel_his_id.nextval
          FROM crmv2.prod_res_inst_rel
         WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    BEGIN
      INSERT INTO crmv2.offer_res_inst_rel_his
        (offer_res_inst_rel_id,
         mkt_res_inst_id,
         prod_offer_inst_id,
         use_prod_inst_id,
         create_date,
         status_cd,
         status_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id)
        SELECT offer_res_inst_rel_id,
               mkt_res_inst_id,
               prod_offer_inst_id,
               use_prod_inst_id,
               create_date,
               status_cd,
               status_date,
               SYSDATE + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_res_inst_rel_his_id.nextval
          FROM crmv2.offer_res_inst_rel
         WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    v_remark      := iremark;
    v_modify_name := modi_man;
    UPDATE crmv1.mkt_occupy_his
       SET remark           = v_remark || v_modify_name,
           real_modify_date = SYSDATE + 1 / 24
     WHERE mkt_occupy_id = v_mkt_occupy_id;
    DELETE crmv1.mkt_occupy WHERE mkt_occupy_id = v_mkt_occupy_id;
    BEGIN
      DELETE crmv2.prod_res_inst_rel
       WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    BEGIN
      DELETE crmv2.offer_res_inst_rel
       WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    UPDATE crmv1.mkt_store_item a
       SET a.usage_count    = a.usage_count + 1,
           a.moving_count   = decode(v_state, '70I', a.moving_count - 1,
                                     a.moving_count),
           real_modify_date = SYSDATE
     WHERE a.store_id = v_storage_id
       AND a.mkt_reso_spec_id = in_mkt_spec;
    i           := 4;
    out_err_msg := out_err_msg || '处理成功';
    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'MKT_RESOURCE',
             v_mkt_reso_id,
             'STATE',
             '',
             '',
             '70A',
             'MODIFY',
             '',
             '',
             'CRMV2.PKG_WH.RELEASE_TERMKEY',
             modi_man,
             f_check_modi_staff(modi_man),
             iremark,
             SYSDATE,
             '释放实物串码',
             '实物类'
        FROM dual;

    COMMIT;
    \*    ITSC_CRM.INS_JT_UPDATE('MKT_OCCUPY',
    'MKT_OCCUPY_ID',
    v_mkt_occupy_id,
    'D',
    sysdate,
    iremark,
    modi_man,
    ERR_MSG);*\
  EXCEPTION
    WHEN OTHERS THEN
      IF i = 0 THEN
        out_err_msg := '无实物数据';
      ELSIF i IN (2, 3, 4) THEN
        out_err_msg := SQLERRM;
      END IF;
  END;

  PROCEDURE ykt_to_cash(in_account_id  IN NUMBER,
                        in_modi_staff  IN VARCHAR2,
                        in_modi_reason IN VARCHAR2,
                        o_result       OUT VARCHAR2) IS
    v_cnt_area_id NUMBER(10);
  BEGIN
    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.account
     WHERE account_id = in_account_id
       AND area_id = f_check_modi_staff(in_modi_staff);

    IF f_check_modi_staff(in_modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(in_modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    ---------------------------  一卡通改现金 -----------------------------------
    -- 把签约号码置空
    INSERT INTO crmv2.account_his
      SELECT account_id,
             cust_id,
             common_region_id,
             account_name,
             account_area_grade,
             account_number,
             group_pay_method,
             pay_cycle,
             contact_phone,
             mobile_phone,
             if_default,
             '' proc_serial,
             ext_account_id,
             area_id,
             create_date,
             create_staff,
             region_cd,
             '1000' status_cd,
             status_date,
             update_date,
             update_staff,
             crmv2.seq_account_his_id.nextval his_id,
             SYSDATE rec_update_date,
             deduct_charge,
             deduct_limit,
             print_prod_id,
             sign_prod_id,
             print_acc_nbr,
             sign_acc_nbr,
             distributor_id,
             jfzs_flag
        FROM crmv2.account
       WHERE account_id = in_account_id;

    UPDATE crmv2.account
       SET print_prod_id = 0,
           sign_prod_id  = 0,
           sign_acc_nbr  = NULL,
           update_date   = SYSDATE,
           status_date   = SYSDATE
     WHERE account_id = in_account_id;

    FOR rec IN (SELECT * FROM payment_plan WHERE account_id = in_account_id) LOOP
      -- 改付款方式为现金
      INSERT INTO crmv2.payment_plan_his
        SELECT payment_plan,
               account_id,
               payment_method_id,
               payment_bank_id,
               payment_account,
               payment_account_name,
               payment_account_type,
               priority,
               area_id,
               create_date,
               create_staff,
               region_cd,
               '1000' status_cd,
               status_date,
               update_date,
               update_staff,
               crmv2.seq_payment_plan_his_id.nextval his_id,
               acc_agreement_code,
               send_entrust_method,
               entrust_type,
               SYSDATE rec_update_date,
               proportion,
               limitation,
               ext_payment_plan_id
          FROM crmv2.payment_plan
         WHERE payment_plan = rec.payment_plan;
      UPDATE crmv2.payment_plan
         SET payment_method_id = 1,
             payment_bank_id   = NULL,
             payment_account   = NULL,
             update_date       = SYSDATE,
             status_date       = SYSDATE

       WHERE payment_plan = rec.payment_plan;
      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PAYMENT_PLAN',
               rec.payment_plan,
               'PAYMENT_METHOD_ID',
               rec.area_id,
               '51',
               '1',
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.YKT_TO_CASH',
               in_modi_staff,
               rec.area_id,
               in_modi_reason,
               SYSDATE,
               '一卡通改现金',
               '账户类'
          FROM dual;

      itsc_crmv2.new_p_ins_billing_update('payment_plan', 'payment_plan',
                                          rec.payment_plan, in_modi_reason,
                                          in_modi_staff);
    END LOOP;
    COMMIT;

    itsc_crmv2.new_p_ins_billing_update('account', 'account_id',
                                        in_account_id, in_modi_reason,
                                        in_modi_staff);
    o_result := '修改成功！';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_result := in_account_id || SQLERRM;
  END;
  PROCEDURE cash_to_ykt(in_account_id   IN NUMBER,
                        in_sign_prod_id IN NUMBER,
                        in_acc_nbr      IN VARCHAR2,
                        in_bank_id      IN NUMBER,
                        in_bankcard     IN VARCHAR2,
                        in_modi_staff   IN VARCHAR2,
                        in_modi_reason  IN VARCHAR2,
                        o_result        OUT VARCHAR2) IS

    v_cnt_area_id NUMBER(10);
  BEGIN
    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.account
     WHERE account_id = in_account_id
       AND area_id = f_check_modi_staff(in_modi_staff);

    IF f_check_modi_staff(in_modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(in_modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    ------------------------ 现金恢复一卡通 --------------------------------------------
    -- 设置签约号码

    INSERT INTO crmv2.account_his
      SELECT account_id,
             cust_id,
             common_region_id,
             account_name,
             account_area_grade,
             account_number,
             group_pay_method,
             pay_cycle,
             contact_phone,
             mobile_phone,
             if_default,
             '' proc_serial,
             ext_account_id,
             area_id,
             create_date,
             create_staff,
             region_cd,
             '1000' status_cd,
             status_date,
             update_date,
             update_staff,
             crmv2.seq_account_his_id.nextval his_id,
             SYSDATE rec_update_date,
             deduct_charge,
             deduct_limit,
             print_prod_id,
             sign_prod_id,
             print_acc_nbr,
             sign_acc_nbr,
             distributor_id,
             jfzs_flag
        FROM crmv2.account
       WHERE account_id = in_account_id;
    UPDATE crmv2.account
       SET sign_prod_id = in_sign_prod_id,
           sign_acc_nbr = in_acc_nbr,
           status_date  = SYSDATE,
           update_date  = SYSDATE
     WHERE account_id = in_account_id;

    FOR rec IN (SELECT * FROM payment_plan WHERE account_id = in_account_id) LOOP
      -- 改付款方式为一卡通
      INSERT INTO crmv2.payment_plan_his
        SELECT payment_plan,
               account_id,
               payment_method_id,
               payment_bank_id,
               payment_account,
               payment_account_name,
               payment_account_type,
               priority,
               area_id,
               create_date,
               create_staff,
               region_cd,
               '1000' status_cd,
               status_date,
               update_date,
               update_staff,
               crmv2.seq_payment_plan_his_id.nextval his_id,
               acc_agreement_code,
               send_entrust_method,
               entrust_type,
               SYSDATE rec_update_date,
               proportion,
               limitation,
               ext_payment_plan_id
          FROM crmv2.payment_plan
         WHERE payment_plan = rec.payment_plan;

      UPDATE crmv2.payment_plan
         SET payment_method_id = 51,
             payment_bank_id   = in_bank_id,
             payment_account   = in_bankcard,
             status_date       = SYSDATE,
             update_date       = SYSDATE
       WHERE payment_plan = rec.payment_plan;
      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PAYMENT_PLAN',
               rec.payment_plan,
               'PAYMENT_METHOD_ID',
               rec.area_id,
               '1',
               '51',
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.YKT_TO_CASH',
               in_modi_staff,
               rec.area_id,
               in_modi_reason,
               SYSDATE,
               '现金改一卡通',
               '账户类'
          FROM dual;

      itsc_crmv2.new_p_ins_billing_update('payment_plan', 'payment_plan',
                                          rec.payment_plan, in_modi_reason,
                                          in_modi_staff);
    END LOOP;

    itsc_crmv2.new_p_ins_billing_update('account', 'account_id',
                                        in_account_id, in_modi_reason,
                                        in_modi_staff);
    COMMIT;
    o_result := '修改成功!!!!!';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_result := in_account_id || SQLERRM;
  END;

  PROCEDURE modify_accountname(in_account_id   IN NUMBER,
                               in_account_name IN VARCHAR2,
                               in_modi_staff   IN VARCHAR2,
                               in_modi_reason  IN VARCHAR2,
                               o_result        OUT VARCHAR2) IS
    v_cnt_area_id NUMBER(10);
  BEGIN

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.payment_plan
     WHERE account_id = in_account_id
       AND area_id = f_check_modi_staff(in_modi_staff);

    IF f_check_modi_staff(in_modi_staff) = 0 THEN
      o_result := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(in_modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_result := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    FOR rec IN (SELECT * FROM payment_plan WHERE account_id = in_account_id) LOOP

      UPDATE crmv2.payment_plan
         SET payment_account_name = in_account_name, update_date = SYSDATE
       WHERE payment_plan = rec.payment_plan;

      itsc_crmv2.new_p_ins_billing_update('payment_plan', 'payment_plan',
                                          rec.payment_plan, in_modi_reason,
                                          in_modi_staff);
    END LOOP;

    UPDATE crmv2.account
       SET account_name = in_account_name, update_date = SYSDATE
     WHERE account_id = in_account_id;

    COMMIT;

    itsc_crmv2.new_p_ins_billing_update('account', 'account_id',
                                        in_account_id, in_modi_reason,
                                        in_modi_staff);

    COMMIT;
    o_result := '修改成功！';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_result := in_account_id || SQLERRM;
  END;

  PROCEDURE p_mod_offer_inst_attr
  \***************************************************************
      FUN NAME: 修改销售品属性的属性值
      VERSION: V1.0.0
      AUTHOR: ZHENGZY
      CREATE_DATE: 20130206
      功能说明：修改销售品属性的属性值
    ****************************************************************\
  (i_offer_inst_attr_id IN NUMBER, --销售品属性表主键id
   i_attr_value         IN VARCHAR2, --属性值
   modi_staff           IN VARCHAR2, --修改人
   modi_reason          IN VARCHAR2, --修改备注
   o_msg                OUT VARCHAR2 --返回备注
   ) IS
    v_bstaff      VARCHAR2(50);
    v_cnt_area_id NUMBER(10);
  BEGIN
    --备份数据提取

    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;

    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := modi_staff;
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_offer_inst_attr
     WHERE prod_offer_inst_attr_id = i_offer_inst_attr_id
       AND area_id = f_check_modi_staff(modi_staff);

    IF f_check_modi_staff(modi_staff) = 0 THEN
      o_msg := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_msg := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    FOR rec IN (SELECT *
                  FROM crmv2.prod_offer_inst_attr
                 WHERE prod_offer_inst_attr_id = i_offer_inst_attr_id) LOOP
      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PROD_OFFER_INST_ATTR',
               rec.prod_offer_inst_attr_id,
               'ATTR_VALUE',
               rec.area_id,
               rec.attr_value,
               i_attr_value,
               'MODIFY',
               rec.attr_id,
               '',
               'CRMV2.PKG_WH.P_MOD_OFFER_INST_ATTR',
               v_bstaff,
               rec.area_id,
               modi_reason,
               SYSDATE,
               '修改销售品属性',
               '销售品类'
          FROM dual;

      UPDATE crmv2.prod_offer_inst_attr a
         SET a.attr_value    = i_attr_value,
             a.attr_value_id =
             (SELECT b.attr_value_id
                FROM crmv2.attr_value b
               WHERE a.attr_id = b.attr_id
                 AND b.attr_value = i_attr_value
                 AND b.status_cd = '1000')
       WHERE a.prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id;

      itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_attr',
                                          'prod_offer_inst_attr_id',
                                          rec.prod_offer_inst_attr_id,
                                          modi_reason, modi_staff);

      o_msg := '修改成功';
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END p_mod_offer_inst_attr;

  ---------------------------------修改套餐参数-----------------------

  \* （1）  允许修改配置表有配置的套餐参数
  （2） 入参：号码、套餐名、参数名、旧值、新值、流程id、
  修改人（根据登录工号自动获得传入）
  （3） 出参：是否成功，不成功要返回报错信息
  （4） 相关要求：
  A.  入参必须都要填，未填的返回报错，说明哪个入参没有填写
  B.  判断传入的流程id是否是>3500000的7位数字，否则返回报错信息：流程id有误
  C.  判断传入的套餐名是否有在配置表中配置，且flag=2 and state=’A’，
  查无记录的返回报错信息：套餐名有误或该套餐不允许修改
  D.  判断用户档案上是否有需取消的套餐及参数名，如果没有则返回报错信息：
  号码有误或套餐参数有误或号码上无此套餐
  E.  判断用户档案上的套餐参数值与传入的旧值是否相符，
  不符合的则返回报错信息：号码原参数值有误，请核实
  F.  修改结果需送往外系统，如ODS。*\

  PROCEDURE change_offer_inst_attr(in_account   IN VARCHAR2,
                                   in_offername IN VARCHAR2,
                                   in_attrname  IN VARCHAR2,

                                   in_newvalue   IN VARCHAR2,
                                   in_remark     IN VARCHAR2,
                                   in_modi_staff IN VARCHAR2,
                                   o_msg         OUT VARCHAR2) IS

    v_account   VARCHAR2(100) := REPLACE(in_account, ' ', '');
    v_offername VARCHAR2(100) := REPLACE(in_offername, ' ', '');
    v_attrname  VARCHAR2(100) := REPLACE(in_attrname, ' ', '');
    v_oldvalue  VARCHAR2(100);
    v_newvalue  VARCHAR2(100) := REPLACE(in_newvalue, ' ', '');
    v_remark    VARCHAR2(100) := REPLACE(in_remark, ' ', '');
    v_staff     VARCHAR2(100) := REPLACE(in_modi_staff, ' ', '');
    v_n         NUMBER(10);
    \*v_attrvalueid    number(10);
    v_attrvalue      varchar2(100);*\
    v_attrinstid     NUMBER(10);
    v_newvalueinst   VARCHAR2(100);
    v_newvalueinstid NUMBER(10);

    ---备份表中需要的字段
    v_bstaff VARCHAR2(100);
    v_attrid NUMBER(10);

  BEGIN
    --------------------------------参数准确性判断----------------------------
    --A.  入参必须都要填，未填的返回报错，说明哪个入参没有填写
    IF v_account IS NULL THEN
      o_msg := '号码未填写';
      RETURN;
    ELSIF v_offername IS NULL THEN
      o_msg := '套餐名未填写';
      RETURN;
    ELSIF v_attrname IS NULL THEN
      o_msg := '参数名称未填写';
      RETURN;

    ELSIF v_newvalue IS NULL THEN
      o_msg := '参数新值未填写';
      RETURN;

    ELSIF v_remark IS NULL THEN
      o_msg := '流程ID未填写';
      RETURN;

    ELSIF v_staff IS NULL THEN
      o_msg := '修改人员未填写';
      RETURN;
    END IF;

    --备份数据提取

    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;

    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := v_staff;
    END IF;

    ----------------------------------------------------------------------------
    --  D.  判断用户档案上是否有需取消的套餐及参数名，
    --如果没有则返回报错信息：
    --号码有误或套餐参数有误或号码上无此套餐

    SELECT COUNT(1)
      INTO v_n
      FROM crmv2.prod_inst            pi,
           crmv2.offer_prod_inst_rel  b,
           crmv2.prod_offer_inst      c,
           crmv2.prod_offer_attr      poa,
           crmv2.attr_spec            ass,
           crmv2.prod_offer_inst_attr poia
     WHERE pi.acc_nbr = v_account
       AND pi.prod_inst_id = b.prod_inst_id
       AND b.prod_offer_inst_id = c.prod_offer_inst_id
       AND c.prod_offer_id = poa.prod_offer_id
       AND poa.attr_id = ass.attr_id
       AND ass.attr_name = v_attrname
       AND ass.attr_id = poia.attr_id
       AND poia.prod_offer_inst_id = c.prod_offer_inst_id
       AND c.status_cd IN ('1299', '1000')
       AND poia.status_cd IN ('1299', '1000');

    IF v_n = 0 THEN
      o_msg := '号码有误或套餐参数有误或号码上无此套餐';
      RETURN;
    END IF;

    --取参数实例ID
    BEGIN
      SELECT poia.prod_offer_inst_attr_id,
             poa.attr_id,
             nvl(poia.attr_value, '空')
        INTO v_attrinstid, v_attrid, v_oldvalue
        FROM crmv2.prod_inst            pi,
             crmv2.offer_prod_inst_rel  b,
             crmv2.prod_offer_inst      c,
             crmv2.prod_offer_attr      poa,
             crmv2.attr_spec            ass,
             crmv2.prod_offer_inst_attr poia,
             crmv2.prod_offer           po
       WHERE pi.acc_nbr = v_account
         AND pi.prod_inst_id = b.prod_inst_id
         AND b.prod_offer_inst_id = c.prod_offer_inst_id
         AND c.prod_offer_id = poa.prod_offer_id
         AND poa.attr_id = ass.attr_id
         AND c.prod_offer_id = po.prod_offer_id
         AND po.prod_offer_name = v_offername
         AND ass.attr_name = v_attrname
         AND ass.attr_id = poia.attr_id
         AND poia.prod_offer_inst_id = c.prod_offer_inst_id
         AND c.status_cd IN ('1299', '1000')
         AND poia.status_cd IN ('1299', '1000');

    EXCEPTION
      WHEN no_data_found THEN
        o_msg := '销售品上的参数档案不存在';
        RETURN;
      WHEN OTHERS THEN
        o_msg := '销售品上的参数个数有误';
        RETURN;

    END;

    --取新值
    BEGIN
      SELECT av.attr_value, av.attr_value_id
        INTO v_newvalueinst, v_newvalueinstid
        FROM crmv2.prod_offer            po,
             crmv2.prod_offer_attr       poa,
             crmv2.attr_spec             ass,
             crmv2.attr_value            av,
             crmv2.prod_offer_attr_value poav
       WHERE po.prod_offer_name = v_offername
         AND po.prod_offer_id = poa.prod_offer_id
         AND poa.attr_id = ass.attr_id
         AND ass.attr_name = v_attrname
         AND poa.prod_offer_attr_id = poav.prod_offer_attr_id
         AND ass.attr_id = av.attr_id
         AND av.attr_value_name = v_newvalue
         AND poa.status_cd = '1000'
         AND poav.status_cd = '1000'
         AND poav.attr_value_id = av.attr_value_id;

    EXCEPTION
      WHEN no_data_found THEN
        SELECT COUNT(1)
          INTO v_n
          FROM crmv2.prod_offer            po,
               crmv2.prod_offer_attr       poa,
               crmv2.prod_offer_attr_value poav,
               crmv2.attr_value            av,
               crmv2.attr_spec             ass
         WHERE po.prod_offer_name = v_offername
           AND poa.attr_id = ass.attr_id
           AND ass.attr_name = v_attrname
           AND po.prod_offer_id = poa.prod_offer_id
           AND poa.prod_offer_attr_id = poav.prod_offer_attr_id
           AND poav.status_cd = '1000';

        IF v_n > 0 THEN
          o_msg := '号码新参数值不适用于该套餐，请核实';
          RETURN;
        ELSE
          v_newvalueinstid := '';
          v_newvalueinst   := v_newvalue;
        END IF;

      WHEN OTHERS THEN
        o_msg := '号码新参数值输入有误，请核实';
        RETURN;

    END;

    --F。修改结果需送往外系统，如ODS。
    UPDATE crmv2.prod_offer_inst_attr a
       SET a.attr_value_id = v_newvalueinstid,
           a.attr_value    = v_newvalueinst
     WHERE a.prod_offer_inst_attr_id = v_attrinstid;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'PROD_OFFER_INST_ATTR',
             v_attrinstid,
             'ATTR_VALUE',
             6,
             v_oldvalue,
             v_newvalueinst,
             'MODIFY',
             v_attrid,
             prod_offer_id,
             'CRMV2.PKG_WH.CHANGE_OFFER_INST_ATTR',
             v_bstaff,
             '6',
             v_remark,
             SYSDATE,
             '修改可选包属性',
             '销售品类'
        FROM itsc_crmv2.qz_prod_offer_config a
       WHERE a.prod_offer_name = v_offername;

    itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_attr',
                                        'prod_offer_inst_attr_id',
                                        v_attrinstid, v_remark, v_staff);

  END;

  PROCEDURE p_modify_single_data
  \***************************************************************
      FUN NAME: 修改数据库表的单条记录
      VERSION: V1.0.0
      AUTHOR: ZHENGZY
      CREATE_DATE: 20130219
      功能说明：修改数据库表的单条记录
    ****************************************************************\
  (in_owner      IN VARCHAR2, --用户名
   in_table_name IN VARCHAR2, --表名
   in_key_id     IN VARCHAR2, --主键id
   in_col_name   IN VARCHAR2, --要修改的字段名称
   in_new_value  IN VARCHAR2, --要修改的字段值
   modi_staff    IN VARCHAR2, --修改人
   modi_reason   IN VARCHAR2, --修改备注
   o_msg         OUT VARCHAR2) --输出结果
   AS
    -- v_cnt         NUMBER(10);
    o_area_id       VARCHAR2(10);
    v_str           VARCHAR2(1000);
    v_primary_col   VARCHAR2(50);
    v_bstaff        VARCHAR2(100);
    v_type          VARCHAR2(50);
    v_old_value_str VARCHAR2(1000);
    v_old_value     VARCHAR2(500);
  BEGIN
    o_msg := '处理失败';
    --备份数据提取

    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;
    IF v_bstaff IN ('CRMV2', 'ITSC_CRMV2') THEN
      v_bstaff := modi_staff;
    END IF;

    --根据配置表判断，是否在允许修改的范围内
    BEGIN
      SELECT a.type
        INTO v_type
        FROM crmv2.crm_tal_col_modi_config a
       WHERE a.owner = upper(TRIM(in_owner))
         AND a.table_name = upper(TRIM(in_table_name))
         AND a.column_name = upper(TRIM(in_col_name));
    EXCEPTION
      WHEN OTHERS THEN
        o_msg := '该字段不允许修改，谢谢';
        RETURN;
    END;

    -- 关联出主键的字段名
    SELECT b.column_name
      INTO v_primary_col
      FROM dba_constraints a, dba_cons_columns b
     WHERE a.table_name = upper(TRIM(in_table_name))
       AND a.constraint_name = b.constraint_name
       AND a.owner = upper(TRIM(in_owner))
       AND a.constraint_type = 'P'
       AND a.owner = b.owner;

    -- 算出处理工号的地区
    o_area_id := f_check_modi_staff(modi_staff);

    --各个地市工号的修改
    IF o_area_id > 1 THEN
      BEGIN
        --获取字段的旧值
        v_old_value_str := 'select ' || in_col_name || ' from ' || in_owner || '.' ||
                           in_table_name || ' where ' || v_primary_col || '=' ||
                           TRIM(in_key_id) || ' and area_id=' || o_area_id;
        dbms_output.put_line(v_old_value_str);
        EXECUTE IMMEDIATE v_old_value_str
          INTO v_old_value;

        v_str := 'update ' || in_owner || '.' || in_table_name || ' set ' ||
                 in_col_name || '=' || '''' || in_new_value || '''' || ',update_date = sysdate '  ||
                 ' where ' || v_primary_col || '=' || TRIM(in_key_id) ||
                 ' and area_id=' || o_area_id;
        dbms_output.put_line(v_str);
        EXECUTE IMMEDIATE v_str;

      EXCEPTION
        WHEN OTHERS THEN
          --add zzy 20130628 修改渠道类数据，用common_region_id 去校验是否C4本地网数据
          --获取字段的旧值
          v_old_value_str := 'select ' || in_col_name || ' from ' ||
                             in_owner || '.' || in_table_name || ' where ' ||
                             v_primary_col || '=' || TRIM(in_key_id) ||
                             ' and Common_Region_Id in (select Common_Region_Id from crmv2.common_region b where b.Up_Region_Id=' ||
                             o_area_id || ')';
          dbms_output.put_line(v_old_value_str);
          EXECUTE IMMEDIATE v_old_value_str
            INTO v_old_value;

          v_str := 'update ' || in_owner || '.' || in_table_name || ' set ' ||
                   in_col_name || '=' || '''' || in_new_value || '''' || ',update_date = sysdate '  ||
                   ' where ' || v_primary_col || '=' || TRIM(in_key_id) ||
                   ' and Common_Region_Id in (select Common_Region_Id from crmv2.common_region b where b.Up_Region_Id=' ||
                   o_area_id || ')';
          dbms_output.put_line(v_str);
          EXECUTE IMMEDIATE v_str;

      END;

      --送接口判断//------都送双写----------------
      --IF v_type IN ('产品类', '销售品类', '客户类', '账户类') THEN
        itsc_crmv2.new_p_ins_billing_update(REPLACE(upper(in_table_name),
                                                    '_HIS', ''),
                                            v_primary_col, TRIM(in_key_id),
                                            modi_reason, modi_staff);
      --END IF;

      o_msg := '单条数据修改成功';

      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT upper(in_table_name),
               in_key_id,
               upper(in_col_name),
               o_area_id,
               v_old_value,
               in_new_value,
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.P_MODIFY_SINGLE_DATA',
               v_bstaff,
               o_area_id,
               modi_reason,
               SYSDATE,
               '修改单个表记录',
               v_type
          FROM dual;

      --ff，fj开头的工号
    ELSIF o_area_id = 1 THEN
      --获取字段的旧值
      v_old_value_str := 'select ' || in_col_name || ' from ' || in_owner || '.' ||
                         in_table_name || ' where ' || v_primary_col || '=' ||
                         TRIM(in_key_id);
      dbms_output.put_line(v_old_value_str);
      EXECUTE IMMEDIATE v_old_value_str
        INTO v_old_value;

      v_str := 'update ' || in_owner || '.' || in_table_name || ' set ' ||
               in_col_name || '=' || in_new_value ||  ', update_date = sysdate ' || ' where ' ||
               v_primary_col || '=' || TRIM(in_key_id);
      dbms_output.put_line(v_str);
      EXECUTE IMMEDIATE v_str;
      --送接口判断//------都送双写----------------
      --IF v_type IN ('产品类', '销售品类', '客户类', '账户类') THEN
        itsc_crmv2.new_p_ins_billing_update(REPLACE(upper(in_table_name),
                                                    '_HIS', ''),
                                            v_primary_col, TRIM(in_key_id),
                                            modi_reason, modi_staff);
      --END IF;
      o_msg := '当条数据修改成功';
      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT upper(in_table_name),
               TRIM(in_key_id),
               upper(in_col_name),
               o_area_id,
               v_old_value,
               in_new_value,
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.P_MODIFY_SINGLE_DATA',
               v_bstaff,
               o_area_id,
               modi_reason,
               SYSDATE,
               '',
               v_type
          FROM dual;

    ELSE
      o_msg := '该条数据不允许修改';
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END p_modify_single_data;


  FUNCTION f_check_modi_staff(in_staff VARCHAR2) RETURN NUMBER IS
    RESULT  NUMBER(12);
    v_staff VARCHAR2(50);
  BEGIN
    v_staff := lower(in_staff);
    IF instr(v_staff, 'fz') = 1 THEN
      RESULT := 2;
    ELSIF instr(v_staff, 'xm') = 1 THEN
      RESULT := 3;
    ELSIF instr(v_staff, 'nd') = 1 THEN
      RESULT := 4;
    ELSIF instr(v_staff, 'pt') = 1 THEN
      RESULT := 5;
    ELSIF instr(v_staff, 'qz') = 1 THEN
      RESULT := 6;
    ELSIF instr(v_staff, 'zz') = 1 THEN
      RESULT := 7;
    ELSIF instr(v_staff, 'ly') = 1 THEN
      RESULT := 8;
    ELSIF instr(v_staff, 'sm') = 1 THEN
      RESULT := 9;
    ELSIF instr(v_staff, 'np') = 1 THEN
      RESULT := 10;
    ELSIF (instr(v_staff, 'ff') = 1 OR instr(v_staff, 'fj') = 1) THEN
      RESULT := 1;
    ELSE
      RESULT := 0;
    END IF;
    RETURN(RESULT);
  END f_check_modi_staff;

  \*procedure p_check_modi_staff(in_staff in varchar2,o_area_id out varchar2) is
  begin
          if instr(in_staff, 'fz') = 1 then
            o_area_id := 2;
          elsif    instr(in_staff, 'xm') = 1 then
            o_area_id := 3;
            elsif    instr(in_staff, 'nd') = 1 then
            o_area_id := 4;
            elsif    instr(in_staff, 'pt') = 1 then
            o_area_id := 5;
            elsif    instr(in_staff, 'qz') = 1 then
            o_area_id := 6;
            elsif    instr(in_staff, 'zz') = 1 then
            o_area_id := 7;
            elsif    instr(in_staff, 'ly') = 1 then
            o_area_id := 8;
            elsif    instr(in_staff, 'sm') = 1 then
            o_area_id := 9;
            elsif    instr(in_staff, 'np') = 1 then
            o_area_id := 10;
            elsif (instr(in_staff, 'ff') = 1 or instr(in_staff, 'fj') = 1) then
             o_area_id := 1;
             else
            o_area_id := 0;
          end if;
  END;*\

  PROCEDURE p_modify_offer_yqsx
  \***************************************************************
      FUN NAME: 延期生效的新套餐销售品修改成立即生效
      VERSION: V1.0.0
      AUTHOR: ZHENGZY
      CREATE_DATE: 20130220
      功能说明：延期生效的新套餐销售品修改成立即生效
    ****************************************************************\
  (in_offer_inst_id IN NUMBER, -- 旧套餐实例id
   modi_staff       IN VARCHAR2, --修改人
   modi_reason      IN VARCHAR2, --修改备注
   o_msg            OUT VARCHAR2) IS
    -- v_src_info_id NUMBER(12);
    v_bstaff VARCHAR2(50);
  BEGIN
    --备份数据提取
    o_msg := '处理失败';
    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;
    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := modi_staff;
    END IF;

    FOR rec IN (SELECT *
                  FROM crmv2.o_auto_order_src_info a
                 WHERE a.src_type = 'extEffOrder'
                   AND param1 = in_offer_inst_id
                   AND a.status_cd = '1000') LOOP

      UPDATE crmv2.o_auto_order_src_info a
         SET a.begin_date = SYSDATE - 1,
             a.remark     = modi_staff || '--' || modi_reason
       WHERE a.src_info_id = rec.src_info_id;
      COMMIT;
      crmv2.proc_auto_order;
      o_msg := '修改成功';

      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'O_AUTO_ORDER_SRC_INFO',
               rec.src_info_id,
               'begin_date',
               rec.area_id,
               to_char(rec.begin_date, 'yyyymmdd hh:mi:ss'),
               to_char(SYSDATE - 1, 'yyyymmdd hh:mi:ss'),
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.P_MODIFY_OFFER_YQSX',
               v_bstaff,
               rec.area_id,
               modi_reason,
               SYSDATE,
               '延期生效新套餐销售品改成立即生效',
               '订单类'
          FROM dual;
      COMMIT;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END p_modify_offer_yqsx;

  PROCEDURE p_modify_prodinst_area
  \***************************************************************
      FUN NAME: 修改产品档案的区域
      VERSION: V1.0.0
      AUTHOR: zhengzy
      CREATE_DATE: 20130222
      功能说明：修改产品档案的区域
    ****************************************************************\
  (in_prod_inst_id IN NUMBER, --产品实例ID
   in_new_region   IN NUMBER, --新的C4区域
   modi_reason     IN VARCHAR2, --修改备注
   modi_staff      IN VARCHAR2, --修改人
   o_msg           OUT VARCHAR) IS
    v_new_area_nbr VARCHAR2(30);
    v_cnt_area_id  NUMBER(10);
    v_bstaff       VARCHAR2(100);
  BEGIN
    o_msg := '处理失败';

    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;
    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := modi_staff;
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_inst
     WHERE prod_inst_id = in_prod_inst_id
       AND area_id = crmv2.pkg_wh.f_check_modi_staff(modi_staff);

    IF f_check_modi_staff(modi_staff) = 0 THEN
      o_msg := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_msg := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    SELECT area_nbr
      INTO v_new_area_nbr
      FROM crmv2.area_code
     WHERE region_id = in_new_region;

    FOR rec IN (SELECT a.prod_inst_id,
                       b.area_nbr,
                       a.common_region_id,
                       a.area_id
                  FROM crmv2.prod_inst a, crmv2.area_code b
                 WHERE prod_inst_id = in_prod_inst_id
                   AND a.common_region_id = b.region_id) LOOP
      INSERT INTO basejk.intf_region_update_queue@lk_crm2jk_weihu
        (intf_region_update_info_id,
         prod_inst_id,
         area_code,
         exch_id_old,
         exch_id_new,
         area_nbr_old,
         area_nbr_new,
         channel_nbr,
         state,
         state_date,
         create_date,
         update_date,
         deal_num,
         next_deal_time,
         err_msg,
         remark)
        SELECT basejk.seq_intf_region_update_info_id.nextval@lk_crm2jk_weihu intf_region_update_info_id,
               prod_inst_id,
               area_code,
               '' exch_id_old,
               '' exch_id_new,
               rec.area_nbr area_nbr_old,
               v_new_area_nbr,
               '600105A019' channel_nbr,
               '70A' state,
               SYSDATE state_date,
               SYSDATE create_date,
               SYSDATE update_date,
               '0' deal_num,
               SYSDATE + 1 / 24 / 12 next_deal_time,
               '' err_msg,
               modi_reason remark
          FROM crmv2.prod_inst a
         WHERE a.prod_inst_id = rec.prod_inst_id;

      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PROD_INST',
               rec.prod_inst_id,
               'COMMON_REGION_ID',
               rec.area_id,
               rec.common_region_id,
               in_new_region,
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.P_MODIFY_PRODINST_AREA',
               v_bstaff,
               rec.area_id,
               modi_reason,
               SYSDATE,
               '修改产品档案地区',
               '产品类'
          FROM dual;

      COMMIT;
    END LOOP;
    o_msg := '处理成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;
  END p_modify_prodinst_area;
  FUNCTION qry_seq
  \***************************************************************
      FUN NAME: 获取crmv2表的seq的值
      VERSION: V1.0.0
      AUTHOR: zhengzy
      CREATE_DATE: 20130227
      功能说明：获取crmv2表的seq的值
    ****************************************************************\
  (in_table IN VARCHAR2, in_col IN VARCHAR2) RETURN VARCHAR2 IS

    RESULT VARCHAR2(40);
    seq    VARCHAR2(500);

    v_cursorid   INTEGER;
    v_selectstmt VARCHAR2(100);
    v_dummy      NUMBER;
    o_seq_nbr    NUMBER;
    v_out        NUMBER := 0;
    v_table      VARCHAR2(60);
    v_col        VARCHAR2(100);
    v_cnt        NUMBER(12);
  BEGIN
    v_table := upper(in_table);
    v_col   := upper(in_col);
    RESULT  := '';
    --判断是否是主键，且必须是主键是1个字段，非组合主键
    SELECT COUNT(1)
      INTO v_cnt
      FROM dba_tables a, dba_constraints b, dba_cons_columns c
     WHERE a.table_name = b.table_name
       AND a.owner = b.owner
       AND b.constraint_name = c.constraint_name
       AND b.owner = c.owner
       AND a.owner = 'CRMV2'
       AND b.constraint_type = 'P'
       AND c.column_name = v_col
       AND a.table_name = v_table;

    IF v_cnt = 1 THEN
      BEGIN
        SELECT seq_name
          INTO seq
          FROM (SELECT DISTINCT t.table_name, t.seq_name
                  FROM crmv2.sys_class t
                 WHERE t.seq_name IS NOT NULL
                   AND table_name = v_table
                UNION
                SELECT DISTINCT t.his_table_name, t.his_seq_name
                  FROM crmv2.sys_class t
                 WHERE t.his_seq_name IS NOT NULL
                   AND his_table_name = v_table
                UNION
                --一些特殊处理的seq，自己建表
                SELECT DISTINCT t.table_name, t.seq_name
                  FROM itsc_crmv2.sys_class_seq t
                 WHERE t.seq_name IS NOT NULL
                   AND table_name = v_table
                UNION
                SELECT DISTINCT t.his_table_name, t.his_seq_name
                  FROM itsc_crmv2.sys_class_seq t
                 WHERE t.his_seq_name IS NOT NULL
                   AND his_table_name = v_table);

      EXCEPTION
        WHEN OTHERS THEN
          RESULT := SQLERRM;
          RETURN RESULT;
      END;
    ELSIF v_table LIKE '%_EXT' AND v_col = 'EXT_ID' THEN

      seq := 'SEQ_EXT_ID';
    ELSIF v_table = 'ACCOUNT' AND v_col = 'ACCOUNT_NUMBER' THEN
      seq := 'ACCOUNT_NUMBER_SEQ';
    END IF;
    BEGIN

      v_cursorid   := dbms_sql.open_cursor;
      v_selectstmt := 'select CRMV2.' || seq || '.nextval from dual';
      dbms_sql.parse(v_cursorid, v_selectstmt, dbms_sql.v7);
      dbms_sql.define_column(v_cursorid, 1, o_seq_nbr);
      v_dummy := dbms_sql.execute(v_cursorid);
      dbms_output.put_line(v_dummy);
      IF dbms_sql.fetch_rows(v_cursorid) != 0 THEN
        dbms_sql.column_value(v_cursorid, 1, o_seq_nbr);
        v_out := o_seq_nbr;
      END IF;
      dbms_sql.close_cursor(v_cursorid);
      RESULT := v_out;
      RETURN(RESULT);
    EXCEPTION
      WHEN OTHERS THEN
        RESULT := '';
        RETURN(RESULT);
    END;
  END;

  PROCEDURE optionalofferproconlyoffer
  \***************************************************************
          FUN NAME: 到期拆除的可选包手动插入到自动队列表
          VERSION: V1.0.0
          AUTHOR: zhengzy
          CREATE_DATE: 20130301
          功能说明：到期拆除的可选包手动插入到自动队列表
    ****************************************************************\
  (v_prod_offer_inst_id NUMBER, --需到期拆的可选包销售品ID
   modi_reason          IN VARCHAR2, --修改备注
   modi_staff           IN VARCHAR2, --修改人
   o_msg                OUT VARCHAR) IS
    backcount NUMBER;
  BEGIN
    o_msg := '插入自动拆除队列失败';
    FOR optionalofferinst IN (SELECT a.exp_date,
                                     a.eff_date,
                                     a.end_auto,
                                     b.prod_offer_id,
                                     b.exp_proc_method,
                                     c.related_prod_offer_inst_id AS prod_offer_inst_id,
                                     c.rela_prod_offer_inst_id    AS base_offer_inst_id,
                                     g.area_id,
                                     g.region_cd
                                FROM prod_offer_inst     a,
                                     prod_offer          b,
                                     prod_offer_inst_rel c,
                                     prod_offer_inst     g
                               WHERE a.prod_offer_id = b.prod_offer_id
                                 AND a.prod_offer_inst_id =
                                     v_prod_offer_inst_id
                                 AND a.exp_date < add_months(SYSDATE, -1)
                                 AND a.status_cd = '1000'
                                 AND b.offer_type IN ('12', '13')
                                 AND b.offer_sub_type IN ('T04', 'T05')
                                 AND b.exp_proc_method = '2'
                                 AND c.related_prod_offer_inst_id =
                                     a.prod_offer_inst_id
                                 AND c.status_cd = '1000'
                                 AND g.prod_offer_inst_id =
                                     c.rela_prod_offer_inst_id
                                 AND EXISTS
                               (SELECT *
                                        FROM prod_offer_inst_attr
                                       WHERE attr_id = 800002919
                                         AND status_cd = '1000'
                                         AND prod_offer_inst_attr.prod_offer_inst_id =
                                             a.prod_offer_inst_id)
                              UNION
                              SELECT a.exp_date,
                                     a.eff_date,
                                     a.end_auto,
                                     b.prod_offer_id,
                                     b.exp_proc_method,
                                     c.related_prod_offer_inst_id AS prod_offer_inst_id,
                                     c.rela_prod_offer_inst_id    AS base_offer_inst_id,
                                     g.area_id,
                                     g.region_cd
                                FROM prod_offer_inst     a,
                                     prod_offer          b,
                                     prod_offer_inst_rel c,
                                     prod_offer_inst     g
                               WHERE a.prod_offer_id = b.prod_offer_id
                                 AND a.prod_offer_inst_id =
                                     v_prod_offer_inst_id
                                 AND a.exp_date < SYSDATE
                                 AND a.status_cd = '1000'
                                 AND b.offer_type IN ('12', '13')
                                 AND b.offer_sub_type IN ('T04', 'T05')
                                 AND b.exp_proc_method = '2'
                                 AND c.related_prod_offer_inst_id =
                                     a.prod_offer_inst_id
                                 AND c.status_cd = '1000'
                                 AND g.prod_offer_inst_id =
                                     c.rela_prod_offer_inst_id
                                 AND NOT EXISTS
                               (SELECT *
                                        FROM prod_offer_inst_attr
                                       WHERE attr_id = 800002919
                                         AND status_cd = '1000'
                                         AND prod_offer_inst_attr.prod_offer_inst_id =
                                             a.prod_offer_inst_id)) LOOP
      backcount := crmv2.pkg_proc_auto_h.optionalautoprocqueue(optionalofferinst.prod_offer_id,
                                                               optionalofferinst.prod_offer_inst_id,
                                                               optionalofferinst.base_offer_inst_id,
                                                               optionalofferinst.exp_proc_method,
                                                               0,
                                                               optionalofferinst.area_id,
                                                               optionalofferinst.region_cd,
                                                               optionalofferinst.eff_date,
                                                               optionalofferinst.exp_date,
                                                               1);
    END LOOP;

    o_msg := modi_staff || '因' || modi_reason || '插入自动拆除队列成功';
    --exception

  EXCEPTION
    WHEN OTHERS THEN
      o_msg := modi_staff || '因' || modi_reason || '插入自动拆除队列失败';

  END optionalofferproconlyoffer;

  PROCEDURE release_termkey_only_res
  \***************************************************************
      FUN NAME: 释放没有占用记录的实物数据
      VERSION: V1.0.0
      AUTHOR: zhengzy
      CREATE_DATE: 20130304
      功能说明：释放没有占用记录的实物数据
    ****************************************************************\
  (in_termkey  IN VARCHAR2, --实物串号
   modi_staff  IN VARCHAR2, --修改人
   modi_reason IN VARCHAR2, --修改备注
   o_msg       OUT VARCHAR2) IS
    v_mkt_reso_id crmv1.mkt_resource.mkt_reso_id%TYPE;
    v_bstaff      VARCHAR2(50);
  BEGIN

    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;
    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := modi_staff;
    END IF;

    o_msg := '修改失败';
    --校验输入的工号正确性
    IF crmv2.pkg_wh.f_check_modi_staff(modi_staff) > 0 THEN

      SELECT a.mkt_reso_id
        INTO v_mkt_reso_id
        FROM crmv1.mkt_resource a
       WHERE a.mkt_reso_key = in_termkey
         AND (EXISTS
              (SELECT 1
                 FROM crmv1.mkt_occupy c, crmv2.prod_inst d
                WHERE a.mkt_reso_id = c.mkt_reso_id
                  AND c.buy_prod_id = d.prod_inst_id
                  AND d.acc_nbr IS NULL
                  AND d.status_cd = '130000') OR
              (NOT EXISTS (SELECT 1
                             FROM crmv1.mkt_occupy b
                            WHERE a.mkt_reso_id = b.mkt_reso_id)));

      FOR rec IN (SELECT *
                    FROM crmv1.mkt_resource
                   WHERE mkt_reso_id = v_mkt_reso_id) LOOP

        UPDATE crmv1.mkt_resource a
           SET a.state = '70A', a.remarks = a.remarks || modi_reason
         WHERE a.mkt_reso_id = rec.mkt_reso_id;
        o_msg := '修改成功';

        INSERT INTO itsc_crmv2.crm_wh_bak
          (tal_name,
           key_id,
           modi_column,
           modi_area,
           old_value,
           new_value,
           modi_action,
           modi_spec,
           offer_spec,
           proce,
           modi_staff,
           staff_area,
           modi_reason,
           modi_time,
           reason,
           modi_type)
          SELECT 'MKT_RESOURCE',
                 v_mkt_reso_id,
                 'STATE',
                 '',
                 rec.state,
                 '70A',
                 'MODIFY',
                 rec.mkt_reso_spec_id,
                 '',
                 'CRMV2.PKG_WH.RELEASE_TERMKEY_ONLY_RES',
                 v_bstaff,
                 crmv2.pkg_wh.f_check_modi_staff(modi_staff),
                 modi_reason,
                 SYSDATE,
                 '释放没有占用记录的实物',
                 '实物类'
            FROM dual;
      END LOOP;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END;

  PROCEDURE p_add_prod_offer_only
  \***************************************************************
      FUN NAME:通过自动队列增加销售品实例
      VERSION: V1.0.0
      AUTHOR: ZENGX
      CREATE_DATE: 20130306
      功能说明：通过自动队列增加销售品实例
    ****************************************************************\
  (in_prod_inst_id  IN NUMBER, --产品实例ID
   in_prod_offer_id IN NUMBER, --销售品规格
   modi_reason      IN VARCHAR2, --修改备注
   modi_staff       IN VARCHAR2, --修改人
   o_msg            OUT VARCHAR) IS
    v_a NUMBER(12) := 0;
    v_b NUMBER(12) := 0;
  BEGIN
    SELECT crmv2.seq_o_auto_proc_queue_id.nextval INTO v_a FROM dual;
    SELECT crmv2.seq_o_auto_proc_queue_id.nextval INTO v_b FROM dual;
    INSERT INTO crmv2.o_auto_proc_queue
      (queue_id,
       super_queue_id,
       priority,
       src_type,
       src_inst_id,
       src_action,
       proc_type,
       cust_order_id,
       order_item_id,
       remark,
       queue_desc,
       EXTEND,
       eff_date,
       area_id,
       region_cd,
       create_staff,
       create_date,
       status_cd,
       status_date,
       update_staff,
       update_date,
       cust_id,
       begin_date)
      SELECT v_a,
             0,
             NULL,
             'ProdOffer',
             in_prod_offer_id,
             '3010100000',
             'MOD',
             NULL,
             NULL,
             modi_staff || modi_reason,
             NULL,
             NULL,
             NULL,
             a.area_id,
             a.common_region_id,
             a.create_staff,
             SYSDATE,
             '200098',
             SYSDATE,
             a.create_staff,
             SYSDATE,
             a.owner_cust_id,
             NULL
        FROM crmv2.prod_inst a
       WHERE prod_inst_id = in_prod_inst_id;

    INSERT INTO crmv2.o_auto_proc_queue
      (queue_id,
       super_queue_id,
       priority,
       src_type,
       src_inst_id,
       src_action,
       proc_type,
       cust_order_id,
       order_item_id,
       remark,
       queue_desc,
       EXTEND,
       eff_date,
       area_id,
       region_cd,
       create_staff,
       create_date,
       status_cd,
       status_date,
       update_staff,
       update_date,
       cust_id,
       begin_date)
      SELECT v_b,
             v_a,
             NULL,
             'ProdInst',
             a.prod_inst_id,
             '3020500000',
             NULL,
             NULL,
             NULL,
             modi_staff || modi_reason,
             NULL,
             NULL,
             NULL,
             a.area_id,
             a.common_region_id,
             a.create_staff,
             SYSDATE,
             '200098',
             SYSDATE,
             a.create_staff,
             SYSDATE,
             a.owner_cust_id,
             NULL
        FROM crmv2.prod_inst a
       WHERE prod_inst_id = in_prod_inst_id;

    INSERT INTO crmv2.proc_queue_attr
      (attr_id,
       queue_id,
       super_attr_id,
       obj_type,
       obj_spec,
       obj_id,
       proc_type,
       remark,
       area_id,
       region_cd,
       create_staff,
       create_date,
       status_cd,
       status_date,
       update_staff,
       update_date,
       obj_value,
       valid_bean,
       valid_param1,
       valid_param2)
      SELECT crmv2.seq_proc_queue_attr_id.nextval,
             v_b,
             NULL,
             'DEFOFFER',
             NULL,
             NULL,
             'INSERT',
             modi_staff || modi_reason,
             a.area_id,
             a.common_region_id,
             a.create_staff,
             SYSDATE,
             '1299',
             SYSDATE,
             a.create_staff,
             SYSDATE,
             NULL,
             NULL,
             NULL,
             NULL
        FROM crmv2.prod_inst a
       WHERE prod_inst_id = in_prod_inst_id;
    COMMIT;
    o_msg := '插入队列成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END;
  PROCEDURE p_modi_prod_acc_nbr
  \***************************************************************
      FUN NAME: 修改销售品属性的属性值
      VERSION: V1.0.0
      AUTHOR: ZHENGZY
      CREATE_DATE: 20130206
      功能说明：修改销售品属性的属性值
      产品实例ID，新业务号，新帐号，修改原因，修改人。
    ****************************************************************\
  (in_prod_inst_id IN NUMBER, --产品实例ID
   in_new_acc_nbr  IN VARCHAR2, --新业务号
   in_new_account  IN VARCHAR2, --新帐号
   modi_staff      IN VARCHAR2, --修改人
   modi_reason     IN VARCHAR2, --修改原因
   o_msg           OUT VARCHAR2) AS
    v_id          NUMBER(20);
    v_cnt_area_id NUMBER(10);
  BEGIN

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_inst
     WHERE prod_inst_id = in_prod_inst_id
       AND area_id = f_check_modi_staff(modi_staff);

    IF f_check_modi_staff(modi_staff) = 0 THEN
      o_msg := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_msg := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    UPDATE crmv2.prod_inst_acc_nbr
       SET acc_nbr = in_new_acc_nbr, update_date = SYSDATE
     WHERE prod_inst_id = in_prod_inst_id
       AND status_cd = '1000';
    COMMIT;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'PROD_INST',
             a.prod_inst_id,
             'ACC_NBR',
             a.area_id,
             a.acc_nbr,
             in_new_acc_nbr,
             'MODIFY',
             a.product_id,
             '',
             'CRMV2.PKG_WH.P_MODI_PROD_ACC_NBR',
             modi_staff,
             f_check_modi_staff(modi_staff),
             modi_reason,
             SYSDATE,
             '修改产品实例账号',
             '产品类'
        FROM crmv2.prod_inst a
       WHERE prod_inst_id = in_prod_inst_id
         AND status_cd = '100000';

    UPDATE crmv2.prod_inst
       SET acc_nbr     = in_new_acc_nbr,
           account     = in_new_account,
           update_date = SYSDATE
     WHERE prod_inst_id = in_prod_inst_id
       AND status_cd = '100000';
    COMMIT;
    SELECT prod_inst_attr_id
      INTO v_id
      FROM crmv2.prod_inst_attr
     WHERE prod_inst_id = in_prod_inst_id
       AND attr_id = 800000282
       AND status_cd = '1000';

    UPDATE crmv2.prod_inst_attr
       SET attr_value = in_new_account, update_date = SYSDATE
     WHERE prod_inst_id = in_prod_inst_id
       AND attr_id = 800000282
       AND status_cd = '1000';
    COMMIT;

    itsc_crmv2.new_p_ins_billing_update('PROD_INST', 'PROD_INST_ID',
                                        in_prod_inst_id, modi_reason,
                                        modi_staff);
    itsc_crmv2.new_p_ins_billing_update('PROD_INST_ATTR',
                                        'PROD_INST_ATTR_ID', v_id,
                                        modi_reason, modi_staff);
    o_msg := '修改成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END;

  PROCEDURE p_finish_customer_contact
  \***************************************************************
      FUN NAME: 手工归档协办单
      VERSION: V1.0.0
      AUTHOR: ZHENGZY
      CREATE_DATE: 20130318
      功能说明：手工归档协办单
    ****************************************************************\
  (in_agree_id IN VARCHAR2,
   modi_staff  IN VARCHAR2,
   modi_reason IN VARCHAR2,
   o_msg       OUT VARCHAR2) AS
    v_cont_id NUMBER;
  BEGIN
    o_msg := '处理失败';
    SELECT cont_id
      INTO v_cont_id
      FROM crmv1.customer_contact
     WHERE agree_id = TRIM(in_agree_id);
    INSERT INTO crmv1.f_task_record_his
      (record_id,
       obj,
       order_id,
       state_code,
       event,
       task_spec_id,
       duty_staff,
       state,
       create_date,
       assign_date,
       complete_date,
       his_id,
       flow_task_spec_id,
       duty_organ,
       active_date,
       overtime_date,
       complete_type,
       proc_result,
       remark,
       op_staff,
       rec_id,
       duty_staff_type,
       assign_opinion,
       task_is_customize,
       task_nodeid,
       task_type,
       task_overtime_unit,
       task_overtime,
       duty_post,
       parent_record_id,
       real_modify_date,
       op_organ,
       pre_sub_staff,
       task_code,
       pause_overtime,
       interface_code,
       interface_type,
       assign_result,
       other_staff_name,
       other_info,
       last_record_id,
       duty_area,
       op_area)
      SELECT record_id,
             obj,
             order_id,
             state_code,
             event,
             task_spec_id,
             duty_staff,
             state,
             create_date,
             assign_date,
             complete_date,
             crmv1.f_task_record_his_id_seq.nextval,
             flow_task_spec_id,
             duty_organ,
             active_date,
             overtime_date,
             complete_type,
             proc_result,
             modi_staff || '因' || modi_reason || '于' ||
             to_char(SYSDATE, 'yyyy-mm-dd') || '手工归档' remark,
             op_staff,
             rec_id,
             duty_staff_type,
             assign_opinion,
             task_is_customize,
             task_nodeid,
             task_type,
             task_overtime_unit,
             task_overtime,
             duty_post,
             parent_record_id,
             real_modify_date,
             op_organ,
             pre_sub_staff,
             task_code,
             pause_overtime,
             interface_code,
             interface_type,
             assign_result,
             other_staff_name,
             other_info,
             last_record_id,
             duty_area,
             op_area
        FROM crmv1.f_task_record a
       WHERE a.order_id = v_cont_id
         AND a.obj = 'custtouch';

    COMMIT;

    DELETE FROM crmv1.f_task_record a
     WHERE a.order_id = v_cont_id
       AND a.obj = 'custtouch';

    COMMIT;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'CUSTOMER_CONTACT',
             v_cont_id,
             '',
             (SELECT up_region_id
                FROM crmv2.common_region
               WHERE common_region_id = a.region),
             '',
             '',
             'DELETE',
             '',
             '',
             'CRMV2.PKG_WH.P_FINISH_CUSTOMER_CONTACT',
             modi_staff,
             f_check_modi_staff(modi_staff),
             modi_reason,
             SYSDATE,
             '手工归档协办单',
             '实物类'
        FROM crmv1.customer_contact a
       WHERE a.cont_id = v_cont_id;

    INSERT INTO crmv1.customer_contact_his
      (his_id,
       cont_id,
       create_date,
       cont_type,
       modify_date,
       complete_date,
       state,
       remark,
       flow_state,
       cust_id,
       region,
       SOURCE,
       in_his_date,
       rela_serial,
       seq,
       staff_id,
       agree_id,
       call_area_code,
       obstacle_area_code,
       fee_type,
       term_type,
       cont_level,
       addr,
       proc_dept,
       proc_type,
       overtime,
       topic,
       content,
       proc_advise,
       link_name,
       reply_date,
       link_content,
       reply_mode,
       real_modify_date,
       area_code,
       call_servnbr,
       obstacle_servnbr,
       proc_mode,
       dispose_dept,
       cases,
       checked,
       op_staff,
       op_team,
       op_type,
       collection_type,
       replyinfo_type,
       modify_cause,
       first_assign_te,
       net,
       za_agree_id,
       proc_area_codes,
       appeal_order_type,
       obstacle_region,
       is_responses,
       check_dept,
       responses_typ,
       responses_code,
       responses_phone,
       prod_attr,
       obstacle_agree_id,
       vip_level)
      SELECT crmv1.customer_contact_his_id_seq.nextval,
             cont_id,
             create_date,
             cont_type,
             modify_date,
             SYSDATE,
             '70X',
             modi_staff || '因' || modi_reason || '于' ||
             to_char(SYSDATE, 'yyyy-mm-dd') || '手工归档' remark,
             flow_state,
             cust_id,
             region,
             SOURCE,
             SYSDATE,
             '',
             NULL,
             '',
             agree_id,
             call_area_code,
             obstacle_area_code,
             fee_type,
             term_type,
             cont_level,
             addr,
             proc_dept,
             proc_type,
             overtime,
             topic,
             content,
             proc_advise,
             link_name,
             reply_date,
             link_content,
             reply_mode,
             real_modify_date,
             area_code,
             call_servnbr,
             obstacle_servnbr,
             proc_mode,
             dispose_dept,
             cases,
             checked,
             '',
             '',
             '',
             collection_type,
             replyinfo_type,
             '',
             first_assign_te,
             net,
             za_agree_id,
             proc_area_codes,
             appeal_order_type,
             obstacle_region,
             is_responses,
             check_dept,
             responses_typ,
             responses_code,
             responses_phone,
             prod_attr,
             obstacle_agree_id,
             vip_level
        FROM crmv1.customer_contact a
       WHERE a.cont_id = v_cont_id;
    COMMIT;
    DELETE FROM crmv1.customer_contact a WHERE a.cont_id = v_cont_id;
    COMMIT;

    INSERT INTO crmv1.customer_contact_fea_his
      (his_id,
       param1,
       cont_id,
       create_date,
       state,
       parent_id,
       modify_date,
       fea_id,
       param2,
       op_mode,
       SOURCE,
       modify_cause,
       fea_spec_id,
       in_his_date,
       rela_serial,
       seq,
       real_modify_date)
      SELECT crmv1.ct_fea_his_id_seq.nextval,
             param1,
             cont_id,
             create_date,
             state,
             parent_id,
             SYSDATE,
             fea_id,
             param2,
             op_mode,
             SOURCE,
             modify_cause,
             fea_id,
             SYSDATE,
             '',
             '',
             SYSDATE
        FROM crmv1.customer_contact_fea v
       WHERE v.cont_id = v_cont_id;
    COMMIT;
    DELETE FROM crmv1.customer_contact_fea v WHERE v.cont_id = v_cont_id;
    COMMIT;

    o_msg := '处理成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END;

  FUNCTION qry_cust_number
  \***************************************************************
      FUN NAME:获取客户统一标示码
      VERSION: V1.0.0
      AUTHOR: ZENGX
      CREATE_DATE: 20130320
      功能说明：获取客户统一标示码
    ****************************************************************\
  (in_area_code IN VARCHAR2) RETURN VARCHAR2 IS
    RESULT      VARCHAR2(50);
    v_area_code NUMBER(10) := to_number(in_area_code);
    v_str       VARCHAR2(100);
    v_sql_name  VARCHAR2(100);
    v_sql_temp  VARCHAR2(100);
  BEGIN
    IF v_area_code BETWEEN '591' AND '599' THEN
      v_sql_name := 'seq_' || v_area_code || '_cust_number';
      v_str      := 'SELECT crmv2.' || v_sql_name || '.nextval  from dual';
      EXECUTE IMMEDIATE v_str
        INTO v_sql_temp;
      SELECT '2' || v_area_code || lpad(v_sql_temp, 8, 0) || '0000'
        INTO RESULT
        FROM dual;
    END IF;
    RETURN(RESULT);
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;

  PROCEDURE p_modi_batch_order
  \***************************************************************
      FUN NAME: 批量单分解异常，修改批量单状态以及采集数据状态使批量主单重新分解
      VERSION: V1.0.0
      AUTHOR: ZHENGZY
      CREATE_DATE: 20130321
      功能说明：批量单分解异常，修改批量单状态以及采集数据状态使批量主单重新分解
    ****************************************************************\
  (in_cust_so_number IN VARCHAR2,
   modi_staff        IN VARCHAR2,
   modi_reason       IN VARCHAR2,
   o_msg             OUT VARCHAR2) IS
    v_cust_order_id NUMBER(10);
  BEGIN

    SELECT cust_order_id
      INTO v_cust_order_id
      FROM crmv2.customer_order co
     WHERE co.cust_so_number = in_cust_so_number;

    --1.获取记录错误信息的order_data_id
    FOR rec IN (SELECT od.order_data_id
                  FROM crmv2.batch_order_rel r, crmv2.batch_order_data od
                 WHERE r.cust_order_id = v_cust_order_id
                   AND r.batch_order_id = od.batch_order_id
                   AND r.data_type = '50'
                   AND od.remark IS NOT NULL
                   AND od.status = '201200') LOOP
      --2.用第一步获取到的order_data_id 修改子单采集信息的状态
      UPDATE crmv2.batch_order_data
         SET remark = '', status = '401700'
       WHERE order_data_id = rec.order_data_id;
      COMMIT;
    END LOOP;

    --3.修改批量主单的订单与订单项的状态
    UPDATE crmv2.customer_order co
       SET co.status_cd = '200098', co.update_date = SYSDATE
     WHERE co.cust_order_id = v_cust_order_id;

    UPDATE crmv2.order_item oi
       SET oi.status_cd = '200000', oi.update_date = SYSDATE
     WHERE oi.cust_order_id = v_cust_order_id;
    COMMIT;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'CUSTOMER_ORDER',
             a.cust_order_id,
             'STATUS_CD',
             a.area_id,
             a.status_cd,
             '200098',
             'MODIFY',
             '',
             '',
             'CRMV2.PKG_WH.P_MODI_BATCH_ORDER',
             modi_staff,
             f_check_modi_staff(modi_staff),
             modi_reason,
             SYSDATE,
             '批量单分解异常，修改批量单状态以及采集数据状态使批量主单重新分解',
             '订单类'
        FROM crmv2.customer_order a
       WHERE a.cust_order_id = v_cust_order_id;
    COMMIT;
    o_msg := '修改成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END;

  PROCEDURE updatebatchbyprodid(v_prod_inst_id IN NUMBER,
                                modi_staff     IN VARCHAR2,
                                modi_reason    IN VARCHAR2,
                                str_msg        OUT VARCHAR) IS
    \**********************************
    根据产品标识，对增量接口相关的表信息全部送批量接口

    **********************************\

  BEGIN
    DECLARE
      \*变量定义*\
      i NUMBER(2) := 0;
    BEGIN

      str_msg := '处理失败!';

      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        \*产品表*\
        new_p_ins_billing_update('prod_inst', 'prod_inst_id',
                                 v_prod_inst_id, '全量上载计费' || modi_reason,
                                 modi_staff, str_msg);
      END;
      i := 1;
      \*产品属性*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.prod_inst_attr
                     WHERE prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_inst_attr', 'prod_inst_attr_id',
                                   rec.prod_inst_attr_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;
      i := 2;
      \*产品关联的功能类产品属性*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT pa.*
                      FROM crmv2.prod_inst      b,
                           crmv2.prod_inst_rel  c,
                           crmv2.prod_inst_attr pa
                     WHERE b.prod_inst_id = c.prod_inst_a_id
                       AND c.relation_type_cd = 100600
                       AND c.prod_inst_z_id = pa.prod_inst_id
                       AND b.prod_inst_id = v_prod_inst_id
                       AND pa.attr_id IN
                           (SELECT attr_id
                              FROM ofcs_cfg_rel.v_pr_tpr_prod_attr_spec@lk_fj_jfin)) LOOP
          new_p_ins_billing_update('prod_inst_attr', 'prod_inst_attr_id',
                                   rec.prod_inst_attr_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;
      i := 3;
      \*产品关联*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.prod_inst_rel
                     WHERE prod_inst_a_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_inst_rel', 'prod_inst_rel_id',
                                   rec.prod_inst_rel_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*产品关联*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.prod_inst_rel
                     WHERE prod_inst_z_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_inst_rel', 'prod_inst_rel_id',
                                   rec.prod_inst_rel_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*产品销售品关联*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.offer_prod_inst_rel
                     WHERE prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('offer_prod_inst_rel',
                                   'offer_prod_inst_rel_id',
                                   rec.offer_prod_inst_rel_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*销售品*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT a.*
                      FROM crmv2.offer_prod_inst_rel a
                     WHERE a.prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_offer_inst', 'prod_offer_inst_id',
                                   rec.prod_offer_inst_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;
      \*主销售品属性*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT c.*
                      FROM crmv2.offer_prod_inst_rel a,
                           -- crmv2.prod_offer_inst_rel  b,
                           crmv2.prod_offer_inst_attr c
                     WHERE a.prod_offer_inst_id = c.prod_offer_inst_id
                       AND a.prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_offer_inst_attr',
                                   'prod_offer_inst_attr_id',
                                   rec.prod_offer_inst_attr_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*销售品*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT c.*
                      FROM crmv2.offer_prod_inst_rel a,
                           crmv2.prod_offer_inst_rel c
                     WHERE c.rela_prod_offer_inst_id = a.prod_offer_inst_id
                       AND a.prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_offer_inst', 'prod_offer_inst_id',
                                   rec.related_prod_offer_inst_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;
      \*产品关联的功能类销售品*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT d.prod_offer_inst_id, a.offer_prod_inst_rel_id
                      FROM crmv2.prod_inst           b,
                           crmv2.prod_inst_rel       c,
                           crmv2.offer_prod_inst_rel a,
                           crmv2.prod_offer_inst     d,
                           crmv2.prod_offer          f
                     WHERE b.prod_inst_id = c.prod_inst_a_id
                       AND c.relation_type_cd = 100600
                       AND c.prod_inst_z_id = a.prod_inst_id
                       AND a.prod_offer_inst_id = d.prod_offer_inst_id
                       AND d.prod_offer_id = f.prod_offer_id
                       AND b.prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_offer_inst', 'prod_offer_inst_id',
                                   rec.prod_offer_inst_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
          new_p_ins_billing_update('offer_prod_inst_rel',
                                   'offer_prod_inst_rel_ID',
                                   rec.offer_prod_inst_rel_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
          FOR rec1 IN (SELECT *
                         FROM prod_offer_inst_attr
                        WHERE prod_offer_inst_id = rec.prod_offer_inst_id) LOOP
            new_p_ins_billing_update('prod_offer_inst_attr',
                                     'prod_offer_inst_attr_id',
                                     rec1.prod_offer_inst_attr_id,
                                     '全量上载计费' || modi_reason, modi_staff,
                                     str_msg);
          END LOOP;
        END LOOP;
      END;
      \*销售品关联*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT c.*
                      FROM crmv2.offer_prod_inst_rel a,
                           crmv2.prod_offer_inst_rel c
                     WHERE c.rela_prod_offer_inst_id = a.prod_offer_inst_id
                       AND a.prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_offer_inst_rel',
                                   'prod_offer_inst_rel_id',
                                   rec.prod_offer_inst_rel_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*销售品属性*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT c.*
                      FROM crmv2.offer_prod_inst_rel  a,
                           crmv2.prod_offer_inst_rel  b,
                           crmv2.prod_offer_inst_attr c
                     WHERE b.rela_prod_offer_inst_id = a.prod_offer_inst_id
                       AND a.prod_inst_id = v_prod_inst_id
                       AND b.related_prod_offer_inst_id =
                           c.prod_offer_inst_id) LOOP
          new_p_ins_billing_update('prod_offer_inst_attr',
                                   'prod_offer_inst_attr_id',
                                   rec.prod_offer_inst_attr_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;
      \*账务关系*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.prod_inst_acct
                     WHERE prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_inst_acct', 'prod_inst_acct_id',
                                   rec.prod_inst_acct_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*电信账户*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.prod_inst_acct
                     WHERE prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('account', 'account_id', rec.account_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*客户账户*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT b.*
                      FROM crmv2.prod_inst_acct a, crmv2.payment_plan b
                     WHERE prod_inst_id = v_prod_inst_id
                       AND a.account_id = b.account_id) LOOP
          new_p_ins_billing_update('payment_plan', 'payment_plan',
                                   rec.payment_plan, '全量上载计费' || modi_reason,
                                   modi_staff, str_msg);
        END LOOP;
      END;

      \*客户*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.prod_inst
                     WHERE prod_inst_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('cust', 'cust_id', rec.owner_cust_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*参与人*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT b.*
                      FROM crmv2.prod_inst a, crmv2.cust b
                     WHERE prod_inst_id = v_prod_inst_id
                       AND a.owner_cust_id = b.cust_id) LOOP
          new_p_ins_billing_update('party', 'party_id', rec.party_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*产品关联的PROD_INST_ID--YANGYX*\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT prod_inst_z_id
                      FROM crmv2.prod_inst_rel
                     WHERE prod_inst_a_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_inst', 'prod_inst_id',
                                   rec.prod_inst_z_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;

      \*产品关联PROD_INST_ID--YANGYX**\
      DECLARE
        v_result VARCHAR2(500);
      BEGIN
        FOR rec IN (SELECT *
                      FROM crmv2.prod_inst_rel
                     WHERE prod_inst_z_id = v_prod_inst_id) LOOP
          new_p_ins_billing_update('prod_inst', 'prod_inst_id',
                                   rec.prod_inst_a_id,
                                   '全量上载计费' || modi_reason, modi_staff,
                                   str_msg);
        END LOOP;
      END;
      str_msg := '处理成功!';
      \*  <<k>>
      NULL;*\
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := i || '上载失败!';
        NULL;
    END;

  END;

  --- --修改属性时间
  --2013.4.1 lud
  PROCEDURE change_attr_date(in_table    IN VARCHAR2,
                             in_key      IN VARCHAR2,
                             in_type     IN VARCHAR2,
                             new_eff     IN VARCHAR2, -- 类型 yyyy-mm-dd
                             new_exp     IN VARCHAR2, -- 类型 yyyy-mm-dd
                             modi_staff  IN VARCHAR2,
                             modi_reason IN VARCHAR2,
                             o_msg       OUT VARCHAR2) IS
    v_table       VARCHAR2(100) := upper(TRIM(in_table));
    v_type        VARCHAR2(100) := upper(TRIM(in_type));
    v_eff         DATE;
    v_exp         DATE;
    v_bstaff      VARCHAR2(100) := TRIM(modi_staff);
    v_cnt_area_id NUMBER(10);
    v_oldvalue    VARCHAR2(100);
    v_newvalue    VARCHAR2(100);
    v_spec        NUMBER(10);
    v_area        NUMBER(10);
    v_oldeff      DATE;
    v_oldexp      DATE;
    v_id          NUMBER(10);
    v_context     VARCHAR2(1000);
    v_name        VARCHAR2(100);
    v_a           VARCHAR2(100);
    v_b           VARCHAR2(100);
    v_his_key_id  NUMBER(10);
  BEGIN
    --表判断

    IF v_table != 'PROD_INST_ATTR' AND v_table != 'PROD_OFFER_INST_ATTR' AND
       v_table != 'PROD_INST_ATTR_HIS' AND
       v_table != 'PROD_OFFER_INST_ATTR_HIS' THEN
      o_msg := '过程只修改PROD_INST_ATTR和PROD_OFFER_INST_ATTR表记录';
      RETURN;
    END IF;
    -- 参数判断
    IF v_type = 'EFF' AND new_eff IS NULL THEN
      o_msg := '生效时间不能为空';
      RETURN;
    ELSIF v_type = 'EXP' AND new_exp IS NULL THEN
      o_msg := '失效时间不能为空';
      RETURN;
    ELSIF v_type = 'ALL' AND (new_eff IS NULL OR new_exp IS NULL) THEN
      o_msg := '生失效时间不能为空';
      RETURN;
    END IF;

    --员工地区判断
    SELECT sys_context('USERENV', 'SESSION_USER') INTO v_bstaff FROM dual;

    IF v_bstaff = 'CRMV2' THEN
      v_bstaff := modi_staff;

    END IF;

    IF v_table = 'PROD_INST_ATTR' THEN
      SELECT COUNT(1)
        INTO v_cnt_area_id
        FROM crmv2.prod_inst_attr
       WHERE prod_inst_attr_id = in_key
         AND area_id = crmv2.pkg_wh.f_check_modi_staff(modi_staff);

    ELSIF v_table = 'PROD_INST_ATTR_HIS' THEN
      SELECT COUNT(1)
        INTO v_cnt_area_id
        FROM crmv2.prod_inst_attr_his
       WHERE his_id = in_key
         AND area_id = crmv2.pkg_wh.f_check_modi_staff(modi_staff);

    ELSIF v_table = 'PROD_OFFER_INST_ATTR_HIS' THEN
      SELECT COUNT(1)
        INTO v_cnt_area_id
        FROM crmv2.prod_offer_inst_attr_his
       WHERE his_id = in_key
         AND area_id = crmv2.pkg_wh.f_check_modi_staff(modi_staff);
    ELSE
      SELECT COUNT(1)
        INTO v_cnt_area_id
        FROM crmv2.prod_offer_inst_attr
       WHERE prod_offer_inst_attr_id = in_key
         AND area_id = crmv2.pkg_wh.f_check_modi_staff(modi_staff);
    END IF;

    IF crmv2.pkg_wh.f_check_modi_staff(modi_staff) = 0 THEN
      o_msg := '修改人不准确';
      RETURN;
    ELSIF crmv2.pkg_wh.f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_msg := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    v_eff := to_date(TRIM(new_eff), 'YYYY-MM-DD');
    v_exp := to_date(TRIM(new_exp), 'YYYY-MM-DD');
    ---prod_offer_inst_attr
    IF v_table = 'PROD_OFFER_INST_ATTR' THEN

      BEGIN
        SELECT a.eff_date, a.exp_date, a.area_id, a.attr_id
          INTO v_oldeff, v_oldexp, v_area, v_spec
          FROM crmv2.prod_offer_inst_attr a
         WHERE a.prod_offer_inst_attr_id = in_key;
      EXCEPTION
        WHEN OTHERS THEN
          o_msg := 'ID值在数据中存储有误';
          RETURN;

      END;

      IF v_type = 'EFF' THEN
        UPDATE crmv2.prod_offer_inst_attr
           SET create_date = v_eff, status_date = v_eff, eff_date = v_eff
         WHERE prod_offer_inst_attr_id = in_key;

        v_oldvalue := to_char(v_oldeff, 'yyyymmdd');
        v_newvalue := to_char(v_eff, 'yyyymmdd');
      ELSIF v_type = 'EXP' THEN
        UPDATE crmv2.prod_offer_inst_attr
           SET exp_date = v_exp
         WHERE prod_offer_inst_attr_id = in_key;

        v_oldvalue := to_char(v_oldexp, 'yyyymmdd');
        v_newvalue := to_char(v_exp, 'yyyymmdd');
      ELSIF v_type = 'ALL' THEN
        UPDATE crmv2.prod_offer_inst_attr
           SET create_date = v_eff,
               status_date = v_eff,
               eff_date    = v_eff,
               exp_date    = v_exp
         WHERE prod_offer_inst_attr_id = in_key;

        v_oldvalue := to_char(v_oldeff, 'yyyymmdd') || '/' ||
                      to_char(v_oldexp, 'yyyymmdd');
        v_newvalue := to_char(v_eff, 'yyyymmdd') || '/' ||
                      to_char(v_exp, 'yyyymmdd');

      END IF;

      itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_ATTR',
                                          'PROD_OFFER_iNST_ATTR_ID', in_key,
                                          modi_reason, v_bstaff);

    ELSIF v_table = 'PROD_OFFER_INST_ATTR_HIS' THEN

      BEGIN
        SELECT a.eff_date,
               a.exp_date,
               a.area_id,
               a.attr_id,
               a.prod_offer_inst_attr_id
          INTO v_oldeff, v_oldexp, v_area, v_spec, v_his_key_id
          FROM crmv2.prod_offer_inst_attr_his a
         WHERE a.his_id = in_key;
      EXCEPTION
        WHEN OTHERS THEN
          o_msg := 'ID值在数据中存储有误';
          RETURN;

      END;

      IF v_type = 'EFF' THEN
        UPDATE crmv2.prod_offer_inst_attr_his
           SET create_date     = v_eff,
               rec_update_date = v_eff,
               eff_date        = v_eff
         WHERE his_id = in_key
           AND status_cd IN ('1000', '1100');

        v_oldvalue := to_char(v_oldeff, 'yyyymmdd');
        v_newvalue := to_char(v_eff, 'yyyymmdd');
      ELSIF v_type = 'EXP' THEN

        UPDATE crmv2.prod_offer_inst_attr_his
           SET exp_date = v_exp
         WHERE his_id = in_key
           AND status_cd IN ('1000', '1100');

        v_oldvalue := to_char(v_oldexp, 'yyyymmdd');
        v_newvalue := to_char(v_exp, 'yyyymmdd');
      ELSIF v_type = 'ALL' THEN

        UPDATE crmv2.prod_offer_inst_attr_his
           SET create_date     = v_eff,
               rec_update_date = v_eff,
               eff_date        = v_eff,
               exp_date        = v_exp
         WHERE his_id = in_key
           AND status_cd IN ('1000', '1100');

        v_oldvalue := to_char(v_oldeff, 'yyyymmdd') || '/' ||
                      to_char(v_oldexp, 'yyyymmdd');
        v_newvalue := to_char(v_eff, 'yyyymmdd') || '/' ||
                      to_char(v_exp, 'yyyymmdd');

      END IF;

      itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST_ATTR',
                                          'PROD_OFFER_iNST_ATTR_ID',
                                          v_his_key_id, modi_reason,
                                          v_bstaff);
    ELSIF v_table = 'PROD_INST_ATTR' THEN

      BEGIN
        SELECT a.eff_date, a.exp_date, a.area_id, a.attr_id
          INTO v_oldeff, v_oldexp, v_area, v_spec
          FROM crmv2.prod_inst_attr a
         WHERE a.prod_inst_attr_id = in_key;
      EXCEPTION
        WHEN OTHERS THEN
          o_msg := 'ID值在数据中存储有误';
          RETURN;

      END;

      IF v_type = 'EFF' THEN
        UPDATE crmv2.prod_inst_attr
           SET create_date = v_eff, status_date = v_eff, eff_date = v_eff
         WHERE prod_inst_attr_id = in_key;

        v_oldvalue := to_char(v_oldeff, 'yyyymmdd');
        v_newvalue := to_char(v_eff, 'yyyymmdd');
      ELSIF v_type = 'EXP' THEN
        UPDATE crmv2.prod_inst_attr
           SET exp_date = v_exp
         WHERE prod_inst_attr_id = in_key;

        v_oldvalue := to_char(v_oldexp, 'yyyymmdd');
        v_newvalue := to_char(v_exp, 'yyyymmdd');
      ELSIF v_type = 'ALL' THEN
        UPDATE crmv2.prod_inst_attr
           SET create_date = v_eff,
               status_date = v_eff,
               eff_date    = v_eff,
               exp_date    = v_exp
         WHERE prod_inst_attr_id = in_key;

        v_oldvalue := to_char(v_oldeff, 'yyyymmdd') || '/' ||
                      to_char(v_oldexp, 'yyyymmdd');

        v_newvalue := to_char(v_eff, 'yyyymmdd') || '/' ||
                      to_char(v_exp, 'yyyymmdd');
      END IF;

      itsc_crmv2.new_p_ins_billing_update('PROD_INST_ATTR',
                                          'PROD_iNST_ATTR_ID', in_key,
                                          modi_reason, v_bstaff);
    ELSIF v_table = 'PROD_INST_ATTR_HIS' THEN

      BEGIN
        SELECT a.eff_date,
               a.exp_date,
               a.area_id,
               a.attr_id,
               a.prod_inst_attr_id
          INTO v_oldeff, v_oldexp, v_area, v_spec, v_his_key_id
          FROM crmv2.prod_inst_attr_his a
         WHERE a.his_id = in_key;
      EXCEPTION
        WHEN OTHERS THEN
          o_msg := 'ID值在数据中存储有误';
          RETURN;

      END;

      IF v_type = 'EFF' THEN
        UPDATE crmv2.prod_inst_attr_his
           SET create_date     = v_eff,
               rec_update_date = v_eff,
               eff_date        = v_eff
         WHERE his_id = in_key
           AND status_cd IN ('1000', '1100');

        v_oldvalue := to_char(v_oldeff, 'yyyymmdd');
        v_newvalue := to_char(v_eff, 'yyyymmdd');
      ELSIF v_type = 'EXP' THEN

        UPDATE crmv2.prod_inst_attr_his
           SET exp_date = v_exp
         WHERE his_id = in_key
           AND status_cd IN ('1000', '1100');
        v_oldvalue := to_char(v_oldexp, 'yyyymmdd');
        v_newvalue := to_char(v_exp, 'yyyymmdd');
      ELSIF v_type = 'ALL' THEN

        UPDATE crmv2.prod_inst_attr_his
           SET create_date     = v_eff,
               rec_update_date = v_eff,
               eff_date        = v_eff,
               exp_date        = v_exp
         WHERE his_id = in_key
           AND status_cd IN ('1000', '1100');
        v_oldvalue := to_char(v_oldeff, 'yyyymmdd') || '/' ||
                      to_char(v_oldexp, 'yyyymmdd');

        v_newvalue := to_char(v_eff, 'yyyymmdd') || '/' ||
                      to_char(v_exp, 'yyyymmdd');
      END IF;

      itsc_crmv2.new_p_ins_billing_update('PROD_INST_ATTR',
                                          'PROD_iNST_ATTR_ID', v_his_key_id,
                                          modi_reason, v_bstaff);
    END IF;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT v_table,
             in_key,
             v_type,
             v_area,
             v_oldvalue,
             v_newvalue,
             'MODIFY',
             v_spec,
             '',
             'CRMV2.PKG_WH.CHANGE_ATTR_DATE',
             v_bstaff,
             crmv2.pkg_wh.f_check_modi_staff(v_bstaff),
             modi_reason,
             SYSDATE,
             decode(v_table, 'PROD_OFFER_INST_ATTR', '修改销售品属性时间',
                    'PROD_OFFER_INST_ATTR_HIS', '修改销售品属性时间', 'PROD_INST_ATTR',
                    '修改产品属性时间', 'PROD_INST_ATTR_HIS', '修改产品属性时间'),
             decode(v_table, 'PROD_OFFER_INST_ATTR', '销售品类',
                    'PROD_OFFER_INST_ATTR_HIS', '销售品类', 'PROD_INST_ATTR',
                    '产品类', 'PROD_INST_ATTR_HIS', '产品类')
        FROM dual;

    IF v_table = 'PROD_OFFER_INST_ATTR_HIS' OR
       v_table = 'PROD_INST_ATTR_HIS' THEN
      o_msg := '修改成功';
      RETURN;
    END IF;

    BEGIN
      IF v_table = 'PROD_OFFER_INST_ATTR' THEN
        SELECT d.prod_inst_id
          INTO v_id
          FROM crmv2.prod_offer_inst_attr a,
               crmv2.offer_prod_inst_rel  c,
               crmv2.prod_inst            d,
               crmv2.product              e
         WHERE a.prod_offer_inst_id = c.prod_offer_inst_id
           AND c.prod_inst_id = d.prod_inst_id
           AND d.product_id = e.product_id
           AND e.prod_func_type = '101'
           AND a.prod_offer_inst_attr_id = in_key
           AND rownum = 1;

      ELSIF v_table = 'PROD_INST_ATTR' THEN
        BEGIN
          SELECT d.prod_inst_id
            INTO v_id
            FROM crmv2.prod_inst_attr a, crmv2.prod_inst d, crmv2.product e
           WHERE a.prod_inst_id = d.prod_inst_id
             AND d.product_id = e.product_id
             AND e.prod_func_type = '101'
             AND a.prod_inst_attr_id = in_key
             AND rownum = 1;

        EXCEPTION
          WHEN OTHERS THEN
            SELECT d.prod_inst_id
              INTO v_id
              FROM crmv2.prod_inst_attr a,
                   crmv2.prod_inst_rel  c,
                   crmv2.prod_inst      d,
                   crmv2.product        e
             WHERE a.prod_inst_id = c.prod_inst_z_id
               AND c.prod_inst_a_id = d.prod_inst_id
               AND c.relation_type_cd = '100600'
               AND d.product_id = e.product_id
               AND a.prod_inst_attr_id = in_key
               AND e.prod_func_type = '101'
               AND rownum = 1;

        END;

      END IF;

      SELECT b.attr_name
        INTO v_name
        FROM crmv2.attr_spec b
       WHERE b.attr_id = v_spec;

      SELECT decode(v_table,

                    'PROD_OFFER_INST_ATTR', '销售品属性', 'PROD_INST_ATTR', '产品属性')
        INTO v_a
        FROM dual;

      SELECT decode(v_type, 'EFF', '生效时间;', 'EXP', '失效时间;', 'ALL', '生失效时间;')
        INTO v_b
        FROM dual;

      v_context := '修改' || v_a || '[' || v_name || ']' || '的' || v_b ||
                   '旧值：' || v_oldvalue || ',' || '新值：' || v_newvalue;

      crmv2.proc_create_order(v_id,
                              --产品实例ID
                              'CHANGE_ATTR_DATE',
                              --存储过程名称
                              '修改属性时间',
                              --调用过程的作用
                              modi_reason,
                              --备注，调用这个存储过程的原因
                              modi_staff, v_context
                              --存储过程操作的工号
                              );

    EXCEPTION
      WHEN OTHERS THEN
        o_msg := '档案修改成功，订单生成：' || ';' || SQLERRM;
    END;
    COMMIT;
  END;

  PROCEDURE offer_attr_his_to_1
  \***************************************************************
      FUN NAME: 将销售品历史属性拉回1表
      VERSION: V1.0.0
      AUTHOR: zhengzy
      CREATE_DATE: 20130503
      功能说明：将销售品历史属性拉回1表
    ****************************************************************\
  (in_his_id   IN NUMBER,
   in_exp      IN VARCHAR2,
   modi_reason IN VARCHAR2,
   modi_staff  IN VARCHAR2,
   o_msg       OUT VARCHAR2) IS

    v_date        DATE;
    v_cnt_area_id NUMBER(10);
    CURSOR c IS
      SELECT a.*
        FROM crmv2.prod_offer_inst_attr_his a
       WHERE a.his_id = in_his_id;
  BEGIN

    IF in_exp IS NULL THEN
      o_msg := '失效时间为空，请输入';
      RETURN;
    ELSE
      v_date := to_date(in_exp, 'yyyy-mm-dd');
    END IF;

    SELECT COUNT(1)
      INTO v_cnt_area_id
      FROM crmv2.prod_offer_inst_attr_his a
     WHERE a.his_id = in_his_id
       AND area_id = crmv2.pkg_wh.f_check_modi_staff(modi_staff);

    IF f_check_modi_staff(modi_staff) = 0 THEN
      o_msg := '修改人不准确';
      RETURN;
    ELSIF f_check_modi_staff(modi_staff) > 1 THEN
      IF v_cnt_area_id = 0 THEN
        o_msg := '修改人不准确';
        RETURN;
      END IF;
    END IF;

    FOR rec IN c LOOP

      INSERT INTO crmv2.prod_offer_inst_attr
        (prod_offer_inst_attr_id,
         prod_offer_inst_id,
         attr_id,
         attr_value_id,
         attr_value,
         create_date,
         exp_date,
         eff_date,
         status_date,
         status_cd,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         rec_update_date,
         version)
        SELECT prod_offer_inst_attr_id,
               prod_offer_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               create_date,
               v_date,
               eff_date,
               status_date,
               '1000' status_cd,
               SYSDATE update_date,
               '' proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               '' rec_update_date,
               '0' version
          FROM crmv2.prod_offer_inst_attr_his a
         WHERE a.his_id = rec.his_id;

      INSERT INTO itsc_crmv2.crm_wh_bak
        (tal_name,
         key_id,
         modi_column,
         modi_area,
         old_value,
         new_value,
         modi_action,
         modi_spec,
         offer_spec,
         proce,
         modi_staff,
         staff_area,
         modi_reason,
         modi_time,
         reason,
         modi_type)
        SELECT 'PROD_OFFER_INST_ATTR',
               a.prod_offer_inst_attr_id,
               '',
               area_id,
               '',
               '',
               'MODIFY',
               '',
               '',
               'CRMV2.PKG_WH.OFFER_ATTR_HIS_TO_1',
               modi_staff,
               crmv2.pkg_wh.f_check_modi_staff(modi_staff),
               modi_reason,
               SYSDATE,
               '可选包属性历史拉在用',
               '销售品类'
          FROM crmv2.prod_offer_inst_attr_his a
         WHERE a.his_id = rec.his_id;

      DELETE FROM crmv2.prod_offer_inst_attr_his a
       WHERE a.his_id = rec.his_id;

      itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_attr',
                                          'prod_offer_inst_attr_id',
                                          rec.prod_offer_inst_attr_id,
                                          modi_reason, modi_staff);
    END LOOP;
    o_msg := 'SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;
  END;

  PROCEDURE p_check_idcardcode(in_reg_nbr IN VARCHAR2,
                               out_str    OUT VARCHAR2) IS

    v_count   NUMBER;
    v_str_y   VARCHAR2(20);
    v_str_m   VARCHAR2(20);
    v_str_d   VARCHAR2(20);
    v_reg_nbr VARCHAR2(40);
    v_num_y   NUMBER;
    v_fag     VARCHAR2(1);
    v_cnt     NUMBER;
    i         NUMBER;
    v_str     VARCHAR2(10);
    v_reg     NUMBER;
    v_add     NUMBER;
    v_result  NUMBER;
    v_last    VARCHAR2(10);
    v_right   VARCHAR2(1);

    out_nbr NUMBER;
  BEGIN
    IF in_reg_nbr IS NULL THEN
      out_nbr := 0;
      out_str := '身份证为空';
      RETURN;
    END IF;
    v_reg_nbr := ltrim(rtrim(in_reg_nbr));
    v_count   := length(v_reg_nbr);
    IF v_count NOT IN (15, 18) THEN
      out_nbr := 0;
      out_str := '身份证号码位数不正确';
      RETURN;
    END IF;
    FOR i IN 1 .. v_count LOOP
      v_str := substr(v_reg_nbr, i, 1);
      IF i <> 18 AND v_str NOT BETWEEN '0' AND '9' THEN
        out_nbr := 0;
        out_str := '前17位身份证号码不是数字';
        RETURN;
      END IF;
    END LOOP;
    IF v_count = 15 THEN
      v_str_y := '19' || substr(v_reg_nbr, 7, 2);
      v_str_m := substr(v_reg_nbr, 9, 2);
      v_str_d := substr(v_reg_nbr, 11, 2);
    ELSE
      v_str_y := substr(v_reg_nbr, 7, 4);
      v_str_m := substr(v_reg_nbr, 11, 2);
      v_str_d := substr(v_reg_nbr, 13, 2);
    END IF;
    IF v_str_m NOT BETWEEN '01' AND '12' THEN
      out_str := '身份证的月份和日期不正确';
      RETURN;
    END IF;
    v_num_y := to_number(v_str_y);
    IF v_num_y NOT BETWEEN 1930 AND 1999 THEN
      out_str := '身份证的年份不正确';
      RETURN;
    END IF;
    IF MOD(v_num_y, 4) = 0 AND v_str_m = '02' AND v_str_d = '29' THEN
      v_fag := '1';
    ELSE
      v_fag := '0';
    END IF;
    SELECT COUNT(*)
      INTO v_cnt
      FROM itsc_crmv2.crm_reg_nbr_check_list
     WHERE mon = v_str_m
       AND dat = v_str_d
       AND fag = v_fag;
    IF v_cnt = 0 THEN
      out_nbr := 0;
      out_str := '身份证的月份和日期不正确';
      RETURN;
    END IF;
    ---------校验18位证件号码是否正确
    IF v_count = 18 THEN
      v_add := 0;
      FOR i IN 1 .. 17 LOOP
        --v_Reg := 0;
        v_reg := to_number(substr(v_reg_nbr, i, 1));
        BEGIN
          SELECT v_reg * nbr + v_add
            INTO v_add
            FROM itsc_crmv2.crm_reg_nbr_check_rule
           WHERE TYPE = 'ADD'
             AND seq = i;
        EXCEPTION
          WHEN OTHERS THEN
            v_add := 0;
        END;
      END LOOP;
      v_last   := substr(v_reg_nbr, 18, 1);
      v_result := MOD(v_add, 11);
      BEGIN
        SELECT nbr
          INTO v_right
          FROM itsc_crmv2.crm_reg_nbr_check_rule
         WHERE TYPE = 'RESULT'
           AND seq = v_result;
      EXCEPTION
        WHEN OTHERS THEN
          v_right := 'P';
      END;
      IF v_right <> v_last THEN
        out_nbr := 0;

        out_str := '身份证的最后一位校验码不正确';
        RETURN;
      END IF;
    END IF;
    out_nbr := 1;
    out_str := '正确!';
  END;

  PROCEDURE delete_functional_product
  \***************************************************************
      FUN NAME: 只删除功能类产品档案，不送外围施工
      VERSION: V1.0.0
      AUTHOR: zengx
      CREATE_DATE: 20130101
      功能说明：只删除功能类产品档案，不送外围施工
    ****************************************************************\
  (v_prod_inst_id IN NUMBER, -- 功能类产品实例id
   iremark        IN VARCHAR2, --修改备注
   modi_man       IN VARCHAR2, --修改人
   o_msg          OUT VARCHAR2) IS
    --执行过程返回信息
    v_prod_func_type     crmv2.product.prod_func_type%TYPE;
    v_prod_offer_inst_id crmv2.prod_offer_inst.prod_offer_inst_id%TYPE;
    v_offer_type         crmv2.prod_offer.offer_type%TYPE;
    v_offer_sub_type     crmv2.prod_offer.offer_sub_type%TYPE;
  BEGIN

    BEGIN
      SELECT c.prod_func_type
        INTO v_prod_func_type
        FROM crmv2.prod_inst b, crmv2.product c
       WHERE b.prod_inst_id = v_prod_inst_id
         AND b.status_cd = 100000
         AND b.product_id = c.product_id;
    EXCEPTION
      WHEN OTHERS THEN
        o_msg := v_prod_inst_id || '产品ID不存在!!';
        RETURN;
    END;

    BEGIN
      SELECT b.prod_offer_inst_id, c.offer_type, c.offer_sub_type
        INTO v_prod_offer_inst_id, v_offer_type, v_offer_sub_type
        FROM crmv2.offer_prod_inst_rel a,
             crmv2.prod_offer_inst     b,
             crmv2.prod_offer          c
       WHERE a.prod_inst_id = v_prod_inst_id
         AND a.status_cd = 1000
         AND a.prod_offer_inst_id = b.prod_offer_inst_id
         AND b.prod_offer_id = c.prod_offer_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    IF v_prod_func_type NOT IN ('102') THEN
      o_msg := '只能删除功能类产品，不删除其他类型产品！';
      RETURN;
    END IF;

    --备份之前的数据
    INSERT INTO itsc_crmv2.del_t02_prod_bak2
      SELECT * FROM itsc_crmv2.del_t02_prod_bak;
    DELETE FROM itsc_crmv2.del_t02_prod_bak;
    COMMIT;

    --删除产品
    INSERT INTO crmv2.prod_inst_his
      SELECT prod_inst_id,
             product_id,
             acc_prod_inst_id,
             address_id,
             owner_cust_id,
             payment_mode_cd,
             product_password,
             important_level,
             area_code,
             acc_nbr,
             exch_id,
             common_region_id,
             remark,
             pay_cycle,
             begin_rent_time,
             stop_rent_time,
             finish_time,
             stop_status,
             110000,
             create_date,
             status_date,
             update_date,
             proc_serial,
             use_cust_id,
             ext_prod_inst_id,
             address_desc,
             area_id,
             update_staff,
             create_staff,
             crmv2.seq_prod_inst_his_id.nextval,
             SYSDATE,
             account,
             community_id,
             version,
             ext_acc_prod_inst_id,
             distributor_id
        FROM crmv2.prod_inst
       WHERE prod_inst_id = v_prod_inst_id
         AND status_cd = 100000;
    INSERT INTO itsc_crmv2.del_t02_prod_bak
      (table_name, col_name, key_id, insert_date, area_id)
      SELECT 'prod_inst', 'prod_inst_id', prod_inst_id, SYSDATE, area_id
        FROM crmv2.prod_inst
       WHERE prod_inst_id = v_prod_inst_id
         AND status_cd = 100000;

    DELETE FROM crmv2.prod_inst
     WHERE prod_inst_id = v_prod_inst_id
       AND status_cd = 100000;
    COMMIT;
    \*    itsc_crmv2.new_p_ins_billing_update('prod_inst',
    'prod_inst_id',
    v_prod_inst_id,
    iremark,
    modi_man);*\
    --删除产品属性
    FOR rec IN (SELECT *
                  FROM crmv2.prod_inst_attr
                 WHERE prod_inst_id = v_prod_inst_id
                   AND status_cd = 1000) LOOP

      INSERT INTO crmv2.prod_inst_attr_his
        SELECT prod_inst_attr_id,
               prod_inst_id,
               attr_id,
               attr_value_id,
               attr_value,
               1100,
               status_date,
               eff_date,
               SYSDATE,
               create_date,
               update_date,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_attr_his_id.nextval,
               SYSDATE,
               version
          FROM crmv2.prod_inst_attr
         WHERE prod_inst_id = v_prod_inst_id
           AND status_cd = 1000;
      INSERT INTO itsc_crmv2.del_t02_prod_bak
        (table_name, col_name, key_id, insert_date, area_id)
        SELECT 'PROD_INST_ATTR',
               'PROD_INST_ATTR_ID',
               prod_inst_attr_id,
               SYSDATE,
               area_id
          FROM crmv2.prod_inst_attr
         WHERE prod_inst_id = v_prod_inst_id
           AND status_cd = 1000;

      DELETE FROM crmv2.prod_inst_attr
       WHERE prod_inst_id = v_prod_inst_id
         AND status_cd = 1000;
      COMMIT;
      \* itsc_crmv2.new_p_ins_billing_update('prod_inst_attr',
      'prod_inst_attr_id',
      rec.prod_inst_attr_id,
      iremark,
      modi_man);*\

    END LOOP;

    IF v_offer_type IN (10, 11) AND v_offer_sub_type IN ('T02') THEN
      --删除销售品
      INSERT INTO crmv2.prod_offer_inst_his
        SELECT prod_offer_inst_id,
               prod_offer_id,
               cust_id,
               channel_id,
               create_date,
               1100,
               status_date,
               eff_date,
               SYSDATE,
               region,
               update_date,
               proc_serial,
               ext_prod_offer_inst_id,
               NULL,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_offer_inst_his_id.nextval,
               SYSDATE,
               trial_eff_date,
               trial_exp_date,
               service_nbr,
               version,
               remark,
               ext_flag2,
               wh_remark,
               ext_flag1,
               distributor_id
          FROM crmv2.prod_offer_inst
         WHERE prod_offer_inst_id = v_prod_offer_inst_id
           AND status_cd = 1000;
      INSERT INTO itsc_crmv2.del_t02_prod_bak
        (table_name, col_name, key_id, insert_date, area_id)
        SELECT 'PROD_OFFER_INST',
               'PROD_OFFER_INST_ID',
               prod_offer_inst_id,
               SYSDATE,
               area_id
          FROM crmv2.prod_offer_inst
         WHERE prod_offer_inst_id = v_prod_offer_inst_id
           AND status_cd = 1000;

      DELETE FROM crmv2.prod_offer_inst
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd = 1000;
      COMMIT;
      \* itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
      'prod_offer_inst_id',
      v_prod_offer_inst_id,
      iremark,
      modi_man);*\
    END IF;
    --删除产品销售品关联
    FOR rec IN (SELECT *
                  FROM crmv2.offer_prod_inst_rel
                 WHERE prod_inst_id = v_prod_inst_id
                   AND status_cd = 1000) LOOP

      INSERT INTO crmv2.offer_prod_inst_rel_his
        SELECT offer_prod_inst_rel_id,
               prod_inst_id,
               prod_offer_inst_id,
               role_cd,
               offer_prod_inst_rel_role_id,
               1100,
               status_date,
               create_date,
               eff_date,
               SYSDATE,
               update_date,
               proc_serial,
               offer_prod_rel_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_prod_inst_rel_his_id.nextval,
               SYSDATE,
               ext_flag
          FROM crmv2.offer_prod_inst_rel
         WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           AND status_cd = 1000;
      INSERT INTO itsc_crmv2.del_t02_prod_bak
        (table_name, col_name, key_id, insert_date, area_id)
        SELECT 'OFFER_PROD_INST_REL',
               'OFFER_PROD_INST_REL_ID',
               offer_prod_inst_rel_id,
               SYSDATE,
               area_id
          FROM crmv2.offer_prod_inst_rel
         WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           AND status_cd = 1000;

      DELETE FROM crmv2.offer_prod_inst_rel
       WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
         AND status_cd = 1000;
      COMMIT;
      \*  itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
      'offer_prod_inst_rel_id',
      rec.offer_prod_inst_rel_id,
      iremark,
      modi_man);*\

    END LOOP;
    --删除产品关联
    FOR rec IN (SELECT *
                  FROM crmv2.prod_inst_rel
                 WHERE prod_inst_z_id = v_prod_inst_id
                   AND status_cd = 1000
                   AND relation_type_cd = '100600') LOOP

      INSERT INTO crmv2.prod_inst_rel_his
        SELECT prod_inst_rel_id,
               prod_inst_a_id,
               prod_inst_z_id,
               relation_type_cd,
               prod_inst_rel_role_id,
               role_cd,
               eff_date,
               SYSDATE,
               create_date,
               1100,
               status_date,
               update_date,
               proc_serial,
               product_rel_id,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_inst_rel_his_id.nextval,
               SYSDATE
          FROM crmv2.prod_inst_rel
         WHERE prod_inst_z_id = v_prod_inst_id
           AND status_cd = 1000
           AND relation_type_cd = '100600';
      INSERT INTO itsc_crmv2.del_t02_prod_bak
        (table_name, col_name, key_id, insert_date, area_id)
        SELECT 'PROD_INST_REL',
               'PROD_INST_REL_ID',
               prod_inst_rel_id,
               SYSDATE,
               area_id
          FROM crmv2.prod_inst_rel
         WHERE prod_inst_z_id = v_prod_inst_id
           AND status_cd = 1000
           AND relation_type_cd = '100600';

      DELETE FROM crmv2.prod_inst_rel
       WHERE prod_inst_z_id = v_prod_inst_id
         AND status_cd = 1000
         AND relation_type_cd = '100600';
      COMMIT;
      \* itsc_crmv2.new_p_ins_billing_update('prod_inst_rel',
      'prod_inst_rel_id',
      rec.prod_inst_rel_id,
      iremark,
      modi_man);*\

    END LOOP;

    --单独送计费接口
    FOR rec IN (SELECT * FROM itsc_crmv2.del_t02_prod_bak) LOOP
      itsc_crmv2.new_p_ins_billing_update(rec.table_name, rec.col_name,
                                          rec.key_id, iremark, modi_man);
    END LOOP;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'PROD_INST',
             a.key_id,
             '',
             area_id,
             '',
             '',
             'DELETE',
             '',
             '',
             'CRMV2.PKG_WH.DELETE_FUNCTIONAL_PRODUCT',
             modi_man,
             f_check_modi_staff(modi_man),
             iremark,
             SYSDATE,
             '删除功能类产品档案',
             '产品类'
        FROM itsc_crmv2.del_t02_prod_bak a
       WHERE a.table_name = 'PROD_INST';

    COMMIT;
    o_msg := '修改成功！';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_msg := v_prod_inst_id || SQLERRM;
  END;

  PROCEDURE release_temkey_yew(in_termkey   IN VARCHAR2,
                               in_phone_nbr IN VARCHAR2,
                               modi_staff   IN VARCHAR,
                               iremark      IN VARCHAR,
                               out_err_msg  OUT VARCHAR2) IS

    -- Local variables here
    v_mkt_occupy_id    VARCHAR2(20);
    v_xml_content      VARCHAR2(3000);
    v_storage_id       NUMBER;
    v_mkt_reso_spec_id NUMBER;
    v_mkt_reso_id      NUMBER;
    v_state_date       VARCHAR2(40);
    v_req_date         VARCHAR2(40);
    v_xml_id           NUMBER;
    v_mkt_type         NUMBER;
    v_mkt_typeb        NUMBER;
    v_remark           VARCHAR2(100);
    v_modify_name      VARCHAR2(100);
    i                  NUMBER;
    num_esn            NUMBER;
    num_esn1           NUMBER;
    num_hflq           NUMBER;
    num_gjq            NUMBER;
    v_n                NUMBER;
    --  v_state              VARCHAR2(10);
    v_mkt_reso_spec_type NUMBER(10);
    modi_man             VARCHAR2(100);
    v_state              VARCHAR2(100);
  BEGIN
    modi_man := modi_staff;
    i        := 10;
    IF iremark IS NULL OR modi_man IS NULL OR in_phone_nbr IS NULL OR
       in_termkey IS NULL THEN
      out_err_msg := 'in_remark、in_modify_name、in_phone_nbr、in_termkey 不允许为空';
      RETURN;
    END IF;
    i := 0;
    BEGIN
      SELECT a.mkt_reso_spec_type
        INTO v_mkt_type
        FROM crmv1.mkt_resource a
       WHERE a.mkt_reso_key = in_termkey;

      IF v_mkt_type IN
         ('610005325', '610006165', '610007508', '610004005', '610006585',
          '610007985', '610006166') THEN

        out_err_msg := '实物类型为旧实物大类，不允许释放，请提交IT释放';
        RETURN;
      END IF;

      SELECT COUNT(1)
        INTO v_n
        FROM crmv1.mkt_occupy      a,
             crmv1.mkt_resource    b,
             crmv2.prod_offer_inst c
       WHERE b.mkt_reso_key = in_termkey
         AND b.mkt_reso_id = a.mkt_reso_id
         AND a.buy_price_id = c.prod_offer_inst_id
         AND c.status_cd != '1100';

      IF v_n > 0 THEN
        out_err_msg := '实物所关联的销售品未拆除，请先从前台拆除';
        RETURN;
      END IF;

      \*     exception when others then out_err_msg := '实物细类填写错误'; return;*\

      -- 关联销售品
    END;
    BEGIN
      SELECT to_char(b.mkt_occupy_id),
             a.mkt_reso_id,
             a.storage_id,
             a.mkt_reso_spec_id,
             a.mkt_reso_spec_type,
             a.state
        INTO v_mkt_occupy_id,
             v_mkt_reso_id,
             v_storage_id,
             v_mkt_reso_spec_id,
             v_mkt_reso_spec_type,
             v_state
        FROM crmv1.mkt_resource a, crmv1.mkt_occupy b
       WHERE a.mkt_reso_key = in_termkey
         AND a.mkt_reso_id = b.mkt_reso_id
         AND (b.buy_prod_id =
             (SELECT prod_inst_id
                 FROM crmv2.prod_inst
                WHERE acc_nbr = in_phone_nbr
                  AND product_id IN (800000002, 800000007)) OR
             b.buy_prod_id IN
             (SELECT prod_inst_id
                 FROM crmv2.prod_inst_his
                WHERE acc_nbr = in_phone_nbr
                  AND product_id IN (800000002, 800000007)))
         AND a.state IN ('70Z', '70I');
    EXCEPTION
      WHEN OTHERS THEN
        SELECT to_char(b.mkt_occupy_id),
               a.mkt_reso_id,
               a.storage_id,
               a.mkt_reso_spec_id,
               mkt_reso_spec_type
          INTO v_mkt_occupy_id,
               v_mkt_reso_id,
               v_storage_id,
               v_mkt_reso_spec_id,
               v_mkt_reso_spec_type
          FROM crmv1.mkt_resource a, crmv1.mkt_occupy_his b
         WHERE a.mkt_reso_key = in_termkey
           AND a.mkt_reso_id = b.mkt_reso_id
           AND (b.buy_prod_id =
               (SELECT prod_inst_id
                   FROM crmv2.prod_inst
                  WHERE acc_nbr = in_phone_nbr
                    AND product_id IN (800000002, 800000007)) OR
               b.buy_prod_id IN
               (SELECT prod_inst_id
                   FROM crmv2.prod_inst_his
                  WHERE acc_nbr = in_phone_nbr
                    AND product_id IN (800000002, 800000007)))
           AND a.state IN ('70Z', '70I')
           AND b.mkt_occupy_id =
               (SELECT MAX(mkt_occupy_id)
                  FROM crmv1.mkt_occupy_his
                 WHERE mkt_reso_id = a.mkt_reso_id);
    END;
    IF v_mkt_reso_spec_type = 610007585 THEN
      out_err_msg := '龙终端请走返销冲正流程进行释放';
      RETURN;
    END IF;
    i        := 1;
    num_esn  := 0;
    num_hflq := 0;
    num_gjq  := 0;
    SELECT \*+index(a,IDX_MKT_RESO_KEY)*\
     COUNT(*)
      INTO num_esn
      FROM crmv2.intf_mkt_xml a
     WHERE mkt_reso_key = in_termkey
       AND xml_type = '20';
    SELECT \*+index(a,IDX_ESN_INDEX)*\
     COUNT(*)
      INTO num_esn1
      FROM crmv2.intf_mkt_xml a
     WHERE esn = in_termkey
       AND xml_type = '20';

    SELECT \*+index(a,IDX_MKT_RESO_KEY)*\
     COUNT(*)
      INTO num_hflq
      FROM crmv2.intf_mkt_xml a, crmv1.mkt_resource b, crmv1.mkt_reso_fea c
     WHERE a.mkt_reso_key = c.param1
       AND b.mkt_reso_id = c.mkt_reso_id
       AND b.mkt_reso_key = in_termkey
       AND xml_type = '20';

    SELECT \*+index(a,IDX_MKT_RESO_KEY)*\
     COUNT(*)
      INTO num_gjq
      FROM crmv2.intf_mkt_xml a, crmv1.mkt_resource b, crmv1.mkt_reso_fea c
     WHERE a.mkt_reso_key = c.param1
       AND b.mkt_reso_id = c.mkt_reso_id
       AND b.mkt_reso_key = in_termkey
       AND xml_type = '20';

    IF num_esn + num_hflq + num_gjq + num_esn1 = 0 THEN
      out_err_msg := '该串号未上传集团';
    ELSE
      i           := 2;
      out_err_msg := '该串号已上传集团';
      --return;
      SELECT \*+index(a,IDX_MKT_INTF_XML_UNIQUE_01)*\
       to_char(a.xml_content), intf_mkt_xml_id
        INTO v_xml_content, v_xml_id
        FROM crmv2.intf_mkt_xml a
       WHERE a.xml_type = '20'
         AND a.xml_ref_id = v_mkt_occupy_id
         AND a.mdn = in_phone_nbr
         AND state = '70C'
         AND to_char(a.xml_content) LIKE '%<ActionCD>10</ActionCD>%'
         AND intf_mkt_xml_id =
             (SELECT \*+index(b,IDX_MKT_INTF_XML_UNIQUE_01)*\
               MAX(intf_mkt_xml_id)
                FROM crmv2.intf_mkt_xml b
               WHERE b.xml_type = '20'
                 AND b.xml_ref_id = v_mkt_occupy_id
                 AND state = '70C'
                 AND b.mdn = in_phone_nbr
                 AND to_char(b.xml_content) LIKE '%<ActionCD>10</ActionCD>%');

      SELECT REPLACE(v_xml_content, '<ActionCD>10</ActionCD>',
                     '<ActionCD>12</ActionCD>')
        INTO v_xml_content
        FROM dual;

      SELECT substr(v_xml_content, instr(v_xml_content, '<SalesDate>'), 31)
        INTO v_state_date
        FROM dual;

      SELECT REPLACE(v_xml_content, v_state_date,
                     '<SalesDate>' || to_char(SYSDATE, 'yyyymmdd') ||
                      '</SalesDate>')
        INTO v_xml_content
        FROM dual;
      SELECT substr(v_xml_content, instr(v_xml_content, '<BindExpTime>'), 35)
        INTO v_state_date
        FROM dual;

      SELECT REPLACE(v_xml_content, v_state_date,
                     '<BindExpTime>' || to_char(SYSDATE, 'yyyymmdd') ||
                      '</BindExpTime>')
        INTO v_xml_content
        FROM dual;

      SELECT substr(v_xml_content, instr(v_xml_content, '<ReqTime>'), 33)
        INTO v_req_date
        FROM dual;

      SELECT REPLACE(v_xml_content, v_req_date,
                     '<ReqTime>' || to_char(SYSDATE, 'yyyymmddhh24miss') ||
                      '</ReqTime>')
        INTO v_xml_content
        FROM dual;

      i := 3;

      INSERT INTO crmv2.intf_mkt_xml c
        (intf_mkt_xml_id,
         xml_ref_id,
         xml_type,
         xml_come,
         xml_go,
         xml_content,
         crea_time,
         modi_time,
         state,
         serial,
         remark,
         real_modify_date,
         service_code,
         transaction_id,
         mdn,
         mkt_reso_key,
         esn)
        SELECT crmv2.seq_intf_mkt_xml_id.nextval,
               v_mkt_occupy_id,
               '21',
               'MKT',
               'JT',
               v_xml_content,
               SYSDATE,
               SYSDATE,
               '70A',
               '',
               '',
               SYSDATE,
               'SVC16021',
               '',
               in_phone_nbr,
               in_termkey,
               in_termkey
          FROM dual;
    END IF;
    UPDATE crmv1.mkt_resource c
       SET state = '70A', real_modify_date = SYSDATE
     WHERE mkt_reso_id = v_mkt_reso_id;
    INSERT INTO crmv1.mkt_occupy_his
      SELECT * FROM crmv1.mkt_occupy WHERE mkt_occupy_id = v_mkt_occupy_id;
    UPDATE crmv1.mkt_occupy_his a
       SET a.remark         = modi_man || '于' ||
                              to_char(SYSDATE, 'yyyy-mm-dd hh24:mi:ss') ||
                              '释放:' || iremark,
           real_modify_date = SYSDATE
     WHERE mkt_occupy_id = v_mkt_occupy_id;
    BEGIN
      INSERT INTO crmv2.prod_res_inst_rel_his
        (prod_res_inst_rel_id,
         prod_inst_id,
         mkt_res_inst_id,
         type_cd,
         property_type,
         create_date,
         status_cd,
         status_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id)
        SELECT prod_res_inst_rel_id,
               prod_inst_id,
               mkt_res_inst_id,
               type_cd,
               property_type,
               create_date,
               status_cd,
               status_date,
               SYSDATE + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_res_inst_rel_his_id.nextval
          FROM crmv2.prod_res_inst_rel
         WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    BEGIN
      INSERT INTO crmv2.offer_res_inst_rel_his
        (offer_res_inst_rel_id,
         mkt_res_inst_id,
         prod_offer_inst_id,
         use_prod_inst_id,
         create_date,
         status_cd,
         status_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id)
        SELECT offer_res_inst_rel_id,
               mkt_res_inst_id,
               prod_offer_inst_id,
               use_prod_inst_id,
               create_date,
               status_cd,
               status_date,
               SYSDATE + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_res_inst_rel_his_id.nextval
          FROM crmv2.offer_res_inst_rel
         WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    v_remark      := iremark;
    v_modify_name := modi_man;
    UPDATE crmv1.mkt_occupy_his
       SET remark           = v_remark || v_modify_name,
           real_modify_date = SYSDATE + 1 / 24
     WHERE mkt_occupy_id = v_mkt_occupy_id;
    DELETE crmv1.mkt_occupy WHERE mkt_occupy_id = v_mkt_occupy_id;
    BEGIN
      DELETE crmv2.prod_res_inst_rel
       WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    BEGIN
      DELETE crmv2.offer_res_inst_rel
       WHERE mkt_res_inst_id = v_mkt_occupy_id;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    UPDATE crmv1.mkt_store_item a
       SET a.usage_count    = a.usage_count + 1,
           a.moving_count   = decode(v_state, '70I', a.moving_count - 1,
                                     a.moving_count),
           real_modify_date = SYSDATE
     WHERE a.store_id = v_storage_id
       AND a.mkt_reso_spec_id = v_mkt_reso_spec_id;
    i           := 4;
    out_err_msg := out_err_msg || '处理成功';
    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'MKT_RESOURCE',
             v_mkt_reso_id,
             'STATE',
             '',
             '',
             '70A',
             'MODIFY',
             '',
             '',
             'CRMV2.PKG_WH.RELEASE_TERMKEY_NEW',
             modi_man,
             f_check_modi_staff(modi_man),
             iremark,
             SYSDATE,
             '释放实物串码',
             '实物类'
        FROM dual;

    COMMIT;
    \*    ITSC_CRM.INS_JT_UPDATE('MKT_OCCUPY',
    'MKT_OCCUPY_ID',
    v_mkt_occupy_id,
    'D',
    sysdate,
    iremark,
    modi_man,
    ERR_MSG);*\
  EXCEPTION
    WHEN OTHERS THEN
      IF i = 0 THEN
        out_err_msg := '无实物数据';
      ELSIF i IN (2, 3, 4) THEN
        out_err_msg := SQLERRM;
      END IF;

  END release_temkey_yew;

  PROCEDURE p_mkt_order_insert(in_key         IN VARCHAR2,
                               in_order       IN VARCHAR2,
                               in_modi_reason IN VARCHAR2,
                               in_modi_staff  IN VARCHAR2,
                               out_msg        OUT VARCHAR2) IS
    v_key         VARCHAR2(100) := TRIM(in_key);
    v_order       VARCHAR2(100) := TRIM(in_order);
    v_ordernumber NUMBER(10);
    v_resoid      NUMBER(10);
  BEGIN
    BEGIN
      SELECT c.order_item_id, a.mkt_reso_id
        INTO v_ordernumber, v_resoid
        FROM crmv1.mkt_reso_order      b,
             crmv1.mkt_reso_order_item c,
             crmv1.mkt_resource        a
       WHERE a.mkt_reso_key = v_key
         AND instr(upper(b.order_number), upper(v_order)) = 1
         AND b.order_id = c.order_id
         AND c.mkt_reso_spec_id = a.mkt_reso_spec_id;
    EXCEPTION
      WHEN OTHERS THEN
        BEGIN
          out_msg := '订单对应不到串码';
          RETURN;
        END;
    END;

    BEGIN
      INSERT INTO crmv1.mkt_reso_ord_rela
        SELECT v_ordernumber, v_resoid, SYSDATE, NULL, NULL FROM dual;
    EXCEPTION
      WHEN OTHERS THEN
        BEGIN
          out_msg := '已存在关联';
          RETURN;
        END;
    END;

    INSERT INTO itsc_crmv2.crm_wh_bak
      (tal_name,
       key_id,
       modi_column,
       modi_area,
       old_value,
       new_value,
       modi_action,
       modi_spec,
       offer_spec,
       proce,
       modi_staff,
       staff_area,
       modi_reason,
       modi_time,
       reason,
       modi_type)
      SELECT 'MKT_RESO_ORD_REL',
             v_resoid,
             '',
             f_check_modi_staff(in_modi_staff),
             '',
             '',
             'INSERT',
             '',
             '',
             'CRMV2.PKG_WH.P_MKT_ORDER_INSERT',
             in_modi_staff,
             f_check_modi_staff(in_modi_staff),
             in_modi_reason,
             SYSDATE,
             '新增实物订单关联',
             '实物类'
        FROM dual;

    out_msg := '添加成功';
    COMMIT;

  END;

  PROCEDURE crm_ottresource_70d(i_mkt_reso_key IN VARCHAR, -- 串码
                                in_modi_man    IN VARCHAR, --修改人
                                in_remark      IN VARCHAR, --修改原因
                                in_ip_address  IN VARCHAR, ---操作ip地址
                                o_result       OUT VARCHAR2) IS
    rec_mkt_reso_id      NUMBER;
    rec_mkt_reso_spec_id NUMBER;
    rec_storage_id       NUMBER;
    rec_mkt_occupy_id    NUMBER;
    b                    NUMBER;
    a                    NUMBER;
    rec_state            VARCHAR(10);
  BEGIN

    SELECT COUNT(1)
      INTO a
      FROM crmv1.mkt_resource
     WHERE mkt_reso_key = i_mkt_reso_key
       AND state IN ('70I', '70A', '70Z', '70D');
    IF a = 1 THEN
      --modify by chenlm 20140619
      -- mkt_reso_spec_type = 610009001, mkt_reso_spec_id= 654080000
      SELECT mkt_reso_id, s.mkt_reso_spec_id, s.storage_id, s.state
        INTO rec_mkt_reso_id,
             rec_mkt_reso_spec_id,
             rec_storage_id,
             rec_state
        FROM crmv1.mkt_resource s
       WHERE mkt_reso_key = i_mkt_reso_key
         AND state IN ('70I', '70Z', '70A', '70D');
      IF rec_state = '70Z' THEN
        UPDATE crmv1.mkt_resource
           SET state = '70A',
               \*storage_id         = '',*\
               real_modify_date = SYSDATE \*,
                                                                       mkt_reso_spec_type = 610009001,
                                                                       mkt_reso_spec_id   = 654080000*\
         WHERE mkt_reso_id = rec_mkt_reso_id;
        \*               update crm.mkt_store_item set usage_count=usage_count+1 where store_id=rec_storage_id and mkt_reso_spec_id=rec_mkt_reso_spec_id;*\
        ---修改库存
        UPDATE crmv1.mkt_store_item
           SET usage_count = usage_count + 1, real_modify_date = SYSDATE
         WHERE store_id = rec_storage_id
           AND mkt_reso_spec_id = rec_mkt_reso_spec_id;

        INSERT INTO itsc_crmv2.crm_resource_70d_log
        VALUES
          (i_mkt_reso_key, in_modi_man, SYSDATE, in_remark, in_ip_address); ---记录日志
        o_result := '成功';

      ELSIF rec_state = '70A' THEN
        UPDATE crmv1.mkt_resource
           SET state = '70A',
               \*storage_id         = '',*\
               real_modify_date = SYSDATE \*,
                                                                       mkt_reso_spec_type = 610009001,
                                                                       mkt_reso_spec_id   = 654080000*\
         WHERE mkt_reso_id = rec_mkt_reso_id;

        INSERT INTO itsc_crmv2.crm_resource_70d_log
        VALUES
          (i_mkt_reso_key, in_modi_man, SYSDATE, in_remark, in_ip_address); ---记录日志
        o_result := '成功';
      ELSIF rec_state = '70I' THEN
        UPDATE crmv1.mkt_resource
           SET state = '70A',
               \*storage_id         = '',*\
               real_modify_date = SYSDATE \*,
                                                                       mkt_reso_spec_type = 610009001,
                                                                       mkt_reso_spec_id   = 654080000*\
         WHERE mkt_reso_id = rec_mkt_reso_id;
        --修改库存
        UPDATE crmv1.mkt_store_item
           SET usage_count      = usage_count + 1,
               moving_count     = moving_count - 1,
               real_modify_date = SYSDATE
         WHERE store_id = rec_storage_id
           AND mkt_reso_spec_id = rec_mkt_reso_spec_id;
        INSERT INTO itsc_crmv2.crm_resource_70d_log
        VALUES
          (i_mkt_reso_key, in_modi_man, SYSDATE, in_remark, in_ip_address); ---记录日志
        o_result := '成功';
      END IF;
      SELECT COUNT(1)
        INTO b
        FROM crmv1.mkt_occupy
       WHERE mkt_reso_id = rec_mkt_reso_id;
      IF b = 1 THEN
        SELECT mkt_occupy_id
          INTO rec_mkt_occupy_id
          FROM crmv1.mkt_occupy
         WHERE mkt_reso_id = rec_mkt_reso_id;
        INSERT INTO crmv1.mkt_occupy_his
          SELECT mkt_occupy_id,
                 buy_prod_id,
                 buy_mdse_id,
                 buy_price_id,
                 mkt_reso_spec_id,
                 occupy_num,
                 occupy_type,
                 store_item_id,
                 mkt_reso_id,
                 '维护系统回退',
                 106,
                 staff,
                 team,
                 modi_time,
                 crea_time,
                 finish_time,
                 is_back,
                 shared_occupy_id,
                 remark,
                 occupy_flag,
                 single_price,
                 buy_cust_id,
                 SYSDATE
            FROM crmv1.mkt_occupy
           WHERE mkt_reso_id = rec_mkt_reso_id;
        DELETE FROM crmv1.mkt_occupy WHERE mkt_reso_id = rec_mkt_reso_id;

        INSERT INTO crmv2.prod_res_inst_rel_his
          (prod_res_inst_rel_id,
           prod_inst_id,
           mkt_res_inst_id,
           type_cd,
           property_type,
           create_date,
           status_cd,
           status_date,
           update_date,
           proc_serial,
           area_id,
           region_cd,
           update_staff,
           create_staff,
           his_id)
          SELECT prod_res_inst_rel_id,
                 prod_inst_id,
                 mkt_res_inst_id,
                 type_cd,
                 property_type,
                 create_date,
                 status_cd,
                 status_date,
                 SYSDATE + 1 / 24,
                 proc_serial,
                 area_id,
                 region_cd,
                 update_staff,
                 create_staff,
                 crmv2.seq_prod_res_inst_rel_his_id.nextval
            FROM crmv2.prod_res_inst_rel
           WHERE mkt_res_inst_id = rec_mkt_occupy_id;

        DELETE FROM crmv2.prod_res_inst_rel
         WHERE mkt_res_inst_id = rec_mkt_occupy_id;

        INSERT INTO crmv2.offer_res_inst_rel_his
          (offer_res_inst_rel_id,
           mkt_res_inst_id,
           prod_offer_inst_id,
           use_prod_inst_id,
           create_date,
           status_cd,
           status_date,
           update_date,
           proc_serial,
           area_id,
           region_cd,
           update_staff,
           create_staff,
           his_id)
          SELECT offer_res_inst_rel_id,
                 mkt_res_inst_id,
                 prod_offer_inst_id,
                 use_prod_inst_id,
                 create_date,
                 status_cd,
                 status_date,
                 SYSDATE + 1 / 24,
                 proc_serial,
                 area_id,
                 region_cd,
                 update_staff,
                 create_staff,
                 crmv2.seq_offer_res_inst_rel_his_id.nextval
            FROM crmv2.offer_res_inst_rel
           WHERE mkt_res_inst_id = rec_mkt_occupy_id;

        DELETE FROM crmv2.offer_res_inst_rel
         WHERE mkt_res_inst_id = rec_mkt_occupy_id;
      END IF;
    ELSE
      o_result := '无需处理';
    END IF;

    COMMIT;
  END;

  PROCEDURE p_intf_dep_finish_update(in_cust_so_number IN VARCHAR2,
                                     o_msg             OUT VARCHAR2) AS
  BEGIN

    UPDATE crmv2.intf_dep_finish
       SET status_cd = 400000, state = '70B'
     WHERE cust_so_number = TRIM(upper(in_cust_so_number));
    COMMIT;
    o_msg := 'OK';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := SQLERRM;

  END;

  PROCEDURE p_cancel_order_70e(v_package_group IN VARCHAR2,
                               in_modi_staff   IN VARCHAR2,
                               in_modi_reason  IN VARCHAR2, ----异常报竣原因
                               o_result        OUT VARCHAR2) IS
    v_ext_cust_order_id    VARCHAR2(100);
    v_order_package_rel_id VARCHAR2(100);
    v_count1               NUMBER(10);
  BEGIN
    SELECT c.ext_cust_order_id, t.intf_dep_order_package_rel_id
      INTO v_ext_cust_order_id, v_order_package_rel_id
      FROM crmv2.intf_dep_order c, crmv2.intf_dep_order_package_rel t
     WHERE t.intf_dep_order_id = c.intf_dep_order_id
       AND c.package_group = v_package_group;
    ------判断是否已有异常记录
    SELECT COUNT(1)
      INTO v_count1
      FROM (SELECT v.intf_dep_finish_id
              FROM crmv2.intf_dep_finish v
             WHERE v.ext_cust_order_id = v_ext_cust_order_id
            UNION ALL
            SELECT intf_dep_finish_id
              FROM crmv2.intf_dep_finish_his v
             WHERE v.ext_cust_order_id = v_ext_cust_order_id);

    SELECT COUNT(1)
      INTO v_count1
      FROM crmv2.intf_dep_finish v
     WHERE v.ext_cust_order_id = v_ext_cust_order_id
       AND v.status_cd = '400000';
    ----已有异常记录，则重写
    IF v_count1 = 0 THEN
      BEGIN
        ----------解析报文，获取订单组id
        DELETE FROM ffpany.购物车流水号_3;
        INSERT INTO ffpany.购物车流水号_3
          SELECT 1 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           1) order_item_group
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id
          UNION ALL
          SELECT 2 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           2) order_item_group
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id
          UNION ALL
          SELECT 3 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           3) order_item_group
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id
          UNION ALL
          SELECT 4 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           4)
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id
          UNION ALL
          SELECT 5 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           5)
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id
          UNION ALL
          SELECT 6 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           6)
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id
          UNION ALL
          SELECT 7 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           7)
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id
          UNION ALL
          SELECT 8 num1,
                 crmv2.pkg_clob_to_str.clob_to_str_single1(c.data_info,
                                                           'ORDER_ITEM_GROUP',
                                                           8)
            FROM crmv2.intf_dep_data_info c
           WHERE c.intf_dep_order_package_rel_id = v_order_package_rel_id;

        BEGIN
          DELETE FROM ffpany.购物车流水号_4;
          FOR m_ IN (SELECT *
                       FROM ffpany.购物车流水号_3
                      WHERE order_item_group IS NOT NULL) LOOP
            INSERT INTO ffpany.购物车流水号_4
              SELECT crmv2.pkg_clob_to_str.clob_to_str_single1(order_item_group,
                                                               'ORDER_ITEM_GROUP_ID',
                                                               1) order_item_group_id,
                     crmv2.pkg_clob_to_str.clob_to_str_single1(order_item_group,
                                                               'GROUP_TYPE',
                                                               1) group_type
                FROM ffpany.购物车流水号_3
               WHERE num1 = m_.num1;
          END LOOP;
        END;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      INSERT INTO crmv2.intf_dep_finish
        SELECT crmv2.seq_intf_dep_finish_id.nextval,
               a.package_group,
               a.ext_cust_order_id,
               '',
               '',
               b.order_item_group_id,
               b.group_type,
               '',
               a.channel_nbr,
               SYSDATE,
               '70B',
               '',
               SYSDATE,
               SYSDATE,
               '1',
               SYSDATE,
               '',
               in_modi_staff || '-撤销过程-pany',
               '400000',
               in_modi_reason
          FROM crmv2.intf_dep_order a, ffpany.购物车流水号_4 b
         WHERE b.group_type IN ('4000', '5000', '6000')
           AND a.ext_cust_order_id = v_ext_cust_order_id;

      UPDATE crmv2.intf_dep_order
         SET state = '70X'
       WHERE ext_cust_order_id = v_ext_cust_order_id
         AND state = '70E';

    ELSE
      UPDATE crmv2.intf_dep_finish v
         SET v.state     = '70B',
             v.status_cd = '400000',
             v.err_desc  = in_modi_reason
       WHERE v.ext_cust_order_id = v_ext_cust_order_id
         AND v.state = '70A';

      UPDATE crmv2.intf_dep_order
         SET state = '70X'
       WHERE ext_cust_order_id = v_ext_cust_order_id
         AND state = '70E';
    END IF;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      o_result := '处理异常！';

      RETURN;
  END;

  PROCEDURE crm_resource_70d(i_mkt_reso_key IN VARCHAR, -- 串码
                             in_modi_man    IN VARCHAR, --修改人
                             in_remark      IN VARCHAR, --修改原因
                             in_ip_address  IN VARCHAR, ---操作ip地址
                             o_result       OUT VARCHAR2) IS
    rec_mkt_reso_id        NUMBER;
    rec_mkt_reso_spec_id   NUMBER;
    rec_storage_id         NUMBER;
    a                      NUMBER;
    rec_state              VARCHAR(10);
    v_count                NUMBER;
    rec_mkt_reso_spec_type NUMBER;
  BEGIN
    SELECT COUNT(1)
      INTO v_count
      FROM (SELECT regexp_substr(i_mkt_reso_key, '[^,]+', 1, LEVEL) mkt_reso_key
              FROM dual
            CONNECT BY LEVEL <= length(i_mkt_reso_key) -
                       length(REPLACE(i_mkt_reso_key, ',')) + 1) a;
    IF v_count > 100 THEN
      o_result := '失败,串码数量大于100个!';
      RETURN;
    END IF;

    FOR rec IN (SELECT regexp_substr(i_mkt_reso_key, '[^,]+', 1, LEVEL) mkt_reso_key
                  FROM dual
                CONNECT BY LEVEL <= length(i_mkt_reso_key) -
                           length(REPLACE(i_mkt_reso_key, ',')) + 1) LOOP

      --只有70A的才可以回退到导入状态.
      SELECT COUNT(1)
        INTO a
        FROM crmv1.mkt_resource
       WHERE mkt_reso_key = rec.mkt_reso_key
         AND state IN ('70A');

      IF a = 1 THEN

        SELECT mkt_reso_spec_type
          INTO rec_mkt_reso_spec_type
          FROM crmv1.mkt_resource
         WHERE mkt_reso_key = rec.mkt_reso_key;

        --非资金平台串码才允许退导入 by fjgaozh
        IF rec_mkt_reso_spec_type NOT IN (63, 65) THEN

          SELECT mkt_reso_id, s.mkt_reso_spec_id, s.storage_id, s.state
            INTO rec_mkt_reso_id,
                 rec_mkt_reso_spec_id,
                 rec_storage_id,
                 rec_state
            FROM crmv1.mkt_resource s
           WHERE mkt_reso_key = rec.mkt_reso_key
             AND state IN ('70A');

          IF rec_state = '70A' THEN
            UPDATE crmv1.mkt_resource
               SET state              = '70D',
                   storage_id         = '',
                   real_modify_date   = SYSDATE,
                   mkt_reso_spec_type = 610009001,
                   mkt_reso_spec_id   = 654080000,
                   state_remark       = state_remark || in_remark
             WHERE mkt_reso_id = rec_mkt_reso_id;

            UPDATE crmv1.mkt_store_item
               SET usage_count      = usage_count - 1,
                   real_modify_date = SYSDATE
             WHERE store_id = rec_storage_id
               AND mkt_reso_spec_id = rec_mkt_reso_spec_id;
             --linc 2016-5-26
             update crmv1.mkt_reso_fea
                set fea_spec_id = 802653150
              where mkt_reso_id = rec_mkt_reso_id
                and fea_spec_id in (620122183, 620122189, 620118275);

            ---记录日志
            INSERT INTO itsc_crmv2.crm_resource_70d_log
            VALUES
              (rec.mkt_reso_key,
               in_modi_man,
               SYSDATE,
               in_remark,
               in_ip_address);
            o_result := '成功,' || o_result;
          END IF;
        ELSE
          o_result := '资金平台串码，无法释放';
        END IF;
      ELSE
        o_result := '无需处理或给的串码不对,' || o_result;
      END IF;

      COMMIT;

    END LOOP;
  END;*/

  PROCEDURE proc_intf_ins_billing_update(i_table_name  itsc_crmv2.intf_ins_billing_update.table_name%TYPE,
                                         i_column_name itsc_crmv2.intf_ins_billing_update.column_name%TYPE,
                                         i_key_id      itsc_crmv2.intf_ins_billing_update.key_id%TYPE,
                                         i_reason      itsc_crmv2.intf_ins_billing_update.reason%TYPE,
                                         i_operator    itsc_crmv2.intf_ins_billing_update.operator%TYPE) IS
    v_his_table_name VARCHAR2(50);
    v_column_name    VARCHAR2(50);
    v_column_name_id VARCHAR2(50);
    v_i_table_name   itsc_crmv2.intf_ins_billing_update.table_name%TYPE;
    v_i_key_id       itsc_crmv2.intf_ins_billing_update.key_id%TYPE;
    v_i_column_name  itsc_crmv2.intf_ins_billing_update.column_name%TYPE;
    TYPE c_type IS REF CURSOR;
    rec c_type;
  BEGIN
    --去掉空格，并转化为大写
    v_i_table_name  := upper(TRIM(i_table_name));
    v_i_key_id      := upper(TRIM(i_key_id));
    v_i_column_name := upper(TRIM(i_column_name));
    -- 判断表是否需要双写
    BEGIN
      /*      SELECT his_table_name, c.column_name
       INTO v_his_table_name, v_column_name
       FROM crmv2.sys_class a, dba_indexes b, dba_ind_columns c
      WHERE a.table_name = v_i_table_name
        AND is_ds IS NOT NULL
        AND a.his_table_name = b.table_name
        AND b.owner = 'CRMV2'
        AND b.uniqueness = 'UNIQUE'
        AND c.index_name = b.index_name
        AND c.table_owner = 'CRMV2'
        AND rownum <= 1;*/

      SELECT his_table_name, column_name
        INTO v_his_table_name, v_column_name
        FROM itsc_crmv2.wh_intf_ins
       WHERE table_name = v_i_table_name;

      -- Dbms_Output.put_line( 'select '||v_COLUMN_NAME||' from '||v_HIS_TABLE_NAME||' where UPDATE_DATE>sysdate-2 and '||I_COLUMN_NAME  );
      IF v_his_table_name = 'CUST_HIS' THEN
        FOR re IN (SELECT his_id FROM cust_his WHERE cust_id = v_i_key_id) LOOP
          INSERT INTO crmv2.intf_ins_ds_update
            (ins_id,
             table_name,
             column_name,
             key_id,
             topic,
             TYPE,
             reason,
             operator,
             state,
             state_date,
             create_date,
             update_date,
             deal_num,
             next_deal_time,
             err_msg,
             remark,
             area_nbr,
             op_type,
             sharding_id)
          VALUES
            (seq_intf_ins_ds_update_id.nextval,
             v_his_table_name,
             v_column_name,
             re.his_id,
             '手工割接',
             '1002',
             i_reason,
             NULL,
             '70A',
             SYSDATE,
             SYSDATE,
             SYSDATE,
             0,
             NULL,
             NULL,
             NULL,
             NULL,
             i_operator,
             NULL);
          COMMIT;
        END LOOP;
      ELSE
        OPEN rec FOR '
       select ' || v_column_name || ' from ' || v_his_table_name || ' where UPDATE_DATE>sysdate-2 and ' || i_column_name || ' =:1'
          USING v_i_key_id;
        LOOP
          FETCH rec
            INTO v_column_name_id;
          EXIT WHEN rec%NOTFOUND;

          INSERT INTO crmv2.intf_ins_ds_update
            (ins_id,
             table_name,
             column_name,
             key_id,
             topic,
             TYPE,
             reason,
             operator,
             state,
             state_date,
             create_date,
             update_date,
             deal_num,
             next_deal_time,
             err_msg,
             remark,
             area_nbr,
             op_type,
             sharding_id)
          VALUES
            (seq_intf_ins_ds_update_id.nextval,
             v_his_table_name,
             v_column_name,
             v_column_name_id,
             '手工割接',
             '1002',
             i_reason,
             NULL,
             '70A',
             SYSDATE,
             SYSDATE,
             SYSDATE,
             0,
             NULL,
             NULL,
             NULL,
             NULL,
             i_operator,
             NULL);
          COMMIT;
        END LOOP;
        COMMIT;
      END IF;

      INSERT INTO crmv2.intf_ins_ds_update
        (ins_id,
         table_name,
         column_name,
         key_id,
         topic,
         TYPE,
         reason,
         operator,
         state,
         state_date,
         create_date,
         update_date,
         deal_num,
         next_deal_time,
         err_msg,
         remark,
         area_nbr,
         op_type,
         sharding_id)
      VALUES
        (seq_intf_ins_ds_update_id.nextval,
         v_i_table_name,
         v_i_column_name,
         v_i_key_id,
         '手工割接',
         '1002',
         i_reason,
         NULL,
         '70A',
         SYSDATE,
         SYSDATE,
         SYSDATE,
         0,
         NULL,
         NULL,
         NULL,
         NULL,
         i_operator,
         NULL);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  END proc_intf_ins_billing_update;

 /* FUNCTION fnc_get_ocs_mutex(i_prod_inst_id IN NUMBER) RETURN VARCHAR2 IS
    v_result VARCHAR2(500);
    v_count1 NUMBER(10) := 0;
    v_count2 NUMBER(10) := 0;
  BEGIN
    SELECT COUNT(*)
      INTO v_count1
      FROM crmv2.prod_inst_rel a, prod_inst b, product p
     WHERE a.prod_inst_a_id = i_prod_inst_id
       AND a.status_cd = '1000'
       AND b.prod_inst_id = a.prod_inst_z_id
       AND b.product_id IN
           ('800761599', '800000048', '800000570', '800000574', '800551836',
            '901052351')
       AND p.product_id = b.product_id;

    SELECT COUNT(*)
      INTO v_count2
      FROM crmv2.prod_inst_rel a, prod_inst b, product p
     WHERE a.prod_inst_z_id = i_prod_inst_id
       AND a.status_cd = '1000'
       AND b.prod_inst_id = a.prod_inst_a_id
       AND b.product_id IN
           ('800000251', '900057529', '800000343', '800299131')
       AND p.product_id = b.product_id;

    IF v_count1 = 0 AND v_count2 = 0 THEN
      SELECT '无互斥业务' INTO v_result FROM dual;
      RETURN(v_result);

    ELSE
      SELECT wm_concat(product_name)
        INTO v_result
        FROM (SELECT p.product_name
                FROM crmv2.prod_inst_rel a, prod_inst b, product p
               WHERE a.prod_inst_a_id = i_prod_inst_id
                 AND a.status_cd = '1000'
                 AND b.prod_inst_id = a.prod_inst_z_id
                 AND b.product_id IN
                     ('800761599', '800000048', '800000570', '800000574',
                      '800551836', '901052351')
                 AND p.product_id = b.product_id
              UNION
              SELECT k.product_name
                FROM crmv2.prod_inst_rel a, prod_inst b, product k
               WHERE a.prod_inst_z_id = i_prod_inst_id
                 AND a.status_cd = '1000'
                 AND b.prod_inst_id = a.prod_inst_a_id
                 AND b.product_id IN
                     ('800000251', '900057529', '800000343', '800299131')
                 AND k.product_id = b.product_id) pir;
      RETURN(v_result);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN(v_result);
  END fnc_get_ocs_mutex;*/

END pkg_wh;
/
