CREATE PACKAGE           pkg_gg_group_data_sync IS

  -- Author  : QIURL
  -- Created : 2013/5/13
  -- Purpose :集团数据增量脚本

  PROCEDURE proc_data_sync;

  --同步 CUST 表数据
  PROCEDURE proc_bus26001_r(in_batch_nbr VARCHAR2);

END pkg_gg;
/
