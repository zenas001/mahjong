CREATE PACKAGE           PKG_DEP_MAINTAIN IS
  /*-------------------------------------------------
    INTF_DEP_ORDER
    Author  : OUZHF
    Created : 2014-03-13
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_DEP_ORDER_HIS;

  /*-------------------------------------------------
    INTF_DEP_FINISH
    Author  : OUZHF
    Created : 2014-03-13
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_DEP_FINISH_HIS;

  /*-------------------------------------------------
    PROC_DOC_INFO
    Author  : zhegnchb
    Created : 2015-11-30
  -------------------------------------------------*/
  PROCEDURE PROC_DOC_INFO;

END PKG_DEP_MAINTAIN;
/
