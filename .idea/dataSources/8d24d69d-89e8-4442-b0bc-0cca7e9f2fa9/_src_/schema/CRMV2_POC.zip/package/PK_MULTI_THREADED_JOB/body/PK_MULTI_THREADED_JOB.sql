CREATE PACKAGE BODY           PK_MULTI_THREADED_JOB IS
  --空过程  用于子线程JOB创建后的默认执行过程
  PROCEDURE PRO_NULL AS
  BEGIN
    NULL;
  END;
  --判断是否还有空闲的JOB可以使用  有则返回JOB编号，没有则返回空
  FUNCTION FUN_ISHAVANULLJOB RETURN NUMBER IS
    IRESULT NUMBER := NULL;
    I_CON   NUMBER := 0;
  BEGIN
    SELECT COUNT(1) INTO I_CON FROM ZZH_JOB_INFO;
    IF (I_CON > 0) THEN
      SELECT M.JOB_NUMBER
        INTO IRESULT
        FROM ZZH_JOB_INFO M
       WHERE M.ISBUSY = 0
         AND ROWNUM < 2;
      RETURN IRESULT;
    ELSE
      --如果没有记录，初始化一个job
      INIT_JOB(1);
      IRESULT := FUN_ISHAVANULLJOB;
      RETURN IRESULT;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;
  /**
  写入日志的job任务表的函数
  OPFLAG 表示操作模式  ADD =INSERT MOD=UPDATE DEL=DELETE
  */
  FUNCTION F_WRITE_ZZH_JOB_INFO(OPFLAG VARCHAR2, JOB_ID NUMBER,
                                I_ISBUSY NUMBER DEFAULT 'null')
    RETURN BOOLEAN IS
  BEGIN
    IF UPPER(OPFLAG) = 'ADD' THEN
      INSERT INTO ZZH_JOB_INFO
        (JOB_NUMBER, CREATE_TIME)
      VALUES
        (JOB_ID, SYSDATE);
    ELSIF UPPER(OPFLAG) = 'MOD' THEN
      UPDATE ZZH_JOB_INFO SET ISBUSY = I_ISBUSY WHERE JOB_NUMBER = JOB_ID;
    ELSIF UPPER(OPFLAG) = 'DEL' THEN
      DELETE ZZH_JOB_INFO WHERE JOB_NUMBER = JOB_ID;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;

  FUNCTION F_WRITE_ZZH_TASK_LOG(OPFLAG VARCHAR2, I_ID NUMBER,
                                I_TASK_ID NUMBER, I_JOB_ID NUMBER,
                                I_STATUS NUMBER,
                                I_SQL VARCHAR2 DEFAULT 'null',
                                I_MSG VARCHAR2 DEFAULT 'null') RETURN BOOLEAN IS
  BEGIN
    IF UPPER(OPFLAG) = 'ADD' THEN

      INSERT INTO ZZH_TASK_LOG
        (ID, BEGIN_TIME, STATUS, TASK_ID, JOB_ID, EXEC_SQL, MSG)
      VALUES
        (I_ID, SYSDATE, I_STATUS, I_TASK_ID, I_JOB_ID, I_SQL, I_MSG);
    ELSIF UPPER(OPFLAG) = 'MOD' THEN
      UPDATE ZZH_TASK_LOG
         SET STATUS = I_STATUS, END_TIME = SYSDATE, MSG = I_MSG
       WHERE ID = I_ID;
    ELSIF UPPER(OPFLAG) = 'DEL' THEN
      DELETE ZZH_TASK_LOG WHERE ID = I_ID;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;
  /**
  *对ZZH_TASK_CFG操作
  *OPFLAG 表示操作模式  ADD =INSERT MOD=UPDATE DEL=DELETE
  *参数：STARZZH_TYPE--启动类型 0 定时启动  1 人工启动
  *add by zhengzhh 20130207
  */
  FUNCTION F_WRITE_ZZH_TASK_LIST(OPFLAG VARCHAR2, I_ID NUMBER,
                                 I_JOB_ID NUMBER DEFAULT 'null',
                                 I_STATE NUMBER, I_SQL VARCHAR2,
                                 I_STARZZH_TYPE NUMBER DEFAULT 'null',
                                 I_EXECDATE DATE) RETURN BOOLEAN IS
  BEGIN
    IF UPPER(OPFLAG) = 'ADD' THEN
      INSERT INTO ZZH_TASK_LIST
        (ID, STATE, JOB_ID, EXECSQL, START_TYPE, EXECDATE)
      VALUES
        (I_ID, 0, I_JOB_ID, I_SQL, I_STARZZH_TYPE, I_EXECDATE);
    ELSIF UPPER(OPFLAG) = 'MOD' THEN
      UPDATE ZZH_TASK_LIST
         SET STATE = I_STATE, JOB_ID = I_JOB_ID, FINISH_DATE = SYSDATE
       WHERE ID = I_ID;
    ELSIF UPPER(OPFLAG) = 'DEL' THEN
      DELETE ZZH_TASK_LIST WHERE ID = I_ID;
    END IF;
    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;
  --寻找最先提交的还没有启动的任务 有则返回ID，没有则返回空...
  FUNCTION F_ISHAVEAUTOTASK RETURN NUMBER IS
    IRESULT NUMBER := NULL;
  BEGIN
    --判断任务列表里为自动启动类型数据
    SELECT T.ID
      INTO IRESULT
      FROM (SELECT ID
               FROM ZZH_TASK_LIST M
              WHERE M.START_TYPE = 0
              ORDER BY ID ASC) T
     WHERE ROWNUM < 2;
    RETURN IRESULT;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;
  /**
  *检查语句的有效性,并返回错误信息
  *参数：I_JOB_ID:任务ID  *I_SQL 需要检查的sql语句
  *O_RESULT 反馈验证成功和失败  *O_MSG 反馈错误信息描述
  *add by zhengzhh 20130219
  */
  PROCEDURE PRO_VALIDITY_OF_SQL(I_JOB_ID NUMBER, I_SQL VARCHAR2,
                                O_RESULT OUT BOOLEAN, O_MSG OUT VARCHAR2) IS

    V_RESULT     BOOLEAN;
    V_MSG        VARCHAR2(1000);
    V_P_NAME     VARCHAR2(30) := 'ZZH_TEST_' || I_JOB_ID;
    V_CREATE_PRO VARCHAR2(4000) := 'CREATE PROCEDURE ' || V_P_NAME ||
                                   ' IS BEGIN ' || I_SQL || 'END ' ||
                                   V_P_NAME || ';';
    V_DROP_PRO   VARCHAR2(50) := 'DROP PROCEDURE ' || V_P_NAME;
  BEGIN
    BEGIN
      EXECUTE IMMEDIATE (V_CREATE_PRO);
      V_RESULT := TRUE;
      V_MSG    := 'SUCCESS';
      --效验成功了才删除，如果错误先留着查问题
      EXECUTE IMMEDIATE (V_DROP_PRO);
    EXCEPTION
      WHEN OTHERS THEN
        V_RESULT := FALSE;
        SELECT 'ERROR_PRO:' || V_P_NAME || CHR(10) ||
                SUBSTR(TO_CHAR(WM_CONCAT(TEXT)), 1, 1000)
          INTO V_MSG
          FROM USER_ERRORS
         WHERE NAME = V_P_NAME
           AND ATTRIBUTE = 'ERROR'
         ORDER BY SEQUENCE ASC;
    END;
    O_RESULT := V_RESULT;
    O_MSG    := V_MSG;
  END;
  /**
  *读取任务日志，只处理自动类型的任务
  * add by zhengzhh 20130207
  */
  PROCEDURE PRO_EXEC_AUTO_TASK IS
    V_SQL       VARCHAR2(4000);
    V_EXEC_DATE DATE;
    V_TASK_ID   NUMBER;
    MSG         VARCHAR2(2000) := NULL;
  BEGIN
    V_TASK_ID := F_ISHAVEAUTOTASK;
    WHILE V_TASK_ID IS NOT NULL LOOP
      BEGIN
        SELECT EXECSQL, EXECDATE
          INTO V_SQL, V_EXEC_DATE
          FROM ZZH_TASK_LIST
         WHERE ID = V_TASK_ID;
        PRO_JOB_SCHEDULE_MAIN(V_TASK_ID, V_SQL, V_EXEC_DATE);
        V_TASK_ID := F_ISHAVEAUTOTASK;
      EXCEPTION
        WHEN OTHERS THEN
          MSG := SUBSTR(SQLERRM, 1, 500);
          DBMS_OUTPUT.PUT_LINE('ERROR:' || MSG);
      END;
    END LOOP;
  END;

  /**
  *读取任务日志，只处理手动类型的任务
  * add by zhengzhh 20130207
  *参数：I_TASK_ID 任务id;I_EXEC_DATE 执行时间 为空时，当前时间加30s
  */
  PROCEDURE PRO_EXEC_MANUAL_TASK(I_TASK_ID NUMBER,
                                 I_EXEC_DATE DATE DEFAULT 'null') IS
    V_SQL       VARCHAR2(4000);
    V_EXEC_DATE DATE := I_EXEC_DATE;
    V_TASK_ID   NUMBER := I_TASK_ID;
    MSG         VARCHAR2(2000) := NULL;
  BEGIN
    IF V_TASK_ID IS NOT NULL THEN
      BEGIN
        IF V_EXEC_DATE IS NULL THEN
          --如果I_EXEC_DATE is空的，执行时间按照当前时间加30s，
          --30s是为了缓冲系统延迟，造成执行不成功。
          V_EXEC_DATE := SYSDATE + 30 / 24 / 3600;
        END IF;
        SELECT EXECSQL INTO V_SQL FROM ZZH_TASK_LIST WHERE ID = V_TASK_ID;
        PRO_JOB_SCHEDULE_MAIN(V_TASK_ID, V_SQL, V_EXEC_DATE);
      EXCEPTION
        WHEN OTHERS THEN
          MSG := SUBSTR(SQLERRM, 1, 500);
          DBMS_OUTPUT.PUT_LINE('ERROR:' || MSG);
      END;
    END IF;
  END;
  /**
  *通过外围调用传入参数，实现参数中需要执行的语句与job捆绑
  *add by zhengzhh  2013-02-01
  *I_EXEC_SQL 传入sql语句，存储过程，函数等
  *I_NEXT_DATE 传入指定执行时间
  */
  PROCEDURE PRO_JOB_SCHEDULE_MAIN(I_TASK_ID NUMBER, I_EXEC_SQL VARCHAR2,
                                  I_NEXT_DATE DATE) IS
    JOB_NUM_NO BINARY_INTEGER := 0;
    PEXECSQL   VARCHAR2(4000) := NULL;
    V_LOG_ID   NUMBER(12) := SEQ_ZZH_TASK_LOG_ID.NEXTVAL;
    V_TASK_ID  NUMBER(12) := I_TASK_ID;
    V_MSG      VARCHAR2(1024) := NULL;
    V_EXEC_SQL VARCHAR2(1024) := I_EXEC_SQL;
    ISTRUE     BOOLEAN;
    D_NEXTDATE DATE := I_NEXT_DATE;
  BEGIN
    JOB_NUM_NO := FUN_ISHAVANULLJOB;
    IF JOB_NUM_NO IS NOT NULL THEN
      --初始任务列表
      ISTRUE := F_WRITE_ZZH_TASK_LOG('ADD', V_LOG_ID, V_TASK_ID, JOB_NUM_NO,
                                     1, V_EXEC_SQL, 'RUNNING');
      ISTRUE := F_WRITE_ZZH_JOB_INFO('MOD', JOB_NUM_NO, 1);
      COMMIT;
      --检查传入SQL语句的有效性
      BEGIN
        --拼接用于执行的job捆绑语句，都通过PRO_JOB_EXECUTE_MAIN该存储过程执行
        --将需要执行的语句进行拼接 语句开头和结尾不需要引号
        /*  PEXECSQL := 'DECLARE BEGIN PK_MULTI_THREADED_JOB.PRO_JOB_EXECUTE_MAIN(''' ||
        V_EXEC_SQL || ''',' || JOB_NUM_NO || ',' || V_LOG_ID ||
        '); END;';*/

        --改用dbms_job.broken函数，防止JOB出错之后无法重新启动
        DBMS_JOB.WHAT(JOB_NUM_NO, V_EXEC_SQL);
        DBMS_JOB.BROKEN(JOB_NUM_NO, FALSE, D_NEXTDATE);
        COMMIT;
        ---JOB_NUM_NO := NULL;
        /*      EXCEPTION
        WHEN OTHERS THEN
          V_MSG := 'ERROR:' || SUBSTR(SQLERRM, 1, 2000);
          DBMS_OUTPUT.PUT_LINE(V_MSG);
          ROLLBACK;
          ISTRUE := F_WRITE_ZZH_TASK_LOG('MOD', V_LOG_ID, V_TASK_ID,
                                         JOB_NUM_NO, 3, V_EXEC_SQL, V_MSG);
          COMMIT;*/
      END;
    ELSE
      ISTRUE := F_WRITE_ZZH_TASK_LOG('ADD', V_LOG_ID, V_TASK_ID, '0', 3,
                                     V_EXEC_SQL, '错误:系统无空闲的任务,请检查任务执行情况。');
      COMMIT;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      V_MSG    := 'ERROR:' || SUBSTR(SQLERRM, 1, 2000);
      PEXECSQL := 'SQL IS ERROR:' || PEXECSQL;
      DBMS_OUTPUT.PUT_LINE(V_MSG);
      ROLLBACK;
      ISTRUE := F_WRITE_ZZH_TASK_LOG('MOD', V_LOG_ID, V_TASK_ID, JOB_NUM_NO,
                                     3, PEXECSQL, V_MSG);
      ISTRUE := F_WRITE_ZZH_JOB_INFO('MOD', JOB_NUM_NO, 0);
      COMMIT;
  END;

  /**
  *子线程 执行过程
  *所有与job捆绑的语句，都通过该存储过程执行
  *add by zhengzhh  2013-02-01
  *EXEC_SQL 传入sql语句，存储过程，函数等
  *PJOBNUM 传入JOB 唯一标识id
  *TSEK_ID 传入任务日志表主键
  */
  PROCEDURE PRO_JOB_EXECUTE_MAIN(EXEC_SQL VARCHAR2, PJOBNUM NUMBER,
                                 I_LOG_ID NUMBER) IS
    V_MSG  VARCHAR2(2000) := NULL;
    ISTRUE BOOLEAN;
  BEGIN
    --执行语句
    EXECUTE IMMEDIATE (EXEC_SQL);
    --成功后回写日志
    ISTRUE := F_WRITE_ZZH_TASK_LOG('MOD', I_LOG_ID, '', PJOBNUM, 2, EXEC_SQL,
                                   'SUCCESS');
    ISTRUE := F_WRITE_ZZH_JOB_INFO('MOD', PJOBNUM, 0);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_MSG := SUBSTR(SQLERRM, 1, 2000);
      --失败后回写日志
      ISTRUE := F_WRITE_ZZH_TASK_LOG('MOD', I_LOG_ID, '', PJOBNUM, 3,
                                     EXEC_SQL, V_MSG);
      ISTRUE := F_WRITE_ZZH_JOB_INFO('MOD', PJOBNUM, 0);
      COMMIT;
  END;
  /**
    *子线程 执行过程 动态sql，取模方式update分片键字段
    *所有与job捆绑的语句，都通过该存储过程执行
    *add by zhengzhh  2016-11-07
    *I_TASK_ID 任务id
    *I_TABLE_NAME 表名
    *I_PARIMY_COL 表对应主键
    *I_PARTITION 分区名称
  */
  PROCEDURE P_UPDATE_SHARDING(I_TASK_ID NUMBER, I_TABLE_NAME VARCHAR2,
                              I_PARIMY_COL VARCHAR2,
                              I_PARTITION VARCHAR2 DEFAULT 'null') IS
    I_JOB    NUMBER := 0;
    I_LOG_ID NUMBER := 0;
    --  I_TASK_ID    NUMBER := 4;
    --  I_TABLE_NAME VARCHAR2(30) := 'BATCH_ORDER_REL';
    --  I_PARIMY_COL VARCHAR2(30) := 'BATCH_ORDER_ID';
    --  I_MOD_NUM   NUMBER := 1;
    --  I_MOD_TOTAL NUMBER := 100;
    IFS BOOLEAN;
  BEGIN
    I_LOG_ID := SEQ_ZZH_TASK_LIST_ID.NEXTVAL;
    DBMS_JOB.SUBMIT(JOB => I_JOB,
                    WHAT => 'DECLARE
  V_MSG    VARCHAR2(4000);
  ISF BOOLEAN;
CURSOR cur IS select *from  ZZH_' || I_TABLE_NAME || ' ' ||
                             I_PARTITION || ' ;
  TYPE rec IS TABLE OF ZZH_' || I_TABLE_NAME ||
                             '%ROWTYPE;
  recs rec;
BEGIN
  OPEN cur;
  WHILE (TRUE) LOOP
    FETCH cur BULK COLLECT
      INTO recs LIMIT 10000;
FORALL i IN 1 .. recs.COUNT
     UPDATE CRMV2.' || I_TABLE_NAME ||
                             ' SET SHARDING_ID=recs(I).SHARDING_ID WHERE ' ||
                             I_PARIMY_COL || '=recs(I).' || I_PARIMY_COL || ';
    COMMIT;
    EXIT WHEN cur%NOTFOUND;
END LOOP;
  CLOSE cur;
   ISF:=PK_MULTI_THREADED_JOB.F_WRITE_ZZH_TASK_LOG(''MOD'',
                        ' || I_LOG_ID || ',' ||
                             I_TASK_ID || ',' || I_JOB ||
                             ',2,'''',''SUCCESS'');
  COMMIT;
EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_MSG := SUBSTR(SQLERRM, 1, 2000);
      ISF:=PK_MULTI_THREADED_JOB.F_WRITE_ZZH_TASK_LOG(''MOD'',
                        ' || I_LOG_ID || ',' ||
                             I_TASK_ID || ',' || I_JOB || ',3,'''',V_MSG);
     COMMIT;
  END;', NEXT_DATE => SYSDATE + 30 / 24 / 3600);
    SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(I_JOB));
    IFS := PK_MULTI_THREADED_JOB.F_WRITE_ZZH_TASK_LOG('ADD', I_LOG_ID,
                                                      I_TASK_ID, I_JOB, 1, '',
                                                      'STARTING');
    COMMIT;
  END;

  PROCEDURE P_UPDATE_REL_SHARDING(I_TASK_ID NUMBER, I_TABLE_NAME VARCHAR2,
                                  I_PARIMY_COL VARCHAR2,
                                  I_PARTITION VARCHAR2 DEFAULT 'null') IS
    I_JOB    NUMBER := 0;
    I_LOG_ID NUMBER := 0;
    --  I_TASK_ID    NUMBER := 4;
    --  I_TABLE_NAME VARCHAR2(30) := 'BATCH_ORDER_REL';
    --  I_PARIMY_COL VARCHAR2(30) := 'BATCH_ORDER_ID';
    --  I_MOD_NUM   NUMBER := 1;
    --  I_MOD_TOTAL NUMBER := 100;
    IFS BOOLEAN;
  BEGIN
    I_LOG_ID := SEQ_ZZH_TASK_LIST_ID.NEXTVAL;
    DBMS_JOB.SUBMIT(JOB => I_JOB,
                    WHAT => 'DECLARE
  V_MSG    VARCHAR2(4000);
  ISF BOOLEAN;
CURSOR cur IS select *from  ZZH_' || I_TABLE_NAME || ' ' ||
                             I_PARTITION || ' ;
  TYPE rec IS TABLE OF ZZH_' || I_TABLE_NAME ||
                             '%ROWTYPE;
  recs rec;
BEGIN
  OPEN cur;
  WHILE (TRUE) LOOP
    FETCH cur BULK COLLECT
      INTO recs LIMIT 10000;
FORALL i IN 1 .. recs.COUNT
     UPDATE CRMV2.' || I_TABLE_NAME ||
                             ' SET SHARDING_ID=recs(I).SHARDING_ID WHERE ' ||
                             I_PARIMY_COL || '=recs(I).' || I_PARIMY_COL || ';
    COMMIT;
    EXIT WHEN cur%NOTFOUND;
END LOOP;
  CLOSE cur;
   ISF:=PK_MULTI_THREADED_JOB.F_WRITE_ZZH_TASK_LOG(''MOD'',
                        ' || I_LOG_ID || ',' ||
                             I_TASK_ID || ',' || I_JOB ||
                             ',2,'''',''SUCCESS'');
  COMMIT;
EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_MSG := SUBSTR(SQLERRM, 1, 2000);
      ISF:=PK_MULTI_THREADED_JOB.F_WRITE_ZZH_TASK_LOG(''MOD'',
                        ' || I_LOG_ID || ',' ||
                             I_TASK_ID || ',' || I_JOB || ',3,'''',V_MSG);
     COMMIT;
  END;', NEXT_DATE => SYSDATE + 30 / 24 / 3600);
    SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(I_JOB));
    IFS := PK_MULTI_THREADED_JOB.F_WRITE_ZZH_TASK_LOG('ADD', I_LOG_ID,
                                                      I_TASK_ID, I_JOB, 1, '',
                                                      'STARTING');
    COMMIT;
  END;

  /**  INIZZH_JOB
  *用于初始job，捆绑一个空的存储过程
  *add by zhengzhh  2013-02-01
  *MAX_JOB_INSTANCE 定义需要初始化多少job
  */
  PROCEDURE INIT_JOB(MAX_JOB_INSTANCE NUMBER) IS
    PJOB_CNT    NUMBER;
    I           NUMBER := 0;
    PJOB_NUM    NUMBER := NULL;
    MAX_JOB_NUM NUMBER := MAX_JOB_INSTANCE;
    I_ISTRUE    BOOLEAN;
  BEGIN
    --包初始化脚本
    --初始化JOB信息
    SELECT COUNT(1) INTO PJOB_CNT FROM ZZH_JOB_INFO;
    IF PJOB_CNT < MAX_JOB_NUM THEN
      FOR I IN 1 .. MAX_JOB_NUM - PJOB_CNT LOOP
        --子线程JOB的时间间隔调整为3560(10年)，理论上不会自动执行
        DBMS_JOB.SUBMIT(PJOB_NUM, 'PK_MULTI_THREADED_JOB.PRO_NULL;',
                        SYSDATE, 'SYSDATE+3560');
        I_ISTRUE := F_WRITE_ZZH_JOB_INFO('ADD', PJOB_NUM, 0);
      END LOOP;
    END IF;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('JOB INIT SUCCESS......');
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('OCCER ERRORS,JOB INIT FAILURE...');
  END;
  --回收job
  --每次操作完，记得回收job
  PROCEDURE REMOVE_JOB IS
    PJOB_CNT NUMBER := 0;
    I        NUMBER := 0;
    PJOB_NUM NUMBER := NULL;
    I_ISTRUE BOOLEAN;
  BEGIN
    --工作结束后，删除job
    SELECT COUNT(1) INTO PJOB_CNT FROM ZZH_JOB_INFO WHERE ISBUSY = 0;
    IF PJOB_CNT > 0 THEN
      FOR I IN 1 .. PJOB_CNT LOOP
        SELECT JOB_NUMBER
          INTO PJOB_NUM
          FROM (SELECT JOB_NUMBER
                   FROM ZZH_JOB_INFO
                  WHERE ISBUSY = 0
                  ORDER BY JOB_NUMBER ASC)
         WHERE ROWNUM < 2;
        I_ISTRUE := F_WRITE_ZZH_JOB_INFO('DEL', PJOB_NUM);
        COMMIT;
        DBMS_JOB.REMOVE(PJOB_NUM);
      END LOOP;
      COMMIT;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('OCCER ERRORS,JOB INIT FAILURE...');
  END;

END PK_MULTI_THREADED_JOB;
/
