CREATE PACKAGE           PKG_AUTOTEST_DATA_TRANS IS

  -- Author  : ZHENGZHH
  -- Created : 2017/3/7 16:47:30
  -- Purpose : 自动测试数据转换
  /*----------------------------------------------------------------------------
    -- 背景
    -- 实现现网受理的订单，通过接口提供的相关表，实现在CRM3.0中自动受理
  ------------------------------------------------------------------------------*/
  -- Public type declarations
  -- type <TypeName> is <Datatype>;

  -- Public constant declarations
  -- <ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  -- <VariableName> <Datatype>;

  -- Public function and procedure declarations
  -- function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;
  --记录日志
  PROCEDURE WRITE_LOG(IN_TAB_ID IN NUMBER, IN_PROC_NAME IN VARCHAR2,
                      IN_PROC_TABLE IN VARCHAR2, IN_LOG_TYPE VARCHAR2,
                      IN_MSG VARCHAR2);
  --客户订单表数据转换 过滤接口创建单
  PROCEDURE CUST_ORDER_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --客户信息数据转换
  PROCEDURE CUST_TRANS(I_CUST_ORDER_ID IN NUMBER, ACTION_TYPE IN VARCHAR);
  --账户信息数据转换
  PROCEDURE ACCOUNT_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --T05销售品数据转换
  PROCEDURE T05_OFFER_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --销售品数据转换
  PROCEDURE OFFER_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --基础产品数据转换
  PROCEDURE T01_PROD_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --功能产品数据转换
  PROCEDURE T02_PROD_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --账务定制关系数据转换
  PROCEDURE PROD_INST_ACCT_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --营销资源数据转换
  PROCEDURE MKT_RESOUCE_TRANS(I_CUST_ORDER_ID IN NUMBER);
  --解析order_item.CLASS_ID 和 order_item.service_offer_id 分解执行
  FUNCTION GET_PROC_NAME(I_ORDER_TIEM_ID IN NUMBER) RETURN VARCHAR2;
  --通过动态SQL调用存储过程
  PROCEDURE EXEC_DATA_TRANS(I_TRANS_NAME IN VARCHAR2,
                            I_ORDER_ITEM_ID IN NUMBER,
                            I_ACTION_TYPE IN VARCHAR2);
END PKG_AUTOTEST_DATA_TRANS;
/
