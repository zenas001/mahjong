CREATE PACKAGE BODY           PKG_NEW_REAL_CERT_JOB IS

  PROCEDURE PROC_NEW_REAL_CERT IS

    N_PROD_INST_COUNT NUMBER;
    V_ERROR_MSG       VARCHAR2(2000);
    v_his_id          PROD_INST_ATTR_HIS.HIS_ID%TYPE; --订单id
    CURSOR CUST IS
      select c.cust_id, rownum
        from cust c, cust_external_attr ca
       where c.cust_id = ca.cust_id
         and ca.attr_id = 950023250
         and ca.status_cd in ('1299', '1000')
         and ca.attr_value = '1'
         and ca.update_date >
             TO_DATE(to_char(sysdate - 1, 'yyyy-mm-dd'), 'yyyy-mm-dd')
         and ca.update_date <
             TO_DATE(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd');

  BEGIN
    FOR CUR IN CUST LOOP
      BEGIN

        for cur_PROD_INST in (select pi.prod_inst_id, pi.owner_cust_id
                                from prod_inst pi, product p
                               where use_cust_id = CUR.cust_id
                                 and pi.product_id = p.product_id
                                 and p.prod_func_type = '101'
                                 and acc_nbr is not null) loop

          select count(1)
            INTO N_PROD_INST_COUNT
            from prod_inst_attr pia
           where pia.prod_inst_id = cur_prod_inst.prod_inst_id
             and pia.attr_id = 950023254;
          if N_PROD_INST_COUNT > 0 then
            BEGIN
              SELECT seq_prod_inst_attr_his_id.nextval
                INTO v_his_id
                FROM dual;
              for cur_PROD_INST_ATTR in (select *
                                           from PROD_INST_ATTR pia
                                          where pia.prod_inst_id =
                                                cur_prod_inst.prod_inst_id
                                            and pia.attr_id = 950023254) loop
                insert into PROD_INST_ATTR_HIS
                  (PROD_INST_ATTR_ID,
                   PROD_INST_ID,
                   ATTR_ID,
                   ATTR_VALUE_ID,
                   ATTR_VALUE,
                   STATUS_CD,
                   STATUS_DATE,
                   EFF_DATE,
                   EXP_DATE,
                   CREATE_DATE,
                   UPDATE_DATE,
                   PROC_SERIAL,
                   AREA_ID,
                   REGION_CD,
                   UPDATE_STAFF,
                   CREATE_STAFF,
                   REC_UPDATE_DATE,
                   VERSION,
                   HIS_ID)
                  (select cur_PROD_INST_ATTR.PROD_INST_ATTR_ID,
                          cur_PROD_INST_ATTR.PROD_INST_ID,
                          cur_PROD_INST_ATTR.ATTR_ID,
                          cur_PROD_INST_ATTR.ATTR_VALUE_ID,
                          cur_PROD_INST_ATTR.ATTR_VALUE,
                          cur_PROD_INST_ATTR.STATUS_CD,
                          cur_PROD_INST_ATTR.STATUS_DATE,
                          cur_PROD_INST_ATTR.EFF_DATE,
                          cur_PROD_INST_ATTR.EXP_DATE,
                          cur_PROD_INST_ATTR.CREATE_DATE,
                          cur_PROD_INST_ATTR.UPDATE_DATE,
                          cur_PROD_INST_ATTR.PROC_SERIAL,
                          cur_PROD_INST_ATTR.AREA_ID,
                          cur_PROD_INST_ATTR.REGION_CD,
                          cur_PROD_INST_ATTR.UPDATE_STAFF,
                          cur_PROD_INST_ATTR.CREATE_STAFF,
                          cur_PROD_INST_ATTR.UPDATE_DATE,
                          cur_PROD_INST_ATTR.VERSION,
                          v_his_id
                     from dual);
                ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS',
                                             'HIS_ID',
                                             v_his_id,
                                             'PKG_NEW_REAL_CERT_JOB',
                                             cur_PROD_INST_ATTR.CREATE_STAFF,
                                             'CREATE',
                                             cur_PROD_INST.owner_cust_id);
                delete from prod_inst_attr pia
                 where pia.PROD_INST_ATTR_ID =
                       cur_PROD_INST_ATTR.PROD_INST_ATTR_ID;
                ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR',
                                             'PROD_INST_ATTR_ID',
                                             cur_PROD_INST_ATTR.PROD_INST_ATTR_ID,
                                             'PKG_NEW_REAL_CERT_JOB',
                                             cur_PROD_INST_ATTR.CREATE_STAFF,
                                             'DELETE',
                                             cur_PROD_INST.owner_cust_id);
              end loop;
            EXCEPTION
              WHEN OTHERS THEN
                ROLLBACK;
                V_ERROR_MSG := SUBSTR(SQLERRM, 0, 1000);
                INSERT INTO circle_info ci
                  (circle_info_ID,
                   OBJ_INST_ID,
                   CLASS_ID,
                   REMARK,
                   CREATE_DATE)
                VALUES
                  (seq_circle_info_id.NEXTVAL,
                   cur_prod_inst.prod_inst_id,
                   4,
                   V_ERROR_MSG,
                   SYSDATE);
                COMMIT;
            END;

          end if;

          select count(1)
            INTO N_PROD_INST_COUNT
            from prod_inst_attr pia
           where pia.prod_inst_id = cur_prod_inst.prod_inst_id
             and pia.attr_id = 950027456;
          if N_PROD_INST_COUNT > 0 then
            BEGIN
              SELECT seq_prod_inst_attr_his_id.nextval
                INTO v_his_id
                FROM dual;
              for cur_PROD_INST_ATTR in (select *
                                           from PROD_INST_ATTR pia
                                          where pia.prod_inst_id =
                                                cur_prod_inst.prod_inst_id
                                            and pia.attr_id = 950027456) loop
                insert into PROD_INST_ATTR_HIS
                  (PROD_INST_ATTR_ID,
                   PROD_INST_ID,
                   ATTR_ID,
                   ATTR_VALUE_ID,
                   ATTR_VALUE,
                   STATUS_CD,
                   STATUS_DATE,
                   EFF_DATE,
                   EXP_DATE,
                   CREATE_DATE,
                   UPDATE_DATE,
                   PROC_SERIAL,
                   AREA_ID,
                   REGION_CD,
                   UPDATE_STAFF,
                   CREATE_STAFF,
                   REC_UPDATE_DATE,
                   VERSION,
                   HIS_ID)
                  (select cur_PROD_INST_ATTR.PROD_INST_ATTR_ID,
                          cur_PROD_INST_ATTR.PROD_INST_ID,
                          cur_PROD_INST_ATTR.ATTR_ID,
                          cur_PROD_INST_ATTR.ATTR_VALUE_ID,
                          cur_PROD_INST_ATTR.ATTR_VALUE,
                          cur_PROD_INST_ATTR.STATUS_CD,
                          cur_PROD_INST_ATTR.STATUS_DATE,
                          cur_PROD_INST_ATTR.EFF_DATE,
                          cur_PROD_INST_ATTR.EXP_DATE,
                          cur_PROD_INST_ATTR.CREATE_DATE,
                          cur_PROD_INST_ATTR.UPDATE_DATE,
                          cur_PROD_INST_ATTR.PROC_SERIAL,
                          cur_PROD_INST_ATTR.AREA_ID,
                          cur_PROD_INST_ATTR.REGION_CD,
                          cur_PROD_INST_ATTR.UPDATE_STAFF,
                          cur_PROD_INST_ATTR.CREATE_STAFF,
                          cur_PROD_INST_ATTR.UPDATE_DATE,
                          cur_PROD_INST_ATTR.VERSION,
                          v_his_id
                     from dual);
                ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS',
                                             'HIS_ID',
                                             v_his_id,
                                             'PKG_NEW_REAL_CERT_JOB',
                                             cur_PROD_INST_ATTR.CREATE_STAFF,
                                             'CREATE',
                                             cur_PROD_INST.owner_cust_id);
                delete from prod_inst_attr pia
                 where pia.PROD_INST_ATTR_ID =
                       cur_PROD_INST_ATTR.PROD_INST_ATTR_ID;
                ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR',
                                             'PROD_INST_ATTR_ID',
                                             cur_PROD_INST_ATTR.PROD_INST_ATTR_ID,
                                             'PKG_NEW_REAL_CERT_JOB',
                                             cur_PROD_INST_ATTR.CREATE_STAFF,
                                             'DELETE',
                                             cur_PROD_INST.owner_cust_id);
              end loop;
            EXCEPTION
              WHEN OTHERS THEN
                ROLLBACK;
                V_ERROR_MSG := SUBSTR(SQLERRM, 0, 1000);
                INSERT INTO circle_info ci
                  (circle_info_ID,
                   OBJ_INST_ID,
                   CLASS_ID,
                   REMARK,
                   CREATE_DATE)
                VALUES
                  (seq_circle_info_id.NEXTVAL,
                   cur_prod_inst.prod_inst_id,
                   4,
                   V_ERROR_MSG,
                   SYSDATE);
                COMMIT;
            END;

          end if;


        END LOOP;
      END;

      COMMIT;
    END LOOP;
  END;

END PKG_NEW_REAL_CERT_JOB;
/
