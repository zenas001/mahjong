CREATE PACKAGE           pkg_wh IS
  -----2013.02.17 备份表记录新增--by lud
  --

  PROCEDURE new_p_ins_billing_update(i_table_name  IN VARCHAR2,
                                     i_column_name IN VARCHAR2,
                                     i_key_id      IN NUMBER,
                                     i_remark      IN VARCHAR2,
                                     in_modi_staff IN VARCHAR2,
                                     o_msg         OUT VARCHAR2);
  ----  在用表1表进历史表
 /* PROCEDURE table_1_to_his(in_table  IN VARCHAR2,
                           in_key    IN VARCHAR2,
                           in_reason IN VARCHAR2,
                           in_staff  IN VARCHAR2,
                           in_exp    IN VARCHAR2,
                           o_result  OUT VARCHAR2);

  --  可选包从拆除拉回在用
  PROCEDURE prod_offer_inst_his_to_1(in_inst_id IN NUMBER,
                                     in_exp     IN VARCHAR2,
                                     in_reason  IN VARCHAR2,
                                     in_staff   IN VARCHAR2,
                                     o_result   OUT VARCHAR2);

  --功　　能：增加产品特性，已经存在的按照新的参数更新
  --创建时间：2012-8-14
  --开山始祖：lud
  --参    数：
  \*
  IN_PRODINST : prod_inst_id
  IN_ATTR_SPEC:  属性规格ID
  IN_PARAM ： 属性值，如果有ATTR_VALUE表中有记录的，需要填ATTR_VALUE_NAME
  O_RESULT : 返回结果
    *\
  PROCEDURE add_or_change_prod_inst_attr(in_prodinst    IN NUMBER,
                                         in_attr_spec   IN NUMBER,
                                         in_param       IN VARCHAR2,
                                         in_modi_staff  IN VARCHAR2,
                                         in_modi_reason IN VARCHAR2,
                                         o_result       OUT VARCHAR2);

  --功　　能：增加产品特性
  --创建时间：2012-8-13
  --开山始祖：lud
  --参    数：
  \*
  IN_PRODINST : prod_inst_id
  IN_ATTR_SPEC:  属性规格ID
  IN_PARAM ： 属性值，如果有ATTR_VALUE表中有记录的，需要填ATTR_VALUE_NAME
  O_RESULT : 返回结果
    *\
  PROCEDURE add_prod_inst_attr(in_prodinst    IN NUMBER,
                               in_attr_spec   IN NUMBER,
                               in_param       IN VARCHAR2,
                               in_modi_staff  IN VARCHAR2,
                               in_modi_reason IN VARCHAR2,
                               o_result       OUT VARCHAR2);

  --功　　能：修改销售品规格为T01, T04, T05的生失效时间
  --创建时间：2012-8-5
  --开山始祖：lud
  --参    数：
  \*
  in_offer_id :销售品实例ID
  modi_eff ：表示字段名
  modi_exp :表示送计费接口的表名对应的主键ID
  modi_type     :表示送计费接口的原因
  modi_staff :表示修改数据的操作人
  modi_reason: 修改原因
  *\

  PROCEDURE change_offer_date(in_prod_inst_id IN NUMBER,
                              in_offer_id     IN NUMBER,
                              modi_eff        IN VARCHAR2,
                              modi_exp        IN VARCHAR2,
                              modi_type       IN VARCHAR2,
                              modi_staff      IN VARCHAR2,
                              modi_reason     IN VARCHAR2,
                              o_result        OUT VARCHAR2);

  PROCEDURE change_offer_expdate_his(in_his_id   IN NUMBER,
                                     modiexp     IN VARCHAR2,
                                     modi_staff  IN VARCHAR2,
                                     modi_reason IN VARCHAR2,
                                     o_result    OUT VARCHAR2);

  --只有历史表有记录
  \*  procedure CHANGE_OFFER_EXPDATE_HIS_temp(IN_his_id   IN number,
               modi_exp    IN date,
               modi_staff  IN varchar2,
               modi_reason IN varchar2,
  o_result       out varchar2);*\

  ----LUD
  --2012.08.06
  -- T04,T05增加可选包，不增加参数
  PROCEDURE create_offer_info(in_p_inst      IN NUMBER,
                              in_offer_id    IN NUMBER,
                              in_eff_date    IN VARCHAR2 DEFAULT '2199-01-01',
                              in_exp_date    IN VARCHAR2 DEFAULT '2199-01-01',
                              in_modi_staff  IN VARCHAR2,
                              in_modi_reason IN VARCHAR2,
                              in_rolecd      IN NUMBER,
                              o_offer_inst   OUT varchar2);

  --                           o_result       out varchar2) ;
  --功　　能：添加销售品参数
  --创建时间：2012-8-7
  --开山始祖：lud
  --参    数：
  \*
  in_offer_id :销售品实例ID
  in_attr_spec ：属性 规格
  in_attr_val : 属性值
  o_result : 返回结果
  modi_staff :表示修改数据的操作人
  modi_reason: 修改原因
  *\

  PROCEDURE insert_offer_attr(in_offer_id    IN NUMBER,
                              in_attr_spec   IN NUMBER,
                              in_attr_val    IN VARCHAR2,
                              in_modi_staff  IN VARCHAR2,
                              in_modi_reason IN VARCHAR2,
                              o_result       OUT VARCHAR2);
  --号码恢复预开通
  PROCEDURE prod_inst_to_ykt(in_prod   IN NUMBER,
                             in_reason IN VARCHAR2,
                             in_staff  IN VARCHAR2,
                             o_result  OUT VARCHAR2);

  --删除可选包：
  PROCEDURE delete_price_T04(v_prod_offer_inst_id IN NUMBER, --mdse_price_rela.rela_id
                             i_exp_date           IN VARCHAR2, --失效时间
                             iremark              IN VARCHAR2, --修改备注
                             modi_staff           IN VARCHAR2, --修改人
                             o_msg                OUT VARCHAR2);

  PROCEDURE delete_price_T05(v_prod_offer_inst_id IN NUMBER, --mdse_price_rela.rela_id
                             i_exp_date           IN VARCHAR2, --失效时间
                             iremark              IN VARCHAR2, --修改备注
                             modi_staff           IN VARCHAR2, --修改人
                             o_msg                OUT VARCHAR2);
  --删属性
  PROCEDURE delete_prod_inst_attr(in_inst_attr_id IN NUMBER,
                                  in_reason       IN VARCHAR2,
                                  in_staff        IN VARCHAR2,
                                  o_result        OUT VARCHAR2);

  --多个T01销售品修复
  PROCEDURE prod_offer_t01_err(in_prod_inst_id    IN NUMBER,
                               in_prodofferinstid IN NUMBER,
                               in_reason          IN VARCHAR2,
                               in_staff           IN VARCHAR2,
                               o_result           OUT VARCHAR2);

  --新增T01销售品
  -- ，不增加参数
  PROCEDURE create_offer_info_t01(in_p_inst      IN NUMBER,
                                  in_offer_id    IN NUMBER,
                                  ineff          IN VARCHAR2,
                                  in_exp         IN VARCHAR2,
                                  in_modi_staff  IN VARCHAR2,
                                  in_modi_reason IN VARCHAR2,
                                  o_offer_inst   OUT VARCHAR2);

  --修改客户战略分群，子群
  --输入： 客户ID， 分群ID， 子群名称
  \*
  政企客户  1000
  公众客户  1100
  其他客户  9900
  *\
  PROCEDURE change_cust_group(in_custid   IN NUMBER,
                              in_group    IN NUMBER,
                              in_subgroup IN VARCHAR2,
                              in_reason   IN VARCHAR2,
                              in_staff    IN VARCHAR2,
                              o_result    OUT VARCHAR2);

  --修改发展人和发展团队
  --输入： 订单号：FJ****； 工号：fz***,  团队ID
  PROCEDURE change_dev_staff_team(in_custnumber IN VARCHAR2,
                                  in_staff_code IN VARCHAR2,
                                  in_team       IN NUMBER,
                                  modi_staff    IN VARCHAR2, --修改人
                                  modi_reason   IN VARCHAR2, --修改备注
                                  o_result      OUT VARCHAR);

  --删除程控时同步删除在途单订单项
  PROCEDURE delete_product_order_item(in_prod_inst_id IN NUMBER,
                                      o_result        OUT VARCHAR2);

  --删除接入类产品档案
  \*  procedure delete_prod_inst_101(in_prod_id in number,
  in_reason  in varchar2,
  in_staff   in varchar2,
  in_exp     in date,
  in_type    in number);*\

  PROCEDURE recode_modi_log(o_ip   OUT VARCHAR2,
                            o_host OUT VARCHAR2,
                            o_user OUT VARCHAR2);

  --释放普通手机终端
  PROCEDURE release_termkey(in_termkey   IN VARCHAR2,
                            in_mkt_spec  in number,
                            in_phone_nbr IN VARCHAR2,
                            modi_staff   IN VARCHAR,
                            iremark      IN VARCHAR,
                            out_err_msg  OUT VARCHAR2);

  PROCEDURE crm_resource_70d(i_mkt_reso_key IN VARCHAR, -- 串码
                             in_modi_man    IN VARCHAR, --修改人
                             in_remark      IN VARCHAR, --修改原因
                             in_ip_address  IN VARCHAR, ---操作ip地址
                             o_result       OUT VARCHAR2);

  PROCEDURE ykt_to_cash(in_account_id  IN NUMBER,
                        in_modi_staff  IN VARCHAR2,
                        in_modi_reason IN VARCHAR2,
                        o_result       OUT VARCHAR2);

  PROCEDURE cash_to_ykt(in_account_id   IN NUMBER,
                        in_sign_prod_id IN NUMBER,
                        in_acc_nbr      IN VARCHAR2,
                        in_bank_id      IN NUMBER,
                        in_bankcard     IN VARCHAR2,
                        in_modi_staff   IN VARCHAR2,
                        in_modi_reason  IN VARCHAR2,
                        o_result        OUT VARCHAR2);
  PROCEDURE modify_accountname(in_account_id   IN NUMBER,
                               in_account_name IN VARCHAR2,
                               in_modi_staff   IN VARCHAR2,
                               in_modi_reason  IN VARCHAR2,
                               o_result        OUT VARCHAR2);
  PROCEDURE p_mod_offer_inst_attr(i_offer_inst_attr_id IN NUMBER,
                                  i_attr_value         IN VARCHAR2,
                                  modi_staff           IN VARCHAR2,
                                  modi_reason          IN VARCHAR2,
                                  o_msg                OUT VARCHAR2);

  --修改套餐参数 lud
  \*（2） 入参：号码、套餐名、参数名、旧值、
  新值、流程id、修改人（根据登录工号自动获得传入）      *\
  PROCEDURE change_offer_inst_attr(in_account   IN VARCHAR2,
                                   in_offername IN VARCHAR2,
                                   in_attrname  IN VARCHAR2,

                                   in_newvalue   IN VARCHAR2,
                                   in_remark     IN VARCHAR2,
                                   in_modi_staff IN VARCHAR2,
                                   o_msg         OUT VARCHAR2);
  \*procedure p_check_modi_staff(in_staff in varchar2,o_area_id out varchar2);*\
  FUNCTION f_check_modi_staff(in_staff VARCHAR2) RETURN NUMBER;
  PROCEDURE p_modify_single_data(in_owner      IN VARCHAR2, --用户名
                                 in_table_name IN VARCHAR2, --表名
                                 in_key_id     IN VARCHAR2, --主键id
                                 in_col_name   IN VARCHAR2, --要修改的字段名称
                                 in_new_value  IN VARCHAR2, --要修改的字段值
                                 modi_staff    IN VARCHAR2, --修改人
                                 modi_reason   IN VARCHAR2, --修改备注
                                 o_msg         OUT VARCHAR2);
  PROCEDURE p_modify_offer_yqsx(in_offer_inst_id IN NUMBER, -- 旧套餐实例id
                                modi_staff       IN VARCHAR2, --修改人
                                modi_reason      IN VARCHAR2, --修改备注
                                o_msg            OUT VARCHAR2);

  PROCEDURE p_modify_prodinst_area(in_prod_inst_id IN NUMBER,
                                   in_new_region   IN NUMBER,
                                   modi_reason     IN VARCHAR2, --修改备注
                                   modi_staff      IN VARCHAR2, --修改人
                                   o_msg           OUT VARCHAR);
  FUNCTION qry_seq(in_table IN VARCHAR2, --表名
                   in_col   IN VARCHAR2 --字段名
                   ) RETURN VARCHAR2;
  PROCEDURE optionalofferproconlyoffer(v_prod_offer_inst_id NUMBER,
                                       modi_reason          IN VARCHAR2, --修改备注
                                       modi_staff           IN VARCHAR2, --修改人
                                       o_msg                OUT VARCHAR);

  PROCEDURE release_termkey_only_res(in_termkey  IN VARCHAR2, --实物串号
                                     modi_staff  IN VARCHAR2, --修改人
                                     modi_reason IN VARCHAR2, --修改备注
                                     o_msg       OUT VARCHAR2);
  PROCEDURE p_add_prod_offer_only(in_prod_inst_id  IN NUMBER, --产品实例ID
                                  in_prod_offer_id IN NUMBER, --销售品规格
                                  modi_reason      IN VARCHAR2, --修改备注
                                  modi_staff       IN VARCHAR2, --修改人
                                  o_msg            OUT VARCHAR);
  PROCEDURE p_dev_staff_team_proc_attr(in_order_item_id IN NUMBER,
                                       in_table_name    IN VARCHAR2,
                                       in_remark        IN VARCHAR2,
                                       in_modi_staff    IN VARCHAR2);

  PROCEDURE P_MODI_PROD_ACC_NBR(in_prod_inst_id IN NUMBER, --产品实例ID
                                in_new_acc_nbr  IN VARCHAR2, --新业务号
                                in_new_account  IN VARCHAR2, --新帐号
                                modi_staff      IN VARCHAR2, --修改人
                                modi_reason     IN VARCHAR2, --修改原因
                                o_msg           OUT VARCHAR2);
  PROCEDURE p_finish_customer_contact(in_agree_id IN VARCHAR2,
                                      modi_staff  IN VARCHAR2,
                                      modi_reason IN VARCHAR2,
                                      o_msg       OUT VARCHAR2);

  FUNCTION qry_cust_number(in_area_code IN VARCHAR2) RETURN VARCHAR2;
  PROCEDURE p_modi_batch_order(in_cust_so_number IN VARCHAR2,
                               modi_staff        IN VARCHAR2,
                               modi_reason       IN VARCHAR2,
                               o_msg             OUT VARCHAR2);
  PROCEDURE updateBatchByProdId(v_Prod_Inst_id in number,
                                modi_staff     in varchar2,
                                modi_reason    IN Varchar2,
                                str_msg        out varchar);

  --修改属性时间
  --2013.4.1 lud
  procedure change_attr_date(in_table    in varchar2,
                             in_key      in varchar2,
                             in_type     in varchar2,
                             new_eff     in varchar2, -- 类型 yyyy-mm-dd
                             new_exp     in varchar2, -- 类型 yyyy-mm-dd
                             modi_staff  in varchar2,
                             modi_reason in varchar2,
                             o_msg       out varchar2);
  PROCEDURE offer_attr_his_to_1(in_his_id   IN NUMBER,
                                in_exp      IN VARCHAR2,
                                modi_reason IN VARCHAR2,
                                modi_staff  IN VARCHAR2,
                                o_msg       OUT VARCHAR2);
  Procedure p_check_idcardcode(in_reg_nbr IN VARCHAR2,
                               out_str    OUT VARCHAR2);
  PROCEDURE delete_functional_product(v_prod_inst_id IN NUMBER, -- 功能类产品实例id
                                      iremark        IN VARCHAR2, --修改备注
                                      modi_man       IN VARCHAR2, --修改人
                                      o_msg          OUT VARCHAR2);

   procedure RELEASE_TEMKEY_YEW(in_termkey   IN VARCHAR2,
                                               in_phone_nbr IN VARCHAR2,
                                               modi_staff   IN VARCHAR,
                                               iremark      IN VARCHAR,
                                               out_err_msg  OUT VARCHAR2)  ;


  procedure  crm_OTTresource_70d(i_mkt_reso_key IN VARCHAR, -- 串码
                             in_modi_man    IN VARCHAR, --修改人
                             in_remark      IN VARCHAR, --修改原因
                             in_ip_address  IN VARCHAR, ---操作ip地址
                             o_result       OUT VARCHAR2)  ;
PROCEDURE p_intf_dep_finish_update(in_cust_so_number IN VARCHAR2,
                                                     o_msg             OUT VARCHAR2);

PROCEDURE p_cancel_order_70E(v_package_group in varchar2,
                                         IN_MODI_STAFF  IN VARCHAR2,
                                         IN_MODI_REASON  IN VARCHAR2,
                                         O_RESULT       OUT VARCHAR2);*/


   PROCEDURE PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME itsc_crmv2.INTF_INS_BILLING_UPDATE.TABLE_NAME%TYPE,
                                         I_COLUMN_NAME itsc_crmv2.INTF_INS_BILLING_UPDATE.COLUMN_NAME%TYPE,
                                         I_KEY_ID      itsc_crmv2.INTF_INS_BILLING_UPDATE.KEY_ID%TYPE,
                                         I_REASON      itsc_crmv2.INTF_INS_BILLING_UPDATE.REASON%TYPE,
                                         I_OPERATOR    itsc_crmv2.INTF_INS_BILLING_UPDATE.OPERATOR%TYPE);


 /*   FUNCTION fnc_get_ocs_mutex(i_prod_inst_id in number) RETURN VARCHAR2;*/

END pkg_wh;
/
