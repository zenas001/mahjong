CREATE PACKAGE BODY           PKG_CRM2_SQL_MONITOR_2 IS
/*   CRM_SQL_ALL_CNT 前期统计跟踪表
   CRM_SQL_ALL 全量SQL表
   CRM_SQL_INC 增量SQL表*/
  ---BYWUZY
  PROCEDURE P_GET_DAY_SQL IS
    V_CNT   NUMBER;
    V_CNT_1 NUMBER;
    V_CNT_2 NUMBER;
    --过程主体
  BEGIN

    ----统计
    SELECT COUNT(1)
      INTO V_CNT_1
      FROM V$SQLAREA A
     WHERE A.PARSING_SCHEMA_NAME IN ('CRMV2', 'CRMV1')
       AND UPPER(A.MODULE)= 'JDBC THIN CLIENT'
       AND UPPER(A.SQL_TEXT) NOT LIKE 'DELETE%'
       AND UPPER(A.SQL_TEXT) NOT LIKE 'INSERT%'
       AND UPPER(A.SQL_TEXT) NOT LIKE 'UPDATE%'
       AND UPPER(A.SQL_TEXT) NOT LIKE '%.NEXTVAL FROM DUAL%'
       AND NOT EXISTS
     (SELECT 1 FROM CRM_SQL_ALL  WHERE SQL_ID = A.SQL_ID);

    ----统计

    ---比对SQL_ID进全量表
    FOR CUR IN (SELECT PARSING_SCHEMA_NAME SCHEMA_NAME, SQL_ID, SQL_FULLTEXT
                  FROM V$SQLAREA A
                 WHERE A.PARSING_SCHEMA_NAME IN ('CRMV2', 'CRMV1')
                   AND UPPER(A.MODULE) = 'JDBC THIN CLIENT'
                   AND UPPER(A.SQL_TEXT) NOT LIKE 'DELETE%'
                   AND UPPER(A.SQL_TEXT) NOT LIKE 'INSERT%'
                   AND UPPER(A.SQL_TEXT) NOT LIKE 'UPDATE%'
                   AND UPPER(A.SQL_TEXT) NOT LIKE '%.NEXTVAL FROM DUAL%'
                   AND NOT EXISTS
                 (SELECT 1 FROM CRM_SQL_ALL  WHERE SQL_ID = A.SQL_ID)) LOOP
      BEGIN
        INSERT INTO CRM_SQL_ALL
          SELECT CUR.SCHEMA_NAME,
                 UPPER(REMOVE_CONSTANTS(SUBSTR(CUR.SQL_FULLTEXT, 1, 4000))) C_SQL,
                 NULL,
                 CUR.SQL_FULLTEXT,
                 CUR.SQL_ID,
                 SYSDATE CREATE_DATE
            FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END LOOP;
    COMMIT;
    ---比对C_SQL进增量表

    ---前期统计数据用
    SELECT COUNT(1)
      INTO V_CNT_2
      FROM (SELECT SCHEMA_NAME, C_SQL
              FROM CRM_SQL_ALL
             WHERE CREATE_DATE > TRUNC(SYSDATE)
            MINUS
            SELECT SCHEMA_NAME, C_SQL
              FROM CRM_SQL_INC);
    if (v_cnt_1<>0 or v_cnt_2<>0) then
	 INSERT INTO CRM_SQL_ALL_CNT
      SELECT V_CNT_1, V_CNT_2, SYSDATE FROM DUAL;
end if;

    ---统计

    FOR CUR IN (SELECT SCHEMA_NAME, C_SQL
                  FROM CRM_SQL_ALL
                 WHERE CREATE_DATE > TRUNC(SYSDATE)
                MINUS
                SELECT SCHEMA_NAME, C_SQL
                  FROM CRM_SQL_INC) LOOP
      INSERT INTO CRM_SQL_INC
        SELECT SEQ_SQL_INC_ID.NEXTVAL INC_ID,
               CUR.SCHEMA_NAME,
               CUR.C_SQL,
               SYSDATE                INC_DATE,
               NULL                   REMARK
          FROM DUAL;
    END LOOP;
    COMMIT;

    ----通知功能

    /* SELECT COUNT(1) INTO  V_CNT FROM  CRM_SQL_INC WHERE INC_DATE>TRUNC(SYSDATE)   ;

    PKG_ITSM.PROC_PUSH_MSG_TO_RTX_DIRECT@LK_CRM2CQ('MAL,WUJL,ZHOUJF', '用测数据库本日新增历史表查询语句提醒', '用测数据库新增历史表查询语句共：'||V_CNT||' 条，请设计组评估该语句的可行性，详见CRMV2.CRM_SQL_INC');  */

  ---表结构变更功能

  END P_GET_DAY_SQL;


function remove_constants( p_query in varchar2 ) return varchar2
as
    l_query long;
    l_char  varchar2(10);
    l_in_quotes boolean default FALSE;
begin
    for i in 1 .. length( p_query )
    loop
        l_char := substr(p_query,i,1);
        if ( l_char = '''' and l_in_quotes )
        then
            l_in_quotes := FALSE;
        elsif ( l_char = '''' and NOT l_in_quotes )
        then
            l_in_quotes := TRUE;
            l_query := l_query || '''#';
        end if;
        if ( NOT l_in_quotes ) then
            l_query := l_query || l_char;
        end if;
    end loop;
    l_query := translate( l_query, '0123456789', '@@@@@@@@@@' );
    for i in 0 .. 8 loop
        l_query := replace( l_query, lpad('@',10-i,'@'), '@' );
        l_query := replace( l_query, lpad(' ',10-i,' '), ' ' );
    end loop;
    return upper(l_query);
end;
END;

----20140430 跟踪结果，发现后期增加的sql多为变种sql，普通的变种sql应该是不算增量的。捞取变种sql的方法暂定如下操作。


---由于sql会产生变种，所以再次做提取，每个变种sql(前100字符相同判定为变种)不超过1条的

/*select *
  from crm_sql_inc dd
 where inc_date > sysdate - 15
   and   exists
 (select *
          from (select substr(c_sql, 1, 100) c_sql, count(1)
                  from crm_sql_inc
                 where 1 = 1
                 group by substr(c_sql, 1, 100)
                having count(1) = 1) tt
         where substr(tt.c_sql, 1, 100) = substr(dd.c_sql, 1, 100))*/
/
