CREATE package           INTF_CRM_PRODUCTINSTANCE_JJX is

  -- Author  : MaLong
  -- Created : 2006-12-16 8:21:33
  -- Purpose : To do the automatic job for product and merchandise
   PROCEDURE INTF_CRM_PRODUCTINSTANCE_JJX_2( l_prod_id in number,
                                          l_resource_id out number,
                                          str_resource_name out varchar);
end INTF_CRM_PRODUCTINSTANCE_JJX;
/
