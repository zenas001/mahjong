CREATE package           pkg_grid_CHANNEL is

--模块：渠道子域（网格）
--时间：2011-03-22
--功能：
----1、产品实例自动划配到网格
------prodinstgridrel
----2、规则变更后产品实例自动重新划配到新网格
------update_grid_rule_inst
----3、客户自动划配到客户经理
------custassignrel

end;
/
