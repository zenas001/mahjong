CREATE PACKAGE BODY           PKG_CHECK_PROD_INST_ACCT IS
  /**根据更新**/
  FUNCTION FUNC_UPDATE_ACCT_DATA(CUST_ORDER_ID IN NUMBER) RETURN NUMBER IS

    V_NEW_ACCOUNT        VARCHAR2(225);
    V_PROD_INST_ID       NUMBER;
    O_LOG_RETURN         BOOLEAN;
    I_CUST_ORDER_ID      NUMBER;
    V_OLD_ACCOUNT        NUMBER;
    V_ERROR_MSG          VARCHAR2(2000);
    V_PROD_INST_ACCT_ID  NUMBER;
    O_UPDATE_ACOUNT      NUMBER;
    V_PROD_INST_ACCT_HIS BOOLEAN;

    CURSOR OBJ_ZZXX IS
      SELECT OIP.ORDER_ITEM_ID, OIP.NEW_VALUE
        FROM ORDER_ITEM_HIS OI, ORDER_ITEM_PROC_ATTR_HIS OIP
       WHERE OI.ORDER_ITEM_ID = OIP.ORDER_ITEM_ID
         AND OI.CUST_ORDER_ID = I_CUST_ORDER_ID
         AND OIP.OBJ_ATTR = 'ZZXX'
         AND OI.STATUS_CD = '300000'
         AND OIP.NEW_VALUE IS NOT NULL;
  BEGIN
    I_CUST_ORDER_ID := CUST_ORDER_ID;
    O_UPDATE_ACOUNT := 0;
    BEGIN
      FOR CUR IN OBJ_ZZXX LOOP
        --更新后的合同号ID
        V_NEW_ACCOUNT := CUR.NEW_VALUE;

        V_NEW_ACCOUNT := SUBSTR(V_NEW_ACCOUNT,
                                INSTR(V_NEW_ACCOUNT, ',') + 1,
                                LENGTH(V_NEW_ACCOUNT));
        V_NEW_ACCOUNT := SUBSTR(V_NEW_ACCOUNT,
                                INSTR(V_NEW_ACCOUNT, ',') + 1,
                                LENGTH(V_NEW_ACCOUNT));
        V_NEW_ACCOUNT := SUBSTR(V_NEW_ACCOUNT,
                                0,
                                INSTR(V_NEW_ACCOUNT, ',') - 1);
        BEGIN
          --取关联订单项产品ID
          SELECT OI.ORDER_ITEM_OBJ_ID
            INTO V_PROD_INST_ID
            FROM ORDER_ITEM_HIS OI
           WHERE OI.ORDER_ITEM_ID = CUR.ORDER_ITEM_ID
             AND OI.CLASS_ID = 4;
          --取当前定制关系合同号ID
          SELECT PIA.ACCOUNT_ID
            INTO V_OLD_ACCOUNT
            FROM PROD_INST_ACCT PIA
           WHERE PIA.PROD_INST_ID = V_PROD_INST_ID
             AND PIA.DEF_ACCT_FLAG = 'T'
             AND PIA.STATUS_CD = '1000';
          --对比是否一样，不一样则修改
          IF V_OLD_ACCOUNT != V_NEW_ACCOUNT THEN
            O_LOG_RETURN := FUNC_INSERT_ACCT_LOG(V_PROD_INST_ID,
                                                 CUR.ORDER_ITEM_ID);
            IF O_LOG_RETURN = TRUE THEN

              SELECT PIA.PROD_INST_ACCT_ID
                INTO V_PROD_INST_ACCT_ID
                FROM PROD_INST_ACCT PIA
               WHERE PIA.PROD_INST_ID = V_PROD_INST_ID
                 AND PIA.DEF_ACCT_FLAG = 'T'
                 AND PIA.STATUS_CD = '1000';

              V_PROD_INST_ACCT_HIS := FUNC_INSERT_ACCT_HIS(V_PROD_INST_ACCT_ID);

              --更新合同号
              UPDATE PROD_INST_ACCT PIA
                 SET PIA.ACCOUNT_ID = V_NEW_ACCOUNT
               WHERE PIA.PROD_INST_ID = V_PROD_INST_ID
                 AND PIA.DEF_ACCT_FLAG = 'T'
                 AND PIA.STATUS_CD = '1000';

              --送计费
              BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('PROD_INST_ACCT',
                                                                         'PROD_INST_ACCT_ID',
                                                                         V_PROD_INST_ACCT_ID,
                                                                         'PKG_CHECK_PROD_INST_ACCT 更新ACCOUNT_ID记录',
                                                                         '1002',
                                                                         'PKG_CHECK_PROD_INST_ACCT 更新ACCOUNT_ID记录',
                                                                         '',
                                                                         '590');

              O_UPDATE_ACOUNT := O_UPDATE_ACOUNT + 1;
            END IF;

          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK;
            V_ERROR_MSG := SUBSTR(SQLERRM, 0, 1000);
            INSERT INTO PROD_INST_ACCT_LOG PIAL
              (PROD_INST_ACCT_LOG_ID,
               ORDER_ITEM_ID,
               UPDATE_DATE_LOG,
               LOG_DATA)
            VALUES
              (SEQ_PROD_INST_ACCT_LOG_ID.NEXTVAL,
               CUR.ORDER_ITEM_ID,
               SYSDATE,
               V_ERROR_MSG);
            COMMIT;
            RETURN O_UPDATE_ACOUNT;
        END;
      END LOOP;
    END;

    RETURN O_UPDATE_ACOUNT;
  END;

  FUNCTION FUNC_SELECT_ACCT_DATA RETURN BOOLEAN IS
    --查询前一天竣工的订单

  BEGIN

    DELETE FROM CUSTOMER_ORDER_ACCT_TMP;
    COMMIT;

    INSERT INTO CUSTOMER_ORDER_ACCT_TMP
      (CUSTOMER_ORDER_ACCT_TMP_ID, CUST_ORDER_ID, STATUS_DATE)
      (SELECT SEQ_CUSTOMER_ORDER_ACCT_TMP_ID.NEXTVAL,
              COH.CUST_ORDER_ID,
              COH.STATUS_DATE
         FROM CUSTOMER_ORDER_HIS COH
        WHERE 1 = 1
          AND COH.STATUS_CD = '300000'
          AND COH.STATUS_DATE > SYSDATE - 10/1440
          AND COH.STAFF_ID != '51447');
    COMMIT;

    INSERT INTO CHECK_PROD_INST_ACCT_LOG
      (CHECK_PROD_INST_ACCT_LOG_ID, JOB_LOG_DATA, JOB_LOG_DATE)
    VALUES
      (SEQ_CHECK_PROD_ACCT_LOG_ID.NEXTVAL,
       '开始前一天竣工的订单到临时表。。',
       SYSDATE);
    COMMIT;
    RETURN TRUE;
  END;
  /**根据开关处理临时表数据**/
  FUNCTION FUNC_SELECT_ACCT_TMP RETURN BOOLEAN IS
    V_ACCT_RESULT             NUMBER;
    V_ACCT_RESULT_COUNT       NUMBER;
    V_ACCOUNT_RESULT          NUMBER;
    V_ACCOUNT_RESULT_COUNT    NUMBER;
    V_PROD_INST_ACCT_JOB_ZZXX NUMBER;
    V_CUST_ID                 NUMBER;
    V_ACCOUNT_JOB_STATUS_CD   NUMBER;
    V_ERROR_MSG               VARCHAR2(2000);

    CURSOR CUST_ORDER_IDS IS
      SELECT COAT.CUST_ORDER_ID
        FROM CUSTOMER_ORDER_ACCT_TMP COAT
       ORDER BY COAT.STATUS_DATE;
  BEGIN
    V_ACCT_RESULT_COUNT    := 0;
    V_ACCOUNT_RESULT_COUNT := 0;

    SELECT COUNT(1)
      INTO V_PROD_INST_ACCT_JOB_ZZXX
      FROM ATTR_SPEC
     WHERE ATTR_CD = 'PROD_INST_ACCT_JOB_ZZXX';

    SELECT COUNT(1)
      INTO V_ACCOUNT_JOB_STATUS_CD
      FROM ATTR_SPEC
     WHERE ATTR_CD = 'ACCOUNT_JOB_STATUS_CD';

    INSERT INTO CHECK_PROD_INST_ACCT_LOG
      (CHECK_PROD_INST_ACCT_LOG_ID, JOB_LOG_DATA, JOB_LOG_DATE)
    VALUES
      (SEQ_CHECK_PROD_ACCT_LOG_ID.NEXTVAL,
       'PROD_INST_ACCT_JOB_ZZXX 开关状态为' || V_PROD_INST_ACCT_JOB_ZZXX ||
       ' ACCOUNT_JOB_STATUS_CD 开关状态为 ' || V_ACCOUNT_JOB_STATUS_CD ||
       ' 开始处理数据',
       SYSDATE);
    COMMIT;

    FOR CUR IN CUST_ORDER_IDS LOOP
      BEGIN
        --根据开关进行处理
        V_CUST_ID := CUR.CUST_ORDER_ID;
        IF V_PROD_INST_ACCT_JOB_ZZXX = 1 THEN
          V_ACCT_RESULT := FUNC_UPDATE_ACCT_DATA(V_CUST_ID);
          IF V_ACCT_RESULT > 0 THEN
            UPDATE CUSTOMER_ORDER_ACCT_TMP COAT
               SET COAT.JOB_ACCT_FLAGE = '1', COAT.JOB_ACCT_DATE = SYSDATE
             WHERE COAT.CUST_ORDER_ID = V_CUST_ID;
          ELSE
            UPDATE CUSTOMER_ORDER_ACCT_TMP COAT
               SET COAT.JOB_ACCT_FLAGE = '0', COAT.JOB_ACCT_DATE = SYSDATE
             WHERE COAT.CUST_ORDER_ID = V_CUST_ID;
          END IF;
          V_ACCT_RESULT_COUNT := V_ACCT_RESULT_COUNT + V_ACCT_RESULT;

        END IF;

        IF V_ACCOUNT_JOB_STATUS_CD = 1 THEN
          V_ACCOUNT_RESULT := FUNC_UPDATE_ACCOUNT_DATA(V_CUST_ID);
          IF V_ACCOUNT_RESULT > 0 THEN
            UPDATE CUSTOMER_ORDER_ACCT_TMP COAT
               SET COAT.JOB_ACCOUNT_FLAGE = '1',
                   COAT.JOB_ACCOUNT_DATE  = SYSDATE
             WHERE COAT.CUST_ORDER_ID = V_CUST_ID;
          ELSE
            UPDATE CUSTOMER_ORDER_ACCT_TMP COAT
               SET COAT.JOB_ACCOUNT_FLAGE = '0',
                   COAT.JOB_ACCOUNT_DATE  = SYSDATE
             WHERE COAT.CUST_ORDER_ID = V_CUST_ID;
          END IF;
          V_ACCOUNT_RESULT_COUNT := V_ACCOUNT_RESULT_COUNT +
                                    V_ACCOUNT_RESULT;
        END IF;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          V_ERROR_MSG := SUBSTR(SQLERRM, 0, 1000);
          UPDATE CUSTOMER_ORDER_ACCT_TMP COAT
             SET COAT.JOB_LOG = V_ERROR_MSG
           WHERE COAT.CUST_ORDER_ID = V_CUST_ID;
          COMMIT;
      END;
    END LOOP;

    INSERT INTO CHECK_PROD_INST_ACCT_LOG
      (CHECK_PROD_INST_ACCT_LOG_ID, JOB_LOG_DATA, JOB_LOG_DATE)
    VALUES
      (SEQ_CHECK_PROD_ACCT_LOG_ID.NEXTVAL,
       'PROD_INST_ACCT_JOB_ZZXX 处理数量为' || V_ACCT_RESULT_COUNT ||
       ' ACCOUNT_JOB_STATUS_CD 处理数量为 ' || V_ACCOUNT_RESULT_COUNT || ' 数据完毕',
       SYSDATE);

    INSERT INTO CUSTOMER_ORDER_ACCT
      (CUST_ORDER_ID,
       STATUS_DATE,
       JOB_ACCT_FLAGE,
       JOB_ACCT_DATE,
       JOB_ACCOUNT_FLAGE,
       JOB_ACCOUNT_DATE,
       JOB_LOG,
       CUSTOMER_ORDER_ACCT_ID)
      (SELECT COAT.CUST_ORDER_ID,
              COAT.STATUS_DATE,
              COAT.JOB_ACCT_FLAGE,
              COAT.JOB_ACCT_DATE,
              COAT.JOB_ACCOUNT_FLAGE,
              COAT.JOB_ACCOUNT_DATE,
              COAT.JOB_LOG,
              COAT.CUSTOMER_ORDER_ACCT_TMP_ID
         FROM CUSTOMER_ORDER_ACCT_TMP COAT);

    INSERT INTO CHECK_PROD_INST_ACCT_LOG
      (CHECK_PROD_INST_ACCT_LOG_ID, JOB_LOG_DATA, JOB_LOG_DATE)
    VALUES
      (SEQ_CHECK_PROD_ACCT_LOG_ID.NEXTVAL,
       ' 备份临时表数据到CUSTOMER_ORDER_ACCT 已经完成。。',
       SYSDATE);
    COMMIT;

    RETURN TRUE;
  END;

  FUNCTION FUNC_INSERT_ACCT_LOG(PROD_INST_ID  IN NUMBER,
                                ORDER_ITEM_ID IN NUMBER) RETURN BOOLEAN IS
    I_PROD_INST_ID  NUMBER;
    I_ORDER_ITEM_ID NUMBER;
  BEGIN
    I_PROD_INST_ID  := PROD_INST_ID;
    I_ORDER_ITEM_ID := ORDER_ITEM_ID;
    INSERT INTO PROD_INST_ACCT_LOG PIAL
      (PROD_INST_ACCT_LOG_ID,
       PROD_INST_ACCT_ID,
       ACCOUNT_ID,
       ACCT_ITEM_TYPE_GROUP_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       PRIORITY,
       STATUS_CD,
       STATUS_DATE,
       PROC_SERIAL,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       UPDATE_DATE,
       CREATE_DATE,
       EFF_DATE,
       EXP_DATE,
       DEF_ACCT_FLAG,
       CHARGE_TYPE,
       INVOICE_FORMART_FLAG,
       REC_UPDATE_DATE,
       GROUP_PROD_INST_ACCT_ID,
       EXT_PROD_INST_ACCT_ID,
       ORDER_ITEM_ID,
       UPDATE_DATE_LOG,
       LOG_DATA)
      (SELECT SEQ_PROD_INST_ACCT_LOG_ID.NEXTVAL,
              PIA.PROD_INST_ACCT_ID,
              PIA.ACCOUNT_ID,
              PIA.ACCT_ITEM_TYPE_GROUP_ID,
              PIA.PROD_INST_ID,
              PIA.PAYMENT_LIMIT_TYPE,
              PIA.PAYMENT_LIMIT,
              PIA.PRIORITY,
              PIA.STATUS_CD,
              PIA.STATUS_DATE,
              PIA.PROC_SERIAL,
              PIA.AREA_ID,
              PIA.REGION_CD,
              PIA.UPDATE_STAFF,
              PIA.CREATE_STAFF,
              PIA.UPDATE_DATE,
              PIA.CREATE_DATE,
              PIA.EFF_DATE,
              PIA.EXP_DATE,
              PIA.DEF_ACCT_FLAG,
              PIA.CHARGE_TYPE,
              PIA.INVOICE_FORMART_FLAG,
              PIA.REC_UPDATE_DATE,
              PIA.GROUP_PROD_INST_ACCT_ID,
              I_ORDER_ITEM_ID,
              SYSDATE,
              NULL
         FROM PROD_INST_ACCT PIA
        WHERE 1 = 1
          AND PIA.PROD_INST_ID = I_PROD_INST_ID
          AND PIA.DEF_ACCT_FLAG = 'T');

    RETURN TRUE;
  END;

  PROCEDURE PROC_CHECK_PROD_INST_ACCT IS
    V_RESULT     BOOLEAN;
    V_TMP_RETURN BOOLEAN;

  BEGIN
    INSERT INTO CHECK_PROD_INST_ACCT_LOG
      (CHECK_PROD_INST_ACCT_LOG_ID, JOB_LOG_DATA, JOB_LOG_DATE)
    VALUES
      (SEQ_CHECK_PROD_ACCT_LOG_ID.NEXTVAL, '开始检查。。。', SYSDATE);
    COMMIT;
    V_RESULT     := FUNC_SELECT_ACCT_DATA();
    V_TMP_RETURN := FUNC_SELECT_ACCT_TMP();
    IF V_TMP_RETURN = TRUE AND V_RESULT = TRUE THEN
      COMMIT;
    END IF;
    INSERT INTO CHECK_PROD_INST_ACCT_LOG
      (CHECK_PROD_INST_ACCT_LOG_ID, JOB_LOG_DATA, JOB_LOG_DATE)
    VALUES
      (SEQ_CHECK_PROD_ACCT_LOG_ID.NEXTVAL, '检查完成。。。', SYSDATE);
    COMMIT;
  END;

  FUNCTION FUNC_UPDATE_ACCOUNT_DATA(CUST_ORDER_ID IN NUMBER) RETURN NUMBER IS
    I_CUST_ORDER_ID      NUMBER;
    V_ACCOUNT_LOG_RETURN BOOLEAN;
    V_ACCOUNT_HIS_RETURN BOOLEAN;
    V_ERROR_MSG          VARCHAR2(2000);
    O_UPDATE_COUNT       NUMBER;
    --已竣工新增账户订单项，账户状态未改的
    CURSOR ACCOUNT_STATUS_CD IS
      SELECT A.STATUS_CD, A.ACCOUNT_ID, OI.ORDER_ITEM_ID
        FROM ACCOUNT A, ORDER_ITEM_HIS OI
       WHERE A.ACCOUNT_ID = OI.ORDER_ITEM_OBJ_ID
         AND OI.CUST_ORDER_ID = I_CUST_ORDER_ID
         AND OI.CLASS_ID = 137
         AND OI.SERVICE_OFFER_ID = 83
         AND A.STATUS_CD = 1299
         AND OI.STATUS_CD = '300000';
  BEGIN
    I_CUST_ORDER_ID := CUST_ORDER_ID;
    O_UPDATE_COUNT  := 0;
    FOR CUR IN ACCOUNT_STATUS_CD LOOP

      BEGIN
        --写日志
        V_ACCOUNT_LOG_RETURN := FUNC_INSERT_ACCOUNT_LOG(CUR.ACCOUNT_ID,
                                                        CUR.ORDER_ITEM_ID);

        IF V_ACCOUNT_LOG_RETURN = TRUE THEN
          V_ACCOUNT_HIS_RETURN := FUNC_INSERT_ACCOUNT_HIS(CUR.ACCOUNT_ID);
          UPDATE ACCOUNT A
             SET A.STATUS_CD = '1000'
           WHERE A.ACCOUNT_ID = CUR.ACCOUNT_ID;
          --送计费
          BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('ACCOUNT',
                                                                     'ACCOUNT_ID',
                                                                     CUR.ACCOUNT_ID,
                                                                     'PKG_CHECK_PROD_INST_ACCT 更新STATUS_CD记录',
                                                                     '1002',
                                                                     'PKG_CHECK_PROD_INST_ACCT 更新STATUS_CD记录',
                                                                     '',
                                                                     '590');
          O_UPDATE_COUNT := O_UPDATE_COUNT + 1;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          V_ERROR_MSG := SUBSTR(SQLERRM, 0, 1000);
          INSERT INTO ACCOUNT_LOG AL
            (ACCOUNT_LOG_ID, ORDER_ITEM_ID, UPDATE_DATE_LOG, LOG_DATA)
          VALUES
            (SEQ_ACCOUNT_LOG_ID.NEXTVAL,
             CUR.ORDER_ITEM_ID,
             SYSDATE,
             V_ERROR_MSG);

          RETURN O_UPDATE_COUNT;
      END;
    END LOOP;
    RETURN O_UPDATE_COUNT;
  END;

  FUNCTION FUNC_INSERT_ACCOUNT_LOG(ACCOUNT_ID    IN NUMBER,
                                   ORDER_ITEM_ID IN NUMBER) RETURN BOOLEAN IS
    I_ACCOUNT_ID    NUMBER;
    I_ORDER_ITEM_ID NUMBER;
  BEGIN
    I_ACCOUNT_ID    := ACCOUNT_ID;
    I_ORDER_ITEM_ID := ORDER_ITEM_ID;

    INSERT INTO ACCOUNT_LOG AL
      (ACCOUNT_LOG_ID,
       ACCOUNT_ID,
       CUST_ID,
       COMMON_REGION_ID,
       ACCOUNT_NAME,
       ACCOUNT_AREA_GRADE,
       ACCOUNT_NUMBER,
       GROUP_PAY_METHOD,
       PAY_CYCLE,
       CONTACT_PHONE,
       MOBILE_PHONE,
       IF_DEFAULT,
       PROC_SERIAL,
       EXT_ACCOUNT_ID,
       AREA_ID,
       CREATE_DATE,
       CREATE_STAFF,
       REGION_CD,
       STATUS_CD,
       STATUS_DATE,
       UPDATE_DATE,
       UPDATE_STAFF,
       REC_UPDATE_DATE,
       DEDUCT_CHARGE,
       DEDUCT_LIMIT,
       PRINT_PROD_ID,
       SIGN_PROD_ID,
       PRINT_ACC_NBR,
       SIGN_ACC_NBR,
       EXT_FLAG1,
       ORDER_ITEM_ID,
       UPDATE_DATE_LOG,
       LOG_DATA)
      (SELECT SEQ_ACCOUNT_LOG_ID.NEXTVAL,
              A.ACCOUNT_ID,
              A.CUST_ID,
              A. COMMON_REGION_ID,
              A. ACCOUNT_NAME,
              A. ACCOUNT_AREA_GRADE,
              A. ACCOUNT_NUMBER,
              A. GROUP_PAY_METHOD,
              A. PAY_CYCLE,
              A.CONTACT_PHONE,
              A. MOBILE_PHONE,
              A.IF_DEFAULT,
              A.PROC_SERIAL,
              A. EXT_ACCOUNT_ID,
              A. AREA_ID,
              A. CREATE_DATE,
              A. CREATE_STAFF,
              A. REGION_CD,
              A. STATUS_CD,
              A. STATUS_DATE,
              A. UPDATE_DATE,
              A. UPDATE_STAFF,
              A. REC_UPDATE_DATE,
              A. DEDUCT_CHARGE,
              A. DEDUCT_LIMIT,
              A. PRINT_PROD_ID,
              A. SIGN_PROD_ID,
              A. PRINT_ACC_NBR,
              A. SIGN_ACC_NBR,
              A. EXT_FLAG1,
              I_ORDER_ITEM_ID,
              SYSDATE,
              NULL
         FROM ACCOUNT A
        WHERE 1 = 1
          AND A.ACCOUNT_ID = I_ACCOUNT_ID);
    RETURN TRUE;
  END;

  /**写历史表**/
  FUNCTION FUNC_INSERT_ACCT_HIS(PROD_INST_ACCT_ID NUMBER) RETURN BOOLEAN IS
    I_PROD_INST_ACCT_ID NUMBER;
  BEGIN
    I_PROD_INST_ACCT_ID := PROD_INST_ACCT_ID;
    INSERT INTO PROD_INST_ACCT_HIS
      (PROD_INST_ACCT_ID,
       ACCOUNT_ID,
       ACCT_ITEM_TYPE_GROUP_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       PRIORITY,
       STATUS_CD,
       STATUS_DATE,
       PROC_SERIAL,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       HIS_ID,
       UPDATE_DATE,
       CREATE_DATE,
       EFF_DATE,
       EXP_DATE,
       DEF_ACCT_FLAG,
       CHARGE_TYPE,
       INVOICE_FORMART_FLAG,
       REC_UPDATE_DATE,
       GROUP_PROD_INST_ACCT_ID)
      (SELECT PROD_INST_ACCT_ID,
              ACCOUNT_ID,
              ACCT_ITEM_TYPE_GROUP_ID,
              PROD_INST_ID,
              PAYMENT_LIMIT_TYPE,
              PAYMENT_LIMIT,
              PRIORITY,
              STATUS_CD,
              STATUS_DATE,
              PROC_SERIAL,
              AREA_ID,
              REGION_CD,
              UPDATE_STAFF,
              CREATE_STAFF,
              SEQ_PROD_INST_ACCT_HIS_ID.NEXTVAL,
              UPDATE_DATE,
              CREATE_DATE,
              EFF_DATE,
              EXP_DATE,
              DEF_ACCT_FLAG,
              CHARGE_TYPE,
              INVOICE_FORMART_FLAG,
              SYSDATE,
              GROUP_PROD_INST_ACCT_ID
         FROM PROD_INST_ACCT PIA
        WHERE PIA.PROD_INST_ACCT_ID = I_PROD_INST_ACCT_ID);
    RETURN TRUE;
  END;
  /**写历史表**/
  FUNCTION FUNC_INSERT_ACCOUNT_HIS(ACCOUNT_ID NUMBER) RETURN BOOLEAN IS
    I_ACCOUNT_ID NUMBER;
  BEGIN
    I_ACCOUNT_ID := ACCOUNT_ID;
    INSERT INTO ACCOUNT_HIS
      (ACCOUNT_ID,
       CUST_ID,
       COMMON_REGION_ID,
       ACCOUNT_NAME,
       ACCOUNT_AREA_GRADE,
       ACCOUNT_NUMBER,
       GROUP_PAY_METHOD,
       PAY_CYCLE,
       CONTACT_PHONE,
       MOBILE_PHONE,
       IF_DEFAULT,
       PROC_SERIAL,
       EXT_ACCOUNT_ID,
       AREA_ID,
       CREATE_DATE,
       CREATE_STAFF,
       REGION_CD,
       STATUS_CD,
       STATUS_DATE,
       UPDATE_DATE,
       UPDATE_STAFF,
       HIS_ID,
       REC_UPDATE_DATE,
       DEDUCT_CHARGE,
       DEDUCT_LIMIT,
       PRINT_PROD_ID,
       SIGN_PROD_ID,
       PRINT_ACC_NBR,
       SIGN_ACC_NBR)
      (SELECT ACCOUNT_ID,
              CUST_ID,
              COMMON_REGION_ID,
              ACCOUNT_NAME,
              ACCOUNT_AREA_GRADE,
              ACCOUNT_NUMBER,
              GROUP_PAY_METHOD,
              PAY_CYCLE,
              CONTACT_PHONE,
              MOBILE_PHONE,
              IF_DEFAULT,
              PROC_SERIAL,
              EXT_ACCOUNT_ID,
              AREA_ID,
              CREATE_DATE,
              CREATE_STAFF,
              REGION_CD,
              STATUS_CD,
              STATUS_DATE,
              UPDATE_DATE,
              UPDATE_STAFF,
              SEQ_ACCOUNT_HIS_ID.NEXTVAL,
              SYSDATE,
              DEDUCT_CHARGE,
              DEDUCT_LIMIT,
              PRINT_PROD_ID,
              SIGN_PROD_ID,
              PRINT_ACC_NBR,
              SIGN_ACC_NBR
         FROM ACCOUNT A
        WHERE A.ACCOUNT_ID = I_ACCOUNT_ID);
    RETURN TRUE;
  END;
END PKG_CHECK_PROD_INST_ACCT;
/
