CREATE PACKAGE           PKG_FINISH IS
  PROCEDURE PROC_ORDER_FINISH_NOTIFY(I_CUST_ORDER_ID             IN CUSTOMER_ORDER.CUST_ORDER_ID%TYPE, --订单id
                                     I_ORDER_ITEM_PROC_ATTR_LIST IN PKG_TFJ.TYPE_ORDER_ITEM_PROC_ATTR_LIST, --变更的属性
                                     I_IS_4G_FLAG              	 IN NUMBER,
                                     I_PROD_INST_OLD             IN PROD_INST%ROWTYPE)
  /*-------------------------------------------------
      功能: 档案竣工归档处理
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GET_DATA_INFO(I_CUST_ORDER_ID             IN CUSTOMER_ORDER.CUST_ORDER_ID%TYPE, --订单id
                             I_PROD_ORDER_ITEM_HIS       IN ORDER_ITEM_HIS%ROWTYPE, --产品订单项id
                             I_OFFER_ORDER_ITEM_HIS      IN ORDER_ITEM_HIS%ROWTYPE, --销售品订单项id
                             I_ORDER_ITEM_PROC_ATTR_LIST IN PKG_TFJ.TYPE_ORDER_ITEM_PROC_ATTR_LIST, --变更的属性
                             I_PROD_INST_OLD             IN PROD_INST%ROWTYPE) RETURN CLOB
  /*-------------------------------------------------
      功能: 创建竣工包
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GEN_CUSTOMER_ORDER_XML(I_CUST_ORDER_ID IN CUSTOMER_ORDER.CUST_ORDER_ID%TYPE --订单id
                                      ) RETURN CLOB
  /*-------------------------------------------------
      功能: 生成 customerOrder 节点
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GEN_PROD_INST_XML(I_PROD_ORDER_ITEM_HIS       IN ORDER_ITEM_HIS%ROWTYPE, --产品订单项
                                 I_ORDER_ITEM_PROC_ATTR_LIST IN PKG_TFJ.TYPE_ORDER_ITEM_PROC_ATTR_LIST, --变更的属性
                                 I_PROD_INST_OLD             IN PROD_INST%ROWTYPE) RETURN CLOB
  /*-------------------------------------------------
      功能: 生成 prodInst 节点
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GEN_PROD_OFFER_INST_XML(I_OFFER_ORDER_ITEM_HIS ORDER_ITEM_HIS%ROWTYPE --销售品订单项
                                       ) RETURN CLOB
  /*-------------------------------------------------
      功能: 生成 prodOfferInst 节点
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GEN_CUST_XML(I_PROD_ORDER_ITEM_HIS ORDER_ITEM_HIS%ROWTYPE --产品订单项
                            ) RETURN CLOB
  /*-------------------------------------------------
      功能: 生成 cust 节点
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GEN_ACCOUNTS_XML(I_PROD_ORDER_ITEM_HIS IN ORDER_ITEM_HIS%ROWTYPE --产品订单项
                               ) RETURN CLOB
  /*-------------------------------------------------
      功能: 生成 accounts 节点
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GEN_ACCOUNT_XML(I_PROD_ORDER_ITEM_HIS IN ORDER_ITEM_HIS%ROWTYPE, --产品订单项
                               I_ACCOUNT_ID          PROD_INST_ACCT.ACCOUNT_ID%TYPE --产品订单项
                               ) RETURN CLOB
  /*-------------------------------------------------
      功能: 生成 account 节点
    -------------------------------------------------*/
  ;

  FUNCTION FNC_GET_INTF_DEFINE_CONFIGS(I_PROD_ITEM_ID_STR  IN VARCHAR2, --产品订单项id, 如111, 222, 333
                                       I_OFFER_ITEM_ID_STR IN VARCHAR2 --销售品订单项id
                                       ) RETURN SYS_REFCURSOR
  /*-------------------------------------------------
      功能: 查询接口配置信息
    -------------------------------------------------*/
  ;

/*FUNCTION F_TEST RETURN VARCHAR2;*/
END PKG_FINISH;
/
