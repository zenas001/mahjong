CREATE package           PKG_MNT is

  ---并发自建job过程
  PROCEDURE MNT_CREATE_JOB;

  ---表空间监控
  PROCEDURE mnt_tablespace_percent;

  ---表增长监控
/*  PROCEDURE mnt_big_tables_ins;*/
  ---索引异常监控

end PKG_MNT;
/
