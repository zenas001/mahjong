CREATE PACKAGE BODY           PKG_CRM_SYNC_UAM IS
  --V_PROVINCE_ID VARCHAR2(10) := '8350000';
  --v_use_type    VARCHAR2(50) := '';
  --批次号生成，格式 BUS_CODE||YYYYMMDDHH24MISS
  FUNCTION FUN_BATCH_NBR_CREATE(IN_BUS_CODE IN VARCHAR2) RETURN VARCHAR2 IS
    V_BUS_CODE  VARCHAR2(50);
    V_SYS_DATE  VARCHAR2(30);
    V_BATCH_NBR VARCHAR2(100);
  BEGIN
    V_BUS_CODE := IN_BUS_CODE;
    SELECT TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI') INTO V_SYS_DATE FROM DUAL;

    V_BATCH_NBR := V_BUS_CODE || V_SYS_DATE;
    RETURN V_BATCH_NBR;
  END;

  --文件名生成,格式 BUS001201605241730001.txt
  FUNCTION FUN_FILE_NAME_CREATE(IN_BUS_CODE        IN VARCHAR2, --业务功能编码
                                IN_USE_TYPE        IN VARCHAR2,
                                IN_CURRENT_PACKAGE IN NUMBER, -- 分割批次次数
                                V_BATCH_NBR IN VARCHAR2 -- 批次号
                                ) RETURN VARCHAR2 IS
    V_INTF_DEP_FTP    INTF_DEP_FTP%ROWTYPE;
    V_FILE_NAME       VARCHAR2(200);
    V_CURRENT_PACKAGE VARCHAR(10);
  BEGIN
    IF IN_USE_TYPE IS NULL THEN
      SELECT INTF_DEP_FTP_ID,
             BUS_CODE,
             FTP_TYPE,
             SRC_SYS_ID,
             DST_SYS_ID,
             FILE_FORMAT,
             FIELD_INTERVAL,
             RECORD_INTERVAL,
             USE_TYPE,
             SRC_INTF_DEP_HOST_ID,
             SRC_PATH,
             DST_INTF_DEP_HOST_ID,
             DST_PATH,
             TABLE_NAME,
             TABLE_FIELD,
             RECORD_NUM,
             OWNER,
             FREQUENCY,
             TIME_POINT,
             STATE,
             STATE_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             REMARK
        INTO V_INTF_DEP_FTP.INTF_DEP_FTP_ID,
             V_INTF_DEP_FTP.BUS_CODE,
             V_INTF_DEP_FTP.FTP_TYPE,
             V_INTF_DEP_FTP.SRC_SYS_ID,
             V_INTF_DEP_FTP.DST_SYS_ID,
             V_INTF_DEP_FTP.FILE_FORMAT,
             V_INTF_DEP_FTP.FIELD_INTERVAL,
             V_INTF_DEP_FTP.RECORD_INTERVAL,
             V_INTF_DEP_FTP.USE_TYPE,
             V_INTF_DEP_FTP.SRC_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.SRC_PATH,
             V_INTF_DEP_FTP.DST_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.DST_PATH,
             V_INTF_DEP_FTP.TABLE_NAME,
             V_INTF_DEP_FTP.TABLE_FIELD,
             V_INTF_DEP_FTP.RECORD_NUM,
             V_INTF_DEP_FTP.OWNER,
             V_INTF_DEP_FTP.FREQUENCY,
             V_INTF_DEP_FTP.TIME_POINT,
             V_INTF_DEP_FTP.STATE,
             V_INTF_DEP_FTP.STATE_DATE,
             V_INTF_DEP_FTP.CREATE_DATE,
             V_INTF_DEP_FTP.UPDATE_DATE,
             V_INTF_DEP_FTP.REMARK
        FROM INTF_DEP_FTP IDF
       WHERE IDF.BUS_CODE = IN_BUS_CODE;
    ELSE
      SELECT INTF_DEP_FTP_ID,
             BUS_CODE,
             FTP_TYPE,
             SRC_SYS_ID,
             DST_SYS_ID,
             FILE_FORMAT,
             FIELD_INTERVAL,
             RECORD_INTERVAL,
             USE_TYPE,
             SRC_INTF_DEP_HOST_ID,
             SRC_PATH,
             DST_INTF_DEP_HOST_ID,
             DST_PATH,
             TABLE_NAME,
             TABLE_FIELD,
             RECORD_NUM,
             OWNER,
             FREQUENCY,
             TIME_POINT,
             STATE,
             STATE_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             REMARK
        INTO V_INTF_DEP_FTP.INTF_DEP_FTP_ID,
             V_INTF_DEP_FTP.BUS_CODE,
             V_INTF_DEP_FTP.FTP_TYPE,
             V_INTF_DEP_FTP.SRC_SYS_ID,
             V_INTF_DEP_FTP.DST_SYS_ID,
             V_INTF_DEP_FTP.FILE_FORMAT,
             V_INTF_DEP_FTP.FIELD_INTERVAL,
             V_INTF_DEP_FTP.RECORD_INTERVAL,
             V_INTF_DEP_FTP.USE_TYPE,
             V_INTF_DEP_FTP.SRC_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.SRC_PATH,
             V_INTF_DEP_FTP.DST_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.DST_PATH,
             V_INTF_DEP_FTP.TABLE_NAME,
             V_INTF_DEP_FTP.TABLE_FIELD,
             V_INTF_DEP_FTP.RECORD_NUM,
             V_INTF_DEP_FTP.OWNER,
             V_INTF_DEP_FTP.FREQUENCY,
             V_INTF_DEP_FTP.TIME_POINT,
             V_INTF_DEP_FTP.STATE,
             V_INTF_DEP_FTP.STATE_DATE,
             V_INTF_DEP_FTP.CREATE_DATE,
             V_INTF_DEP_FTP.UPDATE_DATE,
             V_INTF_DEP_FTP.REMARK
        FROM INTF_DEP_FTP IDF
       WHERE IDF.BUS_CODE = IN_BUS_CODE
         AND IDF.USE_TYPE = IN_USE_TYPE;
    END IF;
    V_CURRENT_PACKAGE := IN_CURRENT_PACKAGE;
    IF IN_CURRENT_PACKAGE < 100 THEN
      V_CURRENT_PACKAGE := '0' || IN_CURRENT_PACKAGE;
    END IF;
    IF IN_CURRENT_PACKAGE < 10 THEN
      V_CURRENT_PACKAGE := '00' || IN_CURRENT_PACKAGE;
    END IF;
    --文件命名规则:%BUS_CODE%||YYYYMMDDHH24MI||\d{3}
    V_FILE_NAME := V_BATCH_NBR || V_CURRENT_PACKAGE || '.txt';
    RETURN V_FILE_NAME;
  END;


  /*
  * 文件抽取 处理中，文件生成 等待中，文件上传 等待中
  * 按照10W条数据创建1个文件。
  *
  */
  PROCEDURE PROC_DEP_COMMON(IN_BUS_CODE          IN VARCHAR2,
                            IN_USE_TYPE          IN VARCHAR2,
                            IN_BATCH_NBR         IN VARCHAR2,
                            IN_CURRENT_PACKAGE   IN NUMBER,
                            IN_TOTAL_PACKAGE_NUM IN NUMBER) IS

    V_FILE_NAME               VARCHAR2(100);
    V_CURRENT_PACKAGE         NUMBER;
    V_BATCH_NBR               VARCHAR2(100);
    V_INTF_DEP_FTP_CONTROL_ID NUMBER;
    V_EXCEPITON               VARCHAR(500);
  BEGIN

   V_FILE_NAME := FUN_FILE_NAME_CREATE(IN_BUS_CODE,
                                          IN_USE_TYPE,
                                          IN_CURRENT_PACKAGE,
                                          IN_BATCH_NBR);

    V_BATCH_NBR       := IN_BATCH_NBR;
    V_CURRENT_PACKAGE := IN_CURRENT_PACKAGE;
    --文件抽取 待处理状态

    SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
      INTO V_INTF_DEP_FTP_CONTROL_ID
      FROM DUAL;
    IF IN_CURRENT_PACKAGE = 1 THEN
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
      VALUES
        (V_INTF_DEP_FTP_CONTROL_ID,
         IN_BUS_CODE,
         IN_BATCH_NBR,
         V_CURRENT_PACKAGE,
         IN_TOTAL_PACKAGE_NUM,
         V_FILE_NAME,
         '100',
         SYSDATE,
         SYSDATE,
         '70B',
         SYSDATE,
         SYSDATE,
         null,
         '0',
         SYSDATE - 10 / 1440,
         null,
         null,
         IN_USE_TYPE);
      --文件生成 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
      VALUES
        (V_INTF_DEP_FTP_CONTROL_ID,
         IN_BUS_CODE,
         IN_BATCH_NBR,
         IN_CURRENT_PACKAGE,
         IN_TOTAL_PACKAGE_NUM,
         V_FILE_NAME,
         '200',
         SYSDATE,
         SYSDATE,
         '70A',
         SYSDATE,
         SYSDATE,
         null,
         '0',
         SYSDATE - 10 / 1440,
         null,
         null,
         IN_USE_TYPE);
      --文件抽取 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
      VALUES
        (V_INTF_DEP_FTP_CONTROL_ID,
         IN_BUS_CODE,
         V_BATCH_NBR,
         IN_CURRENT_PACKAGE,
         IN_TOTAL_PACKAGE_NUM,
         V_FILE_NAME,
         '300',
         SYSDATE,
         SYSDATE,
         '70A',
         SYSDATE,
         SYSDATE,
         null,
         '0',
         SYSDATE - 10 / 1440,
         null,
         null,
         IN_USE_TYPE);
      commit;
    ELSE
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
        SELECT V_INTF_DEP_FTP_CONTROL_ID,
               BUS_CODE,
               BATCH_NBR,
               IN_CURRENT_PACKAGE,
               IN_TOTAL_PACKAGE_NUM,
               V_FILE_NAME,
               TYPE,
               START_TIME,
               END_TIME,
               STATE,
               STATE_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               DEAL_NUM,
               NEXT_DEAL_TIME,
               ERR_MSG,
               REMARK,
               IN_USE_TYPE
          FROM INTF_DEP_FTP_CONTROL
         WHERE BATCH_NBR = V_BATCH_NBR
           AND BUS_CODE = IN_BUS_CODE
           AND TYPE = '100'
           AND CURRENT_PACKAGE = 1
           AND ROWNUM = 1;
      --文件生成 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
        SELECT V_INTF_DEP_FTP_CONTROL_ID,
               BUS_CODE,
               BATCH_NBR,
               IN_CURRENT_PACKAGE,
               IN_TOTAL_PACKAGE_NUM,
               V_FILE_NAME,
               TYPE,
               START_TIME,
               END_TIME,
               STATE,
               STATE_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               DEAL_NUM,
               NEXT_DEAL_TIME,
               ERR_MSG,
               REMARK,
               IN_USE_TYPE
          FROM INTF_DEP_FTP_CONTROL
         WHERE BATCH_NBR = V_BATCH_NBR
           AND BUS_CODE = IN_BUS_CODE
           AND TYPE = '200'
           AND CURRENT_PACKAGE = 1
           AND ROWNUM = 1;
      --文件抽取 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
        SELECT V_INTF_DEP_FTP_CONTROL_ID,
               BUS_CODE,
               BATCH_NBR,
               IN_CURRENT_PACKAGE,
               IN_TOTAL_PACKAGE_NUM,
               V_FILE_NAME,
               TYPE,
               START_TIME,
               END_TIME,
               STATE,
               STATE_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               DEAL_NUM,
               NEXT_DEAL_TIME,
               ERR_MSG,
               REMARK,
               IN_USE_TYPE
          FROM INTF_DEP_FTP_CONTROL
         WHERE BATCH_NBR = V_BATCH_NBR
           AND BUS_CODE = IN_BUS_CODE
           AND TYPE = '300'
           AND CURRENT_PACKAGE = 1
           AND ROWNUM = 1;
      commit;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
      DBMS_OUTPUT.put_line(V_EXCEPITON);
  END;

  /**
  * 数据抽取完后回填
  *
  * 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
  */
  PROCEDURE PROC_DEP_COMPLETE(IN_BUS_CODE  IN VARCHAR2,
                              IN_BATCH_NBR IN VARCHAR2) IS

    V_BUS_CODE   VARCHAR2(100);
    V_BATCH_NBR  VARCHAR2(100);
    V_EXCEPITON  VARCHAR2(500);
    V_UPDATE_SQL VARCHAR2(200);
  BEGIN
    V_BUS_CODE   := IN_BUS_CODE;
    V_BATCH_NBR  := IN_BATCH_NBR;
    V_UPDATE_SQL := 'UPDATE INTF_DEP_FTP_CONTROL SET STATE=''70C'',END_TIME=SYSDATE,STATE_DATE  =SYSDATE WHERE TYPE=''100'' AND  BUS_CODE= ''' ||
                    V_BUS_CODE || '''' || ' AND BATCH_NBR=''' ||
                    V_BATCH_NBR || '''';
    EXECUTE IMMEDIATE V_UPDATE_SQL;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
  END;

  /*
  *清空数据中间表
  */
  PROCEDURE PROC_INIT_TABLE(IN_BUS_CODE IN VARCHAR2) IS
    V_SQL VARCHAR2(1000);
  BEGIN
    V_SQL := 'TRUNCATE TABLE INTF_' || IN_BUS_CODE || '_AUDIT';
    EXECUTE IMMEDIATE V_SQL;
    DELETE CRMV2.INTF_DEP_FTP_CONTROL
     WHERE BUS_CODE = IN_BUS_CODE
       --AND TRUNC(START_TIME) = TRUNC(SYSDATE);
       AND START_TIME > SYSDATE - 30 / 1440;
    COMMIT;
  END;
  /*
  分批次*/
  PROCEDURE PROC_CURRENT_PACKAGE_AVG(IN_TABLE_NAME       IN VARCHAR2,
                                     IN_BATCH_NBR        IN VARCHAR2,
                                     IN_MAX_NUMBER       IN INTEGER,
                                     O_TOTAL_PACKAGE_NUM OUT INTEGER) IS
    --V_SQL VARCHAR2(500);
    --V_TABLE_NAME VARCHAR2(50);
    V_CURRENT_PACKAGE   INTEGER;
    V_COUNT             INTEGER;
    V_TOTAL_PACKAGE_NUM INTEGER;
    --V_MAX_NUMBER        INTEGER;
    v_str varchar2(1000);
  BEGIN
    -- V_TABLE_NAME:=IN_TABLE_NAME;
    loop
      EXECUTE IMMEDIATE 'select nvl(max(CURRENT_PACKAGE), -1) + 1 from ' ||
                        IN_TABLE_NAME || ' where BATCH_NBR =''' ||
                        IN_BATCH_NBR || ''''
        into V_CURRENT_PACKAGE;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;
      EXECUTE IMMEDIATE 'select count(*)
        from ' || IN_TABLE_NAME ||
                        ' where CURRENT_PACKAGE = 0'
        into V_COUNT;

      if V_COUNT > IN_MAX_NUMBER then
        EXECUTE IMMEDIATE 'update ' || IN_TABLE_NAME ||
                          ' set CURRENT_PACKAGE = ' || V_CURRENT_PACKAGE ||
                          ' where CURRENT_PACKAGE = 0
           and rownum < (' || IN_MAX_NUMBER ||
                          ' + 1)';
      else
        EXECUTE IMMEDIATE 'update ' || IN_TABLE_NAME ||
                          ' set CURRENT_PACKAGE = ' || V_CURRENT_PACKAGE ||
                          ' where CURRENT_PACKAGE = 0';
      end if;
      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= IN_MAX_NUMBER;
    end loop;
    O_TOTAL_PACKAGE_NUM := V_TOTAL_PACKAGE_NUM;
  exception
    when others then
      v_str := sqlerrm;
  END;

  /*PROC_MAIN*/
  PROCEDURE PROC_MAIN IS
    V_EXCEPITON         VARCHAR(500);
  BEGIN
    PROC_BUS001;
    PROC_BUS002;
    PROC_BUS003;
    PROC_BUS004;
    PROC_BUS005;
    PROC_BUS006;
    PROC_BUS007;
    PROC_BUS008;
    PROC_BUS009;
    PROC_BUS010;
    PROC_BUS011;
    PROC_BUS012;
    PROC_BUS013;
    PROC_BUS014;
    PROC_BUS015;
  END;

  /*员工 STAFF*/
  PROCEDURE PROC_BUS001 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS001'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT STAFF_ID,PARTY_ID,STAFF_CODE,STAFF_NAME,STAFF_DESC,ORG_ID,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,STAFF_TYPE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,ID_CODE,DEV_ORG_ID,CHANNEL_ID,STAFF_NBR,SALES_CODE,LAST_LOGIN_DATE,COMMON_REGION_ID
                    FROM CRMV2.STAFF I WHERE  I.UPDATE_DATE>SYSDATE-1/48 ) LOOP

        INSERT INTO INTF_BUS001_AUDIT
          (STAFF_ID,PARTY_ID,STAFF_CODE,STAFF_NAME,STAFF_DESC,ORG_ID,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,STAFF_TYPE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,ID_CODE,DEV_ORG_ID,CHANNEL_ID,STAFF_NBR,SALES_CODE,LAST_LOGIN_DATE,COMMON_REGION_ID,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.STAFF_ID,REC.PARTY_ID,REC.STAFF_CODE,REC.STAFF_NAME,REC.STAFF_DESC,REC.ORG_ID,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.STAFF_TYPE,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.ID_CODE,REC.DEV_ORG_ID,REC.CHANNEL_ID,REC.STAFF_NBR,REC.SALES_CODE,REC.LAST_LOGIN_DATE,REC.COMMON_REGION_ID,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS001_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS001_AUDIT B
                      WHERE A.STAFF_ID = B.STAFF_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*销售员关联渠道 STAFF_CHANNEL_RELA*/
  PROCEDURE PROC_BUS002 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS002'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT RELA_ID,STAFF_ID,CHANNEL_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF
                    FROM CRMV2.STAFF_CHANNEL_RELA I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS002_AUDIT
          (RELA_ID,STAFF_ID,CHANNEL_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.RELA_ID,REC.STAFF_ID,REC.CHANNEL_ID,REC.RELA_TYPE,REC.DESCRIPTION,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.CREATE_STAFF,REC.UPDATE_DATE,REC.UPDATE_STAFF,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS002_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS002_AUDIT B
                      WHERE A.RELA_ID = B.RELA_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*销售员关联经营主体 STAFF_OPERATORS_RELA*/
  PROCEDURE PROC_BUS003 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS003'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT RELA_ID,OPERATORS_ID,STAFF_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF
                    FROM CRMV2.STAFF_OPERATORS_RELA I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS003_AUDIT
          (RELA_ID,OPERATORS_ID,STAFF_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.RELA_ID,REC.OPERATORS_ID,REC.STAFF_ID,REC.RELA_TYPE,REC.DESCRIPTION,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.CREATE_STAFF,REC.UPDATE_DATE,REC.UPDATE_STAFF,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS003_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS003_AUDIT B
                      WHERE A.RELA_ID = B.RELA_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*经营主体 OPERATORS*/
  PROCEDURE PROC_BUS004 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS004'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT OPERATORS_ID,ORG_ID,PARTY_ID,OPERATORS_NBR,OPERATORS_NAME,OPERATORS_AREA_GRADE,PARENT_OPER_ID,COMMON_REGION_ID,CERT_TYPE,CERT_NBR,OPERATORS_SNAME,LEGAL_REPR,ADDRESS,TELEPHONE,CONTACT,EMAIL,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,CHAIN_SHOP,EXT_OPERATORS_NBR,OPERATORS_TYPE_CD
                    FROM CRMV2.OPERATORS I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS004_AUDIT
          (OPERATORS_ID,ORG_ID,PARTY_ID,OPERATORS_NBR,OPERATORS_NAME,OPERATORS_AREA_GRADE,PARENT_OPER_ID,COMMON_REGION_ID,CERT_TYPE,CERT_NBR,OPERATORS_SNAME,LEGAL_REPR,ADDRESS,TELEPHONE,CONTACT,EMAIL,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,CHAIN_SHOP,EXT_OPERATORS_NBR,OPERATORS_TYPE_CD,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.OPERATORS_ID,REC.ORG_ID,REC.PARTY_ID,REC.OPERATORS_NBR,REC.OPERATORS_NAME,REC.OPERATORS_AREA_GRADE,REC.PARENT_OPER_ID,REC.COMMON_REGION_ID,REC.CERT_TYPE,REC.CERT_NBR,REC.OPERATORS_SNAME,REC.LEGAL_REPR,REC.ADDRESS,REC.TELEPHONE,REC.CONTACT,REC.EMAIL,REC.DESCRIPTION,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.CREATE_STAFF,REC.UPDATE_DATE,REC.UPDATE_STAFF,REC.CHAIN_SHOP,REC.EXT_OPERATORS_NBR,REC.OPERATORS_TYPE_CD,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS004_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS004_AUDIT B
                      WHERE A.OPERATORS_ID = B.OPERATORS_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*渠道 CHANNEL*/
  PROCEDURE PROC_BUS005 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS005'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT CHANNEL_ID,CHANNEL_NAME,CHANNEL_NBR,CHANNEL_LEVEL_CD,CHANNEL_TYPE_CD,CHANNEL_SUBTYPE_CD,STATUS_CD,PARENT_CHN_ID,CHANNEL_ADDRESS,CONTACT_PERSON,CONTACT_PHONE,CONTACT_ADDRESS,AREA_ID,REGION_CD,STATUS_DATE,CREATE_DATE,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,COMMON_REGION_ID,ORG_ID,PARTY_ID,GROUP_CHANNEL_ID,GROUP_CHANNEL_NBR,CHANNEL_CLASS,FULL_CIRCLE_SELLER_NAME,HX_GROUP_VIEW_CODE,QD_ORG_CODE,CHANNEL_CREAT_TIME,CHN_TYPE_CD
                    FROM CRMV2.CHANNEL I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS005_AUDIT
          (CHANNEL_ID,CHANNEL_NAME,CHANNEL_NBR,CHANNEL_LEVEL_CD,CHANNEL_TYPE_CD,CHANNEL_SUBTYPE_CD,STATUS_CD,PARENT_CHN_ID,CHANNEL_ADDRESS,CONTACT_PERSON,CONTACT_PHONE,CONTACT_ADDRESS,AREA_ID,REGION_CD,STATUS_DATE,CREATE_DATE,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,COMMON_REGION_ID,ORG_ID,PARTY_ID,GROUP_CHANNEL_ID,GROUP_CHANNEL_NBR,CHANNEL_CLASS,FULL_CIRCLE_SELLER_NAME,HX_GROUP_VIEW_CODE,QD_ORG_CODE,CHANNEL_CREAT_TIME,CHN_TYPE_CD,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.CHANNEL_ID,REC.CHANNEL_NAME,REC.CHANNEL_NBR,REC.CHANNEL_LEVEL_CD,REC.CHANNEL_TYPE_CD,REC.CHANNEL_SUBTYPE_CD,REC.STATUS_CD,REC.PARENT_CHN_ID,REC.CHANNEL_ADDRESS,REC.CONTACT_PERSON,REC.CONTACT_PHONE,REC.CONTACT_ADDRESS,REC.AREA_ID,REC.REGION_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.CREATE_STAFF,REC.UPDATE_DATE,REC.UPDATE_STAFF,REC.COMMON_REGION_ID,REC.ORG_ID,REC.PARTY_ID,REC.GROUP_CHANNEL_ID,REC.GROUP_CHANNEL_NBR,REC.CHANNEL_CLASS,REC.FULL_CIRCLE_SELLER_NAME,REC.HX_GROUP_VIEW_CODE,REC.QD_ORG_CODE,REC.CHANNEL_CREAT_TIME,REC.CHN_TYPE_CD,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS005_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS005_AUDIT B
                      WHERE A.CHANNEL_ID = B.CHANNEL_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*渠道关联组织 CHANNEL_ORG_RELA*/


  /*渠道关联组织 CHANNEL_ORG_RELA*/
  PROCEDURE PROC_BUS006 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS006'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT RELA_ID,CHANNEL_ID,ORG_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF
                    FROM CRMV2.CHANNEL_ORG_RELA I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS006_AUDIT
          (RELA_ID,CHANNEL_ID,ORG_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.RELA_ID,REC.CHANNEL_ID,REC.ORG_ID,REC.RELA_TYPE,REC.DESCRIPTION,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.CREATE_STAFF,REC.UPDATE_DATE,REC.UPDATE_STAFF,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS006_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS006_AUDIT B
                      WHERE A.RELA_ID = B.RELA_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*渠道关联经营场所 CHANNEL_OPERATORS_RELA*/
  PROCEDURE PROC_BUS007 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS007'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT RELA_ID,OPERATORS_ID,CHANNEL_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF
                    FROM CRMV2.CHANNEL_OPERATORS_RELA I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS007_AUDIT
          (RELA_ID,OPERATORS_ID,CHANNEL_ID,RELA_TYPE,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.RELA_ID,REC.OPERATORS_ID,REC.CHANNEL_ID,REC.RELA_TYPE,REC.DESCRIPTION,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.CREATE_STAFF,REC.UPDATE_DATE,REC.UPDATE_STAFF,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS007_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS007_AUDIT B
                      WHERE A.RELA_ID = B.RELA_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*渠道属性 CHANNEL_ATTR*/
  PROCEDURE PROC_BUS008 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS008'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT CHANNEL_ATTR_ID,ATTR_ID,CHANNEL_ID,ATTR_VALUE,ATTR_VALUE_ID,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF
                    FROM CRMV2.CHANNEL_ATTR I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS008_AUDIT
          (CHANNEL_ATTR_ID,ATTR_ID,CHANNEL_ID,ATTR_VALUE,ATTR_VALUE_ID,DESCRIPTION,STATUS_CD,STATUS_DATE,CREATE_DATE,AREA_ID,REGION_CD,CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.CHANNEL_ATTR_ID,REC.ATTR_ID,REC.CHANNEL_ID,REC.ATTR_VALUE,REC.ATTR_VALUE_ID,REC.DESCRIPTION,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.CREATE_STAFF,REC.UPDATE_DATE,REC.UPDATE_STAFF,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS008_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS008_AUDIT B
                      WHERE A.CHANNEL_ATTR_ID = B.CHANNEL_ATTR_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*组织 ORGANIZATION*/
  PROCEDURE PROC_BUS009 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS009'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT ORG_ID,COMMON_REGION_ID,PARENT_ORG_ID,ORG_TYPE,ORG_CONTENT,ORG_SCALE,PRINCIPAL,ORG_NAME,ORG_NAME_EN,ORG_CODE,AREA_CODE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,ORG_DUTY,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,TOWN_FLAG,ORG_SUB_TYPE,ORG_LEVEL,ORG_SORT,ORG_SEQ,PARTY_ID,CTG_CHANNEL_NBR,GROUP_ORG_ID,GROUP_ORG_CODE,CHANNEL_TYPE,STAFF_ID
                    FROM CRMV2.ORGANIZATION I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS009_AUDIT
          (ORG_ID,COMMON_REGION_ID,PARENT_ORG_ID,ORG_TYPE,ORG_CONTENT,ORG_SCALE,PRINCIPAL,ORG_NAME,ORG_NAME_EN,ORG_CODE,AREA_CODE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,ORG_DUTY,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,TOWN_FLAG,ORG_SUB_TYPE,ORG_LEVEL,ORG_SORT,ORG_SEQ,PARTY_ID,CTG_CHANNEL_NBR,GROUP_ORG_ID,GROUP_ORG_CODE,CHANNEL_TYPE,STAFF_ID,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.ORG_ID,REC.COMMON_REGION_ID,REC.PARENT_ORG_ID,REC.ORG_TYPE,REC.ORG_CONTENT,REC.ORG_SCALE,REC.PRINCIPAL,REC.ORG_NAME,REC.ORG_NAME_EN,REC.ORG_CODE,REC.AREA_CODE,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.ORG_DUTY,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.TOWN_FLAG,REC.ORG_SUB_TYPE,REC.ORG_LEVEL,REC.ORG_SORT,REC.ORG_SEQ,REC.PARTY_ID,REC.CTG_CHANNEL_NBR,REC.GROUP_ORG_ID,REC.GROUP_ORG_CODE,REC.CHANNEL_TYPE,REC.STAFF_ID,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS009_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS009_AUDIT B
                      WHERE A.ORG_ID = B.ORG_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*参与人 PARTY*/
  PROCEDURE PROC_BUS010 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS010'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT PARTY_ID,PARTY_NAME,PARTY_ABBRNAME,ENGLISH_NAME,PARTY_TYPE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,CERT_CHECK_RESULT,REC_UPDATE_DATE,PROC_SERIAL
                    FROM CRMV2.PARTY WHERE PARTY_ID IN (SELECT PARTY_ID FROM CRMV2.STAFF) AND UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS010_AUDIT
          (PARTY_ID,PARTY_NAME,PARTY_ABBRNAME,ENGLISH_NAME,PARTY_TYPE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,CERT_CHECK_RESULT,REC_UPDATE_DATE,PROC_SERIAL,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.PARTY_ID,REC.PARTY_NAME,REC.PARTY_ABBRNAME,REC.ENGLISH_NAME,REC.PARTY_TYPE,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.CERT_CHECK_RESULT,REC.REC_UPDATE_DATE,REC.PROC_SERIAL,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS010_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS010_AUDIT B
                      WHERE A.PARTY_ID = B.PARTY_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*参与人联系信息 PARTY_CONTACT_INFO*/
  PROCEDURE PROC_BUS011 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS011'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT CONTACT_ID,PARTY_ID,HEAD_FLAG,CONTACT_TYPE,CONTACT_NAME,CONTACT_GENDER,CONTACT_ADDRESS,CONTACT_EMPLOYER,HOME_PHONE,OFFICE_PHONE,MOBILE_PHONE,CONTACT_DESC,E_MAIL,POSTCODE,POST_ADDRESS,FAX,MOD_DATE,STAFF_ID,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,QQ_NUMBER,EXT_CONTACT_ID
                    FROM CRMV2.PARTY_CONTACT_INFO WHERE PARTY_ID IN (SELECT PARTY_ID FROM CRMV2.STAFF) AND UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS011_AUDIT
          (CONTACT_ID,PARTY_ID,HEAD_FLAG,CONTACT_TYPE,CONTACT_NAME,CONTACT_GENDER,CONTACT_ADDRESS,CONTACT_EMPLOYER,HOME_PHONE,OFFICE_PHONE,MOBILE_PHONE,CONTACT_DESC,E_MAIL,POSTCODE,POST_ADDRESS,FAX,MOD_DATE,STAFF_ID,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,QQ_NUMBER,EXT_CONTACT_ID,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.CONTACT_ID,REC.PARTY_ID,REC.HEAD_FLAG,REC.CONTACT_TYPE,REC.CONTACT_NAME,REC.CONTACT_GENDER,REC.CONTACT_ADDRESS,REC.CONTACT_EMPLOYER,REC.HOME_PHONE,REC.OFFICE_PHONE,REC.MOBILE_PHONE,REC.CONTACT_DESC,REC.E_MAIL,REC.POSTCODE,REC.POST_ADDRESS,REC.FAX,REC.MOD_DATE,REC.STAFF_ID,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.QQ_NUMBER,REC.EXT_CONTACT_ID,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS011_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS011_AUDIT B
                      WHERE A.CONTACT_ID = B.CONTACT_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*参与人证件 PARTY_CERTIFICATION*/
  PROCEDURE PROC_BUS012 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS012'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT PARTY_CERTI_ID,PARTY_ID,CERT_TYPE,CERT_ORG,CERT_ADDRESS,CERT_NUMBER,EFF_DATE,EXP_DATE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,CERT_SORT,PROC_SERIAL,EXT_PARTY_CERTI_ID
                    FROM CRMV2.PARTY_CERTIFICATION WHERE PARTY_ID IN (SELECT PARTY_ID FROM CRMV2.STAFF) AND UPDATE_DATE>SYSDATE-1/48 ) LOOP

        INSERT INTO INTF_BUS012_AUDIT
          (PARTY_CERTI_ID,PARTY_ID,CERT_TYPE,CERT_ORG,CERT_ADDRESS,CERT_NUMBER,EFF_DATE,EXP_DATE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,CERT_SORT,PROC_SERIAL,EXT_PARTY_CERTI_ID,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.PARTY_CERTI_ID,REC.PARTY_ID,REC.CERT_TYPE,REC.CERT_ORG,REC.CERT_ADDRESS,REC.CERT_NUMBER,REC.EFF_DATE,REC.EXP_DATE,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.CERT_SORT,REC.PROC_SERIAL,REC.EXT_PARTY_CERTI_ID,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS012_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS012_AUDIT B
                      WHERE A.PARTY_CERTI_ID = B.PARTY_CERTI_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*个人信息 INDIVIDUAL*/
  PROCEDURE PROC_BUS013 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS013'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,INDIVIDUAL_ID,PARTY_ID,BIRTHDAY,MARITAL_STATUS,GENDER,NATIONALITY,NATION,EDUCATION_LEVEL,EMPLOYER,RELIGION,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,ADDRESS_ID,ADDRESS_DESC,POST_CODE,OCCUPATION
                    FROM CRMV2.INDIVIDUAL WHERE PARTY_ID IN (SELECT PARTY_ID FROM CRMV2.STAFF) AND UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS013_AUDIT
          (STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,INDIVIDUAL_ID,PARTY_ID,BIRTHDAY,MARITAL_STATUS,GENDER,NATIONALITY,NATION,EDUCATION_LEVEL,EMPLOYER,RELIGION,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,ADDRESS_ID,ADDRESS_DESC,POST_CODE,OCCUPATION,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.INDIVIDUAL_ID,REC.PARTY_ID,REC.BIRTHDAY,REC.MARITAL_STATUS,REC.GENDER,REC.NATIONALITY,REC.NATION,REC.EDUCATION_LEVEL,REC.EMPLOYER,REC.RELIGION,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.ADDRESS_ID,REC.ADDRESS_DESC,REC.POST_CODE,REC.OCCUPATION,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS013_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS013_AUDIT B
                      WHERE A.INDIVIDUAL_ID = B.INDIVIDUAL_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*系统用户 SYSTEM_USER*/
  PROCEDURE PROC_BUS014 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS014'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT SYSTEM_USER_ID,STAFF_ID,STAFF_CODE,PASSWORD,PASSWORD_EFF_DATE,PASSWORD_EXP_DATE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,EXT_SYS_USER_ID,QUEUE_STAFF_CODE,CALL_SERIAL_NBR,USER_EFF_DATE,USER_EXP_DATE
                    FROM CRMV2.SYSTEM_USER I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS014_AUDIT
          (SYSTEM_USER_ID,STAFF_ID,STAFF_CODE,PASSWORD,PASSWORD_EFF_DATE,PASSWORD_EXP_DATE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,EXT_SYS_USER_ID,QUEUE_STAFF_CODE,CALL_SERIAL_NBR,USER_EFF_DATE,USER_EXP_DATE,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.SYSTEM_USER_ID,REC.STAFF_ID,REC.STAFF_CODE,REC.PASSWORD,REC.PASSWORD_EFF_DATE,REC.PASSWORD_EXP_DATE,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.EXT_SYS_USER_ID,REC.QUEUE_STAFF_CODE,REC.CALL_SERIAL_NBR,REC.USER_EFF_DATE,REC.USER_EXP_DATE,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS014_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS014_AUDIT B
                      WHERE A.SYSTEM_USER_ID = B.SYSTEM_USER_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

  /*区域 COMMON_REGION*/
  PROCEDURE PROC_BUS015 IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    --V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS015'; --业务功能编码
    V_TABLE_NAME        varchar2(30);
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    --清空数据中间表
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      V_INT_NUM := 0;
      FOR REC IN (SELECT COMMON_REGION_ID,UP_REGION_ID,REGION_NAME,REGION_CODE,REGION_TYPE,REGION_DESC,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,DEFAULT_REGION_ID,REMARK,COUNTY_TYPE
                    FROM CRMV2.COMMON_REGION I WHERE  I.UPDATE_DATE>SYSDATE-1/48) LOOP

        INSERT INTO INTF_BUS015_AUDIT
          (COMMON_REGION_ID,UP_REGION_ID,REGION_NAME,REGION_CODE,REGION_TYPE,REGION_DESC,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,DEFAULT_REGION_ID,REMARK,COUNTY_TYPE,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR)
        VALUES
          (REC.COMMON_REGION_ID,REC.UP_REGION_ID,REC.REGION_NAME,REC.REGION_CODE,REC.REGION_TYPE,REC.REGION_DESC,REC.AREA_ID,REC.REGION_CD,REC.UPDATE_STAFF,REC.CREATE_STAFF,REC.STATUS_CD,REC.STATUS_DATE,REC.CREATE_DATE,REC.UPDATE_DATE,REC.DEFAULT_REGION_ID,REC.REMARK,REC.COUNTY_TYPE,V_BUS_CODE,0,V_BATCH_NBR);
        V_INT_NUM := V_INT_NUM + 1;
        IF V_INT_NUM = 1000 THEN
           V_INT_NUM := 0;
           COMMIT;
        END IF;
      END LOOP;
      COMMIT;
    END;
    ---排重
    DELETE FROM CRMV2.INTF_BUS015_AUDIT A
     WHERE ROWID <> (SELECT MAX(ROWID)
                       FROM CRMV2.INTF_BUS015_AUDIT B
                      WHERE A.COMMON_REGION_ID = B.COMMON_REGION_ID);

    COMMIT;
    --分批次
    V_TABLE_NAME     := 'INTF_' || V_BUS_CODE || '_AUDIT';
    PROC_CURRENT_PACKAGE_AVG(V_TABLE_NAME,
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);
    V_INT_NUM := 2;
    IF V_TOTAL_PACKAGE_NUM > 1 THEN
      LOOP
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      END LOOP;
    END IF;
    --调整同批次号（分割次数总数）一致
    UPDATE CRMV2.INTF_DEP_FTP_CONTROL
       SET TOTAL_PACKAGE_NUM = V_TOTAL_PACKAGE_NUM
     WHERE BATCH_NBR = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;

END PKG_CRM_SYNC_UAM;
/
