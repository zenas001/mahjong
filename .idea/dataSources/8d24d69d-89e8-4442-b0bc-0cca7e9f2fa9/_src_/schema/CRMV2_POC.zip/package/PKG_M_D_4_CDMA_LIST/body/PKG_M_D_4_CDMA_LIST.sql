CREATE PACKAGE BODY           PKG_M_D_4_CDMA_LIST IS
  PROCEDURE PROC_DEAL_M_ZD_UP4_CDMA_LIST IS
    /*1个JOB每个月11日凌晨执行，将M_ZD_UP4_CDMA_LIST表中STATUS_CD=’70N’的数据
    根据PROD_INST_ID, USER_FLAG_ID往PROD_INST_ATTR表加相应记录，并上载计费内存；
    每处理1条记录，将表M_ZD_UP4_CDMA_LIST对应记录STATUS_CD改为’70A’;*/
    NUM1                NUMBER;
    V_PROD_INST_ATTR_ID NUMBER;
    V_AREA_NBR          AREA_CODE.AREA_NBR%TYPE;
    V_PROD_INST         PROD_INST%ROWTYPE;
    DD                  VARCHAR2(2);
    ROWNUM              NUMBER;
    PRODINSTNUM         NUMBER;
    V_HIS_ID            NUMBER;
    V_JOB_NAME          VARCHAR2(100);
    I_DB_JOB_ID         NUMBER;
    CURSOR CUR IS
      SELECT * FROM M_ZD_UP4_CDMA_LIST WHERE STATUS_CD = '70N';

  BEGIN
    V_JOB_NAME  := 'PROC_DEAL_M_ZD_UP4_CDMA_LIST';
    I_DB_JOB_ID := 4;
    PKG_PUBLIC.PROC_JOB_ENTRY(I_DB_JOB_ID, V_JOB_NAME);
    ROWNUM      := 0;
    PRODINSTNUM := 0;
    SELECT TO_CHAR(SYSDATE, 'DD') INTO DD FROM DUAL;
    IF DD IN ('11') THEN
      FOR REC IN CUR LOOP
        ---判断是否有该产品实例
        SELECT COUNT(*)
          INTO PRODINSTNUM
          FROM PROD_INST
         WHERE PROD_INST_ID = REC.PROD_ID;
        --产品实例不存在，直接更新M_ZD_UP4_CDMA_LIST 状态是70E
        IF PRODINSTNUM = 0 THEN
          UPDATE M_ZD_UP4_CDMA_LIST DZ
             SET DZ.STATUS_CD = '70E', REMARK = '处理失败，产品实例不存在'
           WHERE DZ.M_ZD_4G_CDMA_LIST_ID = REC.M_ZD_4G_CDMA_LIST_ID;
        ELSE
          --获取产品实例
          SELECT *
            INTO V_PROD_INST
            FROM PROD_INST
           WHERE PROD_INST_ID = REC.PROD_ID;
          --判断是否有有该标签产品实例属性
          SELECT COUNT(*)
            INTO NUM1
            FROM PROD_INST_ATTR
           WHERE PROD_INST_ID = REC.PROD_ID
             AND ATTR_ID = REC.USER_FLAG_ID;
          --不存在的话做下面的操作 ：新增产品实例属性，上载计费内存表
          IF NUM1 = 0 THEN
            SELECT SEQ_PROD_INST_ATTR_ID.NEXTVAL
              INTO V_PROD_INST_ATTR_ID
              FROM DUAL;
            --新增产品实例属性
            INSERT INTO PROD_INST_ATTR
              (PROD_INST_ATTR_ID,
               PROD_INST_ID,
               ATTR_ID,
               ATTR_VALUE_ID,
               ATTR_VALUE,
               STATUS_CD,
               STATUS_DATE,
               EFF_DATE,
               EXP_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               PROC_SERIAL,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               REC_UPDATE_DATE,
               VERSION)
            VALUES
              (V_PROD_INST_ATTR_ID,
               REC.PROD_ID,
               REC.USER_FLAG_ID,
               '',
               '1',
               '1000',
               SYSDATE,
               SYSDATE,
               TO_DATE('21990101', 'YYYYMMDD'),
               SYSDATE,
               SYSDATE,
               '',
               V_PROD_INST.AREA_ID,
               V_PROD_INST.COMMON_REGION_ID,
               '51447',
               '51447',
               '',
               '0');
            --产品实例属性变更记录移到历史表
            SELECT SEQ_PROD_INST_ATTR_HIS_ID.NEXTVAL
              INTO V_HIS_ID
              FROM DUAL;
            INSERT INTO PROD_INST_ATTR_HIS
              (PROD_INST_ATTR_ID,
               PROD_INST_ID,
               ATTR_ID,
               ATTR_VALUE_ID,
               ATTR_VALUE,
               STATUS_CD,
               STATUS_DATE,
               EFF_DATE,
               EXP_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               PROC_SERIAL,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               REC_UPDATE_DATE,
               VERSION,
               HIS_ID)
            VALUES
              (V_PROD_INST_ATTR_ID,
               REC.PROD_ID,
               REC.USER_FLAG_ID,
               '',
               '1',
               '1000',
               SYSDATE,
               SYSDATE,
               TO_DATE('21990101', 'YYYYMMDD'),
               SYSDATE,
               SYSDATE,
               '',
               V_PROD_INST.AREA_ID,
               V_PROD_INST.COMMON_REGION_ID,
               '51447',
               '51447',
               '',
               '0',
               V_HIS_ID);

            --获取产品实例对应的区域的信息
            SELECT A.AREA_NBR
              INTO V_AREA_NBR
              FROM AREA_CODE A, COMMON_REGION B, PROD_INST C
             WHERE A.REGION_ID = B.COMMON_REGION_ID
               AND B.COMMON_REGION_ID = C.AREA_ID
               AND C.PROD_INST_ID = REC.PROD_ID;
            ---上载计费内存   crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
            /*       BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('PROD_INST_ATTR',
            'PROD_INST_ATTR_ID',
            PROD_INST_ATTR_ID,
            '批量新增3升4打标标签',
            '1002',
            '批量新增3升4打标标签',
            '',
            V_AREA_NBR);*/

       /*     BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF
            ('PROD_INST_ATTR',
             'PROD_INST_ATTR_ID',
             V_PROD_INST_ATTR_ID,
             '批量新增3升4打标标签',
             '1002',
             '批量新增3升4打标标签',
             '',
             V_AREA_NBR);

            BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF
            ('PROD_INST_ATTR_HIS',
             'HIS_ID',
             V_HIS_ID,
             '批量新增3升4打标标签',
             '1002',
             '批量新增3升4打标标签',
             '',
             V_AREA_NBR);*/

             PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE
            ('PROD_INST_ATTR',
             'PROD_INST_ATTR_ID',
             V_PROD_INST_ATTR_ID,
             '批量新增3升4打标标签',
             '1002',
             '批量新增3升4打标标签',
             '',
             V_AREA_NBR);

      /*       PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE
            ('PROD_INST_ATTR_HIS',
             'HIS_ID',
             V_HIS_ID,
             '批量新增3升4打标标签',
             '1002',
             '批量新增3升4打标标签',
             '',
             V_AREA_NBR);*/


     ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS','HIS_ID',V_HIS_ID,
    'pkg_m_d_4_CDMA_LIST 插入PROD_INST_ATTR_HIS记录','','CREATE','');
            --更新 M_ZD_UP4_CDMA_LIST 为70A成功
            UPDATE M_ZD_UP4_CDMA_LIST DZ
               SET DZ.STATUS_CD = '70A', REMARK = '处理成功'
             WHERE DZ.M_ZD_4G_CDMA_LIST_ID = REC.M_ZD_4G_CDMA_LIST_ID;
          ELSE
            --更新 M_ZD_UP4_CDMA_LIST 为70E失败
            UPDATE M_ZD_UP4_CDMA_LIST DZ
               SET DZ.STATUS_CD = '70E',
                   REMARK       = '处理失败,产品实例已经有该属性，无需新增'
             WHERE DZ.M_ZD_4G_CDMA_LIST_ID = REC.M_ZD_4G_CDMA_LIST_ID;
          END IF;
        END IF;
        --将处理的数据移到历史表 M_ZD_UP4_CDMA_LIST_HIS
        INSERT INTO M_ZD_UP4_CDMA_LIST_HIS
          SELECT *
            FROM M_ZD_UP4_CDMA_LIST DZ
           WHERE DZ.M_ZD_4G_CDMA_LIST_ID = REC.M_ZD_4G_CDMA_LIST_ID;
        --删除一表的数据
        DELETE FROM M_ZD_UP4_CDMA_LIST DZ
         WHERE DZ.M_ZD_4G_CDMA_LIST_ID = REC.M_ZD_4G_CDMA_LIST_ID;
        ROWNUM := ROWNUM + 1;
        IF ROWNUM >= 100 THEN
          ROWNUM := 0;
          COMMIT;
        END IF;
      END LOOP;
      COMMIT;
      PKG_PUBLIC.PROC_JOB_FINISH_NOTIFY(V_JOB_NAME);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PKG_PUBLIC.PROC_SAVE_LOG(V_JOB_NAME, SUBSTR(SQLERRM, 1, 450));
  END;

  PROCEDURE PROC_DEAL_D_ZD_4G_CDMA_LIST IS
    /*1个JOB每天凌晨3点执行，将D_ZD_4G_CDMA_LIST表中STATUS_CD=’70N’的数据
    根据PROD_INST_ID, USER_FLAG_ID将PROD_INST_ATTR表已有标签删除(指的是删除4G属性的标签吗)，
    并上载计费内存，将表D_ZD_4G_CDMA_LIST对应记录STATUS_CD改为’70A’*/
    NUM1                NUMBER;
    V_PROD_INST_ATTR_ID NUMBER;
    V_AREA_NBR          AREA_CODE.AREA_NBR%TYPE;
    ROWNUM              NUMBER;
    PRODINSTNUM         NUMBER;
    V_HIS_ID            NUMBER;
    V_JOB_NAME          VARCHAR2(100);
    I_DB_JOB_ID         NUMBER;
    CURSOR CUR IS
      SELECT * FROM D_ZD_4G_CDMA_LIST WHERE STATUS_CD = '70N';
  BEGIN
    ROWNUM      := 0;
    PRODINSTNUM := 0;
    V_JOB_NAME  := 'PROC_DEAL_D_ZD_4G_CDMA_LIST';
    I_DB_JOB_ID := 3;
    PKG_PUBLIC.PROC_JOB_ENTRY(I_DB_JOB_ID, V_JOB_NAME);
    FOR REC IN CUR LOOP
      --判断是否有此产品实例ID对应的产品实例
      SELECT COUNT(*)
        INTO PRODINSTNUM
        FROM PROD_INST A
       WHERE A.PROD_INST_ID = REC.PROD_ID;
      --如果产品实例不存在，更新D_ZD_4G_CDMA_LIST 为70E
      IF PRODINSTNUM = 0 THEN
        UPDATE D_ZD_4G_CDMA_LIST DZ
           SET DZ.STATUS_CD = '70E', REMARK = '处理失败，产品实例不存在'
         WHERE DZ.D_ZD_4G_CDMA_LIST_ID = REC.D_ZD_4G_CDMA_LIST_ID;
      ELSE
        --产品实例存在的话，判断是否有该标签属性
        SELECT COUNT(*)
          INTO NUM1
          FROM PROD_INST_ATTR
         WHERE PROD_INST_ID = REC.PROD_ID
           AND ATTR_ID = REC.USER_FLAG_ID;
        --存在的话，进行下面的逻辑操作 ：删除该标签属性，上载计费内存
        IF NUM1 = 1 THEN
          SELECT PROD_INST_ATTR_ID
            INTO V_PROD_INST_ATTR_ID
            FROM PROD_INST_ATTR
           WHERE PROD_INST_ID = REC.PROD_ID
             AND ATTR_ID = REC.USER_FLAG_ID;
          --插入到历史表中PROD_INST_ATTR_HIS
          SELECT SEQ_PROD_INST_ATTR_HIS_ID.NEXTVAL INTO V_HIS_ID FROM DUAL;
          INSERT INTO PROD_INST_ATTR_HIS
            (PROD_INST_ATTR_ID,
             PROD_INST_ID,
             ATTR_ID,
             ATTR_VALUE_ID,
             ATTR_VALUE,
             STATUS_CD,
             STATUS_DATE,
             EFF_DATE,
             EXP_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             PROC_SERIAL,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             HIS_ID,
             REC_UPDATE_DATE,
             VERSION)
            SELECT PROD_INST_ATTR_ID,
                   PROD_INST_ID,
                   ATTR_ID,
                   ATTR_VALUE_ID,
                   ATTR_VALUE,
                   STATUS_CD,
                   STATUS_DATE,
                   EFF_DATE,
                   EXP_DATE,
                   CREATE_DATE,
                   UPDATE_DATE,
                   PROC_SERIAL,
                   AREA_ID,
                   REGION_CD,
                   UPDATE_STAFF,
                   CREATE_STAFF,
                   V_HIS_ID,
                   SYSDATE,
                   VERSION
              FROM PROD_INST_ATTR
             WHERE PROD_INST_ATTR_ID = V_PROD_INST_ATTR_ID;
          --删除1表的数据PROD_INST_ATTR
          DELETE FROM PROD_INST_ATTR
           WHERE PROD_INST_ID = REC.PROD_ID
             AND ATTR_ID = REC.USER_FLAG_ID;
          --获取产品实例对应的区域
          SELECT A.AREA_NBR
            INTO V_AREA_NBR
            FROM AREA_CODE A, COMMON_REGION B, PROD_INST C
           WHERE A.REGION_ID = B.COMMON_REGION_ID
             AND B.COMMON_REGION_ID = C.AREA_ID
             AND C.PROD_INST_ID = REC.PROD_ID;
          --上载计费内存表  crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
         /* BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF
          ('PROD_INST_ATTR',
           'PROD_INST_ATTR_ID',
           V_PROD_INST_ATTR_ID,
           '批量新增3升4打标标签',
           '1002',
           '批量新增3升4打标标签',
           '',
           V_AREA_NBR);

          BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF
          ('PROD_INST_ATTR_HIS',
           'HIS_ID',
           V_HIS_ID,
           '批量新增3升4打标标签',
           '1002',
           '批量新增3升4打标标签',
           '',
           V_AREA_NBR);*/

           PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE
          ('PROD_INST_ATTR',
           'PROD_INST_ATTR_ID',
           V_PROD_INST_ATTR_ID,
           '批量新增3升4打标标签',
           '1002',
           '批量新增3升4打标标签',
           '',
           V_AREA_NBR);

        /*  PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE
          ('PROD_INST_ATTR_HIS',
           'HIS_ID',
           V_HIS_ID,
           '批量新增3升4打标标签',
           '1002',
           '批量新增3升4打标标签',
           '',
           V_AREA_NBR);
           */

            ds_ins_intf_ins_ds_update_wh('PROD_INST_ATTR_HIS','HIS_ID',V_HIS_ID,
    'pkg_m_d_4_CDMA_LIST 插入PROD_INST_ATTR_HIS记录','','CREATE','');
          --更新 D_ZD_4G_CDMA_LIST状态为 70A 处理成功
          UPDATE D_ZD_4G_CDMA_LIST DZ
             SET DZ.STATUS_CD = '70A', REMARK = '处理成功'
           WHERE DZ.D_ZD_4G_CDMA_LIST_ID = REC.D_ZD_4G_CDMA_LIST_ID;
        ELSE
          --更新1表的数据D_ZD_4G_CDMA_LIST 的状态为70E 处理失败
          UPDATE D_ZD_4G_CDMA_LIST DZ
             SET DZ.STATUS_CD = '70E',
                 REMARK       = '处理失败，产品实例不存在该标签属性'
           WHERE DZ.D_ZD_4G_CDMA_LIST_ID = REC.D_ZD_4G_CDMA_LIST_ID;
        END IF;
      END IF;
      -- 将数据移动历史表中D_ZD_4G_CDMA_LIST_HIS
      INSERT INTO D_ZD_4G_CDMA_LIST_HIS
        SELECT *
          FROM D_ZD_4G_CDMA_LIST DZ
         WHERE DZ.D_ZD_4G_CDMA_LIST_ID = REC.D_ZD_4G_CDMA_LIST_ID;
      ---删除1表的数据 D_ZD_4G_CDMA_LIST
      DELETE FROM D_ZD_4G_CDMA_LIST DZ
       WHERE DZ.D_ZD_4G_CDMA_LIST_ID = REC.D_ZD_4G_CDMA_LIST_ID;
      --每100条提交一次
      ROWNUM := ROWNUM + 1;
      IF ROWNUM >= 100 THEN
        COMMIT;
        ROWNUM := 0;
      END IF;
    END LOOP;
    COMMIT;
    PKG_PUBLIC.PROC_JOB_FINISH_NOTIFY(V_JOB_NAME);
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PKG_PUBLIC.PROC_SAVE_LOG(V_JOB_NAME, SUBSTR(SQLERRM, 1, 450));
  END;
  PROCEDURE PROC_GET_M_ZD_UP4_CDMA_LIST IS
    DD          VARCHAR2(2);
    MM          VARCHAR2(2);
    YYYY        VARCHAR2(4);
    BEGIN_TIME  VARCHAR2(30);
    END_TIME    VARCHAR2(30);
    V_JOB_NAME  VARCHAR2(100);
    I_DB_JOB_ID NUMBER;
  BEGIN
    V_JOB_NAME  := 'PROC_GET_M_ZD_UP4_CDMA_LIST';
    I_DB_JOB_ID := 2;
    PKG_PUBLIC.PROC_JOB_ENTRY(I_DB_JOB_ID, V_JOB_NAME);
    SELECT TO_CHAR(SYSDATE, 'DD') INTO DD FROM DUAL;
    SELECT TO_CHAR(SYSDATE, 'MM') INTO MM FROM DUAL;
    SELECT TO_CHAR(SYSDATE, 'YYYY') INTO YYYY FROM DUAL;
    IF DD = '10' THEN
      IF MM IN
         ('02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12') THEN
        IF MM IN ('11', '12') THEN
          BEGIN_TIME := YYYY || (MM - 1) || '10';
        ELSE
          BEGIN_TIME := YYYY || '0' || (MM - 1) || '10';
        END IF;
        END_TIME := YYYY || MM || '09';
        INSERT INTO M_ZD_UP4_CDMA_LIST
          (THE_DATE,
           LATN_NAME,
           PROD_ID,
           SERV_ACC_NBR,
           USER_FLAG_ID,
           USER_FLAG_NAME,
           STATUS_CD,
           M_ZD_4G_CDMA_LIST_ID)
          SELECT T.THE_DATE,
                 T.LATN_NAME,
                 T.PROD_ID,
                 T.SERV_ACC_NBR,
                 T.USER_FLAG_ID,
                 T.USER_FLAG_NAME,
                 T.STATUS_CD,
                 SEQ_M_ZD_4G_CDMA_LIST_ID.NEXTVAL
            FROM (SELECT MZ.THE_DATE,
                         MZ.LATN_NAME,
                         MZ.PROD_ID,
                         MZ.SERV_ACC_NBR,
                         MZ.USER_FLAG_ID,
                         MZ.USER_FLAG_NAME,
                         '70N' STATUS_CD
                           /*20160518 测试需要先注释
                    FROM JK_CRM.M_ZD_UP4_CDMA_LIST@LK_CRM2ODS MZ*/
                         from   BASEJK.M_ZD_UP4_CDMA_LIST MZ
                   WHERE MZ.ETL_DATE BETWEEN TO_DATE(BEGIN_TIME, 'YYYYMMDD') AND
                         TO_DATE(END_TIME, 'YYYYMMDD')
                     AND NOT EXISTS
                   (SELECT 1
                            FROM M_ZD_UP4_CDMA_LIST A
                           WHERE A.THE_DATE = MZ.THE_DATE
                             AND A.PROD_ID = MZ.PROD_ID)) T;
        COMMIT;
        PKG_PUBLIC.PROC_JOB_FINISH_NOTIFY(V_JOB_NAME);
      ELSE
        BEGIN_TIME := YYYY - 1 || '1210';
        END_TIME   := YYYY || MM || '09';
        INSERT INTO M_ZD_UP4_CDMA_LIST
          (THE_DATE,
           LATN_NAME,
           PROD_ID,
           SERV_ACC_NBR,
           USER_FLAG_ID,
           USER_FLAG_NAME,
           STATUS_CD,
           M_ZD_4G_CDMA_LIST_ID)
          SELECT T.THE_DATE,
                 T.LATN_NAME,
                 T.PROD_ID,
                 T.SERV_ACC_NBR,
                 T.USER_FLAG_ID,
                 T.USER_FLAG_NAME,
                 T.STATUS_CD,
                 SEQ_M_ZD_4G_CDMA_LIST_ID.NEXTVAL
            FROM (SELECT MZ.THE_DATE,
                         MZ.LATN_NAME,
                         MZ.PROD_ID,
                         MZ.SERV_ACC_NBR,
                         MZ.USER_FLAG_ID,
                         MZ.USER_FLAG_NAME,
                         '70N' STATUS_CD
                           /*20160518 测试需要先注释
                    FROM  JK_CRM.M_ZD_UP4_CDMA_LIST@LK_CRM2ODS MZ*/
                         from BASEJK.M_ZD_UP4_CDMA_LIST MZ
                   WHERE MZ.ETL_DATE BETWEEN TO_DATE(BEGIN_TIME, 'YYYYMMDD') AND
                         TO_DATE(END_TIME, 'YYYYMMDD')
                     AND NOT EXISTS
                   (SELECT 1
                            FROM M_ZD_UP4_CDMA_LIST A
                           WHERE A.THE_DATE = MZ.THE_DATE
                             AND A.PROD_ID = MZ.PROD_ID)) T;
        COMMIT;
        PKG_PUBLIC.PROC_JOB_FINISH_NOTIFY(V_JOB_NAME);
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PKG_PUBLIC.PROC_SAVE_LOG(V_JOB_NAME, SUBSTR(SQLERRM, 1, 450));
  END;
  PROCEDURE PROC_GET_D_ZD_4G_CDMA_LIST IS
    V_JOB_NAME  VARCHAR2(100);
    I_DB_JOB_ID NUMBER;
  BEGIN
    I_DB_JOB_ID := 1;
    V_JOB_NAME  := 'PROC_GET_D_ZD_4G_CDMA_LIST';
    PKG_PUBLIC.PROC_JOB_ENTRY(I_DB_JOB_ID, V_JOB_NAME);
    INSERT INTO D_ZD_4G_CDMA_LIST
      (THE_DATE,
       LATN_NAME,
       PROD_ID,
       SERV_ACC_NBR,
       USER_FLAG_ID,
       USER_FLAG_NAME,
       STATUS_CD,
       D_ZD_4G_CDMA_LIST_ID)
      SELECT T.THE_DATE,
             T.LATN_NAME,
             T.PROD_ID,
             T.SERV_ACC_NBR,
             T.USER_FLAG_ID,
             T.USER_FLAG_NAME,
             T.STATUS_CD,
             SEQ_D_ZD_4G_CDMA_LIST_ID.NEXTVAL
        FROM (SELECT DZ.THE_DATE,
                     DZ.LATN_NAME,
                     DZ.PROD_ID,
                     DZ.SERV_ACC_NBR,
                     DZ.USER_FLAG_ID,
                     DZ.USER_FLAG_NAME,
                     '70N' STATUS_CD
                     /*20160518 测试需要先注释
                FROM JK_CRM.D_ZD_4G_CDMA_LIST@LK_CRM2ODS DZ*/
                     from BASEJK.D_ZD_4G_CDMA_LIST DZ
               WHERE DZ.ETL_DATE = TRUNC(SYSDATE - 1)
                 AND NOT EXISTS (SELECT 1
                        FROM D_ZD_4G_CDMA_LIST A
                       WHERE A.THE_DATE = DZ.THE_DATE
                         AND A.PROD_ID = DZ.PROD_ID)
              ) T;
    COMMIT;
    PKG_PUBLIC.PROC_JOB_FINISH_NOTIFY(V_JOB_NAME);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PKG_PUBLIC.PROC_SAVE_LOG(V_JOB_NAME, SUBSTR(SQLERRM, 1, 450));
  END;


   PROCEDURE PROC_GET_INTF_YXTYK_LIST IS
    V_JOB_NAME  VARCHAR2(100);
    I_DB_JOB_ID NUMBER;
  BEGIN
    I_DB_JOB_ID := 1;
    V_JOB_NAME  := 'PROC_GET_INTF_YXTYK_LIST';
    PKG_PUBLIC.PROC_JOB_ENTRY(I_DB_JOB_ID, V_JOB_NAME);
   INSERT INTO INTF_YXTYK_LIST a
      ( THE_DATE,
       LATN_ID,
       PROD_INST_ID,
       CREATE_DATE,
       ACC_NBR,
       ETL_DATE,
       state,
       INTF_YXTYK_LIST_ID)
      SELECT T.THE_DATE,
             T.latn_id,
             T.PROD_ID,
             T.crt_dt,
             T.serv_acc_nbr,
             T.etl_date,
             T.state,
             SEQ_INTF_YXTYK_LIST_ID.NEXTVAL
        FROM (SELECT DZ.the_date,
                     DZ.latn_id,
                     DZ.PROD_ID,
                     DZ.crt_dt,
                     DZ.serv_acc_nbr,
                     DZ.etl_date,
                     'N' state
                     /*20160518 测试需要先注释
                FROM JK_CRM.INTF_YXTYK_LIST@LK_CRM2ODS DZ*/
                     from BASEJK.INTF_YXTYK_LIST DZ
               WHERE DZ.ETL_DATE = TRUNC(SYSDATE)
                 AND NOT EXISTS (SELECT 1
                        FROM INTF_YXTYK_LIST A
                       WHERE A.THE_DATE = DZ.THE_DATE
                         AND A.PROD_INST_ID = DZ.PROD_ID)
              ) T;
    COMMIT;
    PKG_PUBLIC.PROC_JOB_FINISH_NOTIFY(V_JOB_NAME);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PKG_PUBLIC.PROC_SAVE_LOG(V_JOB_NAME, SUBSTR(SQLERRM, 1, 450));
  END;
END PKG_M_D_4_CDMA_LIST;
/
