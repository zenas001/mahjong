CREATE PACKAGE           PKG_PROD_OFFER_ATTR_DEAL IS

  -- AUTHOR  : LIUFZH
  -- CREATED : 2016/4/11 15:53:59
  -- PURPOSE :  CRM00075476 子单_全省_关于新增“4G融合高值套餐副卡语音流量促销包”的需求_接口组

  PROCEDURE PRC_PROD_OFFER_ATTR_DEAL;
  /*取出符合条件的中间表
  1、通过OFFER_PROD_INST_REL计算副卡数量时，要关联PROD_INST表取PRODUCT_ID= 800000002的数量；
  不能只查ROLE_CD= 13932（加装移动电话）的数量，副卡关联程控产品的角色也都是这个,不能统计在内；且
  要判断当前在用的副卡数量（不含：停保用户，生效日期为次月的用户）；
  */
  PROCEDURE PRC_PROD_OFFER_ATTR_DEAL_1;

  /*遍历NUM_OFFER_PROD_INST_REL 循环处理 */
  PROCEDURE PRC_PROD_OFFER_ATTR_DEAL_2;

  /*属性处理在这边
  1、前台受理时，赠送时长、赠送流量两个参数不可见，
  程序处理逻辑要判断若‘903440525 2016-4G融合高值套餐赠送语音流量促销包’
  实例上没有赠送时长、赠送流量的参数，则INSERT参数实例，若已有参数，
  则先将参数实例删除到历史表再插入；
  2、新增删除的记录要通过批量接口送计费内存*/
  PROCEDURE PRC_PROD_OFFER_ATTR_DEAL_3(V_NUM_OFFER_PROD_INST_REL IN NUM_OFFER_PROD_INST_REL%ROWTYPE,
                                       V_ATTR_ID                 IN NUMBER,
                                       V_PROD_OFFER_INST         IN PROD_OFFER_INST%ROWTYPE);
  /*关联的副卡为0 的情况下，如果可选包上有这两个属性的话，要将属性值设置成0*/
  /*  PROCEDURE PRC_PROD_OFFER_ATTR_DEAL_4;*/
  /*获取下个月的时间*/
  FUNCTION FUNC_NEXT_MONTH_FIRST_DAY RETURN DATE;
END PKG_PROD_OFFER_ATTR_DEAL;
/
