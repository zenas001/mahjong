CREATE PACKAGE BODY           PKG_DEP_MAINTAIN IS

  /*-------------------------------------------------
    INTF_DEP_ORDER
    Author  : OUZHF
    Created : 2014-03-13
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_DEP_ORDER_HIS IS
  BEGIN
    FOR REC IN (SELECT *
                  FROM INTF_DEP_ORDER A
                 WHERE STATE IN ('70C', '70D')
                    OR (STATE = '70E' AND PRE_HANDLE_FLAG = 'E' AND
                       CREATE_DATE < SYSDATE - 1)) LOOP
      BEGIN
        FOR REL IN (SELECT *
                      FROM INTF_DEP_ORDER_PACKAGE_REL
                     WHERE INTF_DEP_ORDER_ID = REC.INTF_DEP_ORDER_ID) LOOP
          BEGIN
            --INTF_DEP_DATA_INFO
            INSERT INTO INTF_DEP_DATA_INFO_HIS
              SELECT INTF_DEP_DATA_INFO_ID,INTF_DEP_ORDER_PACKAGE_REL_ID,DATA_INFO,REMARK,sysdate
                FROM INTF_DEP_DATA_INFO
               WHERE INTF_DEP_ORDER_PACKAGE_REL_ID =
                     REL.INTF_DEP_ORDER_PACKAGE_REL_ID;
            DELETE FROM INTF_DEP_DATA_INFO
             WHERE INTF_DEP_ORDER_PACKAGE_REL_ID =
                   REL.INTF_DEP_ORDER_PACKAGE_REL_ID;

            --INTF_DEP_ORDER_PACKAGE_REL
            INSERT INTO INTF_DEP_ORDER_PACKAGE_REL_HIS
              SELECT *
                FROM INTF_DEP_ORDER_PACKAGE_REL
               WHERE INTF_DEP_ORDER_PACKAGE_REL_ID =
                     REL.INTF_DEP_ORDER_PACKAGE_REL_ID;
            DELETE FROM INTF_DEP_ORDER_PACKAGE_REL
             WHERE INTF_DEP_ORDER_PACKAGE_REL_ID =
                   REL.INTF_DEP_ORDER_PACKAGE_REL_ID;
          END;
        END LOOP;

        --INTF_DEP_ORDER
        INSERT INTO INTF_DEP_ORDER_HIS
          SELECT *
            FROM INTF_DEP_ORDER
           WHERE INTF_DEP_ORDER_ID = REC.INTF_DEP_ORDER_ID;
        DELETE FROM INTF_DEP_ORDER
         WHERE INTF_DEP_ORDER_ID = REC.INTF_DEP_ORDER_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
    INTF_DEP_FINISH
    Author  : OUZHF
    Created : 2014-03-13
  -------------------------------------------------*/
  PROCEDURE PROC_INTF_DEP_FINISH_HIS IS
  BEGIN
    FOR REC IN (SELECT *
                  FROM INTF_DEP_FINISH A
                 WHERE STATE IN ('70C', '70D')) LOOP
      BEGIN
        FOR REL IN (SELECT *
                      FROM INTF_DEP_ORDER_ITEM_REL
                     WHERE INTF_DEP_FINISH_ID = REC.INTF_DEP_FINISH_ID) LOOP
          BEGIN
            --INTF_DEP_ORDER_ITEM_ATTR
            INSERT INTO INTF_DEP_ORDER_ITEM_ATTR_HIS
              SELECT *
                FROM INTF_DEP_ORDER_ITEM_ATTR
               WHERE INTF_DEP_ORDER_ITEM_REL_ID =
                     REL.INTF_DEP_ORDER_ITEM_REL_ID;
            DELETE FROM INTF_DEP_ORDER_ITEM_ATTR
             WHERE INTF_DEP_ORDER_ITEM_REL_ID =
                   REL.INTF_DEP_ORDER_ITEM_REL_ID;

            --INTF_DEP_ORDER_ITEM_REL
            INSERT INTO INTF_DEP_ORDER_ITEM_REL_HIS
              SELECT *
                FROM INTF_DEP_ORDER_ITEM_REL
               WHERE INTF_DEP_ORDER_ITEM_REL_ID =
                     REL.INTF_DEP_ORDER_ITEM_REL_ID;
            DELETE FROM INTF_DEP_ORDER_ITEM_REL
             WHERE INTF_DEP_ORDER_ITEM_REL_ID =
                   REL.INTF_DEP_ORDER_ITEM_REL_ID;
          END;
        END LOOP;

        --INTF_DEP_FINISH
        INSERT INTO INTF_DEP_FINISH_HIS
          SELECT *
            FROM INTF_DEP_FINISH
           WHERE INTF_DEP_FINISH_ID = REC.INTF_DEP_FINISH_ID;
        DELETE FROM INTF_DEP_FINISH
         WHERE INTF_DEP_FINISH_ID = REC.INTF_DEP_FINISH_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

  /*-------------------------------------------------
   DOC_INFO
   Author  : zhengchb
   Created : 2015-11-30
  -------------------------------------------------*/
  PROCEDURE PROC_DOC_INFO IS
  BEGIN
    FOR REC IN (SELECT DOC_INFO_ID
                  FROM DOC_INFO DI
                 WHERE DI.DOC_APP_OBJECT_TYPE = 'SALE_ORDER_NBR'
                   AND NOT EXISTS
                 (SELECT '1'
                          FROM DOC_ORDER DO
                         WHERE DO.DOC_ID = DI.DOC_ID
                           AND DO.STATE IN ('70A', '70E', '70F'))
                   AND EXISTS
                 (SELECT '1'
                          FROM PRE_SALE_ORDER_HIS PSO
                         WHERE PSO.PRE_ORDER_NUMBER = DI.DOC_APP_OBJECT
                           AND PSO.SEQ = '1'
                           AND PSO.STATUS_CD in ('300000','401200'))) LOOP
      BEGIN
        DELETE FROM DOC_INFO WHERE DOC_INFO_ID = REC.DOC_INFO_ID;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
      END;
    END LOOP;
  END;

END PKG_DEP_MAINTAIN;
/
