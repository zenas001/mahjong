CREATE PACKAGE           PKG_CRM2_SQL_MONITOR_2 IS
  PROCEDURE P_GET_DAY_SQL;
  function remove_constants( p_query in varchar2 ) return VARCHAR2;
END;
/
