CREATE PACKAGE BODY           PKG_DEP_EXTRACT_111 IS
  V_PROVINCE_ID VARCHAR2(10) := '8350000';
  --v_use_type    VARCHAR2(50) := '';
  --批次号生成，格式 BUS_CODE||YYYYMMDDHH24MISS
  FUNCTION FUN_BATCH_NBR_CREATE(IN_BUS_CODE IN VARCHAR2) RETURN VARCHAR2 IS
    V_BUS_CODE  VARCHAR2(50);
    V_SYS_DATE  VARCHAR2(30);
    V_BATCH_NBR VARCHAR2(100);
  BEGIN
    V_BUS_CODE := IN_BUS_CODE;
    SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') INTO V_SYS_DATE FROM DUAL;

    V_BATCH_NBR := V_BUS_CODE || V_SYS_DATE;
    RETURN V_BATCH_NBR;
  END;

  --文件名生成,格式 60010500011000000036BUS6001620140530U001.txt
  FUNCTION FUN_FILE_NAME_CREATE(IN_BUS_CODE        IN VARCHAR2, --业务功能编码
                                IN_USE_TYPE        IN VARCHAR2,
                                IN_CURRENT_PACKAGE IN NUMBER -- 分割批次次数
                                ) RETURN VARCHAR2 IS
    V_INTF_DEP_FTP    INTF_DEP_FTP%ROWTYPE;
    V_FILE_NAME       VARCHAR2(200);
    V_CURRENT_PACKAGE VARCHAR(10);
  BEGIN
    IF IN_USE_TYPE IS NULL THEN
      SELECT INTF_DEP_FTP_ID,
             BUS_CODE,
             FTP_TYPE,
             SRC_SYS_ID,
             DST_SYS_ID,
             FILE_FORMAT,
             FIELD_INTERVAL,
             RECORD_INTERVAL,
             USE_TYPE,
             SRC_INTF_DEP_HOST_ID,
             SRC_PATH,
             DST_INTF_DEP_HOST_ID,
             DST_PATH,
             TABLE_NAME,
             TABLE_FIELD,
             RECORD_NUM,
             OWNER,
             FREQUENCY,
             TIME_POINT,
             STATE,
             STATE_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             REMARK
        INTO V_INTF_DEP_FTP.INTF_DEP_FTP_ID,
             V_INTF_DEP_FTP.BUS_CODE,
             V_INTF_DEP_FTP.FTP_TYPE,
             V_INTF_DEP_FTP.SRC_SYS_ID,
             V_INTF_DEP_FTP.DST_SYS_ID,
             V_INTF_DEP_FTP.FILE_FORMAT,
             V_INTF_DEP_FTP.FIELD_INTERVAL,
             V_INTF_DEP_FTP.RECORD_INTERVAL,
             V_INTF_DEP_FTP.USE_TYPE,
             V_INTF_DEP_FTP.SRC_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.SRC_PATH,
             V_INTF_DEP_FTP.DST_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.DST_PATH,
             V_INTF_DEP_FTP.TABLE_NAME,
             V_INTF_DEP_FTP.TABLE_FIELD,
             V_INTF_DEP_FTP.RECORD_NUM,
             V_INTF_DEP_FTP.OWNER,
             V_INTF_DEP_FTP.FREQUENCY,
             V_INTF_DEP_FTP.TIME_POINT,
             V_INTF_DEP_FTP.STATE,
             V_INTF_DEP_FTP.STATE_DATE,
             V_INTF_DEP_FTP.CREATE_DATE,
             V_INTF_DEP_FTP.UPDATE_DATE,
             V_INTF_DEP_FTP.REMARK
        FROM INTF_DEP_FTP IDF
       WHERE IDF.BUS_CODE = IN_BUS_CODE;
    ELSE
      SELECT INTF_DEP_FTP_ID,
             BUS_CODE,
             FTP_TYPE,
             SRC_SYS_ID,
             DST_SYS_ID,
             FILE_FORMAT,
             FIELD_INTERVAL,
             RECORD_INTERVAL,
             USE_TYPE,
             SRC_INTF_DEP_HOST_ID,
             SRC_PATH,
             DST_INTF_DEP_HOST_ID,
             DST_PATH,
             TABLE_NAME,
             TABLE_FIELD,
             RECORD_NUM,
             OWNER,
             FREQUENCY,
             TIME_POINT,
             STATE,
             STATE_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             REMARK
        INTO V_INTF_DEP_FTP.INTF_DEP_FTP_ID,
             V_INTF_DEP_FTP.BUS_CODE,
             V_INTF_DEP_FTP.FTP_TYPE,
             V_INTF_DEP_FTP.SRC_SYS_ID,
             V_INTF_DEP_FTP.DST_SYS_ID,
             V_INTF_DEP_FTP.FILE_FORMAT,
             V_INTF_DEP_FTP.FIELD_INTERVAL,
             V_INTF_DEP_FTP.RECORD_INTERVAL,
             V_INTF_DEP_FTP.USE_TYPE,
             V_INTF_DEP_FTP.SRC_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.SRC_PATH,
             V_INTF_DEP_FTP.DST_INTF_DEP_HOST_ID,
             V_INTF_DEP_FTP.DST_PATH,
             V_INTF_DEP_FTP.TABLE_NAME,
             V_INTF_DEP_FTP.TABLE_FIELD,
             V_INTF_DEP_FTP.RECORD_NUM,
             V_INTF_DEP_FTP.OWNER,
             V_INTF_DEP_FTP.FREQUENCY,
             V_INTF_DEP_FTP.TIME_POINT,
             V_INTF_DEP_FTP.STATE,
             V_INTF_DEP_FTP.STATE_DATE,
             V_INTF_DEP_FTP.CREATE_DATE,
             V_INTF_DEP_FTP.UPDATE_DATE,
             V_INTF_DEP_FTP.REMARK
        FROM INTF_DEP_FTP IDF
       WHERE IDF.BUS_CODE = IN_BUS_CODE
         AND IDF.USE_TYPE = IN_USE_TYPE;
    END IF;
    V_CURRENT_PACKAGE := IN_CURRENT_PACKAGE;
    IF IN_CURRENT_PACKAGE < 100 THEN
      V_CURRENT_PACKAGE := '0' || IN_CURRENT_PACKAGE;
    END IF;
    IF IN_CURRENT_PACKAGE < 10 THEN
      V_CURRENT_PACKAGE := '00' || IN_CURRENT_PACKAGE;
    END IF;
    --文件命名规则:%SRC_SYS_ID%||%DST_SYS_ID%||%BUS_CODE%||YYYYMMDD||%USE_TYPE%||\d{3}
    V_FILE_NAME := V_INTF_DEP_FTP.SRC_SYS_ID || V_INTF_DEP_FTP.DST_SYS_ID ||
                   FUN_BATCH_NBR_CREATE(V_INTF_DEP_FTP.BUS_CODE) ||
                   V_INTF_DEP_FTP.USE_TYPE || V_CURRENT_PACKAGE || '.txt';
    RETURN V_FILE_NAME;
  END;

  --BUS90001文件名生成,格式 CRM2BestPay_CRM_YYYYMMDD_NNNN.txt
  FUNCTION FUN_BUS90001_FILE_NAME_CREATE(IN_CURRENT_PACKAGE IN NUMBER -- 分割批次次数
                                         ) RETURN VARCHAR2 IS
    V_FILE_HEAD       VARCHAR2(30);
    V_SYS_DATE        VARCHAR2(30);
    V_FILE_NAME       VARCHAR2(200);
    V_CURRENT_PACKAGE VARCHAR(10);
  BEGIN
    V_FILE_HEAD := 'CRM2BestPay_CRM';
    --取序列 三位数
    SELECT LPAD(IN_CURRENT_PACKAGE, 4, 0) INTO V_CURRENT_PACKAGE FROM DUAL;
    SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') INTO V_SYS_DATE FROM DUAL;

    --文件命名规则:CRM2BestPay_CRM_YYYYMMDD_NNNN.txt
    V_FILE_NAME := V_FILE_HEAD || '_' || V_SYS_DATE || '_' ||
                   V_CURRENT_PACKAGE || '.txt';

    RETURN V_FILE_NAME;
  END;
  /*
  * 文件抽取 处理中，文件生成 等待中，文件上传 等待中
  * 按照10W条数据创建1个文件。
  *
  */
  PROCEDURE PROC_DEP_COMMON(IN_BUS_CODE          IN VARCHAR2,
                            IN_USE_TYPE          IN VARCHAR2,
                            IN_BATCH_NBR         IN VARCHAR2,
                            IN_CURRENT_PACKAGE   IN NUMBER,
                            IN_TOTAL_PACKAGE_NUM IN NUMBER) IS

    V_FILE_NAME               VARCHAR2(100);
    V_CURRENT_PACKAGE         NUMBER;
    V_BATCH_NBR               VARCHAR2(100);
    V_INTF_DEP_FTP_CONTROL_ID NUMBER;
    V_EXCEPITON               VARCHAR(500);
  BEGIN
    IF IN_BUS_CODE = 'BUS90001' THEN
      V_FILE_NAME := FUN_BUS90001_FILE_NAME_CREATE(IN_CURRENT_PACKAGE);
    ELSE
      V_FILE_NAME := FUN_FILE_NAME_CREATE(IN_BUS_CODE,
                                          IN_USE_TYPE,
                                          IN_CURRENT_PACKAGE);
    END IF;
    V_BATCH_NBR       := IN_BATCH_NBR;
    V_CURRENT_PACKAGE := IN_CURRENT_PACKAGE;
    --文件抽取 待处理状态

    SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
      INTO V_INTF_DEP_FTP_CONTROL_ID
      FROM DUAL;
    IF IN_CURRENT_PACKAGE = 1 THEN
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
      VALUES
        (V_INTF_DEP_FTP_CONTROL_ID,
         IN_BUS_CODE,
         IN_BATCH_NBR,
         V_CURRENT_PACKAGE,
         IN_TOTAL_PACKAGE_NUM,
         V_FILE_NAME,
         '100',
         SYSDATE,
         SYSDATE,
         '70B',
         SYSDATE,
         SYSDATE,
         null,
         '0',
         SYSDATE - 10 / 1440,
         null,
         null,
         IN_USE_TYPE);
      --文件生成 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
      VALUES
        (V_INTF_DEP_FTP_CONTROL_ID,
         IN_BUS_CODE,
         IN_BATCH_NBR,
         IN_CURRENT_PACKAGE,
         IN_TOTAL_PACKAGE_NUM,
         V_FILE_NAME,
         '200',
         SYSDATE,
         SYSDATE,
         '70A',
         SYSDATE,
         SYSDATE,
         null,
         '0',
         SYSDATE - 10 / 1440,
         null,
         null,
         IN_USE_TYPE);
      --文件抽取 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
      VALUES
        (V_INTF_DEP_FTP_CONTROL_ID,
         IN_BUS_CODE,
         V_BATCH_NBR,
         IN_CURRENT_PACKAGE,
         IN_TOTAL_PACKAGE_NUM,
         V_FILE_NAME,
         '300',
         SYSDATE,
         SYSDATE,
         '70A',
         SYSDATE,
         SYSDATE,
         null,
         '0',
         SYSDATE - 10 / 1440,
         null,
         null,
         IN_USE_TYPE);
      commit;
    ELSE
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
        SELECT V_INTF_DEP_FTP_CONTROL_ID,
               BUS_CODE,
               BATCH_NBR,
               IN_CURRENT_PACKAGE,
               IN_TOTAL_PACKAGE_NUM,
               V_FILE_NAME,
               TYPE,
               START_TIME,
               END_TIME,
               STATE,
               STATE_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               DEAL_NUM,
               NEXT_DEAL_TIME,
               ERR_MSG,
               REMARK,
               IN_USE_TYPE
          FROM INTF_DEP_FTP_CONTROL
         WHERE BATCH_NBR = V_BATCH_NBR
           AND BUS_CODE = IN_BUS_CODE
           AND TYPE = '100'
           AND CURRENT_PACKAGE = 1
           AND ROWNUM = 1;
      --文件生成 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
        SELECT V_INTF_DEP_FTP_CONTROL_ID,
               BUS_CODE,
               BATCH_NBR,
               IN_CURRENT_PACKAGE,
               IN_TOTAL_PACKAGE_NUM,
               V_FILE_NAME,
               TYPE,
               START_TIME,
               END_TIME,
               STATE,
               STATE_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               DEAL_NUM,
               NEXT_DEAL_TIME,
               ERR_MSG,
               REMARK,
               IN_USE_TYPE
          FROM INTF_DEP_FTP_CONTROL
         WHERE BATCH_NBR = V_BATCH_NBR
           AND BUS_CODE = IN_BUS_CODE
           AND TYPE = '200'
           AND CURRENT_PACKAGE = 1
           AND ROWNUM = 1;
      --文件抽取 待处理状态
      SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
        INTO V_INTF_DEP_FTP_CONTROL_ID
        FROM DUAL;
      INSERT INTO INTF_DEP_FTP_CONTROL
        (INTF_DEP_FTP_CONTROL_ID,
         BUS_CODE,
         BATCH_NBR,
         CURRENT_PACKAGE,
         TOTAL_PACKAGE_NUM,
         FILE_NAME,
         TYPE,
         START_TIME,
         END_TIME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         DEAL_NUM,
         NEXT_DEAL_TIME,
         ERR_MSG,
         REMARK,
         USE_TYPE)
        SELECT V_INTF_DEP_FTP_CONTROL_ID,
               BUS_CODE,
               BATCH_NBR,
               IN_CURRENT_PACKAGE,
               IN_TOTAL_PACKAGE_NUM,
               V_FILE_NAME,
               TYPE,
               START_TIME,
               END_TIME,
               STATE,
               STATE_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               DEAL_NUM,
               NEXT_DEAL_TIME,
               ERR_MSG,
               REMARK,
               IN_USE_TYPE
          FROM INTF_DEP_FTP_CONTROL
         WHERE BATCH_NBR = V_BATCH_NBR
           AND BUS_CODE = IN_BUS_CODE
           AND TYPE = '300'
           AND CURRENT_PACKAGE = 1
           AND ROWNUM = 1;
      commit;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
      DBMS_OUTPUT.put_line(V_EXCEPITON);
  END;

  /**
  * 数据抽取完后回填
  *
  * 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
  */
  PROCEDURE PROC_DEP_COMPLETE(IN_BUS_CODE  IN VARCHAR2,
                              IN_BATCH_NBR IN VARCHAR2) IS

    V_BUS_CODE   VARCHAR2(100);
    V_BATCH_NBR  VARCHAR2(100);
    V_EXCEPITON  VARCHAR2(500);
    V_UPDATE_SQL VARCHAR2(200);
  BEGIN
    V_BUS_CODE   := IN_BUS_CODE;
    V_BATCH_NBR  := IN_BATCH_NBR;
    V_UPDATE_SQL := 'UPDATE INTF_DEP_FTP_CONTROL SET STATE=''70C'',END_TIME=SYSDATE,STATE_DATE  =SYSDATE WHERE TYPE=''100'' AND  BUS_CODE= ''' ||
                    V_BUS_CODE || '''' || ' AND BATCH_NBR=''' ||
                    V_BATCH_NBR || '''';
    EXECUTE IMMEDIATE V_UPDATE_SQL;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
  END;

  /*
  *清空数据中间表
  */
  PROCEDURE PROC_INIT_TABLE(IN_BUS_CODE IN VARCHAR2) IS
    V_SQL VARCHAR2(1000);
  BEGIN
    V_SQL := 'TRUNCATE TABLE INTF_' || IN_BUS_CODE || '_AUDIT';
    EXECUTE IMMEDIATE V_SQL;
    DELETE CRMV2.INTF_DEP_FTP_CONTROL
     WHERE BUS_CODE = IN_BUS_CODE
       AND TRUNC(START_TIME) = TRUNC(SYSDATE);
    COMMIT;
  END;
  /*
  分批次*/
  PROCEDURE PROC_CURRENT_PACKAGE_AVG(IN_TABLE_NAME       IN VARCHAR2,
                                     IN_BATCH_NBR        IN VARCHAR2,
                                     IN_MAX_NUMBER       IN INTEGER,
                                     O_TOTAL_PACKAGE_NUM OUT INTEGER) IS
    V_SQL VARCHAR2(500);
    --V_TABLE_NAME VARCHAR2(50);
    V_CURRENT_PACKAGE   INTEGER;
    V_COUNT             INTEGER;
    V_TOTAL_PACKAGE_NUM INTEGER;
    --V_MAX_NUMBER        INTEGER;
    v_str varchar2(1000);
  BEGIN
    -- V_TABLE_NAME:=IN_TABLE_NAME;
    loop
      EXECUTE IMMEDIATE 'select nvl(max(CURRENT_PACKAGE), -1) + 1 from ' ||
                        IN_TABLE_NAME || ' where BATCH_NBR =''' ||
                        IN_BATCH_NBR || ''''
        into V_CURRENT_PACKAGE;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;
      EXECUTE IMMEDIATE 'select count(*)
        from ' || IN_TABLE_NAME ||
                        ' where CURRENT_PACKAGE = 0'
        into V_COUNT;

      if V_COUNT > IN_MAX_NUMBER then
        EXECUTE IMMEDIATE 'update ' || IN_TABLE_NAME ||
                          ' set CURRENT_PACKAGE = ' || V_CURRENT_PACKAGE ||
                          ' where CURRENT_PACKAGE = 0
           and rownum < (' || IN_MAX_NUMBER ||
                          ' + 1)';
      else
        EXECUTE IMMEDIATE 'update ' || IN_TABLE_NAME ||
                          ' set CURRENT_PACKAGE = ' || V_CURRENT_PACKAGE ||
                          ' where CURRENT_PACKAGE = 0';
      end if;
      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= IN_MAX_NUMBER;
    end loop;
    O_TOTAL_PACKAGE_NUM := V_TOTAL_PACKAGE_NUM;
  exception
    when others then
      v_str := sqlerrm;
  END;

  /*
  * 订单信息稽核 20140624 add by wangweibin
  */
  PROCEDURE PROC_BUS60016 IS
    -- TYPE INTF_ORDER_INFO_AUDIT IS REF CURSOR; --定义游标变量类型
    -- V_CURSORVAR INTF_ORDER_INFO_AUDIT; --声明游标变量
    -- V_INTF_ORDER_INFO_AUDIT INTF_ORDER_INFO_AUDIT;
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS60016'; --业务功能编码
    -- V_INTF_ORDER_INFO_AUDIT_ID NUMBER;

  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    BEGIN
      --取数插中间表逻辑
      for rec in (select P.EXT_CUST_ORDER_ID CUST_ORDER_ID,
                         V_PROVINCE_ID PROVINCE_ID,
                         pkg_clob_to_str.clob_to_str_single1(iddih.data_info,
                                                             'LAN_ID',
                                                             1) LAN_ID,
                         pkg_clob_to_str.clob_to_str_single1(iddih.data_info,
                                                             'ACC_NBR',
                                                             1) ACC_NBR,
                         decode(DBMS_LOB.INSTR(iddih.data_info, 'C-IMSI'),
                                0,
                                '',
                                TO_CHAR(SUBSTR(iddih.data_info,
                                               DBMS_LOB.INSTR(iddih.data_info,
                                                              'C-IMSI') - 17,
                                               15))) C_IMSI,
                         decode(DBMS_LOB.INSTR(iddih.data_info, 'G-IMSI'),
                                0,
                                '',
                                TO_CHAR(SUBSTR(iddih.data_info,
                                               DBMS_LOB.INSTR(iddih.data_info,
                                                              'G-IMSI') - 17,
                                               15))) G_IMSI,
                         decode(DBMS_LOB.INSTR(iddih.data_info, 'L-IMSI'),
                                0,
                                '',
                                TO_CHAR(SUBSTR(iddih.data_info,
                                               DBMS_LOB.INSTR(iddih.data_info,
                                                              'L-IMSI') - 17,
                                               15))) L_IMSI,
                         pkg_clob_to_str.clob_to_str_single1(iddih.data_info,
                                                             'MKT_RES_INST_CODE',
                                                             1) MKT_NBR
                    from crmv2.intf_dep_order_his             p,
                         crmv2.intf_dep_order_package_rel_his idop,
                         crmv2.intf_dep_data_info_his         iddih
                   where p.intf_dep_order_id = idop.intf_dep_order_id
                     and idop.intf_dep_order_package_rel_id =
                         iddih.intf_dep_order_package_rel_id
                     and trunc(p.create_date) = trunc(sysdate - 1)
                     and p.service_code in
                         ('SVC80003', 'SVC80011', 'SVC80005', 'SVC80019')
                  union
                  select P.EXT_CUST_ORDER_ID CUST_ORDER_ID,
                         V_PROVINCE_ID PROVINCE_ID,
                         pkg_clob_to_str.clob_to_str_single1(iddih.data_info,
                                                             'LAN_ID',
                                                             1) LAN_ID,
                         pkg_clob_to_str.clob_to_str_single1(iddih.data_info,
                                                             'ACC_NBR',
                                                             1) ACC_NBR,
                         decode(DBMS_LOB.INSTR(iddih.data_info, 'C-IMSI'),
                                0,
                                '',
                                TO_CHAR(SUBSTR(iddih.data_info,
                                               DBMS_LOB.INSTR(iddih.data_info,
                                                              'C-IMSI') - 17,
                                               15))) C_IMSI,
                         decode(DBMS_LOB.INSTR(iddih.data_info, 'G-IMSI'),
                                0,
                                '',
                                TO_CHAR(SUBSTR(iddih.data_info,
                                               DBMS_LOB.INSTR(iddih.data_info,
                                                              'G-IMSI') - 17,
                                               15))) G_IMSI,
                         decode(DBMS_LOB.INSTR(iddih.data_info, 'L-IMSI'),
                                0,
                                '',
                                TO_CHAR(SUBSTR(iddih.data_info,
                                               DBMS_LOB.INSTR(iddih.data_info,
                                                              'L-IMSI') - 17,
                                               15))) L_IMSI,
                         pkg_clob_to_str.clob_to_str_single1(iddih.data_info,
                                                             'MKT_RES_INST_CODE',
                                                             1) MKT_NBR
                    from crmv2.intf_dep_order             p,
                         crmv2.intf_dep_order_package_rel idop,
                         crmv2.intf_dep_data_info         iddih
                   where p.intf_dep_order_id = idop.intf_dep_order_id
                     and idop.intf_dep_order_package_rel_id =
                         iddih.intf_dep_order_package_rel_id
                     and trunc(P.create_date) = trunc(sysdate - 1)
                     and p.service_code in
                         ('SVC80003', 'SVC80011', 'SVC80005', 'SVC80019')) LOOP

        INSERT INTO INTF_BUS60016_AUDIT
          (INTF_BUS60016_AUDIT_ID,
           CUST_ORDER_ID,
           PROVINCE_ID,
           LAN_ID,
           ACC_NBR,
           C_IMSI,
           G_IMSI,
           L_IMSI,
           MKT_NBR,
           BUS_CODE,
           CURRENT_PACKAGE,
           BATCH_NBR)
        VALUES
          (SEQ_INTF_BUS60016_AUDIT_ID.NEXTVAL,
           rec.CUST_ORDER_ID,
           rec.PROVINCE_ID,
           rec.LAN_ID,
           rec.ACC_NBR,
           rec.C_IMSI,
           rec.G_IMSI,
           rec.L_IMSI,
           rec.MKT_NBR,
           V_BUS_CODE,
           0,
           V_BATCH_NBR);
      END LOOP;
      commit;
      ---终端预约
      INSERT INTO INTF_BUS60016_AUDIT
        (INTF_BUS60016_AUDIT_ID,
         CUST_ORDER_ID,
         PROVINCE_ID,
         LAN_ID,
         BUS_CODE,
         CURRENT_PACKAGE,
         BATCH_NBR)
        select SEQ_INTF_BUS60016_AUDIT_ID.NEXTVAL,
               EXT_CUST_ORDER_ID,
               '8350000',
               CRMV2.pkg_clob_to_str.clob_to_str_single1(DEP_MSG,
                                                         'LAN_ID',
                                                         1),
               V_BUS_CODE,
               0,
               V_BATCH_NBR
          FROM crmv2.intf_dep_order_batch
         where trunc(create_date) = trunc(sysdate - 1);
      commit;
    END;

    ---排重
    delete from crmv2.INTF_BUS60016_AUDIT a
     where rowid <> (select max(rowid)
                       from crmv2.INTF_BUS60016_AUDIT b
                      where a.cust_order_id = b.cust_order_id
                        and nvl(a.acc_nbr, 1) = nvl(b.acc_nbr, 1));
    commit;

    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from INTF_BUS60016_AUDIT b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.INTF_BUS60016_AUDIT a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.INTF_BUS60016_AUDIT a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.INTF_BUS60016_AUDIT
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;
    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    commit;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
  END;

  /*
  * 订单费用稽核 20140624 add by wangweibin
  */
  PROCEDURE PROC_BUS60017 IS
    -- TYPE INTF_ORDER_INFO_AUDIT IS REF CURSOR; --定义游标变量类型
    -- V_CURSORVAR INTF_ORDER_INFO_AUDIT; --声明游标变量
    -- V_INTF_ORDER_INFO_AUDIT INTF_ORDER_INFO_AUDIT;
    V_EXCEPITON                VARCHAR(500);
    V_MAX_NUMBER               INTEGER := 100000;
    V_INT_NUM                  INTEGER;
    V_CURRENT_PACKAGE          NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM        NUMBER := 0; --分割批次数总数
    V_COUNT                    NUMBER := 0; --取数总量
    V_BATCH_NBR                VARCHAR2(100); --批次号
    V_BUS_CODE                 VARCHAR2(50) := 'BUS60017'; --业务功能编码
    V_INTF_ORDER_INFO_AUDIT_ID NUMBER;
    V_ACCT_ITEM_TYPE_ID        CRMV2.INTF_BUS60017_AUDIT.ACCT_ITEM_TYPE_ID%TYPE;
    V_AMOUNT                   CRMV2.INTF_BUS60017_AUDIT.AMOUNT%TYPE;
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    BEGIN

      /*20141231 modify by linyx*/
      EXECUTE IMMEDIATE 'TRUNCATE TABLE intf_dep_order_his_bus60017';
      EXECUTE IMMEDIATE 'TRUNCATE TABLE intf_dep_order_his_bus60017_1';
      EXECUTE IMMEDIATE 'TRUNCATE TABLE intf_dep_order_his_bus60017_2';
      insert into intf_dep_order_his_bus60017_1
        select p.intf_dep_order_id,
               p.EXT_CUST_ORDER_ID,
               p.package_group,
               p.create_date
          from crmv2.intf_dep_order p
         where trunc(p.create_date) = trunc(sysdate - 1)
           and p.service_code in
               ('SVC80003', 'SVC80011', 'SVC80005', 'SVC80019');
      commit;

      insert into intf_dep_order_his_bus60017_2
        select p.*, idop.intf_dep_order_package_rel_id
          from intf_dep_order_his_bus60017_1    p,
               crmv2.intf_dep_order_package_rel idop
         where p.intf_dep_order_id = idop.intf_dep_order_id;
      commit;
      insert into crmv2.intf_dep_order_his_bus60017
        select p.*, iddih.data_info
          from crmv2.intf_dep_order_his_bus60017_2 p,
               crmv2.intf_dep_data_info            iddih
         where p.intf_dep_order_package_rel_id =
               iddih.intf_dep_order_package_rel_id;
      commit;

      EXECUTE IMMEDIATE 'TRUNCATE TABLE intf_dep_order_his_bus60017_1';
      EXECUTE IMMEDIATE 'TRUNCATE TABLE intf_dep_order_his_bus60017_2';

      insert into intf_dep_order_his_bus60017_1
        select p.intf_dep_order_id,
               p.EXT_CUST_ORDER_ID,
               p.package_group,
               p.create_date
          from crmv2.intf_dep_order_his p
         where trunc(p.create_date) = trunc(sysdate - 1)
           and p.service_code in
               ('SVC80003', 'SVC80011', 'SVC80005', 'SVC80019');
      commit;
      insert into intf_dep_order_his_bus60017_2
        select p.*, idop.intf_dep_order_package_rel_id
          from intf_dep_order_his_bus60017_1        p,
               crmv2.intf_dep_order_package_rel_his idop
         where p.intf_dep_order_id = idop.intf_dep_order_id;
      commit;

      insert into crmv2.intf_dep_order_his_bus60017
        select p.*, iddih.data_info
          from crmv2.intf_dep_order_his_bus60017_2 p,
               crmv2.intf_dep_data_info_his        iddih
         where p.intf_dep_order_package_rel_id =
               iddih.intf_dep_order_package_rel_id;
      commit;

      -----排重
      delete from crmv2.intf_dep_order_his_bus60017 a
       where intf_dep_order_id <>
             (select max(intf_dep_order_id)
                from crmv2. intf_dep_order_his_bus60017 b
               where a.ext_cust_order_id = b.ext_cust_order_id);
      commit;

      delete from crmv2.intf_dep_order_his_bus60017 a
       where rowid <>
             (select max(rowid)
                from crmv2. intf_dep_order_his_bus60017 b
               where a.ext_cust_order_id = b.ext_cust_order_id);
      commit;

      --取数插中间表逻辑
      for rec in (select EXT_CUST_ORDER_ID CUST_ORDER_ID,
                         V_PROVINCE_ID PROVINCE_ID,
                         pkg_clob_to_str.clob_to_str_single1(data_info,
                                                             'LAN_ID',
                                                             1) LAN_ID,
                         package_group
                    from intf_dep_order_his_bus60017) LOOP
        V_INT_NUM := 1;
        LOOP

          SELECT pkg_clob_to_str.clob_to_str_single1(DATA_INFO,
                                                     'ACCT_ITEM_TYPE_ID',
                                                     V_INT_NUM),
                 pkg_clob_to_str.clob_to_str_single1(DATA_INFO,
                                                     'AMOUNT',
                                                     V_INT_NUM)
            INTO V_ACCT_ITEM_TYPE_ID, V_AMOUNT
            FROM intf_dep_order_his_bus60017
           where package_group = rec.package_group;
          EXIT WHEN V_ACCT_ITEM_TYPE_ID IS NULL OR V_AMOUNT IS NULL;

          INSERT INTO INTF_BUS60017_AUDIT
            (INTF_BUS60017_AUDIT_ID,
             CUST_ORDER_ID,
             ACCT_ITEM_TYPE_ID,
             AMOUNT,
             PROVINCE_ID,
             LAN_ID,
             BUS_CODE,
             CURRENT_PACKAGE,
             BATCH_NBR)
          VALUES
            (SEQ_INTF_BUS60017_AUDIT_ID.NEXTVAL,
             rec.CUST_ORDER_ID,
             V_ACCT_ITEM_TYPE_ID,
             V_AMOUNT,
             rec.PROVINCE_ID,
             rec.LAN_ID,
             V_BUS_CODE,
             0,
             V_BATCH_NBR);
          V_INT_NUM := V_INT_NUM + 1;
        END LOOP;
        commit;
      END LOOP;

      /*     for rec in (select distinct P.EXT_CUST_ORDER_ID CUST_ORDER_ID,
                                  V_PROVINCE_ID PROVINCE_ID,
                                  pkg_clob_to_str.clob_to_str_single1(iddih.data_info,
                                                                      'LAN_ID',
                                                                      1) LAN_ID,
                                  p.package_group

                    from crmv2.intf_dep_order             p,
                         crmv2.intf_dep_order_package_rel idop,
                         crmv2.intf_dep_data_info         iddih
                   where p.intf_dep_order_id = idop.intf_dep_order_id
                     and idop.intf_dep_order_package_rel_id =
                         iddih.intf_dep_order_package_rel_id
                     and trunc(p.create_date) = trunc(sysdate - 1)
                     and p.service_code in
                         ('SVC80003', 'SVC80011', 'SVC80005', 'SVC80019')) LOOP
        V_INT_NUM := 1;
        LOOP

          SELECT pkg_clob_to_str.clob_to_str_single1(C.DATA_INFO,
                                                     'ACCT_ITEM_TYPE_ID',
                                                     V_INT_NUM),
                 pkg_clob_to_str.clob_to_str_single1(C.DATA_INFO,
                                                     'AMOUNT',
                                                     V_INT_NUM)
            INTO V_ACCT_ITEM_TYPE_ID, V_AMOUNT
            FROM crmv2.intf_dep_order             a,
                 crmv2.intf_dep_order_package_rel b,
                 crmv2.intf_dep_data_info         c
           where a.intf_dep_order_id = b.intf_dep_order_id
             and b.intf_dep_order_package_rel_id =
                 c.intf_dep_order_package_rel_id
             and a.package_group = rec.package_group;

          EXIT WHEN V_ACCT_ITEM_TYPE_ID IS NULL OR V_AMOUNT IS NULL;

          INSERT INTO INTF_BUS60017_AUDIT
            (INTF_BUS60017_AUDIT_ID,
             CUST_ORDER_ID,
             ACCT_ITEM_TYPE_ID,
             AMOUNT,
             PROVINCE_ID,
             LAN_ID,
             BUS_CODE,
             CURRENT_PACKAGE,
             BATCH_NBR)
          VALUES
            (SEQ_INTF_BUS60017_AUDIT_ID.NEXTVAL,
             rec.CUST_ORDER_ID,
             V_ACCT_ITEM_TYPE_ID,
             V_AMOUNT,
             rec.PROVINCE_ID,
             rec.LAN_ID,
             V_BUS_CODE,
             0,
             V_BATCH_NBR);
          V_INT_NUM := V_INT_NUM + 1;
        END LOOP;
        commit;
      END LOOP;*/
    END;

    FOR REC IN (SELECT CUST_ORDER_ID, ACCT_ITEM_TYPE_ID
                  FROM INTF_BUS60017_AUDIT
                 group by CUST_ORDER_ID, ACCT_ITEM_TYPE_ID
                HAVING COUNT(*) > 1) LOOP
      SELECT MIN(INTF_BUS60017_AUDIT_ID)
        INTO V_INTF_ORDER_INFO_AUDIT_ID
        FROM INTF_BUS60017_AUDIT
       where CUST_ORDER_ID = REC.CUST_ORDER_ID
         AND ACCT_ITEM_TYPE_ID = REC.ACCT_ITEM_TYPE_ID;
      UPDATE INTF_BUS60017_AUDIT
         SET AMOUNT =
             (SELECT SUM(AMOUNT)
                FROM INTF_BUS60017_AUDIT
               WHERE CUST_ORDER_ID = REC.CUST_ORDER_ID
                 AND ACCT_ITEM_TYPE_ID = REC.ACCT_ITEM_TYPE_ID)
       where INTF_BUS60017_AUDIT_ID = V_INTF_ORDER_INFO_AUDIT_ID;
      DELETE INTF_BUS60017_AUDIT
       where CUST_ORDER_ID = REC.CUST_ORDER_ID
         AND ACCT_ITEM_TYPE_ID = REC.ACCT_ITEM_TYPE_ID
         AND INTF_BUS60017_AUDIT_ID <> V_INTF_ORDER_INFO_AUDIT_ID;
      COMMIT;
    END LOOP;

    delete from crmv2.INTF_BUS60017_AUDIT a
     where rowid <> (select max(rowid)
                       from crmv2.INTF_BUS60017_AUDIT b
                      where a.cust_order_id = b.cust_order_id
                        and a.acct_item_type_id = b.acct_item_type_id
                        and a.amount = b.amount);
    commit;

    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from INTF_BUS60017_AUDIT b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.INTF_BUS60017_AUDIT a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.INTF_BUS60017_AUDIT a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.INTF_BUS60017_AUDIT
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;
    V_INT_NUM := 2;

    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
      INSERT INTO FFLINYX.INTF_DEP_FTP_LOG
      VALUES
        (V_BUS_CODE, V_EXCEPITON, SYSDATE);
      COMMIT;
  END;

  /*
  * 号码激活稽核 20140707 add by fflingy
  */
  PROCEDURE PROC_BUS60018 IS
    -- TYPE INTF_ORDER_INFO_AUDIT IS REF CURSOR; --定义游标变量类型
    -- V_CURSORVAR INTF_ORDER_INFO_AUDIT; --声明游标变量
    -- V_INTF_ORDER_INFO_AUDIT INTF_ORDER_INFO_AUDIT;
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS60018'; --业务功能编码
    --V_INTF_ORDER_INFO_AUDIT_ID NUMBER;
    V_SQL VARCHAR2(2000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      EXECUTE IMMEDIATE 'truncate TABLE intf_group_log_BUS60018';
    exception
      when others then
        EXECUTE IMMEDIATE 'create table intf_group_log_BUS60018 as where select * from crmv2.intf_group_log where 1=2';
    END;

    BEGIN
      EXECUTE IMMEDIATE 'truncate TABLE intf_group_log_BUS60018_1';
    exception
      when others then
        EXECUTE IMMEDIATE 'create table INTF_GROUP_LOG_BUS60018_1
          (
            CUST_SO_NUMBER   VARCHAR2(50),
            ACCEPT_TIME      DATE,
            ACC_NBR          VARCHAR2(32),
            COMMON_REGION_ID NUMBER(12),
            AREA_CODE        VARCHAR2(12)
          )';
    END;

    /*    BEGIN
      EXECUTE IMMEDIATE 'truncate TABLE INTF_BUS60018_AUDIT_LOG';
    exception
      when others then
        EXECUTE IMMEDIATE 'create table INTF_BUS60018_AUDIT_LOG as
            select log_id,
             cust_so_number,
             request_message,
             request_date,
             respond_date,
             acc_nbr,
             transaction_id from CRMV2.INTF_LOG where 1=2';
    END;*/

    insert into intf_group_log_BUS60018
      select *
        from crmv2.intf_group_log
       where trunc(update_date) = trunc(sysdate - 1, 'dd')
         and channel_nbr = '600105C002'
         and remark = '首拨开通成功';
    commit;
    DELETE FROM intf_group_log_BUS60018 A
     where update_date <>
           (select MAX(update_date)
              from intf_group_log_BUS60018 B
             where A.cust_so_number = B.cust_so_number);
    COMMIT;

    /*   insert into INTF_BUS60018_AUDIT_LOG
      select log_id,
             cust_so_number,
             request_message,
             request_date,
             respond_date,
             acc_nbr,
             transaction_id
        from basejk.INTF_LOG_view
       WHERE MSG_TYPE = 'BUS80001,SVC80008'
         AND RESULT_FLAG = '0'
         and trunc(request_date) = trunc(sysdate - 1)
         and transaction_id in
             (select transaction_id from intf_group_log_BUS60018);
    commit;

    DELETE FROM INTF_BUS60018_AUDIT_LOG A
     where RESPOND_DATE <> (select MAX(RESPOND_DATE)
                              from INTF_BUS60018_AUDIT_LOG B
                             where A.ACC_NBR = B.ACC_NBR);
    COMMIT;
    DELETE FROM INTF_BUS60018_AUDIT_LOG A
     where rowid <> (select MAX(rowid)
                       from INTF_BUS60018_AUDIT_LOG B
                      where A.ACC_NBR = B.ACC_NBR);
    COMMIT;*/

    insert into intf_group_log_BUS60018_1
      select a.cust_so_number,
             b.accept_time,
             d.acc_nbr,
             d.common_region_id,
             d.area_code
        from CRMV2.intf_group_log_BUS60018 a,
             CRMV2.CUSTOMER_ORDER_HIS      b,
             crmv2.order_item_his          c,
             prod_inst                     d
       where a.cust_so_number = b.cust_so_number
         and b.cust_order_id = c.cust_order_id
         and c.class_id = '4'
         and c.order_item_obj_id = d.prod_inst_id
         and d.product_id = '800000002';
    commit;
    DELETE FROM intf_group_log_BUS60018 A
     where rowid <> (select MAX(rowid)
                       from intf_group_log_BUS60018 B
                      where A.cust_so_number = B.cust_so_number);
    COMMIT;

    INSERT INTO crmv2.INTF_BUS60018_AUDIT
      (INTF_BUS60018_AUDIT_ID,
       PHONE_NUMBER,
       PROVINCE_ID,
       LAN_ID,
       AREA_CODE,
       ACTIVE_TIME,
       BUS_CODE,
       CURRENT_PACKAGE,
       BATCH_NBR)
      select SEQ_INTF_BUS60018_AUDIT_ID.NEXTVAL,
             A.acc_nbr phone_nbr,
             '8350000',
             b.region_code,
             a.area_code,
             to_char(A.accept_time, 'yyyymmddhh24miss'),
             V_BUS_CODE,
             0,
             V_BATCH_NBR
        FROM intf_group_log_BUS60018_1 A, CRMV2.COMMON_REGION_jt B
       where a.common_region_id = B.common_region_id;
    COMMIT;

    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from INTF_BUS60018_AUDIT b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.INTF_BUS60018_AUDIT a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.INTF_BUS60018_AUDIT a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.INTF_BUS60018_AUDIT
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;
    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    commit;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
      DBMS_OUTPUT.put_line(V_EXCEPITON);
  END;
  /*
  * 卡资源稽核 20140707 add by fflingy
  */
  PROCEDURE PROC_BUS60020 IS
    -- TYPE INTF_ORDER_INFO_AUDIT IS REF CURSOR; --定义游标变量类型
    -- V_CURSORVAR INTF_ORDER_INFO_AUDIT; --声明游标变量
    -- V_INTF_ORDER_INFO_AUDIT INTF_ORDER_INFO_AUDIT;
    V_EXCEPITON             VARCHAR(500);
    V_MAX_NUMBER            INTEGER := 500000;
    V_INT_NUM               INTEGER;
    V_CURRENT_PACKAGE       NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM     NUMBER := 0; --分割批次数总数
    V_COUNT                 NUMBER := 0; --取数总量
    V_BATCH_NBR             VARCHAR2(100); --批次号
    V_BUS_CODE              VARCHAR2(50) := 'BUS60020'; --业务功能编码
    V_INTF_BUSCODE_AUDIT_ID NUMBER;
    DD                      VARCHAR2(2);
  BEGIN

    --获取批次号
    SELECT TO_CHAR(SYSDATE, 'DD') INTO DD FROM DUAL;
    IF DD NOT IN ('05', '15', '25') THEN
      RETURN;
    END IF;
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    BEGIN
      --取数插中间表逻辑
      for rec in (select mkt_reso_id
                    from crmv1.mkt_reso_fea
                   where fea_spec_id = 620124501
                     and param1 = '1') loop

        SELECT SEQ_INTF_BUS60020_AUDIT_ID.NEXTVAL
          INTO V_INTF_BUSCODE_AUDIT_ID
          FROM DUAL;
        INSERT /*+APPAND*/
        INTO INTF_BUS60020_AUDIT
          (INTF_BUS60020_AUDIT_ID,
           ICCID,
           C_IMSI,
           STATUS,
           PROVINCE_ID,
           LAN_ID,
           BUS_CODE,
           CURRENT_PACKAGE,
           BATCH_NBR)
          SELECT /*+ PARALLEL(4) */
           V_INTF_BUSCODE_AUDIT_ID,
           a.MKT_RESO_KEY,
           b.PARAM1,
           '1003',
           V_PROVINCE_ID,
           c.param1,
           V_BUS_CODE,
           0,
           V_BATCH_NBR
            from CRMV1.MKT_RESOURCE a,
                 CRMV1.MKT_RESO_FEA b,
                 CRMV1.MKT_RESO_FEA c
           where b.mkt_reso_id = rec.MKT_RESO_ID
             and c.mkt_reso_id = rec.MKT_RESO_ID
             and b.fea_spec_id = '620029411'
             and c.fea_spec_id = '802653175'
             and a.mkt_reso_id = rec.MKT_RESO_ID;

        UPDATE INTF_BUS60020_AUDIT
           SET STATUS = '1004'
         WHERE INTF_BUS60020_AUDIT_ID = V_INTF_BUSCODE_AUDIT_ID
           AND EXISTS (SELECT *
                  FROM CRMV1.MKT_OCCUPY
                 WHERE MKT_RESO_ID = REC.MKT_RESO_ID
                   AND STATE = '103');

        UPDATE INTF_BUS60020_AUDIT
           SET G_IMSI =
               (SELECT PARAM1
                  FROM CRMV1.MKT_RESO_FEA
                 WHERE MKT_RESO_ID = REC.MKT_RESO_ID
                   AND FEA_SPEC_ID = 620124476
                   and rownum = 1)
         WHERE INTF_BUS60020_AUDIT_ID = V_INTF_BUSCODE_AUDIT_ID;

        UPDATE INTF_BUS60020_AUDIT
           SET l_IMSI =
               (SELECT PARAM1
                  FROM CRMV1.MKT_RESO_FEA
                 WHERE MKT_RESO_ID = REC.MKT_RESO_ID
                   AND FEA_SPEC_ID = 620124477
                   and rownum = 1)
         WHERE INTF_BUS60020_AUDIT_ID = V_INTF_BUSCODE_AUDIT_ID;
        V_INT_NUM := V_INT_NUM + 1;
        if V_INT_NUM = 1000 then
          V_INT_NUM := 0;
          commit;
        end if;
      END LOOP;
    END;
    ----集团问题不愿意改的做特殊处理
    update crmv2.INTF_BUS60020_AUDIT a
       set status =
           (select b.state
              from fflinyx.linyx_usim_jt b
             where a.iccid = b.iccid)
     where ICCID in (select ICCID from fflinyx.linyx_usim_jt);
    commit;
    ---将区域不一致的特殊处理
    /*    UPDATE CRMV2.INTF_BUS60020_AUDIT A
       SET LAN_ID = (select LAN_ID
                       from FFLINYX.INTF_BUS60020_AUDIT_LAN_JT B
                      where A.ICCID = B.ICCID)
     where ICCID IN (SELECT ICCID FROM FFLINYX.INTF_BUS60020_AUDIT_LAN_JT);
    commit;*/

    ----取纵横还未正式导入但集团已下发的数据
    insert into CRMV2.INTF_BUS60020_AUDIT
      (INTF_BUS60020_AUDIT_ID,
       ICCID,
       C_IMSI,
       STATUS,
       PROVINCE_ID,
       LAN_ID,
       G_IMSI,
       l_IMSI,
       BUS_CODE,
       CURRENT_PACKAGE,
       BATCH_NBR)
      select crmv2.SEQ_INTF_BUS60020_AUDIT_ID.NEXTVAL,
             substr(iccid, 1, 19),
             psnm,
             '1003',
             '8350000',
             region_code,
             imsi_g,
             imsi_lte,
             V_BUS_CODE,
             0,
             V_BATCH_NBR
        from basejk.intf_uim_info_bd@lk_crm2jk_weihu a,
             crmv2.common_region_jt                  b
       where a.area_code = b.area_code
         and b.common_region_id between 2 and 10
         and not exists (select 1
                from crmv2.INTF_BUS60020_AUDIT c
               where c.c_imsi = a.psnm);
    commit;

    /*    ------集团不一致的数据特殊处理
    update CRMV2.INTF_BUS60020_AUDIT a
       set status = (select status
                       from fflinyx.bus60020_err b
                      where a.iccid = b.iccid)
     where iccid in (select iccid from fflinyx.bus60020_err);
    commit;*/
    ---集团独有省内不存在
    insert into CRMV2.INTF_BUS60020_AUDIT
      (INTF_BUS60020_AUDIT_ID,
       ICCID,
       C_IMSI,
       STATUS,
       PROVINCE_ID,
       LAN_ID,
       G_IMSI,
       l_IMSI,
       BUS_CODE,
       CURRENT_PACKAGE,
       BATCH_NBR)
      select crmv2.SEQ_INTF_BUS60020_AUDIT_ID.NEXTVAL,
             substr(col1, 1, 19),
             col2,
             col3,
             col4,
             col5,
             col6,
             col7,
             V_BUS_CODE,
             0,
             V_BATCH_NBR
        from fflinyx.bus60020_err a
       where not exists (select 1
                from crmv2.INTF_BUS60020_AUDIT c
               where c.c_imsi = a.col1);
    commit;

    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from INTF_BUS60020_AUDIT b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.INTF_BUS60020_AUDIT a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.INTF_BUS60020_AUDIT a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.INTF_BUS60020_AUDIT
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;
    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
  END;

  /*
  WAP比对稽核 add by linyx
  */
  PROCEDURE PROC_BUS24001 IS
    V_SQL VARCHAR2(4000);
    DD    VARCHAR2(10);
    -- V_BUS_CODE          VARCHAR2(50) := 'BUS24002';
    V_MAX_NUMBER        INTEGER := 1000000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_EXCEPITON         VARCHAR(500);
    v_use_type1         VARCHAR2(50);
    v_use_type2         VARCHAR2(50);
  begin

    V_BATCH_NBR := FUN_BATCH_NBR_CREATE('BUS24001');
    --V_BATCH_NBR := 'BUS2400120141118';
    select to_char(sysdate, 'dd') into dd from dual;

    --控制提数的日期
    execute IMMEDIATE 'select use_type  from crmv2.Intf_Dep_Ftp where bus_code=''BUS24001'' and frequency in (' || dd || ')'
      into v_use_type1;
    execute IMMEDIATE 'select use_type  from crmv2.Intf_Dep_Ftp where bus_code=''BUS24002'''
      into v_use_type2;

    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON('BUS24001', --业务功能编码
                    v_use_type1,
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    PROC_DEP_COMMON('BUS24002', --业务功能编码
                    v_use_type2,
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    EXECUTE IMMEDIATE 'truncate TABLE INTF_BUS24001_AUDIT';
    commit;
    EXECUTE IMMEDIATE 'truncate TABLE INTF_BUS24001_AUDIT_gg';
    commit;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_USIM';
    exception
      when others then
        null;
    END;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_IMSI';
    exception
      when others then
        null;
    END;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_IMSI_GG';
    exception
      when others then
        null;
    END;
    --改
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_LTE_IMSI';
    exception
      when others then
        null;
    END;

    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_LTE_IMSI_GG';
    exception
      when others then
        null;
    END;
    ------
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_STOP';
    exception
      when others then
        null;
    END;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_STOP_GG';
    exception
      when others then
        null;
    END;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_ALL';
    exception
      when others then
        null;
    END;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_ALL_GG';
    exception
      when others then
        null;
    END;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_USIM0';
    exception
      when others then
        null;
    END;
    BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE PROD_CDMA_USIM1';
    exception
      when others then
        null;
    END;

    insert into fflinyx.linyx_log values ('PROD_CDMA_USIM0', sysdate, 1);
    commit; -----日志
    V_SQL := ' CREATE TABLE PROD_CDMA_USIM0 AS
      select /*+ PARALLEL(20) */A.PROD_INST_ID,
             ''86''||A.ACC_NBR MDN,
             decode(NVL(A.PAYMENT_MODE_CD,''1200''),''1200'',''12'',''1201'',''22'',''2100'',''21'',''12'') PAY_TYPE,
             a.status_cd,
             a.create_date LOCAL_CREATE_DATE,
             a.update_date MODIFY_DATE,
             a.product_id,
             0  seq
        from prod_inst A
       where product_id in (800000002,800000007,800000054,900283009)
         AND A.STATUS_CD not in (''110000'',''130000'') ';

    EXECUTE IMMEDIATE V_SQL;

    EXECUTE IMMEDIATE 'create index idx_PROD_CDMA_USIM0 on PROD_CDMA_USIM0(prod_inst_id)';

    insert into fflinyx.linyx_log values ('PROD_CDMA_STOP', sysdate, 2);
    commit; -----日志
    V_SQL := 'CREATE TABLE PROD_CDMA_STOP AS
    SELECT/*+ PARALLEL(20) */ DISTINCT A.PROD_INST_ID,A.MDN,a.product_id,ATTR_CD ,a.status_cd FROM PROD_CDMA_USIM0 A,PROD_INST_ATTR B,ATTR_SPEC C
    WHERE A.PROD_INST_ID=B.PROD_INST_ID AND B.ATTR_ID=C.ATTR_ID AND B.STATUS_CD<>''1100''
    AND C.attr_cd in (''SO_SERViSTOP_PECC'',''SO_SERViSTOP_USER'',''SO_SERViSTOP_RTLS'',''SO_SERViSTOP_OWE'',''SO_SERViSTOP_CALL_OWE'',''SO_SERViSTOP_REMOVE'')';
    EXECUTE IMMEDIATE V_SQL;

    insert into fflinyx.linyx_log values ('PROD_CDMA_USIM1', sysdate, 3);
    commit; -----日志
    V_SQL := 'CREATE TABLE PROD_CDMA_USIM1 AS
      select /*+ PARALLEL(20) */A.*, b.attr_value
        from crmv2.PROD_CDMA_USIM0 A,
             (select prod_inst_id, attr_value
                from PROD_INST_ATTR
               where ATTR_ID = 800000347
                 and status_cd = ''1000'') b
       where A.PROD_INST_ID = b.PROD_INST_ID(+)';
    EXECUTE IMMEDIATE V_SQL;
    insert into fflinyx.linyx_log values ('PROD_CDMA_USIM', sysdate, 4);
    commit; -----日志

    V_SQL := ' CREATE TABLE PROD_CDMA_USIM AS
      select /*+ PARALLEL(20) */A.*,
             c.MKT_RESO_ID
        from crmv2.PROD_CDMA_USIM1 A,CRMV1.MKT_RESOURCE C
         where  a.ATTR_VALUE = C.MKT_RESO_KEY(+)';
    EXECUTE IMMEDIATE V_SQL;

    insert into fflinyx.linyx_log values ('PROD_CDMA_STOP_GG', sysdate, 5);
    commit; -----日志
    V_SQL := 'CREATE TABLE PROD_CDMA_STOP_GG AS SELECT * FROM PROD_CDMA_STOP where product_id=''800000002'' and STATUS_CD not in (''140000'')';
    EXECUTE IMMEDIATE V_SQL;

    V_SQL := 'DELETE PROD_CDMA_STOP WHERE PROD_INST_ID IN (SELECT PROD_INST_ID FROM PROD_CDMA_STOP GROUP BY PROD_INST_ID HAVING COUNT(*)>1) AND ATTR_CD IN (''SO_SERViSTOP_OWE'',''SO_SERViSTOP_CALL_OWE'')';
    EXECUTE IMMEDIATE V_SQL;
    COMMIT;
    V_SQL := 'DELETE PROD_CDMA_STOP WHERE PROD_INST_ID IN (SELECT PROD_INST_ID FROM PROD_CDMA_STOP GROUP BY PROD_INST_ID HAVING COUNT(*)>1) AND ATTR_CD IN (''SO_SERViSTOP_RTLS'')';
    EXECUTE IMMEDIATE V_SQL;
    COMMIT;
    V_SQL := 'DELETE PROD_CDMA_STOP WHERE PROD_INST_ID IN (SELECT PROD_INST_ID FROM PROD_CDMA_STOP GROUP BY PROD_INST_ID HAVING COUNT(*)>1) AND ATTR_CD IN (''SO_SERViSTOP_REMOVE'')';
    EXECUTE IMMEDIATE V_SQL;
    COMMIT;
    insert into fflinyx.linyx_log values ('PROD_CDMA_IMSI', sysdate, 6);
    commit; -----日志
    V_SQL := 'CREATE TABLE PROD_CDMA_IMSI AS
    SELECT /*+ PARALLEL(20) */A.*,B.PARAM1 IMSI FROM PROD_CDMA_USIM A,(select * from CRMV1.MKT_RESO_FEA where FEA_SPEC_ID=620029411) B
    WHERE A.MKT_RESO_ID=B.MKT_RESO_ID(+)';
    EXECUTE IMMEDIATE V_SQL;

    /*    V_SQL := 'CREATE TABLE PROD_CDMA_IMSI_GG AS SELECT * FROM PROD_CDMA_IMSI WHERE PRODUCT_ID=''800000002''';
    EXECUTE IMMEDIATE V_SQL;*/
    ----改

    insert into fflinyx.linyx_log
    values
      ('PROD_CDMA_LTE_IMSI', sysdate, 7);
    commit; -----日志
    v_SQL := 'CREATE TABLE PROD_CDMA_LTE_IMSI AS
    select /*+ PARALLEL(20) */A.*,B.PARAM1 LTE_IMSI
    from crmv2.PROD_CDMA_IMSI A,(select * from CRMV1.MKT_RESO_FEA where FEA_SPEC_ID=620124477) B
    WHERE A.MKT_RESO_ID=B.MKT_RESO_ID(+)';
    EXECUTE IMMEDIATE V_SQL;

    insert into fflinyx.linyx_log
    values
      ('PROD_CDMA_LTE_IMSI_GG', sysdate, 8);
    commit; -----日志
    V_SQL := 'CREATE TABLE PROD_CDMA_LTE_IMSI_GG AS SELECT * FROM PROD_CDMA_LTE_IMSI WHERE PRODUCT_ID=''800000002'' and STATUS_CD not in (''140000'')';
    EXECUTE IMMEDIATE V_SQL;
    EXECUTE IMMEDIATE 'DELETE FROM PROD_CDMA_LTE_IMSI where ATTR_VALUE IS NULL';
    COMMIT;
    -------
    insert into fflinyx.linyx_log values ('PROD_CDMA_ALL', sysdate, 9);
    commit; -----日志
    V_SQL := 'CREATE TABLE PROD_CDMA_ALL AS SELECT /*+ PARALLEL(20) */A.*,
    DECODE(NVL(ATTR_CD,''0''),
    ''SO_SERViSTOP_PECC'',''1204'',
    ''SO_SERViSTOP_USER'',''1201'',
    ''SO_SERViSTOP_RTLS'',''1204'',
    ''SO_SERViSTOP_OWE'',''1204'',
    ''SO_SERViSTOP_CALL_OWE'',''1203'',
    ''SO_SERViSTOP_REMOVE'',''1101'', ''1001'') STATE FROM PROD_CDMA_LTE_IMSI A, PROD_CDMA_STOP B WHERE A.PROD_INST_ID = B.PROD_INST_ID(+)';
    EXECUTE IMMEDIATE V_SQL;
    COMMIT;

    insert into fflinyx.linyx_log values ('PROD_CDMA_ALL_GG', sysdate, 10);
    commit; -----日志
    V_SQL := 'CREATE TABLE PROD_CDMA_ALL_GG AS SELECT /*+ PARALLEL(20) */A.*,
    DECODE(NVL(ATTR_CD,''0''),
    ''SO_SERViSTOP_PECC'',''1204'',
    ''SO_SERViSTOP_USER'',''1204'',
    ''SO_SERViSTOP_RTLS'',''1204'',
    ''SO_SERViSTOP_OWE'',''1204'',
    ''SO_SERViSTOP_CALL_OWE'',''1203'',
    ''SO_SERViSTOP_REMOVE'',''1101'', ''1001'') STATE FROM PROD_CDMA_LTE_IMSI_GG A, PROD_CDMA_STOP_GG B WHERE A.PROD_INST_ID = B.PROD_INST_ID(+)';
    EXECUTE IMMEDIATE V_SQL;
    COMMIT;

    V_SQL := ' INSERT INTO INTF_BUS24001_AUDIT(INTF_CDMA_ALL_ID, MDN, IMSI, LTEIMSI,STATE, PAYTYPE, PROVINCECODE, CREATETIME, UPDATETIME,  PROD_INST_ID,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR) SELECT SEQ_INTF_CDMA_ALL_ID.NEXTVAL, MDN, IMSI ,LTE_IMSI, STATE, PAY_TYPE, ''600105'', to_char(LOCAL_CREATE_DATE, ''YYYYMMDDHH24MISS''), to_char(MODIFY_DATE, ''YYYYMMDDHH24MISS''), PROD_INST_ID,''BUS24001'',
             0,''' || V_BATCH_NBR || ''' FROM PROD_CDMA_ALL ';
    dbms_output.put_line(V_SQL);
    EXECUTE IMMEDIATE V_SQL;

    V_SQL := ' INSERT INTO INTF_BUS24001_AUDIT_GG(INTF_CDMA_ALL_ID, MDN, IMSI, STATE, PAYTYPE, PROVINCECODE, CREATETIME, UPDATETIME,  PROD_INST_ID,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR) SELECT SEQ_INTF_CDMA_ALL_ID.NEXTVAL, MDN, IMSI, STATE, PAY_TYPE, ''600105'', to_char(LOCAL_CREATE_DATE, ''YYYYMMDDHH24MISS''), to_char(MODIFY_DATE, ''YYYYMMDDHH24MISS''), PROD_INST_ID,''BUS24002'',
             0,''' || V_BATCH_NBR ||
             ''' FROM PROD_CDMA_ALL_GG ';
    -- dbms_output.put_line(V_SQL);
    EXECUTE IMMEDIATE V_SQL;
    V_SQL := ' INSERT INTO INTF_BUS24001_AUDIT_GG(INTF_CDMA_ALL_ID, MDN,  STATE, PAYTYPE, PROVINCECODE, CREATETIME, UPDATETIME,  PROD_INST_ID,BUS_CODE,CURRENT_PACKAGE,BATCH_NBR) SELECT SEQ_INTF_CDMA_ALL_ID.NEXTVAL, MDN, STATE, PAY_TYPE, ''600105'', to_char(LOCAL_CREATE_DATE, ''YYYYMMDDHH24MISS''), to_char(MODIFY_DATE, ''YYYYMMDDHH24MISS''), PROD_INST_ID,''BUS24002'',
             0,''' || V_BATCH_NBR ||
             ''' FROM PROD_CDMA_ALL_GG_xykd ';
    EXECUTE IMMEDIATE V_SQL;
    commit;

    ---排重
    delete from crmv2.INTF_BUS24001_AUDIT a
     where rowid <> (select max(rowid)
                       from crmv2.INTF_BUS24001_AUDIT b
                      where a.mdn = b.mdn);
    commit;
    delete from crmv2.INTF_BUS24001_AUDIT a
     where rowid <> (select max(rowid)
                       from crmv2.INTF_BUS24001_AUDIT b
                      where a.imsi = b.imsi);
    commit;
    delete from crmv2.INTF_BUS24001_AUDIT_GG a
     where rowid <> (select max(rowid)
                       from crmv2.INTF_BUS24001_AUDIT_GG b
                      where a.mdn = b.mdn);
    commit;
    delete from crmv2.INTF_BUS24001_AUDIT_GG a
     where rowid <> (select max(rowid)
                       from crmv2.INTF_BUS24001_AUDIT_GG b
                      where a.imsi = b.imsi);
    commit;
    -----WAP
    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from INTF_BUS24001_AUDIT b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.INTF_BUS24001_AUDIT a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.INTF_BUS24001_AUDIT a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.INTF_BUS24001_AUDIT
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop
        DBMS_OUTPUT.put_line('V_INT_NUM=' || V_INT_NUM);
        DBMS_OUTPUT.put_line('V_TOTAL_PACKAGE_NUM=' || V_TOTAL_PACKAGE_NUM);
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON('BUS24001', --业务功能编码
                        v_use_type1,
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE('BUS24001', V_BATCH_NBR);

    -------------GG
    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from INTF_BUS24001_AUDIT_GG b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.INTF_BUS24001_AUDIT_GG a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.INTF_BUS24001_AUDIT_GG a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.INTF_BUS24001_AUDIT_GG
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON('BUS24002', --业务功能编码
                        v_use_type2,
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE('BUS24002', V_BATCH_NBR);
    ----更新GG文件名
    UPDATE crmv2.intf_dep_ftp_control
       SET file_name = replace(file_name, 'BUS24002', 'BUS24001')
     where BUS_CODE = 'BUS24002'
       AND BATCH_NBR = V_BATCH_NBR;
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
      dbms_output.put_line(V_EXCEPITON);
  END;

  /* 4G产品实例日增量稽核*/
  procedure PROC_BUS60024 is
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 500000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS60024'; --业务功能编码
    v_sql               varchar2(2000);
  begin
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_DAY_TMP PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_DAY_TMP1 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_DAY_TMP11 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_DAY_TMP2 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_DAY_TMP3 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_DAY_TMP4 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_DAY_TMP5 PURGE';
    exception
      when others then
        null;
    end;

    --  execute immediate 'TRUNCATE TABLE PROD_INST_4G_DAY';

    execute immediate 'create table PROD_INST_4G_DAY_TMP nologging parallel 10 AS
                  select  distinct cust_so_number  from ITSC_CRMV2.VIEW_INTF_DEP_FINISH idf
                     where  trunc(idf.update_date) = trunc(sysdate - 1)';

    commit;
    execute immediate 'create table PROD_INST_4G_DAY_TMP1 nologging parallel 10 as
                  select distinct A.CUST_ORDER_ID from crmv2.customer_order_his a
       where cust_so_number in (select cust_so_number from PROD_INST_4G_DAY_TMP)';
    execute immediate 'create index idx_PROD_INST_4G_DAY_TMP1 on PROD_INST_4G_DAY_TMP1(cust_order_id)';

    execute immediate 'create table PROD_INST_4G_DAY_TMP11 nologging parallel 10 as
                  select distinct A.CUST_ORDER_ID from crmv2.customer_order a
       where cust_so_number in (select cust_so_number from PROD_INST_4G_DAY_TMP)';

    /*  execute immediate 'create table PROD_INST_4G_DAY_TMP2 nologging parallel 10 as
          select ORDER_ITEM_OBJ_ID prod_inst_id, finish_time
        from crmv2.order_item_his where 1=2';

    declare
      TYPE ref_cursor_type IS REF CURSOR;
      cur             ref_cursor_type;
      v_cust_order_id varchar2(20);
    begin
      v_sql := 'select cust_order_id from PROD_INST_4G_DAY_TMP11';
      open cur for v_sql;
      loop
        begin
          fetch cur
            into v_cust_order_id;
          exit when cur%notfound;
          execute immediate 'insert into PROD_INST_4G_DAY_TMP2
              select ORDER_ITEM_OBJ_ID prod_inst_id, finish_time
                from crmv2.order_item b
               where cust_order_id =' ||
                            v_cust_order_id ||
                            'AND b.class_id = ''4''
                 and entt_spec_type = ''AP''';
          commit;
        exception
          when others then
            null;
        end;
      end loop;
      close cur;
    end;

    declare
      TYPE ref_cursor_type IS REF CURSOR;
      cur             ref_cursor_type;
      v_cust_order_id varchar2(20);
    begin
      v_sql := 'select cust_order_id from PROD_INST_4G_DAY_TMP1';
      open cur for v_sql;
      loop
        begin
          fetch cur
            into v_cust_order_id;
          exit when cur%notfound;
          execute immediate 'insert into PROD_INST_4G_DAY_TMP2
              select ORDER_ITEM_OBJ_ID prod_inst_id, finish_time
                from crmv2.order_item_his b
               where cust_order_id =' ||
                            v_cust_order_id ||
                            'AND b.class_id = ''4''
                 and entt_spec_type = ''AP''';
          commit;
        exception
          when others then
            null;
        end;
      end loop;
      close cur;
    end;*/

    execute immediate 'create table PROD_INST_4G_DAY_TMP2 nologging parallel 10 as
select ORDER_ITEM_OBJ_ID prod_inst_id, finish_time,class_id,entt_spec_type
  from ORDER_ITEM_HIS
 where CUST_ORDER_ID IN
       (SELECT CUST_ORDER_ID FROM CRMV2.PROD_INST_4G_DAY_TMP1)';

    execute immediate 'insert into PROD_INST_4G_DAY_TMP2
       select ORDER_ITEM_OBJ_ID prod_inst_id, finish_time,class_id,entt_spec_type
  from ORDER_ITEM
 where CUST_ORDER_ID IN
       (SELECT CUST_ORDER_ID FROM CRMV2.PROD_INST_4G_DAY_TMP11)';
    commit;
    execute immediate 'delete from PROD_INST_4G_DAY_TMP2 where not(class_id = ''4'' and  entt_spec_type = ''AP'')';
    execute immediate 'delete from PROD_INST_4G_DAY_TMP2 where  entt_spec_type is null';
    commit;

    execute immediate 'delete from PROD_INST_4G_DAY_TMP2 a
             where nvl(finish_time,to_date(''2000/01/01'',''yyyy/mm/dd'')) <> (select max(finish_time)
          from PROD_INST_4G_DAY_TMP2 b
             where a.prod_inst_id = b.prod_inst_id)';
    commit;

    execute immediate ' create table PROD_INST_4G_DAY_TMP3 nologging parallel 10 as
      select a.*,
             acc_nbr,
             OWNER_CUST_ID,
             EXT_PROD_INST_ID,
             COMMON_REGION_ID,
             STATUS_CD,
             product_id,
             BEGIN_RENT_TIME,
             create_date
        from PROD_INST_4G_DAY_TMP2 a, prod_inst b
       where a.prod_inst_id = b.prod_inst_id and b.ext_prod_inst_id is not null';
    execute immediate ' create index idx_PROD_INST_4G_DAY_TMP3 on PROD_INST_4G_DAY_TMP3(prod_inst_id)';
    ---效率太低暂时先屏蔽不取  20160324
    /* execute immediate ' create table PROD_INST_4G_DAY_TMP4 nologging parallel 10 as
              select t.*, b.attr_value C_IMSI
                from (select a.*, C.attr_value USIM
                        from PROD_INST_4G_DAY_TMP3 a, PROD_INST_ATTR C
                       where A.PROD_INST_ID = C.PROD_INST_ID
                         AND C.ATTR_ID = 800000347) t
                left join (select * from PROD_INST_ATTR where ATTR_ID = 800000506) b on t.prod_inst_id =
                                                                                        B.PROD_INST_ID';
    */

    ----删除已被新装的旧号  PROD_INST_4G_DAY_TMP4改PROD_INST_4G_DAY_TMP3  20160324
    execute immediate ' delete from crmv2.PROD_INST_4G_DAY_TMP3 a where a.status_cd=''110000''
       and exists(select * from crmv2.PROD_INST_4G_DAY_TMP3 b where a.acc_nbr=b.acc_nbr
        and a.prod_inst_id<>b.prod_inst_id and b.status_cd<>''110000'')';
    commit;
    ---按集团要求更新 '1400000','140001','140002'

    /* execute immediate 'update crmv2.PROD_INST_4G_DAY_TMP5 a set status_cd=''140001'' where status_cd=''140000''';
    */
    execute immediate 'update crmv2.PROD_INST_4G_DAY_TMP3 a set status_cd=''120000'',BEGIN_RENT_TIME=NVL(A.BEGIN_RENT_TIME,A.CREATE_DATE)
 where status_cd=''140000'' and exists(select 1 from crmv2.prod_inst_attr c where a.prod_inst_id=c.prod_Inst_id and c.attr_id=''800000250'')';
    commit;
    execute immediate 'update crmv2.PROD_INST_4G_DAY_TMP3 a set status_cd=(select b.attr_value from prod_inst_attr b where a.prod_inst_id=b.prod_inst_id and b.attr_id=''800078200'')
 where status_cd=''140000'' and exists(select 1 from crmv2.prod_inst_attr c where a.prod_inst_id=c.prod_Inst_id and c.attr_id=''800078200'')';
    execute immediate 'update crmv2.PROD_INST_4G_DAY_TMP3 a set status_cd=(select b.attr_value from prod_inst_attr_his b where a.prod_inst_id=b.prod_inst_id and b.attr_id=''800078200''
    and attr_value is not null and rownum=1) where status_cd is null';
    commit;
    execute immediate 'update crmv2.PROD_INST_4G_DAY_TMP3 a set status_cd=''140002'' where status_cd=''140000''';
    commit;

    v_sql := ' INSERT INTO INTF_BUS60024_AUDIT
 select ACC_NBR,
        EXT_PROD_INST_ID,
        ''8350000'',
        D.REGION_CODE,
        A.STATUS_CD,
        '''',
        '''',
        '''',
        '''',
        e.source_code,
        e.source_name,
        NVL(TO_CHAR(A.BEGIN_RENT_TIME, ''YYYYMMDDHH24MISS''),TO_CHAR(A.FINISH_TIME, ''YYYYMMDDHH24MISS'')),
        TO_CHAR(A.FINISH_TIME, ''YYYYMMDDHH24MISS''),
        DECODE(A.STATUS_CD,
               ''110000'',
               TO_CHAR(A.FINISH_TIME, ''YYYYMMDDHH24MISS''),
               ''''),''' || V_BUS_CODE || ''',
           0,
           ''' || V_BATCH_NBR || '''
   from PROD_INST_4G_DAY_TMP3   A,
       CRMV2.COMMON_REGION_JT  B,
       PRODUCT                 C,
       CRMV2.COMMON_REGION_JT  D,
       crmv2.intf_dep_code_map e
 where A.COMMON_REGION_ID = B.COMMON_REGION_ID
   AND A.PRODUCT_ID = C.PRODUCT_ID
   AND A.FINISH_TIME IS NOT NULL
   and a.ext_prod_inst_id is NOT null
   AND B.UP_REGION_ID = D.COMMON_REGION_ID
   and to_char(c.ext_prod_id) = e.target_code
   and e.object_type = ''0100''';
    --dbms_output.put_line(v_sql);
    execute immediate v_sql;
    commit;

    execute immediate ' delete from crmv2.INTF_BUS60024_AUDIT a
             where nvl(finish_time,to_date(''2000/01/01'',''yyyy/mm/dd'')) <> (select max(finish_time)
          from crmv2.INTF_BUS60024_AUDIT b
             where a.phone_number = b.phone_number)';
    commit;

    execute immediate ' delete from crmv2.INTF_BUS60024_AUDIT a
             where rowid <> (select max(rowid)
          from crmv2.INTF_BUS60024_AUDIT b
             where a.phone_number = b.phone_number)';
    commit;

    PROC_CURRENT_PACKAGE_AVG('INTF_BUS60024_AUDIT',
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  end PROC_BUS60024;

  /* 4G产品实例月增量稽核*/
  procedure PROC_BUS60025 is
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 1000000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS60025'; --业务功能编码
    v_sql               varchar2(2000);
  begin
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_MONTH_TMP PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_MONTH_TMP1 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_MONTH_TMP2 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_INST_4G_MONTH_TMP3 PURGE';
    exception
      when others then
        null;
    end;

    execute immediate 'create table PROD_INST_4G_MONTH_TMP2 nologging parallel 16  as
     select b.prod_inst_id,b.ACC_NBR,b.product_id,b.EXT_PROD_INST_ID,b.area_code,b.status_cd,b.finish_time ,b.begin_rent_time
 from prod_inst b where product_id in(''800000002'',''800000007'') and ext_prod_inst_id is not null and length(ext_prod_inst_id) <30 and status_cd<>''110000'' and b.create_date<trunc(sysdate,''dd'')';

    execute immediate 'create index idx_PROD_INST_4G_MONTH_TMP2 on PROD_INST_4G_MONTH_TMP2(prod_inst_id)';

    /*
        execute immediate 'create table PROD_INST_4G_MONTH_TMP1 nologging parallel 4 AS
          select t.*, b.attr_value C_IMSI
            from (select a.*, C.attr_value USIM
                    from PROD_INST_4G_MONTH_TMP a, PROD_INST_ATTR C
                   where A.PROD_INST_ID = C.PROD_INST_ID
                     AND C.ATTR_ID = 800000347) t
            left join (select * from PROD_INST_ATTR where ATTR_ID = 800000506) b on t.prod_inst_id =
                                                                                    B.PROD_INST_ID';

        execute immediate ' create table PROD_INST_4G_MONTH_TMP2 nologging parallel 4 AS
    SELECT T1.*, T2.PARAM1 G_IMSI, T3.PARAM1 L_IMSI
      FROM (select A.*, B.MKT_RESO_ID
              from PROD_INST_4G_MONTH_TMP1 A, CRMV1.MKT_RESOURCE B
             where A.USIM = B.MKT_RESO_KEY) T1,
           (select * from CRMV1.MKT_RESO_FEA where FEA_SPEC_ID = 620124476) T2,
           (select * from CRMV1.MKT_RESO_FEA where FEA_SPEC_ID = 620124477) T3
     where T1.MKT_RESO_ID = T2.MKT_RESO_ID(+)
       AND T1.MKT_RESO_ID = T3.MKT_RESO_ID(+) ';
        execute immediate ' create index idx_PROD_INST_4G_MONTH_TMP2 on PROD_INST_4G_MONTH_TMP2(prod_inst_id)';
        execute immediate ' create index idx_PROD_INST_4G_MONTH_TMP21 on PROD_INST_4G_MONTH_TMP2(status_cd)';*/
    ----删除已被新装的旧号
    execute immediate ' delete from PROD_INST_4G_MONTH_TMP2 a where a.status_cd=''110000''
       and exists(select * from PROD_INST_4G_MONTH_TMP2 b where a.acc_nbr=b.acc_nbr
        and a.prod_inst_id<>b.prod_inst_id and b.status_cd<>''110000'')';
    commit;
    ---按集团要求更新 '1400000','140001','140002'
    declare
      TYPE ref_cursor_type IS REF CURSOR;
      cur            ref_cursor_type;
      v_prod_inst_id varchar2(20);
      v_attr_value   varchar2(20);
    begin
      v_sql := 'Select a.prod_inst_id,b.attr_value From crmv2.PROD_INST_4G_MONTH_TMP2 a,prod_inst_attr b where a.status_cd=''140000''
       and a.prod_inst_id=b.prod_inst_Id and b.attr_id=''800078200''';
      open cur for v_sql;
      loop
        begin
          fetch cur
            into v_prod_inst_id, v_attr_value;
          exit when cur%notfound;
          execute immediate ' update crmv2.PROD_INST_4G_MONTH_TMP2 a set status_cd=' ||
                            v_attr_value || ' where prod_inst_id=' ||
                            v_prod_inst_id;
          commit;
        exception
          when others then
            null;
        end;
      end loop;
      close cur;
    end;
    execute immediate ' update crmv2.PROD_INST_4G_MONTH_TMP2 a set status_cd=''140002'' where status_cd=''140000''';
    commit;
    execute immediate ' INSERT INTO INTF_BUS60025_AUDIT
     select a.ACC_NBR,
        a.EXT_PROD_INST_ID,
        ''8350000'',
        b.REGION_CODE,
        a.STATUS_CD,
        '''',
        '''',
        '''',
        '''',
        e.source_code,
        e.source_name,
        NVL(TO_CHAR(a.BEGIN_RENT_TIME, ''YYYYMMDDHH24MISS''),TO_CHAR(a.FINISH_TIME, ''YYYYMMDDHH24MISS'')),
        TO_CHAR(a.FINISH_TIME, ''YYYYMMDDHH24MISS''),
        DECODE(a.STATUS_CD,
               ''110000'',
               TO_CHAR(a.FINISH_TIME, ''YYYYMMDDHH24MISS''),
               ''''),''' || V_BUS_CODE || ''',
           0,
           ''' || V_BATCH_NBR || '''
   from PROD_INST_4G_MONTH_TMP2   A,
       CRMV2.COMMON_REGION_JT  B,
       PRODUCT                 C,
       crmv2.intf_dep_code_map e
 where a.area_code = B.area_code
   and b.common_region_id between 2 and 10
   AND a.PRODUCT_ID = C.PRODUCT_ID
   AND a.FINISH_TIME IS NOT NULL
   and a.ext_prod_inst_id is NOT null
   and to_char(c.ext_prod_id) = e.target_code
   and e.object_type = ''0100''';
    commit;
    -----剔重
    execute immediate 'delete from crmv2.INTF_BUS60025_AUDIT a where rowid<>(select max(rowid) from crmv2.INTF_BUS60025_AUDIT b where a.phone_number=b.phone_number)';
    commit;

    PROC_CURRENT_PACKAGE_AVG('INTF_BUS60025_AUDIT',
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  end PROC_BUS60025;

  /* 4G销售品实例日增量稽核*/
  procedure PROC_BUS60026 is
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 500000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS60026'; --业务功能编码
    v_sql               varchar2(2000);
  begin
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_DAY_TMP PURGE';
    exception
      when others then
        null;
    end;

    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_DAY_TMP1 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_DAY_TMP11 PURGE';
    exception
      when others then
        null;
    end;

    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_DAY_TMP2 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_DAY_TMP3 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_DAY_TMP4 PURGE';
    exception
      when others then
        null;
    end;

    execute immediate 'create table PROD_OFFER_INST_4G_DAY_TMP nologging parallel 8 AS
              select  distinct cust_so_number  from ITSC_CRMV2.VIEW_INTF_DEP_FINISH idf
                 where  trunc(idf.create_date) = trunc(sysdate - 1)';

    execute immediate 'create table PROD_OFFER_INST_4G_DAY_TMP1 nologging parallel 8 as
              select distinct A.CUST_ORDER_ID from crmv2.customer_order_his a
   where cust_so_number in (select cust_so_number from PROD_OFFER_INST_4G_DAY_TMP)';

    execute immediate 'create table PROD_OFFER_INST_4G_DAY_TMP11 nologging parallel 8 as
              select distinct A.CUST_ORDER_ID from crmv2.customer_order a
   where cust_so_number in (select cust_so_number from PROD_OFFER_INST_4G_DAY_TMP)';

    /*execute immediate 'create table PROD_OFFER_INST_4G_DAY_TMP2 nologging parallel 8 as
      select ORDER_ITEM_OBJ_ID prod_offer_inst_id, finish_time,service_offer_id
    from crmv2.order_item_his where 1=2';

    declare
      TYPE ref_cursor_type IS REF CURSOR;
      cur             ref_cursor_type;
      v_cust_order_id varchar2(20);
    begin
      v_sql := 'select cust_order_id from PROD_OFFER_INST_4G_DAY_TMP11';
      open cur for v_sql;
      loop
        begin
          fetch cur
            into v_cust_order_id;
          exit when cur%notfound;
          execute immediate 'insert into PROD_OFFER_INST_4G_DAY_TMP2
          select ORDER_ITEM_OBJ_ID prod_offer_inst_id, finish_time,service_offer_id
            from crmv2.order_item b
           where cust_order_id =' ||
                            v_cust_order_id || 'AND b.class_id = ''6''';
          commit;
        exception
          when others then
            null;
        end;
      end loop;
      close cur;
    end;

    declare
      TYPE ref_cursor_type IS REF CURSOR;
      cur             ref_cursor_type;
      v_cust_order_id varchar2(20);
    begin
      v_sql := 'select cust_order_id from PROD_OFFER_INST_4G_DAY_TMP1';
      open cur for v_sql;
      loop
        begin
          fetch cur
            into v_cust_order_id;
          exit when cur%notfound;
          execute immediate 'insert into PROD_OFFER_INST_4G_DAY_TMP2
          select ORDER_ITEM_OBJ_ID prod_offer_inst_id, finish_time,service_offer_id
            from crmv2.order_item_his b
           where cust_order_id =' ||
                            v_cust_order_id || 'AND b.class_id = ''6''';
          commit;
        exception
          when others then
            null;
        end;
      end loop;
      close cur;
    end;*/
    execute immediate ' create table PROD_OFFER_INST_4G_DAY_TMP2 as
select ORDER_ITEM_OBJ_ID prod_offer_inst_id, finish_time,class_Id
  from ORDER_ITEM_HIS
 where CUST_ORDER_ID IN
       (SELECT CUST_ORDER_ID FROM CRMV2.PROD_OFFER_INST_4G_DAY_TMP1)';

    execute immediate 'insert into PROD_OFFER_INST_4G_DAY_TMP2
select ORDER_ITEM_OBJ_ID prod_offer_inst_id, finish_time,class_Id
  from ORDER_ITEM
 where CUST_ORDER_ID IN
       (SELECT CUST_ORDER_ID FROM CRMV2.PROD_OFFER_INST_4G_DAY_TMP11)';
    commit;

    execute immediate 'delete from PROD_OFFER_INST_4G_DAY_TMP2 where class_id<>''6''';
    commit;

    execute immediate 'delete from PROD_OFFER_INST_4G_DAY_TMP2 a
             where finish_time <> (select max(finish_time)
          from PROD_OFFER_INST_4G_DAY_TMP2 b
         where a.prod_offer_inst_id = b.prod_offer_inst_id)';
    commit;
    execute immediate ' delete from PROD_OFFER_INST_4G_DAY_TMP2 a
    where rowid <>
          (select max(rowid)
             from PROD_OFFER_INST_4G_DAY_TMP2 b
            where a.prod_offer_inst_id = b.prod_offer_inst_id)';
    commit;

    execute immediate ' create table PROD_OFFER_INST_4G_DAY_TMP3 nologging parallel 10 as
   select a.*,
         b.ext_prod_offer_inst_id,
         b.cust_id,
         b.eff_date,
         b.exp_date,
         b.create_date,
         b.status_cd,b.region_cd,b.prod_offer_id
    from crmv2.PROD_OFFER_INST_4G_DAY_TMP2 a, prod_offer_inst b
   where a.prod_offer_inst_id = b.prod_offer_inst_id';

    /*  execute immediate ' insert into PROD_OFFER_INST_4G_DAY_TMP3
    select a.*,
          b.ext_prod_offer_inst_id,
          b.cust_id,
          b.eff_date,
          b.exp_date,
          b.create_date,
          b.status_cd,b.region_cd,b.prod_offer_id
     from crmv2.PROD_OFFER_INST_4G_DAY_TMP2 a, prod_offer_inst_his b
    where a.prod_offer_inst_id = b.prod_offer_inst_id
    and b.status_cd=''1100''';
    commit;*/

    execute immediate ' create table PROD_OFFER_INST_4G_DAY_TMP4 nologging parallel 8 as
 select a.*, c.source_code, c.source_name,E.EXPIRE_TYPE
   from PROD_OFFER_INST_4G_DAY_TMP3 a,
        prod_offer e,
        (select distinct t.*
           from crmv2.intf_dep_code_map t
          where t.object_type = ''0200''
            and intf_dep_code_map_id =
                (select max(intf_dep_code_map_id)
                   from crmv2.intf_dep_code_map g
                  where g.object_type = ''0200''
                    and t.target_code = g.target_code)) c
  where a.prod_offer_id = e.prod_offer_id
    and e.ext_offer_nbr = c.target_code';

    execute immediate 'UPDATE PROD_OFFER_INST_4G_DAY_TMP4 SET STATUS_CD=''1000'' where STATUS_CD=''1100'' AND EXPIRE_TYPE=''3''';
    COMMIT;
    execute immediate 'delete from PROD_OFFER_INST_4G_DAY_TMP4 a
             where nvl(create_date,to_date(''2000/01/01'',''yyyy/mm/dd'')) <> (select max(create_date)
          from PROD_OFFER_INST_4G_DAY_TMP4 b
             where a.prod_offer_inst_id = b.prod_offer_inst_id)';
    commit;
    execute immediate 'insert into INTF_BUS60026_AUDIT
      select ext_prod_offer_inst_id,
             ''8350000'',
             D.region_code,
             nvl(a.cust_id,''99999''),
             a.status_cd,
             a.source_code,
             a.source_name,
             nvl(decode(TO_CHAR(A.eff_date, ''YYYYMMDD''),''21990101'',TO_CHAR(A.create_date, ''YYYYMMDDHH24MISS''),TO_CHAR(A.eff_date, ''YYYYMMDDHH24MISS'')),TO_CHAR(A.create_date, ''YYYYMMDDHH24MISS'')),
             case when TO_CHAR(A.exp_date, ''YYYYMMDD'')>=''20300101'' then ''30000201000000'' else TO_CHAR(A.exp_date, ''YYYYMMDDHH24MISS'') end,
             ''' || V_BUS_CODE || ''',
           0,
           ''' || V_BATCH_NBR || '''
        from crmv2.PROD_OFFER_INST_4G_DAY_TMP4 a,
             crmv2.common_region_jt      b,
             crmv2.common_region_jt      D
       where a.region_cd = b.common_region_id
         and ext_prod_offer_inst_id is not null
         AND B.UP_REGION_ID=D.COMMON_REGION_ID';
    commit;

    PROC_CURRENT_PACKAGE_AVG('INTF_BUS60026_AUDIT',
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END PROC_BUS60026;

  /* 4G销售品实例月增量稽核*/
  procedure PROC_BUS60027 is
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 1000000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS60027'; --业务功能编码
    v_sql               varchar2(2000);
  begin
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_MONTH_TMP PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_MONTH_TMP1 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_MONTH_TMP2 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE PROD_OFFER_INST_4G_MONTH_TMP3 PURGE';
    exception
      when others then
        null;
    end;

    /*    begin
       execute immediate 'create table PROD_OFFER_INST_4G_MONTH_TMP as
       select prod_inst_id from PROD_INST_4G_MONTH_TMP';
     exception
       when others then
         execute immediate 'create table PROD_OFFER_INST_4G_MONTH_TMP nologging parallel 4  as
      select b.prod_inst_id  from prod_inst b where product_id=''800000002'' and ext_prod_inst_id is not null
       and length(ext_prod_inst_id) <30 and status_cd<>''110000'' and b.create_date<trunc(sysdate,''dd'')';

     end;
     execute immediate 'create index idx_OFFER_INST_4G_MONTH_TMP on PROD_OFFER_INST_4G_MONTH_TMP(prod_inst_id)';

     execute immediate 'create table PROD_OFFER_INST_4G_MONTH_TMP1  as
     select distinct b.prod_offer_inst_id from PROD_OFFER_INST_4G_MONTH_TMP a,crmv2.offer_prod_inst_rel b where a.prod_inst_id=b.prod_inst_id';

     execute immediate 'create index idx_OFFER_INST_4G_MONTH_TMP1 on PROD_OFFER_INST_4G_MONTH_TMP1(prod_offer_inst_id)';

     execute immediate 'create table PROD_OFFER_INST_4G_MONTH_TMP2 nologging parallel 4  as
    select a.*,
          b.ext_prod_offer_inst_id,
          b.cust_id,
          b.eff_date,
          b.exp_date,
          b.create_date,
          b.status_cd,b.region_cd,b.prod_offer_id
     from PROD_OFFER_INST_4G_MONTH_TMP1 a, prod_offer_inst b
    where a.prod_offer_inst_id = b.prod_offer_inst_id';*/
    execute immediate ' create table PROD_OFFER_INST_4G_MONTH_TMP2 nologging parallel 8  as
    select b.prod_offer_inst_id,
         b.ext_prod_offer_inst_id,
         b.cust_id,
         b.eff_date,
         b.exp_date,
         b.create_date,
         b.status_cd,b.region_cd,b.prod_offer_id
      from prod_offer_inst b
     where ext_prod_offer_inst_id is not null
       and status_cd <> ''1100''
       and create_date < trunc(sysdate, ''dd'')
       and length(ext_prod_offer_inst_id) <30';

    ----一次性优惠
    execute immediate 'insert into PROD_OFFER_INST_4G_MONTH_TMP2
  select /*+index(b,IDX_PROD_OFFER_INST_013)*/ b.prod_offer_inst_id,
         b.ext_prod_offer_inst_id,
         b.cust_id,
         b.eff_date,
         last_day(sysdate),
         b.create_date,
         ''1000'',
         b.region_cd,
         b.prod_offer_id
    from prod_offer_inst b
   where prod_offer_id in
         (select distinct target_code
  from crmv2.intf_dep_code_map
 where object_type = ''0200''
   and target_code in
       (select prod_offer_id from prod_offer where expire_type = ''3'' or prod_offer_id in (''900409809'',''900409810'')))
     and create_date >= add_months(trunc(sysdate, ''mm''), -3)
     and length(ext_prod_offer_inst_id) < 30';
    commit;

    execute immediate 'delete from CRMV2.PROD_OFFER_INST_4G_MONTH_TMP2 A
   where EXP_DATE <>
         (SELECT MIN(EXP_DATE)
            FROM CRMV2.PROD_OFFER_INST_4G_MONTH_TMP2 B
           where A.PROD_OFFER_INST_ID = B.PROD_OFFER_INST_ID)';
    COMMIT;

    execute immediate ' create table PROD_OFFER_INST_4G_MONTH_TMP3  nologging parallel 8 as
 select a.*, c.source_code, c.source_name
   from PROD_OFFER_INST_4G_MONTH_TMP2 a,
        prod_offer e,
        (select distinct t.*
           from crmv2.intf_dep_code_map t
          where t.object_type = ''0200''
            and intf_dep_code_map_id =
                (select max(intf_dep_code_map_id)
                   from crmv2.intf_dep_code_map g
                  where g.object_type = ''0200''
                    and t.target_code = g.target_code)) c
  where a.prod_offer_id = e.prod_offer_id
    and e.ext_offer_nbr = c.target_code';

    execute immediate 'insert into INTF_BUS60027_AUDIT
      select ext_prod_offer_inst_id,
             ''8350000'',
             D.region_code,
             nvl(a.cust_id,''99999''),
             a.status_cd,
             a.source_code,
             a.source_name,
             nvl(decode(TO_CHAR(A.eff_date, ''YYYYMMDD''),''21990101'',TO_CHAR(A.create_date, ''YYYYMMDDHH24MISS''),TO_CHAR(A.eff_date, ''YYYYMMDDHH24MISS'')),TO_CHAR(A.create_date, ''YYYYMMDDHH24MISS'')),
             case when TO_CHAR(A.exp_date, ''YYYYMMDD'')>=''20300101'' then ''30000201000000'' else TO_CHAR(A.exp_date, ''YYYYMMDDHH24MISS'') end,
             ''' || V_BUS_CODE || ''',
           0,
           ''' || V_BATCH_NBR || '''
        from PROD_OFFER_INST_4G_MONTH_TMP3 a,
             crmv2.common_region_jt      b,
             crmv2.common_region_jt      D
       where a.region_cd = b.common_region_id
         and ext_prod_offer_inst_id is not null
         AND B.UP_REGION_ID=D.COMMON_REGION_ID
         and a.ext_prod_offer_inst_id is not null';
    commit;

    /*    execute immediate 'insert into INTF_BUS60027_AUDIT
             select ext_prod_offer_inst_id,
       province_id,
       lan_id,
       cust_id,
       offer_inst_status_cd,
       ext_prod_offer_id,
       prod_offer_name,
       eff_date,
       exp_date,''' || V_BUS_CODE || ''',
           0,
           ''' || V_BATCH_NBR ||
                      ''' from FFLINYX.INTF_BUS60027_AUDIT_JTDY a';
    commit;*/

    execute immediate ' delete from crmv2.intf_bus60027_audit a where
    rowid<>(select max(rowid) from crmv2.intf_bus60027_audit b where a.ext_prod_offer_inst_id=b.ext_prod_offer_inst_id)';
    commit;
    execute immediate 'update crmv2.intf_bus60027_audit set offer_inst_status_cd=''1000'' where offer_inst_status_cd<>''1000''';
    commit;

    PROC_CURRENT_PACKAGE_AVG('INTF_BUS60027_AUDIT',
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END PROC_BUS60027;

  procedure PROC_GG_UPLOAD is
    V_MAX_NUMBER        INTEGER;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50); --业务功能编码
    v_sql               varchar2(4000);
    v_str               varchar2(20);
    v_tab_old           varchar2(30);
    v_ERR_MSG           varchar2(1000);
  begin
    -----------------------------------------正式表--------------------------------------
    FOR REC IN (SELECT BUS_CODE, USE_TYPE, RECORD_NUM
                  FROM CRMV2.INTF_DEP_FTP
                 where BUS_CODE IN ('BUS26001',
                                    'BUS26002',
                                    'BUS26003',
                                    'BUS26008',
                                    'BUS26010',
                                    'BUS26012',
                                    'BUS26013' /*, 'BUS26014'*/,
                                    'BUS26027')) LOOP
      V_BUS_CODE  := REC.BUS_CODE;
      V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
      PROC_INIT_TABLE(V_BUS_CODE);
      --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
      PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                      REC.USE_TYPE,
                      V_BATCH_NBR, --批次号
                      1, --分割批次号
                      1); --分割次数总数

      V_STR     := 'INTF_' || V_BUS_CODE || '_AUDIT';
      v_tab_old := 'fflingy.GJ591_' || V_BUS_CODE;
      insert into fflingy.gj_log
        (gj_log_id, proc_name, begin_time)
        select fflingy.seq_gj_log_id.nextval, V_STR, sysdate from dual;
      commit;
      v_sql := ' insert into ' || V_STR || ' select t1.*,''' || V_BUS_CODE ||
               ''',0,''' || V_BATCH_NBR || ''' from ' || v_tab_old || ' t1';
      dbms_output.put_line('v_sql' || v_sql);
      execute immediate v_sql;
      commit;
      update fflingy.gj_log set end_time = sysdate where proc_name = V_STR;
      commit;

      PROC_CURRENT_PACKAGE_AVG(V_STR,
                               V_BATCH_NBR,
                               REC.RECORD_NUM,
                               V_TOTAL_PACKAGE_NUM);
      V_INT_NUM := 2;
      if V_TOTAL_PACKAGE_NUM > 1 then
        loop

          --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
          PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                          REC.USE_TYPE,
                          V_BATCH_NBR, --批次号
                          V_INT_NUM, --分割批次号
                          V_TOTAL_PACKAGE_NUM); --分割次数总数
          V_INT_NUM := V_INT_NUM + 1;
          EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
        end loop;
      end if;
      update crmv2.intf_dep_ftp_control
         set total_package_num = V_TOTAL_PACKAGE_NUM
       where batch_nbr = V_BATCH_NBR;
      COMMIT;
      --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
      PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);

    END LOOP;
  exception
    when others then
      v_ERR_MSG := sqlerrm;
      insert into fflingy.gj_log
        (gj_log_id, remark)
      values
        (fflingy.seq_gj_log_id.nextval, v_ERR_MSG);
      commit;
  end;

  /*IVPN数据上传集团*/
  procedure PROC_BUS23002 is

    ydjf_flag              number;
    startdate              date;
    v_INTF_FTP_CONTROL_ID  crmv2.INTF_FTP_CONTROL.INTF_FTP_CONTROL_ID%TYPE;
    v_INTF_FTP_CONTROL_NBR crmv2.INTF_FTP_CONTROL.INTF_FTP_CONTROL_NBR%TYPE;
    cCustOrderType         varchar(6);
    cPricePlanCode         VARCHAR2(30);
    cProdCode              VARCHAR2(30) := '00201034101000000000';
    dd                     varchar(4);
    str_errmsg             varchar2(2000);
    cysx_flag              number;
    v_prod_offer_inst_id   crmv2.prod_offer_inst.prod_offer_inst_id%type;
    v_prod_offer_id        crmv2.prod_offer.prod_offer_id%type;
    V_HAVE_PARAM           INTEGER;
    v_custid               varchar2(50);
    V_MAX_NUMBER           INTEGER := 50000;
    V_INT_NUM              INTEGER;
    V_CURRENT_PACKAGE      NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM    NUMBER := 0; --分割批次数总数
    V_COUNT                NUMBER := 0; --取数总量
    V_BATCH_NBR            VARCHAR2(100); --批次号
    V_BUS_CODE             VARCHAR2(50) := 'BUS23002'; --业务功能编码
    v_sql                  varchar2(2000);
    v_use_type1            VARCHAR2(50);
  begin

    --cProvinceCode  := '600105';
    cCustOrderType := '212';
    --拆网或者退网数据的开始时间

    select to_char(sysdate, 'dd') into dd from dual;
    /*  if dd NOT IN ('01', '07', '15', '21', '27') then
      return;
    end if;*/
    IF dd = '01' then
      select add_months(last_day(trunc(sysdate)) + 1, -2)
        into startdate
        from dual;
    else
      select add_months(last_day(trunc(sysdate)), -1) + 1
        into startdate
        from dual;
    end if;

    execute IMMEDIATE 'select use_type  from crmv2.Intf_Dep_Ftp where bus_code=''BUS23002'' and frequency in (' || dd || ')'
      into v_use_type1;

    --批次号生成，格式 BUS_CODEYYYYMMDDHH  例如：BUS2300120150730
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    --清除表数据，同时清理intf_dep_ftp_control数据
    PROC_INIT_TABLE(V_BUS_CODE);
    --插1条数据到intf_dep_ftp_control
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    v_use_type1,
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数

    --对所有集团IVPN数据进行处理
    execute immediate 'truncate table ffzhanghw.jt_ivpn_temp';
    insert into ffzhanghw.jt_ivpn_temp
      select a.prod_inst_id,
             a.owner_cust_id,
             b.status_cd,
             b.prod_inst_z_id,
             b.status_date,
             c.product_id,
             c.area_code,
             c.acc_nbr
        from crmv2.prod_inst a, crmv2.prod_inst_rel b, crmv2.prod_inst c
       where a.product_id in ('800299131', '800000343')
         and a.prod_inst_id = b.prod_inst_a_id
         and relation_type_cd = '100300'
         and b.prod_inst_z_id = c.prod_inst_id
         and c.acc_nbr is not null;
    commit;

    insert into ffzhanghw.jt_ivpn_temp
      select a.prod_inst_id,
             a.owner_cust_id,
             b.status_cd,
             b.prod_inst_z_id,
             b.update_date,
             c.product_id,
             c.area_code,
             c.acc_nbr
        from crmv2.prod_inst         a,
             crmv2.prod_inst_rel_his b,
             crmv2.prod_inst         c
       where a.product_id in ('800299131', '800000343')
         and a.prod_inst_id = b.prod_inst_a_id
         and relation_type_cd = '100300'
         and b.prod_inst_z_id = c.prod_inst_id
         and c.acc_nbr is not null
         and (b.status_cd = '1100' and b.exp_date > startdate)
         and c.prod_inst_id not in
             (select prod_inst_z_id from ffzhanghw.jt_ivpn_temp);
    commit;
    insert into ffzhanghw.jt_ivpn_temp
      select a.prod_inst_id,
             a.owner_cust_id,
             b.status_cd,
             b.prod_inst_z_id,
             b.update_date,
             c.product_id,
             c.area_code,
             c.acc_nbr
        from crmv2.prod_inst         a,
             crmv2.prod_inst_rel_his b,
             crmv2.prod_inst_his     c
       where a.product_id in ('800299131', '800000343')
         and a.prod_inst_id = b.prod_inst_a_id
         and relation_type_cd = '100300'
         and b.prod_inst_z_id = c.prod_inst_id
         and c.status_cd = '110000'
         and b.status_cd = '1100'
         and b.update_date > startdate
         and c.prod_inst_id not in
             (select prod_inst_z_id from ffzhanghw.jt_ivpn_temp);
    commit;
    delete from ffzhanghw.jt_ivpn_temp a
     where (prod_inst_id, prod_inst_z_id) in
           (select prod_inst_id, prod_inst_z_id
              from ffzhanghw.jt_ivpn_temp
             group by prod_inst_id, prod_inst_z_id
            having count(*) > 1)
       and a.status_date <>
           (select max(status_date)
              from ffzhanghw.jt_ivpn_temp b
             where a.prod_inst_id = b.prod_inst_id
               and a.prod_inst_z_id = b.prod_inst_z_id);
    commit;

    DELETE from ffzhanghw.jt_ivpn_temp A
     where status_date <> (select max(status_date)
                             from ffzhanghw.jt_ivpn_temp B
                            where A.acc_nbr = B.acc_nbr);
    commit;

    for rec in (select * from ffzhanghw.jt_ivpn_temp) loop

      --对单条集团IVPN数据进行处理

      begin
        if rec.status_cd = '1100' then
          cCustOrderType := '213';
        ELSE
          cCustOrderType := '212';
        end if;
        --prodid
        ydjf_flag := 0;
        cysx_flag := 0;
        select b.group_cust_seq
          into v_custid
          from prod_inst a, cust b
         where a.prod_inst_id = rec.prod_inst_id
           and a.owner_cust_id = b.cust_id;
        --取套餐
        if rec.prod_inst_id = 49937301 then
          --49937301 表示军翼网
          cPricePlanCode := '10011'; -- 集团下发的集团套餐编码
        else
          begin
            BEGIN
              select b.prod_offer_inst_id, C.prod_offer_id
                into v_prod_offer_inst_id, v_prod_offer_id
                from crmv2.offer_prod_inst_rel a,
                     crmv2.prod_offer_inst     b,
                     prod_offer                c
               where a.prod_inst_id = rec.prod_inst_z_id
                 and a.prod_offer_inst_id = b.prod_offer_inst_id
                 and b.prod_offer_id = c.prod_offer_id
                 and c.offer_sub_type = 'T01'
                 and b.prod_offer_id in
                     (select destination_code
                        from crmv2.intf_code_mapping
                       where source_system = 'GROUP'
                         AND OBJECT_TYPE = 'PROD_OFFER_CODE'
                         AND OBJECT_NAME = '集团IVPN套餐');
            exception
              when others then
                BEGIN
                  select b.prod_offer_inst_id, C.prod_offer_id
                    into v_prod_offer_inst_id, v_prod_offer_id
                    from crmv2.offer_prod_inst_rel a,
                         crmv2.prod_offer_inst     b,
                         prod_offer                c
                   where a.prod_inst_id = rec.prod_inst_z_id
                     and a.prod_offer_inst_id = b.prod_offer_inst_id
                     and b.prod_offer_id = c.prod_offer_id
                     and c.offer_sub_type <> 'T01'
                     and b.prod_offer_id in
                         (select destination_code
                            from crmv2.intf_code_mapping
                           where source_system = 'GROUP'
                             AND OBJECT_TYPE = 'PROD_OFFER_CODE'
                             AND OBJECT_NAME = '集团IVPN套餐');
                exception
                  when others then
                    str_errmsg := sqlerrm;
                    select distinct b.prod_offer_inst_id, prod_offer_id
                      into v_prod_offer_inst_id, v_prod_offer_id
                      from crmv2.offer_prod_inst_rel_his a,
                           crmv2.prod_offer_inst_his     b
                     where a.prod_inst_id = rec.prod_inst_z_id
                       and a.prod_offer_inst_id = b.prod_offer_inst_id
                       and a.status_cd = '1100'
                       and b.status_cd = '1100'
                       AND A.UPDATE_DATE > startdate
                       and b.prod_offer_id in
                           (select destination_code
                              from crmv2.intf_code_mapping
                             where source_system = 'GROUP'
                               AND OBJECT_TYPE = 'PROD_OFFER_CODE'
                               AND OBJECT_NAME = '集团IVPN套餐')
                       and a.update_date =
                           (select max(update_date)
                              from crmv2.offer_prod_inst_rel_his q
                             where q.prod_offer_inst_id in
                                   (select b.prod_offer_inst_id
                                      from crmv2.offer_prod_inst_rel_his a,
                                           crmv2.prod_offer_inst_his     b
                                     where a.prod_inst_id =
                                           rec.prod_inst_z_id
                                       and a.prod_offer_inst_id =
                                           b.prod_offer_inst_id
                                       and a.status_cd = '1100'
                                       and b.status_cd = '1100'
                                       AND A.update_date > startdate
                                       and b.prod_offer_id in
                                           (select destination_code
                                              from crmv2.intf_code_mapping
                                             where source_system = 'GROUP'
                                               AND OBJECT_TYPE =
                                                   'PROD_OFFER_CODE'
                                               AND OBJECT_NAME = '集团IVPN套餐'))
                               and status_cd = '1100');
                END;
            END;
          end;
          Select Count(1)
            INTO V_HAVE_PARAM
            From CRMV2.INTF_CODE_MAPPING A, CRMV2.INTF_CODE_MAPPING B
           where A.DESTINATION_CODE = V_PROD_OFFER_ID
             AND A.source_system = 'GROUP'
             AND A.OBJECT_TYPE = 'PROD_OFFER_CODE'
             AND A.OBJECT_NAME = '集团IVPN套餐'
             AND A.SOURCE_CODE = B.SOURCE_CODE
             AND B.SOURCE_SYSTEM = 'GROUP'
             AND B.OBJECT_TYPE = 'PROD_OFFER_ATTR';
          if v_have_param > 0 then
            BEGIN
              select E.SOURCE_CODE
                INTO cPricePlanCode --- 集团下发的集团套餐编码
                from CRMV2.INTF_CODE_MAPPING    A,
                     CRMV2.INTF_CODE_MAPPING    B,
                     CRMV2.PROD_OFFER_INST_ATTR C,
                     CRMV2.ATTR_SPEC            D,
                     CRMV2.INTF_CODE_MAPPING    E,
                     CRMV2.ATTR_VALUE           F
               WHERE A.DESTINATION_CODE = v_prod_offer_id
                 AND A.source_system = 'GROUP'
                 AND A.OBJECT_TYPE = 'PROD_OFFER_CODE'
                 AND A.OBJECT_NAME = '集团IVPN套餐'
                 AND A.SOURCE_CODE = B.SOURCE_CODE
                 AND B.SOURCE_SYSTEM = 'GROUP'
                 AND B.OBJECT_NAME = 'PROD_OFFER_ATTR'
                 AND B.Destination_Code = D.EXT_ATTR_NBR
                 AND D.ATTR_ID = C.ATTR_ID
                 AND C.PROD_OFFER_INST_ID = v_prod_offer_inst_id
                 AND C.ATTR_VALUE = F.ATTR_VALUE
                 AND C.ATTR_VALUE_ID = F.ATTR_VALUE_ID
                 and f.attr_id = d.attr_id
                 AND E.SOURCE_SYSTEM = 'GROUP'
                 AND E.OBJECT_NAME = 'PROD_OFFER_ATTR_VALUE'
                 AND E.source_code = a.source_code
                 and c.attr_value_id = e.destination_code;
            EXCEPTION
              WHEN OTHERS THEN
                BEGIN
                  select E.SOURCE_CODE
                    INTO cPricePlanCode
                    from CRMV2.INTF_CODE_MAPPING        A,
                         CRMV2.INTF_CODE_MAPPING        B,
                         CRMV2.PROD_OFFER_INST_ATTR_HIS C,
                         CRMV2.ATTR_SPEC                D,
                         CRMV2.INTF_CODE_MAPPING        E,
                         CRMV2.ATTR_VALUE               F
                   WHERE A.DESTINATION_CODE = V_PROD_OFFER_ID
                     AND A.source_system = 'GROUP'
                     AND A.OBJECT_TYPE = 'PROD_OFFER_CODE'
                     AND A.OBJECT_NAME = '集团IVPN套餐'
                     AND A.SOURCE_CODE = B.SOURCE_CODE
                     AND B.SOURCE_SYSTEM = 'GROUP'
                     AND B.OBJECT_NAME = 'PROD_OFFER_ATTR'
                     AND B.Destination_Code = D.EXT_ATTR_NBR
                     AND C.STATUS_CD = '1100'
                     AND C.CREATE_DATE =
                         (SELECT MAX(CREATE_DATE)
                            FROM CRMV2.PROD_OFFER_INST_ATTR_HIS
                           WHERE PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
                             AND ATTR_ID = C.ATTR_ID)
                     AND D.ATTR_ID = C.ATTR_ID
                     AND C.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
                     AND C.ATTR_VALUE = F.ATTR_VALUE
                     AND C.ATTR_VALUE_ID = F.ATTR_VALUE_ID
                     and f.attr_id = d.attr_id
                     AND E.SOURCE_SYSTEM = 'GROUP'
                     AND E.OBJECT_NAME = 'PROD_OFFER_ATTR_VALUE'
                     AND E.source_code = a.source_code
                     and c.attr_value_id = e.destination_code;
                END;
            END;
          else
            select source_code
              into cPricePlanCode
              from crmv2.intf_code_mapping
             where object_type = 'PROD_OFFER_CODE'
               and source_system = 'GROUP'
               and destination_code = v_prod_offer_id
               AND OBJECT_NAME = '集团IVPN套餐';
          end if;
        end if;

        INSERT INTO crmv2.intf_bus23002_audit
          (intf_ivpn_id,
           provincecode,
           custid,
           ProductNbr,
           custordertype,
           citycode,
           prodcode,
           priceplancode,
           bus_code,
           current_package,
           batch_nbr)
        values
          (crmv2.seq_intf_ivpn_id.nextval,
           '600105',
           v_custid,
           rec.acc_nbr,
           cCustOrderType,
           rec.area_code,
           cProdCode,
           cPricePlanCode,
           '',
           '0',
           V_BATCH_NBR);
        commit;

      exception
        when others then
          null;

      end;

    end loop; -- 对所有集团IVPN数据进行处理

    ----套餐拆除保留212
    /* ---先判断是否拆机或退网,是则标识一下不插入 crmv2.intf_bus23002_audit   -----这段放到job2768执行
    update fflinyx.intf_ivpn_tmp a
       set seq = 1
     where exists (select *
              from prod_inst c
             where a.ProductNbr = c.acc_nbr
               and c.product_id = '800000002'
               and c.status_cd = '110000'
               and update_date < trunc(sysdate, 'mm'));
    commit;
    update fflinyx.intf_ivpn_tmp a
       set seq = 2
     where exists
     (select *
              from crmv2.intf_jt_monitor b, crmv2.intf_jt_data_info c
             where a.ProductNbr = b.acc_nbr
               and b.order_item_group_id = c.order_item_group_id
               and c.jt_in_xml_msg like '%<OrderTypeCd>213</OrderTypeCd>%'
               and c.insert_date < trunc(sysdate, 'mm')
               and b.state = '70C'
               AND C.STATE = '70C');
    COMMIT;*/

    INSERT INTO crmv2.intf_bus23002_audit
      (intf_ivpn_id,
       provincecode,
       custid,
       ProductNbr,
       custordertype,
       citycode,
       prodcode,
       priceplancode,
       bus_code,
       current_package,
       batch_nbr)
      select crmv2.seq_intf_ivpn_id.nextval,
             '600105',
             a.custid,
             productnbr,
             custordertype,
             citycode,
             cProdCode,
             a.priceplancode,
             '',
             '0',
             V_BATCH_NBR
        from fflinyx.intf_ivpn_XS a
       where not exists (select *
                from crmv2.intf_bus23002_audit
               where productnbr = a.productnbr)
         AND EXP_DATE > SYSDATE;
    commit;

    DELETE from crmv2.intf_bus23002_audit A
     where rowid <> (select min(rowid)
                       from crmv2.intf_bus23002_audit B
                      where A.productnbr = B.productnbr);
    COMMIT;
    --特殊处理
    update crmv2.intf_bus23002_audit
       set productnbr = '6851293'
     where productnbr = '6852293';
    COMMIT;
    --IVPN数据分批次
    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from crmv2.intf_bus23002_audit b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.intf_bus23002_audit a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.intf_bus23002_audit a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.intf_bus23002_audit
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON('BUS23002', --业务功能编码
                        v_use_type1,
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;

    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;

    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
    --更改表名
    UPDATE crmv2.intf_dep_ftp_control
       SET file_name = replace(file_name, 'BUS23002', 'BUS23001')
     where BUS_CODE = 'BUS23002'
       AND BATCH_NBR = V_BATCH_NBR;
    commit;

  exception
    when others then
      --记录所有异常的信息
      --str_errmsg := sqlerrm;
      /*    insert into group_abstract_log
      (abstract_id, log_info, log_date)
      select abstractid, str_errmsg, sysdate from dual;*/
      commit;
  end;

  /*一点收费数据上传集团*/
  procedure PROC_BUS23001 is

    prodid               number(10);
    prodspecid           number(10);
    priceid              number(10);
    priceinsid           number(10);
    i                    number;
    ydjf_flag            number;
    startdate            date;
    cProvinceCode        number(10);
    cCustOrderType       varchar(6);
    cCityCode            varchar(6);
    cProductNbr          VARCHAR2(15);
    cShortNbr            VARCHAR2(20);
    cServID              VARCHAR2(50);
    cAccID               VARCHAR2(50);
    cCustID              VARCHAR2(30);
    cPricePlanCode       VARCHAR2(30);
    cProdCode            VARCHAR2(30);
    cPayPointType        VARCHAR2(30);
    cCnetLimit           VARCHAR2(30);
    cCONBR               VARCHAR2(30);
    cStatusDateTime      DATE;
    cPricePlanStartDate  DATE;
    dd                   varchar(4);
    str_errflag          varchar2(200);
    str_errmsg           varchar2(2000);
    exists_flag          number;
    cysx_flag            number;
    months               varchar2(4);
    v_product_id         crmv2.prod_inst.product_id%type;
    v_prod_inst_id       crmv2.prod_inst.prod_inst_id%type;
    v_prod_offer_inst_id crmv2.prod_offer_inst.prod_offer_inst_id%type;
    v_prod_offer_id      crmv2.prod_offer.prod_offer_id%type;
    V_HAVE_PARAM         INTEGER;
    cChargeState         varchar2(6);
    v_AcctItemID         varchar2(9);
    V_EXCEPITON          VARCHAR(500);
    V_MAX_NUMBER         INTEGER := 500000;
    V_INT_NUM            INTEGER;
    V_CURRENT_PACKAGE    NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM  NUMBER := 0; --分割批次数总数
    V_COUNT              NUMBER := 0; --取数总量
    V_BATCH_NBR          VARCHAR2(100); --批次号
    V_BUS_CODE           VARCHAR2(50) := 'BUS23001'; --业务功能编码
    v_sql                varchar2(2000);
    v_use_type1          VARCHAR2(50);
  begin

    cProvinceCode  := '600105';
    cCustOrderType := '212';
    commit;
    --拆网或者退网数据的开始时间

    select to_char(SYSDATE, 'dd') into dd from dual;
    IF dd = '01' then
      select add_months(last_day(trunc(SYSDATE)) + 1, -2)
        into startdate
        from dual;
    else
      select add_months(last_day(trunc(SYSDATE)), -1) + 1
        into startdate
        from dual;
    end if;

    execute IMMEDIATE 'select use_type  from crmv2.Intf_Dep_Ftp where bus_code=''BUS23001'' and frequency in (' || dd || ')'
      into v_use_type1;

    --批次号生成，格式 BUS_CODEYYYYMMDDHH  例如：BUS2300120150730
    V_BATCH_NBR := CRMV2.PKG_DEP_EXTRACT.FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    --清除表数据，同时清理intf_dep_ftp_control数据
    CRMV2.PKG_DEP_EXTRACT.PROC_INIT_TABLE(V_BUS_CODE);
    --插1条数据到intf_dep_ftp_control
    CRMV2.PKG_DEP_EXTRACT.PROC_DEP_COMMON('BUS23001', --业务功能编码
                                          v_use_type1,
                                          V_BATCH_NBR, --批次号
                                          1, --分割批次号
                                          1); --分割次数总数

    --取一点收费数据
    for rec in (select e.cust_id                 owner_cust_id,
                       d.prod_inst_id,
                       c.status_date,
                       c.status_cd               acct_status_cd,
                       d.area_code,
                       c.prod_inst_acct_id,
                       c.account_id,
                       c.charge_type,
                       c.create_date,
                       c.eff_date,
                       d.product_id,
                       d.acc_nbr,
                       c.proc_serial,
                       c.acct_item_type_group_id,
                       PAYMENT_LIMIT_TYPE,
                       PAYMENT_LIMIT
                  from crmv2.prod_inst_acct c, crmv2.prod_inst d, account e
                 where c.prod_inst_id = d.prod_inst_id
                   and product_id in ('800000000', '800000002')
                   and c.charge_type in
                       ('30080002', '30080003', '30080004', '30080005')
                   and c.account_id = e.account_id
                   and c.group_prod_inst_acct_id is not null
                /*
                12  账务定制关系  公免标识 集团-完全一点收费 30080002  800001808
                13  账务定制关系  公免标识 集团-部分一点收费 30080003  800001808
                14  账务定制关系  公免标识 集团-固定额度一点收  30080004  800001808
                15 账务定制关系  公免标识  集团-指定账目项一点收 30080005  800001808
                */

                union
                select e.cust_id               owner_cust_id,
                       d.prod_inst_id,
                       c.status_date,
                       c.status_cd             acct_status_cd,
                       d.area_code,
                       c.prod_inst_acct_id,
                       c.account_id,
                       c.charge_type,
                       c.rec_update_date       create_date,
                       c.exp_date              eff_date,
                       d.product_id,
                       d.acc_nbr,
                       c.proc_serial,
                       acct_item_type_group_id,
                       PAYMENT_LIMIT_TYPE,
                       PAYMENT_LIMIT
                  from crmv2.prod_inst_acct_his c,
                       crmv2.prod_inst          d,
                       account                  e
                 where c.charge_type in ('30080002', '30080003', '30080004')
                   and product_id in ('800000000', '800000002')
                   and c.update_date > startdate
                   and c.prod_inst_id = d.prod_inst_id
                   and c.update_date =
                       (select max(update_date)
                          from crmv2.prod_inst_acct_his
                         where prod_inst_id = c.prod_inst_id
                           and charge_type in
                               ('30080002', '30080003', '30080004')
                           and status_cd = '1100'
                           and exp_date > startdate)
                   and c.status_cd = '1100'
                   and c.exp_date > startdate
                   and c.account_id = e.account_id
                   and c.group_prod_inst_acct_id is not null) loop

      begin
        if rec.acct_status_cd = '1100' then
          cChargeState := '213';
        ELSE
          cChargeState := '212';
        end if;
        cPayPointType       := rec.charge_type;
        cStatusDateTime     := rec.create_date;
        cPricePlanStartDate := rec.eff_date;
        if cPricePlanStartDate is null then
          cPricePlanStartDate := to_date('2013-01-01', 'yyyy-mm-dd');
        end if;
        select DECODE(to_char(rec.acct_item_type_group_id),
                      '0',
                      '',
                      to_char(rec.acct_item_type_group_id))
          into v_AcctItemID
          from dual;

        IF REC.PAYMENT_LIMIT_TYPE = 11 THEN
          cCnetLimit := REC.PAYMENT_LIMIT;
        else
          cCnetLimit := '';
        END IF;
        begin
          select acc_nbr, area_code
            into cProductNbr, cCityCode --号码，区号
            from crmv2.prod_inst
           where prod_inst_id = rec.prod_inst_id;
        end;
        --集团订单号不取（2015-7-27 注释 by zhw）
        /*      begin
          SELECT CONBR
            INTO cCONBR
            FROM INTF_ONE_ACCT_CHANGE_LOG A
           WHERE ACC_NBR = cProductNbr
             AND STATE_DATE =
                 (SELECT MAX(STATE_DATE)
                    FROM INTF_ONE_ACCT_CHANGE_LOG
                   WHERE ACC_NBR = A.ACC_NBR
                     AND SERVICE_OFFER_ID IN ('212', '213'));
        exception
          when others then
            select b.ext_cust_order_id
              into cCONBR
              from order_item_his a, customer_order_his b
             where order_item_id = rec.proc_serial
               and a.cust_order_id = b.cust_order_id;
        end;*/
        begin
          select ext_account_id
            into cAccID
            from crmv2.account
           where account_id = rec.account_id;
        exception
          when others then
            select ext_account_id
              into cAccID
              from crmv2.account_his a
             where account_id = rec.account_id
               and a.create_date =
                   (select max(create_date)
                      from crmv2.account_his a
                     where account_id = rec.account_id);
        end;
        --prodid
        ydjf_flag := 0;
        cysx_flag := 0;

        if rec.product_id = 800000000 then
          cProdCode := '00101001101000000000';
        else
          cProdCode := '00101005101000000000';
        end if;
        cShortNbr := '123';
        /*      begin
          select pia.attr_value
            into cShortNbr
            from crmv2.prod_inst_rel  aa,
                 crmv2.prod_inst      bb,
                 crmv2.prod_inst_attr pia
           where aa.prod_inst_a_id = rec.prod_inst_id
             and aa.prod_inst_z_id = bb.prod_inst_id
             and bb.product_id = 801166017
             and pia.prod_inst_id = bb.prod_inst_id
             and pia.attr_id = 800000566;
        exception
          when others then
            begin
              select pia.attr_value
                into cShortNbr
                from crmv2.prod_inst_rel_his  aa,
                     crmv2.prod_inst          bb,
                     crmv2.prod_inst_attr_his pia
               where aa.prod_inst_a_id = rec.prod_inst_id
                 and aa.prod_inst_z_id = bb.prod_inst_id
                 and bb.product_id = 801166017
                 and aa.status_cd = '1100'
                 and aa.status_date =
                     (select max(status_date)
                        from crmv2.prod_inst_rel_his
                       where prod_inst_a_id = rec.prod_inst_id
                         and prod_inst_z_id = bb.prod_inst_id
                         and bb.product_id = 801166017
                         and status_cd = '1100')
                 and pia.prod_inst_id = bb.prod_inst_id
                 and pia.attr_id = 800000566
                 and pia.status_cd = '1100'
                 and pia.status_date =
                     (select max(status_date)
                        from crmv2.prod_inst_attr_his
                       where prod_inst_id = bb.prod_inst_id
                         and attr_id = 800000566
                         and status_cd = '1100');
            exception
              when others then
                cShortNbr := '123';
            end;
        end;*/
        str_errflag := 'CustID';
        begin
          select group_cust_seq
            into cCustID
            from crmv2.cust
           where cust_id = rec.owner_cust_id;
        exception
          when no_data_found then
            select group_cust_seq
              into cCustID
              from crmv2.cust_his
             where cust_id = rec.owner_cust_id
               and rownum < 2;
        end;
        if cCustID is null then
          cCustID := '0205000000000000000';
        end if;
        begin
          select attr_value
            into cServID
            from crmv2.prod_inst_attr
           where prod_inst_id = rec.prod_inst_id
             and attr_id = 800000295; --一点计费主产品ID
        exception
          when others then
            begin
              select attr_value
                into cServID
                from crmv2.prod_inst_attr_his
               where prod_inst_id = rec.prod_inst_id
                 and attr_id = 800000295
                 and status_cd = '1100'
                 and status_date =
                     (select max(status_date)
                        from crmv2.prod_inst_attr_his
                       where prod_inst_id = rec.prod_inst_id
                         and attr_id = 800000295
                         and status_cd = '1100');
            exception
              when others then
                select serv_id
                  into cservid
                  from fflingy.fflingy_one_acct_serv_id_tmp
                 where acc_nbr = cProductNbr;
            end;
        end;
        /*      begin
          select b.prod_offer_inst_id, prod_offer_id
            into v_prod_offer_inst_id, v_prod_offer_id
            from crmv2.offer_prod_inst_rel a, crmv2.prod_offer_inst b
           where a.prod_inst_id = rec.prod_inst_id
             and a.prod_offer_inst_id = b.prod_offer_inst_id
             and b.prod_offer_id in
                 (select destination_code
                    from crmv2.intf_code_mapping
                   where source_system = 'GROUP'
                     AND OBJECT_NAME = 'PROD_OFFER_CODE');
        exception
          when others then
            str_errmsg := sqlerrm;
            select b.prod_offer_inst_id, prod_offer_id
              into v_prod_offer_inst_id, v_prod_offer_id
              from crmv2.offer_prod_inst_rel_his a,
                   crmv2.prod_offer_inst_his     b
             where a.prod_inst_id = rec.prod_inst_id
               and a.prod_offer_inst_id = b.prod_offer_inst_id
               and a.status_cd = '1100'
               and b.prod_offer_id in
                   (select destination_code
                      from crmv2.intf_code_mapping
                     where source_system = 'GROUP'
                       AND OBJECT_NAME = 'PROD_OFFER_CODE')
               and b.status_date =
                   (select max(status_date)
                      from crmv2.prod_offer_inst_his
                     where prod_offer_inst_id = a.prod_offer_inst_id
                       and status_cd = '1100'
                       and prod_offer_id in
                           (select destination_code
                              from crmv2.intf_code_mapping
                             where source_system = 'GROUP'
                               AND OBJECT_NAME = 'PROD_OFFER_CODE'));
        end;
        Select Count(1)
          INTO V_HAVE_PARAM
          From CRMV2.INTF_CODE_MAPPING A, CRMV2.INTF_CODE_MAPPING B
         where A.DESTINATION_CODE = V_PROD_OFFER_ID
           AND A.source_system = 'GROUP'
           AND A.OBJECT_TYPE = 'PROD_OFFER_CODE'
           AND A.SOURCE_CODE = B.SOURCE_CODE
           AND B.SOURCE_SYSTEM = 'GROUP'
           AND B.OBJECT_TYPE = 'PROD_OFFER_ATTR';
        if v_have_param > 0 then
          BEGIN
            select E.SOURCE_CODE
              INTO cPricePlanCode
              from CRMV2.INTF_CODE_MAPPING    A,
                   CRMV2.INTF_CODE_MAPPING    B,
                   CRMV2.PROD_OFFER_INST_ATTR C,
                   CRMV2.ATTR_SPEC            D,
                   CRMV2.INTF_CODE_MAPPING    E,
                   CRMV2.ATTR_VALUE           F
             WHERE A.DESTINATION_CODE = v_prod_offer_id
               AND A.source_system = 'GROUP'
               AND A.OBJECT_NAME = 'PROD_OFFER_CODE'
               AND A.SOURCE_CODE = B.SOURCE_CODE
               AND B.SOURCE_SYSTEM = 'GROUP'
               AND B.OBJECT_NAME = 'PROD_OFFER_ATTR'
               AND B.Destination_Code = D.EXT_ATTR_NBR
               AND D.ATTR_ID = C.ATTR_ID
               AND C.PROD_OFFER_INST_ID = v_prod_offer_inst_id
               AND C.ATTR_VALUE = F.ATTR_VALUE
               AND C.ATTR_VALUE_ID = F.ATTR_VALUE_ID
               and f.attr_id = d.attr_id
               AND E.SOURCE_SYSTEM = 'GROUP'
               AND E.OBJECT_NAME = 'PROD_OFFER_ATTR_VALUE'
               AND E.source_code = a.source_code
               and c.attr_value_id = e.destination_code;
          EXCEPTION
            WHEN OTHERS THEN
              BEGIN
                select E.SOURCE_CODE
                  INTO cPricePlanCode
                  from CRMV2.INTF_CODE_MAPPING        A,
                       CRMV2.INTF_CODE_MAPPING        B,
                       CRMV2.PROD_OFFER_INST_ATTR_HIS C,
                       CRMV2.ATTR_SPEC                D,
                       CRMV2.INTF_CODE_MAPPING        E,
                       CRMV2.ATTR_VALUE               F
                 WHERE A.DESTINATION_CODE = V_PROD_OFFER_ID
                   AND A.source_system = 'GROUP'
                   AND A.OBJECT_NAME = 'PROD_OFFER_CODE'
                   AND A.SOURCE_CODE = B.SOURCE_CODE
                   AND B.SOURCE_SYSTEM = 'GROUP'
                   AND B.OBJECT_NAME = 'PROD_OFFER_ATTR'
                   AND B.Destination_Code = D.EXT_ATTR_NBR
                   AND C.STATUS_CD = '1100'
                   AND C.CREATE_DATE =
                       (SELECT MAX(CREATE_DATE)
                          FROM CRMV2.PROD_OFFER_INST_ATTR_HIS
                         WHERE PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
                           AND ATTR_ID = C.ATTR_ID)
                   AND D.ATTR_ID = C.ATTR_ID
                   AND C.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
                   AND C.ATTR_VALUE = F.ATTR_VALUE
                   AND C.ATTR_VALUE_ID = F.ATTR_VALUE_ID
                   and f.attr_id = d.attr_id
                   AND E.SOURCE_SYSTEM = 'GROUP'
                   AND E.OBJECT_NAME = 'PROD_OFFER_ATTR_VALUE'
                   AND E.source_code = a.source_code
                   and c.attr_value_id = e.destination_code;
              END;
          END;
        else
          select source_code
            into cPricePlanCode
            from crmv2.intf_code_mapping
           where object_name = 'PROD_OFFER_CODE'
             and source_system = 'GROUP'
             and destination_code = v_prod_offer_id;
        end if;*/

        insert into crmv2.intf_bus23001_audit
          (intf_one_acct_id,
           ProvinceCode, --省份
           CONBR, --业务流水
           custOrderType, --用户状态
           CityCode, --区号
           ShortNbr, --短号（写死123）
           ProductNbr, --号码
           PricePlanCode, --取业务订单里集团下发的集团套餐编码（写死123）
           ServID, --一点计费主产品ID
           AccID, --取一点收费服务订单里集团下发的帐务ID
           CustID, --取一点收费服务订单里集团下发的客户ID
           ProdCode, --产品编码 如果是800000000，则00101001101000000000，否则00101005101000000000
           PayPointType, --收费方式
           CnetLimit, --月限额(月限额可为空，固定额度一点收费时必填)
           StatusDateTime, --一点收费竣工时间
           PricePlanStartDate, --一点收费生效时间
           chargestate, --一点收费状态
           acctitemid,
           current_package,
           batch_nbr)
        values
          (crmv2.seq_intf_one_acct_id.nextval,
           cProvinceCode,
           '',
           cCustOrderType,
           cCityCode,
           cShortNbr,
           cProductNbr,
           '123',
           cServID,
           cAccID,
           cCustID,
           cProdCode,
           cPayPointType,
           cCnetLimit,
           to_char(cStatusDateTime, 'yyyy-mm-dd'),
           to_char(cPricePlanStartDate, 'yyyy-mm-dd'),
           cChargeState,
           v_AcctItemID,
           '0',
           V_BATCH_NBR);
        commit;

        /*      exception
        when others then
          --记录所有异常的信息
          str_errmsg := sqlerrm;
          select str_errflag || ' ==> mdse_idb=' ||
                 to_char(mdserela.mdse_idb) || ',' || 'mdse_ida=' ||
                 to_char(mdserela.mdse_ida) || ',' || 'prod_ida=' ||
                 to_char(rec.prod_id) || ':' || str_errmsg
            into str_errmsg
            from dual;
          insert into group_abstract_log
            (abstract_id, log_info, log_date)
            select abstractid, str_errmsg, SYSDATE+1 from dual;
          commit;*/

      end;

    end loop;

    update crmv2.intf_bus23001_audit
       set custid = '0205000000000000000'
     where accid = '9992010694';
    COMMIT;
    --一点收费数据分批
    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from crmv2.intf_bus23001_audit b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.intf_bus23001_audit a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.intf_bus23001_audit a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.intf_bus23001_audit
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop
        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON('BUS23001', --业务功能编码
                        v_use_type1,
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;

    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;

    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);

  exception
    when others then
      --记录所有异常的信息
      str_errmsg := sqlerrm;
      /*    insert into group_abstract_log
      (abstract_id, log_info, log_date)
      select abstractid, str_errmsg, SYSDATE+1 from dual;*/
      commit;
  end;

  /*省受理集团卡同步集团*/
  procedure PROC_BUS80009 is
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS80009'; --业务功能编码
  begin
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    begin
      execute immediate 'DROP TABLE linyx_order_proc_attr0 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE linyx_order_proc_attr1 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE linyx_order_proc_attr2 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE linyx_order_proc_attr3 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE linyx_order_proc_attr4 PURGE';
    exception
      when others then
        null;
    end;
    begin
      execute immediate 'DROP TABLE linyx_order_proc_attr5 PURGE';
    exception
      when others then
        null;
    end;

    SELECT record_num
      INTO V_MAX_NUMBER
      FROM crmv2.Intf_Dep_Ftp
     where bus_code = 'BUS80009';

    execute immediate 'create table linyx_order_proc_attr0 as
    select *
      from order_item_proc_attr_his
     where update_date between trunc(sysdate - 1) and trunc(sysdate)
       and class_id = 4
       and obj_attr = ''Z''
       and status = ''1000''';
    execute immediate 'insert into linyx_order_proc_attr0
    select *
      from order_item_proc_attr_his A
     where update_date between trunc(sysdate - 1) and trunc(sysdate)
       and A.class_id = ''144''
       AND a.obj_attr = ''prodResInstRels''
       and status = ''1000''';
    commit;

    execute immediate 'delete
     from linyx_order_proc_attr0 a
     where exists (select *
          from customer_order_his b, order_item_his c
         where a.order_item_id = c.order_item_id
           and c.cust_order_id = b.cust_order_id
           and b.channel_id in (268, 280))';
    commit;

    --execute immediate 'update linyx_order_proc_attr0 set new_value=old_value where operate=''12''';

    execute immediate 'create table linyx_order_proc_attr1 as
    select a.order_item_id,
           a.region_cd,
           b.mkt_reso_id,
           b.mkt_reso_spec_id,
           nvl(b.iccs, b.mkt_reso_key) iccs,
           b.mkt_reso_key iccid,
           a.update_date,
           ''1113'' status_cd
      from linyx_order_proc_attr0 a, crmv1.mkt_resource b
     where a.new_value = b.mkt_reso_key
       and a.operate = ''11''';

    execute immediate 'insert into linyx_order_proc_attr1
    select a.order_item_id,
           a.region_cd,
           b.mkt_reso_id,
           b.mkt_reso_spec_id,
           nvl(b.iccs, b.mkt_reso_key) iccs,
           b.mkt_reso_key iccid,
           a.update_date,
           ''1106'' status_cd
      from linyx_order_proc_attr0 a, crmv1.mkt_resource b
     where a.old_value = b.mkt_reso_key
       and a.operate = ''11''';
    commit;
    execute immediate 'insert into linyx_order_proc_attr1
      select a.order_item_id,
             a.region_cd,
             d.mkt_reso_id,
             d.mkt_reso_spec_id,
             nvl(d.iccs, d.mkt_reso_key) iccs,
             mkt_reso_key iccid,
             a.update_date,
             ''1113''
              from linyx_order_proc_attr0 a,
             prod_res_inst_rel      b,
             crmv1.mkt_occupy       c,
             crmv1.mkt_resource     d
             where a.new_value = b.prod_res_inst_rel_id
               and b.mkt_res_inst_id = c.mkt_occupy_id
               and c.mkt_reso_id = d.mkt_reso_id
               and a.operate = ''10''';
    commit;
    execute immediate 'insert into linyx_order_proc_attr1
      select a.order_item_id,
             a.region_cd,
             d.mkt_reso_id,
             d.mkt_reso_spec_id,
             nvl(d.iccs, d.mkt_reso_key) iccs,
             mkt_reso_key iccid,
             a.update_date,
             ''1106''
              from linyx_order_proc_attr0 a,
             prod_res_inst_rel_his      b,
             crmv1.mkt_occupy       c,
             crmv1.mkt_resource     d
             where a.old_value = b.prod_res_inst_rel_id
               and b.mkt_res_inst_id = c.mkt_occupy_id
               and c.mkt_reso_id = d.mkt_reso_id
               and a.operate = ''12''';
    commit;
    execute immediate 'delete from linyx_order_proc_attr1 where length(iccid)<19';
    execute immediate 'delete from linyx_order_proc_attr1 a
     where update_date <> (select max(update_date)
                             from linyx_order_proc_attr1 b
                            where a.iccid = b.iccid)';
    execute immediate 'delete from linyx_order_proc_attr1 a
     where rowid <> (select max(rowid)
                             from linyx_order_proc_attr1 b
                            where a.iccid = b.iccid)';
    commit;
    execute immediate 'create index idx_linyx_order_proc_attr1 on linyx_order_proc_attr1(mkt_reso_id)';

    execute immediate 'create table linyx_order_proc_attr2 as
       select a.*, b.param1
      from linyx_order_proc_attr1 a, crmv1.mkt_reso_fea b
     where a.mkt_reso_id = b.mkt_reso_id
       and b.fea_spec_id = ''620124501'''; ---集团制卡
    execute immediate 'delete from  linyx_order_proc_attr2 where param1=''0''';
    commit; ------正式开始时需要放开

    execute immediate 'create table linyx_order_proc_attr3 as
    SELECT A.*, B.PARAM1 IMSI
      FROM linyx_order_proc_attr2 A,
           (select * from CRMV1.MKT_RESO_FEA where FEA_SPEC_ID = 620029411) B
     WHERE A.MKT_RESO_ID = B.MKT_RESO_ID';

    execute immediate 'create table linyx_order_proc_attr4 as
    SELECT A.*, B.PARAM1 IMSI_G
      FROM linyx_order_proc_attr3 A,
           (select * from CRMV1.MKT_RESO_FEA where FEA_SPEC_ID = 620124476) B
     WHERE A.MKT_RESO_ID = B.MKT_RESO_ID(+)';

    execute immediate 'create table linyx_order_proc_attr5 as
    SELECT A.*, B.PARAM1 IMSI_LTE
      FROM linyx_order_proc_attr4 A,
           (select * from CRMV1.MKT_RESO_FEA where FEA_SPEC_ID = 620124477) B
     WHERE A.MKT_RESO_ID = B.MKT_RESO_ID';

    execute immediate 'INSERT INTO INTF_BUS80009_AUDIT
    SELECT ''A'',
           c.REGION_CODE,
           (select zbgs
              from crmv1.zb
             where zbzs = a.mkt_reso_spec_id
               and zb.zbfl = ''EZF_USIM''),
           ICCS,
           ICCID,
           IMSI,
           IMSI_G,
           IMSI_LTE,
           STATUS_CD,
           TO_CHAR(UPDATE_DATE, ''YYYYMMDDHH24MISS''),''' ||
                      V_BUS_CODE || ''',
           0,
           ''' || V_BATCH_NBR || '''
      from linyx_order_proc_attr5 A, crmv2.common_region_jt B, crmv2.common_region_jt c
     where A.REGION_CD = B.COMMON_REGION_ID and b.up_region_id=c.common_region_id';

    PROC_CURRENT_PACKAGE_AVG('INTF_BUS80009_AUDIT',
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  end PROC_BUS80009;

  procedure PROC_BUS80010 is
    V_ACTION_TYPE VARCHAR2(2);
    --V_CNT           number(3);
    V_CNT1                  number(3);
    V_CNT2                  number(3);
    v_OFFER_NBR             varchar2(20);
    v_prod_offer_id         varchar2(20);
    v_prod_offer_name       varchar2(200);
    v_cust_so_number        varchar2(20);
    v_staff_code            varchar2(20);
    v_staff_id              varchar2(20);
    v_update_date           varchar2(16);
    v_channel_nbr           varchar2(20);
    v_channel_id            varchar2(20);
    v_MKT_RES_CD            varchar2(10);
    v_TERM_MODEL_CD         varchar2(25);
    v_model_id              varchar2(25);
    v_PHONE_NBR             varchar2(15);
    v_SALES_CODE            varchar2(15);
    V_BUY_PRICE_ID          varchar2(15);
    v_OLD_MKT_RES_INST_CODE varchar2(30);
    v_prod_inst_id          varchar2(20);
    V_ext_cust_order_id     varchar2(20);
    V_COMMON_REGION_ID      varchar2(8);
    v_STATUS_CD             varchar2(4);
    v_sql                   varchar2(200);
    V_EXCEPITON             VARCHAR(500);
    V_MAX_NUMBER            INTEGER := 100000;
    V_INT_NUM               INTEGER;
    V_CURRENT_PACKAGE       NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM     NUMBER := 0; --分割批次数总数
    -- V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR VARCHAR2(100); --批次号
    V_BUS_CODE  VARCHAR2(50) := 'BUS80010'; --业务功能编码
    cursor aa IS
      SELECT  * FROM fflinyx.linyx_80010_code;
  BEGIN
    DELETE FROM fflinyx.linyx_80010_code;
     INSERT INTO fflinyx.linyx_80010_code
         SELECT  distinct b.MODI_TIME MODI_TIME_occupy,a.*, to_char(SYSdate,'yyyy-mm-dd') bak_date
        from crmv1.mkt_resource a, crmv1.mkt_occupy b
       where a.state in ('70B', '70Z')
         and a.mkt_reso_spec_type in (63, 65, 67, 610007585)
         and a.mkt_reso_id = b.mkt_reso_id
         and trunc(b.modi_time) = trunc(sysdate - 1) ;

         INSERT INTO fflinyx.linyx_80010_code_all
         SELECT * FROM fflinyx.linyx_80010_code;
         COMMIT;
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);

    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    FOR REC IN AA LOOP
      begin
        V_ACTION_TYPE           := '';
        v_PHONE_NBR             := '';
        V_BUY_PRICE_ID          := '';
        v_OLD_MKT_RES_INST_CODE := '';
        v_OFFER_NBR             := '';
        v_prod_offer_name       := '';

        IF REC.STATE = '70B' THEN
          begin
            V_ACTION_TYPE := '10';
            v_STATUS_CD   := '1203';

            --  DBMS_OUTPUT.put_line('01');
            select c.order_id,
                   c.order_number,
                   c.staff_id,
                   to_char(c.modi_date, 'yyyymmddhh24miss')
              into V_ext_cust_order_id,
                   v_cust_so_number,
                   v_staff_id,
                   v_update_date
              from crmv1.mkt_reso_ord_rela   a,
                   crmv1.mkt_reso_order_item b,
                   crmv1.mkt_reso_order      c
             where a.mkt_reso_id = REC.MKT_RESO_ID
               and a.order_item_id = b.order_item_id
               and b.order_id = c.order_id;
            ---DBMS_OUTPUT.put_line('02');
            select b.staff_code,
                   d.channel_nbr,
                   (SELECT T2.REGION_CODE
                      FROM CRMV2.COMMON_REGION_JT T1,
                           CRMV2.COMMON_REGION_JT t2
                     where T1.COMMON_REGION_ID = d.COMMON_REGION_ID
                       and T1.UP_REGION_ID = T2.COMMON_REGION_ID),
                   a.staff_nbr
              into v_staff_code,
                   v_channel_nbr,
                   V_COMMON_REGION_ID,
                   v_SALES_CODE
              from staff a, crmv2.SYSTEM_USER b, channel d
             where a.staff_code = v_staff_id
               and a.staff_id = b.staff_id
               and a.org_id = d.org_id;
          exception
            when others then
              V_ACTION_TYPE := '';
          end;
        ELSE
          begin

            SELECT order_no, buy_prod_id, BUY_PRICE_ID
              into v_cust_so_number, v_prod_inst_id, V_BUY_PRICE_ID
              from CRMV1.MKT_OCCUPY
             where MKT_RESO_ID = REC.MKT_RESO_ID
               and modi_time in
                   (SELECT max(modi_time)
                      from CRMV1.MKT_OCCUPY
                     where MKT_RESO_ID = REC.MKT_RESO_ID) /*
                                                   and trunc(modi_time) = trunc(sysdate - 1)*/
            ;
            -- DBMS_OUTPUT.put_line('03');

            select C.OFFER_NBR, c.prod_offer_name, c.prod_offer_id
              into v_OFFER_NBR, v_prod_offer_name, v_prod_offer_id
              from crmv2.prod_offer_inst b, crmv2.prod_offer c
             where b.prod_offer_inst_id = V_BUY_PRICE_ID
               and b.prod_offer_id = c.prod_offer_id;
            select count(*)
              into v_cnt1
              from crmv2.Common_Conf_Obj    a,
                   crmv2.Common_Conf        b,
                   crmv2.prod_offer/*_res_rel*/ c
             where a.conf_Id = b.conf_Id
               and a.obj_id = c.prod_offer_id
               and b.conf_Type in
                   ('PLANA_PRICEPLAN_ZD', 'PLANA_PRICEPLAN_HF')
               and b.class_Id = 3
               and a.status_Cd = '1000'
               /*AND C.MKT_RES_ID = rec.mkt_reso_spec_id*/
               and c.prod_offer_id = v_prod_offer_id;

            select count(*)
              into v_cnt2
              from crmv2.Common_Conf_Obj a,
                   crmv2.Common_Conf     b,
                   crmv2.attr_value      c
             where a.conf_Id = b.conf_Id
               and a.obj_id = c.attr_value
               and b.conf_Type in ('PLANA_PRICEPLAN_ZD')
               and b.class_Id = 3
               and a.status_Cd = '1000'
               AND C.attr_value = v_prod_offer_id
               and c.attr_id = 950024347;

            if v_cnt1 > 0 or v_cnt2 > 0 then
              V_ACTION_TYPE := '11';
              v_STATUS_CD   := '1204';
            else
              V_ACTION_TYPE := '10';
              v_STATUS_CD   := '1203';
            end if;

            -----过滤集团订单
            begin
              select c.staff_code,
                     d.staff_nbr,
                     to_char(A.update_date, 'yyyymmddhh24miss'),
                     B.channel_nbr,
                     /* decode(LENGTH(ext_cust_order_id),
                     '12',
                     A.ext_cust_order_id,
                     A.cust_order_id),*/
                     a.cust_order_id,
                     (SELECT T2.REGION_CODE
                        FROM CRMV2.COMMON_REGION_JT T1,
                             CRMV2.COMMON_REGION_JT t2
                       where T1.COMMON_REGION_ID = f.COMMON_REGION_ID
                         and T1.UP_REGION_ID = T2.COMMON_REGION_ID)
                into v_staff_code,
                     v_SALES_CODE,
                     v_update_date,
                     v_channel_nbr,
                     V_ext_cust_order_id,
                     V_COMMON_REGION_ID
                from crmv2.customer_order_his a,
                     channel                  b,
                     crmv2.system_user        c,
                     staff                    d,
                     CRMV2.ORGANIZATION       F
               where cust_so_number = v_cust_so_number
                 and a.channel_id = b.channel_id
                 and a.staff_id = C.staff_id
                 and a.staff_id = d.staff_id
                 AND D.ORG_ID = F.ORG_ID /*
                                                           and a.channel_id not in ('268', '280')*/
              ;
            exception
              when others then
                V_ext_cust_order_id := '';
            end;

            select acc_nbr
              into v_PHONE_NBR
              from prod_inst
             where prod_inst_id = v_prod_inst_id;
            --DBMS_OUTPUT.put_line('0');
            begin
              SELECT B.MKT_RESO_KEY
                INTO v_OLD_MKT_RES_INST_CODE
                from CRMV1.MKT_OCCUPY_HIS A, CRMV1.MKT_RESOURCE B
               where order_no = v_cust_so_number
                 and buy_prod_id = V_BUY_PRICE_ID
                 AND occupy_flag in (5, 6, 7)
                 AND A.MKT_RESO_ID = B.MKT_RESO_ID;

              V_ACTION_TYPE := '12';
            exception
              when others then
                v_OLD_MKT_RES_INST_CODE := '';
            end;
            -- DBMS_OUTPUT.put_line('1');
          exception
            when others then
              V_ACTION_TYPE := '';
          end;
        end if;
        --DBMS_OUTPUT.put_line('V_ACTION_TYPE=' || V_ACTION_TYPE);
        select distinct d.source_code, a.jt_code, a.model_id
          into v_mkt_res_cd, v_TERM_MODEL_CD, v_model_id
          from crmv2.mkt_model         a,
               crmv2.mkt_res_mod_rela  b,
               crmv2.mkt_resource      c,
               crmv2.intf_dep_code_map d
         where a.model_id = b.model_id
           and b.mkt_res_id = c.mkt_res_id
           and a.jt_code = d.target_code
           and c.mkt_res_id = rec.mkt_reso_spec_id
           and rownum = 1;
        ----非4G终端都当初裸机销售
        select count(*)
          into v_cnt1
          from crmv2.mkt_model_attr a
         where a.model_id = v_model_id
           and a.attr_id = 950022240
           and attr_value <> '2';
        if v_cnt1 > 0 then
          V_ACTION_TYPE := '10';
        END IF;
        ---如果是店中商则取上级销售点
        begin
          select channel_id
            into v_channel_id
            from crmv2.channel
           where channel_nbr = v_channel_nbr
             and channel_class = '20';
          select a.channel_nbr
            into v_channel_nbr
            from channel a, crmv2.channel_rela b
           where a.channel_id = b.channel_id
             and b.cha_channel_id = v_channel_id;
        exception
          when others then
            null;
        end;
        if V_ACTION_TYPE is not null and V_ext_cust_order_id is not null then
          INSERT INTO INTF_BUS80010_AUDIT
          VALUES
            (V_ACTION_TYPE,
             V_COMMON_REGION_ID,
             v_staff_code,
             V_MKT_RES_CD,
             v_TERM_MODEL_CD,
             REC.MKT_RESO_KEY,
             v_update_date,
             v_OFFER_NBR,
             V_PROD_OFFER_NAME,
             v_STATUS_CD,
             v_CHANNEL_NBR,
             V_ext_cust_order_id,
             v_OLD_MKT_RES_INST_CODE,
             v_PHONE_NBR,
             v_SALES_CODE,
             REC.STORAGE_ID,
             V_BUS_CODE,
             0,
             V_BATCH_NBR);
          COMMIT;
          -- DBMS_OUTPUT.put_line('2');

        end if;

      exception
        when others then
          v_sql := substr(sqlerrm, 1, 200);
          insert into fflinyx.uim_upload_log
          values
            (rec.mkt_reso_key, v_sql, sysdate);
          commit;
      end;
    END LOOP;
    update INTF_BUS80010_AUDIT
       set offer_nbr = '', prod_offer_name = ''
     where action_TYPE = '10';
    commit;
    ---将市场部提供的数据当作裸机销售导入。数据由林嵩导入
    BEGIN
    INSERT INTO INTF_BUS80010_AUDIT
      SELECT action_type,
             common_region_id,
             staff_code,
             mkt_res_cd,
             TERM_MODEL_CD,
             mkt_res_inst_code,
             accept_time,
             offer_nbr,
             prod_offer_name,
             status_cd,
             channel_nbr,
             cust_order_id,
             old_mkt_res_inst_code,
             phone_nbr,
             sales_code,
             mkt_res_store_id,
             V_BUS_CODE,
             0,
             V_BATCH_NBR 　FROM FFLINYX.INTF_BUS80010_IMP A where DEAL_STATE='70A'
             AND TERM_MODEL_CD IS NOT NULL AND mkt_res_cd IS NOT NULL;
    COMMIT;
    UPDATE FFLINYX.INTF_BUS80010_IMP  SET  DEAL_STATE='70C' WHERE DEAL_STATE='70A' AND TERM_MODEL_CD IS NOT NULL  AND mkt_res_cd IS NOT NULL;
    COMMIT;
    exception when others then null;
    END;

    ----备份
    INSERT INTO FFLINYX.INTF_BUS80010_AUDIT_BAK
      SELECT A.*,
             DECODE(CHANNEL_NBR,
                    '10000002999',
                    '集团',
                    '100000208',
                    '集团',
                    '本地'),
             to_char(sysdate, 'yyyy/mm/dd')
        FROM CRMV2.INTF_BUS80010_AUDIT A;
    COMMIT;
    DELETE FROM INTF_BUS80010_AUDIT
     where CHANNEL_NBR IN ('10000002999', '100000208');
    COMMIT;

    PROC_CURRENT_PACKAGE_AVG('INTF_BUS80010_AUDIT',
                             V_BATCH_NBR,
                             V_MAX_NUMBER,
                             V_TOTAL_PACKAGE_NUM);

    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  end;
  /*
  * 上传号码及属性给翼支付 20160107 add by xiely
  */
  PROCEDURE PROC_BUS90001(IN_ATTR_NAME IN VARCHAR2) IS
    V_EXCEPITON         VARCHAR(500);
    V_MAX_NUMBER        INTEGER := 100000;
    V_INT_NUM           INTEGER;
    V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
    V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
    V_COUNT             NUMBER := 0; --取数总量
    V_BATCH_NBR         VARCHAR2(100); --批次号
    V_BUS_CODE          VARCHAR2(50) := 'BUS90001'; --业务功能编码
    V_SQL               VARCHAR2(1000);
  BEGIN
    --获取批次号
    V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
    V_SQL       := 'TRUNCATE TABLE INTF_' || V_BUS_CODE || '_AUDIT';
    EXECUTE IMMEDIATE V_SQL;
    COMMIT;
    PROC_INIT_TABLE(V_BUS_CODE);
    --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
    PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                    '',
                    V_BATCH_NBR, --批次号
                    1, --分割批次号
                    1); --分割次数总数
    BEGIN
      --取数插中间表逻辑
      for rec in (SELECT P.ACC_NBR ACC_NBR, A.ATTR_NAME ATTR_NAME
                    FROM CRMV2.PROD_INST_ATTR PA,
                         CRMV2.PROD_INST      P,
                         CRMV2.ATTR_SPEC      A
                   WHERE P.PROD_INST_ID = PA.PROD_INST_ID
                     AND A.ATTR_ID = PA.ATTR_ID
                     AND A.ATTR_NAME = IN_ATTR_NAME) LOOP

        INSERT INTO INTF_BUS90001_AUDIT
          (ACC_NBR, ATTR_NAME, BUS_CODE, CURRENT_PACKAGE, BATCH_NBR)
        VALUES
          (rec.ACC_NBR, rec.ATTR_NAME, V_BUS_CODE, 0, V_BATCH_NBR);
      END LOOP;
      commit;
    END;
    ---排重
    delete from crmv2.INTF_BUS90001_AUDIT a
     where rowid <> (select max(rowid)
                       from crmv2.INTF_BUS90001_AUDIT b
                      where a.acc_nbr = b.acc_nbr
                        and nvl(a.acc_nbr, 1) = nvl(b.acc_nbr, 1));
    commit;

    loop
      select nvl(max(CURRENT_PACKAGE), -1) + 1
        into V_CURRENT_PACKAGE
        from INTF_BUS90001_AUDIT b
       where BATCH_NBR = V_BATCH_NBR;
      if V_CURRENT_PACKAGE = 0 then
        V_TOTAL_PACKAGE_NUM := 0;
      end if;
      exit when V_CURRENT_PACKAGE = 0;

      select count(*)
        into V_COUNT
        from crmv2.INTF_BUS90001_AUDIT a
       where CURRENT_PACKAGE = 0;

      if V_COUNT > V_MAX_NUMBER then
        update crmv2.INTF_BUS90001_AUDIT a
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0
           and rownum < (V_MAX_NUMBER + 1);
      else
        update crmv2.INTF_BUS90001_AUDIT
           set CURRENT_PACKAGE = V_CURRENT_PACKAGE
         where CURRENT_PACKAGE = 0;
      end if;

      commit;
      V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
      exit when V_COUNT <= V_MAX_NUMBER;

    end loop;

    COMMIT;
    V_INT_NUM := 2;
    if V_TOTAL_PACKAGE_NUM > 1 then
      loop

        --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
        PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                        '',
                        V_BATCH_NBR, --批次号
                        V_INT_NUM, --分割批次号
                        V_TOTAL_PACKAGE_NUM); --分割次数总数
        V_INT_NUM := V_INT_NUM + 1;
        EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
      end loop;
    end if;
    update crmv2.intf_dep_ftp_control
       set total_package_num = V_TOTAL_PACKAGE_NUM
     where batch_nbr = V_BATCH_NBR;
    commit;
    COMMIT;
    --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
    PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;
END PKG_DEP_EXTRACT_111;
/
