CREATE package           PKG_PROC_AUTO_H is
  -- Author  : LITTLEHUI
  -- Created : 2012/6/21 17:34:57
  -- Purpose : auto stop offerinst

  --提供Job自动执行所有自动处理过程
  PROCEDURE prodAutoProc; --执行可选包到期
  PROCEDURE prodAutoProc2; --执行停保复机和功能类销售品到期
  PROCEDURE prodAutoProc3; --执行接入类到期和改号通知音
  --停机保号
  PROCEDURE stopRemainNumber(str_msg out varchar);
  --可选包到期 只拆除可选包
  PROCEDURE optionalOfferProcOnlyOffer(i_mode  in number,
                                       i_int   in number,
                                       str_msg out varchar);
  PROCEDURE optionalOfferProcOnlyOffer2(str_msg out varchar);
  --可选包到期 有关联产品处理
  PROCEDURE optionalOfferProcForProd(str_msg out varchar);
  --可选群组类到期 拆除可选群组
  PROCEDURE optionalGroupOfferProc(str_msg out varchar);
  --可选包的参数到期 有关联产品处理
  PROCEDURE optionalOfferAttrProcForProd(str_msg out varchar);
  --处理可选包到期队列
  function optionalAutoProcQueue(v_prod_offer_id      in number,
                                 v_prod_offer_inst_id in number,
                                 v_base_offer_inst_id in number,
                                 v_exp_proc_method    in varchar2,
                                 v_rela_prod_inst_id  in number,
                                 v_area_id            in number,
                                 v_region_cd          in number,
                                 v_eff_date           in date,
                                 v_exp_date           in date,
                                 v_direct_proc_flag   in number)
    return number;
  --接入类基础销售品
  PROCEDURE procAccBaseOffer(str_msg out varchar);
  --程控到期
  PROCEDURE procFuncBaseOffer(str_msg out varchar);
  --移机
  PROCEDURE changeNumbers(str_msg out varchar);
  --到期可选包队列过程处理
  PROCEDURE procOptionOfferNotOrder(i_queue_id      IN o_auto_proc_queue.queue_id%TYPE,
                                    o_result        OUT VARCHAR2,
                                    o_msg           OUT VARCHAR2,
                                    o_cust_order_id OUT customer_order.cust_order_id%TYPE);
  --到期可选群组类队列过程处理
  PROCEDURE procOptionGroupOfferNotOrder(i_queue_id      IN o_auto_proc_queue.queue_id%TYPE,
                                         o_result        OUT VARCHAR2,
                                         o_msg           OUT VARCHAR2,
                                         o_cust_order_id OUT customer_order.cust_order_id%TYPE);

  PROCEDURE InsertIntoIntfInsBillingUpdate(tableName  in varchar2,
                                           columnName in varchar2,
                                           keyId      in number,
                                           topic      in varchar2,
                                           areaId     in number);
  function InsertIntoOAutoProcQueue(SUPER_QUEUE_ID in number,
                                    SRC_INST_ID    in number,
                                    SRC_TYPE       in varchar2,
                                    SRC_ACTION     in varchar2,
                                    PROC_TYPE      in varchar2,
                                    STATUS_CD      in varchar2,
                                    QUEUE_DESC     in varchar2) return number;

  function InsertIntoOAutoProcQueueByArea(SUPER_QUEUE_ID in number,
                                          SRC_INST_ID    in number,
                                          SRC_TYPE       in varchar2,
                                          SRC_ACTION     in varchar2,
                                          PROC_TYPE      in varchar2,
                                          STATUS_CD      in varchar2,
                                          QUEUE_DESC     in varchar2,
                                          AREA_ID        in number,
                                          REGION_CD      in number)
    return number;

  function InsertIntoProcQueueAttr(QUEUE_ID     in number,
                                   OBJ_SPEC     in number,
                                   OBJ_TYPE     in varchar2,
                                   OBJ_ID       in number,
                                   PROC_TYPE    in varchar2,
                                   OBJ_VALUE    in varchar2,
                                   VALID_BEAN   in varchar2,
                                   VALID_PARAM1 in varchar2,
                                   VALID_PARAM2 in varchar2,
                                   REMARK       in varchar2) return number;
  function IsHasOfferInQueue(instId in number, srcType in varchar)
    return number;
  function IsHasSameInstInQueue(instId    in number,
                                srcType   in varchar,
                                queueDesc in varchar) return number;
  function saveLogInfo(l_logId in number, str_message in varchar)
    return number;
  function IsHasAttrInQueue(QUEUE_ID     in number,
                            OBJ_SPEC     in number,
                            OBJ_TYPE     in varchar2,
                            OBJ_ID       in number,
                            PROC_TYPE    in varchar2,
                            OBJ_VALUE    in varchar2,
                            VALID_BEAN   in varchar2,
                            VALID_PARAM2 in varchar2) return number;
  function IsYKT(i_prodInstId in number) return number; --为0表示不是预开通，>0表示预开通
  function IsHasQXSB(prodInstId in number) return number;
  --是否为可以直接档案处理的可选包,返回1为可以直接处理,前提exp_proc_method必须是2
  function IsCanDirectProc(i_prodOfferId in number) return number;
  --是否有产品实例队列'ProdInst'
  function IsHasProdInstProc(i_queueId in number) return number;
end PKG_PROC_AUTO_H;
/
