CREATE PACKAGE BODY           PKG_CRM2_SYNC_NEW IS
--生产差异数据
  PROCEDURE P_CREATESYNCDATA(I_SYNCID       IN NUMBER, --同步表ID
                                  I_ID           IN NUMBER, --销售品规格ID，产品规格ID
                                  I_AREAID       IN NUMBER, --配置区域
                                  I_LINK         IN VARCHAR2, --目标库的链接
                                  I_BATCH        IN VARCHAR2, --批次
                                  I_ITSM_CODE    IN varchar2, -- ITSM单号 用于remark模糊查询
                                  O_RESULT       OUT VARCHAR2, --返回标识
                                  O_TMPTABLENAME OUT VARCHAR2, --临时表名
                                  O_MSG          OUT VARCHAR2) IS
    V_CNT           NUMBER; --结果变量
    V_SYNCSQL       VARCHAR2(2000); --同步脚本语句
    V_TABLE         VARCHAR2(100); --同步表
    V_SEQ           NUMBER; --同步表顺序
    V_KEYCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_MAPCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_LINKINSTTABLE VARCHAR2(100); --外数据库链接的实例表
    V_EXECUTESQL    VARCHAR2(8000); --实时执行语句
    V_EXECUTESQL_FROM    VARCHAR2(8000); --源数据执行语句
    V_EXECUTESQL_TO   VARCHAR2(8000); --目标数据执行语句
    COLUMN_NAME    VARCHAR2(1000);--同步的表字段合集


  BEGIN
    O_RESULT   := 'FALSE';
    /*------------------------------------------------------------------------------------------
      步骤一：根据传入的同步表ID，以及主键和区域ID，拼装出要同步的表数据
    ------------------------------------------------------------------------------------------*/
    FOR COMSYNCCONF IN (SELECT *
                          FROM COM_SYNC_CONF
                         WHERE ID = I_SYNCID) LOOP
      V_SYNCSQL       := COMSYNCCONF.SYNC_SQL;
      V_TABLE         := COMSYNCCONF.TABLE_NAME;
      V_SEQ           := COMSYNCCONF.SEQ;
      V_KEYCOLUMN     := COMSYNCCONF.KEY_COLUMN;
      V_LINKINSTTABLE := COMSYNCCONF.INST_TABLE;
    END LOOP;
    IF V_SYNCSQL IS NULL OR V_TABLE IS NULL OR V_KEYCOLUMN IS NULL THEN
      O_MSG := '根据ID' || TO_CHAR(I_SYNCID) || '查询com_sync_conf表数据异常,请检查是否Sync_Sql,Table_Name,Key_Column为空';
      RETURN;
    END IF;
    --可能对应实例表的字段与配置字段不同
    V_MAPCOLUMN := V_KEYCOLUMN;
    IF V_LINKINSTTABLE IS NOT NULL THEN
      V_CNT := INSTR(V_LINKINSTTABLE, '-', 1, 1);
      IF V_CNT > 0 THEN
        V_MAPCOLUMN     := SUBSTR(V_LINKINSTTABLE, V_CNT + 1);
        V_LINKINSTTABLE := SUBSTR(V_LINKINSTTABLE, 0, V_CNT - 1);
      END IF;
    END IF;

    --替换主键
    V_CNT := INSTR(V_SYNCSQL, ':id', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL := REPLACE(V_SYNCSQL, ':id', TO_CHAR(I_ID));
    END IF;
    --替换区域
    V_CNT := INSTR(V_SYNCSQL, ':cfgAreaId', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL := REPLACE(V_SYNCSQL, ':cfgAreaId', TO_CHAR(I_AREAID));
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤二： 取出本数据库中要同步表的数据，放入名为 SYNC_FROM_201207100945_1
      (该表名自动生成，字段与原表相同，SYNC_FROM+sysdate+表执行顺序)的表内，
    ------------------------------------------------------------------------------------------*/
    V_EXECUTESQL_FROM := REPLACE(V_SYNCSQL, '@');
    V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM, '#');

    COLUMN_NAME := '';
    V_CNT := INSTR(I_LINK, '.', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '@');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '#', I_LINK);
      for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE order by column_id) loop
         COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
      end loop;
    ELSE
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '#');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '@', I_LINK);
      for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE AND DATA_TYPE NOT IN('CLOB','NCLOB','BLOB','BFILE') order by column_id) loop
         COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
      end loop;
    END IF;
    COLUMN_NAME := substr(COLUMN_NAME,1,length(COLUMN_NAME)-1);
    IF INSTR(V_EXECUTESQL_FROM, '*', 1, 1) >0 AND INSTR(V_EXECUTESQL_TO, '*', 1, 1) >0 THEN
       V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM, '*', COLUMN_NAME);
       V_EXECUTESQL_TO := REPLACE(V_EXECUTESQL_TO, '*', COLUMN_NAME);
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤三： mod by linxi 根据传入的ITSM_CODE模糊查询
    ------------------------------------------------------------------------------------------*/
    V_CNT := INSTR(V_SYNCSQL, '^', 1, 1);
    IF V_CNT > 0 THEN
       IF length(I_ITSM_CODE) >0 THEN
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^' ,' AND REMARK LIKE  ''%'||I_ITSM_CODE||'%''' );
         V_EXECUTESQL_TO := V_SYNCSQL;
         V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '@', I_LINK);
         V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM , '^' ,' AND REMARK LIKE  ''%'||I_ITSM_CODE||'%''' );
       ELSE
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^');
         V_EXECUTESQL_TO := REPLACE(V_EXECUTESQL_TO , '^');
         V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM , '^');
       END IF;
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤四：创建差异表,比对以上两个表，
      取出要变更的数据放入差异表中，该表字段为“KEY_ID”放置主键，“MINUS_OP”放置操作类型ADD,DEL,UPDATE。
    ------------------------------------------------------------------------------------------*/

    --1.要新增的数据导入差异表
    V_EXECUTESQL := 'INSERT INTO SYNC_MINUSTABLE select SEQ_SYNC_MINUSTABLE_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,n.'|| V_KEYCOLUMN ||',''ADD'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''' from (' ||
                    V_EXECUTESQL_FROM || ') n where not exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' ||
                    V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ') and n.STATUS_CD != ''1100''';
    EXECUTE IMMEDIATE V_EXECUTESQL;
    --2.要删除的数据导入差异表
    /**
    V_EXECUTESQL := 'INSERT INTO SYNC_MINUSTABLE select SEQ_SYNC_MINUSTABLE_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,o.'|| V_KEYCOLUMN ||',''DEL'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||'''  from (' ||
                    V_EXECUTESQL_TO || ') o where not exists (select 1 from (' || V_EXECUTESQL_FROM || ') where ' ||
                    V_KEYCOLUMN || '=o.' || V_KEYCOLUMN || ')  and o.STATUS_CD != ''1100''';
    EXECUTE IMMEDIATE V_EXECUTESQL;
    **/
    --3.变更的数据导入差异表
    IF INSTR(V_EXECUTESQL_FROM, '*', 1, 1) >0 AND INSTR(V_EXECUTESQL_TO, '*', 1, 1) >0 THEN
       V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM, '*', COLUMN_NAME);
       V_EXECUTESQL_TO := REPLACE(V_EXECUTESQL_TO, '*', COLUMN_NAME);
    END IF;

    V_EXECUTESQL := 'INSERT INTO SYNC_MINUSTABLE select SEQ_SYNC_MINUSTABLE_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,'|| V_KEYCOLUMN ||',''UPDATE'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''' from
                    (select * from ('|| V_EXECUTESQL_FROM || ') n where exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' || V_KEYCOLUMN ||
                    '=n.' || V_KEYCOLUMN || ') minus select * from (' || V_EXECUTESQL_TO || '))';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    --找出主键冲突的标记为CALCEL 不进行同步
    V_EXECUTESQL := 'select count(*) from SYNC_MINUSTABLE WHERE MINUS_OP = ''ADD'' AND BATCH_NO='''||I_BATCH||'''';
    EXECUTE IMMEDIATE V_EXECUTESQL INTO V_CNT;
    IF V_CNT > 0 THEN
      V_CNT := INSTR(I_LINK, '.', 1, 1);
      IF V_CNT > 0 THEN
        V_TABLE := I_LINK || V_TABLE;
      ELSE
        V_TABLE := V_TABLE || I_LINK;
      END IF;
      V_EXECUTESQL := 'UPDATE SYNC_MINUSTABLE SET MINUS_OP=''CANCEL'' WHERE MINUS_OP=''ADD'' AND CFG_ID='''||I_SYNCID||''' AND BATCH_NO='''||I_BATCH||''' AND exists (select 1 from ' || V_TABLE ||
          ' where ' || V_KEYCOLUMN || '= SYNC_MINUSTABLE.KEY_ID)';
      EXECUTE IMMEDIATE V_EXECUTESQL;
    END IF;

    COMMIT;
    O_TMPTABLENAME := V_TABLE;
    O_MSG          := '获取'||V_TABLE||' 表增量数据成功';
    O_RESULT       := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'p_createSyncTempTable:' || SQLERRM;
  END;

--生成执行脚本
  PROCEDURE P_CREATESQL(I_BATCH        IN VARCHAR2, --批次
                        I_LINK         IN VARCHAR2, --目标库的链接
                        I_STAFF        IN VARCHAR2, --操作员工
                        I_LOGIN_IP     IN VARCHAR2, --登陆ip
                        O_RESULT       OUT VARCHAR2, --返回标识
                        O_MSG          OUT VARCHAR2) IS

     V_EXECUTESQL   VARCHAR2(6000); --实时执行语句
     V_SQL          VARCHAR2(4000); --生成的脚本
     V_TABLE_NAME   VARCHAR2(50);
     V_KEY_COLUMN   VARCHAR2(50);
     V_KEY_ID       NUMBER;
     V_CFG_ID       NUMBER;
     V_CNT          NUMBER;
     COLUMN_NAME    VARCHAR2(1000);
     HIS_TABLE_NAME VARCHAR2(50);
     HIS_SEQ        VARCHAR(50);

   BEGIN
     O_RESULT   := 'FALSE';



     V_CNT := INSTR(I_LINK, '.', 1, 1);
     --新增
     FOR COMSYNCCONF IN (SELECT distinct batch_no,table_name,key_id,minus_op,cfg_id,key_column
                          FROM SYNC_MINUSTABLE
                         WHERE MINUS_OP='ADD' AND BATCH_NO = I_BATCH) LOOP
       V_TABLE_NAME := COMSYNCCONF.TABLE_NAME;
       V_KEY_ID := COMSYNCCONF.KEY_ID;
       V_CFG_ID := COMSYNCCONF.CFG_ID;
       V_KEY_COLUMN := COMSYNCCONF.KEY_COLUMN;

       --获取列名
       COLUMN_NAME := '';
       IF V_CNT > 0 THEN
         for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE_NAME order by column_id) loop
            COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
         end loop;
       ELSE
         for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE_NAME AND DATA_TYPE NOT IN('CLOB','NCLOB','BLOB','BFILE') order by column_id) loop
            COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
         end loop;
       END IF;
       COLUMN_NAME := substr(COLUMN_NAME,1,length(COLUMN_NAME)-1);
       --同步脚本
       if V_CNT>0 then
          V_SQL := 'insert into ' || I_LINK || V_TABLE_NAME || '(' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from '|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
       else
          V_SQL := 'insert into '|| V_TABLE_NAME || I_LINK || '(' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from '|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
       end if;
       EXECUTE IMMEDIATE V_SQL;
       V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
       EXECUTE IMMEDIATE V_EXECUTESQL;

       --备份脚本
       --V_SQL := 'delete from '||V_TABLE_NAME||' where '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
       --V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''BACKUP'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
       --EXECUTE IMMEDIATE V_EXECUTESQL;
     END LOOP;
     dbms_output.put_line('1');
     --删除
     /*
     FOR COMSYNCCONF IN (SELECT *
                          FROM SYNC_MINUSTABLE
                         WHERE MINUS_OP='DEL' AND BATCH_NO = I_BATCH) LOOP
       V_TABLE_NAME := COMSYNCCONF.TABLE_NAME;
       V_KEY_ID := COMSYNCCONF.KEY_ID;
       V_CFG_ID := COMSYNCCONF.CFG_ID;
       V_KEY_COLUMN := COMSYNCCONF.KEY_COLUMN;

       --同步脚本
       V_SQL := 'delete from '||V_TABLE_NAME||' where '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
       V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
       EXECUTE IMMEDIATE V_EXECUTESQL;

     END LOOP;
     */
     --修改

     FOR COMSYNCCONF IN (SELECT *
                          FROM SYNC_MINUSTABLE
                         WHERE MINUS_OP='UPDATE' AND BATCH_NO = I_BATCH) LOOP
       V_TABLE_NAME := COMSYNCCONF.TABLE_NAME;
       V_KEY_ID := COMSYNCCONF.KEY_ID;
       V_CFG_ID := COMSYNCCONF.CFG_ID;
       V_KEY_COLUMN := COMSYNCCONF.KEY_COLUMN;

       --获取列名
       COLUMN_NAME := '';
       IF V_CNT > 0 THEN
         for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE_NAME order by column_id) loop
            COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
         end loop;
       ELSE
         for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE_NAME AND DATA_TYPE NOT IN('CLOB','NCLOB','BLOB','BFILE') order by column_id) loop
            COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
         end loop;
       END IF;
       COLUMN_NAME := substr(COLUMN_NAME,1,length(COLUMN_NAME)-1);
       --同步脚本,修改采用插入历史表然后删除再新增
       SELECT DISTINCT t.his_table_name INTO HIS_TABLE_NAME FROM SYS_CLASS t,USER_TABLES tb WHERE t.table_name=V_TABLE_NAME AND t.his_table_name=tb.table_name;
       dbms_output.put_line(HIS_TABLE_NAME);
       IF HIS_TABLE_NAME IS NOT NULL THEN
          SELECT DISTINCT t.his_seq_name INTO HIS_SEQ FROM sys_class t WHERE t.table_name =V_TABLE_NAME;
          IF HIS_SEQ IS NOT NULL THEN
             --生成插入历史表的语句
             if V_CNT>0 THEN
                V_SQL :='insert into ' ||I_LINK|| HIS_TABLE_NAME || '('||COLUMN_NAME||',HIS_ID) select '||COLUMN_NAME||',' ||I_LINK|| HIS_SEQ||'.nextval from ' || I_LINK || V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             ELSE
                V_SQL :='insert into ' || HIS_TABLE_NAME  ||I_LINK|| '('||COLUMN_NAME||',HIS_ID) select '||COLUMN_NAME||','||HIS_SEQ||'.nextval' ||I_LINK|| ' from '|| V_TABLE_NAME || I_LINK ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             END IF;
             EXECUTE IMMEDIATE V_SQL;
             V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
             EXECUTE IMMEDIATE V_EXECUTESQL;
             --生成删除数据的语句
             if V_CNT>0 THEN
                V_SQL := 'delete from ' ||I_LINK|| V_TABLE_NAME || ' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             ELSE
                V_SQL := 'delete from ' || V_TABLE_NAME ||I_LINK|| ' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             END IF;
             EXECUTE IMMEDIATE V_SQL;
             V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
             EXECUTE IMMEDIATE V_EXECUTESQL;
             --生成添加数据的数据
             if V_CNT>0 then
                V_SQL := 'insert into ' ||I_LINK|| V_TABLE_NAME || '(' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from '|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
                else
                V_SQL := 'insert into ' || V_TABLE_NAME ||I_LINK|| '(' || COLUMN_NAME || ') select '|| COLUMN_NAME || ' from '|| V_TABLE_NAME ||' where '||V_KEY_COLUMN||'='||V_KEY_ID;
             end if;
             EXECUTE IMMEDIATE V_SQL;
             V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
             EXECUTE IMMEDIATE V_EXECUTESQL;
          END IF;
       END IF;

     END LOOP;
     dbms_output.put_line('2');
     --DELUP
     /*
     FOR COMSYNCCONF IN (SELECT *
                          FROM SYNC_MINUSTABLE
                         WHERE MINUS_OP='DELUP' AND BATCH_NO = I_BATCH) LOOP
       V_TABLE_NAME := COMSYNCCONF.TABLE_NAME;
       V_KEY_ID := COMSYNCCONF.KEY_ID;
       V_CFG_ID := COMSYNCCONF.CFG_ID;

       V_SQL := 'UPDATE '|| V_TABLE_NAME || 'SET STATUS_CD=''1100'' WHERE '||V_KEY_COLUMN||'='||V_KEY_ID|| ';';
       V_EXECUTESQL := 'INSERT INTO SYNC_SQL VALUES (SEQ_SYNC_SQL_ID.NEXTVAL,'''||I_BATCH||''','''||V_CFG_ID||''','''||V_SQL||''',''SYNC'','''||I_STAFF||''',sysdate,'''||I_LOGIN_IP||''')';
       EXECUTE IMMEDIATE V_EXECUTESQL;
     END LOOP;
     */
     COMMIT;

     O_MSG          := '获取表执行脚本成功';
     O_RESULT       := 'TRUE';
    EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'P_CREATESQL:' || SQLERRM;
   END;

   --生产差异数据
  PROCEDURE P_CREATESYNCLOG(I_SYNCID       IN NUMBER, --同步表ID
                            I_ID           IN NUMBER, --销售品规格ID，产品规格ID
                            I_LINK         IN VARCHAR2, --目标库的链接
                            I_BATCH        IN VARCHAR2, --批次
                            I_ITSM_CODE    IN varchar2, -- ITSM单号 用于remark模糊查询
                            I_LOCAL_DBA    IN VARCHAR2,--源库
                            I_COM_SYNC_DBA IN VARCHAR2,--目标库
                            O_RESULT       OUT VARCHAR2, --返回标识
                            O_MSG          OUT VARCHAR2) IS
    V_CNT           NUMBER; --结果变量
    V_SYNCSQL       VARCHAR2(2000); --同步脚本语句
    V_TABLE         VARCHAR2(100); --同步表
    V_TAR_TABLE     VARCHAR2(100);--目标库表
    V_SEQ           NUMBER; --同步表顺序
    V_KEYCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_MAPCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_LINKINSTTABLE VARCHAR2(100); --外数据库链接的实例表
    V_EXECUTESQL    VARCHAR2(8000); --实时执行语句
    V_EXECUTESQL_FROM    VARCHAR2(8000); --源数据执行语句
    V_EXECUTESQL_TO   VARCHAR2(8000); --目标数据执行语句
    COLUMN_NAME    VARCHAR2(1000);--同步的表字段合集


  BEGIN
    O_RESULT   := 'FALSE';
    /*------------------------------------------------------------------------------------------
      步骤一：根据传入的同步表ID，以及主键和区域ID，拼装出要同步的表数据
    ------------------------------------------------------------------------------------------*/
    FOR COMSYNCCONF IN (SELECT *
                          FROM COM_SYNC_CONF
                         WHERE ID = I_SYNCID) LOOP
      V_SYNCSQL       := COMSYNCCONF.SYNC_SQL;
      V_TABLE         := COMSYNCCONF.TABLE_NAME;
      V_SEQ           := COMSYNCCONF.SEQ;
      V_KEYCOLUMN     := COMSYNCCONF.KEY_COLUMN;
      V_LINKINSTTABLE := COMSYNCCONF.INST_TABLE;
    END LOOP;
    IF V_SYNCSQL IS NULL OR V_TABLE IS NULL OR V_KEYCOLUMN IS NULL THEN
      O_MSG := '根据ID' || TO_CHAR(I_SYNCID) || '查询com_sync_conf表数据异常,请检查是否Sync_Sql,Table_Name,Key_Column为空';
      RETURN;
    END IF;
    --可能对应实例表的字段与配置字段不同
    V_MAPCOLUMN := V_KEYCOLUMN;
    IF V_LINKINSTTABLE IS NOT NULL THEN
      V_CNT := INSTR(V_LINKINSTTABLE, '-', 1, 1);
      IF V_CNT > 0 THEN
        V_MAPCOLUMN     := SUBSTR(V_LINKINSTTABLE, V_CNT + 1);
        V_LINKINSTTABLE := SUBSTR(V_LINKINSTTABLE, 0, V_CNT - 1);
      END IF;
    END IF;

    --替换主键
    V_CNT := INSTR(V_SYNCSQL, ':id', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL := REPLACE(V_SYNCSQL, ':id', TO_CHAR(I_ID));
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤二： 取出本数据库中要同步表的数据，放入名为 SYNC_FROM_201207100945_1
      (该表名自动生成，字段与原表相同，SYNC_FROM+sysdate+表执行顺序)的表内，
    ------------------------------------------------------------------------------------------*/
    V_EXECUTESQL_FROM := REPLACE(V_SYNCSQL, '@');
    V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM, '#');

    COLUMN_NAME := '';
    V_CNT := INSTR(I_LINK, '.', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '@');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '#', I_LINK);
      V_TAR_TABLE     := I_LINK||V_TABLE;
      for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE order by column_id) loop
         COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
      end loop;
    ELSE
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '#');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '@', I_LINK);
      V_TAR_TABLE     := V_TABLE||I_LINK;
      for tabcolumns in (select * from user_tab_columns where table_name = V_TABLE AND DATA_TYPE NOT IN('CLOB','NCLOB','BLOB','BFILE') order by column_id) loop
         COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
      end loop;
    END IF;
    COLUMN_NAME := substr(COLUMN_NAME,1,length(COLUMN_NAME)-1);
    IF INSTR(V_EXECUTESQL_FROM, '*', 1, 1) >0 AND INSTR(V_EXECUTESQL_TO, '*', 1, 1) >0 THEN
       V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM, '*', COLUMN_NAME);
       V_EXECUTESQL_TO := REPLACE(V_EXECUTESQL_TO, '*', COLUMN_NAME);
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤三： mod by linxi 根据传入的ITSM_CODE模糊查询
    ------------------------------------------------------------------------------------------*/
    V_CNT := INSTR(V_SYNCSQL, '^', 1, 1);
    IF V_CNT > 0 THEN
       IF length(I_ITSM_CODE) >0 THEN
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^' ,' AND REMARK LIKE  ''%'||I_ITSM_CODE||'%''' );
         V_EXECUTESQL_TO := V_SYNCSQL;
         V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '@', I_LINK);
         V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM , '^' ,' AND REMARK LIKE  ''%'||I_ITSM_CODE||'%''' );
       ELSE
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^');
         V_EXECUTESQL_TO := REPLACE(V_EXECUTESQL_TO , '^');
         V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM , '^');
       END IF;
    END IF;

    --1.源库有该数据，目标库无 且该数据状态不为1100
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,n.'|| V_KEYCOLUMN ||',''数据缺失'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''',''源库有该数据，目标库无 且该数据状态不为1100'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||''' from (' ||
                    V_EXECUTESQL_FROM || ') n where not exists (select 1 from '||V_TAR_TABLE||' where ' ||
                    V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ') and n.STATUS_CD != ''1100''';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    --2.源库有该数据，目标库无 且该数据状态为1100
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,n.'|| V_KEYCOLUMN ||',''数据缺失'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''',''源库有该数据，目标库无 且该数据状态为1100'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||''' from (' ||
                    V_EXECUTESQL_FROM || ') n where not exists (select 1 from '||V_TAR_TABLE||' where ' ||
                    V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ') and n.STATUS_CD = ''1100''';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    --3.源库无该数据，目标库有 且该数据状态不为1100
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,o.'|| V_KEYCOLUMN ||',''数据缺失'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''',''源库无该数据，目标库有 且该数据状态不为1100'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||'''  from (' ||
                    V_EXECUTESQL_TO || ') o where not exists (select 1 from (' || V_EXECUTESQL_FROM || ') where ' ||
                    V_KEYCOLUMN || '=o.' || V_KEYCOLUMN || ')  and o.STATUS_CD != ''1100''';
    EXECUTE IMMEDIATE V_EXECUTESQL;
    --4.源库无该数据，目标库有 且该数据状态为1100
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,o.'|| V_KEYCOLUMN ||',''数据缺失'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''',''源库无该数据，目标库有 且该数据状态为1100'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||'''  from (' ||
                    V_EXECUTESQL_TO || ') o where not exists (select 1 from (' || V_EXECUTESQL_FROM || ') where ' ||
                    V_KEYCOLUMN || '=o.' || V_KEYCOLUMN || ')  and o.STATUS_CD = ''1100''';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    --3.变更的数据导入差异表
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,'|| V_KEYCOLUMN ||',''数据差异'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''',''源库与目标库数据存在差异'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||''' from
                    (select * from ('|| V_EXECUTESQL_FROM || ') n where exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' || V_KEYCOLUMN ||
                    '=n.' || V_KEYCOLUMN || ') minus select * from (' || V_EXECUTESQL_TO || '))';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    --4.主键冲突
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||V_TABLE||''' ,n.'|| V_KEYCOLUMN ||',''数据差异'','''|| I_SYNCID ||''','''|| V_KEYCOLUMN ||''',''数据差异，主键被占用！'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||''' from (' ||
                    V_EXECUTESQL_FROM || ') n where not exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' ||
                    V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ') and exists (select 1 from '||V_TAR_TABLE||' where '||
                    V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ')';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    COMMIT;
    O_MSG          := ''||V_TABLE||' 比对数据成功';
    O_RESULT       := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'p_createSyncTempTable:' || SQLERRM;
  END;

  --比较主数据差异存入日志表
  PROCEDURE P_CREATEMETADATASYNCLOG(I_TABLENAME    IN VARCHAR2, --表名
                            I_LINK         IN VARCHAR2, --目标库的链接
                            I_BATCH        IN VARCHAR2, --批次
                            I_ITSM_CODE    IN varchar2, -- ITSM单号 用于remark模糊查询
                            I_LOCAL_DBA    IN VARCHAR2,--源库
                            I_COM_SYNC_DBA IN VARCHAR2,--目标库
                            O_RESULT       OUT VARCHAR2, --返回标识
                            O_MSG          OUT VARCHAR2) IS
    V_CNT           NUMBER; --结果变量
    V_SYNCSQL       VARCHAR2(2000); --同步脚本语句
    V_KEYCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_MAPCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_LINKINSTTABLE VARCHAR2(100); --外数据库链接的实例表
    V_EXECUTESQL    VARCHAR2(8000); --实时执行语句
    V_EXECUTESQL_FROM    VARCHAR2(8000); --源数据执行语句
    V_EXECUTESQL_TO   VARCHAR2(8000); --目标数据执行语句
    COLUMN_NAME    VARCHAR2(1000);--同步的表字段合集


  BEGIN
    O_RESULT   := 'FALSE';
    IF length(I_ITSM_CODE) <= 0 THEN
      O_MSG := '未传入ITSM_CODE';
      RETURN;
    END IF;

    IF I_TABLENAME ='ATTR_SPEC' THEN
       V_SYNCSQL := 'SELECT * FROM #ATTR_SPEC@ t1 WHERE  EXISTS (SELECT ''X'' FROM attr_spec t2 WHERE t2.attr_id=t1.attr_id AND t2.REMARK LIKE ''%'||I_ITSM_CODE||'%'')';
       V_EXECUTESQL_FROM := 'SELECT * FROM ATTR_SPEC WHERE REMARK LIKE ''%'||I_ITSM_CODE||'%''';
       V_KEYCOLUMN := 'ATTR_ID';
    ELSIF I_TABLENAME ='ATTR_VALUE' THEN
       V_SYNCSQL := 'SELECT * FROM #ATTR_VALUE@ t1 WHERE EXISTS (SELECT ''X'' FROM attr_value t2 WHERE t2.attr_value_id=t1.attr_value_id AND t2.REMARK LIKE ''%'||I_ITSM_CODE||'%'')';
       V_EXECUTESQL_FROM := 'SELECT * FROM ATTR_VALUE WHERE REMARK LIKE ''%'||I_ITSM_CODE||'%''';
       V_KEYCOLUMN := 'ATTR_VALUE_ID';
    END IF;
    --拼接表字段与目标库链接或用户。
    --同库的同步CLOB字段表内容 不同库的数据库不同步CLOB字段
    COLUMN_NAME := '';
    V_CNT := INSTR(I_LINK, '.', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '@');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '#', I_LINK);
      for tabcolumns in (select * from user_tab_columns where table_name = I_TABLENAME order by column_id) loop
         COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
      end loop;
    ELSE
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '#');
      V_EXECUTESQL_TO := REPLACE(V_SYNCSQL, '@', I_LINK);
      for tabcolumns in (select * from user_tab_columns where table_name = I_TABLENAME AND DATA_TYPE NOT IN('CLOB','NCLOB','BLOB','BFILE') order by column_id) loop
         COLUMN_NAME := COLUMN_NAME || tabcolumns.column_name || ',';
      end loop;
    END IF;
    COLUMN_NAME := substr(COLUMN_NAME,1,length(COLUMN_NAME)-1);
    --替换*为字段名称
    IF INSTR(V_EXECUTESQL_FROM, '*', 1, 1) >0 AND INSTR(V_EXECUTESQL_TO, '*', 1, 1) >0 THEN
       V_EXECUTESQL_FROM := REPLACE(V_EXECUTESQL_FROM, '*', COLUMN_NAME);
       V_EXECUTESQL_TO := REPLACE(V_EXECUTESQL_TO, '*', COLUMN_NAME);
    END IF;
    --1.源库有该数据，目标库无 且该数据状态不为1100
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||I_TABLENAME||''' ,n.'|| V_KEYCOLUMN ||',''数据缺失'',''0'','''|| V_KEYCOLUMN ||''',''源库有该数据，目标库无 且该数据状态不为1100'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||''' from (' ||
                    V_EXECUTESQL_FROM || ') n where not exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' ||
                    V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ') and n.STATUS_CD != ''1100''';
   EXECUTE IMMEDIATE V_EXECUTESQL;

    --2.源库有该数据，目标库无 且该数据状态为1100
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||I_TABLENAME||''' ,n.'|| V_KEYCOLUMN ||',''数据缺失'',''0'','''|| V_KEYCOLUMN ||''',''源库有该数据，目标库无 且该数据状态为1100'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||''' from (' ||
                    V_EXECUTESQL_FROM || ') n where not exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' ||
                    V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ') and n.STATUS_CD = ''1100''';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    --3.变更的数据导入差异表
    --获取列名 对列数据进行对比
    V_EXECUTESQL := 'INSERT INTO SYNC_LOG select SEQ_SYNC_LOG_ID.NEXTVAL,'''||I_BATCH||''','''||I_TABLENAME||''' ,'|| V_KEYCOLUMN ||',''数据差异'',''0'','''|| V_KEYCOLUMN ||''',''源库与目标库数据存在差异'','''||I_LOCAL_DBA||''','''||I_COM_SYNC_DBA||''' from
                    (select * from ('|| V_EXECUTESQL_FROM || ') n where exists (select 1 from (' || V_EXECUTESQL_TO || ') where ' || V_KEYCOLUMN ||
                    '=n.' || V_KEYCOLUMN || ') minus select * from (' || V_EXECUTESQL_TO || '))';
    EXECUTE IMMEDIATE V_EXECUTESQL;
    COMMIT;
    O_MSG          := ''||I_TABLENAME||' 比对数据成功';
    O_RESULT       := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'p_createSyncTempTable:' || SQLERRM;
  END;
END PKG_CRM2_SYNC_NEW;
/
