CREATE PACKAGE BODY           PKG_CRM2_PROD_SYNC IS

  PROCEDURE P_CREATESYNCTEMPTABLE(I_SYNCID       IN NUMBER, --同步表ID
                                  I_ID           IN NUMBER, --销售品规格ID，产品规格ID
                                  I_AREAID       IN NUMBER, --配置区域
                                  I_LINK         IN VARCHAR2, --目标库的链接
                                  I_ITSM_CODE    IN VARCHAR2, --修改查询
                                  O_RESULT       OUT VARCHAR2, --返回标识
                                  O_TMPTABLENAME OUT VARCHAR2, --临时表名
                                  O_MSG          OUT VARCHAR2) IS
    V_CNT           NUMBER; --结果变量
    V_SYNCSQL       VARCHAR2(2000); --同步脚本语句
    V_TABLE         VARCHAR2(100); --同步表
    V_SEQ           NUMBER; --同步表顺序
    V_KEYCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_MAPCOLUMN     VARCHAR2(100); --同步表的主键字段
    V_LINKINSTTABLE VARCHAR2(100); --外数据库链接的实例表
    V_SYNCFROMTABLE VARCHAR2(100); --本地同步数据生成的表名
    V_SYNCTOTABLE   VARCHAR2(100); --目的同步数据生成的表名
    V_MINUSTABLE    VARCHAR2(100); --差异表表名
    V_DATETIME      VARCHAR2(20); --当前时间
    V_EXECUTESQL    VARCHAR2(2000); --实时执行语句
    V_DATA_TYPE     VARCHAR2(20);
-- mod by 2013-09-09
/*
    V_KEYID         VARCHAR2(100);
    TYPE C1 IS REF CURSOR;
    TEMP_CURSOR C1;
*/
  BEGIN
    V_DATETIME := TO_CHAR(SYSDATE, 'yyyymmddhh24miss');
    O_RESULT   := 'FALSE';
    /*------------------------------------------------------------------------------------------
      步骤一：根据传入的同步表ID，以及主键和区域ID，拼装出要同步的表数据
    ------------------------------------------------------------------------------------------*/
    FOR COMSYNCCONF IN (SELECT *
                          FROM COM_SYNC_CONF
                         WHERE ID = I_SYNCID) LOOP
      V_SYNCSQL       := COMSYNCCONF.SYNC_SQL;
      V_TABLE         := COMSYNCCONF.TABLE_NAME;
      V_SEQ           := COMSYNCCONF.SEQ;
      V_KEYCOLUMN     := COMSYNCCONF.KEY_COLUMN;
      V_LINKINSTTABLE := COMSYNCCONF.INST_TABLE;
      V_DATA_TYPE     := COMSYNCCONF.Data_Type;
    END LOOP;
    IF V_SYNCSQL IS NULL OR V_TABLE IS NULL OR V_KEYCOLUMN IS NULL THEN
      O_MSG := '根据ID' || TO_CHAR(I_SYNCID) || '查询com_sync_conf表数据异常,请检查是否Sync_Sql,Table_Name,Key_Column为空';
      RETURN;
    END IF;
    --可能对应实例表的字段与配置字段不同
    V_MAPCOLUMN := V_KEYCOLUMN;
    IF V_LINKINSTTABLE IS NOT NULL THEN
      V_CNT := INSTR(V_LINKINSTTABLE, '-', 1, 1);
      IF V_CNT > 0 THEN
        V_MAPCOLUMN     := SUBSTR(V_LINKINSTTABLE, V_CNT + 1);
        V_LINKINSTTABLE := SUBSTR(V_LINKINSTTABLE, 0, V_CNT - 1);
      END IF;
    END IF;
    V_SYNCFROMTABLE := 'SYNC_FROM_' || V_DATETIME || '_' || TO_CHAR(V_SEQ);
    V_SYNCTOTABLE   := 'SYNC_TO_' || V_DATETIME || '_' || TO_CHAR(V_SEQ);
    V_MINUSTABLE    := 'SYNC_MINU_' || V_DATETIME || '_' || TO_CHAR(V_SEQ);
    --替换主键
    V_CNT := INSTR(V_SYNCSQL, ':id', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL := REPLACE(V_SYNCSQL, ':id', TO_CHAR(I_ID));
    END IF;
    --替换区域
    V_CNT := INSTR(V_SYNCSQL, ':cfgAreaId', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL := REPLACE(V_SYNCSQL, ':cfgAreaId', TO_CHAR(I_AREAID));
    END IF;

    /*------------------------------------------------------------------------------------------
      是否是修改同步
    ------------------------------------------------------------------------------------------*/
    V_CNT := INSTR(V_SYNCSQL, '^', 1, 1);
    IF V_CNT > 0 THEN
       IF length(I_ITSM_CODE) >0 THEN
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^' ,' AND REMARK LIKE  ''%'||I_ITSM_CODE||'%''' );
       ELSE
         V_SYNCSQL := REPLACE(V_SYNCSQL , '^');
       END IF;
    END IF;

    /*------------------------------------------------------------------------------------------
      步骤二： 取出本数据库中要同步表的数据，放入名为 SYNC_FROM_201207100945_1
      (该表名自动生成，字段与原表相同，SYNC_FROM+sysdate+表执行顺序)的表内，
    ------------------------------------------------------------------------------------------*/
    V_EXECUTESQL := 'CREATE TABLE ' || V_SYNCFROMTABLE || ' AS ' || REPLACE(V_SYNCSQL, '@');
    V_EXECUTESQL := REPLACE(V_EXECUTESQL, '#');
    EXECUTE IMMEDIATE V_EXECUTESQL;
    /*------------------------------------------------------------------------------------------
     步骤三： 将目标库要被覆盖的数据，放入名为 SYNC_TO_201207100945_1
     (该表名自动生成，字段与原表相同，SYNC_TO+sysdate+表执行顺序) 的表内
     字段排列顺序不同也会造成minu错误，所以先根据同步表建备份表，再导入数据
    ------------------------------------------------------------------------------------------*/
    V_EXECUTESQL := 'CREATE TABLE ' || V_SYNCTOTABLE || ' AS SELECT * FROM ' || V_SYNCFROMTABLE || ' WHERE 1=2';
    /*v_executeSql := 'CREATE TABLE ' || v_syncToTable || ' AS ' ||
    REPLACE(v_syncSql, '@', i_link);*/
    EXECUTE IMMEDIATE V_EXECUTESQL;
    --同个数据库，不同用户名的情况，传入的链接为crmv2.格式。
    --不同数据库，采用数据库链路，传入的链接为@LK_CRM2DEV3格式。
    V_CNT := INSTR(I_LINK, '.', 1, 1);
    IF V_CNT > 0 THEN
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '@');
      V_EXECUTESQL := 'INSERT INTO ' || V_SYNCTOTABLE || '  ' || REPLACE(V_SYNCSQL, '#', I_LINK);
    ELSE
      V_SYNCSQL    := REPLACE(V_SYNCSQL, '#');
      V_EXECUTESQL := 'INSERT INTO ' || V_SYNCTOTABLE || '  ' || REPLACE(V_SYNCSQL, '@', I_LINK);
    END IF;
    EXECUTE IMMEDIATE V_EXECUTESQL;
    /*------------------------------------------------------------------------------------------
      步骤四：创建差异表,比对以上两个表，
      取出要变更的数据放入差异表中，该表字段为“KEY_ID”放置主键，“MINUS_OP”放置操作类型ADD,DEL,UPDATE。
    ------------------------------------------------------------------------------------------*/
    V_EXECUTESQL := 'create table ' || V_MINUSTABLE || ' (KEY_ID number,MINUS_OP varchar2(6))';
    EXECUTE IMMEDIATE V_EXECUTESQL;
    if V_DATA_TYPE='PUB' then
      V_EXECUTESQL := 'INSERT INTO ' || V_MINUSTABLE || ' select ' || V_KEYCOLUMN || ',''UPDATE'' from ' || V_SYNCFROMTABLE ;
      EXECUTE IMMEDIATE V_EXECUTESQL;
    else
      --1.要新增的数据导入差异表
      V_EXECUTESQL := 'INSERT INTO ' || V_MINUSTABLE || ' select n.' || V_KEYCOLUMN || ',''ADD'' from ' ||
                      V_SYNCFROMTABLE || ' n where not exists (select 1 from ' || V_SYNCTOTABLE || ' where ' ||
                      V_KEYCOLUMN || '=n.' || V_KEYCOLUMN || ')';
      EXECUTE IMMEDIATE V_EXECUTESQL;
      --2.要删除的数据导入差异表
      V_EXECUTESQL := 'INSERT INTO ' || V_MINUSTABLE || ' select o.' || V_KEYCOLUMN || ',''DEL'' from ' || V_SYNCTOTABLE ||
                      ' o where not exists (select 1 from ' || V_SYNCFROMTABLE || ' where ' || V_KEYCOLUMN || '=o.' ||
                      V_KEYCOLUMN || ')  and o.STATUS_CD != ''1100''';
      EXECUTE IMMEDIATE V_EXECUTESQL;
      --3.变更的数据导入差异表
      V_EXECUTESQL := 'INSERT INTO ' || V_MINUSTABLE || ' select ' || V_KEYCOLUMN || ',''UPDATE'' from (select * from ' ||
                      V_SYNCFROMTABLE || ' n where exists (select 1 from ' || V_SYNCTOTABLE || ' where ' || V_KEYCOLUMN ||
                      '=n.' || V_KEYCOLUMN || ') minus select * from ' || V_SYNCTOTABLE || ')';
      EXECUTE IMMEDIATE V_EXECUTESQL;
    end if;
    /*------------------------------------------------------------------------------------------
     步骤五：针对DEL类型数据增加与目标库的实例数据判断，如果已经存在实例，则操作类型更改成DELUP
    ------------------------------------------------------------------------------------------*/
    IF V_LINKINSTTABLE IS NOT NULL THEN
      V_EXECUTESQL := 'select count(*) from ' || V_MINUSTABLE || ' WHERE MINUS_OP = ''DEL''';
      EXECUTE IMMEDIATE V_EXECUTESQL
        INTO V_CNT;
      IF V_CNT > 0 THEN
        V_CNT := INSTR(I_LINK, '.', 1, 1);
        IF V_CNT > 0 THEN
          V_LINKINSTTABLE := I_LINK || V_LINKINSTTABLE;
        ELSE
          V_LINKINSTTABLE := V_LINKINSTTABLE || I_LINK;
        END IF;

--  mod by 2013-09-09
/*
        V_EXECUTESQL := 'SELECT KEY_ID FROM ' || V_MINUSTABLE || ' WHERE MINUS_OP=''DEL''';
        OPEN TEMP_CURSOR FOR V_EXECUTESQL;
        LOOP
             FETCH TEMP_CURSOR INTO V_KEYID;
             EXIT WHEN TEMP_CURSOR%NOTFOUND;
             EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || V_LINKINSTTABLE || ' WHERE ' || V_MAPCOLUMN || '=' || V_KEYID INTO V_CNT;
             IF V_CNT > 0 THEN
               EXECUTE IMMEDIATE 'UPDATE ' || V_MINUSTABLE ||' SET MINUS_OP=''DELUP'' WHERE KEY_ID='||V_KEYID;
             END IF;
        END LOOP;
        CLOSE TEMP_CURSOR;
*/

        V_EXECUTESQL := 'UPDATE ' || V_MINUSTABLE ||
                        ' SET MINUS_OP=''DELUP'' WHERE MINUS_OP=''DEL'' AND exists (select 1 from ' || V_LINKINSTTABLE ||
                        ' where ' || V_MAPCOLUMN || '=' || V_MINUSTABLE || '.KEY_ID)';
        EXECUTE IMMEDIATE V_EXECUTESQL;

      END IF;
    END IF;
    COMMIT;
    O_TMPTABLENAME := V_MINUSTABLE;
    O_MSG          := '获取增量临时表' || V_MINUSTABLE || '成功';
    O_RESULT       := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'p_createSyncTempTable:' || SQLERRM ;
  END;

  PROCEDURE P_DROPSYNCTEMPTABLE(I_MINUTABLE IN VARCHAR2, --临时差异表
                                O_RESULT    OUT VARCHAR2, --返回标识
                                O_MSG       OUT VARCHAR2) IS
    V_CNT           NUMBER; --结果变量
    V_TABLE         VARCHAR2(100); --表名
    V_SYNCFROMTABLE VARCHAR2(100); --本地同步数据生成的表名
    V_SYNCTOTABLE   VARCHAR2(100); --目的同步数据生成的表名
    V_MINUSTABLE    VARCHAR2(100); --差异表表名
    V_EXECUTESQL    VARCHAR2(2000); --实时执行语句
  BEGIN
    O_RESULT := 'FALSE';
    IF I_MINUTABLE IS NULL THEN
      O_MSG := '传入的增量临时表为空,请确认';
      RETURN;
    END IF;
    V_CNT := INSTR(I_MINUTABLE, 'SYNC_', 1, 1);
    IF V_CNT > 0 THEN
      V_TABLE := LTRIM(I_MINUTABLE, 'SYNC_MINU_');
    ELSE
      V_TABLE := I_MINUTABLE;
    END IF;
    V_SYNCFROMTABLE := 'SYNC_FROM_' || V_TABLE;
    V_SYNCTOTABLE   := 'SYNC_TO_' || V_TABLE;
    V_MINUSTABLE    := 'SYNC_MINU_' || V_TABLE;

    --删除临时同步表
    SELECT COUNT(*)
      INTO V_CNT
      FROM USER_TAB_COMMENTS
     WHERE TABLE_NAME = V_SYNCFROMTABLE;
    IF V_CNT > 0 THEN
      V_EXECUTESQL := 'DROP TABLE ' || V_SYNCFROMTABLE;
      EXECUTE IMMEDIATE V_EXECUTESQL;
      O_MSG := '删除' || V_SYNCFROMTABLE || '表成功;';
    END IF;

    --删除临时备份表
    SELECT COUNT(*)
      INTO V_CNT
      FROM USER_TAB_COMMENTS
     WHERE TABLE_NAME = V_SYNCTOTABLE;
    IF V_CNT > 0 THEN
      V_EXECUTESQL := 'DROP TABLE ' || V_SYNCTOTABLE;
      EXECUTE IMMEDIATE V_EXECUTESQL;
      O_MSG := '删除' || V_SYNCTOTABLE || '表成功;' || O_MSG;
    END IF;

    --删除临时增量表
    SELECT COUNT(*)
      INTO V_CNT
      FROM USER_TAB_COMMENTS
     WHERE TABLE_NAME = V_MINUSTABLE;
    IF V_CNT > 0 THEN
      V_EXECUTESQL := 'DROP TABLE ' || V_MINUSTABLE;
      EXECUTE IMMEDIATE V_EXECUTESQL;
      O_MSG := '删除' || V_MINUSTABLE || '表成功;' || O_MSG;
    END IF;

    O_MSG    := '执行过程成功：' || O_MSG;
    O_RESULT := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      O_MSG := 'p_dropSyncTempTable:' || SQLERRM;
  END;
END PKG_CRM2_PROD_SYNC;
/
