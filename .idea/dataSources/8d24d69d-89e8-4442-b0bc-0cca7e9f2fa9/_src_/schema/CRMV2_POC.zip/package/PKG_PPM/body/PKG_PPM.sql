CREATE PACKAGE BODY           PKG_PPM IS
  /* LTE 插入，更新 INTF_DEP_CODE_MAP */
  PROCEDURE PROC_INTF_DEP_CODE_MAP(I_OBJECT_TYPE IN VARCHAR2, --对象类型  0100：产品规格编码 0200销售品规格编码：0300：营销资源细类编码
                                   I_CHANNEL_NBR IN VARCHAR2, --渠道编码
                                   I_SOURCE_CODE IN VARCHAR2, --源系统编码
                                   I_SOURCE_NAME IN VARCHAR2, --源系统编码名称
                                   I_TARGET_CODE IN VARCHAR2, --目标系统编码
                                   I_TARGET_NAME IN VARCHAR2, --目标系统编码名称
                                   I_IS_DEFAULT  IN VARCHAR2, --存在一对多映射时,默认选择这条映射. 1: 默认, NULL: 不默认
                                   I_OBJECT_NBR  IN VARCHAR2, --产品编码（以业务部门为准
                                   O_RESULT      OUT VARCHAR2--执行结果
                                   ) IS
    V_STATE           VARCHAR2(6);
    V_SOURCE_SYSTEM   VARCHAR2(10);
    V_TARGET_SYSTEM   VARCHAR2(10);
    V_OBJECT_NAME     VARCHAR2(50);
    P_TARGET_CODE     VARCHAR2(50);
  BEGIN
    V_STATE := '1000';
    P_TARGET_CODE:=NULL;
    O_RESULT :='FALSE';
    IF I_OBJECT_TYPE IS NULL THEN
       RETURN;
    END IF;
    IF I_SOURCE_CODE IS NULL THEN
       RETURN;
    END IF;
    IF I_TARGET_CODE IS NULL THEN
       RETURN;
    END IF;

    --假如是终端细类编码
    IF I_OBJECT_TYPE='0300' THEN
        V_SOURCE_SYSTEM:='CRM';
        V_TARGET_SYSTEM:='DEP';
        V_OBJECT_NAME:='营销资源细类编码';
    END IF;
   --销售品编码
    IF I_OBJECT_TYPE='0200' THEN
        V_SOURCE_SYSTEM:='DEP';
        V_TARGET_SYSTEM:='CRM';
        V_OBJECT_NAME:='销售品编码';
         IF I_OBJECT_NBR IS NULL THEN
           RETURN;
        END IF;
    END IF;
    --产品编码
     IF I_OBJECT_TYPE='0100' THEN
        V_SOURCE_SYSTEM:='DEP';
        V_TARGET_SYSTEM:='CRM';
        V_OBJECT_NAME:='产品编码';
    END IF;

      BEGIN
        SELECT I.TARGET_CODE
          INTO P_TARGET_CODE
          FROM INTF_DEP_CODE_MAP I
         WHERE I.SOURCE_CODE = I_SOURCE_CODE
           AND I.SOURCE_SYSTEM = V_SOURCE_SYSTEM
           AND I.TARGET_SYSTEM = V_TARGET_SYSTEM
           AND I.OBJECT_TYPE = I_OBJECT_TYPE
           AND ROWNUM=1;
          EXCEPTION
           WHEN OTHERS THEN
           NULL;
      END ;

    IF P_TARGET_CODE IS NOT NULL THEN
        BEGIN
          UPDATE INTF_DEP_CODE_MAP I
             SET I.TARGET_CODE = I_TARGET_CODE, I.UPDATE_DATE = SYSDATE
           WHERE I.SOURCE_CODE = I_SOURCE_CODE
             AND I.SOURCE_SYSTEM = V_SOURCE_SYSTEM
             AND I.TARGET_SYSTEM = V_TARGET_SYSTEM
             AND I.OBJECT_TYPE = I_OBJECT_TYPE;
          COMMIT;
          O_RESULT := 'TRUE';
          RETURN;
        EXCEPTION
           WHEN OTHERS THEN
              ROLLBACK;
              RETURN;
         END;
    END IF;
    IF P_TARGET_CODE IS NULL THEN
      BEGIN
      INSERT INTO INTF_DEP_CODE_MAP
        (INTF_DEP_CODE_MAP_ID,
         OBJECT_TYPE,
         OBJECT_NAME,
         CHANNEL_NBR,
         SOURCE_SYSTEM,
         SOURCE_CODE,
         SOURCE_NAME,
         TARGET_SYSTEM,
         TARGET_CODE,
         TARGET_NAME,
         STATE,
         STATE_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         REMARK,
         IS_DEFAULT,
         OBJECT_NBR)
      VALUES
        (SEQ_INTF_DEP_CODE_MAP_ID.NEXTVAL,
         I_OBJECT_TYPE,
         V_OBJECT_NAME,
         '',
         V_SOURCE_SYSTEM,
         I_SOURCE_CODE,
         I_SOURCE_NAME,
         V_TARGET_SYSTEM,
         I_TARGET_CODE,
         I_TARGET_NAME,
         V_STATE,
         SYSDATE,
         SYSDATE,
         SYSDATE,
         'PPM自动配置',
         I_IS_DEFAULT,
         I_OBJECT_NBR);
      COMMIT;
      O_RESULT := 'TRUE';
      RETURN;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          RETURN;
      END;
    END IF;
   END;

  PROCEDURE PROC_PPM_SYNC_PCRF_CFG(I_PROD_OFFER_ID    IN VARCHAR2,
                                  I_PROD_OFFER_NAME  IN VARCHAR2,
                                  I_EXT_OFFER_NBR    IN VARCHAR2,
                                  O_RESULT           OUT VARCHAR2,  --TRUE成功 FALSE失败
                                  O_MSG              OUT VARCHAR2) IS

  BEGIN
    O_RESULT := 'FALSE';
    O_MSG := '';

    DELETE FROM INTF_DEFINE_CONFIG
     WHERE PROD_OFFER_ID = I_PROD_OFFER_ID
       AND CHANNEL_NBR =  '600105A081';
    INSERT INTO INTF_DEFINE_CONFIG
      (INTF_DEFINE_CONFIG_ID,
       PAYMENT_MODE_CD,
       PROD_OFFER_ID,
       PRODUCT_ID,
       SERVICE_OFFER_CODE,
       AREA_ID,
       CLASS_ID,
       ATTR_ID,
       ATTR_VALUE_OLD,
       ATTR_VALUE_NEW,
       ACTION,
       CHANNEL_NBR,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       REMARK)
    VALUES
      (SEQ_PPM_INTF_DEFINE_CONFIG_ID.NEXTVAL,
       '',
       I_PROD_OFFER_ID,
       NULL,
       3010100000,
       NULL,
       NULL,
       NULL,
       '',
       '',
       '',
       '600105A081',
       '1000',
       SYSDATE,
       SYSDATE,
       NULL,
       'PPM自动配置');
    INSERT INTO INTF_DEFINE_CONFIG
      (INTF_DEFINE_CONFIG_ID,
       PAYMENT_MODE_CD,
       PROD_OFFER_ID,
       PRODUCT_ID,
       SERVICE_OFFER_CODE,
       AREA_ID,
       CLASS_ID,
       ATTR_ID,
       ATTR_VALUE_OLD,
       ATTR_VALUE_NEW,
       ACTION,
       CHANNEL_NBR,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       REMARK)
    VALUES
      (SEQ_PPM_INTF_DEFINE_CONFIG_ID.NEXTVAL,
       '',
       I_PROD_OFFER_ID,
       NULL,
       3030100000,
       NULL,
       NULL,
       NULL,
       '',
       '',
       '',
       '600105A081',
       '1000',
       SYSDATE,
       SYSDATE,
       NULL,
       'PPM自动配置');

    DELETE FROM INTF_CODE_MAPPING
     WHERE SOURCE_CODE = I_PROD_OFFER_ID
       AND OBJECT_TYPE = 'PROD_OFFER_ID'
       AND CHANNEL_ID = 313
       AND DESTINATION_SYSTEM =  'PCRF' ;

    INSERT INTO INTF_CODE_MAPPING
      (INTF_CODE_MAPPING_ID,
       SOURCE_SYSTEM,
       SOURCE_CODE,
       SOURCE_NAME,
       CHANNEL_ID,
       DESTINATION_SYSTEM,
       DESTINATION_CODE,
       OBJECT_TYPE,
       OBJECT_NAME,
       PRODUCT_ID,
       PROD_OFFER_ID,
       REMARK)
    VALUES
      (SEQ_PPM_INTF_CODE_MAPPING_ID.NEXTVAL,
       'CRM',
       I_PROD_OFFER_ID,
       I_PROD_OFFER_NAME,
       '313',
       'PCRF',
       I_EXT_OFFER_NBR,
       'PROD_OFFER_ID',
       '销售品规格',
       '',
       '',
       'PPM自动配置');
    COMMIT;
    O_RESULT := 'TRUE';
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    O_RESULT := 'FALSE';
    O_MSG := SUBSTR(SQLERRM,1,500);
  END;

PROCEDURE PROC_PPM_SYNC_ATTR_AUTO_ADD(I_PROD_OFFER_ID   IN VARCHAR2,
                                      I_PROD_OFFER_NAME IN VARCHAR2,
                                      I_ATTR_ID         IN VARCHAR2,
                                      I_ATTR_DESC       IN VARCHAR2,
                                      O_RESULT          OUT VARCHAR2, --TRUE成功 FALSE失败
                                      O_MSG             OUT VARCHAR2) IS
  --失败信息
  V_COUNT NUMBER;
  V_REMARK  VARCHAR2(50);
BEGIN
  O_RESULT := 'FALSE';
  O_MSG    := '';
  IF I_PROD_OFFER_ID IS NULL THEN
    RETURN;
  END IF;
  IF I_ATTR_ID IS NULL THEN
    RETURN;
  END IF;
  IF I_ATTR_DESC IS NULL THEN
    RETURN;
  END IF;

  BEGIN
    SELECT COUNT(*)
      INTO V_COUNT
      FROM ATTR_VALUE A
     WHERE A.ATTR_VALUE = I_PROD_OFFER_ID
       AND A.ATTR_ID = I_ATTR_ID;

    IF V_COUNT > 0 THEN

    SELECT A.REMARK
      INTO V_REMARK
      FROM ATTR_VALUE A
     WHERE A.ATTR_VALUE = I_PROD_OFFER_ID
       AND A.ATTR_ID = I_ATTR_ID;

      UPDATE ATTR_VALUE A
         SET A.ATTR_VALUE_NAME = I_PROD_OFFER_NAME,
             A.ATTR_DESC       = I_ATTR_DESC,
             A.REMARK          =V_REMARK||';PPM自动配置'||SYSDATE
       where ATTR_VALUE = I_PROD_OFFER_ID
         AND ATTR_ID = I_ATTR_ID;
      COMMIT;
      O_RESULT := 'TRUE';
      RETURN;
    END IF;
  END;

  BEGIN
    INSERT INTO ATTR_VALUE
      (ATTR_VALUE_ID,
       ATTR_VALUE_NAME,
       ATTR_ID,
       ATTR_DESC,
       ATTR_VALUE_TYPE,
       ATTR_FORMAT,
       ATTR_LENGTH,
       ATTR_VALUE,
       MAX_VALUE,
       MIN_VALUE,
       STATUS_DATE,
       CREATE_DATE,
       STATUS_CD,
       PARENT_VALUE_ID,
       ATTR_VALUE_SEQ,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       REMARK,
       IS_TRANS,
       MANAGE_GRADE,
       EFF_DATE,
       EXP_DATE,
       GROUP_CD)
    VALUES
      (SEQ_ATTR_VALUE_ID.NEXTVAL,
       I_PROD_OFFER_NAME,
       I_ATTR_ID,
       I_ATTR_DESC,
       '',
       '',
       '',
       I_PROD_OFFER_ID,
       '',
       '',
       SYSDATE,
       SYSDATE,
       '1000',
       '',
       '',
       1,
       1,
       '',
       '',
       'PPM自动配置',
       '',
       '',
       null,
       null,
       '');
    COMMIT;
    O_RESULT := 'TRUE';
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_RESULT := 'FALSE';
      O_MSG    := SUBSTR(SQLERRM, 1, 500);
      RETURN;
  END;
END;

PROCEDURE SYNC_OFFER_TO_CRM_TEST(I_PROD_OFFER_ID   IN VARCHAR2,
                                 I_REMARK IN VARCHAR2,
                                 O_RESULT          OUT VARCHAR2, --TRUE成功 FALSE失败
                                 O_MSG             OUT VARCHAR2 --失败信息
                                 ) IS
  --失败信息
  V_REMARK  VARCHAR2(50);
  V_COUNT NUMBER;
BEGIN
  O_RESULT := 'FALSE';
  O_MSG    := '';
  IF I_PROD_OFFER_ID IS NULL THEN
    O_MSG :='传入的销售品ID为空';
    RETURN;
  END IF;

  BEGIN
    SELECT COUNT(*)
      INTO V_COUNT
      FROM prod_offer A
     WHERE A.prod_offer_id = I_PROD_OFFER_ID;

    IF V_COUNT > 0 THEN
      O_MSG :='该销售品已经配置，不能再同步测试数据';
      RETURN;
    END IF;
  END;

  BEGIN
    INSERT INTO prod_offer
    SELECT * FROM crm_ppm.prod_offer WHERE prod_offer_id = I_PROD_OFFER_ID;
    update prod_offer p set p.remark = I_REMARK,p.status_cd='1299' WHERE  prod_offer_id = I_PROD_OFFER_ID;
    COMMIT;
    O_RESULT := 'TRUE';
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_RESULT := 'FALSE';
      O_MSG    := SUBSTR(SQLERRM, 1, 500);
      RETURN;
  END;
END;
PROCEDURE SYNC_OFFER_MLTZ_TO_CRM(I_PROD_OFFER_ID   IN VARCHAR2,
                                 I_REMARK IN VARCHAR2,
                                 i_offer_catlg_loc_id IN VARCHAR2,
                                 O_RESULT          OUT VARCHAR2, --TRUE成功 FALSE失败
                                 O_MSG             OUT VARCHAR2 --失败信息
                                 ) IS
  --失败信息
  V_REMARK  VARCHAR2(50);
  V_COUNT NUMBER;
BEGIN
  O_RESULT := 'FALSE';
  O_MSG    := '';
  IF I_PROD_OFFER_ID IS NULL THEN
    O_MSG :='传入的销售品ID为空';
    RETURN;
  END IF;

  BEGIN
    UPDATE CRMV2.PROD_OFFER t1 SET (t1.prod_offer_name,t1.offer_nbr,t1.offer_type,t1.remark)=(SELECT t2.prod_offer_name,t2.offer_nbr,t2.offer_type,t1.remark||I_REMARK FROM CRM_PPM.PROD_OFFER t2 WHERE t1.prod_offer_id=t2.PROD_OFFER_ID)
           WHERE t1.prod_offer_id = I_PROD_OFFER_ID;
    IF i_offer_catlg_loc_id IS NOT NULL THEN
       UPDATE CRMV2.CATALOG_ITEM_ELEMENT t1 SET (t1.catalog_item_id,t1.remark) = (SELECT t2.catalog_item_id,t1.remark||I_REMARK FROM CRM_PPM.CATALOG_ITEM_ELEMENT t2 WHERE t1.offer_catlg_loc_id=t2.offer_catlg_loc_id)
           WHERE t1.offer_catlg_loc_id=i_offer_catlg_loc_id;
    END IF;
    COMMIT;
    O_RESULT := 'TRUE';
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_RESULT := 'FALSE';
      O_MSG    := SUBSTR(SQLERRM, 1, 500);
      RETURN;
  END;
END;


END PKG_PPM;
/
