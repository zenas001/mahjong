CREATE package body           crmv2_rules is

  --宽带帐号唯一性校验
  --product_id  产品规格ID
  --in_acc_nbr  帐号
  function chk_lan_nbr_exists(in_product_id   in number,
                              in_acc_nbr      in varchar2,
                              in_prod_inst_id in number, out_result out varchar2) return number is
    i_count number;

  begin
    if in_acc_nbr is null then
      return rule_result_pass;
    end if;


    select count(*)
      into i_count
      from prod_inst a
     where a.acc_nbr = in_acc_nbr
       and a.prod_inst_id <> in_prod_inst_id
       and a.status_cd != '11'
       and a.product_id = in_product_id;
    if (i_count > 0) then
      out_result := '业务号码' || in_acc_nbr || '唯一性校验';
      return rule_result_error;
    end if;
    return rule_result_pass;
  end;
  --III类客户不能订购任何销售品
  function chk_cust_so(in_cust_id   in number, in_offer_name in varchar2, out_result out varchar2) return number is
    i_count number;
  begin
    if in_cust_id is null then
      return rule_result_pass;
    end if;



    select count(*)
      into i_count
      from cust_spetial_list a
     where a.cust_id = in_cust_id
       and a.special_type = '12' and a.status_cd = '10';
    if (i_count > 0) then
      out_result := '本客户为III类客户不能订购' || in_offer_name;
      return rule_result_error;
    end if;
    return rule_result_pass;
  end;
begin
  -- Initialization
  null;
end crmv2_rules;
/
