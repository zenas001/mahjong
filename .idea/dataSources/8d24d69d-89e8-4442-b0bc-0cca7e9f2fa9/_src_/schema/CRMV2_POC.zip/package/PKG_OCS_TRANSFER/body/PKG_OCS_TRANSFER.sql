CREATE PACKAGE BODY           PKG_OCS_TRANSFER IS

  C_REC_CNT      CONSTANT      NUMBER := 3000 ;

  PROCEDURE PROC_EXTRACT_BILL_OCS_TRANSFER  IS
    V_INT        NUMBER(10) := 0;
    V_NUM        NUMBER(10) := 0;
    V_MIN_REC_ID CRM_OCS_TRANSFER_LOG.REC_ID%TYPE;
    V_MAX_REC_ID CRM_OCS_TRANSFER_LOG.REC_ID%TYPE;
    V_BEGIN_DATE DATE;
  BEGIN
    SELECT SYSDATE INTO V_BEGIN_DATE FROM DUAL;
    FOR REC IN (SELECT REC_ID
                  FROM (SELECT REC_ID
                          FROM BILL_OCS_TRANSFER_LOG
                         WHERE CRM_STATE IS NULL --记录创建时为空    1AS 处理成功 1AF 处理失败 1AN 取数成功
                           AND PF_STATE  = '1AS'  --PF处理成功
                         ORDER BY REC_ID )
                 WHERE ROWNUM < C_REC_CNT) LOOP
      V_INT := V_INT + 1;
      V_NUM := V_NUM + 1;
      if V_NUM = 1 then
        V_MIN_REC_ID := REC.REC_ID;
      end if;
      V_MAX_REC_ID := REC.REC_ID;
      BEGIN
        INSERT INTO CRM_OCS_TRANSFER_LOG
          ( REC_ID  ,
            ACC_NBR  ,
            AREA_CODE  ,
            TRANSFER_TYPE  ,
            CREATED_DATE  ,
            STAFF_ID  ,
            CURRENT_CREDIT_LEVEL  ,
            CURRENT_CREDIT_LEVEL_SCORE  ,
            CURRENT_BALANCE_SCORE  ,
            CURRENT_SCORE_LOWER_LIMIT  ,
            CURRENT_SCORE_FLOAT  ,
            PF_STATE  ,
            PF_STATE_DATE  ,
            PF_RESULT_INFO  ,
            CRM_STATE  ,
            CRM_STATE_DATE  ,
            CRM_RESULT_INFO  ,
            VSOP_STATE  ,
            VSOP_STATE_DATE  ,
            VSOP_RESULT_INFO  ,
            REMARK,
            SERV_ID   )
          SELECT REC_ID  ,
            ACC_NBR  ,
            AREA_CODE  ,
            TRANSFER_TYPE  ,
            CREATED_DATE  ,
            STAFF_ID  ,
            CURRENT_CREDIT_LEVEL  ,
            CURRENT_CREDIT_LEVEL_SCORE  ,
            CURRENT_BALANCE_SCORE  ,
            CURRENT_SCORE_LOWER_LIMIT  ,
            CURRENT_SCORE_FLOAT  ,
            PF_STATE  ,
            PF_STATE_DATE  ,
            PF_RESULT_INFO  ,
            '1AN' CRM_STATE  ,
            --crm00058934 FJCRMV2.0_BUG_福建省_class_id为空导致外网接口异常  qiurl 20141107
            SYSDATE CRM_STATE_DATE  ,
            CRM_RESULT_INFO  ,
            VSOP_STATE  ,
            VSOP_STATE_DATE  ,
            VSOP_RESULT_INFO  ,
            REMARK,
            SERV_ID
            FROM BILL_OCS_TRANSFER_LOG
           WHERE REC_ID = REC.REC_ID;

        UPDATE BILL_OCS_TRANSFER_LOG
           SET CRM_STATE = '1AN', CRM_STATE_DATE = SYSDATE
         WHERE REC_ID = REC.REC_ID;

      EXCEPTION
        WHEN OTHERS THEN
          UPDATE BILL_OCS_TRANSFER_LOG
             SET CRM_STATE = '1AF', CRM_STATE_DATE = SYSDATE,REMARK = '取数失败'
           WHERE REC_ID = REC.REC_ID;
      END;

      IF V_INT > 1000 THEN
        COMMIT;
        V_INT := 0;
      END IF;
    END LOOP;
    COMMIT;

    INSERT INTO INTF_OCS_TRANSFER_DEAL_LOG
    ( LOG_ID,
      MIN_REC_ID,
      MAX_REC_ID,
      EXTRACT_NUM,
      BEGIN_DATE,
      END_TIME)
   VALUES( SEQ_INTF_OCS_TRANSFER_DEAL_LOG.NEXTVAL,
      V_MIN_REC_ID,
      V_MAX_REC_ID,
      V_NUM,
      V_BEGIN_DATE,
      SYSDATE);
   COMMIT;

  END;

  PROCEDURE PROC_LOAD_CRM_OCS_TRANSFER(I_RET_ID           IN NUMBER,  --TFJ_ACC_NBR表的主键
                                       I_PROD_INST_ID     IN NUMBER, --产品实例
                                       I_TRANSFER_TYPE    IN VARCHAR2  --转换类型 O2H –从OCS卸载；H2O –加载到OCS；
                                ) IS
    V_CUST_ORDER_ID      CRM_OCS_TRANSFER_LOG.CUST_ORDER_ID%TYPE;
    V_CRM_STATE          CRM_OCS_TRANSFER_LOG.CRM_STATE%TYPE;
    V_ERR_CODE           INTEGER := 0;
    V_ERR_MSG            CRM_OCS_TRANSFER_LOG.REMARK%TYPE;
  BEGIN
    V_ERR_MSG := '';
    V_CUST_ORDER_ID := 0;
    BEGIN
      PKG_OCS_TRANSFER.SP_OCS_TRANSFER_REQUEST(I_RET_ID,
                                               I_PROD_INST_ID,
                                               I_TRANSFER_TYPE,
                                               V_CUST_ORDER_ID );
    EXCEPTION  WHEN OTHERS THEN
        ROLLBACK;
        V_ERR_CODE := 1;
        V_ERR_MSG  := 'PROC_LOAD_CRM_OCS_TRANSFER:' || SUBSTR(SQLERRM, 1, 100);
    END;

    IF V_ERR_CODE = 0 THEN
      V_CRM_STATE := '1AS';
    ELSE
      V_CRM_STATE := '1AF';
    END IF;

    BEGIN
      UPDATE CRM_OCS_TRANSFER_LOG
         SET CRM_STATE      = V_CRM_STATE,
             CRM_STATE_DATE = SYSDATE,
             CUST_ORDER_ID  = V_CUST_ORDER_ID,
             CRM_RESULT_INFO = V_ERR_MSG
       WHERE REC_ID = I_RET_ID;
      UPDATE BILL_OCS_TRANSFER_LOG
         SET CRM_STATE      = V_CRM_STATE,
             CRM_STATE_DATE = SYSDATE,
             CRM_RESULT_INFO = V_ERR_MSG
       WHERE REC_ID = I_RET_ID;
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  END;

  PROCEDURE SP_OCS_TRANSFER_REQUEST(I_RET_ID           IN NUMBER,
                                    I_PROD_INST_ID        IN NUMBER, --产品实例
                                    I_TRANSFER_TYPE       IN VARCHAR2, --转换类型
                                    O_CUST_ORDER_ID       OUT NUMBER )      IS
    --V_TAR_PAYMENT_MODE_CD   PROD_INST.PAYMENT_MODE_CD%TYPE;
    V_PROD_INST_ATTR        PROD_INST_ATTR%ROWTYPE;
    V_CUR_ATTR_VALUE        PROD_INST_ATTR.ATTR_VALUE%TYPE;
    V_ATTR_VALUE_OPERATE    ORDER_ITEM_PROC_ATTR.OPERATE%TYPE;
    V_PROD_INST             PROD_INST%ROWTYPE;
    V_PROD_OFFER_INST       PROD_OFFER_INST%ROWTYPE;
    V_AOC_PROD_INST         PROD_INST%ROWTYPE;
    V_AOC_PROD_INST_ATTR    PROD_INST_ATTR%ROWTYPE;
    V_PROD_INST_REL         PROD_INST_REL%ROWTYPE;
    V_CUSTOMER_ORDER_HIS    CUSTOMER_ORDER_HIS%ROWTYPE;
    V_ORDER_ITEM_HIS        ORDER_ITEM_HIS%ROWTYPE;
    V_OFFER_PROD_INST_REL   OFFER_PROD_INST_REL%ROWTYPE;
  BEGIN

    /*后付费  1200
    预付费  1201
    预付费（OCS）  2100
    --------------------------
    O2H –从OCS卸载；    改为 1201
    H2O –加载到OCS      改为 2100
    预改后：改为1201
    后改预：改为2100
    */
    /*  crm00061958
    计费发起预改后，则将‘是否信控’属性取值由‘是’改为‘否’（若号码上无此属性，则新增‘是否信控’属性，取值为‘否’）；
    计费发起后改预，则将‘是否信控’属性取值由‘否’改为‘是’（若号码上无此属性，则新增‘是否信控’属性，取值为‘是’）；
    attr_name = '是否信控'; --attr_id = 800072702
    900071775	否	10
    900071776	是	20
    O2H –从OCS卸载；    attr_value_id = 900071775  attr_value = 10
    H2O –加载到OCS      attr_value_id = 900071776  attr_value = 20
    */
    BEGIN
      SELECT * INTO V_PROD_INST
        FROM PROD_INST
       WHERE PROD_INST_ID = I_PROD_INST_ID
         AND STATUS_CD != 110000;
    EXCEPTION WHEN OTHERS THEN
       RAISE_APPLICATION_ERROR(-20101, '查档案出错!');
    END;
    BEGIN
      SELECT *
        INTO V_PROD_INST_ATTR
        FROM PROD_INST_ATTR
       WHERE PROD_INST_ID = I_PROD_INST_ID
         AND ATTR_ID = 800072702
         AND STATUS_CD != 1100;
       V_ATTR_VALUE_OPERATE := '11';
       V_CUR_ATTR_VALUE  := V_PROD_INST_ATTR.ATTR_VALUE;
    EXCEPTION WHEN OTHERS THEN
     SELECT  SEQ_PROD_INST_ATTR_ID.NEXTVAL INTO V_PROD_INST_ATTR.PROD_INST_ATTR_ID  FROM DUAL;
      V_PROD_INST_ATTR.PROD_INST_ID := V_PROD_INST.PROD_INST_ID;
      V_PROD_INST_ATTR.ATTR_ID := 800072702;
      V_PROD_INST_ATTR.STATUS_CD := 1000;
      V_PROD_INST_ATTR.STATUS_DATE := SYSDATE;
      V_PROD_INST_ATTR.EFF_DATE := SYSDATE;
      V_PROD_INST_ATTR.EXP_DATE := TO_DATE('21991230 23:59:59','YYYYMMDD HH24:MI:SS');
      V_PROD_INST_ATTR.CREATE_DATE := SYSDATE;
      V_PROD_INST_ATTR.UPDATE_DATE := SYSDATE;
      V_PROD_INST_ATTR.AREA_ID := V_PROD_INST.AREA_ID;
      V_PROD_INST_ATTR.REGION_CD := V_PROD_INST.COMMON_REGION_ID;
      V_PROD_INST_ATTR.UPDATE_STAFF := PKG_CONSTANTS.JK_STAFF_ID;
      V_PROD_INST_ATTR.CREATE_STAFF := PKG_CONSTANTS.JK_STAFF_ID;
      V_PROD_INST_ATTR.REC_UPDATE_DATE := NULL;
      V_PROD_INST_ATTR.VERSION := 0;
      V_PROD_INST_ATTR.ATTR_VALUE_ID := 0;
      V_PROD_INST_ATTR.ATTR_VALUE := 'NULL';
      V_CUR_ATTR_VALUE := NULL;
      V_ATTR_VALUE_OPERATE := '10';
    END;
/*    IF I_TRANSFER_TYPE = 'H2O' AND V_PROD_INST.PAYMENT_MODE_CD = '2100'  THEN
        RAISE_APPLICATION_ERROR(-20101, '该产品实例已经是预付费（OCS）!');
    END IF;
    IF I_TRANSFER_TYPE = 'O2H' AND V_PROD_INST.PAYMENT_MODE_CD = '1201'  THEN
       RAISE_APPLICATION_ERROR(-20101, '该产品实例已经是预付费!');
    END IF;*/
    IF I_TRANSFER_TYPE = 'H2O' AND V_PROD_INST_ATTR.ATTR_VALUE = '20'  THEN
        RAISE_APPLICATION_ERROR(-20101, '该产品实例‘是否信控’属性取值已经是‘是’!');
    END IF;
    IF I_TRANSFER_TYPE = 'O2H' AND V_PROD_INST_ATTR.ATTR_VALUE = '10'  THEN
        RAISE_APPLICATION_ERROR(-20101, '该产品实例‘是否信控’属性取值已经是‘否’!');
    END IF;

    IF I_TRANSFER_TYPE = 'H2O' THEN
      --V_TAR_PAYMENT_MODE_CD := '2100';
      V_PROD_INST_ATTR.ATTR_VALUE_ID := 900071776;
      V_PROD_INST_ATTR.ATTR_VALUE := '20';
    ELSE
      --V_TAR_PAYMENT_MODE_CD := '1201';
      V_PROD_INST_ATTR.ATTR_VALUE_ID := 900071775;
      V_PROD_INST_ATTR.ATTR_VALUE := '10';
    END IF;

    --生成PF_OCS_TRANSFER_LOG数据
    --PROC_PF_OCS_TRANSFER_LOG(I_RET_ID,V_PROD_INST,V_TAR_PAYMENT_MODE_CD);
    PROC_PF_OCS_TRANSFER_LOG(I_RET_ID,V_PROD_INST,'',I_TRANSFER_TYPE );
    --生成CUSTOMER_ORDER_HIS数据
    PROC_CUSTOMER_ORDER_HIS(V_CUSTOMER_ORDER_HIS,V_PROD_INST);
    V_ORDER_ITEM_HIS.CUST_ORDER_ID := V_CUSTOMER_ORDER_HIS.CUST_ORDER_ID;

    --插销售品订单项
    BEGIN
      SELECT POI.* INTO V_PROD_OFFER_INST
        FROM OFFER_PROD_INST_REL R,PROD_OFFER_INST POI,PROD_OFFER PO
       WHERE POI.PROD_OFFER_INST_ID = R.PROD_OFFER_INST_ID
         AND PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
         AND R.PROD_INST_ID = V_PROD_INST.PROD_INST_ID
         AND PO.OFFER_TYPE IN ('10', '11')
         AND POI.STATUS_CD = '1000'
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20102, '找不到销售品实例');
    END;
    --销售品定单项数据
    PROC_ORDER_ITEM_HIS(V_ORDER_ITEM_HIS,'1200',503,V_PROD_OFFER_INST,V_PROD_INST);
    PROC_ORDER_ITEM_ACT_RELA_HIS(V_ORDER_ITEM_HIS,503,'A');
    --产品定单项数据
    PROC_ORDER_ITEM_HIS(V_ORDER_ITEM_HIS,'1300',24,V_PROD_OFFER_INST,V_PROD_INST);
    --PROC_ORDER_ITEM_ACT_RELA_HIS(V_ORDER_ITEM_HIS,997,'N');
    PROC_ORDER_ITEM_ACT_RELA_HIS(V_ORDER_ITEM_HIS,24,'A');
    PROC_ORDER_ITEM_PROC_ATTR_HIS(V_ORDER_ITEM_HIS,
                                  V_ATTR_VALUE_OPERATE ,
                                   V_PROD_INST_ATTR.ATTR_VALUE ,
                                   V_CUR_ATTR_VALUE ,
                                   800072702 );
    --IVPN_NBR表的处理
    PROC_IVPN_NBR(I_RET_ID,V_PROD_INST,V_ORDER_ITEM_HIS.ORDER_ITEM_ID,I_TRANSFER_TYPE);
    V_PROD_INST.PROC_SERIAL := V_ORDER_ITEM_HIS.ORDER_ITEM_ID;
    --主接入类产品实例处理
    PROC_PROD_INST(V_PROD_INST, NULL,NULL );

    --属性处理
    V_PROD_INST_ATTR.PROC_SERIAL := V_ORDER_ITEM_HIS.ORDER_ITEM_ID;
    PROC_PROD_INST_ATTR(V_PROD_INST_ATTR,V_ATTR_VALUE_OPERATE);

   --若：办理的预改后，且号码上有开通‘计费提醒服务（AOC）’功能，程序在改付费方式后还要自动删除档案上的‘计费提醒服务（AOC）’功能
    IF I_TRANSFER_TYPE = 'O2H' THEN
      BEGIN
        SELECT A.*
          INTO V_PROD_INST_REL
          FROM PROD_INST_REL A,PROD_INST B
         WHERE A.PROD_INST_A_ID = I_PROD_INST_ID
           AND A.PROD_INST_Z_ID = B.PROD_INST_ID
           AND A.STATUS_CD != '1100'
           AND B.STATUS_CD != '110000'
           AND B.PRODUCT_ID = 800000479
           AND ROWNUM = 1 ; -- 计费提醒服务（AOC）
        SELECT B.*
          INTO V_AOC_PROD_INST
          FROM PROD_INST_REL A,PROD_INST B
         WHERE A.PROD_INST_A_ID = I_PROD_INST_ID
           AND A.PROD_INST_Z_ID = B.PROD_INST_ID
           AND A.STATUS_CD != '1100'
           AND B.STATUS_CD != '110000'
           AND B.PRODUCT_ID = 800000479
           AND ROWNUM = 1; -- 计费提醒服务（AOC）
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END;
      IF V_AOC_PROD_INST.PROD_INST_ID  IS NOT NULL AND V_PROD_INST_REL.PROD_INST_REL_ID IS NOT NULL THEN
        --主接入类补两条
        PROC_ORDER_ITEM_ACT_RELA_HIS(V_ORDER_ITEM_HIS,209,'N');
        PROC_ORDER_ITEM_PROC_ATTR_HIS(V_ORDER_ITEM_HIS,
                                      '12' ,
                                       NULL ,
                                       V_PROD_INST_REL.PROD_INST_REL_ID ,
                                      5381 );

        --找AOC销售品订单项
        BEGIN
          SELECT POI.* INTO V_PROD_OFFER_INST
            FROM OFFER_PROD_INST_REL R,PROD_OFFER_INST POI,PROD_OFFER PO
           WHERE POI.PROD_OFFER_INST_ID = R.PROD_OFFER_INST_ID
             AND PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
             AND R.PROD_INST_ID = V_AOC_PROD_INST.PROD_INST_ID
             AND PO.PROD_OFFER_ID = 800001103
             AND POI.STATUS_CD = '1000'
             AND ROWNUM = 1;
          SELECT R.*
            INTO V_OFFER_PROD_INST_REL
            FROM OFFER_PROD_INST_REL R,PROD_OFFER_INST POI,PROD_OFFER PO
           WHERE POI.PROD_OFFER_INST_ID = R.PROD_OFFER_INST_ID
             AND PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
             AND R.PROD_INST_ID = V_AOC_PROD_INST.PROD_INST_ID
             AND PO.PROD_OFFER_ID = 800001103
             AND POI.STATUS_CD = '1000'
             AND ROWNUM = 1;
        EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20102, 'AOC产品实例找不到对应的销售品实例');
        END;
        --插入AOC销售品订单项
        PROC_ORDER_ITEM_HIS(V_ORDER_ITEM_HIS,'1200',501,V_PROD_OFFER_INST,V_PROD_INST);
        PROC_ORDER_ITEM_ACT_RELA_HIS(V_ORDER_ITEM_HIS,501,'A');
        PROC_ORDER_ITEM_PROC_ATTR_HIS(V_ORDER_ITEM_HIS,
                                      '12' ,
                                       NULL ,
                                       V_PROD_INST_REL.PROD_INST_REL_ID ,
                                       5062 );
        --插入AOC产品订单项
        PROC_ORDER_ITEM_HIS(V_ORDER_ITEM_HIS,'1300',101,V_PROD_OFFER_INST,V_AOC_PROD_INST);
        PROC_ORDER_ITEM_ACT_RELA_HIS(V_ORDER_ITEM_HIS,101,'A');
        PROC_ORDER_ITEM_PROC_ATTR_HIS(V_ORDER_ITEM_HIS,
                                      '12' ,
                                       NULL ,
                                       V_OFFER_PROD_INST_REL.OFFER_PROD_INST_REL_ID ,
                                      -5382 );
        PROC_ORDER_ITEM_PROC_ATTR_HIS(V_ORDER_ITEM_HIS,
                                      '12' ,
                                       NULL ,
                                       V_PROD_INST_REL.PROD_INST_REL_ID ,
                                      -5381 );
        PROC_PROD_INST(V_AOC_PROD_INST, NULL ,'110000' );
        BEGIN
          SELECT * INTO V_AOC_PROD_INST_ATTR
            FROM PROD_INST_ATTR
           WHERE PROD_INST_ID = V_AOC_PROD_INST.PROD_INST_ID
             AND ATTR_ID = 800001693
             AND STATUS_CD != '1100'
             AND ROWNUM = 1;
        EXCEPTION WHEN OTHERS THEN
           NULL;
        END;
        if V_AOC_PROD_INST_ATTR.PROD_INST_ATTR_ID IS NOT NULL then
          PROC_PROD_INST_ATTR(V_AOC_PROD_INST_ATTR,'12' );
        end if;

        PROC_PROD_INST_REL(V_PROD_INST_REL );
        PROC_OFFER_PROD_INST_REL(V_OFFER_PROD_INST_REL );
        PROC_PROD_OFFER_INST(V_PROD_OFFER_INST);
      END IF;
    END IF;
    --crm00057424  FJCRMV2.0_BUG_福建省_OCS动态加载 qiurl 20141024
/*    BEGIN
      PKG_OCS_FINISH.PROC_ORDER_FINISH_NOTIFY(V_CUSTOMER_ORDER_HIS.CUST_ORDER_ID);
    EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20102, 'PKG_OCS_FINISH'|| SUBSTR(SQLERRM,1,200) );
    END;*/
    O_CUST_ORDER_ID := V_CUSTOMER_ORDER_HIS.CUST_ORDER_ID;
  END;

  /*-------------------------------------------------
      功能: 处理产品实例
    -------------------------------------------------*/
  PROCEDURE PROC_PROD_INST(I_PROD_INST         IN   PROD_INST%ROWTYPE,--产品实例
                           I_PAYMENT_MODE_CD   IN   VARCHAR2,  --产品状态, 该参数为NULL时, 不修改产品实例状态
                           I_STATUS_CD         IN   PROD_INST.STATUS_CD%TYPE
                                   )
   IS
    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;
    V_NEW_STATUS_DATE DATE;
    V_CHANNEL_NAME    CHANNEL.CHANNEL_NAME%TYPE;
  BEGIN

    V_NEW_STATUS_DATE := SYSDATE;
    --产品实例移到2表
    INSERT INTO PROD_INST_HIS
      (PROD_INST_ID,
       PRODUCT_ID,
       ACC_PROD_INST_ID,
       ADDRESS_ID,
       OWNER_CUST_ID,
       PAYMENT_MODE_CD,
       PRODUCT_PASSWORD,
       IMPORTANT_LEVEL,
       AREA_CODE,
       ACC_NBR,
       EXCH_ID,
       COMMON_REGION_ID,
       REMARK,
       PAY_CYCLE,
       BEGIN_RENT_TIME,
       STOP_RENT_TIME,
       FINISH_TIME,
       STOP_STATUS,
       STATUS_CD,
       CREATE_DATE,
       STATUS_DATE,
       UPDATE_DATE,
       PROC_SERIAL,
       USE_CUST_ID,
       EXT_PROD_INST_ID,
       ADDRESS_DESC,
       AREA_ID,
       UPDATE_STAFF,
       CREATE_STAFF,
       HIS_ID,
       REC_UPDATE_DATE,
       ACCOUNT,
       COMMUNITY_ID,
       VERSION,
       EXT_ACC_PROD_INST_ID)
      SELECT I_PROD_INST.PROD_INST_ID, --PROD_INST_ID,
             I_PROD_INST.PRODUCT_ID, --PRODUCT_ID,
             I_PROD_INST.ACC_PROD_INST_ID, --ACC_PROD_INST_ID,
             I_PROD_INST.ADDRESS_ID, --ADDRESS_ID,
             I_PROD_INST.OWNER_CUST_ID, --OWNER_CUST_ID,
             I_PROD_INST.PAYMENT_MODE_CD, --PAYMENT_MODE_CD,
             I_PROD_INST.PRODUCT_PASSWORD, --PRODUCT_PASSWORD,
             I_PROD_INST.IMPORTANT_LEVEL, --IMPORTANT_LEVEL,
             I_PROD_INST.AREA_CODE, --AREA_CODE,
             I_PROD_INST.ACC_NBR, --ACC_NBR,
             I_PROD_INST.EXCH_ID, --EXCH_ID,
             I_PROD_INST.COMMON_REGION_ID, --COMMON_REGION_ID,
             I_PROD_INST.REMARK, --REMARK,
             I_PROD_INST.PAY_CYCLE, --PAY_CYCLE,
             I_PROD_INST.BEGIN_RENT_TIME, --BEGIN_RENT_TIME,
             I_PROD_INST.STOP_RENT_TIME, --STOP_RENT_TIME,
             V_NEW_STATUS_DATE,--I_PROD_INST.FINISH_TIME, --FINISH_TIME,
             I_PROD_INST.STOP_STATUS, --STOP_STATUS,
             I_PROD_INST.STATUS_CD, --STATUS_CD,
             I_PROD_INST.CREATE_DATE, --CREATE_DATE,
             I_PROD_INST.STATUS_DATE, --STATUS_DATE,
             V_NEW_STATUS_DATE, --UPDATE_DATE,
             I_PROD_INST.PROC_SERIAL, --PROC_SERIAL,
             I_PROD_INST.USE_CUST_ID, --USE_CUST_ID,
             I_PROD_INST.EXT_PROD_INST_ID, --EXT_PROD_INST_ID,
             I_PROD_INST.ADDRESS_DESC, --ADDRESS_DESC,
             I_PROD_INST.AREA_ID, --AREA_ID,
             I_PROD_INST.UPDATE_STAFF, --UPDATE_STAFF,
             I_PROD_INST.CREATE_STAFF, --CREATE_STAFF,
             SEQ_PROD_INST_HIS_ID.NEXTVAL, --HIS_ID,
             V_NEW_STATUS_DATE, --REC_UPDATE_DATE,
             I_PROD_INST.ACCOUNT, --ACCOUNT,
             I_PROD_INST.COMMUNITY_ID, --COMMUNITY_ID,
             I_PROD_INST.VERSION, --VERSION,
             I_PROD_INST.EXT_ACC_PROD_INST_ID --EXT_ACC_PROD_INST_ID
        FROM DUAL ;

    --改产品实例
    UPDATE PROD_INST PI
       SET PI.UPDATE_DATE  = V_NEW_STATUS_DATE,
           PI.PAYMENT_MODE_CD = NVL(I_PAYMENT_MODE_CD,PI.PAYMENT_MODE_CD),
           PI.STATUS_CD = NVL(I_STATUS_CD,PI.STATUS_CD),
           PI.STATUS_DATE  = V_NEW_STATUS_DATE,
           PI.UPDATE_STAFF = PKG_CONSTANTS.JK_STAFF_ID,
           PI.VERSION =  PI.VERSION + 1
     WHERE PI.PROD_INST_ID = I_PROD_INST.PROD_INST_ID;

    --插INTF_INS_BILLING_UPDATE表
    BEGIN
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
      FROM AREA_CODE A, COMMON_REGION B
     WHERE A.REGION_ID = B.COMMON_REGION_ID
       AND B.COMMON_REGION_ID = I_PROD_INST.AREA_ID ;

      SELECT C.CHANNEL_NAME
        INTO V_CHANNEL_NAME
        FROM CHANNEL C
       WHERE C.CHANNEL_NBR = OCS_TRANSFER_CHANNEL_NBR
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'PROD_INST',
                                            I_COLUMN_NAME => 'PROD_INST_ID',
                                            I_KEY_ID      => I_PROD_INST.PROD_INST_ID,
                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),
                                            I_TYPE        => '1004',
                                            I_REASON      => NULL,
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20102,
                              '把产品实例信息移到二表失败.' || SQLERRM);
  END;

  PROCEDURE PROC_PROD_INST_ATTR(I_PROD_INST_ATTR         IN   PROD_INST_ATTR%ROWTYPE, --产品实例
                                I_OPERATE                IN   VARCHAR2   )
   IS
    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;
    V_NEW_STATUS_DATE DATE;
    V_CHANNEL_NAME    CHANNEL.CHANNEL_NAME%TYPE;
  BEGIN

    V_NEW_STATUS_DATE := SYSDATE;
    IF I_OPERATE = '10' THEN
      INSERT INTO PROD_INST_ATTR
      ( PROD_INST_ATTR_ID	,
        PROD_INST_ID	,
        ATTR_ID	,
        ATTR_VALUE_ID	,
        ATTR_VALUE	,
        STATUS_CD	,
        STATUS_DATE	,
        EFF_DATE	,
        EXP_DATE	,
        CREATE_DATE	,
        UPDATE_DATE	,
        PROC_SERIAL	,
        AREA_ID	,
        REGION_CD	,
        UPDATE_STAFF	,
        CREATE_STAFF	,
        REC_UPDATE_DATE	,
        VERSION	 )
      VALUES
      ( I_PROD_INST_ATTR.PROD_INST_ATTR_ID,
        I_PROD_INST_ATTR.PROD_INST_ID,
        I_PROD_INST_ATTR.ATTR_ID,
        I_PROD_INST_ATTR.ATTR_VALUE_ID,
        I_PROD_INST_ATTR.ATTR_VALUE,
        I_PROD_INST_ATTR.STATUS_CD,
        I_PROD_INST_ATTR.STATUS_DATE,
        I_PROD_INST_ATTR.EFF_DATE,
        I_PROD_INST_ATTR.EXP_DATE,
        I_PROD_INST_ATTR.CREATE_DATE,
        I_PROD_INST_ATTR.UPDATE_DATE,
        I_PROD_INST_ATTR.PROC_SERIAL,
        I_PROD_INST_ATTR.AREA_ID,
        I_PROD_INST_ATTR.REGION_CD,
        I_PROD_INST_ATTR.UPDATE_STAFF,
        I_PROD_INST_ATTR.CREATE_STAFF,
        I_PROD_INST_ATTR.REC_UPDATE_DATE,
        I_PROD_INST_ATTR.VERSION);

	  ELSIF I_OPERATE = '11' THEN
      INSERT INTO PROD_INST_ATTR_HIS
      ( PROD_INST_ATTR_ID  ,
        PROD_INST_ID  ,
        ATTR_ID  ,
        ATTR_VALUE_ID  ,
        ATTR_VALUE  ,
        STATUS_CD  ,
        STATUS_DATE  ,
        EFF_DATE  ,
        EXP_DATE  ,
        CREATE_DATE  ,
        UPDATE_DATE  ,
        PROC_SERIAL  ,
        AREA_ID  ,
        REGION_CD  ,
        UPDATE_STAFF  ,
        CREATE_STAFF  ,
        HIS_ID  ,
        REC_UPDATE_DATE  ,
        VERSION  )
      SELECT A.PROD_INST_ATTR_ID  ,
        A.PROD_INST_ID  ,
        A.ATTR_ID  ,
        A.ATTR_VALUE_ID  ,
        A.ATTR_VALUE  ,
        A.STATUS_CD  ,
        A.STATUS_DATE  ,
        A.EFF_DATE  ,
        V_NEW_STATUS_DATE  ,  --EXP_DATE
        A.CREATE_DATE  ,
        V_NEW_STATUS_DATE  ,  --UPDATE_DATE
        A.PROC_SERIAL  ,
        A.AREA_ID  ,
        A.REGION_CD  ,
        A.UPDATE_STAFF  ,
        A.CREATE_STAFF  ,
        SEQ_PROD_INST_ATTR_HIS_ID.NEXTVAL  ,
        V_NEW_STATUS_DATE  ,  --REC_UPDATE_DATE
        A.VERSION
        FROM PROD_INST_ATTR A
       WHERE PROD_INST_ATTR_ID = I_PROD_INST_ATTR.PROD_INST_ATTR_ID ;

      --改产品实例
      UPDATE PROD_INST_ATTR
         SET ATTR_VALUE_ID = I_PROD_INST_ATTR.ATTR_VALUE_ID,
             ATTR_VALUE = I_PROD_INST_ATTR.ATTR_VALUE,
             EFF_DATE = V_NEW_STATUS_DATE,
             EXP_DATE = I_PROD_INST_ATTR.EXP_DATE,
             STATUS_DATE = V_NEW_STATUS_DATE,
             UPDATE_DATE = V_NEW_STATUS_DATE,
             UPDATE_STAFF =  PKG_CONSTANTS.JK_STAFF_ID
       WHERE PROD_INST_ATTR_ID = I_PROD_INST_ATTR.PROD_INST_ATTR_ID;

    ELSIF I_OPERATE = '12' THEN
      --产品实例移到2表
      INSERT INTO PROD_INST_ATTR_HIS
      ( PROD_INST_ATTR_ID  ,
        PROD_INST_ID  ,
        ATTR_ID  ,
        ATTR_VALUE_ID  ,
        ATTR_VALUE  ,
        STATUS_CD  ,
        STATUS_DATE  ,
        EFF_DATE  ,
        EXP_DATE  ,
        CREATE_DATE  ,
        UPDATE_DATE  ,
        PROC_SERIAL  ,
        AREA_ID  ,
        REGION_CD  ,
        UPDATE_STAFF  ,
        CREATE_STAFF  ,
        HIS_ID  ,
        REC_UPDATE_DATE  ,
        VERSION  )
      SELECT I_PROD_INST_ATTR.PROD_INST_ATTR_ID  ,
        I_PROD_INST_ATTR.PROD_INST_ID  ,
        I_PROD_INST_ATTR.ATTR_ID  ,
        I_PROD_INST_ATTR.ATTR_VALUE_ID  ,
        I_PROD_INST_ATTR.ATTR_VALUE  ,
        I_PROD_INST_ATTR.STATUS_CD  ,
        I_PROD_INST_ATTR.STATUS_DATE  ,
        I_PROD_INST_ATTR.EFF_DATE  ,
        V_NEW_STATUS_DATE  ,  --EXP_DATE
        I_PROD_INST_ATTR.CREATE_DATE  ,
        V_NEW_STATUS_DATE  ,  --UPDATE_DATE
        I_PROD_INST_ATTR.PROC_SERIAL  ,
        I_PROD_INST_ATTR.AREA_ID  ,
        I_PROD_INST_ATTR.REGION_CD  ,
        I_PROD_INST_ATTR.UPDATE_STAFF  ,
        I_PROD_INST_ATTR.CREATE_STAFF  ,
        SEQ_PROD_INST_ATTR_HIS_ID.NEXTVAL  ,
        V_NEW_STATUS_DATE  ,  --REC_UPDATE_DATE
        I_PROD_INST_ATTR.VERSION
        FROM DUAL ;

      --改产品实例
      DELETE FROM PROD_INST_ATTR PIA
       WHERE PIA.PROD_INST_ATTR_ID = I_PROD_INST_ATTR.PROD_INST_ATTR_ID;

    END IF;

    --插INTF_INS_BILLING_UPDATE表
    BEGIN
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
      FROM AREA_CODE A, COMMON_REGION B
     WHERE A.REGION_ID = B.COMMON_REGION_ID
       AND B.COMMON_REGION_ID = I_PROD_INST_ATTR.AREA_ID ;

      SELECT C.CHANNEL_NAME
        INTO V_CHANNEL_NAME
        FROM CHANNEL C
       WHERE C.CHANNEL_NBR = OCS_TRANSFER_CHANNEL_NBR
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'PROD_INST_ATTR',
                                            I_COLUMN_NAME => 'PROD_INST_ATTR_ID',
                                            I_KEY_ID      => I_PROD_INST_ATTR.PROD_INST_ATTR_ID,
                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),
                                            I_TYPE        => '1004',
                                            I_REASON      => NULL,
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20102,
                              '把产品实例信息移到二表失败.' || SQLERRM);
  END;


  PROCEDURE PROC_PROD_INST_REL (I_PROD_INST_REL IN   PROD_INST_REL%ROWTYPE  --产品实例
                                   ) IS

    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;
    V_NEW_STATUS_DATE DATE;
    V_CHANNEL_NAME    CHANNEL.CHANNEL_NAME%TYPE;
  BEGIN

    V_NEW_STATUS_DATE := SYSDATE;

    --产品实例移到2表
    INSERT INTO PROD_INST_REL_HIS
      (PROD_INST_REL_ID  ,
        PROD_INST_A_ID  ,
        PROD_INST_Z_ID  ,
        RELATION_TYPE_CD  ,
        PROD_INST_REL_ROLE_ID  ,
        ROLE_CD  ,
        EFF_DATE  ,
        EXP_DATE  ,
        CREATE_DATE  ,
        STATUS_CD  ,
        STATUS_DATE  ,
        UPDATE_DATE  ,
        PROC_SERIAL  ,
        PRODUCT_REL_ID  ,
        AREA_ID  ,
        REGION_CD  ,
        UPDATE_STAFF  ,
        CREATE_STAFF  ,
        HIS_ID  ,
        REC_UPDATE_DATE
        )
      SELECT I_PROD_INST_REL.PROD_INST_REL_ID  ,
              I_PROD_INST_REL.PROD_INST_A_ID  ,
              I_PROD_INST_REL.PROD_INST_Z_ID  ,
              I_PROD_INST_REL.RELATION_TYPE_CD  ,
              I_PROD_INST_REL.PROD_INST_REL_ROLE_ID  ,
              I_PROD_INST_REL.ROLE_CD  ,
              I_PROD_INST_REL.EFF_DATE  ,
              V_NEW_STATUS_DATE  ,  --EXP_DATE
              I_PROD_INST_REL.CREATE_DATE  ,
              I_PROD_INST_REL.STATUS_CD  ,
              I_PROD_INST_REL.STATUS_DATE  ,
              V_NEW_STATUS_DATE  ,  --UPDATE_DATE
              I_PROD_INST_REL.PROC_SERIAL  ,
              I_PROD_INST_REL.PRODUCT_REL_ID  ,
              I_PROD_INST_REL.AREA_ID  ,
              I_PROD_INST_REL.REGION_CD  ,
              I_PROD_INST_REL.UPDATE_STAFF  ,
              I_PROD_INST_REL.CREATE_STAFF  ,
              SEQ_PROD_INST_REL_HIS_ID.NEXTVAL  ,
              V_NEW_STATUS_DATE    --REC_UPDATE_DATE
        FROM DUAL ;

    --删关联关系
    DELETE FROM PROD_INST_REL
     WHERE PROD_INST_REL_ID = I_PROD_INST_REL.PROD_INST_REL_ID;

    --插INTF_INS_BILLING_UPDATE表
    BEGIN
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
      FROM AREA_CODE A, COMMON_REGION B
     WHERE A.REGION_ID = B.COMMON_REGION_ID
       AND B.COMMON_REGION_ID =   I_PROD_INST_REL.AREA_ID;

      SELECT C.CHANNEL_NAME
        INTO V_CHANNEL_NAME
        FROM CHANNEL C
       WHERE C.CHANNEL_NBR = OCS_TRANSFER_CHANNEL_NBR
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'PROD_INST_REL',
                                            I_COLUMN_NAME => 'PROD_INST_REL_ID',
                                            I_KEY_ID      => I_PROD_INST_REL.PROD_INST_REL_ID,
                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),
                                            I_TYPE        => '1004',
                                            I_REASON      => NULL,
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20102,
                              '把PROD_INST_REL信息移到二表失败.' || SQLERRM);
  END;

  PROCEDURE PROC_OFFER_PROD_INST_REL (I_OFFER_PROD_INST_REL IN   OFFER_PROD_INST_REL%ROWTYPE  --产品实例
                                   ) IS
    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;
    V_NEW_STATUS_DATE DATE;
    V_CHANNEL_NAME    CHANNEL.CHANNEL_NAME%TYPE;
    S_ERRMSG          VARCHAR2(500);
  BEGIN

    V_NEW_STATUS_DATE := SYSDATE;

    --产品实例移到2表
    INSERT INTO OFFER_PROD_INST_REL_HIS
      (OFFER_PROD_INST_REL_ID  ,
        PROD_INST_ID  ,
        PROD_OFFER_INST_ID  ,
        ROLE_CD  ,
        OFFER_PROD_INST_REL_ROLE_ID  ,
        STATUS_CD  ,
        STATUS_DATE  ,
        CREATE_DATE  ,
        EFF_DATE  ,
        EXP_DATE  ,
        UPDATE_DATE  ,
        PROC_SERIAL  ,
        OFFER_PROD_REL_ID  ,
        AREA_ID  ,
        REGION_CD  ,
        UPDATE_STAFF  ,
        CREATE_STAFF  ,
        HIS_ID  ,
        REC_UPDATE_DATE  ,
        EXT_FLAG
        )
      SELECT I_OFFER_PROD_INST_REL.OFFER_PROD_INST_REL_ID  ,
              I_OFFER_PROD_INST_REL.PROD_INST_ID  ,
              I_OFFER_PROD_INST_REL.PROD_OFFER_INST_ID  ,
              I_OFFER_PROD_INST_REL.ROLE_CD  ,
              I_OFFER_PROD_INST_REL.OFFER_PROD_INST_REL_ROLE_ID  ,
              I_OFFER_PROD_INST_REL.STATUS_CD ,
              I_OFFER_PROD_INST_REL.STATUS_DATE  ,
              I_OFFER_PROD_INST_REL.CREATE_DATE  ,
              I_OFFER_PROD_INST_REL.EFF_DATE  ,
              V_NEW_STATUS_DATE  ,  --EXP_DATE
              V_NEW_STATUS_DATE  ,  --UPDATE_DATE
              I_OFFER_PROD_INST_REL.PROC_SERIAL  ,
              I_OFFER_PROD_INST_REL.OFFER_PROD_REL_ID  ,
              I_OFFER_PROD_INST_REL.AREA_ID  ,
              I_OFFER_PROD_INST_REL.REGION_CD  ,
              I_OFFER_PROD_INST_REL.UPDATE_STAFF  ,
              I_OFFER_PROD_INST_REL.CREATE_STAFF  ,
              SEQ_OFFER_PROD_INST_REL_HIS_ID.NEXTVAL  ,
              V_NEW_STATUS_DATE  ,  --REC_UPDATE_DATE
              I_OFFER_PROD_INST_REL.EXT_FLAG
        FROM DUAL ;

    --删关联关系
    DELETE FROM OFFER_PROD_INST_REL
     WHERE OFFER_PROD_INST_REL_ID = I_OFFER_PROD_INST_REL.OFFER_PROD_INST_REL_ID;

    --插INTF_INS_BILLING_UPDATE表
    BEGIN
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
      FROM AREA_CODE A, COMMON_REGION B
     WHERE A.REGION_ID = B.COMMON_REGION_ID
       AND B.COMMON_REGION_ID =   I_OFFER_PROD_INST_REL.AREA_ID;

      SELECT C.CHANNEL_NAME
        INTO V_CHANNEL_NAME
        FROM CHANNEL C
       WHERE C.CHANNEL_NBR = OCS_TRANSFER_CHANNEL_NBR
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        S_ERRMSG := SUBSTR(SQLERRM,1,500);
    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'OFFER_PROD_INST_REL',
                                            I_COLUMN_NAME => 'OFFER_PROD_INST_REL_ID',
                                            I_KEY_ID      => I_OFFER_PROD_INST_REL.OFFER_PROD_INST_REL_ID,
                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),
                                            I_TYPE        => '1004',
                                            I_REASON      => NULL,
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20102,
                              '把OFFER_PROD_INST_REL信息移到二表失败.' || SQLERRM);
  END;

  PROCEDURE PROC_PROD_OFFER_INST(I_PROD_OFFER_INST         IN   PROD_OFFER_INST%ROWTYPE --产品实例
                                   )
   IS
    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;
    V_NEW_STATUS_DATE DATE;
    V_CHANNEL_NAME    CHANNEL.CHANNEL_NAME%TYPE;
  BEGIN

    V_NEW_STATUS_DATE := SYSDATE;
    --产品实例移到2表
    INSERT INTO PROD_OFFER_INST_HIS
      (PROD_OFFER_INST_ID  ,
        PROD_OFFER_ID  ,
        CUST_ID  ,
        CHANNEL_ID  ,
        CREATE_DATE  ,
        STATUS_CD  ,
        STATUS_DATE  ,
        EFF_DATE  ,
        EXP_DATE  ,
        REGION  ,
        UPDATE_DATE  ,
        PROC_SERIAL  ,
        EXT_PROD_OFFER_INST_ID  ,
        LAN_ID  ,
        AREA_ID  ,
        REGION_CD  ,
        UPDATE_STAFF  ,
        CREATE_STAFF  ,
        HIS_ID  ,
        REC_UPDATE_DATE  ,
        TRIAL_EFF_DATE  ,
        TRIAL_EXP_DATE  ,
        SERVICE_NBR  ,
        VERSION  ,
        REMARK  ,
        EXT_FLAG2  ,
        WH_REMARK  ,
        EXT_FLAG1  ,
        DISTRIBUTOR_ID
        )
      SELECT I_PROD_OFFER_INST.PROD_OFFER_INST_ID  ,
          I_PROD_OFFER_INST.PROD_OFFER_ID  ,
          I_PROD_OFFER_INST.CUST_ID  ,
          I_PROD_OFFER_INST.CHANNEL_ID  ,
          I_PROD_OFFER_INST.CREATE_DATE  ,
          I_PROD_OFFER_INST.STATUS_CD  ,
          I_PROD_OFFER_INST.STATUS_DATE  ,
          I_PROD_OFFER_INST.EFF_DATE  ,
          I_PROD_OFFER_INST.EXP_DATE  ,
          I_PROD_OFFER_INST.REGION  ,
          V_NEW_STATUS_DATE  ,  --UPDATE_DATE
          I_PROD_OFFER_INST.PROC_SERIAL  ,
          I_PROD_OFFER_INST.EXT_PROD_OFFER_INST_ID  ,
          NULL,--I_PROD_OFFER_INST.LAN_ID  ,
          I_PROD_OFFER_INST.AREA_ID  ,
          I_PROD_OFFER_INST.REGION_CD  ,
          I_PROD_OFFER_INST.UPDATE_STAFF  ,
          I_PROD_OFFER_INST.CREATE_STAFF  ,
          SEQ_PROD_OFFER_INST_HIS_ID.NEXTVAL  ,
          V_NEW_STATUS_DATE  ,  --REC_UPDATE_DATE
          I_PROD_OFFER_INST.TRIAL_EFF_DATE  ,
          I_PROD_OFFER_INST.TRIAL_EXP_DATE  ,
          I_PROD_OFFER_INST.SERVICE_NBR  ,
          I_PROD_OFFER_INST.VERSION  ,
          I_PROD_OFFER_INST.REMARK  ,
          I_PROD_OFFER_INST.EXT_FLAG2  ,
          I_PROD_OFFER_INST.WH_REMARK  ,
          I_PROD_OFFER_INST.EXT_FLAG1  ,
          I_PROD_OFFER_INST.DISTRIBUTOR_ID
        FROM DUAL ;

    --改销售品实例
    UPDATE PROD_OFFER_INST POI
       SET POI.UPDATE_DATE  = V_NEW_STATUS_DATE,
           POI.STATUS_CD = '1100',
           POI.STATUS_DATE  = V_NEW_STATUS_DATE,
           POI.UPDATE_STAFF = PKG_CONSTANTS.JK_STAFF_ID,
           POI.VERSION =  POI.VERSION + 1
     WHERE POI.PROD_OFFER_INST_ID = I_PROD_OFFER_INST.PROD_OFFER_INST_ID;

    --插INTF_INS_BILLING_UPDATE表
    BEGIN
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
      FROM AREA_CODE A, COMMON_REGION B
     WHERE A.REGION_ID = B.COMMON_REGION_ID
       AND B.COMMON_REGION_ID =  I_PROD_OFFER_INST.AREA_ID;

      SELECT C.CHANNEL_NAME
        INTO V_CHANNEL_NAME
        FROM CHANNEL C
       WHERE C.CHANNEL_NBR = OCS_TRANSFER_CHANNEL_NBR
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'PROD_OFFER_INST',
                                            I_COLUMN_NAME => 'PROD_OFFER_INST_ID',
                                            I_KEY_ID      => I_PROD_OFFER_INST.PROD_OFFER_INST_ID,
                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),
                                            I_TYPE        => '1004',
                                            I_REASON      => NULL,
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);

  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20102,
                              '把销售品实例信息移到二表失败.' || SQLERRM);
  END;


  PROCEDURE PROC_CUSTOMER_ORDER_HIS(I_CUSTOMER_ORDER_HIS  IN OUT CUSTOMER_ORDER_HIS%ROWTYPE,
                                        I_PROD_INST IN PROD_INST%ROWTYPE ) IS
  BEGIN
    --生成新的订单流水号
    SELECT 'FJ' || TO_CHAR(SYSDATE, 'YYYYMMDD') ||
           LPAD(TO_CHAR(SEQ_CUSTOMER_ORDER_SO_NUMBER.NEXTVAL), 8, '0')
      INTO I_CUSTOMER_ORDER_HIS.CUST_SO_NUMBER
      FROM DUAL;
    --订单id
    SELECT SEQ_CUSTOMER_ORDER_ID.NEXTVAL INTO I_CUSTOMER_ORDER_HIS.CUST_ORDER_ID FROM DUAL;
    --插订单
    INSERT INTO CUSTOMER_ORDER_HIS
      (CUST_ORDER_ID,
       CUSTOMER_INTERACTION_EVENT_ID,
       CHANNEL_ID,
       CUST_ID,
       STAFF_ID,
       CUST_SO_NUMBER,
       CUST_ORDER_TYPE,
       STATUS_CD,
       STATUS_DATE,
       PRE_HANDLE_FLAG,
       HANDLE_PEOPLE_NAME,
       PRIORITY,
       REASON,
       CREATE_DATE,
       UPDATE_DATE,
       ACCEPT_TIME,
       EXT_CUST_ORDER_ID,
       LAN_ID,
       REMARK,
       BOOK_TIME,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       ORG_ID,
       HIS_ID,
       ORDER_FROM,
       DB_INST_ID,
       PROC_PRIORITY)
      SELECT I_CUSTOMER_ORDER_HIS.CUST_ORDER_ID, --CUST_ORDER_ID,
             NULL, --CUSTOMER_INTERACTION_EVENT_ID,
             (SELECT C.CHANNEL_ID
                FROM CHANNEL C
               WHERE C.CHANNEL_NBR = OCS_TRANSFER_CHANNEL_NBR
                 AND ROWNUM = 1), --CHANNEL_ID,
             I_PROD_INST.OWNER_CUST_ID, --CUST_ID,
             PKG_CONSTANTS.JK_STAFF_ID, --STAFF_ID,
             I_CUSTOMER_ORDER_HIS.Cust_So_Number, --CUST_SO_NUMBER,
             '101', --CUST_ORDER_TYPE,???
             '300000', --STATUS_CD,(300000: 竣工)
             SYSDATE, --STATUS_DATE,
             NULL, --PRE_HANDLE_FLAG,
             NULL, --HANDLE_PEOPLE_NAME,
             '100', --PRIORITY,
             NULL, --REASON,
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             SYSDATE, --ACCEPT_TIME,
             NULL, --EXT_CUST_ORDER_ID,
             NULL, --LAN_ID,
             NULL, --REMARK,
             NULL, --BOOK_TIME,
             I_PROD_INST.AREA_ID, --AREA_ID,
             I_PROD_INST.COMMON_REGION_ID, --REGION_CD,
             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,
             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,
             PKG_CONSTANTS.JK_ORG_ID, --ORG_ID,
             SEQ_CUSTOMER_ORDER_HIS_ID.NEXTVAL, --HIS_ID,
             OCS_TRANSFER_CHANNEL_NBR, --ORDER_FROM,
             NULL, --DB_INST_ID,
             NULL --PROC_PRIORITY,
        FROM DUAL;
   EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20103,
                              '生成CUSTOMER_ORDER_HIS表失败.' || SQLERRM);
  END;

  PROCEDURE PROC_ORDER_ITEM_HIS(I_ORDER_ITEM_HIS      IN OUT  ORDER_ITEM_HIS%ROWTYPE,
                                    I_ORDER_ITEM_CD   IN      ORDER_ITEM_HIS.ORDER_ITEM_CD%TYPE,
                                    I_SERVICE_OFFER_ID IN     ORDER_ITEM_HIS.SERVICE_OFFER_ID%TYPE,
                                    I_PROD_OFFER_INST IN      PROD_OFFER_INST%ROWTYPE,
                                    I_PROD_INST       IN      PROD_INST%ROWTYPE) IS
  BEGIN
    if I_ORDER_ITEM_CD = '1200' then
      I_ORDER_ITEM_HIS.ORDER_ITEM_OBJ_ID := I_PROD_OFFER_INST.PROD_OFFER_INST_ID;
      I_ORDER_ITEM_HIS.CLASS_ID := 6;
      I_ORDER_ITEM_HIS.AREA_ID := I_PROD_OFFER_INST.AREA_ID;
      I_ORDER_ITEM_HIS.REGION_CD :=  I_PROD_OFFER_INST.REGION_CD;
      I_ORDER_ITEM_HIS.ENTT_SPEC_TYPE := 'BO';
      I_ORDER_ITEM_HIS.ENTT_SPEC_ID := I_PROD_OFFER_INST.PROD_OFFER_ID;
    else
      I_ORDER_ITEM_HIS.ORDER_ITEM_OBJ_ID := I_PROD_INST.PROD_INST_ID;
      I_ORDER_ITEM_HIS.CLASS_ID := 4;
      I_ORDER_ITEM_HIS.AREA_ID := I_PROD_INST.AREA_ID;
      I_ORDER_ITEM_HIS.REGION_CD :=  I_PROD_INST.Common_Region_Id;
      if I_PROD_INST.ACC_PROD_INST_ID = I_PROD_INST.PROD_INST_ID then
        I_ORDER_ITEM_HIS.ENTT_SPEC_TYPE := 'AP';
        I_ORDER_ITEM_HIS.ENTT_SPEC_ID := I_PROD_INST.PRODUCT_ID;
      else
         I_ORDER_ITEM_HIS.ENTT_SPEC_TYPE := NULL;
        I_ORDER_ITEM_HIS.ENTT_SPEC_ID := NULL;
      end if;
    end if;
    SELECT SEQ_ORDER_ITEM_ID.NEXTVAL INTO I_ORDER_ITEM_HIS.ORDER_ITEM_ID FROM DUAL;
    INSERT INTO ORDER_ITEM_HIS
      (ORDER_ITEM_ID,
       CUST_ORDER_ID,
       ORDER_ITEM_CD,
       CUST_WORKSHEET_ID,
       STATUS_CD,
       STATUS_DATE,
       STATUS_CHANGE_REASON,
       PRIORITY,
       PRE_HANDLE_FLAG,
       HANDLE_TIME,
       ARCHIVE_DATE,
       FINISH_TIME,
       ORDER_ITEM_OBJ_ID,
       INSTALL_TIME_SEGMENT_ID,
       BEGIN_TIME_SEGMENT_ID,
       SERVICE_OFFER_ID,
       CREATE_DATE,
       UPDATE_DATE,
       REASON,
       EXT_ORDER_ITEM_ID,
       LAN_ID,
       CLASS_ID,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       HIS_ID,
       ORDER_CLASS_ID,
       DB_INST_ID,
       PF_PROCESS_FLAG,
       PROC_PRIORITY,
       ENTT_SPEC_TYPE,
       ENTT_SPEC_ID)
      SELECT  I_ORDER_ITEM_HIS.ORDER_ITEM_ID, --ORDER_ITEM_ID,
             I_ORDER_ITEM_HIS.Cust_Order_Id, --CUST_ORDER_ID,
             I_ORDER_ITEM_CD, --ORDER_ITEM_CD,(1300: 产品订单项)
             NULL, --CUST_WORKSHEET_ID,
             '300000', --STATUS_CD,(300000: 竣工)
             SYSDATE, --STATUS_DATE,
             NULL, --STATUS_CHANGE_REASON,
             NULL, --PRIORITY,
             NULL, --PRE_HANDLE_FLAG,
             NULL, --HANDLE_TIME,
             SYSDATE, --ARCHIVE_DATE,
             SYSDATE, --FINISH_TIME,
             I_ORDER_ITEM_HIS.ORDER_ITEM_OBJ_ID, --ORDER_ITEM_OBJ_ID,
             NULL, --INSTALL_TIME_SEGMENT_ID,
             NULL, --BEGIN_TIME_SEGMENT_ID,
             I_SERVICE_OFFER_ID, --SERVICE_OFFER_ID,
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             NULL, --REASON,
             NULL, --EXT_ORDER_ITEM_ID,
             NULL, --LAN_ID,
             I_ORDER_ITEM_HIS.Class_Id, --CLASS_ID,
             I_ORDER_ITEM_HIS.AREA_ID, --AREA_ID,
             I_ORDER_ITEM_HIS.Region_Cd, --REGION_CD,
             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,
             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,
             SEQ_ORDER_ITEM_HIS_ID.NEXTVAL, --HIS_ID,
             24, --ORDER_CLASS_ID,
             NULL, --DB_INST_ID,
             NULL, --PF_PROCESS_FLAG,
             100, --PROC_PRIORITY,
             I_ORDER_ITEM_HIS.Entt_Spec_Type,
             I_ORDER_ITEM_HIS.Entt_Spec_Id
        FROM DUAL;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20104,
                              '生成ORDER_ITEM_HIS表失败.' || SQLERRM);
  END;

  PROCEDURE PROC_ORDER_ITEM_ACT_RELA_HIS(I_ORDER_ITEM_HIS      IN   ORDER_ITEM_HIS%ROWTYPE,
                                         I_SERVICE_OFFER_ID IN     ORDER_ITEM_HIS.SERVICE_OFFER_ID%TYPE,
                                         I_TARGET           IN     ORDER_ITEM_ACT_RELA.TARGET%TYPE) IS
  BEGIN
       INSERT INTO ORDER_ITEM_ACT_RELA_HIS
      (HIS_ID,
       ORDER_ITEM_ID,
       SERVICE_OFFER_ID,
       ORDER_ITEM_ACT_RELA_ID,
       TARGET,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       DB_INST_ID)
      SELECT SEQ_ORDER_ITEM_ACT_RELA_HIS_ID.NEXTVAL, --HIS_ID,
             I_ORDER_ITEM_HIS.ORDER_ITEM_ID, --ORDER_ITEM_ID,
             I_SERVICE_OFFER_ID, --SERVICE_OFFER_ID,--503: 变更
             SEQ_ORDER_ITEM_ACT_RELA_ID.NEXTVAL, --ORDER_ITEM_ACT_RELA_ID,
             I_TARGET, --TARGET,
             '1000', --STATUS_CD,
             SYSDATE, --STATUS_DATE,
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             I_ORDER_ITEM_HIS.AREA_ID, --AREA_ID,
             I_ORDER_ITEM_HIS.REGION_CD, --REGION_CD,
             PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,
             PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,
             NULL --DB_INST_ID,
        FROM DUAL;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20105,
                              '生成ORDER_ITEM_ACT_RELA_HIS表失败.' || SQLERRM);
  END;

  PROCEDURE PROC_ORDER_ITEM_PROC_ATTR_HIS(I_ORDER_ITEM_HIS  IN   ORDER_ITEM_HIS%ROWTYPE,
                                          I_OPERATE         IN     ORDER_ITEM_PROC_ATTR_HIS.OPERATE%TYPE,
                                          I_NEW_VALUE       IN     ORDER_ITEM_PROC_ATTR_HIS.NEW_VALUE%TYPE,
                                          I_OLD_VALUE       IN     ORDER_ITEM_PROC_ATTR_HIS.OLD_VALUE%TYPE,
                                          I_OBJ_ATTR_ID     IN     ORDER_ITEM_PROC_ATTR_HIS.OBJ_ATTR_ID%TYPE ) IS
  BEGIN
       INSERT INTO ORDER_ITEM_PROC_ATTR_HIS
        (ORDER_ITEM_PROC_ATTR_ID,
         ORDER_ITEM_ID,
         CLASS_ID,
         OBJ_INST_ID,
         OBJ_ATTR,
         OPERATE,
         NEW_VALUE,
         OLD_VALUE,
         STATUS,
         CREATE_DATE,
         STATUS_DATE,
         REMARK,
         OBJ_ATTR_ID,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         HIS_ID,
         UPDATE_DATE,
         DB_INST_ID,
         VERSION)
        SELECT SEQ_ORDER_ITEM_PROC_ATTR_ID.NEXTVAL, --ORDER_ITEM_PROC_ATTR_ID,
               I_ORDER_ITEM_HIS.ORDER_ITEM_ID, --ORDER_ITEM_ID,
               --crm00058934 FJCRMV2.0_BUG_福建省_class_id为空导致外网接口异常  qiurl 20141107
               S.CLASS_ID, --CLASS_ID,
               I_ORDER_ITEM_HIS.ORDER_ITEM_OBJ_ID, --OBJ_INST_ID,
               S.JAVA_CODE, --OBJ_ATTR,
               I_OPERATE, --OPERATE,
               I_NEW_VALUE, --NEW_VALUE,
               I_OLD_VALUE, --OLD_VALUE,
               '1000', --STATUS,
               SYSDATE, --CREATE_DATE,
               SYSDATE, --STATUS_DATE,
               NULL, --REMARK,
               I_OBJ_ATTR_ID,
               I_ORDER_ITEM_HIS.AREA_ID, --AREA_ID,
               I_ORDER_ITEM_HIS.REGION_CD, --REGION_CD,
               PKG_CONSTANTS.JK_STAFF_ID, --UPDATE_STAFF,
               PKG_CONSTANTS.JK_STAFF_ID, --CREATE_STAFF,
               SEQ_OR_ITEM_PROC_ATTR_HIS_ID.NEXTVAL, --HIS_ID,
               SYSDATE, --UPDATE_DATE,
               NULL, --DB_INST_ID,
               NULL --VERSION,
          FROM ATTR_SPEC  S
         WHERE ATTR_ID = I_OBJ_ATTR_ID ;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20105,
                              '生成ORDER_ITEM_PROC_ATTR_HIS表失败.' || SQLERRM);
  END;

  /*
  800000254        挂失停机  双停
800000312        未激活(充值开通)  单停
800000251        欠费双停   双停
800013054        欠费单停   单停
800000252        违章停机   这个应该不是天翼的。。。双停吧。
800000253        用户申请停机  双停
800000250        预销户/预拆机  双停
800000280        未激活(预开通)  单停
  */
  PROCEDURE PROC_PF_OCS_TRANSFER_LOG(I_REC_ID        IN PF_OCS_TRANSFER_LOG.REC_ID%TYPE,
                                     I_PROD_INST     IN PROD_INST%ROWTYPE,
                                     I_TAR_PAYMENT_MODE_CD IN PF_OCS_TRANSFER_LOG.TAR_PAYMENT_MODE_CD%TYPE,
                                     I_TRANSFER_TYPE       IN VARCHAR2) IS
    V_IMSI             PF_OCS_TRANSFER_LOG.IMSI%TYPE;
    V_TFJ_FLAG         PF_OCS_TRANSFER_LOG.TFJ_FLAG%TYPE;
    V_ST_FLAG          PF_OCS_TRANSFER_LOG.TFJ_FLAG%TYPE;
    V_DT_FLAG          PF_OCS_TRANSFER_LOG.TFJ_FLAG%TYPE;
    --crm00059203 FJCRMV2.0_BUG_福建省_lan 上行AAA认证失败 1077 qiurl 20141124
    V_YKT_FLAG          PF_OCS_TRANSFER_LOG.TFJ_FLAG%TYPE;
  BEGIN
    --IMSI
    SELECT D.PARAM1
      INTO V_IMSI
      FROM PROD_INST_ATTR A, MKT_RESOURCE C, MKT_RESO_FEA D
     WHERE C.MKT_RESO_KEY = A.ATTR_VALUE
       AND C.MKT_RESO_ID = D.MKT_RESO_ID
       AND D.FEA_SPEC_ID = 620029411
       AND A.PROD_INST_ID = I_PROD_INST.PROD_INST_ID
       AND A.ATTR_ID = 800000347;

    V_ST_FLAG   := 0 ;  --双停标志
    V_DT_FLAG   := 0 ;  --单停标志
    V_YKT_FLAG  := 0;   --预开通标志
    FOR  REC IN  (
        SELECT ATTR_ID FROM PROD_INST_ATTR
         WHERE PROD_INST_ID = I_PROD_INST.PROD_INST_ID
           AND STATUS_CD = 1000
           AND ATTR_ID IN (800000254,
                           800000312,
                           800000251,
                           800013054,
                           800000252,
                           800000253,
                           800000250,
                           800000280)
      ) LOOP
       IF REC.ATTR_ID = 800000254 THEN  -- 挂失停机  双停
         V_ST_FLAG := 1 ;
       ELSIF REC.ATTR_ID = 800000312  THEN         -- 未激活(充值开通)  单停
         --V_DT_FLAG := 1 ;
         V_YKT_FLAG  := 1;
       ELSIF REC.ATTR_ID =800000251    THEN       -- 欠费双停   双停
        V_ST_FLAG := 1 ;
       ELSIF  REC.ATTR_ID = 800013054  THEN        -- 欠费单停   单停
        V_DT_FLAG := 1 ;
       ELSIF REC.ATTR_ID = 800000252 THEN         -- 违章停机   这个应该不是天翼的。。。双停吧。
        V_ST_FLAG := 1 ;
       ELSIF REC.ATTR_ID = 800000253  THEN        -- 用户申请停机  双停
        V_ST_FLAG := 1 ;
       ELSIF REC.ATTR_ID = 800000250 THEN         -- 预销户/预拆机  双停
        V_ST_FLAG := 1 ;
       ELSIF REC.ATTR_ID = 800000280 THEN          -- 未激活(预开通)  单停
        -- V_DT_FLAG := 1 ;
        V_YKT_FLAG  := 1;
      END IF;
    END LOOP;

    --2：单停   1：双停  0：复机 3:预开通
    IF V_ST_FLAG = 1 THEN
      V_TFJ_FLAG := 1;
    ELSIF   V_DT_FLAG = 1 THEN
      V_TFJ_FLAG := 2;
    ELSIF   V_YKT_FLAG = 1 THEN
      V_TFJ_FLAG := 3;
    ELSE
      V_TFJ_FLAG := 0;
    END IF;

    INSERT INTO PF_OCS_TRANSFER_LOG
       ( PF_OCS_TRANSFER_LOG_ID,
         REC_ID ,
        ACC_NBR,
        IMSI,
        TAR_PAYMENT_MODE_CD,
        AREA_CODE,
        STATE,
        PRODUCT_ID,
        TFJ_FLAG,
        INSERT_TIME,
        PROD_INST_ID,
        TRANSFER_TYPE  )
      SELECT
        SEQ_PF_OCS_TRANSFER_LOG_ID.NEXTVAL,
        I_REC_ID,
        I_PROD_INST.ACC_NBR,
        V_IMSI,
        --I_TAR_PAYMENT_MODE_CD,
        I_PROD_INST.PAYMENT_MODE_CD,
        (SELECT AREA_CODE FROM AREA_CODE
          WHERE REGION_ID = PIR.REGION_CD
            AND ROWNUM = 1 ) AREA_CODE,
        '10I',
        PR.PRODUCT_Z_ID,
        V_TFJ_FLAG,
        SYSDATE,
        I_PROD_INST.PROD_INST_ID,
        I_TRANSFER_TYPE
        FROM PROD_INST_REL PIR, PRODUCT_RELATION PR
        WHERE PIR.PROD_INST_A_ID = I_PROD_INST.PROD_INST_ID
          AND PIR.PRODUCT_REL_ID = pr.product_rel_id
       AND PIR.STATUS_CD = 1000
       --crm00057424  FJCRMV2.0_BUG_福建省_OCS动态加载  qiurl 20141024
       and PR.PRODUCT_Z_ID IN (SELECT PRODUCT_ID FROM INTF_OCS_PF_PRODUCT_CFG
                                WHERE STATE = '1000')
       AND PR.RELATION_TYPE_CD = '100600'
       AND PR.STATUS_CD =  1000 ;
   EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20103,
                              '生成PF_OCS_TRANSFER_LOG表失败.' || SQLERRM);
  END;

  PROCEDURE PROC_IVPN_NBR(I_REC_ID        IN PF_OCS_TRANSFER_LOG.REC_ID%TYPE,
                           I_PROD_INST     IN PROD_INST%ROWTYPE,
                           I_ORDER_ITEM_ID IN ORDER_ITEM.ORDER_ITEM_ID%TYPE,
                           I_TRANSFER_TYPE       IN VARCHAR2)    --转换类型
  IS
    V_ACTION             IVPN_NBR.ACTION%TYPE;
    V_EFF_DATE           IVPN_NBR.EFF_DATE%TYPE;
    V_EXP_DATE           IVPN_NBR.EXP_DATE%TYPE;
    V_ACCOUNT_ID         IVPN_NBR.NEW_ACCOUNT_ID%TYPE;
    V_NEW_ACCOUNT_ID     IVPN_NBR.NEW_ACCOUNT_ID%TYPE:=NULL;
    V_OLD_ACCOUNT_ID     IVPN_NBR.OLD_ACCOUNT_ID%TYPE:=NULL;
    V_REC_ID             IVPN_NBR.REC_ID%TYPE;
    V_AREA_NBR AREA_CODE.AREA_NBR%TYPE;
    V_CHANNEL_NAME       CHANNEL.CHANNEL_NAME%TYPE;
    V_PRE_REC_ID         IVPN_NBR.REC_ID%TYPE;
  BEGIN
    SELECT A.ACCOUNT_ID INTO V_ACCOUNT_ID
      FROM PROD_INST_ACCT A
     WHERE A.PROD_INST_ID = I_PROD_INST.PROD_INST_ID
       AND A.DEF_ACCT_FLAG = 'T'
       AND ROWNUM = 1;
    IF I_TRANSFER_TYPE = 'H2O' then
      V_ACTION := 'A';
      V_EFF_DATE := SYSDATE;
      V_EXP_DATE := NULL;
    ELSE
      V_ACTION := 'R';
      V_NEW_ACCOUNT_ID := V_ACCOUNT_ID;
      V_OLD_ACCOUNT_ID := V_ACCOUNT_ID;
      V_EFF_DATE := SYSDATE;
      V_EXP_DATE := SYSDATE;
    END IF;

    BEGIN
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
      FROM AREA_CODE A, COMMON_REGION B
     WHERE A.REGION_ID = B.COMMON_REGION_ID
       AND B.COMMON_REGION_ID = I_PROD_INST.AREA_ID ;

      SELECT C.CHANNEL_NAME
        INTO V_CHANNEL_NAME
        FROM CHANNEL C
       WHERE C.CHANNEL_NBR = OCS_TRANSFER_CHANNEL_NBR
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      SELECT REC_ID
        INTO V_PRE_REC_ID
        FROM IVPN_NBR
       WHERE REC_ID =
             (SELECT MAX(REC_ID)
                FROM IVPN_NBR
               WHERE PROD_INST_ID = I_PROD_INST.PROD_INST_ID)
         AND EXP_DATE IS NULL;
      UPDATE IVPN_NBR
         SET EXP_DATE = V_EFF_DATE,STATUS_DATE = SYSDATE
       WHERE REC_ID = V_PRE_REC_ID;
      PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'IVPN_NBR',
                                              I_COLUMN_NAME => 'REC_ID',
                                              I_KEY_ID      => V_PRE_REC_ID,
                                              I_TOPIC       => NVL(V_CHANNEL_NAME,
                                                                   ' '),
                                              I_TYPE        => '1004',
                                              I_REASON      => NULL,
                                              I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                              I_AREA_NBR    => V_AREA_NBR);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    SELECT SEQ_IVPN_NBR_ID.NEXTVAL INTO V_REC_ID FROM DUAL;

    INSERT INTO IVPN_NBR
    (  REC_ID ,
      ACTION ,
      AREA_CODE ,
      CREATE_DATE ,
      EFF_DATE ,
      EXP_DATE ,
      NEW_ACCOUNT_ID ,
      OLD_ACCOUNT_ID ,
      PROD_INST_ID,
      PROD_ID ,
      RELA_PROD_INST_ID ,
      RELA_ORDER_ITEM_ID,
      ACC_NBR ,
      STATUS_CD,
      STATUS_DATE,
      TYPE  )
    SELECT V_REC_ID,
      V_ACTION,
      I_PROD_INST.AREA_CODE,
      SYSDATE,
      V_EFF_DATE ,
      V_EXP_DATE ,
      V_NEW_ACCOUNT_ID,
      V_OLD_ACCOUNT_ID,
      I_PROD_INST.PROD_INST_ID,
      I_PROD_INST.PRODUCT_ID,
      NULL,
      I_ORDER_ITEM_ID,
      I_PROD_INST.ACC_NBR,
      '0',
      SYSDATE,
      'OCS'
      FROM DUAL;



    PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(I_TABLE_NAME  => 'IVPN_NBR',
                                            I_COLUMN_NAME => 'REC_ID',
                                            I_KEY_ID      => V_REC_ID,
                                            I_TOPIC       => NVL(V_CHANNEL_NAME, ' '),
                                            I_TYPE        => '1004',
                                            I_REASON      => NULL,
                                            I_OPERATOR    => PKG_CONSTANTS.JK_STAFF_ID,
                                            I_AREA_NBR    => V_AREA_NBR);


  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20103,
                              '生成IVPN_NBR表失败.' || SQLERRM);
  END;


END PKG_OCS_TRANSFER;
/
