CREATE package           PKG_10000QRY is

  -- Author  : ouzhf
  -- Created : 2013/4/2
  -- Purpose : 10000查询接口

  /* 客户经理信息查询 */
  PROCEDURE PROC_QUERY_KHJL_INFO(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR     IN VARCHAR2, --业务号码
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_KHJL_NAME   OUT VARCHAR2, --客户经理名称
                                 O_KHJL_PHONE  OUT VARCHAR2 --客户经理电话
                                 );

  /* 客户信息查询 */
  PROCEDURE PROC_QUERY_CUST_INFO(I_ACC_NBR      IN VARCHAR2, --业务号码，如：18959190160
                                 I_EXT_PROD_ID  IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                 O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG      OUT VARCHAR2, --错误信息
                                 O_CUST_NAME    OUT VARCHAR2, --客户名称
                                 O_CUST_TYPE    OUT VARCHAR2, --客户类型
                                 O_CREATE_DATE  OUT VARCHAR2, --入网时间
                                 O_CUST_LEVEL   OUT VARCHAR2, --客户级别
                                 O_VIP_CARD_NO  OUT VARCHAR2, --VIP卡号
                                 O_CUST_NUMBER  OUT VARCHAR2, --客户编码
                                 O_AREA_CODE    OUT VARCHAR2, --产品区域，如：福州0591
                                 O_PROD_INST_ID OUT NUMBER --产品实例标识
                                 );

end PKG_10000QRY;
/
