CREATE PACKAGE BODY           PKG_INTF IS
  ----------------------
  FUNCTION FNC_GET_INTF_DEFINE_CONFIGS(I_PROD_ITEM_ID_STR  IN VARCHAR2, --产品订单项id, 如111, 222, 333
                                       I_OFFER_ITEM_ID_STR IN VARCHAR2 --销售品订单项id
                                       ) RETURN VARCHAR2
  /*-------------------------------------------------
      功能: 查询接口配置信息
    -------------------------------------------------*/
   IS
    CUR_INTF_DEFINE_CONFIGS SYS_REFCURSOR;

    V_CHANNEL_NBRS VARCHAR2(2000);
    V_CHANNEL_NBR CHANNEL.CHANNEL_NBR%TYPE; --渠道编码
  BEGIN
    OPEN CUR_INTF_DEFINE_CONFIGS FOR 'SELECT DISTINCT A.CHANNEL_NBR
          FROM INTF_DEFINE_CONFIG   A,
               ORDER_ITEM_HIS           B,
               PROD_INST            C,
               ORDER_ITEM_ACT_RELA_HIS  D,
               ORDER_ITEM_PROC_ATTR_HIS E,
               SERVICE_OFFER        F
         WHERE B.ORDER_ITEM_ID IN (' || NVL(I_PROD_ITEM_ID_STR, '0') || ')
           AND B.CLASS_ID = 4
           AND B.ORDER_ITEM_OBJ_ID = C.PROD_INST_ID
           AND B.ORDER_ITEM_ID = D.ORDER_ITEM_ID
           AND B.ORDER_ITEM_ID = E.ORDER_ITEM_ID
           AND D.SERVICE_OFFER_ID = F.SERVICE_OFFER_ID
           AND (C.PAYMENT_MODE_CD = A.PAYMENT_MODE_CD OR A.PAYMENT_MODE_CD IS NULL)
           AND (C.PRODUCT_ID = A.PRODUCT_ID OR A.PRODUCT_ID IS NULL)
           AND (F.STANDARD_CD = A.SERVICE_OFFER_CODE OR
               A.SERVICE_OFFER_CODE IS NULL)
           AND (C.AREA_ID = A.AREA_ID OR A.AREA_ID IS NULL)
           AND ((E.CLASS_ID = A.CLASS_ID AND
               (E.OBJ_ATTR_ID = A.ATTR_ID AND
               ((E.OPERATE = A.ACTION AND
               ((E.NEW_VALUE = A.ATTR_VALUE_NEW OR A.ATTR_VALUE_NEW IS NULL) AND
               (E.OLD_VALUE = A.ATTR_VALUE_OLD OR A.ATTR_VALUE_OLD IS NULL)) OR
               A.ACTION IS NULL)) OR A.ATTR_ID IS NULL)) OR A.CLASS_ID IS NULL)
           AND EXISTS
         (SELECT 1
                  FROM OFFER_PROD_INST_REL G, PROD_OFFER_INST H
                 WHERE G.PROD_OFFER_INST_ID = H.PROD_OFFER_INST_ID
                   AND G.PROD_INST_ID = C.PROD_INST_ID
                   AND (H.PROD_OFFER_ID = A.PROD_OFFER_ID OR A.PROD_OFFER_ID IS NULL)
                   AND ROWNUM = 1)
        UNION
        SELECT DISTINCT A.CHANNEL_NBR
          FROM INTF_DEFINE_CONFIG   A,
               ORDER_ITEM_HIS           B,
               PROD_OFFER_INST      C,
               ORDER_ITEM_ACT_RELA_HIS  D,
               ORDER_ITEM_PROC_ATTR_HIS E,
               SERVICE_OFFER        F
         WHERE B.ORDER_ITEM_ID IN (' || NVL(I_OFFER_ITEM_ID_STR, '0') || ')
           AND B.CLASS_ID = 6
           AND B.ORDER_ITEM_OBJ_ID = C.PROD_OFFER_INST_ID
           AND B.ORDER_ITEM_ID = D.ORDER_ITEM_ID
           AND B.ORDER_ITEM_ID = E.ORDER_ITEM_ID
           AND D.SERVICE_OFFER_ID = F.SERVICE_OFFER_ID
           AND (C.PROD_OFFER_ID = A.PROD_OFFER_ID OR A.PROD_OFFER_ID IS NULL)
           AND (F.STANDARD_CD = A.SERVICE_OFFER_CODE OR
               A.SERVICE_OFFER_CODE IS NULL)
           AND (C.AREA_ID = A.AREA_ID OR A.AREA_ID IS NULL)
           AND ((E.CLASS_ID = A.CLASS_ID AND
               (E.OBJ_ATTR_ID = A.ATTR_ID AND
               ((E.OPERATE = A.ACTION AND
               ((E.NEW_VALUE = A.ATTR_VALUE_NEW OR A.ATTR_VALUE_NEW IS NULL) AND
               (E.OLD_VALUE = A.ATTR_VALUE_OLD OR A.ATTR_VALUE_OLD IS NULL)) OR
               A.ACTION IS NULL)) OR A.ATTR_ID IS NULL)) OR A.CLASS_ID IS NULL)
           AND EXISTS
         (SELECT 1
                  FROM OFFER_PROD_INST_REL G, PROD_INST H, PROD_OFFER I
                 WHERE G.PROD_OFFER_INST_ID = C.PROD_OFFER_INST_ID
                   AND C.PROD_OFFER_ID = I.PROD_OFFER_ID
                   AND I.OFFER_SUB_TYPE <> ''T05''
                   AND G.PROD_INST_ID = H.PROD_INST_ID
                   AND (H.PRODUCT_ID = A.PRODUCT_ID OR A.PRODUCT_ID IS NULL)
                   AND (H.PAYMENT_MODE_CD = A.PAYMENT_MODE_CD OR
                       A.PAYMENT_MODE_CD IS NULL)
                   AND ROWNUM = 1) ';

    --拼成字符串, 逗号隔开
    IF CUR_INTF_DEFINE_CONFIGS%ISOPEN THEN
      LOOP
        FETCH CUR_INTF_DEFINE_CONFIGS
          INTO V_CHANNEL_NBR;
        EXIT WHEN CUR_INTF_DEFINE_CONFIGS%NOTFOUND;

        V_CHANNEL_NBRS := V_CHANNEL_NBRS || ',' || V_CHANNEL_NBR;
      END LOOP;

      V_CHANNEL_NBRS := SUBSTR(V_CHANNEL_NBRS, 2);

      CLOSE CUR_INTF_DEFINE_CONFIGS;
    END IF;

    RETURN V_CHANNEL_NBRS;
  EXCEPTION
    WHEN OTHERS THEN
      IF CUR_INTF_DEFINE_CONFIGS%ISOPEN THEN
        CLOSE CUR_INTF_DEFINE_CONFIGS;
      END IF;
      RAISE_APPLICATION_ERROR(-20001,
                              '读INTF_DEFINE_CONFIG配置失败.' || SQLERRM);
  END;

 /*-------------------------------------------------
   功能: 查停复机INTF_DEFINE_CONFIG
 -------------------------------------------------*/
 FUNCTION FNC_GET_TFJ_DEFINE_CONFIGS(I_PROD_OFFER_ID    IN NUMBER,
                                     I_PRODUCT_ID       IN NUMBER,
                                     I_SERVICE_OFFER_ID IN NUMBER,
                                     I_AREA_ID          IN NUMBER)
   RETURN VARCHAR2 IS
   V_CHANNEL_NBRS VARCHAR2(2000);
 BEGIN
   FOR REC IN (SELECT DISTINCT C.CHANNEL_NBR
                 FROM INTF_DEFINE_CONFIG C
                WHERE (C.SERVICE_OFFER_CODE =
                      DECODE(I_SERVICE_OFFER_ID,
                              28,
                              '4060300001',
                              29,
                              '4070300001',
                              30,
                              '4060300002',
                              31,
                              '4070300002'))
                  AND (C.PRODUCT_ID = I_PRODUCT_ID OR C.PRODUCT_ID IS NULL)
                  AND (C.PROD_OFFER_ID = I_PROD_OFFER_ID OR
                      C.PROD_OFFER_ID IS NULL)
                  AND (C.AREA_ID = I_AREA_ID OR C.AREA_ID IS NULL)
                  AND (C.SERVICE_OFFER_CODE IS NOT NULL OR
                      C.PRODUCT_ID IS NOT NULL OR
                      C.PROD_OFFER_ID IS NOT NULL OR C.AREA_ID IS NOT NULL)) LOOP

     V_CHANNEL_NBRS := V_CHANNEL_NBRS || ',' || REC.CHANNEL_NBR;
   END LOOP;

   V_CHANNEL_NBRS := SUBSTR(V_CHANNEL_NBRS, 2);
   RETURN V_CHANNEL_NBRS;
 EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20001,
                             '读INTF_DEFINE_CONFIG配置失败.' || SQLERRM);
 END;

 /*----------------------------------------------------------------------------
      功能: 查停复机INTF_DEFINE_CONFIG_4G add by wwb 20140414
    ----------------------------------------------------------------------------*/
FUNCTION FNC_GET_TFJ_DEFINE_CONFIGS_4G(I_PROD_OFFER_ID      IN NUMBER,
                                       I_PRODUCT_ID            IN NUMBER,
                                       I_SERVICE_OFFER_ID      IN NUMBER,
                                       I_AREA_ID               IN NUMBER,
                                       I_ATTR_ID               IN VARCHAR2,
                                       I_ATTR_VALUE_NEW        IN VARCHAR2,
                                       I_ACTION                IN VARCHAR2)
   RETURN VARCHAR2 IS
   V_CHANNEL_NBRS VARCHAR2(2000);
 BEGIN
   FOR REC IN (SELECT DISTINCT C.CHANNEL_NBR
                 FROM INTF_DEFINE_CONFIG C
                WHERE (C.SERVICE_OFFER_CODE =
                      DECODE(I_SERVICE_OFFER_ID,
                              28,
                              '4060300001',
                              29,
                              '4070300001',
                              30,
                              '4060300002',
                              31,
                              '4070300002'))
                  AND (C.PRODUCT_ID = I_PRODUCT_ID OR C.PRODUCT_ID IS NULL)
                  AND (C.PROD_OFFER_ID = I_PROD_OFFER_ID OR
                      C.PROD_OFFER_ID IS NULL)
                  AND (C.AREA_ID = I_AREA_ID OR C.AREA_ID IS NULL)
                  AND (C.ATTR_ID in (I_ATTR_ID) OR C.ATTR_ID IS NULL)
                  AND (C.ATTR_VALUE_NEW = I_ATTR_VALUE_NEW OR C.ATTR_VALUE_NEW IS NULL)
                  AND (C.ACTION = I_ACTION OR C.ACTION IS NULL)
                  AND (C.SERVICE_OFFER_CODE IS NOT NULL OR
                      C.PRODUCT_ID IS NOT NULL OR
                      C.PROD_OFFER_ID IS NOT NULL OR C.AREA_ID IS NOT NULL)) LOOP

     V_CHANNEL_NBRS := V_CHANNEL_NBRS || ',' || REC.CHANNEL_NBR;
   END LOOP;

   V_CHANNEL_NBRS := SUBSTR(V_CHANNEL_NBRS, 2);
   RETURN V_CHANNEL_NBRS;
 EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20001,
                             '读INTF_DEFINE_CONFIG配置失败.' || SQLERRM);
 END;


 /*----------------------------------------------------------------------------
      功能: OCS FNC_GET_TFJ_DEFINE_CONFIGS_OCS add by qiurl 20141024
    ----------------------------------------------------------------------------*/
FUNCTION FNC_GET_TFJ_DEFINE_CONFIGS_OCS(I_PROD_OFFER_ID      IN NUMBER,
                                       I_PRODUCT_ID            IN NUMBER,
                                       I_SERVICE_OFFER_ID      IN NUMBER,
                                       I_AREA_ID               IN NUMBER,
                                       I_ATTR_ID               IN VARCHAR2,
                                       I_ACTION                IN VARCHAR2)
   RETURN VARCHAR2 IS
   V_CHANNEL_NBRS VARCHAR2(2000);
 BEGIN
   --crm00057424  FJCRMV2.0_BUG_福建省_OCS动态加载 qiurl 20141024
   --需加 4041300000 动作的配置
   FOR REC IN (SELECT DISTINCT C.CHANNEL_NBR
                 FROM INTF_DEFINE_CONFIG C
                WHERE C.PRODUCT_ID = I_PRODUCT_ID
                  AND ( C.SERVICE_OFFER_CODE = '4041300000' OR C.ATTR_ID = 17142 )  ) LOOP
     V_CHANNEL_NBRS := V_CHANNEL_NBRS || ',' || REC.CHANNEL_NBR;
   END LOOP;

   V_CHANNEL_NBRS := SUBSTR(V_CHANNEL_NBRS, 2);
   RETURN V_CHANNEL_NBRS;
 EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20001,
                             '读INTF_DEFINE_CONFIG配置失败.' || SQLERRM);
 END;

END PKG_INTF;
/
