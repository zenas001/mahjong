CREATE PACKAGE           PKG_TFJ IS
  --自定义类型: 订单项处理属性
  TYPE TYPE_ORDER_ITEM_PROC_ATTR IS RECORD(
    PROD_INST_ATTR_ID PROD_INST_ATTR.PROD_INST_ATTR_ID%TYPE, --PROD_INST_ATTR_ID
    ATTR_ID           PROD_INST_ATTR.ATTR_ID%TYPE, --attr_id
    NEW_VALUE         ORDER_ITEM_PROC_ATTR.NEW_VALUE%TYPE, --新值
    OLD_VALUE         ORDER_ITEM_PROC_ATTR.OLD_VALUE%TYPE, --旧值
    OPERATE           ORDER_ITEM_PROC_ATTR.OPERATE%TYPE --A:新增, M:更新, D:删除
    );
  --自定义类型: 订单项处理属性List
  TYPE TYPE_ORDER_ITEM_PROC_ATTR_LIST IS TABLE OF TYPE_ORDER_ITEM_PROC_ATTR;

  /*
    计费停复机(充值开通)。
    Author  : g.caijx
    Created : 2012-08-11
  */
  PROCEDURE PROC_INTF_CHARGE_OPEN;

  PROCEDURE PROC_EXTRACT_WORK_ORDER
  /*
      功能: 从计费系统把非CDMA的数据搬到CRM接口表中。
   */
  ;

  PROCEDURE PROC_EXTRACT_WORK_ORDER_CDMA
  /*
      功能: 从计费系统把CDMA的数据搬到CRM接口表中。
   */
  ;

  /*
  功能: WORK_ORDER_CDMA 分发程控
  Author  : g.caijx
  Created : 2012-7-7
  */
  PROCEDURE PROC_NWK_TRANSFORM_ORDER_CDMA(I_ORDER_SERIAL_NBR NUMBER, --WORK_ORDER_CDMA.ORDER_SERIAL_NBR
                                          I_SERV_ID          IN NUMBER --产品实例标识
                                          );

  /*
  功能: WORK_ORDER 分发程控
  Author  : g.caijx
  Created : 2012-8-6
   */
  PROCEDURE PROC_NWK_TRANSFORM_ORDER(I_ORDER_SERIAL_NBR NUMBER, --WORK_ORDER.ORDER_SERIAL_NBR
                                     I_SERV_ID          IN NUMBER --产品实例标识
                                     );

  PROCEDURE PROC_LOAD_WORK_ORDER(I_SERV_ID      IN NUMBER, --产品实例id
                                 I_SERV_TYPE_ID IN VARCHAR2, --产品规格id
                                 I_SERIAL_NBR   IN VARCHAR2, --TFJ_ACC_NBR表的主键
                                 I_ACT_TYPE     IN VARCHAR2 --动作类型（T：双停；S：单停；K：开机）
                                 )
  /*
      功能: 对TFJ_ACC_NBR表中记录进行CRM档案更新处理。
    */
  ;

  PROCEDURE SP_TFJ_REQUEST(I_SERV_ID       IN NUMBER, --产品实例id
                           I_SERIAL_NBR    IN NUMBER, --TFJ_ACC_NBR表的主键
                           I_ACT_TYPE      IN VARCHAR2, --动作类型（T：双停；S：单停；K：开机）
                           O_CUST_ORDER_ID OUT NUMBER --产生的订单id
                           )
  /*
      功能: 关联停复机 被SP_TFJ_REDO调用
     */
  ;

  PROCEDURE TFJ_ACC_NBR_PROCESS(I_PROD_INST     IN OUT PROD_INST%ROWTYPE, --产品实例
                                I_ACT_TYPE      IN VARCHAR2, --停机类型（T：双停；S：单停；K：开机）
                                O_CUST_ORDER_ID OUT NUMBER, --产生的订单id
                                I_PROD_INST_OLD     IN OUT PROD_INST%ROWTYPE )
  /*
      功能: 批量语音类停复机工单的处理，由接口直接产生到2表中并修改实例表状态。
    */
  ;

  PROCEDURE PROC_TRANSFORM_WORK_ORDER(I_ORDER_SERIAL_NBR IN NUMBER, --WORK_ORDER表的主键
                                      I_PROD_SPEC_ID     IN NUMBER, --
                                      I_SERV_ID          IN NUMBER, --prod_inst_id
                                      I_ACC_NBR          IN VARCHAR2, --号码
                                      I_ACTION           IN NUMBER, --
                                      I_LATN_ID          IN NUMBER, --如591
                                      I_STOP_FLAG        IN NUMBER --停机保号状态, 1为停机保号
                                      )
  /*
    功能: 把Work_order和work_order_cdma表的数据分发给电子工单系统、PF系统、激活系统等
    */
  ;

  PROCEDURE PROC_CREATE_ORDER(I_PROD_INST                 IN PROD_INST%ROWTYPE, --产品实例
                              I_SERVICE_OFFER_ID          IN SERVICE_OFFER.SERVICE_OFFER_ID%TYPE, --SERVICE_OFFER_ID
                              I_ORDER_ITEM_PROC_ATTR_LIST IN TYPE_ORDER_ITEM_PROC_ATTR_LIST, --变更的属性
                              I_CHANNEL_NBR               IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE, --渠道
                              O_CUST_ORDER_ID             OUT NUMBER, --产生的订单id
                              I_PROD_INST_OLD     IN OUT PROD_INST%ROWTYPE)
  /*
    功能: 生成订单
    Author  : g.caijx
    Created : 2012-7-7
    */
  ;

  PROCEDURE PROC_AUTO_SO_SERV(I_PROD_INST_ID    IN NUMBER, --接入类产品实例标识
                              I_ACT_TYPE        IN VARCHAR2, --动作类型（T：双停；S：单停；K：开机）
                              I_SERIAL_NBR      IN VARCHAR2, --TFJ_ACC_NBR表的主键
                              O_INTF_SO_SERV_ID OUT NUMBER, --INTF_SO_SERV表id
                              O_ERR_CODE        OUT NUMBER, --错误编码（0--成功 1--失败）
                              O_ERR_MSG         OUT VARCHAR2 --错误信息
                              )
  /*
    功能: 插INTF_SO_SERV表, 由轮询来生成订单
    Author  : g.caijx
    Created : 2012-7-7
    */
  ;

  PROCEDURE PROC_PROCESS_PROD_INST(I_PROD_INST   IN OUT PROD_INST%ROWTYPE, --产品实例
                                   I_STATUS_CD   IN PROD_INST.STATUS_CD%TYPE, --产品状态, 该参数为NULL时, 不修改产品实例状态
                                   I_CHANNEL_NBR IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE --渠道
                                   )
  /*
      功能: 处理产品实例
    */
  ;

  PROCEDURE PROC_PROCESS_PROD_OFFER_INST(I_PROD_INST   IN PROD_INST%ROWTYPE, --产品实例
                                         I_CHANNEL_NBR IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE --渠道
                                         )
  /*
      功能: 处理销售品实例
   */
  ;
  PROCEDURE PROC_PROCESS_PROD_INST_ATTR(I_PROD_INST                 IN PROD_INST%ROWTYPE, --产品实例
                                        I_ACTION                    IN VARCHAR2, --动作(A:新增, M:更新, D:删除)
                                        I_ATTR_ID                   IN PROD_INST_ATTR.ATTR_ID%TYPE, --属性
                                        I_ATTR_VALUE                IN PROD_INST_ATTR.ATTR_VALUE%TYPE, --属性值. 枚举类型请传ATTR_VALUE_ID, 当I_ACTION为D时,忽略该参数
                                        I_CHANNEL_NBR               IN INTF_DEFINE_CONFIG.CHANNEL_NBR%TYPE, --渠道
                                        O_ORDER_ITEM_PROC_ATTR_LIST IN OUT TYPE_ORDER_ITEM_PROC_ATTR_LIST --记录下变更的属性
                                        )
  /*
      功能: 处理产品实例属性
    */
  ;

  FUNCTION FUNC_CALC_EFF_DATE(I_ATTR_ID IN ATTR_SPEC.ATTR_ID%TYPE)
    RETURN DATE;
  /*
    功能: 属性变动时计算生效时间
  */
END PKG_TFJ;
/
