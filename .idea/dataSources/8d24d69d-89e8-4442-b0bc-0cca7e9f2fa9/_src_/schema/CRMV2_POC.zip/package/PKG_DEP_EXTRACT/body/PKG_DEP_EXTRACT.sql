CREATE PACKAGE BODY           PKG_DEP_EXTRACT IS

  --批次号生成，格式 BUS_CODE||YYYYMMDDHH24MISS
  FUNCTION FUN_BATCH_NBR_CREATE(IN_BUS_CODE IN VARCHAR2) RETURN VARCHAR2 IS
    V_BUS_CODE  VARCHAR2(50);
    V_SYS_DATE  VARCHAR2(30);
    V_BATCH_NBR VARCHAR2(100);
  BEGIN
    V_BUS_CODE := IN_BUS_CODE;
    SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') INTO V_SYS_DATE FROM DUAL;

    V_BATCH_NBR := IN_BUS_CODE || V_SYS_DATE;
    RETURN V_BATCH_NBR;
  END;

  --文件名生成,格式 60010500011000000036BUS6001620140530U001.txt
  FUNCTION FUN_FILE_NAME_CREATE(IN_BUS_CODE        IN VARCHAR2, --业务功能编码
                                IN_CURRENT_PACKAGE IN NUMBER -- 分割批次次数
                                ) RETURN VARCHAR2 IS
    V_INTF_DEP_FTP    INTF_DEP_FTP%ROWTYPE;
    V_FILE_NAME       VARCHAR2(200);
    V_CURRENT_PACKAGE VARCHAR(10);
  BEGIN
    SELECT INTF_DEP_FTP_ID,
           BUS_CODE,
           FTP_TYPE,
           SRC_SYS_ID,
           DST_SYS_ID,
           FILE_FORMAT,
           FIELD_INTERVAL,
           RECORD_INTERVAL,
           USE_TYPE,
           SRC_INTF_DEP_HOST_ID,
           SRC_PATH,
           DST_INTF_DEP_HOST_ID,
           DST_PATH,
           TABLE_NAME,
           TABLE_FIELD,
           RECORD_NUM,
           OWNER,
           FREQUENCY,
           TIME_POINT,
           STATE,
           STATE_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           REMARK
      INTO V_INTF_DEP_FTP.INTF_DEP_FTP_ID,
           V_INTF_DEP_FTP.BUS_CODE,
           V_INTF_DEP_FTP.FTP_TYPE,
           V_INTF_DEP_FTP.SRC_SYS_ID,
           V_INTF_DEP_FTP.DST_SYS_ID,
           V_INTF_DEP_FTP.FILE_FORMAT,
           V_INTF_DEP_FTP.FIELD_INTERVAL,
           V_INTF_DEP_FTP.RECORD_INTERVAL,
           V_INTF_DEP_FTP.USE_TYPE,
           V_INTF_DEP_FTP.SRC_INTF_DEP_HOST_ID,
           V_INTF_DEP_FTP.SRC_PATH,
           V_INTF_DEP_FTP.DST_INTF_DEP_HOST_ID,
           V_INTF_DEP_FTP.DST_PATH,
           V_INTF_DEP_FTP.TABLE_NAME,
           V_INTF_DEP_FTP.TABLE_FIELD,
           V_INTF_DEP_FTP.RECORD_NUM,
           V_INTF_DEP_FTP.OWNER,
           V_INTF_DEP_FTP.FREQUENCY,
           V_INTF_DEP_FTP.TIME_POINT,
           V_INTF_DEP_FTP.STATE,
           V_INTF_DEP_FTP.STATE_DATE,
           V_INTF_DEP_FTP.CREATE_DATE,
           V_INTF_DEP_FTP.UPDATE_DATE,
           V_INTF_DEP_FTP.REMARK
      FROM INTF_DEP_FTP IDF
     WHERE IDF.BUS_CODE = IN_BUS_CODE;

  --取序列 三位数
    SELECT LPAD(IN_CURRENT_PACKAGE,3,0) INTO V_CURRENT_PACKAGE  FROM DUAL;

    --文件命名规则:%SRC_SYS_ID%||%DST_SYS_ID%||%BUS_CODE%||YYYYMMDD||%USE_TYPE%||\d{3}
    V_FILE_NAME := V_INTF_DEP_FTP.SRC_SYS_ID || V_INTF_DEP_FTP.DST_SYS_ID ||
                   FUN_BATCH_NBR_CREATE(V_INTF_DEP_FTP.BUS_CODE) ||
                   V_INTF_DEP_FTP.USE_TYPE || V_CURRENT_PACKAGE || '.txt';
    RETURN V_FILE_NAME;
  END;
  --BUS90001文件名生成,格式CRM2BestPay_CRM_YYYYMMDD_NNNN.txt
  FUNCTION FUN_BUS90001_FILE_NAME_CREATE(IN_CURRENT_PACKAGE IN NUMBER -- 分割批次次数
                                         ) RETURN VARCHAR2 IS
    V_FILE_HEAD        VARCHAR2(30);
    V_SYS_DATE        VARCHAR2(30);
    V_FILE_NAME       VARCHAR2(200);
    V_CURRENT_PACKAGE VARCHAR(10);
  BEGIN
    V_FILE_HEAD  :='CRM2BestPay_CRM';
    --取序列 三位数
    SELECT LPAD(IN_CURRENT_PACKAGE, 4, 0) INTO V_CURRENT_PACKAGE FROM DUAL;
    SELECT TO_CHAR(SYSDATE, 'YYYYMMDD') INTO V_SYS_DATE FROM DUAL;

    --文件命名规则:CRM2BestPay_CRM_YYYYMMDD_NNNN.txt
    V_FILE_NAME := V_FILE_HEAD|| '_'|| V_SYS_DATE || '_'|| V_CURRENT_PACKAGE ||'.txt';

    RETURN V_FILE_NAME;
  END;
 /*
  *清空数据中间表
  */
  PROCEDURE PROC_INIT_TABLE(IN_BUS_CODE IN VARCHAR2) IS
    V_SQL VARCHAR2(1000);
  BEGIN
    V_SQL := 'TRUNCATE TABLE INTF_' || IN_BUS_CODE || '_AUDIT';
    EXECUTE IMMEDIATE V_SQL;
    DELETE CRMV2.INTF_DEP_FTP_CONTROL
     WHERE BUS_CODE = IN_BUS_CODE
       AND TRUNC(START_TIME) = TRUNC(SYSDATE);
    COMMIT;
  END;
  /*
   * 文件抽取 处理中，文件生成 等待中，文件上传 等待中
   * 按照10W条数据创建1个文件。
   *
   */
  PROCEDURE PROC_DEP_COMMON(IN_BUS_CODE          IN VARCHAR2,
                              IN_BATCH_NBR         IN VARCHAR2,
                              IN_CURRENT_PACKAGE   IN NUMBER,
                              IN_TOTAL_PACKAGE_NUM IN NUMBER) IS

    V_FILE_NAME               VARCHAR2(100);
    V_CURRENT_PACKAGE         NUMBER;
    V_BATCH_NBR               VARCHAR2(100);
    V_INTF_DEP_FTP_CONTROL_ID NUMBER;
    V_EXCEPITON               VARCHAR(500);
  BEGIN
    IF IN_BUS_CODE = 'BUS90001'
      THEN    V_FILE_NAME:=FUN_BUS90001_FILE_NAME_CREATE(IN_CURRENT_PACKAGE);
     ELSE
               V_FILE_NAME       := FUN_FILE_NAME_CREATE(IN_BUS_CODE,IN_CURRENT_PACKAGE);
    END IF;
    V_BATCH_NBR       := IN_BATCH_NBR;
    V_CURRENT_PACKAGE := IN_CURRENT_PACKAGE;
    --文件抽取 待处理状态
    SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
      INTO V_INTF_DEP_FTP_CONTROL_ID
      FROM DUAL;
    INSERT INTO INTF_DEP_FTP_CONTROL
      (INTF_DEP_FTP_CONTROL_ID,
       BUS_CODE,
       BATCH_NBR,
       CURRENT_PACKAGE,
       TOTAL_PACKAGE_NUM,
       FILE_NAME,
       TYPE,
       START_TIME,
       END_TIME,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       DEAL_NUM,
       NEXT_DEAL_TIME,
       ERR_MSG,
       REMARK)
    VALUES
      (V_INTF_DEP_FTP_CONTROL_ID,
       IN_BUS_CODE,
       IN_BATCH_NBR,
       IN_CURRENT_PACKAGE,
       IN_TOTAL_PACKAGE_NUM,
       V_FILE_NAME,
       '100',
       SYSDATE,
       SYSDATE + 1,
       '70B',
       SYSDATE,
       SYSDATE,
       null,
       '0',
       SYSDATE - 10 / 1440,
       null,
       null);
    --文件生成 待处理状态
    SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
      INTO V_INTF_DEP_FTP_CONTROL_ID
      FROM DUAL;
    INSERT INTO INTF_DEP_FTP_CONTROL
      (INTF_DEP_FTP_CONTROL_ID,
       BUS_CODE,
       BATCH_NBR,
       CURRENT_PACKAGE,
       TOTAL_PACKAGE_NUM,
       FILE_NAME,
       TYPE,
       START_TIME,
       END_TIME,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       DEAL_NUM,
       NEXT_DEAL_TIME,
       ERR_MSG,
       REMARK)
    VALUES
      (V_INTF_DEP_FTP_CONTROL_ID,
       IN_BUS_CODE,
       IN_BATCH_NBR,
       IN_CURRENT_PACKAGE,
       IN_TOTAL_PACKAGE_NUM,
       V_FILE_NAME,
       '200',
       SYSDATE,
       SYSDATE + 1,
       '70A',
       SYSDATE,
       SYSDATE,
       null,
       '0',
       SYSDATE - 10 / 1440,
       null,
       null);
    --文件抽取 待处理状态
    SELECT SEQ_INTF_DEP_FTP_CONTROL_ID.NEXTVAL
      INTO V_INTF_DEP_FTP_CONTROL_ID
      FROM DUAL;
    INSERT INTO INTF_DEP_FTP_CONTROL
      (INTF_DEP_FTP_CONTROL_ID,
       BUS_CODE,
       BATCH_NBR,
       CURRENT_PACKAGE,
       TOTAL_PACKAGE_NUM,
       FILE_NAME,
       TYPE,
       START_TIME,
       END_TIME,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       DEAL_NUM,
       NEXT_DEAL_TIME,
       ERR_MSG,
       REMARK)
    VALUES
      (V_INTF_DEP_FTP_CONTROL_ID,
       IN_BUS_CODE,
       IN_BATCH_NBR,
       IN_CURRENT_PACKAGE,
       IN_TOTAL_PACKAGE_NUM,
       V_FILE_NAME,
       '300',
       SYSDATE,
       SYSDATE + 1,
       '70A',
       SYSDATE,
       SYSDATE,
       null,
       '0',
       SYSDATE - 10 / 1440,
       null,
       null);
    commit;

  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);

  END;

 /**
  * 数据抽取完后回填
  *
  * 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
  */
 PROCEDURE PROC_DEP_COMPLETE(IN_BUS_CODE IN VARCHAR2,
                             IN_BATCH_NBR IN VARCHAR2) IS

    V_BUS_CODE               VARCHAR2(100);
    V_BATCH_NBR              VARCHAR2(100);
    V_EXCEPITON              VARCHAR2(500);
    V_UPDATE_SQL             VARCHAR2(2000);
  BEGIN
    V_BUS_CODE:=IN_BUS_CODE;
    V_BATCH_NBR:=IN_BATCH_NBR;
    V_UPDATE_SQL:= 'UPDATE INTF_DEP_FTP_CONTROL SET STATE=''70C'',STATE_DATE	=SYSDATE WHERE TYPE=''100'' AND  BUS_CODE= '''||IN_BUS_CODE||''''||' AND BATCH_NBR='''||V_BATCH_NBR||'''';
     EXECUTE IMMEDIATE V_UPDATE_SQL;
     COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
  END;

 /*
  * 订单信息稽核 20140624 add by wangweibin
  */
 PROCEDURE PROC_BUS60016 IS
 -- TYPE INTF_ORDER_INFO_AUDIT IS REF CURSOR; --定义游标变量类型
 -- V_CURSORVAR INTF_ORDER_INFO_AUDIT; --声明游标变量
 -- V_INTF_ORDER_INFO_AUDIT INTF_ORDER_INFO_AUDIT;
  V_EXCEPITON               VARCHAR(500);
  V_CURRENT_PACKAGE  NUMBER:=0;--分割批次数
  V_TOTAL_PACKAGE_NUM      NUMBER:=0;--分割批次数总数
  V_COUNT    NUMBER:=0; --取数总量
  V_BATCH_NBR VARCHAR2(100); --批次号
 /**
   * ========================================================
   *  修改点：不一样的BUS_CDOE 修改对应的值
   *
  **/
  V_BUS_CODE  VARCHAR2(50):='BUS60016'; --业务功能编码

--===========================================================
  V_INTF_ORDER_INFO_AUDIT_ID NUMBER;
  V_RECORD_NUM  NUMBER(12); --行数

 BEGIN
 --获取批次号
 V_BATCH_NBR:=FUN_BATCH_NBR_CREATE(V_BUS_CODE);
--统计数据总数
 SELECT COUNT(1) INTO V_COUNT
  FROM INTF_DEP_ORDER_HIS             P,
       INTF_DEP_ORDER_PACKAGE_REL_HIS IDOP,
       INTF_DEP_DATA_INFO_HIS         IDDIH
 WHERE P.INTF_DEP_ORDER_ID = IDOP.INTF_DEP_ORDER_ID
   AND IDOP.INTF_DEP_ORDER_PACKAGE_REL_ID =
       IDDIH.INTF_DEP_ORDER_PACKAGE_REL_ID
   AND P.PACKAGE_GROUP IN
       (SELECT DISTINCT I.PACKAGE_GROUP
          FROM INTF_DEP_FINISH_HIS I
          WHERE TRUNC(I.UPDATE_DATE) =TRUNC(SYSDATE - 1));
--分割批次号 以10W数量为分割单位
  /* IF V_COUNT>100000 AND MOD(V_COUNT,100000)=0  THEN V_TOTAL_PACKAGE_NUM := (V_COUNT/100000);    END IF;
   IF V_COUNT>100000 AND MOD(V_COUNT,100000)>0  THEN  V_TOTAL_PACKAGE_NUM := (V_COUNT/100000+1); END IF;
   IF V_COUNT<100000 THEN V_TOTAL_PACKAGE_NUM:=1; END IF;*/
 --取出BUS_CODE对应配置的行数
   SELECT RECORD_NUM INTO V_RECORD_NUM  FROM CRMV2.INTF_DEP_FTP WHERE BUS_CODE=V_BUS_CODE;
   --通过行数判断分割的总量
   SELECT CEIL(V_COUNT/V_RECORD_NUM) INTO V_TOTAL_PACKAGE_NUM FROM DUAL;

  BEGIN
          LOOP
          V_CURRENT_PACKAGE:=V_CURRENT_PACKAGE+1;
          --如果分割数大于分割数总数则跳出
          IF V_CURRENT_PACKAGE > V_TOTAL_PACKAGE_NUM
             THEN EXIT;
          ELSE
          --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
           PROC_DEP_COMMON(V_BUS_CODE , --业务功能编码
                         V_BATCH_NBR,--批次号
                         V_CURRENT_PACKAGE,--分割批次号
                         V_TOTAL_PACKAGE_NUM);--分割次数总数

     /**
      * =======================================================================================================================================================================
      *  修改点：不一样的取数逻辑编写对应的取数逻辑
      *
     **/
          --取数插中间表逻辑
         for rec in ( SELECT PKG_CLOB_TO_STR.CLOB_TO_STR_SINGLE1(IDDIH.DATA_INFO,'EXT_CUST_ORDER_ID',1) CUST_ORDER_ID,
                   DECODE(PKG_CLOB_TO_STR.CLOB_TO_STR_SINGLE1(IDDIH.DATA_INFO,'DSTORGID',1),NULL,600105/*福建集团区域编码*/)PROVINCE_ID,
                   PKG_CLOB_TO_STR.CLOB_TO_STR_SINGLE1(IDDIH.DATA_INFO,'LAN_ID',1) LAN_ID,PKG_CLOB_TO_STR.CLOB_TO_STR_SINGLE1(IDDIH.DATA_INFO,'ACC_NBR',1) ACC_NBR,
                   DECODE(DBMS_LOB.INSTR(IDDIH.DATA_INFO,'C-IMSI'),0,'',TO_CHAR(SUBSTR(IDDIH.DATA_INFO,DBMS_LOB.INSTR(IDDIH.DATA_INFO,'C-IMSI')-17,15))) C_IMSI,
                   DECODE(DBMS_LOB.INSTR(IDDIH.DATA_INFO,'G-IMSI'),0,'',TO_CHAR(SUBSTR(IDDIH.DATA_INFO,DBMS_LOB.INSTR(IDDIH.DATA_INFO,'G-IMSI')-17,15))) G_IMSI,
                   DECODE(DBMS_LOB.INSTR(IDDIH.DATA_INFO,'L-IMSI'),0,'',TO_CHAR(SUBSTR(IDDIH.DATA_INFO,DBMS_LOB.INSTR(IDDIH.DATA_INFO,'L-IMSI')-17,15))) L_IMSI,
                   PKG_CLOB_TO_STR.CLOB_TO_STR_SINGLE1(IDDIH.DATA_INFO,'MKT_RES_INST_CODE',1)  MKT_NBR,DECODE(1,1,V_BUS_CODE) BUS_CODE,DECODE(1,1,V_CURRENT_PACKAGE) CURRENT_PACKAGE,
                   DECODE(1,1,V_BATCH_NBR) BATCH_NBR
                   FROM INTF_DEP_ORDER_HIS             P,
                    INTF_DEP_ORDER_PACKAGE_REL_HIS IDOP,
                    INTF_DEP_DATA_INFO_HIS         IDDIH
                    WHERE P.INTF_DEP_ORDER_ID = IDOP.INTF_DEP_ORDER_ID
                          AND IDOP.INTF_DEP_ORDER_PACKAGE_REL_ID = IDDIH.INTF_DEP_ORDER_PACKAGE_REL_ID
                          AND P.PACKAGE_GROUP IN
                             (SELECT DISTINCT I.PACKAGE_GROUP
                              FROM INTF_DEP_FINISH_HIS I
                              WHERE TRUNC(I.UPDATE_DATE) =TRUNC(SYSDATE - 1))AND
                            ROWNUM > V_RECORD_NUM*(V_CURRENT_PACKAGE-1)   AND ROWNUM < V_RECORD_NUM*V_CURRENT_PACKAGE) LOOP
           SELECT SEQ_INTF_ORDER_INFO_AUDIT_ID.NEXTVAL INTO V_INTF_ORDER_INFO_AUDIT_ID FROM DUAL;
           INSERT INTO INTF_ORDER_INFO_AUDIT (INTF_ORDER_INFO_AUDIT_ID,CUST_ORDER_ID,  PROVINCE_ID,LAN_ID,  ACC_NBR,  C_IMSI,  G_IMSI,  L_IMSI,  MKT_NBR,BUS_CODE, CURRENT_PACKAGE, BATCH_NBR)
            VALUES(V_INTF_ORDER_INFO_AUDIT_ID,rec.CUST_ORDER_ID,  rec.PROVINCE_ID,rec.LAN_ID,  rec.ACC_NBR,  rec.C_IMSI,  rec.G_IMSI, rec.L_IMSI,  rec.MKT_NBR,rec.BUS_CODE, rec.CURRENT_PACKAGE, rec.BATCH_NBR);
          END LOOP;
 /**
   * =======================================================================================================================================================================
   *
  **/
         END IF ;
         END LOOP;
   END;
  COMMIT;
 --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
  PROC_DEP_COMPLETE(V_BUS_CODE,V_BATCH_NBR);
 EXCEPTION
    WHEN OTHERS THEN
      V_EXCEPITON := SUBSTR(SQLERRM, 1, 500);
 END;
/*
* 上传号码及属性给翼支付 20160107 add by xiely
*/
PROCEDURE PROC_BUS90001(IN_ATTR_NAME IN VARCHAR2) IS
  V_EXCEPITON         VARCHAR(500);
  V_MAX_NUMBER        INTEGER := 100000;
  V_INT_NUM           INTEGER;
  V_CURRENT_PACKAGE   NUMBER := 0; --分割批次数
  V_TOTAL_PACKAGE_NUM NUMBER := 0; --分割批次数总数
  V_COUNT             NUMBER := 0; --取数总量
  V_BATCH_NBR         VARCHAR2(100); --批次号
  V_BUS_CODE          VARCHAR2(50) := 'BUS90001'; --业务功能编码
  V_SQL              VARCHAR2(1000);
BEGIN
  --获取批次号
  V_BATCH_NBR := FUN_BATCH_NBR_CREATE(V_BUS_CODE);
  V_SQL := 'TRUNCATE TABLE INTF_' || V_BUS_CODE || '_AUDIT';
  EXECUTE IMMEDIATE V_SQL;
  COMMIT;
 PROC_INIT_TABLE(V_BUS_CODE);
  --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
  PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                  V_BATCH_NBR, --批次号
                  1, --分割批次号
                  1); --分割次数总数
  BEGIN
    --取数插中间表逻辑
    for rec in (SELECT P.ACC_NBR ACC_NBR, A.ATTR_NAME ATTR_NAME
                  FROM CRMV2.PROD_INST_ATTR PA,
                       CRMV2.PROD_INST      P,
                       CRMV2.ATTR_SPEC      A
                 WHERE P.PROD_INST_ID = PA.PROD_INST_ID
                   AND A.ATTR_ID = PA.ATTR_ID
                   AND A.ATTR_NAME =IN_ATTR_NAME) LOOP

      INSERT INTO INTF_BUS90001_AUDIT
        (ACC_NBR, ATTR_NAME, BUS_CODE, CURRENT_PACKAGE, BATCH_NBR)
      VALUES
        (rec.ACC_NBR, rec.ATTR_NAME, V_BUS_CODE, 0, V_BATCH_NBR);
    END LOOP;
    commit;
  END;
  ---排重
  delete from crmv2.INTF_BUS90001_AUDIT a
   where rowid <> (select max(rowid)
                     from crmv2.INTF_BUS90001_AUDIT b
                    where a.acc_nbr = b.acc_nbr
                      and nvl(a.acc_nbr, 1) = nvl(b.acc_nbr, 1));
  commit;

  loop
    select nvl(max(CURRENT_PACKAGE), -1) + 1
      into V_CURRENT_PACKAGE
      from INTF_BUS90001_AUDIT b
     where BATCH_NBR = V_BATCH_NBR;
    if V_CURRENT_PACKAGE = 0 then
      V_TOTAL_PACKAGE_NUM := 0;
    end if;
    exit when V_CURRENT_PACKAGE = 0;

    select count(*)
      into V_COUNT
      from crmv2.INTF_BUS90001_AUDIT a
     where CURRENT_PACKAGE = 0;

    if V_COUNT > V_MAX_NUMBER then
      update crmv2.INTF_BUS90001_AUDIT a
         set CURRENT_PACKAGE = V_CURRENT_PACKAGE
       where CURRENT_PACKAGE = 0
         and rownum < (V_MAX_NUMBER + 1);
    else
      update crmv2.INTF_BUS90001_AUDIT
         set CURRENT_PACKAGE = V_CURRENT_PACKAGE
       where CURRENT_PACKAGE = 0;
    end if;

    commit;
    V_TOTAL_PACKAGE_NUM := V_CURRENT_PACKAGE;
    exit when V_COUNT <= V_MAX_NUMBER;

  end loop;

  COMMIT;
  V_INT_NUM := 2;
  if V_TOTAL_PACKAGE_NUM > 1 then
    loop

      --FTP接口队列 INTF_DEP_FTP_CONTROL  插入数据
      PROC_DEP_COMMON(V_BUS_CODE, --业务功能编码
                      V_BATCH_NBR, --批次号
                      V_INT_NUM, --分割批次号
                      V_TOTAL_PACKAGE_NUM); --分割次数总数
      V_INT_NUM := V_INT_NUM + 1;
      EXIT WHEN V_INT_NUM > V_TOTAL_PACKAGE_NUM;
    end loop;
  end if;
  update crmv2.intf_dep_ftp_control
     set total_package_num = V_TOTAL_PACKAGE_NUM
   where batch_nbr = V_BATCH_NBR;
  commit;
  COMMIT;
  --取数成功后回写 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
  PROC_DEP_COMPLETE(V_BUS_CODE, V_BATCH_NBR);
  END;
END PKG_DEP_EXTRACT;
/
