CREATE package           PKG_JT_MDSE_SPEC is

  -- Author  : zhengcl
  -- Created : 2010-08-10 9:33:32
  -- Purpose : 集团销售品处理

--全量映射CRM销售品到集团销售品
PROCEDURE saveLocalSpecToJtMdse(i_localspecId    in number,      --CRM本地规格
                                                  i_parentNodeId   in number,      --集团树父节点
                                                  i_staff          in VARCHAR2,      --受理工号
                                                  o_return    out number,      --成功标识
                                                  o_nodeid    out number,      --新创建的节点标识
                                                  str_msg     out VARCHAR2);

--变更本单销售品的清理状态
PROCEDURE changeLocalSpecCleanState(i_localspecId    in number,      --CRM本地规格
                                                  i_cleanstate   in VARCHAR2,      --清理状态
                                                  o_return    out number,      --成功标识
                                                  str_msg     out VARCHAR2);   --返回信息

--删除映射的集团销售品返回到CRM销售品
PROCEDURE delJtMdseToLocalspec(i_jtmdsespecid    in number,      --集团销售品规格
                                                  o_return    out number,      --成功标识
                                                  str_msg     out VARCHAR2);

--根据CRM销售品返回集团销售品规格
PROCEDURE getJtMdseFromLocalspec(i_localspecId    in number,      --CRM销售品规格
                                 i_keyid          in number,   --要映射表的主键
                                 i_agreeid       in number,    --协议号
                                 o_jtmdsespecId   out number);      --集团销售品规格
--判断是否符合映射参数
function IsMapAttr(i_mappingId  in number,i_keyId in number,i_agreeid in number)
        return number;--为0表示匹配参数，不为0表示不匹配
end PKG_JT_MDSE_SPEC;
/
