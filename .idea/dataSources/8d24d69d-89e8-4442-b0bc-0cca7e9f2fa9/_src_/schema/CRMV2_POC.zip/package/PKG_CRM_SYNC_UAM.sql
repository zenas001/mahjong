CREATE PACKAGE           PKG_CRM_SYNC_UAM IS
  --批次号生成，格式 BUS_CODE||YYYYMMDDHH24MISS
  FUNCTION FUN_BATCH_NBR_CREATE(IN_BUS_CODE IN VARCHAR2) RETURN VARCHAR2;

  --文件名生成,格式 60010500011000000036BUS6001620140530U001.txt
  FUNCTION FUN_FILE_NAME_CREATE(IN_BUS_CODE        IN VARCHAR2, --业务功能编码
                                IN_USE_TYPE        IN VARCHAR2,
                                IN_CURRENT_PACKAGE IN NUMBER, -- 分割批次次数
                                V_BATCH_NBR IN VARCHAR2 -- 批次号
                                ) RETURN VARCHAR2;

  /** 共同体
   *  文件抽取 处理中，文件生成 等待中，文件上传 等待中
   *  按照10W条数据创建1个文件。
  */
  PROCEDURE PROC_DEP_COMMON(IN_BUS_CODE          IN VARCHAR2, --业务功能编码
                            IN_USE_TYPE          IN VARCHAR2,
                            IN_BATCH_NBR         IN VARCHAR2, --批次号
                            IN_CURRENT_PACKAGE   IN NUMBER, --分割批次号
                            IN_TOTAL_PACKAGE_NUM IN NUMBER); --分割次数总数

  /**
  * 数据抽取完后回填
  *
  * 数据更新文件抽取部分TYPE:100 状态为处理完成 状态为：70C
  */
  PROCEDURE PROC_DEP_COMPLETE(IN_BUS_CODE  IN VARCHAR2,
                              IN_BATCH_NBR IN VARCHAR2);
  /*
  *清空数据中间表
  */
  PROCEDURE PROC_INIT_TABLE(IN_BUS_CODE IN VARCHAR2);
  /*
  分批次*/
  PROCEDURE PROC_CURRENT_PACKAGE_AVG(IN_TABLE_NAME       IN VARCHAR2,
                                     IN_BATCH_NBR        IN VARCHAR2,
                                     IN_MAX_NUMBER       IN INTEGER,
                                     O_TOTAL_PACKAGE_NUM OUT INTEGER);
  /*PROC_MAIN*/
  PROCEDURE PROC_MAIN;
  /*员工 STAFF*/
  PROCEDURE PROC_BUS001;
  /*销售员关联渠道 STAFF_CHANNEL_RELA*/
  PROCEDURE PROC_BUS002;
  /*销售员关联经营主体 STAFF_OPERATORS_RELA*/
  PROCEDURE PROC_BUS003;
  /*经营主体 OPERATORS*/
  PROCEDURE PROC_BUS004;
  /*渠道 CHANNEL*/
  PROCEDURE PROC_BUS005;
  /*渠道关联组织 CHANNEL_ORG_RELA*/
  PROCEDURE PROC_BUS006;
  /*渠道关联经营场所 CHANNEL_OPERATORS_RELA*/
  PROCEDURE PROC_BUS007;
  /*渠道属性 CHANNEL_ATTR*/
  PROCEDURE PROC_BUS008;
  /*组织 ORGANIZATION*/
  PROCEDURE PROC_BUS009;
  /*参与人 PARTY*/
  PROCEDURE PROC_BUS010;
  /*参与人联系信息 PARTY_CONTACT_INFO*/
  PROCEDURE PROC_BUS011;
  /*参与人证件 PARTY_CERTIFICATION*/
  PROCEDURE PROC_BUS012;
  /*个人信息 INDIVIDUAL*/
  PROCEDURE PROC_BUS013;
  /*系统用户 SYSTEM_USER*/
  PROCEDURE PROC_BUS014;
  /*区域 COMMON_REGION*/
  PROCEDURE PROC_BUS015;
END PKG_CRM_SYNC_UAM;
/
