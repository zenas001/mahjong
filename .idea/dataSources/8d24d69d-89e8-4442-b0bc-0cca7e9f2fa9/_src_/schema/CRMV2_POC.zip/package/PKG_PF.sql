CREATE package           PKG_PF is

  -- Author  : OUZHF
  -- Created : 2012/7/13 9:11:49
  -- Purpose :
  /*-------------------------------------------------
  协同通信业务号码查询
  PF需要查询某号码属于哪个协同通信群组产品时，调用此接口
  Author  : ouzhf
  Created : 2012-07-13
  -------------------------------------------------*/
  PROCEDURE PROC_QUERY_ACCOUNT_BY_ID(I_PROD_INST_ID IN NUMBER, --成员实例标识
                                     O_ACC_NBR      OUT VARCHAR2, --成员实例标识所在的在用的协同通信的业务号码
                                     O_ERR_CODE     OUT NUMBER, --返回值：0-成功 ；1-失败
                                     O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                     );

  /************************************************************************
  Function  ：此过程是根据产品实例查询关联从产品的相关信息。
  该过程提供pf调用。
  Author　  ：Wangjianjun
  Date      : 2012-07-26
  Parameter :
              I_PROD_INST_ID  ---产品实例ID
              O_RETURN_STR    --关联从信息
              包括关联从产品实例，关联从产品规格，关联类型，之间用逗号隔开，多个该组合列表使用分号隔开
              O_ERR_CODE      --返回编码（0 成功 1 失败）
              O_ERR_MSG       --返回信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_REL_PRODUCT(I_PROD_INST_ID IN NUMBER, --产品实例ID
                                   O_RETURN_STR   OUT VARCHAR2, --关联从信息,包括关联从产品实例，关联从产品规格，关联类型，之间用逗号隔开，多个该组合列表使用分号隔开
                                   O_ERR_CODE     OUT NUMBER, --返回编码（0 成功 1 失败）
                                   O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                   );

  /************************************************************************
  Function  ：此过程是根据产品实例查询产品的属性信息。
  该过程提供pf调用。
  Author　  ：Wangjianjun
  Date      : 2012-07-26
  Parameter :
              I_PROD_INST_ID --产品实例ID
              O_FACT_SPEED   --实际速率
              O_UP_SPEED     --上行速率
              O_DOWN_SPEED   --下行速率
              O_MAX_LINK     --最大连接数
              O_BIND_TYPE    --漫游方式
              O_FLAG         --业务标识（0 未定义 1 是）
              --O_FLAG是由多位组成，有新的需求再扩展位数，比如
              --查询的宽带是承载iTV、是e8-2套餐的宽带、是承载商铺管家业务，那么oO_FLAG返回111
              --查询的宽带是承载iTV、不是e8-2套餐的宽带、不是承载商铺管家业务，那么O_FLAG返回100 等等
              O_WIRELESS     --漫游/MANYOU  区域漫游/QYMANYOU  不漫游/BMANYOU
              O_ACCOUNT      --宽带帐号
              O_USE_SAMETIME --WLAN和有线是否同时使用（是/WYTSSYY、否/WYKSSYN）
              O_ERR_CODE     --返回编码（0 成功 1 失败）
              O_ERR_MSG      --返回具体的错误信息
  ************************************************************************/
  PROCEDURE PROC_GET_PROD_INST_ATTR(I_PROD_INST_ID IN NUMBER, --产品实例ID
                                    O_FACT_SPEED   OUT VARCHAR2, --实际速率
                                    O_UP_SPEED     OUT VARCHAR2, --上行速率
                                    O_DOWN_SPEED   OUT VARCHAR2, --下行速率
                                    O_MAX_LINK     OUT VARCHAR2, --最大连接数
                                    O_BIND_TYPE    OUT VARCHAR2, --漫游方式
                                    O_FLAG         OUT VARCHAR2, --业务标识（0 未定义 1 是）
                                    --o_flag是由多位组成，有新的需求再扩展位数，比如
                                    --查询的宽带是承载iTV、是e8-2套餐的宽带、是承载商铺管家业务，那么o_flag返回111
                                    --查询的宽带是承载iTV、不是e8-2套餐的宽带、不是承载商铺管家业务，那么o_flag返回100 等等
                                    O_WIRELESS     OUT VARCHAR2, --漫游/MANYOU  区域漫游/QYMANYOU  不漫游/BMANYOU
                                    O_ACCOUNT      OUT VARCHAR2, --宽带帐号
                                    O_USE_SAMETIME OUT VARCHAR2, --WLAN和有线是否同时使用（是/WYTSSYY、否/WYKSSYN）
                                    O_ERR_CODE     OUT NUMBER, --返回编码（0 成功 1 失败）
                                    O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                    );

  /*-------------------------------------------------
  产品是否停机查询
  提供PF查询产品是否停机（判断产品包含“挂失停机/欠费单停/欠费双停/违章停机/用户申请停机/预拆机”返回停机标识）时，调用此接口
  Author  : ouzhf
  Created : 2012-08-15
  -------------------------------------------------*/
  PROCEDURE PROC_PROD_STOP_STATUS(I_PROD_INST_ID IN NUMBER, --成员实例标识
                                  O_IS_STOP      OUT VARCHAR2, --是否停机标识： 1-单停状态（欠费单停）；2-双停状态（挂失停机/欠费双停/违章停机/用户申请停机/预拆机）；3-未激活（预开通）；4-未激活（充值开通）；0-其他状态
                                  O_ERR_CODE     OUT NUMBER, --返回值：0-成功 ；1-失败
                                  O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                  );

end PKG_PF;
/
