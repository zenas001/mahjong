CREATE PACKAGE BODY           PKG_QUEUE IS

  /* VIP会员级别查询 */
  PROCEDURE PROC_QUERY_VIP_LEVEL(I_TYPE             IN NUMBER, --查询类型 1：VIP卡号 2：业务号码 3：身份证号
                                 I_AREA_CODE        IN VARCHAR2, --区号编码 如福州0591
                                 I_ACCOUNT          IN VARCHAR2, --号码  包括VIP卡号，业务号码，身份证号
                                 O_MEMBERSHIP_LEVEL OUT VARCHAR2, --会员级别
                                 O_ERR_CODE         OUT NUMBER, --处理结果（0--成功 1--失败）
                                 O_ERR_MSG          OUT VARCHAR2 --错误信息
                                 ) IS
  BEGIN
    O_ERR_CODE := 0;
    O_ERR_MSG  := '操作成功';

    BEGIN

      IF I_TYPE = 1 THEN
        select distinct av.attr_value_name
          into O_MEMBERSHIP_LEVEL
          from club_member_info cmi, attr_value av
         where 1 = 1
           and cmi.membership_level = av.attr_value
           and cmi.vip_area_code = I_AREA_CODE
           and cmi.vip_card_nbr = I_ACCOUNT
           and av.attr_id = '800034289';
        --如果从club_member取membership_level则此处attr_id为9014
      ELSIF I_TYPE = 2 THEN
        select distinct av.attr_value_name
          into O_MEMBERSHIP_LEVEL
          from prod_inst        pi,
               cust             c,
               club_member      cm,
               club_member_info cmi,
               attr_value       av
         where 1 = 1
           and pi.owner_cust_id = c.cust_id
           and c.cust_id = cm.cust_id
           and cm.member_code = cmi.member_code
           and cmi.membership_level = av.attr_value
           and pi.area_code = I_AREA_CODE
           and pi.acc_nbr = I_ACCOUNT
           and av.attr_id = '800034289'
           and pi.status_cd = '100000'
           and cm.status_cd = '1000';
      ELSIF I_TYPE = 3 THEN
        select distinct av.attr_value_name
          into O_MEMBERSHIP_LEVEL
          from party_certification pc,
               party               p,
               cust                c,
               club_member         cm,
               club_member_info    cmi,
               attr_value          av
         where 1 = 1
           and pc.party_id = p.party_id
           and p.party_id = c.cust_id
           and c.cust_id = cm.cust_id
           and cm.member_code = cmi.member_code
           and cmi.membership_level = av.attr_value
           and pc.cert_number = I_ACCOUNT
           and av.attr_id = '800034289'
           and cm.status_cd = '1000';
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查询客户VIP级别失败';
    END;

  END PROC_QUERY_VIP_LEVEL;

  PROCEDURE PROC_QUEUE_INFO_SYNC(I_CALL_SERIAL_NBR  IN VARCHAR2, --呼叫流水号
                                 I_QUEUE_STAFF_CODE IN VARCHAR2, --排队员工号
                                 O_ERR_CODE         OUT NUMBER, --处理结果（0--成功 1--失败）
                                 O_ERR_MSG          OUT VARCHAR2, --错误信息
                                 O_RESULT           OUT VARCHAR2 --处理结果
                                 ) IS
    V_STAFF_NUM NUMBER;
  BEGIN
    O_ERR_CODE  := 0;
    O_ERR_MSG   := '';
    O_RESULT    := '';
    V_STAFF_NUM := 0;

    --由于排队机输入排队工号为0造成数据更新缓慢，屏蔽0的处理
    if I_QUEUE_STAFF_CODE = '0' or I_QUEUE_STAFF_CODE is null then
      O_ERR_MSG := '排队员工号为0不处理!';
      RETURN;
    end if;

    select count(*)
      INTO V_STAFF_NUM
      from SYSTEM_USER
     where QUEUE_STAFF_CODE = I_QUEUE_STAFF_CODE;

    IF V_STAFF_NUM = 0 THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '排队员工号不存在!';
      RETURN;
    END IF;

    select count(*)
      INTO V_STAFF_NUM
      from SYSTEM_USER
     where QUEUE_STAFF_CODE = I_QUEUE_STAFF_CODE
       and CALL_SERIAL_NBR = I_CALL_SERIAL_NBR;

    IF V_STAFF_NUM > 0 THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '流水号已经存在!';
      RETURN;
    END IF;

    BEGIN
      UPDATE SYSTEM_USER
         set CALL_SERIAL_NBR = I_CALL_SERIAL_NBR
       where QUEUE_STAFF_CODE = I_QUEUE_STAFF_CODE;
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := sqlerrm;
        ROLLBACK;
    END;

  END PROC_QUEUE_INFO_SYNC;

END PKG_QUEUE;
/
