CREATE package body           pkg_grid is

  -------------------按产品地址取网格-------------------
  --RULE_CODE  RULE_NAME  RULE_TYPE
  --R-09  人工待划配 211
  --HDHP  按号段划配 168
  --KHHP  按客户划配 165
  --DZHP  按地址划配 10
  --SBHP  按设备划配 11
  procedure p_prod_address_grid(i_prod_inst_id       in number,
                                o_grid_rule_inst_lst out t_grid_rule_inst_lst) is
    v_address_id  prod_inst.address_id%type;
    v_location_id standard_adress.location_id%type;
    --按产品地址取数据
    cursor cur is
      select d.grid_id, d.rule_inst_id, d.rule_id
        from (select location_id
                 from political_location
               connect by prior up_location_id = location_id
                start with location_id = v_location_id) c, grid_rule_inst d,
             grid_rule e
       where d.column_1 = to_char(c.location_id)
         and d.rule_id = e.rule_id
         and e.rule_type = '10';
  begin
    --初始化
    o_grid_rule_inst_lst := t_grid_rule_inst_lst();
    begin
      -----------产品信息----------------
      --装机地址
      select address_id
        into v_address_id
        from prod_inst a
       where prod_inst_id = i_prod_inst_id;

      --标准地址
      select b.location_id
        into v_location_id
        from standard_adress b
       where b.adress_id = v_address_id;

      -----------网格信息----------------
      --按产品地址取数据
      for rec in cur loop
        o_grid_rule_inst_lst.extend;
        o_grid_rule_inst_lst(o_grid_rule_inst_lst.count) := t_grid_rule_inst(rec.grid_id,
                                                                             rec.rule_inst_id,
                                                                             rec.rule_id);

      end loop;
    exception
      when others then
        null;
    end;
  end;

  -------------------按产品设备取网格-------------------
  --RULE_CODE  RULE_NAME  RULE_TYPE
  --R-09  人工待划配 211
  --HDHP  按号段划配 168
  --KHHP  按客户划配 165
  --DZHP  按地址划配 10
  --SBHP  按设备划配 11
  procedure p_prod_device_grid(i_prod_inst_id       in number,
                               o_grid_rule_inst_lst out t_grid_rule_inst_lst) is
    v_address_id  prod_inst.address_id%type;
    v_location_id standard_adress.location_id%type;
    v_device_id   device.device_id%type;
    --按设备地址取数据
    cursor cur is
      select d.grid_id, d.rule_inst_id, d.rule_id
        from grid_rule_inst d, grid_rule e
       where d.column_1 = to_char(v_device_id)
         and d.rule_id = e.rule_id
         and e.rule_type = '11';

  begin
    --初始化
    o_grid_rule_inst_lst := t_grid_rule_inst_lst();
    begin
      -----------产品设备----------------
      --注：临时把标准地址location_id作为产品设备ID
      -----------------------------------
      --装机地址
      select address_id
        into v_address_id
        from prod_inst a
       where prod_inst_id = i_prod_inst_id;

      --标准地址
      select b.location_id
        into v_location_id
        from standard_adress b
       where b.adress_id = v_address_id;

      --产品设备
      select d.device_id
        into v_device_id
        from (select location_id
                 from political_location
               connect by prior up_location_id = location_id
                start with location_id = v_location_id) c, device d
       where c.location_id = d.device_id;

      -----------网格信息----------------
      --按设备地址取数据
      for rec in cur loop
        o_grid_rule_inst_lst.extend;
        o_grid_rule_inst_lst(o_grid_rule_inst_lst.count) := t_grid_rule_inst(rec.grid_id,
                                                                             rec.rule_inst_id,
                                                                             rec.rule_id);

      end loop;
    exception
      when others then
        null;
    end;
  end;

  -------------------按号段取网格-------------------
  --RULE_CODE  RULE_NAME  RULE_TYPE
  --R-09  人工待划配 211
  --HDHP  按号段划配 168
  --KHHP  按客户划配 165
  --DZHP  按地址划配 10
  --SBHP  按设备划配 11
  procedure p_prod_sec_grid(i_prod_inst_id       in number,
                            o_grid_rule_inst_lst out t_grid_rule_inst_lst) is
    v_acc_nbr   prod_inst.acc_nbr%type;
    v_region_cd prod_inst.common_region_id%type;
    --按产品地址取数据
    cursor cur is
      select d.grid_id, d.rule_inst_id, d.rule_id
        from grid_rule_inst_attr b, grid_rule_inst_attr c, grid_rule_inst d,
             grid_rule e, grid f
       where b.attr_id = '27840'
         and b.attr_value <= to_char(v_acc_nbr)
         and length(b.attr_value) = length(v_acc_nbr)
         and c.attr_id = '27841'
         and c.attr_value >= to_char(v_acc_nbr)
         and length(c.attr_value) = length(v_acc_nbr)
         and e.rule_type = '168'
         and b.grid_rule_inst_id = d.rule_inst_id
         and c.grid_rule_inst_id = d.rule_inst_id
         and d.rule_id = e.rule_id
         and d.grid_id = f.grid_id
         and f.region_cd = v_region_cd;
  begin
    begin
      --初始化
      o_grid_rule_inst_lst := t_grid_rule_inst_lst();

      -----------产品信息----------------
      --号码
      select acc_nbr, common_region_id
        into v_acc_nbr, v_region_cd
        from prod_inst a
       where prod_inst_id = i_prod_inst_id;

      -----------网格信息----------------
      --按产品地址取数据
      for rec in cur loop
        o_grid_rule_inst_lst.extend;
        o_grid_rule_inst_lst(o_grid_rule_inst_lst.count) := t_grid_rule_inst(rec.grid_id,
                                                                             rec.rule_inst_id,
                                                                             rec.rule_id);

      end loop;
    exception
      when others then
        null;
    end;
  end;

  -------------------按待划配取网格-------------------
  procedure p_prod_dhp_grid(i_prod_inst_id       in number,
                            o_grid_rule_inst_lst out t_grid_rule_inst_lst) is
    cursor cur is
      select a.grid_id, '' rule_inst_id, '999' rule_id
        from grid a, prod_inst b
       where a.grid_sort = '13'
         and a.grid_code = '4LEVEL_DHP_GZ'
         and b.prod_inst_id = i_prod_inst_id
         and a.region_cd = b.common_region_id
         and rownum = 1;
  begin
    begin
      --初始化
      o_grid_rule_inst_lst := t_grid_rule_inst_lst();

      -----------网格信息----------------
      for rec in cur loop
        o_grid_rule_inst_lst.extend;
        o_grid_rule_inst_lst(o_grid_rule_inst_lst.count) := t_grid_rule_inst(rec.grid_id,
                                                                             rec.rule_inst_id,
                                                                             rec.rule_id);

      end loop;
    exception
      when others then
        null;
    end;
  end;

  ----1、产品实例自动划配到网格
  ------prodinstgridrel
  /*
  案例名称  产品实例自动划配到网格
  业务场景  新入网的客户（王二）新装一个固定电话，在竣工后，固定电话产品实例被自动划配到客户经理(张三)所负责的网格；
  测试目的  验证某个产品实例能否按照规则正确划配到所在的网格
  预置条件  1.  提供一个能够进行固定电话受理的工号A；
  2.  固定电话的安装地址为张三所负责的网格（通过划配规则体现）
  3.  张三所在的网格已经设置了划配规则
  4.  自动划配程序运行正常
  测试过程  1.  检查预置条件是否具备
  2.  工号A登录CRM，进入业务受理界面，完成新建客户（王二）和固定电话的新装，要求固话地址为张三所负责的网格；完成固定产品竣工
  3.  自动划配程序对产品实例进行自动划配
  预期结果  1.  能够查询到固定电话已经划配到张三负责的网格。
  */

  procedure p_prod_inst_grid_rel(i_prod_inst_id in number,
                                 o_state        out number,
                                 o_msg          out varchar2) is
    cur_prod_inst prod_inst%rowtype;
    --
    v_grid_id      grid_rule_inst.grid_id%type;
    v_rule_inst_id grid_rule_inst.rule_inst_id%type;
    v_rule_id      grid_rule_inst.rule_id%type;
    --
    v_count           number(10) := 0;
    v_count_grid_team number(10) := 0;
    v_value_switch    varchar2(10) := '';
    --数组主列表e
    v_grid_rule_inst_lst t_grid_rule_inst_lst;
    --数组
    v_grid_rule_inst t_grid_rule_inst;
    --数组子列表
    v_child_grid_rule_inst_lst t_grid_rule_inst_lst;

  begin
    -----------产品信息----------------
    begin
      select area_id, common_region_id, create_staff
        into cur_prod_inst.area_id, cur_prod_inst.common_region_id,
             cur_prod_inst.create_staff
        from prod_inst a
       where prod_inst_id = i_prod_inst_id;
    exception
      when no_data_found or too_many_rows then
        cur_prod_inst := null;
    end;
    ----------------------------------------------
    -----------增加产品实例网格关联数据-----------
    ----------------------------------------------
    ----取网格
    begin
      ----------------------
      --取产品关联网格
      ----------------------
      --网格集合
      v_grid_rule_inst_lst := t_grid_rule_inst_lst();

      --1.取产品对应的网格（按地址）
      v_child_grid_rule_inst_lst := t_grid_rule_inst_lst();
      p_prod_address_grid(i_prod_inst_id, v_child_grid_rule_inst_lst);
      for i in 1 .. v_child_grid_rule_inst_lst.count loop
        v_grid_rule_inst_lst.extend;
        v_grid_rule_inst_lst(v_grid_rule_inst_lst.count) := v_child_grid_rule_inst_lst(i);
      end loop;

      --2.取产品对应的网格（按设备）
      v_child_grid_rule_inst_lst := t_grid_rule_inst_lst();
      p_prod_device_grid(i_prod_inst_id, v_child_grid_rule_inst_lst);
      for i in 1 .. v_child_grid_rule_inst_lst.count loop
        v_grid_rule_inst_lst.extend;
        v_grid_rule_inst_lst(v_grid_rule_inst_lst.count) := v_child_grid_rule_inst_lst(i);
      end loop;

      --3.取产品对应的网格（按号段）
      v_child_grid_rule_inst_lst := t_grid_rule_inst_lst();
      p_prod_sec_grid(i_prod_inst_id, v_child_grid_rule_inst_lst);
      for i in 1 .. v_child_grid_rule_inst_lst.count loop
        v_grid_rule_inst_lst.extend;
        v_grid_rule_inst_lst(v_grid_rule_inst_lst.count) := v_child_grid_rule_inst_lst(i);
      end loop;

      --4.增加待划配产品关联网格数据（找不到数据直接归到人工待划配中）
      if v_grid_rule_inst_lst.count = 0 then
        v_child_grid_rule_inst_lst := t_grid_rule_inst_lst();
        p_prod_dhp_grid(i_prod_inst_id, v_child_grid_rule_inst_lst);
        for i in 1 .. v_child_grid_rule_inst_lst.count loop
          v_grid_rule_inst_lst.extend;
          v_grid_rule_inst_lst(v_grid_rule_inst_lst.count) := v_child_grid_rule_inst_lst(i);
        end loop;
      end if;

      ----------------------------------------------------------
      --增加网格关联数据prod_inst_assign_rel 同 prod_inst_grid_rel 表
      ----------------------------------------------------------
      ----删除历史划配产品关联网格数据
      for rec in (select prod_inst_grid_rel_id, grid_id, prod_inst_id,
                         rule_inst_id, rule_id
                    from prod_inst_grid_rel
                   where prod_inst_id = i_prod_inst_id) loop
        --判断是否在新规则中存在的网格
        v_count := 0;
        for i in 1 .. v_grid_rule_inst_lst.count loop
          v_grid_rule_inst := v_grid_rule_inst_lst(i);
          if rec.grid_id = v_grid_rule_inst.grid_id then
            v_count := v_count + 1;
          end if;
        end loop;
        --删除不存在的数据
        if v_count = 0 then
          insert into prod_inst_grid_rel_his
            (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
             event_id, status_cd, status_date, create_date, update_date,
             area_id, region_cd, update_staff, create_staff, rule_id,
             column_1, his_id, prod_inst_assign_rel_id, chn_org_unit_id,
             channel_member_id, relationship_type_cd, responsibility_type_cd)
            select prod_inst_grid_rel_id, grid_id, prod_inst_id,
                   rule_inst_id, event_id, status_cd, status_date,
                   create_date, sysdate update_date, area_id, region_cd,
                   update_staff, create_staff, rule_id, column_1,
                   seq_prod_inst_grid_rel_his_id.nextval his_id,
                   prod_inst_assign_rel_id, chn_org_unit_id,
                   channel_member_id, relationship_type_cd,
                   responsibility_type_cd
              from prod_inst_grid_rel
             where prod_inst_id = i_prod_inst_id
               and grid_id = rec.grid_id;
          delete from prod_inst_grid_rel
           where prod_inst_id = i_prod_inst_id
             and grid_id = rec.grid_id;
        end if;
      end loop;

      ----增加新产品关联网格
      for i in 1 .. v_grid_rule_inst_lst.count loop
        --取得各列的值
        v_grid_rule_inst := v_grid_rule_inst_lst(i);
        v_grid_id        := v_grid_rule_inst.grid_id;
        v_rule_inst_id   := v_grid_rule_inst.rule_inst_id;
        v_rule_id        := v_grid_rule_inst.rule_id;
        ----判断网格是否存在。如果存在就更新记录，如果不存在就增加记录
        select count(1)
          into v_count
          from prod_inst_grid_rel
         where prod_inst_id = i_prod_inst_id
           and grid_id = v_grid_id;
        ----判断是否有配置客户经理
        select count(1)
          into v_count_grid_team
          from grid_team a
         where a.grid_id = v_grid_id;
        ----取新旧模式标志(一个产品对应多个渠道成员,Y:按渠道成员及渠道只能单元对应,N:按海南网格对应)
        select attr_value
          into v_value_switch
          from attr_value
         where attr_id = 8241;
        -------旧版本 网格------begin---
        if v_count_grid_team = 0 or v_value_switch = 'N' then
          if v_count = 0 then
            insert into prod_inst_grid_rel
              (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
               event_id, status_cd, status_date, create_date, update_date,
               area_id, region_cd, update_staff, create_staff, rule_id,
               column_1, prod_inst_assign_rel_id, chn_org_unit_id,
               channel_member_id, relationship_type_cd,
               responsibility_type_cd)
              select seq_prod_inst_grid_rel_id.nextval prod_inst_grid_rel_id,
                     v_grid_id grid_id, i_prod_inst_id prod_inst_id,
                     v_rule_inst_id rule_inst_id, '0' event_id,
                     '10' status_cd, sysdate status_date,
                     sysdate create_date, sysdate update_date,
                     cur_prod_inst.area_id, cur_prod_inst.common_region_id,
                     '' update_staff, cur_prod_inst.create_staff,
                     v_rule_id rule_id, '' column_1,
                     seq_prod_inst_grid_rel_id.nextval prod_inst_assign_rel_id,
                     '0' chn_org_unit_id, '0' channel_member_id,
                     '10' relationship_type_cd, '0' responsibility_type_cd
                from dual;
          elsif v_count = 1 then
            update prod_inst_grid_rel
               set grid_id = v_grid_id, rule_inst_id = v_rule_inst_id,
                   rule_id = v_rule_id, update_date = sysdate
             where prod_inst_id = i_prod_inst_id
               and grid_id = v_grid_id;
          elsif v_count > 1 then
            delete prod_inst_grid_rel
             where prod_inst_id = i_prod_inst_id
               and grid_id = v_grid_id;
            insert into prod_inst_grid_rel
              (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
               event_id, status_cd, status_date, create_date, update_date,
               area_id, region_cd, update_staff, create_staff, rule_id,
               column_1, prod_inst_assign_rel_id, chn_org_unit_id,
               channel_member_id, relationship_type_cd,
               responsibility_type_cd)
              select seq_prod_inst_grid_rel_id.nextval prod_inst_grid_rel_id,
                     v_grid_id grid_id, i_prod_inst_id prod_inst_id,
                     v_rule_inst_id rule_inst_id, '0' event_id,
                     '10' status_cd, sysdate status_date,
                     sysdate create_date, sysdate update_date,
                     cur_prod_inst.area_id, cur_prod_inst.common_region_id,
                     '' update_staff, cur_prod_inst.create_staff,
                     v_rule_id rule_id, '' column_1,
                     seq_prod_inst_grid_rel_id.nextval prod_inst_assign_rel_id,
                     '0' chn_org_unit_id, '0' channel_member_id,
                     '10' relationship_type_cd, '0' responsibility_type_cd
                from dual;
          end if;
          -------旧版本 网格------end---
          --新版本 网格*客户经理--begin--2011-6-27---
        elsif v_count_grid_team > 0 then
          if v_count = 0 then
            insert into prod_inst_grid_rel
              (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
               event_id, status_cd, status_date, create_date, update_date,
               area_id, region_cd, update_staff, create_staff, rule_id,
               column_1, prod_inst_assign_rel_id, chn_org_unit_id,
               channel_member_id, relationship_type_cd,
               responsibility_type_cd)
              select seq_prod_inst_grid_rel_id.nextval prod_inst_grid_rel_id,
                     v_grid_id grid_id, i_prod_inst_id prod_inst_id,
                     v_rule_inst_id rule_inst_id, '0' event_id,
                     '10' status_cd, sysdate status_date,
                     sysdate create_date, sysdate update_date,
                     cur_prod_inst.area_id, cur_prod_inst.common_region_id,
                     '' update_staff, cur_prod_inst.create_staff,
                     v_rule_id rule_id, '' column_1,
                     seq_prod_inst_grid_rel_id.nextval prod_inst_assign_rel_id,
                     a.team_id chn_org_unit_id, a.staff_id channel_member_id,
                     '10' relationship_type_cd,
                     a.role_type responsibility_type_cd
                from grid_team a
               where a.grid_id = v_grid_id;
          elsif v_count > 0 then
            delete prod_inst_grid_rel
             where prod_inst_id = i_prod_inst_id
               and grid_id = v_grid_id;
            insert into prod_inst_grid_rel
              (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
               event_id, status_cd, status_date, create_date, update_date,
               area_id, region_cd, update_staff, create_staff, rule_id,
               column_1, prod_inst_assign_rel_id, chn_org_unit_id,
               channel_member_id, relationship_type_cd,
               responsibility_type_cd)
              select seq_prod_inst_grid_rel_id.nextval prod_inst_grid_rel_id,
                     v_grid_id grid_id, i_prod_inst_id prod_inst_id,
                     v_rule_inst_id rule_inst_id, '0' event_id,
                     '10' status_cd, sysdate status_date,
                     sysdate create_date, sysdate update_date,
                     cur_prod_inst.area_id, cur_prod_inst.common_region_id,
                     '' update_staff, cur_prod_inst.create_staff,
                     v_rule_id rule_id, '' column_1,
                     seq_prod_inst_grid_rel_id.nextval prod_inst_assign_rel_id,
                     a.team_id chn_org_unit_id, a.staff_id channel_member_id,
                     '10' relationship_type_cd,
                     a.role_type responsibility_type_cd
                from grid_team a
               where a.grid_id = v_grid_id;
          end if;
          --新版本 网格*客户经理--end--2011-6-27---
        end if;
      end loop;

      o_state := '1';
      o_msg   := '成功';
    exception
      when others then
        o_state := '0';
        o_msg   := '失败:' || sqlerrm;
    end;
  end;

  ----3、客户自动划配到客户经理
  ------cust_grid_rel
  /*
  案例名称  客户自动划配到客户经理
  业务场景
  测试目的  验证客户可以自动划配到某个客户经理
  预置条件  1.  存在客户经理A的自动配置规则
  2.  自动划配程序正常运行
  测试过程  1.  新增一个客户C，同时购买一个商务领航的套餐；（满足被自动划配到客户经理A的划配规则，在预置条件中进行检查）
  2.  完成商务领航套餐的订购，并自动开通和竣工
  3.  自动划配程序对客户进行自动划配
  预期结果  1.  客户查询到客户C被自动划配到客户经理A
  */

  procedure p_cust_grid_rel(i_cust_id in number,
                            o_state   out number,
                            o_msg     out varchar2) is
    cur_cust cust%rowtype;
    --
    v_prod_inst_id number(12);
    --
    v_grid_id      grid_rule_inst.grid_id%type;
    v_rule_inst_id grid_rule_inst.rule_inst_id%type;
    v_rule_id      grid_rule_inst.rule_id%type;
    --
    v_count        number(10) := 0;
    v_assign_count number(10) := 0;
  begin
    --0、删除历史已划配客户关联网格数据
    insert into cust_grid_rel_his
      (cust_grid_rel_id, cust_id, grid_id, rule_inst_id, event_id,
       status_cd, status_date, create_date, update_date, area_id, region_cd,
       update_staff, create_staff, rule_id, column_1, his_id)
      select cust_grid_rel_id, cust_id, grid_id, rule_inst_id, event_id,
             status_cd, status_date, create_date, sysdate update_date,
             area_id, region_cd, update_staff, create_staff, rule_id,
             column_1, seq_cust_grid_rel_his_id.nextval his_id
        from cust_grid_rel a
       where cust_id = i_cust_id;
    delete from cust_grid_rel a where cust_id = i_cust_id;

    --1、按行业划配客户
    select count(*)
      into v_count
      from grid_rule a, grid_rule_inst b, grid_rule_inst_attr c,
           attr_value d, cust e
     where a.rule_type = '165'
       and a.rule_id = b.rule_id
       and b.rule_inst_id = c.grid_rule_inst_id
       and c.attr_value_id = d.attr_value_id
       and d.attr_value = e.industry_cd
          -- and b.region_cd = e.region_cd
       and e.cust_id = i_cust_id;
    if v_count > 0 then
      insert into cust_grid_rel
        (cust_grid_rel_id, cust_id, grid_id, rule_inst_id, event_id,
         status_cd, status_date, create_date, update_date, area_id,
         region_cd, update_staff, create_staff, rule_id, column_1)
        select seq_cust_grid_rel_id.nextval cust_grid_rel_id, e.cust_id,
               b.grid_id, b.rule_inst_id, '0' event_id, '10' status_cd,
               sysdate status_date, sysdate create_date, sysdate update_date,
               e.area_id, e.region_cd, '' update_staff, '' create_staff,
               b.rule_id, '' column_1
          from grid_rule f, grid_rule_inst b, grid_rule_inst_attr c,
               attr_value d, cust e
         where f.rule_type = '165'
           and f.rule_id = b.rule_id
           and b.rule_inst_id = c.grid_rule_inst_id
           and c.attr_value_id = d.attr_value_id
           and d.attr_value = e.industry_cd
              -- and b.region_cd = e.region_cd
           and e.cust_id = i_cust_id;

      select count(*)
        into v_assign_count
        from grid_team a, cust_grid_rel b
       where a.grid_id = b.grid_id
         and b.cust_id = i_cust_id;
      if v_assign_count > 0 then
        insert into cust_assign_rel_his
          (his_id, cust_assign_rel_id, chn_org_unit_id, cust_id,
           channel_member_id, relationship_type_cd, responsibility_type_cd,
           area_id, region_cd, status_cd, status_date, create_date,
           create_staff, update_date, update_staff, in_his_date, in_his_type,
           in_his_staff, in_his_desc)
          select seq_cust_assign_rel_his_id.nextval his_id,
                 cust_assign_rel_id, chn_org_unit_id, cust_id,
                 channel_member_id, relationship_type_cd,
                 responsibility_type_cd, area_id, region_cd, status_cd,
                 status_date, create_date, create_staff, update_date,
                 update_staff, sysdate in_his_date, 'mod' in_his_type,
                 '' in_his_staff, '后台修改' in_his_desc
            from cust_assign_rel
           where cust_id = i_cust_id;
        delete from cust_assign_rel where cust_id = i_cust_id;
        insert into cust_assign_rel
          (cust_assign_rel_id, chn_org_unit_id, cust_id, channel_member_id,
           relationship_type_cd, responsibility_type_cd, area_id, region_cd,
           status_cd, create_date, status_date, update_date)
          select seq_cust_assign_rel_id.nextval, a.team_id chn_org_unit_id,
                 i_cust_id cust_id, a.staff_id channel_member_id,
                 '10' relationship_type_cd,
                 a.role_type responsibility_type_cd, b.area_id, b.region_cd,
                 '10' status_cd, sysdate, sysdate, sysdate
            from grid_team a, cust_grid_rel b
           where a.grid_id = b.grid_id
             and b.cust_id = i_cust_id;
      else
        select count(1)
          into v_count
          from cust_assign_rel
         where cust_id = i_cust_id;
        if v_count = 0 then
          insert into cust_assign_rel
            (cust_assign_rel_id, cust_id, area_id, region_cd, status_cd,
             create_date, status_date, update_date, channel_member_id,
             chn_org_unit_id, relationship_type_cd, responsibility_type_cd)
            select seq_cust_assign_rel_id.nextval, i_cust_id cust_id,
                   a.area_id, a.region_cd, '14' status_cd, sysdate, sysdate,
                   sysdate, '0' channel_member_id, '0' chn_org_unit_id,
                   '10' relationship_type_cd, '10' responsibility_type_cd
              from cust a
             where a.cust_id = i_cust_id;
        end if;
      end if;
    else
      --2、按客户对应的最早产品划配客户
      -------------------------------------------
      --------取客户对应的最早产品---------------
      begin
        select a.prod_inst_id
          into v_prod_inst_id
          from prod_inst a, product b
         where a.product_id = b.product_id
           and b.prod_func_type = '101'
           and a.owner_cust_id = i_cust_id
           and a.rowid in
               (select min(a.rowid)
                  from prod_inst a, product b
                 where a.product_id = b.product_id
                   and b.prod_func_type = '101'
                   and a.owner_cust_id = i_cust_id
                   and a.create_date in
                       (select min(a.create_date)
                          from prod_inst a, product b
                         where a.product_id = b.product_id
                           and b.prod_func_type = '101'
                           and a.owner_cust_id = i_cust_id));
      exception
        when others then
          null;
      end;

      -----------取客户信息----------------
      begin
        select area_id, region_cd, create_staff
          into cur_cust.area_id, cur_cust.region_cd, cur_cust.create_staff
          from cust a
         where cust_id = i_cust_id;
      exception
        when no_data_found or too_many_rows then
          cur_cust := null;
      end;

      ----------------------------------------------
      -----------增加客户实例网格关联数据-----------
      ----------------------------------------------
      begin
        --增加划配客户关联网格数据
        for rec in (select distinct grid_id, rule_inst_id, rule_id
                      from prod_inst_grid_rel
                     where prod_inst_id = v_prod_inst_id) loop
          --取得各列的值
          v_grid_id      := rec.grid_id;
          v_rule_inst_id := rec.rule_inst_id;
          v_rule_id      := '999';

          ----如果存在就更新记录，如果不存在就增加记录
          select count(1)
            into v_count
            from cust_grid_rel
           where cust_id = i_cust_id
             and grid_id = v_grid_id;
          if v_count = 0 then
            insert into cust_grid_rel
              (cust_grid_rel_id, cust_id, grid_id, rule_inst_id, event_id,
               status_cd, status_date, create_date, update_date, area_id,
               region_cd, update_staff, create_staff, rule_id, column_1)
              select seq_cust_grid_rel_id.nextval cust_grid_rel_id,
                     i_cust_id cust_id, v_grid_id grid_id,
                     v_rule_inst_id rule_inst_id, '0' event_id,
                     '10' status_cd, sysdate status_date,
                     sysdate create_date, sysdate update_date,
                     cur_cust.area_id, cur_cust.region_cd, '' update_staff,
                     cur_cust.create_staff, v_rule_id rule_id, '' column_1
                from dual;
          elsif v_count = 1 then
            update cust_grid_rel
               set grid_id = v_grid_id, rule_inst_id = v_rule_inst_id,
                   rule_id = v_rule_id, update_date = sysdate
             where cust_id = i_cust_id
               and grid_id = v_grid_id;
          elsif v_count > 1 then
            delete from cust_grid_rel
             where cust_id = i_cust_id
               and grid_id = v_grid_id;
            insert into cust_grid_rel
              (cust_grid_rel_id, cust_id, grid_id, rule_inst_id, event_id,
               status_cd, status_date, create_date, update_date, area_id,
               region_cd, update_staff, create_staff, rule_id, column_1)
              select seq_cust_grid_rel_id.nextval cust_grid_rel_id,
                     i_cust_id cust_id, v_grid_id grid_id,
                     v_rule_inst_id rule_inst_id, '0' event_id,
                     '10' status_cd, sysdate status_date,
                     sysdate create_date, sysdate update_date,
                     cur_cust.area_id, cur_cust.region_cd, '' update_staff,
                     cur_cust.create_staff, v_rule_id rule_id, '' column_1
                from dual;
          end if;
        end loop;
        ---------------------------------------------------------
        --已划配
        select count(*)
          into v_assign_count
          from grid_team a, cust_grid_rel b
         where a.grid_id = b.grid_id
           and not exists (select 1
                  from grid
                 where grid_id = a.grid_id
                   and grid_sort = '13')
           and b.cust_id = i_cust_id;
        if v_assign_count > 0 then
          insert into cust_assign_rel_his
            (his_id, cust_assign_rel_id, chn_org_unit_id, cust_id,
             channel_member_id, relationship_type_cd, responsibility_type_cd,
             area_id, region_cd, status_cd, status_date, create_date,
             create_staff, update_date, update_staff, in_his_date,
             in_his_type, in_his_staff, in_his_desc)
            select seq_cust_assign_rel_his_id.nextval his_id,
                   cust_assign_rel_id, chn_org_unit_id, cust_id,
                   channel_member_id, relationship_type_cd,
                   responsibility_type_cd, area_id, region_cd, status_cd,
                   status_date, create_date, create_staff, update_date,
                   update_staff, sysdate in_his_date, 'mod' in_his_type,
                   '' in_his_staff, '后台修改' in_his_desc
              from cust_assign_rel
             where cust_id = i_cust_id;
          delete from cust_assign_rel where cust_id = i_cust_id;
          insert into cust_assign_rel
            (cust_assign_rel_id, chn_org_unit_id, cust_id,
             channel_member_id, relationship_type_cd, responsibility_type_cd,
             area_id, region_cd, status_cd, create_date, status_date,
             update_date)
            select seq_cust_assign_rel_id.nextval, a.team_id chn_org_unit_id,
                   i_cust_id cust_id, a.staff_id channel_member_id,
                   '10' relationship_type_cd,
                   a.role_type responsibility_type_cd, b.area_id,
                   b.region_cd, '10' status_cd, sysdate, sysdate, sysdate
              from grid_team a, cust_grid_rel b
             where a.grid_id = b.grid_id
               and b.cust_id = i_cust_id;
        else
          --待划配     --增加待划配客户 2011-5-26 ---begin-----------
          select count(1)
            into v_count
            from cust_assign_rel
           where cust_id = i_cust_id;
          if v_count = 0 then
            insert into cust_assign_rel
              (cust_assign_rel_id, cust_id, area_id, region_cd, status_cd,
               create_date, status_date, update_date, channel_member_id,
               chn_org_unit_id, relationship_type_cd, responsibility_type_cd)
              select seq_cust_assign_rel_id.nextval, cust_id, area_id,
                     region_cd, '14' status_cd, sysdate, sysdate, sysdate,
                     '0' channel_member_id, '0' chn_org_unit_id,
                     '10' relationship_type_cd, '10' responsibility_type_cd
                from cust
               where cust_id = i_cust_id;
          end if;
        end if;

        o_state := '1';
        o_msg   := '成功';
      exception
        when others then
          o_state := '0';
          o_msg   := '失败:' || sqlerrm;
      end;
    end if;
  end;

  ----1、订单接口进行产品实例客户划配到网格
  procedure p_main_customer_order is
    --客户订单 10
    --产品订单 13
    ---已竣工
    --接口表
    cursor cur is
      select order_id, intf_order_id
        from update_intf_order
       where op_result = '0';
    v_order_id update_intf_order.order_id%type;
    --
    cursor cur_prod is
      select distinct c.prod_inst_id, c.owner_cust_id cust_id
        from customer_order_his a, order_item_his b, prod_inst c, product d
       where a.cust_order_id = b.cust_order_id
         and b.order_item_cd = '13'
            --and b.status_cd = '13'
         and b.order_item_obj_id = c.prod_inst_id
         and c.product_id = d.product_id
         and d.prod_func_type = '101'
         and a.cust_order_id = v_order_id;
    v_prod_inst_id number(12);
    cursor cur_cust is
      select distinct b.order_item_obj_id cust_id
        from customer_order_his a, order_item_his b
       where a.cust_order_id = b.cust_order_id
         and b.order_item_cd = '10'
            --and b.status_cd = '13'
         and a.cust_order_id = v_order_id;

    o_state number;
    o_msg   varchar2(2000);
  begin
    --取接口数据
    insert into update_intf_order
      (intf_order_id, order_id, intf_id, proc_type, err_num, err_msg,
       proc_num, mdse_id, account, area_id, region_cd, status_cd,
       status_date, create_date, create_staff, update_date, update_staff,
       class_id, op_result)
      select intf_order_id, order_id, intf_id, proc_type, err_num, err_msg,
             proc_num, mdse_id, account, area_id, region_cd, status_cd,
             status_date, create_date, create_staff, update_date,
             update_staff, class_id, 0 op_result
        from intf_order a
       where not exists (select 1
                from update_intf_order b
               where a.intf_order_id = b.intf_order_id);
    commit;
    --处理数据
    for rec in cur loop
      v_order_id := rec.order_id;
      for rec_prod in cur_prod loop
        p_prod_inst_grid_rel(rec_prod.prod_inst_id, o_state, o_msg);
        --客户划配，判断产品是否是客户最早的产品
        begin
          select a.prod_inst_id
            into v_prod_inst_id
            from prod_inst a, product b
           where a.product_id = b.product_id
             and b.prod_func_type = '101'
             and a.owner_cust_id = rec_prod.cust_id
             and a.rowid in
                 (select min(a.rowid)
                    from prod_inst a, product b
                   where a.product_id = b.product_id
                     and b.prod_func_type = '101'
                     and a.owner_cust_id = rec_prod.cust_id
                     and a.create_date in
                         (select min(a.create_date)
                            from prod_inst a, product b
                           where a.product_id = b.product_id
                             and b.prod_func_type = '101'
                             and a.owner_cust_id = rec_prod.cust_id));
        exception
          when others then
            null;
        end;
        if rec_prod.prod_inst_id = v_prod_inst_id then
          p_cust_grid_rel(rec_prod.cust_id, o_state, o_msg);
        end if;
      end loop;

      for rec_cust in cur_cust loop
        p_cust_grid_rel(rec_cust.cust_id, o_state, o_msg);
      end loop;

      --更新接口记录
      update update_intf_order
         set op_result = '1', update_date = sysdate
       where op_result = '0'
         and intf_order_id = rec.intf_order_id;
      commit;
    end loop;
  end;

  ----2、规则变更后产品实例自动重新划配到新网格
  ------update_grid_rule_inst
  /*
  案例名称  规则变更后产品实例自动重新划配到新网格
  业务场景  修改某个认领规则，产品实例能重新进行认领
  测试目的  验证规则变更后产品实例能自动划配到新的网格
  预置条件  1.  提供能够进行划配规则维护和审批的工号A
  2.  根据划配规则，固定产品（A）的安装地址属于网格（G0）
  3.  固定产品A已经被划配到网格（G0）
  4.  自动划配程序运行正常
  测试过程  1.  工号A登录CRM系统，进行划配规则修改；
  2.  选择一条划配规则，调整划配规则，将固定电话A的安装地址的关联规则从网格（G0）调整到网格（G1）
  3.  进行划配规则的变更审核，选择上述修改的规则，审核通过
  4.  自动划配程序对被修改规则相关的产品实例进行重新划配
  预期结果  1.  在规则修改之前，可以看到固定产品A归属网格（G0）
  2.  在规则修改之后，可以看到固定产品A归属网格（G1）
  */
  --RULE_CODE  RULE_NAME  RULE_TYPE
  --R-09  人工待划配 211
  --HDHP  按号段划配 168
  --KHHP  按客户划配 165
  --DZHP  按地址划配 10
  --SBHP  按设备划配 11
  procedure p_main_update_grid_rule_inst is
    cursor cur is
      select distinct a.grid_id, a.rule_inst_id, b.column_1, c.rule_type
        from update_grid_rule_inst a, grid_rule_inst b, grid_rule c
       where a.op_result = '0'
            --  and a.grid_id = b.grid_id
         and a.rule_inst_id = b.rule_inst_id
         and b.rule_id = c.rule_id
         and c.rule_type in ('10', '11')
      union
      select distinct a.grid_id, a.rule_inst_id, b.column_1, c.rule_type
        from update_grid_rule_inst a, grid_rule_inst_his b, grid_rule c
       where a.op_result = '0'
            --  and a.grid_id = b.grid_id
         and a.rule_inst_id = b.rule_inst_id
         and b.rule_id = c.rule_id
         and c.rule_type in ('10', '11');

    cursor cur3 is
      select distinct a.grid_id, a.rule_inst_id, d.attr_value column_1,
                      e.attr_value column_2, c.rule_type, f.region_cd
        from update_grid_rule_inst a, grid_rule_inst b, grid_rule c,
             grid_rule_inst_attr d, grid_rule_inst_attr e, grid f
       where d.attr_id = '27840'
         and e.attr_id = '27841'
         and a.op_result = '0'
         and b.rule_inst_id = d.grid_rule_inst_id
         and b.rule_inst_id = e.grid_rule_inst_id
            --  and a.grid_id = b.grid_id
         and a.rule_inst_id = b.rule_inst_id
         and b.rule_id = c.rule_id
         and b.grid_id = f.grid_id
         and c.rule_type = '168'
      union
      select distinct a.grid_id, a.rule_inst_id, d.attr_value column_1,
                      e.attr_value column_2, c.rule_type, f.region_cd
        from update_grid_rule_inst a, grid_rule_inst_his b, grid_rule c,
             grid_rule_inst_attr_his d, grid_rule_inst_attr_his e, grid f
       where d.attr_id = '27840'
         and e.attr_id = '27841'
         and a.op_result = '0'
         and b.rule_inst_id = d.grid_rule_inst_id
         and b.rule_inst_id = e.grid_rule_inst_id
            -- and a.grid_id = b.grid_id
         and a.rule_inst_id = b.rule_inst_id
         and b.rule_id = c.rule_id
         and b.grid_id = f.grid_id
         and c.rule_type = '168';
    --
    o_state number;
    o_msg   varchar2(2000);
    v_count number(10) := 0;

  begin
    for rec in cur loop
      ----删除历史划配产品关联网格数据
      insert into prod_inst_grid_rel_his
        (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
         event_id, status_cd, status_date, create_date, update_date, area_id,
         region_cd, update_staff, create_staff, rule_id, column_1, his_id)
        select prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
               event_id, status_cd, status_date, create_date,
               sysdate update_date, area_id, region_cd, update_staff,
               create_staff, rule_id, column_1,
               seq_prod_inst_grid_rel_his_id.nextval his_id
          from prod_inst_grid_rel
         where grid_id = rec.grid_id
           and rule_inst_id = rec.rule_inst_id;
      delete from prod_inst_grid_rel
       where grid_id = rec.grid_id
         and rule_inst_id = rec.rule_inst_id;
      -----------------按地址--------------
      if rec.rule_type = '10' then
        --产品
        for rec_addr in (select distinct c.prod_inst_id
                           from (select location_id
                                    from political_location
                                  connect by prior location_id = up_location_id
                                   start with location_id =
                                              to_number(rec.column_1)) a,
                                standard_adress b, prod_inst c
                          where a.location_id = b.location_id
                            and b.adress_id = c.address_id) loop
          p_prod_inst_grid_rel(rec_addr.prod_inst_id, o_state, o_msg);
          v_count := v_count + 1;
          if v_count > 1000 then
            commit;
            v_count := 0;
          end if;
        end loop;
        commit;
        --客户
        for rec_addr in (select distinct c.owner_cust_id cust_id
                           from (select location_id
                                    from political_location
                                  connect by prior location_id = up_location_id
                                   start with location_id =
                                              to_number(rec.column_1)) a,
                                standard_adress b, prod_inst c
                          where a.location_id = b.location_id
                            and b.adress_id = c.address_id) loop
          p_cust_grid_rel(rec_addr.cust_id, o_state, o_msg);
          v_count := v_count + 1;
          if v_count > 1000 then
            commit;
            v_count := 0;
          end if;
        end loop;

        ----------------按设备--------------
      elsif rec.rule_type = '11' then
        --产品
        for rec_addr in (select distinct c.prod_inst_id
                           from (select location_id
                                    from political_location
                                  connect by prior location_id = up_location_id
                                   start with location_id in
                                              (select device_id
                                                 from device
                                                where device_code =
                                                      to_char(rec.column_1))) a,
                                standard_adress b, prod_inst c
                          where a.location_id = b.location_id
                            and b.adress_id = c.address_id) loop
          p_prod_inst_grid_rel(rec_addr.prod_inst_id, o_state, o_msg);
          v_count := v_count + 1;
          if v_count > 1000 then
            commit;
            v_count := 0;
          end if;
        end loop;
        commit;
        --客户
        for rec_addr in (select distinct c.owner_cust_id cust_id
                           from (select location_id
                                    from political_location
                                  connect by prior location_id = up_location_id
                                   start with location_id in
                                              (select device_id
                                                 from device
                                                where device_code =
                                                      to_char(rec.column_1))) a,
                                standard_adress b, prod_inst c
                          where a.location_id = b.location_id
                            and b.adress_id = c.address_id) loop
          p_cust_grid_rel(rec_addr.cust_id, o_state, o_msg);
          v_count := v_count + 1;
          if v_count > 1000 then
            commit;
            v_count := 0;
          end if;
        end loop;
      end if;
      --更新接口记录
      update update_grid_rule_inst
         set op_result = '1', update_date = sysdate
       where op_result = '0'
         and rule_inst_id = rec.rule_inst_id
         and grid_id = rec.grid_id;
      commit;
    end loop;

    ----------------按号段--------------
    for rec in cur3 loop
      --产品
      for rec_addr in (select distinct c.prod_inst_id
                         from prod_inst c
                        where c.acc_nbr between rec.column_1 and
                              rec.column_2
                          and length(c.acc_nbr) = length(rec.column_1)
                          and c.common_region_id = rec.region_cd) loop
        p_prod_inst_grid_rel(rec_addr.prod_inst_id, o_state, o_msg);
        v_count := v_count + 1;
        if v_count > 1000 then
          commit;
          v_count := 0;
        end if;
      end loop;
      commit;
      --客户
      for rec_addr in (select distinct c.owner_cust_id cust_id
                         from prod_inst c
                        where c.acc_nbr between rec.column_1 and
                              rec.column_2
                          and length(c.acc_nbr) = length(rec.column_1)
                          and c.common_region_id = rec.region_cd) loop
        p_cust_grid_rel(rec_addr.cust_id, o_state, o_msg);
        v_count := v_count + 1;
        if v_count > 1000 then
          commit;
          v_count := 0;
        end if;
      end loop;
      --更新接口记录
      update update_grid_rule_inst
         set op_result = '1', update_date = sysdate
       where op_result = '0'
         and rule_inst_id = rec.rule_inst_id
         and grid_id = rec.grid_id;
      commit;
    end loop;
  end;

  --人工划配产品到网格后，客户重新划配到新网格
  ----------------处理人工划配---2011-5-19--TTP：2767-----------
  procedure p_main_grid_reassign is

    o_state number;
    o_msg   varchar2(2000);

    v_count           number(10) := 0;
    v_count_grid_team number(10) := 0;
    v_value_switch    varchar2(10) := '';

    v_prod_inst_id number(12);
  begin
    for rec in (select a.grid_reassign_id, a.grid_id, b.rule_inst_id,
                       b.prod_inst_id, c.owner_cust_id cust_id,
                       b.prod_inst_grid_rel_id
                  from grid_reassign a, prod_inst_grid_rel b, prod_inst c
                 where a.class_id = 104
                   and a.obj_inst_id = b.prod_inst_grid_rel_id
                   and b.prod_inst_id = c.prod_inst_id
                   and a.op_result = '0') loop
      --客户划配，判断产品是否是客户最早的产品
      begin
        select a.prod_inst_id
          into v_prod_inst_id
          from prod_inst a, product b
         where a.product_id = b.product_id
           and b.prod_func_type = '101'
           and a.owner_cust_id = rec.cust_id
           and a.rowid in
               (select min(a.rowid)
                  from prod_inst a, product b
                 where a.product_id = b.product_id
                   and b.prod_func_type = '101'
                   and a.owner_cust_id = rec.cust_id
                   and a.create_date in
                       (select min(a.create_date)
                          from prod_inst a, product b
                         where a.product_id = b.product_id
                           and b.prod_func_type = '101'
                           and a.owner_cust_id = rec.cust_id));
      exception
        when others then
          null;
      end;
      --增加客户网格
      if rec.prod_inst_id = v_prod_inst_id then
        p_cust_grid_rel(rec.cust_id, o_state, o_msg);
      end if;
      --2011-7-4
      ----判断是否有配置客户经理
      select count(1)
        into v_count_grid_team
        from grid_team a
       where a.grid_id = rec.grid_id;
      ----取新旧模式标志(一个产品对应多个渠道成员,Y:按渠道成员及渠道只能单元对应,N:按海南网格对应)
      select attr_value
        into v_value_switch
        from attr_value
       where attr_id = 8241;
      ----
      if v_count_grid_team = 1 and v_value_switch = 'Y' then
        update prod_inst_grid_rel a
           set (chn_org_unit_id, channel_member_id, relationship_type_cd, responsibility_type_cd) = (select b.team_id,
                                                                                                             b.staff_id,
                                                                                                             '10',
                                                                                                             b.role_type
                                                                                                        from grid_team b
                                                                                                       where b.grid_id =
                                                                                                             a.grid_id)
         where a.prod_inst_id = rec.prod_inst_id
           and a.grid_id = rec.grid_id
           and a.prod_inst_grid_rel_id = rec.prod_inst_grid_rel_id;
      elsif v_count_grid_team > 1 and v_value_switch = 'Y' then
        insert into prod_inst_grid_rel
          (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
           event_id, status_cd, status_date, create_date, update_date,
           area_id, region_cd, update_staff, create_staff, rule_id, column_1,
           prod_inst_assign_rel_id, chn_org_unit_id, channel_member_id,
           relationship_type_cd, responsibility_type_cd)
          select seq_prod_inst_grid_rel_id.nextval prod_inst_grid_rel_id,
                 b.grid_id, b.prod_inst_id, b.rule_inst_id, b.event_id,
                 b.status_cd, b.status_date, b.create_date, b.update_date,
                 b.area_id, b.region_cd, b.update_staff, b.create_staff,
                 b.rule_id, b.column_1,
                 seq_prod_inst_grid_rel_id.nextval prod_inst_assign_rel_id,
                 a.team_id chn_org_unit_id, a.staff_id channel_member_id,
                 '10' relationship_type_cd,
                 a.role_type responsibility_type_cd
            from grid_team a, prod_inst_grid_rel b
           where a.grid_id = b.grid_id
             and a.grid_id = rec.grid_id
             and b.prod_inst_id = rec.prod_inst_id;
        --删除多余数据
        insert into prod_inst_grid_rel_his
          (prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
           event_id, status_cd, status_date, create_date, update_date,
           area_id, region_cd, update_staff, create_staff, rule_id, column_1,
           his_id, prod_inst_assign_rel_id, chn_org_unit_id,
           channel_member_id, relationship_type_cd, responsibility_type_cd)
          select prod_inst_grid_rel_id, grid_id, prod_inst_id, rule_inst_id,
                 event_id, status_cd, status_date, create_date,
                 sysdate update_date, area_id, region_cd, update_staff,
                 create_staff, rule_id, column_1,
                 seq_prod_inst_grid_rel_his_id.nextval his_id,
                 prod_inst_assign_rel_id, chn_org_unit_id, channel_member_id,
                 relationship_type_cd, responsibility_type_cd
            from prod_inst_grid_rel
           where prod_inst_grid_rel_id = rec.prod_inst_grid_rel_id;
        delete from prod_inst_grid_rel
         where prod_inst_grid_rel_id = rec.prod_inst_grid_rel_id;
      end if;

      --更新接口记录
      update grid_reassign
         set op_result = '1', update_date = sysdate
       where op_result = '0'
         and grid_reassign_id = rec.grid_reassign_id;

      v_count := v_count + 1;
      if v_count > 1000 then
        commit;
        v_count := 0;
      end if;
    end loop;
    commit;
  end;

  ----4、客户、产品营销和维系关系
  procedure p_main_cust_prod_inst_rel is
    --o_state number;
    --o_msg   varchar2(2000);
    v_count number(10) := 0;
    cursor cur is
      select a.sale_obj_id, a.prod_inst_id, a.owner_cust_id cust_id,
             d.solution_type, c.mkt_campaign_type
        from mkt_sale_obj_list a, mkt_campaign c, mkt_solution d
       where a.status_cd = '10'
         and a.mkt_campaign_id = c.mkt_campaign_id
         and c.mkt_solution_id = d.mkt_solution_id
         and not exists (select 1
                from update_data_log e
               where e.obj_type = '1'
                 and e.obj_id = a.sale_obj_id);
  begin
    for rec in cur loop
      if rec.solution_type = 'YX' then
        --营销关系  10 SOLUTION_TYPE  营销方案  YX
        insert into cust_prod_inst_rel_his
          (cust_prod_inst_rel_id, prod_inst_id, cust_id,
           relationship_type_cd, status_cd, status_date, create_date,
           update_date, area_id, region_cd, update_staff, create_staff,
           his_id)
          select cust_prod_inst_rel_id, prod_inst_id, cust_id,
                 relationship_type_cd, status_cd, status_date, create_date,
                 sysdate update_date, area_id, region_cd, update_staff,
                 create_staff, seq_cust_prod_inst_rel_his_id.nextval his_id
            from cust_prod_inst_rel
           where cust_id = rec.cust_id
             and prod_inst_id = rec.prod_inst_id
             and relationship_type_cd = '10';
        delete from cust_prod_inst_rel
         where cust_id = rec.cust_id
           and prod_inst_id = rec.prod_inst_id
           and relationship_type_cd = '10';
        insert into cust_prod_inst_rel
          (cust_prod_inst_rel_id, prod_inst_id, cust_id,
           relationship_type_cd, status_cd, status_date, create_date,
           update_date, area_id, region_cd, update_staff, create_staff)
          select seq_cust_prod_inst_rel_id.nextval cust_prod_inst_rel_id,
                 a.prod_inst_id, a.owner_cust_id cust_id,
                 '10' relationship_type_cd, 10 status_cd,
                 sysdate status_date, sysdate create_date,
                 sysdate update_date, a.area_id, a.region_cd,
                 '' update_staff, '' create_staff
            from mkt_sale_obj_list a, mkt_campaign c, mkt_solution d
           where a.status_cd = '10'
             and a.mkt_campaign_id = c.mkt_campaign_id
             and c.mkt_solution_id = d.mkt_solution_id
             and d.solution_type = 'YX'
             and a.sale_obj_id = rec.sale_obj_id;
      elsif rec.solution_type = 'WX' then
        --维系关系  11 SOLUTION_TYPE  维系活动  WX
        insert into cust_prod_inst_rel_his
          (cust_prod_inst_rel_id, prod_inst_id, cust_id,
           relationship_type_cd, status_cd, status_date, create_date,
           update_date, area_id, region_cd, update_staff, create_staff,
           his_id)
          select cust_prod_inst_rel_id, prod_inst_id, cust_id,
                 relationship_type_cd, status_cd, status_date, create_date,
                 sysdate update_date, area_id, region_cd, update_staff,
                 create_staff, seq_cust_prod_inst_rel_his_id.nextval his_id
            from cust_prod_inst_rel
           where cust_id = rec.cust_id
             and prod_inst_id = rec.prod_inst_id
             and relationship_type_cd = '11';
        delete from cust_prod_inst_rel
         where cust_id = rec.cust_id
           and prod_inst_id = rec.prod_inst_id
           and relationship_type_cd = '11';
        insert into cust_prod_inst_rel
          (cust_prod_inst_rel_id, prod_inst_id, cust_id,
           relationship_type_cd, status_cd, status_date, create_date,
           update_date, area_id, region_cd, update_staff, create_staff)
          select seq_cust_prod_inst_rel_id.nextval cust_prod_inst_rel_id,
                 a.prod_inst_id, a.owner_cust_id cust_id,
                 '11' relationship_type_cd, 10 status_cd,
                 sysdate status_date, sysdate create_date,
                 sysdate update_date, a.area_id, a.region_cd,
                 '' update_staff, '' create_staff
            from mkt_sale_obj_list a, mkt_campaign c, mkt_solution d
           where a.status_cd = '10'
             and a.mkt_campaign_id = c.mkt_campaign_id
             and c.mkt_solution_id = d.mkt_solution_id
             and d.solution_type = 'WX'
             and a.sale_obj_id = rec.sale_obj_id;
      end if;
      --写日志
      insert into update_data_log
        (obj_type, obj_id, update_date, tab_name, col_name, remark)
      values
        ('1', rec.sale_obj_id, sysdate, 'MKT_SALE_OBJ_LIST', 'SALE_OBJ_ID',
         'cust_prod_inst_rela客户和产品关系');
      --
      v_count := v_count + 1;
      if v_count > 1000 then
        commit;
        v_count := 0;
      end if;
    end loop;
    commit;
  end;

end;
/
