CREATE package body           proc_cross_1TO2 is


  procedure main(i_mdseId       in varchar2, --商品mdseId
                 i_operate      in varchar2, --操作类型
                 o_result       out number,
                 o_errMsg       out varchar2) as     --信息
  i_khId       number(11);
  v_khbm       varchar2(50);
  i_count      number;
  i_party_seq  number(15);
  i_prod_inst_seq       number(15);
  i_prod_offer_inst_seq number(15);
  i_prod_inst_acc_nbr_seq number(15);
  v_service_code        varchar2(100);
  v_account             varchar2(100);
  i_region              number;
  i_areaId              number;
  i_prodId     number(15);
  i_account_id number(15);
  v_agreement_code varchar2(100);
  prod_inst_rela_id number(15);  --1.0中的关系被实例化出来。
  v_zh_account varchar2(100);
  i_zh_region  number;
  i_zh_Prod_inst_id number(15);
  v_prod_spec_id  varchar2(100);
  i_product_id    number(15);
  i_CY_ID         number(15);
  i_cust_seq      number(15);
  i_cust_vpn      number(15);
  i_PARTY_CERTI_ID_seq number(15);
  i_kh_id         number(15);
  i_offer_prod_seq number(15);
  i_Prod_Inst_Rel_seq number(15);
  i_tel_acct_id  number(15);
  i_PAYMENT_PLAN_id number(15);
  i_payment_plan_id2 number(15);
  i_prod_inst_acct_seq number(15);
  i_zg_id number(15);
  i_BATCH_ID  number(15);
  i_attr_id   number(15);
  i_attr_spec_id number(15);
  i_prod_inst_id number(15);
  --i_prod_id      number(15);
  i_priceId      number(15);
  i_priceId_2    number(15);
  i_priceRrelaId number(15);
  i_prod_spec    number(15);
  i_prod_fea_id  number(15);
  i_mdseId_b     number(15);
  i_mdseId_a     number(15);
  i_account_vpn  varchar2(50);
  i_prodOfferInstId number(15);
  i_offer_prod_inst_rel_seq number(15);
  id_prod_inst_rel_seq number(15);
  i_product_a_id    number(15);
  i_product_z_id    number(15);
  i_product_rel_id  number(15);
  v_zgtl     varchar2(10);
  i_mdse_spec_id number(15);
  i_mdse_idb  number(15);
  i_cust_id   number(15);
  v_mdseType varchar2(10);
  o_ceshi varchar2(100);
  i_mdse_roleb number(15);
  v_roleName varchar2(100);
  v_area_code varchar2(10);
  i_prodId_vpn number(15);
  i_region_vpn number(15);
  i_prod_inst_YKSH  number(15);
  i_area_code  varchar2(10);
  i_area      varchar2(10);
  /**
   功能说明：crm1.0跨本地网业务，crm1.0的客户、产品、账户同步到2.0中
   author：fangzn
   创建时间：2012-5-24
  **/
begin
  o_result := 0;
  o_ceshi := '0';  --测试专用日志
  if i_operate = '003'  then  --拆机判断
    --加载一次号码 是否有号码存在 删一卡双号虚号码
    select p.service_code into  v_service_code from  prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
    select p.region,p.area_code into i_region,i_area_code  from  prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
    select p.account into v_account from prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
    select count(*) into i_count from crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where acc_nbr =  v_service_code ;
    o_ceshi := '003-01';  --测试专用日志
    if  i_count = 0 then
      o_errMsg := '2.0中无此业务号码,无需同步';
      o_result := 1;
      return;
    end if;

    --i_area_code := substr(i_area_code,2,3);

    o_ceshi := '003-02';  --测试专用日志
    select prod_inst_id into i_prod_inst_id from crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where acc_nbr =  v_service_code ;

    o_ceshi := '003-03';  --测试专用日志
    /*
    --增量2.0接口机子上计费
    basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
   ('PROD_INST_ATTR','PROD_INST_ATTR_ID',2510359924,'upload','1002','1.0同步到2.0','fangzn','591');
    from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  prod_inst_id in (select prod_inst_z_id from crmv2.Prod_inst_rel@lk_crm1tocrm2db b where b.prod_inst_a_id = i_prod_inst_id );

    for PIA in( select prod_inst_attr_id
    from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  prod_inst_id in (select prod_inst_z_id from crmv2.Prod_inst_rel@lk_crm1tocrm2db b where b.prod_inst_a_id = i_prod_inst_id )
     )LOOP

    end LOOP;*/

    insert into crmv2.prod_inst_attr_his@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE,  VERSION)
    select                          PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_prod_inst_attr_his_id.nextval@lk_crm1tocrm2db, REC_UPDATE_DATE,  VERSION
    from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  prod_inst_id in (select prod_inst_z_id from crmv2.Prod_inst_rel@lk_crm1tocrm2db b where b.prod_inst_a_id = i_prod_inst_id );
    delete crmv2.prod_inst_attr@lk_crm1tocrm2db  where  prod_inst_id in (select prod_inst_z_id from crmv2.Prod_inst_rel@lk_crm1tocrm2db b where b.prod_inst_a_id = i_prod_inst_id );

    --删主副关系
    select  count(*) into i_count from   crmv2.prod_inst_rel@lk_crm1tocrm2db pir where  pir.prod_inst_a_id = i_prod_inst_id   and pir.product_rel_id = '18571';
    if i_count > 0 then
      insert into crmv2.Prod_inst_rel_his@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE)
      select                         PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_Prod_inst_rel_his_id.Nextval@lk_crm1tocrm2db, REC_UPDATE_DATE
      from crmv2.Prod_inst_rel@lk_crm1tocrm2db where prod_inst_a_id = i_prod_inst_id   and product_rel_id = '18571';
      delete crmv2.Prod_inst_rel@lk_crm1tocrm2db where prod_inst_a_id = i_prod_inst_id   and product_rel_id = '18571';
    end if;

    select  count(*) into i_count from   crmv2.prod_inst_rel@lk_crm1tocrm2db pir where  pir.prod_inst_a_id = i_prod_inst_id and
    exists (select 'X' from  crmv2.prod_inst@lk_crm1tocrm2db pi where pi.prod_inst_id = pir.prod_inst_z_id and pi.product_id in(800551836,800575119));
    o_ceshi := '003-0312';
    if i_count = 1 then
      select  pir.prod_inst_z_id  into i_prod_inst_YKSH from crmv2.prod_inst_rel@lk_crm1tocrm2db pir where  pir.prod_inst_a_id = i_prod_inst_id and
      exists (select 'X' from  crmv2.prod_inst@lk_crm1tocrm2db pi where pi.prod_inst_id = pir.prod_inst_z_id and pi.product_id in(800551836,800575119));

      insert into crmv2.Prod_inst_rel_his@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE)
      select                         PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_Prod_inst_rel_his_id.Nextval@lk_crm1tocrm2db, REC_UPDATE_DATE
      from crmv2.Prod_inst_rel@lk_crm1tocrm2db where prod_inst_z_id = i_prod_inst_YKSH;
      delete crmv2.Prod_inst_rel@lk_crm1tocrm2db where prod_inst_z_id = i_prod_inst_YKSH;

      insert into crmv2.prod_inst_his@lk_crm1tocrm2db (PROD_INST_ID, PRODUCT_ID, ACC_PROD_INST_ID, ADDRESS_ID, OWNER_CUST_ID, PAYMENT_MODE_CD, PRODUCT_PASSWORD, IMPORTANT_LEVEL, AREA_CODE, ACC_NBR, EXCH_ID, COMMON_REGION_ID, REMARK, PAY_CYCLE, BEGIN_RENT_TIME, STOP_RENT_TIME, FINISH_TIME, STOP_STATUS, STATUS_CD, CREATE_DATE, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, USE_CUST_ID, EXT_PROD_INST_ID, ADDRESS_DESC, AREA_ID, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE, ACCOUNT, COMMUNITY_ID, VERSION)
      select PROD_INST_ID, PRODUCT_ID, ACC_PROD_INST_ID, ADDRESS_ID, OWNER_CUST_ID, PAYMENT_MODE_CD, PRODUCT_PASSWORD, IMPORTANT_LEVEL, AREA_CODE, ACC_NBR, EXCH_ID, COMMON_REGION_ID, REMARK, PAY_CYCLE, BEGIN_RENT_TIME, STOP_RENT_TIME, FINISH_TIME, STOP_STATUS, STATUS_CD, CREATE_DATE, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, USE_CUST_ID, EXT_PROD_INST_ID, ADDRESS_DESC, AREA_ID, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_prod_inst_his_id.nextval@lk_crm1tocrm2db, REC_UPDATE_DATE, ACCOUNT, COMMUNITY_ID, VERSION
      from crmv2.prod_inst@lk_crm1tocrm2db where  prod_inst_id = i_prod_inst_YKSH;
      delete  crmv2.prod_inst@lk_crm1tocrm2db where  prod_inst_id = i_prod_inst_YKSH;

    end if;
    o_ceshi := '003-04';  --测试专用日志
    insert into crmv2.Prod_inst_rel_his@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE)
    select                         PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_Prod_inst_rel_his_id.Nextval@lk_crm1tocrm2db, REC_UPDATE_DATE
    from crmv2.Prod_inst_rel@lk_crm1tocrm2db where prod_inst_z_id in (select prod_inst_z_id from crmv2.Prod_inst_rel@lk_crm1tocrm2db b where b.prod_inst_a_id = i_prod_inst_id );
    delete crmv2.Prod_inst_rel@lk_crm1tocrm2db where prod_inst_z_id in (select prod_inst_z_id from crmv2.Prod_inst_rel@lk_crm1tocrm2db b where b.prod_inst_a_id = i_prod_inst_id );
    o_ceshi := '003-05';  --测试专用日志
    insert into crmv2.prod_offer_inst_attr_his@lk_crm1tocrm2db (PROD_OFFER_INST_ATTR_ID, PROD_OFFER_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, CREATE_DATE, EXP_DATE, EFF_DATE, STATUS_DATE, STATUS_CD, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE, VERSION)
    select                                PROD_OFFER_INST_ATTR_ID, PROD_OFFER_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, CREATE_DATE, EXP_DATE, EFF_DATE, STATUS_DATE, STATUS_CD, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.SEQ_PROD_OFFER_INST_ATTR_2_ID.nextval@lk_crm1tocrm2db, REC_UPDATE_DATE, VERSION
    from crmv2.prod_offer_inst_attr@lk_crm1tocrm2db a where  a.prod_offer_inst_id in
        (  select prod_offer_inst_id from crmv2.offer_prod_inst_rel@lk_crm1tocrm2db     where  prod_inst_id = i_prod_inst_id );
    delete crmv2.prod_offer_inst_attr@lk_crm1tocrm2db a where  a.prod_offer_inst_id in
        (  select prod_offer_inst_id from crmv2.offer_prod_inst_rel@lk_crm1tocrm2db     where  prod_inst_id = i_prod_inst_id );
    o_ceshi := '003-06';  --测试专用日志
    insert into crmv2.prod_offer_inst_his@lk_crm1tocrm2db (PROD_OFFER_INST_ID, PROD_OFFER_ID, CUST_ID, CHANNEL_ID, CREATE_DATE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, REGION, UPDATE_DATE, PROC_SERIAL, EXT_PROD_OFFER_INST_ID, LAN_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE, TRIAL_EFF_DATE, TRIAL_EXP_DATE, SERVICE_NBR, VERSION)
    select                           PROD_OFFER_INST_ID, PROD_OFFER_ID, CUST_ID, CHANNEL_ID, CREATE_DATE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, REGION, UPDATE_DATE, PROC_SERIAL, EXT_PROD_OFFER_INST_ID, '', AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_prod_offer_inst_his_id.nextval@lk_crm1tocrm2db, REC_UPDATE_DATE, TRIAL_EFF_DATE, TRIAL_EXP_DATE, SERVICE_NBR, VERSION
    from crmv2.prod_offer_inst@lk_crm1tocrm2db a  where a.prod_offer_inst_id in (select prod_offer_inst_id from   crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where prod_inst_id = i_prod_inst_id ) ;
    delete crmv2.prod_offer_inst@lk_crm1tocrm2db a  where a.prod_offer_inst_id in (select prod_offer_inst_id from   crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where prod_inst_id = i_prod_inst_id ) ;
    o_ceshi := '003-07';  --测试专用日志
    insert into crmv2.offer_prod_inst_rel_his@lk_crm1tocrm2db (OFFER_PROD_INST_REL_ID, PROD_INST_ID, PROD_OFFER_INST_ID, ROLE_CD, OFFER_PROD_INST_REL_ROLE_ID, STATUS_CD, STATUS_DATE, CREATE_DATE, EFF_DATE, EXP_DATE, UPDATE_DATE, PROC_SERIAL, OFFER_PROD_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE)
    select                               OFFER_PROD_INST_REL_ID, PROD_INST_ID, PROD_OFFER_INST_ID, ROLE_CD, OFFER_PROD_INST_REL_ROLE_ID, STATUS_CD, STATUS_DATE, CREATE_DATE, EFF_DATE, EXP_DATE, UPDATE_DATE, PROC_SERIAL, OFFER_PROD_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_offer_prod_inst_rel_his_id.nextval@lk_crm1tocrm2db, REC_UPDATE_DATE
    from crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where prod_inst_id = i_prod_inst_id;
    delete crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where prod_inst_id = i_prod_inst_id;
    o_ceshi := '003-08';  --测试专用日志
    insert into crmv2.prod_inst_attr_his@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE,  VERSION)
    select                          PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_prod_inst_attr_his_id.nextval@lk_crm1tocrm2db, REC_UPDATE_DATE,  VERSION
    from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  prod_inst_id = i_prod_inst_id;
    delete crmv2.prod_inst_attr@lk_crm1tocrm2db  where  prod_inst_id = i_prod_inst_id;
    o_ceshi := '003-09';  --测试专用日志
    insert into crmv2.prod_inst_acc_nbr_his@lk_crm1tocrm2db (PROD_INST_ACC_NBR_ID, ACC_NBR_TYPE_CD, ACC_NBR, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PROD_INST_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, HIS_ID, AREA_CODE)
    select                             PROD_INST_ACC_NBR_ID, ACC_NBR_TYPE_CD, ACC_NBR, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PROD_INST_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_prod_inst_acc_nbr_his_id.nextval@lk_crm1tocrm2db, AREA_CODE
    from crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where prod_inst_id = i_prod_inst_id;
    delete crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where prod_inst_id = i_prod_inst_id;
    o_ceshi := '003-10';  --测试专用日志
    insert into crmv2.prod_inst_his@lk_crm1tocrm2db (PROD_INST_ID, PRODUCT_ID, ACC_PROD_INST_ID, ADDRESS_ID, OWNER_CUST_ID, PAYMENT_MODE_CD, PRODUCT_PASSWORD, IMPORTANT_LEVEL, AREA_CODE, ACC_NBR, EXCH_ID, COMMON_REGION_ID, REMARK, PAY_CYCLE, BEGIN_RENT_TIME, STOP_RENT_TIME, FINISH_TIME, STOP_STATUS, STATUS_CD, CREATE_DATE, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, USE_CUST_ID, EXT_PROD_INST_ID, ADDRESS_DESC, AREA_ID, UPDATE_STAFF, CREATE_STAFF, HIS_ID, REC_UPDATE_DATE, ACCOUNT, COMMUNITY_ID, VERSION)
    select PROD_INST_ID, PRODUCT_ID, ACC_PROD_INST_ID, ADDRESS_ID, OWNER_CUST_ID, PAYMENT_MODE_CD, PRODUCT_PASSWORD, IMPORTANT_LEVEL, AREA_CODE, ACC_NBR, EXCH_ID, COMMON_REGION_ID, REMARK, PAY_CYCLE, BEGIN_RENT_TIME, STOP_RENT_TIME, FINISH_TIME, STOP_STATUS, STATUS_CD, CREATE_DATE, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, USE_CUST_ID, EXT_PROD_INST_ID, ADDRESS_DESC, AREA_ID, UPDATE_STAFF, CREATE_STAFF, crmv2.seq_prod_inst_his_id.nextval@lk_crm1tocrm2db, REC_UPDATE_DATE, ACCOUNT, COMMUNITY_ID, VERSION
    from crmv2.prod_inst@lk_crm1tocrm2db where  prod_inst_id = i_prod_inst_id;
    delete  crmv2.prod_inst@lk_crm1tocrm2db where  prod_inst_id = i_prod_inst_id;

    o_errMsg := '成功';
    o_result := 1;

    return;
  end if;

  select crmv2.SEQ_CROSS_LOCALAREA_BATCH_ID.NEXTVAL@lk_crm1tocrm2db into i_BATCH_ID from  dual;
  o_ceshi := '001-01';  --测试专用日志
  proc_cross_kh_1TO2(i_mdseId,i_BATCH_ID,i_cust_seq,o_errMsg );
  o_ceshi := '001-02';  --测试专用日志
  --同步组合套餐 与同步组合套餐参数
  select m.mdse_type into v_mdseType  from  mdse m    where mdse_id = i_mdseId ;
  if  v_mdseType = '105' then
    proc_cross_prod_1TO2(i_mdseId,'', i_cust_seq, i_BATCH_ID, o_errMsg);
    o_errMsg := '成功';
    o_result := 1;
    return;
  end if;

  o_ceshi := '001-03';  --测试专用日志
  select p.prod_id,p.prod_spec_id into i_prodId,i_prod_spec from prod p, mdse m where m.mdse_id =i_mdseId  and m.prod_id = p.prod_id ;

  --同步产品信息
  o_errMsg := '产品信息同步';

  select count(*) into i_count from  prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and  p.service_code like '%FZGJ%';
  if i_count >0 then
    o_errMsg := '福州割接号码不允许再次同步到2.0';
    return;
  end if;



  select p.service_code into  v_service_code from  prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
  select p.region,p.area_code into i_region, v_area_code from  prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
  select p.account into v_account from prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;

  if i_region = 2 then
    o_errMsg := '福州割接号码不允许再次同步到2.0造成档案异常';
    return;
  end if;

  select count(*) into i_count from crmv2.prod_inst@lk_crm1tocrm2db pi, crmv2.prod_inst_rel@lk_crm1tocrm2db pir
    where account = v_service_code and pir.prod_inst_z_id = pi.prod_inst_id
    and pir.product_rel_id in('18572', '18571');
  if i_count > 0 then
    o_errMsg := '一卡双号关系已经生成，不允许再次同步，造成数据错误,请确认!';
    return;
  end if;

  select count(*) into i_count from crmv2.prod_inst@lk_crm1tocrm2db pi, crmv2.prod_inst_rel@lk_crm1tocrm2db pir
    where account = v_service_code and pir.prod_inst_a_id = pi.prod_inst_id
    and pir.product_rel_id in('18572', '18571');
  if i_count > 0 then
    o_result := 1;
    o_errMsg := '已经同步关系。无需再次同步数据';
    return;
  end if;

  select p.standardcode into i_area from mdse m, p_area p where  m.mdse_id = i_mdseId and m.region = p.id;
  i_area := substr(i_area, 2, 3);
  i_area := '590';
  delete crmv2.prod_inst@lk_crm1tocrm2db  where account = v_service_code;
  delete crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where acc_nbr= v_service_code;
  select count(*) into i_count from crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where acc_nbr =  v_service_code and  area_code = v_area_code;


  o_ceshi := '001-04';  --测试专用日志
  if i_count = 0 then

    proc_cross_prod_1TO2(i_mdseId,'', i_cust_seq, i_BATCH_ID, o_errMsg);

   o_ceshi := '001-05';  --测试专用日志
    --判断同步的是否是"综合VPN" 是的话，查找是否有上级 企业总机 有的话把 企业总机也同步过来
    select mdse_spec_id into i_mdse_spec_id from mdse where mdse_id = i_mdseId;
    if i_mdse_spec_id = 610157919 then
      for MR in(select mdse_ida , mdse_idb from mdse_rela where mdse_idb = i_mdseId and rela_type = '150')LOOP
        o_ceshi := '001-06';  --测试专用日志
        --同步企业总机
        proc_cross_kh_1TO2(MR.MDSE_IDA,i_BATCH_ID,i_cust_id,o_errMsg );
        o_ceshi := '001-07';  --测试专用日志
        proc_cross_prod_1TO2(MR.MDSE_IDA,i_mdseId, i_cust_id,i_BATCH_ID, o_errMsg);
        o_ceshi := '001-08';  --测试专用日志
        /*
        select count(*) into i_count from mdse_rela where mdse_ida = MR.MDSE_IDA  and rela_type = '151';
        if  i_count = 1 then
          select mdse_idb into i_mdse_idb from mdse_rela where mdse_ida = MR.MDSE_IDA  and rela_type = '151';
          proc_cross_prod_1TO2(i_mdse_idb, i_cust_seq,i_BATCH_ID, o_errMsg);
        end if;    */
        --企业总机 与 综合VPN
        --prod_offer_id   prod_int   offer_prod_inst_rel
        --查出两个号码
        --加关联结束
      end LOOP;
    end if;
    --在查询一次
   select count(*) into i_count from crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where acc_nbr =  v_service_code and  region_cd = i_region;
   if i_count = 0 then
     o_errMsg := '产品信息同步失败不成功';
   end if;
   o_ceshi := '001-09';  --测试专用日志
   select prod_inst_id into i_prod_inst_seq from crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where acc_nbr =  v_service_code and  region_cd = i_region;
  select product_id into i_product_z_id from crmv2.prod_inst@lk_crm1tocrm2db where prod_inst_id = i_prod_inst_seq;
  --select prod_offer_inst_id into i_prod_offer_inst_seq from crmv2.offer_prod_inst_rel@lk_crm1tocrm2db  where prod_inst_id = i_prod_inst_seq;


    --是否是天翼，是否有那个套餐与那个特性 有的话就割接到2.0去。
    select count(*) into i_count from  mdse_rela a, mdse b, prod p where a.mdse_idb = i_mdseId and a.rela_type = '197' and
     a.mdse_ida = b.mdse_id and p.prod_id = b.prod_id;
    o_ceshi := '001-10';  --测试专用日志
    if i_prod_spec = 610003886 and  i_count = 0  then

      select count(*) into i_count
        from prod_fea a
       where a.prod_id = i_prodId
         and exists (select 'X' from prod_fea_spec b where b.code = 'YKSH' and a.fea_spec_id = b.fea_spec_id );
      if i_count >0 then
        --同步这个特性
        o_ceshi := 'texing_001-10';--测试专用日志
        select attr_id into i_attr_spec_id from  crmv2.attr_spec@lk_crm1tocrm2db  where java_code = 'YKSH';
       select prod_fea_id into i_prod_fea_id
         from prod_fea a
        where a.prod_id = i_prodId
          and exists (select 'X' from prod_fea_spec b where b.code = 'YKSH' and a.fea_spec_id = b.fea_spec_id );
        o_ceshi := 'texing_001-11';--测试专用日志
        select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
        insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
        select i_attr_id, i_prod_inst_seq, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
        from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', i_prod_fea_id, i_attr_id, sysdate, '同步特性属性表',i_BATCH_ID);

        i_count:=1;
      end if;

      --是否有天翼超无 有的话也要进行同步 天翼超无
      select count(*) into i_count from mdse_rela  where rela_type = '178' and  mdse_ida = i_mdseId;
      if i_count > 0  then
        o_ceshi := '2-002-1';--测试专用日志
        select crmv2.seq_prod_inst_id.nextval@lk_crm1tocrm2db into prod_inst_rela_id from dual;
        insert into crmv2.prod_inst@lk_crm1tocrm2db ( PROD_INST_ID, PRODUCT_ID, ACC_PROD_INST_ID, ADDRESS_ID, OWNER_CUST_ID, PAYMENT_MODE_CD, PRODUCT_PASSWORD, IMPORTANT_LEVEL, AREA_CODE, ACC_NBR, EXCH_ID, COMMON_REGION_ID, REMARK, PAY_CYCLE, BEGIN_RENT_TIME, STOP_RENT_TIME, FINISH_TIME, STOP_STATUS, STATUS_CD, CREATE_DATE, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, USE_CUST_ID, EXT_PROD_INST_ID, ADDRESS_DESC, AREA_ID, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE, ACCOUNT, VERSION)
        select prod_inst_rela_id,     800000048, '', p.address_id, i_cust_seq, '', '', '', p.area_code, '', '', 1, '', '', p.create_date, p.rent_date, p.create_date, '0', '100000', p.create_date, p.modify_date, p.modify_date, '51499029', i_cust_seq, '', '', 1, '', '', null, '', '1'
        from  prod p, mdse m,p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region ;
        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_INST','PROD_INST_ID',prod_inst_rela_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.prod_inst_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
        select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db, prod_inst_id, null, p.area_id, p.common_region_id, p.status_cd, p.status_date, p.create_date, null, sysdate, null
         from  crmv2.prod_inst@lk_crm1tocrm2db  p where  PROD_INST_ID =  prod_inst_rela_id;

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst', '', prod_inst_rela_id, sysdate, '同步产品实例表',i_BATCH_ID);
        o_ceshi := '2-002-2';--测试专用日志
        select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=4;

        select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
        insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
        select i_attr_id, prod_inst_rela_id, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
        from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

       --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);
        o_ceshi := '2-002-3';--测试专用日志

        --这个是虚号码的
        select crmv2.seq_Prod_inst_rel_id.Nextval@lk_crm1tocrm2db into i_Prod_Inst_Rel_seq from dual;
        insert into crmv2.Prod_inst_rel@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
        select  i_Prod_Inst_Rel_seq, i_prod_inst_seq, prod_inst_rela_id, '100600', null, null, a.eff_date, a.exp_date, a.create_date, '1000', a.modify_date, a.modify_date, '', 18283, 1, 1, '', '', null
        from mdse_rela a where a.mdse_ida = i_mdseId and a.rela_type = '178';
        --这个是主号码的
        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_INST_REL','PROD_INST_REL_ID',i_Prod_Inst_Rel_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'Prod_inst_rel', '', i_Prod_Inst_Rel_seq, sysdate, '同步产品实例关联表',i_BATCH_ID);

        o_ceshi := '2-002-4';--测试专用日志
        select count(*) into i_count  from mdse_rela a, mdse b, prod p where a.mdse_ida = i_mdseId and a.rela_type = '178' and
         a.mdse_idb = b.mdse_id and p.prod_id = b.prod_id;

        if  i_count = 0 then
          o_errMsg := '1.0主号码获取失败无法同步关联数据';

        end if;

        select p.account, p.region into  v_zh_account, i_zh_region  from mdse_rela a, mdse b, prod p where a.mdse_ida = i_mdseId and a.rela_type = '197' and
         a.mdse_idb = b.mdse_id and p.prod_id = b.prod_id;
        o_ceshi := '2-002-5';--测试专用日志
        select count(*) into i_count  from  crmv2.Prod_inst@lk_crm1tocrm2db where account = v_zh_account  and common_region_id = i_zh_region;
        --同步进天翼超无B端的号码到2.0去。
        if i_count = 0 then
           select b.mdse_id into  i_mdseId_b  from mdse_rela a, mdse b, prod p where a.mdse_ida = i_mdseId and a.rela_type = '197' and
           a.mdse_idb = b.mdse_id and p.prod_id = b.prod_id;
           proc_cross_prod_1TO2(i_mdseId_b,'',i_cust_seq,i_BATCH_ID, o_errMsg);
        end if;

        select Prod_inst_id into i_zh_Prod_inst_id from  crmv2.Prod_inst@lk_crm1tocrm2db where account = v_zh_account  and common_region_id = i_zh_region;

        select crmv2.seq_Prod_inst_rel_id.Nextval@lk_crm1tocrm2db into i_Prod_Inst_Rel_seq from dual;
        insert into crmv2.Prod_inst_rel@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
        select i_Prod_Inst_Rel_seq, i_zh_Prod_inst_id, prod_inst_rela_id, '100600', null, 330, a.eff_date, a.exp_date, a.create_date, '1000', a.modify_date, a.modify_date, '', 18284, 1, 1, '', '', null
        from mdse_rela a, mdse b where a.mdse_ida = i_mdseId and a.rela_type = '178' ;
        o_ceshi := '2-002-6';--测试专用日志
        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_INST_REL','PROD_INST_REL_ID',i_Prod_Inst_Rel_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'Prod_inst_rel', '', i_Prod_Inst_Rel_seq, sysdate, '同步产品实例关联表',i_BATCH_ID);

      end if;

      --同步军翼网 与 综合VPN
      select count(*) into i_count
        from mdse_rela mr
       where mr.mdse_idb = i_mdseId
         and mr.rela_type = '105'
         and exists (select 'X'
                from mdse m, zb a
               where m.mdse_id = mr.mdse_ida
                 and m.mdse_spec_id = a.zbbm
                 and a.zbfl = 'CZKT_CDMA_013_LIMIT');

       if i_count > 0 then
          o_ceshi := '3-002-1';--测试专用日志
          select mr.mdse_ida, mr.mdseb_role into i_mdseId_a, i_mdse_roleb
            from mdse_rela mr
           where mr.mdse_idb = i_mdseId
             and mr.rela_type = '105'
             and exists (select 'X'
                    from mdse m, zb a
                   where m.mdse_id = mr.mdse_ida
                     and m.mdse_spec_id = a.zbbm
                     and a.zbfl = 'CZKT_CDMA_013_LIMIT');
          -- 查出角色名称 用来做为2.0 角色获取来入网
          select name into v_roleName from  prefer_mdse_spec_rela where rela_id = i_mdse_roleb;

          select p.account,p.prod_id,p.region into i_account_vpn,i_prodId_vpn,i_region_vpn from prod p , mdse m where m.mdse_id = i_mdseId_a and  m.prod_id = p.prod_id ;

          select count(*) into i_count  from  crmv2.Prod_inst@lk_crm1tocrm2db where account = i_account_vpn;

          o_ceshi := '3-002-2';--测试专用日志
          proc_cross_kh_1TO2(i_mdseId_a,i_BATCH_ID,i_cust_vpn,o_errMsg);
          if i_count = 0 then
          o_ceshi := '3-002-223';--测试专用日志
          proc_cross_prod_1TO2(i_mdseId_a,'',i_cust_vpn,i_BATCH_ID, o_errMsg);
          end if;
          select p.account,p.prod_id,p.region into i_account_vpn,i_prodId_vpn,i_region_vpn from prod p , mdse m where m.mdse_id = i_mdseId_a and  m.prod_id = p.prod_id ;

          --select Prod_inst_id, product_id into i_zh_Prod_inst_id, i_product_a_id  from  crmv2.Prod_inst@lk_crm1tocrm2db where account = v_zh_account  and common_region_id = i_zh_region;
          select Prod_inst_id, product_id into i_zh_Prod_inst_id, i_product_a_id  from  crmv2.Prod_inst@lk_crm1tocrm2db where account = i_account_vpn;
          --select prod_offer_inst_id into i_prodOfferInstId from  crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where Prod_inst_id = i_zh_Prod_inst_id ;
          o_ceshi := '3-002-3';--测试专用日志
          proc_cross_account_1TO2(i_prodId_vpn,i_BATCH_ID,i_region_vpn,i_cust_vpn,i_zh_Prod_inst_id,o_errMsg );
          o_ceshi := '3-002-33';--测试专用日志
          select product_rel_id into i_product_rel_id from crmv2.product_relation@lk_crm1tocrm2db a where  a.product_a_id = i_product_a_id and a.product_z_id = i_product_z_id
           and exists ( select 'X' from CRMV2.PRODUCT_REL_ROLE@lk_crm1tocrm2db b where b.ROLE_CD = a.ROLE_CD and b.role_name = v_roleName);
           select pa.super into i_areaId from p_area pa where pa.id =i_region;
          select crmv2.seq_prod_inst_rel_id.nextval@lk_crm1tocrm2db into id_prod_inst_rel_seq  from dual;
          insert into crmv2.prod_inst_rel@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          values (id_prod_inst_rel_seq, i_zh_Prod_inst_id , i_prod_inst_seq, '100300', null, '', sysdate, to_date('01-01-2199', 'dd-mm-yyyy'), sysdate, '1000', sysdate, sysdate, '', i_product_rel_id,  i_areaId, i_region, '', '', null);

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_INST_REL','PROD_INST_REL_ID',id_prod_inst_rel_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);



       end if;


    end if;
    o_ceshi := '001-11';  --测试专用日志
    select count(*) into i_count from  mdse_rela a, mdse b, prod p where a.mdse_idb = i_mdseId and a.rela_type = '197' and
     a.mdse_ida = b.mdse_id and p.prod_id = b.prod_id;

    if i_count > 0 then
      --添加关系  800551836 是一卡双号的程控   这的时间是否要用 mdse_rela 表的那些数据的时间
      select crmv2.seq_prod_inst_id.nextval@lk_crm1tocrm2db into prod_inst_rela_id from dual;
      insert into crmv2.prod_inst@lk_crm1tocrm2db ( PROD_INST_ID, PRODUCT_ID, ACC_PROD_INST_ID, ADDRESS_ID, OWNER_CUST_ID, PAYMENT_MODE_CD, PRODUCT_PASSWORD, IMPORTANT_LEVEL, AREA_CODE, ACC_NBR, EXCH_ID, COMMON_REGION_ID, REMARK, PAY_CYCLE, BEGIN_RENT_TIME, STOP_RENT_TIME, FINISH_TIME, STOP_STATUS, STATUS_CD, CREATE_DATE, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, USE_CUST_ID, EXT_PROD_INST_ID, ADDRESS_DESC, AREA_ID, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE, ACCOUNT, VERSION)
      select prod_inst_rela_id,     800551836, '', p.address_id, i_cust_seq, '', '', '', p.area_code, '', '', 1, '', '', p.create_date, p.rent_date, p.create_date, '0', '100000', p.create_date, p.modify_date, p.modify_date, '51499029', i_cust_seq, '', '', 1, '', '', null, '', '1'
      from  prod p, mdse m,p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region ;
      --增量2.0计费
      basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
      ('PROD_INST','PROD_INST_ID',prod_inst_rela_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

      insert into crmv2.prod_inst_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db, prod_inst_id, null, p.area_id, p.common_region_id, p.status_cd, p.status_date, p.create_date, null, sysdate, null
       from  crmv2.prod_inst@lk_crm1tocrm2db  p where  PROD_INST_ID =  prod_inst_rela_id;

      o_ceshi := '4-002-1';--测试专用日志
      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst', '', prod_inst_rela_id, sysdate, '同步产品实例表',i_BATCH_ID);

      select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=4;

      select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
      insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
      select i_attr_id, prod_inst_rela_id, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
      from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

      --增量2.0计费
      basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
      ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

      o_ceshi := '4-002-2';--测试专用日志
      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);


      --这个是虚号码的
      select crmv2.seq_Prod_inst_rel_id.Nextval@lk_crm1tocrm2db into i_Prod_Inst_Rel_seq from dual;
      insert into crmv2.Prod_inst_rel@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
      select  i_Prod_Inst_Rel_seq, i_prod_inst_seq, prod_inst_rela_id, '100600', null, null, b.eff_date, b.exp_date, a.create_date, '1000', a.modify_date, a.modify_date, '', 18283, 1, 1, '', '', null
      from mdse_rela a, mdse b where a.mdse_idb = i_mdseId and a.rela_type = '197' and
       a.mdse_ida = b.mdse_id ;
      --增量2.0计费
      basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
      ('PROD_INST_REL','PROD_INST_REL_ID',i_Prod_Inst_Rel_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

      --这个是主号码的
      o_ceshi := '4-002-3';--测试专用日志
      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'Prod_inst_rel', '', i_Prod_Inst_Rel_seq, sysdate, '同步产品实例关联表',i_BATCH_ID);


      select count(*) into i_count  from mdse_rela a, mdse b, prod p where a.mdse_idb = i_mdseId and a.rela_type = '197' and
       a.mdse_ida = b.mdse_id and p.prod_id = b.prod_id;

      if  i_count = 0 then
        o_errMsg := '1.0主号码获取失败无法同步关联数据';

      end if;
      o_ceshi := '4-002-4';--测试专用日志
      select p.account, p.region into  v_zh_account, i_zh_region  from mdse_rela a, mdse b, prod p where a.mdse_idb = i_mdseId and a.rela_type = '197' and
       a.mdse_ida = b.mdse_id and p.prod_id = b.prod_id;

      select count(*) into i_count  from  crmv2.Prod_inst@lk_crm1tocrm2db where account = v_zh_account  and area_id = i_zh_region;

      if i_count = 0 then
        o_errMsg := '2.0主号码获取失败无法同步关联数据';
      end if;

      select Prod_inst_id into i_zh_Prod_inst_id from  crmv2.Prod_inst@lk_crm1tocrm2db where account = v_zh_account  and area_id = i_zh_region;
      o_ceshi := '4-002-5';--测试专用日志
      select crmv2.seq_Prod_inst_rel_id.Nextval@lk_crm1tocrm2db into i_Prod_Inst_Rel_seq from dual;
      insert into crmv2.Prod_inst_rel@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
      select i_Prod_Inst_Rel_seq, i_zh_Prod_inst_id, prod_inst_rela_id, '100600', null, 330, a.eff_date, a.exp_date, a.create_date, '1000', a.modify_date, a.modify_date, '', 18284, 1, 1, '', '', null
      from mdse_rela a, mdse b where a.mdse_idb = i_mdseId and a.rela_type = '197' and
       a.mdse_ida = b.mdse_id ;
      --增量2.0计费
      basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
      ('PROD_INST_REL','PROD_INST_REL_ID',i_Prod_Inst_Rel_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'Prod_inst_rel', '', i_Prod_Inst_Rel_seq, sysdate, '同步产品实例关联表',i_BATCH_ID);

      --添加主从关系
      select Prod_inst_id into i_zh_Prod_inst_id from  crmv2.Prod_inst@lk_crm1tocrm2db where account = v_zh_account  and area_id = i_zh_region;
      o_ceshi := '4-002-55';--测试专用日志
      select crmv2.seq_Prod_inst_rel_id.Nextval@lk_crm1tocrm2db into i_Prod_Inst_Rel_seq from dual;
      insert into crmv2.Prod_inst_rel@lk_crm1tocrm2db (PROD_INST_REL_ID, PROD_INST_A_ID, PROD_INST_Z_ID, RELATION_TYPE_CD, PROD_INST_REL_ROLE_ID, ROLE_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PRODUCT_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
      select i_Prod_Inst_Rel_seq, i_prod_inst_seq, i_zh_Prod_inst_id, '109920', null, 0, a.eff_date, a.exp_date, a.create_date, '1000', a.modify_date, a.modify_date, '', 18571, 1, 1, '', '', null
      from mdse_rela a, mdse b where a.mdse_idb = i_mdseId and a.rela_type = '197' and
       a.mdse_ida = b.mdse_id;
      --增量2.0计费
      basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
      ('PROD_INST_REL','PROD_INST_REL_ID',i_Prod_Inst_Rel_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'Prod_inst_rel', '', i_Prod_Inst_Rel_seq, sysdate, '同步添加主从关系',i_BATCH_ID);

      --
      select p.area_code into i_area_code from mdse m, prod p where m.mdse_id = i_mdseId and m.prod_id = p.prod_id;
      --2.0
      select count(*) into i_count from  prod_offer_inst_attr@lk_crm1tocrm2db poia, offer_prod_inst_rel@lk_crm1tocrm2db opir where opir.prod_inst_id = i_zh_Prod_inst_id and
      opir.prod_offer_inst_id = poia.prod_offer_inst_id and poia.attr_id = 800011905 and  opir.status_cd = '1000';

      if i_count > 0 then
        update  prod_offer_inst_attr@lk_crm1tocrm2db poia  set  attr_value = i_area_code  where  poia.attr_id = 800011905   and exists (
        select 'X' from   offer_prod_inst_rel@lk_crm1tocrm2db opir  where   opir.prod_inst_id = i_zh_Prod_inst_id and  opir.status_cd = '1000' and opir.prod_offer_inst_id = poia.prod_offer_inst_id  );

        select count(*) into i_count from prod_offer_inst_attr@lk_crm1tocrm2db poia   where  poia.attr_id = 800011905   and exists (
        select 'X' from   offer_prod_inst_rel@lk_crm1tocrm2db opir  where   opir.prod_inst_id = i_zh_Prod_inst_id and  opir.status_cd = '1000' and opir.prod_offer_inst_id = poia.prod_offer_inst_id  );

        if i_count = 1 then
          select prod_offer_inst_attr_id into i_Prod_Inst_Rel_seq from prod_offer_inst_attr@lk_crm1tocrm2db poia    where  poia.attr_id = 800011905   and exists (
          select 'X' from   offer_prod_inst_rel@lk_crm1tocrm2db opir  where   opir.prod_inst_id = i_zh_Prod_inst_id and  opir.status_cd = '1000' and opir.prod_offer_inst_id = poia.prod_offer_inst_id  );

          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_OFFER_INST_ATTR','PROD_OFFER_INST_ATTR_ID',i_Prod_Inst_Rel_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);
        end if;
      end if;

    end if;

    o_errMsg := '添加电信账户信息错误';
    o_ceshi := '4-002-6';--测试专用日志
    proc_cross_account_1TO2(i_prodId,i_BATCH_ID,i_region,i_cust_seq,i_prod_inst_seq,o_errMsg );

    /*
    select count(*) into i_count   from zg z, telecom_account ta where  z.zgzr = i_prodId
    and ta.tel_acct_id = z.zgzh;

    if i_count > 0 then
      select ta.agreement_code, ta.tel_acct_id  into  v_agreement_code, i_tel_acct_id   from zg z, telecom_account ta where  z.zgzr = i_prodId
      and ta.tel_acct_id = z.zgzh;
      o_ceshi := '4-002-7';--测试专用日志
      --2.0
      select count(*) into i_count  from crmv2.account@lk_crm1tocrm2db  where account_number = v_agreement_code ;
      if i_count > 0  then
        select account_id into i_account_id  from crmv2.account@lk_crm1tocrm2db  where account_number = v_agreement_code ;
      else
        select crmv2.seq_account_id.nextval@lk_crm1tocrm2db into i_account_id from dual;

        insert into crmv2.account@lk_crm1tocrm2db
          (ACCOUNT_ID,
           CUST_ID,
           COMMON_REGION_ID,
           ACCOUNT_NAME,
           ACCOUNT_AREA_GRADE,
           ACCOUNT_NUMBER, --
           GROUP_PAY_METHOD,
           PAY_CYCLE,   --记录付款周期
           CONTACT_PHONE,
           MOBILE_PHONE,
           IF_DEFAULT,
           PROC_SERIAL,
           EXT_ACCOUNT_ID,  --外部帐户标识
           --LAN_ID,
           AREA_ID,
           CREATE_DATE,
           CREATE_STAFF,
           REGION_CD,
           STATUS_CD,
           STATUS_DATE,
           UPDATE_DATE,
           UPDATE_STAFF,
           REC_UPDATE_DATE,
           DEDUCT_CHARGE,
           DEDUCT_LIMIT,
           PRINT_PROD_ID,
           SIGN_PROD_ID,
           PRINT_ACC_NBR,
           SIGN_ACC_NBR,
           EXT_FLAG1)
          select i_account_id,
                 i_cust_seq,
                 i_region,
                 ta.tel_acct_name,
                 '',
                 ta.agreement_code,
                 '',
                 '',  --
                 '',
                 '',
                 '',
                 '',
                 '', --外部帐户标识
                 pa.super,
                 ta.create_date,
                 null,
                 ta.region,
                 '1000',
                 ta.create_date,
                 ta.create_date,
                 null,
                 null,
                 ta.DEDUCT_CHARGE,
                 ta.DEDUCT_LIMIT,
                 null,
                 null,
                 '',
                 '',
                 'Y'
            from zg z, telecom_account ta, p_area pa
           where z.zgzr = i_prodId
             and ta.tel_acct_id = z.zgzh and pa.id = z.zgqy;

    o_ceshi := '4-002-8';--测试专用日志
    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'account', i_tel_acct_id, i_account_id, sysdate, '同步账户实例表',i_BATCH_ID);

      select zgtl,zgid into v_zgtl, i_zg_id from zg where zgzr = i_prodid;
      if v_zgtl = 'true' then
         v_zgtl := 'T';
      else
         v_zgtl := 'F';
      end if;

      select crmv2.seq_prod_inst_acct_id.nextval@lk_crm1tocrm2db into i_prod_inst_acct_seq  from   dual;
      insert into crmv2.prod_inst_acct@lk_crm1tocrm2db
        (PROD_INST_ACCT_ID,
         ACCOUNT_ID,
         ACCT_ITEM_TYPE_GROUP_ID,
         PROD_INST_ID,
         PAYMENT_LIMIT_TYPE,
         PAYMENT_LIMIT,
         PRIORITY,
         STATUS_CD,
         STATUS_DATE,
         PROC_SERIAL,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         UPDATE_DATE,
         CREATE_DATE,
         EFF_DATE,
         EXP_DATE,
         DEF_ACCT_FLAG,
         CHARGE_TYPE,
         INVOICE_FORMART_FLAG,
         REC_UPDATE_DATE)
        select i_prod_inst_acct_seq,
               i_account_id,
               zgzl,
               i_prod_inst_seq,
               zgff,
               zgxe,
               zgxs,
               '1000',
               real_modify_date,
               '',
               pa.super,-- zgqy,
               pa.super,
               null,
               null,
               real_modify_date,
               zgrq,
               null,
               null,
               v_zgtl,
               zgfg,
               null,
               null
          from zg, p_area pa
         where zgzr = i_prodid  and zgqy = pa.id ;


    o_ceshi := '4-002-9';--测试专用日志
    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_acct', i_zg_id, i_prod_inst_acct_seq, sysdate, '同步商品账户实例表',i_BATCH_ID);

    select crmv2.seq_PAYMENT_PLAN_id.nextval@lk_crm1tocrm2db into i_PAYMENT_PLAN_id from dual;

      insert into crmv2.payment_plan@lk_crm1tocrm2db
        (PAYMENT_PLAN,
         ACCOUNT_ID,
         PAYMENT_METHOD_ID,
         PAYMENT_BANK_ID,
         PAYMENT_ACCOUNT,
         PAYMENT_ACCOUNT_NAME,
         PAYMENT_ACCOUNT_TYPE,
         PRIORITY,
         AREA_ID,
         CREATE_DATE,
         CREATE_STAFF,
         REGION_CD,
         STATUS_CD,
         STATUS_DATE,
         UPDATE_DATE,
         UPDATE_STAFF,
         ACC_AGREEMENT_CODE,
         SEND_ENTRUST_METHOD,
         ENTRUST_TYPE,
         REC_UPDATE_DATE,
         PROPORTION,
         LIMITATION)
        select i_PAYMENT_PLAN_id,
               i_account_id,
               zh.zhlx,
               zh.zhyh,
               zh.zhzh,
               zh.zhmc,
               '',
               pp.priority,
               pa.super,
               pp.create_date,
               null,
               pa.id,
               '1000',
               pp.real_modify_date,
               pp.real_modify_date,
               null,
               zh.acc_agreement_code,
               zh.send_method_type,
               zh.entrust_type,
               null,
               '',
               0
          from payment_plan pp, zg z, telecom_account ta, zh , p_area pa
         where z.zgzr = i_prodId
           and ta.tel_acct_id = z.zgzh
           and ta.tel_acct_id = pp.tel_acct_id
           and zh.zhid = pp.cust_acct_id
           and pa.id = ta.region
           and rownum < 2;

           select pp.payment_plan_id into i_payment_plan_id2
          from payment_plan pp, zg z, telecom_account ta, zh , p_area pa
         where z.zgzr = i_prodId
           and ta.tel_acct_id = z.zgzh
           and ta.tel_acct_id = pp.tel_acct_id
           and zh.zhid = pp.cust_acct_id
           and pa.id = ta.region
           and rownum < 2;
       o_ceshi := '4-002-10';--测试专用日志
      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'payment_plan', i_payment_plan_id2, i_PAYMENT_PLAN_id, sysdate, '同步支付实例表',i_BATCH_ID);

      end if;
    end if;    */

  end if;

  o_errMsg := 'TRUE';
  o_result := 1;
  --commit;

exception
  when others then
    rollback;
    dbms_output.put_line(SQLERRM);

    o_errMsg := o_errMsg || 'i_mdseid[' || i_mdseid  || ']i_operateType:' || i_operate || ']['||o_ceshi;
    insert into crm.new_oss_log (LOG_ID, REQUEST_TYPE, FUN_NAME, REQUEST_DT, REQUEST_DESC, RESPONSE_DT, RESPONSE_DESC, MDSE_SPEC_ID, INST_ID)
    values (crm.O_NEW_OSS_LOG_SEQ.Nextval, 'VNP_CALCULATE_FEE_TO_20', i_mdseid, sysdate, o_errMsg, null, '', 0, '1');

    o_errMsg := o_errMsg;
    o_result := 0;
    commit;
end main;
--同步客户信息
   PROCEDURE proc_cross_kh_1TO2(i_mdseId       in varchar2,
                                  i_BATCH_ID     in number,
                                  o_cust_seq     out number,
                                  o_errMsg       out varchar2 )as
--同步产品信息
  --i_khId       number(11);
  v_khbm       varchar2(50);
  i_count      number;
  i_party_seq  number(15);
  i_prod_inst_seq       number(15);
  i_prod_offer_inst_seq number(15);
  i_prod_inst_acc_nbr_seq number(15);
  v_service_code        varchar2(100);
  v_account             varchar2(100);
  i_region              number;
  i_prodId     number(15);
  i_priceId    number(15);
  i_priceRrelaId number(15);
  i_priceId_2   number(15);
  --i_account_id number(15);
  --v_agreement_code varchar2(100);
  --prod_inst_rela_id number(15);  --1.0中的关系被实例化出来。
  --v_zh_account varchar2(100);
  --i_zh_region  number;
  --i_zh_Prod_inst_id number(15);
  v_prod_spec_id  varchar2(100);
  i_product_id    number(15);
  i_CY_ID         number(15);
  i_cust_seq      number(15);
  i_PARTY_CERTI_ID_seq number(15);
  i_khId         number(15);
  i_kh_id        number(15);
  i_offer_prod_seq number(15);
  --i_Prod_Inst_Rel_seq number(15);
  --i_tel_acct_id  number(15);
  --i_PAYMENT_PLAN_id number(15);
  --i_payment_plan_id2 number(15);
  --i_prod_inst_acct_seq number(15);
  --i_zg_id number(15);
  --i_BATCH_ID  number(15);
  i_attr_id   number(15);
  i_attr_spec_id number(15);
  i_mdseSpecId number(15);
  --i_prod_inst_id number(15);
  --i_prod_id      number(15);
  --i_priceId      number(15);
  --i_priceId_2    number(15);
  --i_priceRrelaId number(15);
  i_prod_spec    number(15);
  --i_prod_fea_id  number(15);
  i_prod_offer_inst_rel_id number(15);
  i_prod_offer_rela_id    number(15);
  i_prod_offer_price_seq   number(15);
  v_offer_id   varchar2(100);
  i_offerType  varchar2(100);
  i_prodSpecId  number(15);
  i_prod_fea_id number(15);
  i_attr_value_id number(15);
  v_code    varchar2(100);
  v_panType varchar2(10);
  v_PAYMENT_MODE_CD varchar2(10);
  i_offer_prod_rel_id  number(15);
  v_mdse_type varchar2(10);
  i_mdse_map_id number(15);
  v_kh_type   varchar2(10);
  v_parameter1  varchar2(50);
  i_area      varchar2(10);

begin
     /**先通过客户编码查询crm1.0中这个客户是否存在，不存在则添加**/
  select  count(*) into  i_khId   from mdse where mdse_id = i_mdseId;

  --select p.standardcode into i_area from mdse m, p_area p where  m.mdse_id = i_mdseId and m.region = p.id;
  --i_area := substr(i_area, 2, 3);
  i_area := '590';
  if i_khId > 0 then
    select  count(*) into  i_khId   from mdse where mdse_id = i_mdseId;
  else
    o_errMsg := '1.0中无此商品不能进行同步';
    return;
  end if;

  --select  count(*) into  i_count  from o_sale_ord where mdse_id = i_mdseId;
  if  i_count >0 then
    o_errMsg := '该同步的销售品有在途单不能进行同步，请竣工后在来同步';
    return;
  end if;

  select count(*) into i_count  from  mdse a, kh b where a.property_custid = b.khid  and a.mdse_id = i_mdseId;


  if i_count > 0 then
    select b.khbm,b.khid,b.main_group_id  into v_khbm, i_kh_id, v_kh_type  from  mdse a, kh b where a.property_custid = b.khid  and a.mdse_id = i_mdseId;
  else
    o_errMsg := 'CRM 1.0 无此商品或客户不能进行同步数据给CRM2.0';
  end if;


  select count(*) into i_count  from  crmv2.cust@lk_crm1tocrm2db where  CUST_NUMBER = v_khbm;
  o_errMsg := '添加cust信息';

  if i_count = 0 then

    select crmv2.seq_party_id.nextval@lk_crm1tocrm2db into i_party_seq from  dual;
    select crmv2.seq_cust_id.nextval@lk_crm1tocrm2db  into i_cust_seq from dual;

    insert into crmv2.party@lk_crm1tocrm2db (PARTY_ID, PARTY_NAME, PARTY_ABBRNAME, ENGLISH_NAME, PARTY_TYPE, STATUS_CD, STATUS_DATE, CREATE_DATE, UPDATE_DATE, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, CERT_CHECK_RESULT, REC_UPDATE_DATE)
     select i_party_seq, k.cymc, k.CYJP, k.CYPM, k.CYLX, '1000', k.cygr, k.cygr, k.cygr, p.super, k.khqy, null, null, '', null
    from khcy k, p_area p where k.khbm = v_khbm and k.khqy = p.id;

    --增量2.0计费
    basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
    ('PARTY','PARTY_ID',i_party_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);


    select k.CYID into i_CY_ID from  khcy k, p_area p where k.khbm = v_khbm and k.khqy = p.id;
    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'party', i_CY_ID, i_party_seq, sysdate, '同步参与人实例表',i_BATCH_ID);

    select crmv2.seq_party_certification_id.nextval@lk_crm1tocrm2db into i_PARTY_CERTI_ID_seq from dual;
    insert into crmv2.party_certification@lk_crm1tocrm2db (PARTY_CERTI_ID, PARTY_ID, CERT_TYPE, CERT_ORG, CERT_ADDRESS, CERT_NUMBER, EFF_DATE, EXP_DATE, STATUS_CD, STATUS_DATE, CREATE_DATE, UPDATE_DATE, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, CERT_SORT)
     select i_PARTY_CERTI_ID_seq, i_party_seq, k.CYZL, '', k.IDENTIFY_ADDR, k.CYMK, '', null, '1000', k.cygr, k.cygr, k.cygr, p.super, k.khqy, null, null, '10'
    from khcy k, p_area p where k.khbm = v_khbm and k.khqy = p.id;

    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'party_certification', '', i_PARTY_CERTI_ID_seq, sysdate, '同步证件实例表',i_BATCH_ID);

    if v_kh_type = '1' then
      v_kh_type := '1000';
    else
      v_kh_type := '1100';
    end if;

    v_parameter1 := 'SJZ010101';

       select count(*) into i_count
     from extension a
    where a.attribution_type = 'KH'
      and a.attribution_id = i_kh_id
      and extension_spec_id = 600001480;
    if i_count = 1 then
       select a.parameter1 into v_parameter1
     from extension a
    where a.attribution_type = 'KH'
      and a.attribution_id = i_kh_id
      and extension_spec_id = 600001480;

      if v_parameter1 = null then
        v_parameter1 := 'SJZ010101';
      end if;

    end if;

    insert into crmv2.cust@lk_crm1tocrm2db (CUST_ID, COMMON_REGION_ID, PARTY_ID, CUST_NUMBER, CUST_ADDRESS, CUST_TYPE, CUST_SUB_TYPE, CUST_AREA_GRADE, GROUP_CUST_SEQ, IMPORTANT_LEVEL, ENTER_DATE, CREATE_DATE, STATUS_CD, STATUS_DATE, MOD_DATE, STAFF_ID, INDUSTRY_CD, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, CUST_ADDRESS_ID, REC_UPDATE_DATE, CUR_YEAR_TYPE)
    select i_cust_seq, k.khqy, i_party_seq, k.khbm, k.CORRESPONDENT, v_kh_type, '', k.KHXD, '', '', sysdate, sysdate, '1100', k.cygr, k.cygr, null, v_parameter1, k.cygr, '', p.super, k.khqy, null, null, '', null, k.cust_year_type
    from  khcy k, p_area p where k.khbm = v_khbm and k.khqy = p.id;

    --增量2.0计费
    basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
    ('CUST','CUST_ID',i_cust_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'cust', i_kh_id, i_cust_seq, sysdate, '同步客户实例表',i_BATCH_ID);

    select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=1;

    select crmv2.seq_cust_external_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
    insert into crmv2.cust_external_attr@lk_crm1tocrm2db (CUST_EXTERNAL_ATTR_ID, CUST_ID, ATTR_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, CREATE_DATE, UPDATE_DATE, ATTR_VALUE_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF)
    select i_attr_id, i_cust_seq, i_attr_spec_id,  'Y', '1000', sysdate, sysdate, sysdate, null,pa.super, p.region, null, null
    from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'cust_external_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);

  else
    select cust_id into i_cust_seq  from  crmv2.cust@lk_crm1tocrm2db where  CUST_NUMBER = v_khbm;
  end if;
  o_cust_seq := i_cust_seq;

end proc_cross_kh_1TO2;

---
  PROCEDURE proc_cross_prod_1TO2 (i_mdseId   in varchar2,
                                  i_vpn_mdseId   in varchar2,
                                  i_cust_seq  in    number,
                                  i_BATCH_ID  in    number,
                                  o_errMsg   out varchar2)as
    /** --i_vpn_mdseId不为空用来判断是vpn同步进来的(同步企业总机到2.0)。 为空是维护调用进来的 （为了更新2.0组合套餐参数的）. */
  --同步产品信息
  --i_khId       number(11);
  --v_khbm       varchar2(50);
  i_count      number;
  --i_party_seq  number(15);
  i_prod_inst_seq       number(15);
  i_prod_offer_inst_seq number(15);
  i_prod_inst_acc_nbr_seq number(15);
  v_service_code        varchar2(100);
  v_account             varchar2(100);
  i_region              number;
  i_prodId     number(15);
  i_priceId    number(15);
  i_priceRrelaId number(15);
  i_priceId_2   number(15);
  --i_account_id number(15);
  --v_agreement_code varchar2(100);
  --prod_inst_rela_id number(15);  --1.0中的关系被实例化出来。
  --v_zh_account varchar2(100);
  --i_zh_region  number;
  --i_zh_Prod_inst_id number(15);
  v_prod_spec_id  varchar2(100);
  i_product_id    number(15);
  --i_CY_ID         number(15);
  --i_cust_seq      number(15);
  --i_PARTY_CERTI_ID_seq number(15);
  --i_kh_id         number(15);
  i_offer_prod_seq number(15);
  --i_Prod_Inst_Rel_seq number(15);
  --i_tel_acct_id  number(15);
  --i_PAYMENT_PLAN_id number(15);
  --i_payment_plan_id2 number(15);
  --i_prod_inst_acct_seq number(15);
  --i_zg_id number(15);
  --i_BATCH_ID  number(15);
  i_attr_id   number(15);
  i_attr_spec_id number(15);
  i_mdseSpecId number(15);
  --i_prod_inst_id number(15);
  --i_prod_id      number(15);
  --i_priceId      number(15);
  --i_priceId_2    number(15);
  --i_priceRrelaId number(15);
  --i_prod_spec    number(15);
  --i_prod_fea_id  number(15);
  i_prod_offer_inst_rel_id number(15);
  i_prod_offer_rela_id    number(15);
  i_prod_offer_price_seq   number(15);
  v_offer_id   varchar2(100);
  i_offerType  varchar2(100);
  i_prodSpecId  number(15);
  i_prod_fea_id number(15);
  i_attr_value_id number(15);
  v_code    varchar2(100);
  v_panType varchar2(10);
  v_PAYMENT_MODE_CD varchar2(10);
  i_offer_prod_rel_id  number(15);
  v_mdse_type varchar2(10);
  i_mdse_map_id number(15);
  v_vpn_account varchar2(100);
  v_mdseType    number(15);
  v_new_code    varchar2(12);
  v_old_code    varchar2(12);
  i_prod_offer_inst_id number(15);
  i_area        varchar2(12);
  begin

  o_errMsg := '产品信息同步';

 --这里同步企业总机
  i_area := '590';
  select count(*) into i_count from prod_common pm , mdse m where m.mdse_id = i_mdseId and m.mdse_spec_id = pm.code and pm.sort = 'VNP_CALCULATE_FEE' and  pm.param1 = '105';
  if i_count > 0  then
    select crmv2.seq_prod_offer_inst_id.nextval@lk_crm1tocrm2db into i_prod_offer_inst_seq  from dual;

    select id_v2 into v_offer_id from  crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db  a, mdse m where a.id_v1 = m.mdse_spec_id and  m.mdse_id = i_mdseId;

    select count(*) into i_count from crmv2.prod_offer_inst@lk_crm1tocrm2db poi, mdse m where m.mdse_id = i_mdseId and m.mdse_serv_number = poi.SERVICE_NBR
    and poi.PROD_OFFER_ID = v_offer_id;

   --select p.standardcode into i_area from mdse m, p_area p where  m.mdse_id = i_mdseId and m.region = p.id;
   --i_area := substr(i_area, 2, 3);
   --i_area := '590';
    if i_vpn_mdseId  is not null then

      if i_count > 0 then --说明已经存在这个的业务号码了，无需再次同步数据
        o_errMsg := '1.0同步到2.0的组合套餐已经已经存在无需再次同步数据，请确认mdse_id:' || i_mdseId;
        return;
      end if;



      insert into crmv2.prod_offer_inst@lk_crm1tocrm2db (PROD_OFFER_INST_ID, PROD_OFFER_ID, CUST_ID, CHANNEL_ID, CREATE_DATE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, REGION, UPDATE_DATE, PROC_SERIAL, EXT_PROD_OFFER_INST_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, TRIAL_EFF_DATE, TRIAL_EXP_DATE, REC_UPDATE_DATE, SERVICE_NBR)
      select i_prod_offer_inst_seq, v_offer_id, i_cust_seq, null, m.create_date, '1000', m.modify_date, m.eff_date, m.exp_date, pa.super, m.modify_date, '', '外部产品实例标识', pa.super, pa.super, null, null, null, null, null, m.mdse_serv_number
      from  mdse m, p_area pa where mdse_id = i_mdseId and m.region = pa.id;
      --增量2.0计费
      basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
      ('PROD_OFFER_INST','PROD_OFFER_INST_ID',i_prod_offer_inst_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

      --v_offer_id := '800001876';
      insert into crmv2.prod_offer_inst_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db, p.prod_offer_inst_id, null, p.area_id, p.region_cd, p.status_cd, p.status_date, p.create_date, null, sysdate, null
       from  crmv2.prod_offer_inst@lk_crm1tocrm2db p  where  prod_offer_inst_id = i_prod_offer_inst_seq;

      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst', i_mdseId, i_prod_offer_inst_seq, sysdate, '同步销售品实例表',i_BATCH_ID);

      select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=6;

      select crmv2.seq_prod_offer_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual ;
      insert into crmv2.prod_offer_inst_attr@lk_crm1tocrm2db (prod_offer_inst_attr_id, prod_offer_inst_id, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
      select i_attr_id, i_prod_offer_inst_seq, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
      from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

      insert into crmv2.prod_offer_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,p.prod_offer_inst_attr_id, null,p.area_id,p.region_cd,p.status_cd,p.status_date,p.create_date,p.create_staff,p.update_date,p.update_staff
      from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db p where  prod_offer_inst_attr_id = i_attr_id;

      --增量2.0计费
      basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
      ('PROD_OFFER_INST_ATTR','PROD_OFFER_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);

      select count(*) into i_count from bill.cust_price_plan_param where mdse_id = i_mdseId;
      if  i_count > 0  then
        --同步组合套餐 套餐参数
        for PP in(select mdse_id, pricing_param_value_id,info_val,eff_date,exp_date  from bill.cust_price_plan_param where mdse_id = i_mdseId)LOOP
          v_old_code :=   PP.pricing_param_value_id;
          select count(*) into i_count   from itsc_crmv2.crmgc_archive_gj_code_conv@lk_crm1tocrm2db  where old_code  = v_old_code  and  field_name = 'MDSE_PARAM_ID';
          if i_count = 1 then
            select  new_code into v_new_code   from itsc_crmv2.crmgc_archive_gj_code_conv@lk_crm1tocrm2db where old_code  = v_old_code  and  field_name = 'MDSE_PARAM_ID';

            select crmv2.seq_prod_offer_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual ;

            insert into crmv2.prod_offer_inst_attr@lk_crm1tocrm2db (prod_offer_inst_attr_id, prod_offer_inst_id, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
            select i_attr_id, i_prod_offer_inst_seq, v_new_code, '', PP.INFO_VAL, '1000', PP.EFF_DATE, PP.Exp_Date,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, m.region, null, null, null
            from  mdse m, p_area pa where  m.mdse_id =  i_mdseId and pa.id = m.region;

      insert into crmv2.prod_offer_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,p.prod_offer_inst_attr_id, null,p.area_id,p.region_cd,p.status_cd,p.status_date,p.create_date,p.create_staff,p.update_date,p.update_staff
      from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db p where  prod_offer_inst_attr_id = i_attr_id;

            --增量2.0计费
            basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
            ('PROD_OFFER_INST_ATTR','PROD_OFFER_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

            insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
            values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);

         end if;
        end LOOP;
      end if;

      select count(*) into i_count from prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id = i_vpn_mdseId;

      if i_count >0 then

        select p.account into v_vpn_account from prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id = i_vpn_mdseId;
        select count(*) into i_count from crmv2.prod_inst@lk_crm1tocrm2db  where  account = v_vpn_account;
        if i_count = 1 then

           select product_id, prod_inst_id  into i_product_id, i_prod_inst_seq from crmv2.prod_inst@lk_crm1tocrm2db  where  account = v_vpn_account;

           select count(*) into i_count from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id;

           if i_count = 1 then
              select r.offer_prod_rela_id into i_offer_prod_rel_id from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id;

              select crmv2.seq_offer_prod_inst_rel_id.nextval@lk_crm1tocrm2db into i_offer_prod_seq from dual;
              insert into crmv2.offer_prod_inst_rel@lk_crm1tocrm2db (OFFER_PROD_INST_REL_ID, PROD_INST_ID, PROD_OFFER_INST_ID, ROLE_CD, OFFER_PROD_INST_REL_ROLE_ID, STATUS_CD, STATUS_DATE, CREATE_DATE, EFF_DATE, EXP_DATE, UPDATE_DATE, PROC_SERIAL, OFFER_PROD_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
              select i_offer_prod_seq, i_prod_inst_seq, i_prod_offer_inst_seq, null, null, '1000', m.eff_date, m.create_date, m.eff_date, m.exp_date, m.modify_date, '', i_offer_prod_rel_id, pa.super, m.region, null, null, null
              from  mdse m, p_area pa where mdse_id = i_mdseId and m.region = pa.id ;

insert into crmv2.offer_prod_inst_rel_ext@lk_crm1tocrm2db (EXT_ID, OFFER_PROD_INST_REL_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select CRMV2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,OFFER_PROD_INST_REL_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from   crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where  OFFER_PROD_INST_REL_ID = i_offer_prod_seq;

              --增量2.0计费
              basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
              ('OFFER_PROD_INST_REL','OFFER_PROD_INST_REL_ID',i_offer_prod_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

              insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
              values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'offer_prod_inst_rel', '', i_offer_prod_seq, sysdate, '同步销售品产品实例关联表',i_BATCH_ID);

           end if;

        end if;
      end if;
    else  --为空是维护调用进来的 （为了更新2.0组合套餐参数的）
      if i_count = 1 then
        --是否有组合套餐的参数
        select prod_offer_inst_id into  i_prod_offer_inst_id  from crmv2.prod_offer_inst@lk_crm1tocrm2db poi, mdse m where m.mdse_id = i_mdseId and m.mdse_serv_number = poi.SERVICE_NBR
        and poi.PROD_OFFER_ID = v_offer_id;

        select count(*) into i_count from bill.cust_price_plan_param where mdse_id = i_mdseId;
        if  i_count > 0  then
          --更新组合套餐 套餐参数
          for PP in(select mdse_id, pricing_param_value_id,info_val,eff_date,exp_date  from bill.cust_price_plan_param where mdse_id = i_mdseId)LOOP
            v_old_code :=   PP.pricing_param_value_id;
            select count(*) into i_count   from itsc_crmv2.crmgc_archive_gj_code_conv@lk_crm1tocrm2db  where old_code  = v_old_code  and  field_name = 'MDSE_PARAM_ID';
            if i_count = 1 then
              select  new_code into v_new_code   from itsc_crmv2.crmgc_archive_gj_code_conv@lk_crm1tocrm2db where old_code  = v_old_code  and  field_name = 'MDSE_PARAM_ID';
              select count(*) into i_count from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db  where prod_offer_inst_id =  i_prod_offer_inst_id and ATTR_ID = v_new_code;
              --没有
              if i_count = 0 then
                select crmv2.seq_prod_offer_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual ;

                insert into crmv2.prod_offer_inst_attr@lk_crm1tocrm2db (prod_offer_inst_attr_id, prod_offer_inst_id, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
                select i_attr_id, i_prod_offer_inst_seq, v_new_code, '', PP.INFO_VAL, '1000', PP.EFF_DATE, PP.Exp_Date,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, m.region, null, null, null
                from  mdse m, p_area pa where  m.mdse_id =  i_mdseId and pa.id = m.region;

      insert into crmv2.prod_offer_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,p.prod_offer_inst_attr_id, null,p.area_id,p.region_cd,p.status_cd,p.status_date,p.create_date,p.create_staff,p.update_date,p.update_staff
      from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db p where  prod_offer_inst_attr_id = i_attr_id;

                --增量2.0计费
                basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
                ('PROD_OFFER_INST_ATTR','PROD_OFFER_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

                insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
                values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst_attr', '', i_attr_id, sysdate, '同步组合套餐参数',i_BATCH_ID);
              else
                select count(*) into i_count from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db  where prod_offer_inst_id =  i_prod_offer_inst_id
                  and ATTR_ID = v_new_code and ATTR_VALUE = PP.info_val;

                if i_count = 0 then
                  update crmv2.prod_offer_inst_attr@lk_crm1tocrm2db  set ATTR_VALUE = PP.info_val, EFF_DATE = PP.Eff_Date, EXP_DATE = PP.Exp_Date, UPDATE_DATE = sysdate
                   where prod_offer_inst_id =  i_prod_offer_inst_id and ATTR_ID = v_new_code;
                end if;

              end if;
           end if;
          end LOOP;
        end if;

      end if;
    end if;

    /*
    select count(*) into i_count from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id;
    if i_count = 1 then
      select r.offer_prod_rela_id into i_offer_prod_rel_id from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id;
    else
      --要报错了.
      select r.offer_prod_rela_id into i_offer_prod_rel_id from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id and rownum < 2;
    end if;

    select crmv2.seq_offer_prod_inst_rel_id.nextval@lk_crm1tocrm2db into i_offer_prod_seq from dual;
    insert into crmv2.offer_prod_inst_rel@lk_crm1tocrm2db (OFFER_PROD_INST_REL_ID, PROD_INST_ID, PROD_OFFER_INST_ID, ROLE_CD, OFFER_PROD_INST_REL_ROLE_ID, STATUS_CD, STATUS_DATE, CREATE_DATE, EFF_DATE, EXP_DATE, UPDATE_DATE, PROC_SERIAL, OFFER_PROD_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
    select i_offer_prod_seq, i_prod_inst_seq, i_prod_offer_inst_seq, null, null, '1000', m.eff_date, m.create_date, m.eff_date, m.exp_date, m.modify_date, '', i_offer_prod_rel_id, pa.super, m.region, null, null, null
    from  mdse m, p_area pa where mdse_id = i_mdseId and m.region = pa.id ;

    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'offer_prod_inst_rel', '', i_offer_prod_seq, sysdate, '同步销售品产品实例关联表',i_BATCH_ID);
    */
    return;  --返回
  end if;  --企业总机服务同步结束

  select p.pay_type, p.prod_id, p.service_code,p.prod_spec_id into v_panType, i_prodId,  v_service_code, i_prodSpecId from  prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
  select p.region into i_region from  prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
  select p.account into v_account from prod p, mdse m where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId ;
  select count(*) into i_count from crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db  where acc_nbr =  v_service_code and  region_cd = i_region;

  if i_count = 0 then

    select crmv2.seq_prod_offer_inst_id.nextval@lk_crm1tocrm2db into i_prod_offer_inst_seq  from dual;
    --select seq_offer_prod_inst_rel_id.nextval into   from dual;
    select crmv2.seq_prod_inst_id.nextval@lk_crm1tocrm2db  into  i_prod_inst_seq from   dual;
    select crmv2.seq_prod_inst_acc_nbr_id.nextval@lk_crm1tocrm2db into i_prod_inst_acc_nbr_seq from   dual;

    insert into crmv2.prod_inst_acc_nbr@lk_crm1tocrm2db (PROD_INST_ACC_NBR_ID, ACC_NBR_TYPE_CD, ACC_NBR, CREATE_DATE, STATUS_CD, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, PROD_INST_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, AREA_CODE)
    select i_prod_inst_acc_nbr_seq, p.service_type, p.service_code, p.create_date, '1000', p.modify_date, p.modify_date, '', i_prod_inst_seq, pa.super, p.region, null, null, ''
    from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_acc_nbr', '', i_prod_inst_acc_nbr_seq, sysdate, '同步接入号码实例表',i_BATCH_ID);


    select prod_spec_id into v_prod_spec_id from  prod p, mdse m where m.mdse_id =i_mdseId  and m.prod_id = p.prod_id ;
    select count(*) into i_count from  crmv2.product@lk_crm1tocrm2db  where ext_prod_id = v_prod_spec_id;
    if i_count = 0 then
      o_errMsg := '1.0商品规格与2.0商品规格对应错误';
      return;
    end if;

    /*
    select count(*) into i_count
      from mdse m, zb a
     where m.mdse_id = i_mdseId
       and m.mdse_spec_id = a.zbbm
       and a.zbfl = 'CZKT_CDMA_013_LIMIT';*/

    select m.mdse_spec_id,m.mdse_type into i_mdseSpecId ,v_mdseType
     from mdse m
    where m.mdse_id = i_mdseId;


    if v_mdseType = '107' then

      select count(*) into i_count  from prefer_price_spec pps,crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a, mdse m where m.mdse_spec_id = pps.mdse_spec_id  and  a.ID_V1 = pps.prefer_spec_id and m.mdse_id = i_mdseId;
      if i_count = 1 then
         select a.id_v2 into v_offer_id  from prefer_price_spec pps,crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a, mdse m where m.mdse_spec_id = pps.mdse_spec_id  and  a.ID_V1 = pps.prefer_spec_id and m.mdse_id = i_mdseId;
         select count(*) into i_count from crmv2.offer_prod_rel@lk_crm1tocrm2db where prod_offer_id = v_offer_id  and status_cd = '1000';
         if i_count = 1 then
           select product_id into i_product_id  from crmv2.offer_prod_rel@lk_crm1tocrm2db where prod_offer_id = v_offer_id  and status_cd = '1000';
         end if;
      else
        --拆多条的目前还不支持。要支持的话 这里要开发。
        o_errMsg := '1.0商品规格与2.0商品规格组合套餐的拆多条出来的，目前不支持';
        return;
      end if;
    else
      select product_id into i_product_id from  crmv2.product@lk_crm1tocrm2db  where ext_prod_id = v_prod_spec_id;
    end if;


    if v_panType = '1'then
      v_PAYMENT_MODE_CD := '1201';
    elsif  v_panType = '2' then
      v_PAYMENT_MODE_CD := '1200';
    elsif  v_panType = '3' then
      v_PAYMENT_MODE_CD := '2100';
    else
      v_PAYMENT_MODE_CD := '1201';
    end if;

    insert into crmv2.prod_inst@lk_crm1tocrm2db (PROD_INST_ID, PRODUCT_ID, ACC_PROD_INST_ID, ADDRESS_ID, OWNER_CUST_ID, PAYMENT_MODE_CD, PRODUCT_PASSWORD, IMPORTANT_LEVEL, AREA_CODE, ACC_NBR, EXCH_ID, COMMON_REGION_ID, REMARK, PAY_CYCLE, BEGIN_RENT_TIME, STOP_RENT_TIME, FINISH_TIME, STOP_STATUS, STATUS_CD, CREATE_DATE, STATUS_DATE, UPDATE_DATE, PROC_SERIAL, USE_CUST_ID, EXT_PROD_INST_ID, ADDRESS_DESC, AREA_ID, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE, ACCOUNT,version)
    select  i_prod_inst_seq, i_product_id, i_prod_inst_seq, p.address_id, i_cust_seq, v_PAYMENT_MODE_CD, '', '', p.area_code, p.account, p.exch_id, pa.super, '', p.acct_cycle, p.create_date, p.rent_date, p.create_date, p.stop_status, '100000', p.create_date, p.modify_date, p.modify_date, '', i_cust_seq, p.prod_spec_id, p.address_name, pa.super, null, '', null, p.account,'1'
    from  prod p, mdse m,p_area pa  where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region ;

    --增量2.0计费
    basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
    ('PROD_INST','PROD_INST_ID',i_prod_inst_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

     insert into crmv2.prod_inst_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
     select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db, prod_inst_id, null, p.area_id, p.common_region_id, p.status_cd, p.status_date, p.create_date, null, sysdate, null
     from  crmv2.prod_inst@lk_crm1tocrm2db  p where  PROD_INST_ID =  i_prod_inst_seq;

    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst', i_prodId, i_prod_inst_seq, sysdate, '同步产品实例表',i_BATCH_ID);

    select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=4;

    select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
    insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
    select i_attr_id, i_prod_inst_seq, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
    from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

    --增量2.0计费
    basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
    ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);

    if i_product_id <> 800000251 and i_product_id <> 800299131 then

      select mdse_type into v_mdse_type from mdse where mdse_id = i_mdseId;

      if v_mdse_type = '107'  then

        select count(*) into i_count  from prefer_price_spec pps,crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a, mdse m where m.mdse_spec_id = pps.mdse_spec_id  and  a.ID_V1 = pps.prefer_spec_id and m.mdse_id = i_mdseId;

        if i_count = 0 then
          o_errMsg := '1.0商品规格与2.0商品规格没有对应关系无法同步';
          return;
        end if;

      else
        select count(*) into i_count  from crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a, mdse m where a.ID_V1 = m.mdse_spec_id and m.mdse_id = i_mdseId;

      end if;


    end if;
      --同步主套餐
      select count(*) into i_count
        from mdse_price_rela a
       where a.mdse_id = i_mdseId
         and exists (select 'X' from price_plan b where b.price_id = a.price_id
         and Yd_Subclass = '1' );

      if i_count > 0 then
        select a.price_id,a.rela_id into i_priceId,i_priceRrelaId
          from mdse_price_rela a
         where a.mdse_id = i_mdseId
           and exists (select 'X' from price_plan b where b.price_id = a.price_id
           and Yd_Subclass = '1' );

        select count(*) into i_count  from crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a where a.ID_V1 = i_priceId;

        if i_count <> 1 then   --如果是多个的就直接取销售品上的.
          i_count := 0;
        end if;
      end if;

      if  i_count > 0 then

        select a.price_id,a.rela_id into i_priceId,i_priceRrelaId
          from mdse_price_rela a
         where a.mdse_id = i_mdseId
           and exists (select 'X' from price_plan b where b.price_id = a.price_id
           and Yd_Subclass = '1' );

        select count(*) into i_count  from crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a where a.ID_V1 = i_priceId;
        if i_count <> 1 then
          o_errMsg := '1.0商品规格与2.0套餐规格没有对应关系无法同步'; --多条也不行
          return;
        end if;
        --主套餐转换成2.0的销售品
        select a.ID_V2 into i_priceId_2  from crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a where a.ID_V1 = i_priceId;

        select a.offer_sub_type  into i_offerType from crmv2.prod_offer@lk_crm1tocrm2db a where a.prod_offer_id = i_priceId_2;
        --销售品同步
        if i_offerType = 'T04' then   --可选包
          --select crmv2.seq_prod_offer_inst_id.nextval@lk_crm1tocrm2db into i_prod_offer_inst_seq  from dual;
          insert into crmv2.prod_offer_inst@lk_crm1tocrm2db (PROD_OFFER_INST_ID, PROD_OFFER_ID, CUST_ID, CHANNEL_ID, CREATE_DATE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, REGION, UPDATE_DATE, PROC_SERIAL, EXT_PROD_OFFER_INST_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, TRIAL_EFF_DATE, TRIAL_EXP_DATE, REC_UPDATE_DATE, SERVICE_NBR)
          select i_prod_offer_inst_seq, a.ID_V2, i_cust_seq, null, m.create_date, '1000', m.modify_date, m.eff_date, m.exp_date, pa.super, m.modify_date, '', '外部产品实例标识', pa.super, pa.super, null, null, null, null, null, ''
          from  mdse m, p_area pa , crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a where mdse_id = i_mdseId and m.region = pa.id and a.ID_V1 = m.mdse_spec_id;

           --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_OFFER_INST','PROD_OFFER_INST_ID',i_prod_offer_inst_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

          insert into crmv2.prod_offer_inst_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
          select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db, p.prod_offer_inst_id, null, p.area_id, p.region_cd, p.status_cd, p.status_date, p.create_date, null, sysdate, null
           from  crmv2.prod_offer_inst@lk_crm1tocrm2db p  where  prod_offer_inst_id = i_prod_offer_inst_seq;

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst', i_mdseId, i_prod_offer_inst_seq, sysdate, '同步销售品实例表',i_BATCH_ID);

          select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=6;

          select crmv2.seq_prod_offer_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual ;
          insert into crmv2.prod_offer_inst_attr@lk_crm1tocrm2db (prod_offer_inst_attr_id, prod_offer_inst_id, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select i_attr_id, i_prod_offer_inst_seq, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
          from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;
      insert into crmv2.prod_offer_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,p.prod_offer_inst_attr_id, null,p.area_id,p.region_cd,p.status_cd,p.status_date,p.create_date,p.create_staff,p.update_date,p.update_staff
      from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db p where  prod_offer_inst_attr_id = i_attr_id;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_OFFER_INST_ATTR','PROD_OFFER_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);

          select r.offer_prod_rela_id into i_offer_prod_rel_id from  crmv2.offer_prod_rel@lk_crm1tocrm2db r,mdse m, crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a where mdse_id = i_mdseId  and a.ID_V1 = m.mdse_spec_id and  r.product_id = i_product_id  and r.prod_offer_id = a.ID_V2;

          select crmv2.seq_offer_prod_inst_rel_id.nextval@lk_crm1tocrm2db into i_offer_prod_seq from dual;
          insert into crmv2.offer_prod_inst_rel@lk_crm1tocrm2db (OFFER_PROD_INST_REL_ID, PROD_INST_ID, PROD_OFFER_INST_ID, ROLE_CD, OFFER_PROD_INST_REL_ROLE_ID, STATUS_CD, STATUS_DATE, CREATE_DATE, EFF_DATE, EXP_DATE, UPDATE_DATE, PROC_SERIAL, OFFER_PROD_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select i_offer_prod_seq, i_prod_inst_seq, i_prod_offer_inst_seq, null, null, '1000', m.eff_date, m.create_date, m.eff_date, m.exp_date, m.modify_date, '', i_offer_prod_rel_id, pa.super, m.region, null, null, null
          from  mdse m, p_area pa where mdse_id = i_mdseId and m.region = pa.id ;

insert into crmv2.offer_prod_inst_rel_ext@lk_crm1tocrm2db (EXT_ID, OFFER_PROD_INST_REL_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select CRMV2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,OFFER_PROD_INST_REL_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from   crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where  OFFER_PROD_INST_REL_ID = i_offer_prod_seq;

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'offer_prod_inst_rel', '', i_offer_prod_seq, sysdate, '同步销售品产品实例关联表',i_BATCH_ID);
        end if;

        --再次获取
        select crmv2.seq_prod_offer_inst_id.nextval@lk_crm1tocrm2db into i_prod_offer_price_seq  from dual;

        insert into crmv2.prod_offer_inst@lk_crm1tocrm2db (PROD_OFFER_INST_ID, PROD_OFFER_ID, CUST_ID, CHANNEL_ID, CREATE_DATE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, REGION, UPDATE_DATE, PROC_SERIAL, EXT_PROD_OFFER_INST_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, TRIAL_EFF_DATE, TRIAL_EXP_DATE, REC_UPDATE_DATE, SERVICE_NBR)
        select i_prod_offer_price_seq, i_priceId_2, i_cust_seq, null, sysdate, '1000', sysdate, a.eff_date, a.exp_date, pa.super, sysdate, '', '外部产品实例标识', pa.super, pa.super, null, null, null, null, null, ''
        from   mdse_price_rela a ,p_area pa
         where a.mdse_id = i_mdseId and a.region = pa.id
           and exists (select 'X' from price_plan b where b.price_id = a.price_id
           and Yd_Subclass = '1' );

        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_OFFER_INST','PROD_OFFER_INST_ID',i_prod_offer_price_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.prod_offer_inst_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
        select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db, p.prod_offer_inst_id, null, p.area_id, p.region_cd, p.status_cd, p.status_date, p.create_date, null, sysdate, null
         from  crmv2.prod_offer_inst@lk_crm1tocrm2db p  where  prod_offer_inst_id = i_prod_offer_price_seq;

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst', i_priceRrelaId, i_prod_offer_price_seq, sysdate, '同步套餐实例表',i_BATCH_ID);

        select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=6;

        select crmv2.seq_prod_offer_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual ;
        insert into crmv2.prod_offer_inst_attr@lk_crm1tocrm2db (prod_offer_inst_attr_id, prod_offer_inst_id, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
        select i_attr_id, i_prod_offer_price_seq, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
        from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

      insert into crmv2.prod_offer_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,p.prod_offer_inst_attr_id, null,p.area_id,p.region_cd,p.status_cd,p.status_date,p.create_date,p.create_staff,p.update_date,p.update_staff
      from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db p where  prod_offer_inst_attr_id = i_attr_id;

        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_OFFER_INST_ATTR','PROD_OFFER_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst_attr', '', i_attr_id, sysdate, '同步销售品属性表',i_BATCH_ID);



        if i_offerType = 'T04' then

          select a.ID_V2 into v_offer_id
          from  mdse m, p_area pa , crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a where mdse_id = i_mdseId and m.region = pa.id and a.ID_V1 = m.mdse_spec_id;

          select a.prod_offer_rela_id into i_prod_offer_rela_id from crmv2.prod_offer_rel@lk_crm1tocrm2db a   where a.offer_a_id = v_offer_id   and a.offer_z_id = i_priceId_2;

          select crmv2.seq_prod_offer_inst_rel_id.nextval@lk_crm1tocrm2db into i_prod_offer_inst_rel_id from dual;
          insert into crmv2.prod_offer_inst_rel@lk_crm1tocrm2db(PROD_OFFER_INST_REL_ID, RELA_PROD_OFFER_INST_ID, RELATED_PROD_OFFER_INST_ID, ROLE_CD, PROD_OFFER_INST_REL_ROLE_ID, RELATION_TYPE_CD, STATUS_CD, EFF_DATE, EXP_DATE, CREATE_DATE, STATUS_DATE, REGION_A, REGION_B, UPDATE_DATE, PROC_SERIAL, PROD_OFFER_RELA_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select  i_prod_offer_inst_rel_id, i_prod_offer_inst_seq, i_prod_offer_price_seq, null, null, '100000', '1000', a.eff_date, a.exp_date, a.create_date, a.create_date, a.region, a.region, a.create_date, '', i_prod_offer_rela_id, pa.super, a.region, null, null, null
          from mdse_price_rela a, p_area pa
         where a.mdse_id = i_mdseId
           and pa.id = a.region
           and exists (select 'X' from price_plan b where b.price_id = a.price_id
           and Yd_Subclass = '1' );

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_OFFER_INST_REL','PROD_OFFER_INST_REL_ID',i_prod_offer_inst_rel_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

     end if;

        if  i_offerType = 'T01' then     --主销售品

          select crmv2.seq_offer_prod_inst_rel_id.nextval@lk_crm1tocrm2db into i_offer_prod_seq from dual;
          insert into crmv2.offer_prod_inst_rel@lk_crm1tocrm2db (OFFER_PROD_INST_REL_ID, PROD_INST_ID, PROD_OFFER_INST_ID, ROLE_CD, OFFER_PROD_INST_REL_ROLE_ID, STATUS_CD, STATUS_DATE, CREATE_DATE, EFF_DATE, EXP_DATE, UPDATE_DATE, PROC_SERIAL, OFFER_PROD_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select i_offer_prod_seq, i_prod_inst_seq, i_prod_offer_price_seq, null, null, '1000', m.eff_date, m.create_date, m.eff_date, m.exp_date, m.modify_date, '', 800024008, pa.super, m.region, null, null, null
          from  mdse m, p_area pa where mdse_id = i_mdseId and m.region = pa.id ;

insert into crmv2.offer_prod_inst_rel_ext@lk_crm1tocrm2db (EXT_ID, OFFER_PROD_INST_REL_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select CRMV2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,OFFER_PROD_INST_REL_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from   crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where  OFFER_PROD_INST_REL_ID = i_offer_prod_seq;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('OFFER_PROD_INST_REL','OFFER_PROD_INST_REL_ID',i_offer_prod_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'offer_prod_inst_rel', '', i_offer_prod_seq, sysdate, '同步套餐产品实例关联表',i_BATCH_ID);
        end if;
      else

        select mdse_type into v_mdse_type from mdse where mdse_id = i_mdseId;

        if v_mdse_type = '107'  then
          select a.ID_V2 into v_offer_id  from prefer_price_spec pps,crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a, mdse m where m.mdse_spec_id = pps.mdse_spec_id  and  a.ID_V1 = pps.prefer_spec_id and m.mdse_id = i_mdseId;
        else
          select count(*) into i_count  from crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a, mdse m where a.ID_V1 = m.mdse_spec_id and m.mdse_id = i_mdseId;
          if i_count = 0 then
            o_errMsg := '1.0商品规格与2.0商品规格没有对应关系无法同步';
            return;
          end if;

          select a.ID_V2 into v_offer_id  from crmv2.mdse_ys_lisy_new@lk_crm1tocrm2db a, mdse m where a.ID_V1 = m.mdse_spec_id and m.mdse_id = i_mdseId;
        end if;

        insert into crmv2.prod_offer_inst@lk_crm1tocrm2db (PROD_OFFER_INST_ID, PROD_OFFER_ID, CUST_ID, CHANNEL_ID, CREATE_DATE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, REGION, UPDATE_DATE, PROC_SERIAL, EXT_PROD_OFFER_INST_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, TRIAL_EFF_DATE, TRIAL_EXP_DATE, REC_UPDATE_DATE, SERVICE_NBR)
        select i_prod_offer_inst_seq, v_offer_id, i_cust_seq, null, m.create_date, '1000', m.modify_date, m.eff_date, m.exp_date,pa.super, m.modify_date, '', '外部产品实例标识', pa.super, pa.super, null, null, null, null, null, ''
        from  mdse m, p_area pa  where mdse_id = i_mdseId and m.region = pa.id ;

        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_OFFER_INST','PROD_OFFER_INST_ID',i_prod_offer_inst_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.prod_offer_inst_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
        select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db, p.prod_offer_inst_id, null, p.area_id, p.region_cd, p.status_cd, p.status_date, p.create_date, null, sysdate, null
         from  crmv2.prod_offer_inst@lk_crm1tocrm2db p  where  prod_offer_inst_id = i_prod_offer_inst_seq;

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst', i_mdseId, i_prod_offer_inst_seq, sysdate, '同步销售品实例表',i_BATCH_ID);

        select attr_id  into i_attr_spec_id from crmv2.attr_spec@lk_crm1tocrm2db t where t.java_code = 'isDummy' and t.class_id=6;

        select crmv2.seq_prod_offer_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual ;
        insert into crmv2.prod_offer_inst_attr@lk_crm1tocrm2db (prod_offer_inst_attr_id, prod_offer_inst_id, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
        select i_attr_id, i_prod_offer_inst_seq, i_attr_spec_id, '', 'Y', '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
        from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

      insert into crmv2.prod_offer_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_OFFER_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
      select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,p.prod_offer_inst_attr_id, null,p.area_id,p.region_cd,p.status_cd,p.status_date,p.create_date,p.create_staff,p.update_date,p.update_staff
      from  crmv2.prod_offer_inst_attr@lk_crm1tocrm2db p where  prod_offer_inst_attr_id = i_attr_id;

        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('PROD_OFFER_INST_ATTR','PROD_OFFER_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_offer_inst_attr', '', i_attr_id, sysdate, '同步客户属性表',i_BATCH_ID);

        --
        select count(*) into i_count from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id;
        if i_count = 1 then
          select r.offer_prod_rela_id into i_offer_prod_rel_id from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id;
        else
          --要报错了.
          select r.offer_prod_rela_id into i_offer_prod_rel_id from  crmv2.offer_prod_rel@lk_crm1tocrm2db r where  r.product_id = i_product_id  and r.prod_offer_id =  v_offer_id and rownum < 2;
        end if;

        select crmv2.seq_offer_prod_inst_rel_id.nextval@lk_crm1tocrm2db into i_offer_prod_seq from dual;
        insert into crmv2.offer_prod_inst_rel@lk_crm1tocrm2db (OFFER_PROD_INST_REL_ID, PROD_INST_ID, PROD_OFFER_INST_ID, ROLE_CD, OFFER_PROD_INST_REL_ROLE_ID, STATUS_CD, STATUS_DATE, CREATE_DATE, EFF_DATE, EXP_DATE, UPDATE_DATE, PROC_SERIAL, OFFER_PROD_REL_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
        select i_offer_prod_seq, i_prod_inst_seq, i_prod_offer_inst_seq, null, null, '1000', m.eff_date, m.create_date, m.eff_date, m.exp_date, m.modify_date, '', i_offer_prod_rel_id, pa.super, m.region, null, null, null
        from  mdse m, p_area pa where mdse_id = i_mdseId and m.region = pa.id ;

insert into crmv2.offer_prod_inst_rel_ext@lk_crm1tocrm2db (EXT_ID, OFFER_PROD_INST_REL_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select CRMV2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,OFFER_PROD_INST_REL_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from   crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where  OFFER_PROD_INST_REL_ID = i_offer_prod_seq;

        --增量2.0计费
        basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
        ('OFFER_PROD_INST_REL','OFFER_PROD_INST_REL_ID',i_offer_prod_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);

        -- 测试
        --select PROD_INST_ID into i_prod_inst_seq  from crmv2.offer_prod_inst_rel@lk_crm1tocrm2db where PROD_INST_ID = i_prod_inst_seq;
        --测试

        insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
        values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'offer_prod_inst_rel', '', i_offer_prod_seq, sysdate, '同步销售品产品实例关联表',i_BATCH_ID);

      end if;

      --select count(*) into i_count from prod_common  where sort = 'IVPN_TONGBU_PEIZHI'  and  code = i_prodSpecId
      --'610003971','610005105'
      if  i_prodSpecId = 610003971 or i_prodSpecId = 610005105 then

        select count(*) into i_count  from prod_fea a where a.prod_id = i_prodId and exists (select 'X' from prod_fea_spec b where  a.fea_spec_id = b.fea_spec_id and   b.sort = '4' and b.code = 'JTFFSX' );
        if i_count>0 then
         select attr_id into i_attr_spec_id from  crmv2.attr_spec@lk_crm1tocrm2db  where java_code = 'JTFFSX';
         select prod_fea_id
           into i_prod_fea_id
           from prod_fea a
          where a.prod_id = i_prodId
            and exists (select 'X'
                   from prod_fea_spec b
                  where b.sort = '4' and
                   a.fea_spec_id = b.fea_spec_id
                    and b.code = 'JTFFSX');

          select pfs.code into  v_code from fea_rela fr, prod_fea  pf, prod_fea_spec pfs where fr.fea_id_a = i_prod_fea_id
           and fr.fea_id_b = pf.prod_fea_id  and pfs.fea_spec_id = pf.fea_spec_id;

          select t.attr_value_id into  i_attr_value_id from crmv2.attr_value@lk_crm1tocrm2db t where t.attr_id = i_attr_spec_id and t.attr_value = v_code;

          select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
          insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select i_attr_id, i_prod_inst_seq, i_attr_spec_id, i_attr_value_id, v_code, '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
          from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', i_prod_fea_id, i_attr_id, sysdate, '同步特性属性表',i_BATCH_ID);

        end if;

        select count(*) into i_count from prod_fea a  where a.prod_id = i_prodId and exists (select 'X' from prod_fea_spec b where a.fea_spec_id = b.fea_spec_id and  b.sort = '3' and b.code = 'IVPNJTZT' );
        if i_count>0 then
         select attr_id into i_attr_spec_id from  crmv2.attr_spec@lk_crm1tocrm2db  where java_code = 'IVPNJTZT';
         select prod_fea_id
           into i_prod_fea_id
           from prod_fea a
          where a.prod_id = i_prodId
            and exists (select 'X'
                   from prod_fea_spec b
                  where a.fea_spec_id = b.fea_spec_id and
                  b.sort = '3'
                    and b.code = 'IVPNJTZT');

          select pfs.code into  v_code from fea_rela fr, prod_fea  pf, prod_fea_spec pfs where fr.fea_id_a = i_prod_fea_id
           and fr.fea_id_b = pf.prod_fea_id  and pfs.fea_spec_id = pf.fea_spec_id;

            select t.attr_value_id into  i_attr_value_id from crmv2.attr_value@lk_crm1tocrm2db t where t.attr_id = i_attr_spec_id and t.attr_value = v_code;


          select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
          insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select i_attr_id, i_prod_inst_seq, i_attr_spec_id, i_attr_value_id, v_code, '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
          from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', i_prod_fea_id, i_attr_id, sysdate, '同步特性属性表',i_BATCH_ID);

        end if;

        select count(*) into i_count from prod_fea a  where prod_id = i_prodId and exists (select 'X' from prod_fea_spec b where a.fea_spec_id = b.fea_spec_id and  b.code = 'WNDHCD' );
        if i_count>0 then
         select attr_id into i_attr_spec_id from  crmv2.attr_spec@lk_crm1tocrm2db  where java_code = 'WNDHCD';
         select prod_fea_id
           into i_prod_fea_id
           from prod_fea a
          where a.prod_id = i_prodId
            and exists (select 'X'
                   from prod_fea_spec b
                  where a.fea_spec_id = b.fea_spec_id and b.code = 'WNDHCD');

          select pfs.code into  v_code from fea_rela fr, prod_fea  pf, prod_fea_spec pfs where fr.fea_id_a = i_prod_fea_id
            and fr.fea_id_b = pf.prod_fea_id  and pfs.fea_spec_id = pf.fea_spec_id;

          select t.attr_value_id into  i_attr_value_id from crmv2.attr_value@lk_crm1tocrm2db t where t.attr_id = i_attr_spec_id and t.attr_value = v_code;

          select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
          insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select i_attr_id, i_prod_inst_seq, i_attr_spec_id, i_attr_value_id, v_code, '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
          from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', i_prod_fea_id, i_attr_id, sysdate, '同步特性属性表',i_BATCH_ID);

        end if;

        select count(*) into i_count from prod_fea a  where prod_id = i_prodId and exists (select 'X' from prod_fea_spec b where a.fea_spec_id = b.fea_spec_id and  b.code = 'QYZJHM' );
        if i_count>0 then
         select attr_id into i_attr_spec_id from  crmv2.attr_spec@lk_crm1tocrm2db  where java_code = 'QYZJHM';
         select prod_fea_id,a.param1
           into i_prod_fea_id,v_code
           from prod_fea a
          where a.prod_id = i_prodId
            and exists (select 'X'
                   from prod_fea_spec b
                  where a.fea_spec_id = b.fea_spec_id and b.code = 'QYZJHM');

          select crmv2.seq_prod_inst_attr_id.nextval@lk_crm1tocrm2db into i_attr_id from dual;
          insert into crmv2.prod_inst_attr@lk_crm1tocrm2db (PROD_INST_ATTR_ID, PROD_INST_ID, ATTR_ID, ATTR_VALUE_ID, ATTR_VALUE, STATUS_CD, STATUS_DATE, EFF_DATE, EXP_DATE, CREATE_DATE, UPDATE_DATE, PROC_SERIAL, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REC_UPDATE_DATE)
          select i_attr_id, i_prod_inst_seq, i_attr_spec_id, '', v_code, '1000', sysdate, sysdate,to_date('10-04-2199 10:07:25', 'dd-mm-yyyy hh24:mi:ss'), sysdate, sysdate, '', pa.super, p.region, null, null, null
          from  prod p, mdse m, p_area pa where p.prod_id = m.prod_id and m.mdse_id =  i_mdseId and pa.id = p.region;

insert into crmv2.prod_inst_attr_ext@lk_crm1tocrm2db (EXT_ID, PROD_INST_ATTR_ID, ORDER_ITEM_ID, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
select crmv2.SEQ_EXT_ID.NEXTVAL@lk_crm1tocrm2db,PROD_INST_ATTR_ID,null,AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
from  crmv2.prod_inst_attr@lk_crm1tocrm2db  where  PROD_INST_ATTR_ID =  i_attr_id;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_INST_ATTR','PROD_INST_ATTR_ID',i_attr_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

          insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
          values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_attr', i_prod_fea_id, i_attr_id, sysdate, '同步特性属性表',i_BATCH_ID);

        end if;

      end if;


  end if;

  end proc_cross_prod_1TO2;

  --同步客户信息
   PROCEDURE proc_cross_account_1TO2(i_prodId       in varchar2,
                                  i_BATCH_ID     in number,
                                  i_region       in number,
                                  i_cust_seq     in number,
                                  i_prod_inst_seq in number,
                                  o_errMsg       out varchar2 )as

   o_ceshi       varchar2(50);
   i_count      number;
   i_account_id number(15);
   v_agreement_code varchar2(100);
   i_tel_acct_id  number(15);
   v_zgtl     varchar2(10);
   i_zg_id number(15);
   i_prod_inst_acct_seq number(15);
   i_PAYMENT_PLAN_id number(15);
   i_payment_plan_id2 number(15);
   i_area  varchar2(10);
   begin

    o_errMsg := '添加电信账户信息错误';
    o_ceshi := '4-002-6';--测试专用日志
    select count(*) into i_count   from zg z, telecom_account ta where  z.zgzr = i_prodId
    and ta.tel_acct_id = z.zgzh;

   --select p.area_code into i_area from prod p where  p.prod_id = i_prodId;
   --i_area := substr(i_area, 2, 3);
   i_area := '590';
    if i_count > 0 then
      select ta.agreement_code, ta.tel_acct_id  into  v_agreement_code, i_tel_acct_id   from zg z, telecom_account ta where  z.zgzr = i_prodId
      and ta.tel_acct_id = z.zgzh;
      o_ceshi := '4-002-7';--测试专用日志
      --2.0
      select count(*) into i_count  from crmv2.account@lk_crm1tocrm2db  where account_number = v_agreement_code ;
      if i_count > 0  then
        select account_id into i_account_id  from crmv2.account@lk_crm1tocrm2db  where account_number = v_agreement_code ;
      else
        select crmv2.seq_account_id.nextval@lk_crm1tocrm2db into i_account_id from dual;

        insert into crmv2.account@lk_crm1tocrm2db
          (ACCOUNT_ID,
           CUST_ID,
           COMMON_REGION_ID,
           ACCOUNT_NAME,
           ACCOUNT_AREA_GRADE,
           ACCOUNT_NUMBER, --
           GROUP_PAY_METHOD,
           PAY_CYCLE,   --记录付款周期
           CONTACT_PHONE,
           MOBILE_PHONE,
           IF_DEFAULT,
           PROC_SERIAL,
           EXT_ACCOUNT_ID,  --外部帐户标识
           --LAN_ID,
           AREA_ID,
           CREATE_DATE,
           CREATE_STAFF,
           REGION_CD,
           STATUS_CD,
           STATUS_DATE,
           UPDATE_DATE,
           UPDATE_STAFF,
           REC_UPDATE_DATE,
           DEDUCT_CHARGE,
           DEDUCT_LIMIT,
           PRINT_PROD_ID,
           SIGN_PROD_ID,
           PRINT_ACC_NBR,
           SIGN_ACC_NBR,
           EXT_FLAG1)
          select i_account_id,
                 i_cust_seq,
                 i_region,
                 ta.tel_acct_name,
                 '',
                 ta.agreement_code,
                 '',
                 '',  --
                 '',
                 '',
                 '',
                 '',
                 '', --外部帐户标识
                 pa.super,
                 ta.create_date,
                 null,
                 ta.region,
                 '1000',
                 ta.create_date,
                 ta.create_date,
                 null,
                 null,
                 ta.DEDUCT_CHARGE,
                 ta.DEDUCT_LIMIT,
                 null,
                 null,
                 '',
                 '',
                 'Y'
            from zg z, telecom_account ta, p_area pa
           where z.zgzr = i_prodId
             and ta.tel_acct_id = z.zgzh and pa.id = z.zgqy;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('ACCOUNT','ACCOUNT_ID',i_account_id,'upload','1002','1.0同步到2.0','fangzn',i_area);

    end if;

    o_ceshi := '4-002-8';--测试专用日志
    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'account', i_tel_acct_id, i_account_id, sysdate, '同步账户实例表',i_BATCH_ID);

      select zgtl,zgid into v_zgtl, i_zg_id from zg where zgzr = i_prodid;
      if v_zgtl = 'true' then
         v_zgtl := 'T';
      else
         v_zgtl := 'F';
      end if;

     select count(*) into i_count from  crmv2.prod_inst_acct@lk_crm1tocrm2db where ACCOUNT_ID = i_account_id and PROD_INST_ID = i_prod_inst_seq;
     if i_count = 0 then
      select crmv2.seq_prod_inst_acct_id.nextval@lk_crm1tocrm2db into i_prod_inst_acct_seq  from   dual;
      insert into crmv2.prod_inst_acct@lk_crm1tocrm2db
        (PROD_INST_ACCT_ID,
         ACCOUNT_ID,
         ACCT_ITEM_TYPE_GROUP_ID,
         PROD_INST_ID,
         PAYMENT_LIMIT_TYPE,
         PAYMENT_LIMIT,
         PRIORITY,
         STATUS_CD,
         STATUS_DATE,
         PROC_SERIAL,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         UPDATE_DATE,
         CREATE_DATE,
         EFF_DATE,
         EXP_DATE,
         DEF_ACCT_FLAG,
         CHARGE_TYPE,
         INVOICE_FORMART_FLAG,
         REC_UPDATE_DATE)
        select i_prod_inst_acct_seq,
               i_account_id,
               zgzl,
               i_prod_inst_seq,
               zgff,
               zgxe,
               zgxs,
               '1000',
               real_modify_date,
               '',
               pa.super,-- zgqy,
               pa.super,
               null,
               null,
               real_modify_date,
               zgrq,
               null,
               null,
               v_zgtl,
               zgfg,
               null,
               null
          from zg, p_area pa
         where zgzr = i_prodid  and zgqy = pa.id ;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PROD_INST_ACCT','PROD_INST_ACCT_ID',i_prod_inst_acct_seq,'upload','1002','1.0同步到2.0','fangzn',i_area);


    o_ceshi := '4-002-9';--测试专用日志
    insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
    values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'prod_inst_acct', i_zg_id, i_prod_inst_acct_seq, sysdate, '同步商品账户实例表',i_BATCH_ID);

    select crmv2.seq_PAYMENT_PLAN_id.nextval@lk_crm1tocrm2db into i_PAYMENT_PLAN_id from dual;

      insert into crmv2.payment_plan@lk_crm1tocrm2db
        (PAYMENT_PLAN,
         ACCOUNT_ID,
         PAYMENT_METHOD_ID,
         PAYMENT_BANK_ID,
         PAYMENT_ACCOUNT,
         PAYMENT_ACCOUNT_NAME,
         PAYMENT_ACCOUNT_TYPE,
         PRIORITY,
         AREA_ID,
         CREATE_DATE,
         CREATE_STAFF,
         REGION_CD,
         STATUS_CD,
         STATUS_DATE,
         UPDATE_DATE,
         UPDATE_STAFF,
         ACC_AGREEMENT_CODE,
         SEND_ENTRUST_METHOD,
         ENTRUST_TYPE,
         REC_UPDATE_DATE,
         PROPORTION,
         LIMITATION)
        select i_PAYMENT_PLAN_id,
               i_account_id,
               zh.zhlx,
               zh.zhyh,
               zh.zhzh,
               zh.zhmc,
               '',
               pp.priority,
               pa.super,
               pp.create_date,
               null,
               pa.id,
               '1000',
               pp.real_modify_date,
               pp.real_modify_date,
               null,
               zh.acc_agreement_code,
               zh.send_method_type,
               zh.entrust_type,
               null,
               '',
               0
          from payment_plan pp, zg z, telecom_account ta, zh , p_area pa
         where z.zgzr = i_prodId
           and ta.tel_acct_id = z.zgzh
           and ta.tel_acct_id = pp.tel_acct_id
           and zh.zhid = pp.cust_acct_id
           and pa.id = ta.region
           and rownum < 2;

          --增量2.0计费
          basejk.pkg_common.proc_intf_ins_billing_update@LK_CRM1TOCRM2JK
          ('PAYMENT_PLAN','PAYMENT_PLAN',i_PAYMENT_PLAN_id,'upload','1002','1.0同步到2.0','fangzn',i_area);


           select pp.payment_plan_id into i_payment_plan_id2
          from payment_plan pp, zg z, telecom_account ta, zh , p_area pa
         where z.zgzr = i_prodId
           and ta.tel_acct_id = z.zgzh
           and ta.tel_acct_id = pp.tel_acct_id
           and zh.zhid = pp.cust_acct_id
           and pa.id = ta.region
           and rownum < 2;
       o_ceshi := '4-002-10';--测试专用日志
      insert into crmv2.CROSS_LOCALAREA_LOG@lk_crm1tocrm2db (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,  BATCH_ID)
      values (crmv2.seq_CROSS_LOCALAREA_LOG_id.Nextval@lk_crm1tocrm2db, '1T2', 'payment_plan', i_payment_plan_id2, i_PAYMENT_PLAN_id, sysdate, '同步支付实例表',i_BATCH_ID);

    end if;
    end if;

   end proc_cross_account_1TO2;




end proc_cross_1TO2;
/
