CREATE package body           PKG_CRM2_CFG_IN_AREA is
  PROCEDURE p_mdseSpecPriceRelaIn(i_mdsespecid  in number, --1.0销售品规格
                                  i_prodofferid in number, --2.0销售品规格
                                  i_name        in VARCHAR2, --销售品名称
                                  str_msg       out VARCHAR2) is
    v_cnt           number; --是否存在数据
    v_kxprodofferid number; --可选包规格
    v_count         number; --总数据
    v_upcount       number; --修改数据
    v_delcount      number; --删除数据
    v_mdsespecid    number; --1.0规格
    v_prodofferid   number; --2.0规格
    v_remark        varchar2(2000); --备注
    v_mdsename      varchar2(200); --名称
    v_prodoffername varchar2(200); --名称
    v_state         varchar2(10); --状态
  begin
    v_count    := 0;
    v_upcount  := 0;
    v_delcount := 0;
    if i_mdsespecid > 0 and i_prodofferid > 0 then
      select name
        into v_mdsename
        from mdse_spec@lk_crmv1
       where mdse_spec_id = i_mdsespecid;
      select prod_offer_name
        into v_prodoffername
        from prod_offer
       where prod_offer_id = i_prodofferid;
      v_mdsespecid  := i_mdsespecid;
      v_prodofferid := i_prodofferid;
    elsif i_name is not null then
      v_mdsename      := i_name;
      v_prodoffername := i_name;
      if i_mdsespecid = 0 or i_mdsespecid is null then
        select count(*)
          into v_cnt
          from mdse_spec@lk_crmv1
         where name = i_name;
        if v_cnt != 1 then
          str_msg := '传入的销售品名称"' || i_name || '"找不到唯一的1.0销售品数据';
          return;
        end if;
        select mdse_spec_id
          into v_mdsespecid
          from mdse_spec@lk_crmv1
         where name = i_name;
      else
        v_mdsespecid := i_mdsespecid;
      end if;
      if i_prodofferid = 0 or i_prodofferid is null then
        select count(*)
          into v_cnt
          from prod_offer
         where prod_offer_name = i_name;
        if v_cnt != 1 then
          str_msg := '传入的销售品名称"' || i_name || '"找不到唯一的2.0销售品数据';
          return;
        end if;
        select prod_offer_id
          into v_prodofferid
          from prod_offer
         where prod_offer_name = i_name;
      else
        v_prodofferid := i_prodofferid;
      end if;
    end if;
    if (v_mdsespecid = 0) or (v_mdsespecid is null) or (v_prodofferid = 0) or
       (v_prodofferid is null) then
      str_msg := '请传入i_mdsespecid,i_prodofferid销售品规格;或者传入销售品名称';
      return;
    end if;
    select count(*)
      into v_cnt
      from prod_offer
     where prod_offer_id = v_prodofferid
       and ((OFFER_TYPE = '12' and OFFER_SUB_TYPE = 'T04') or
           OFFER_TYPE = '13');
    if v_cnt > 0 then
      --作为A端的销售品是可选包且细类是可选类销售品,或者为促销包的情况，不允许继续操作，且要把原先有的数据清理掉
      select count(*)
        into v_cnt
        from prod_offer_rel
       where relation_type_cd = '100000'
         and offer_a_id = v_prodofferid;
      if v_cnt > 0 then
        --错误数据已经作为可选关系的A端了。
        FOR DKX IN (select por.*
                      from prod_offer_rel por
                     where por.relation_type_cd = '100000'
                       and offer_a_id = v_prodofferid) LOOP
          select count(*)
            into v_cnt
            from prod_offer_inst_rel poir
           where poir.prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
          if v_cnt > 0 then
            --已经生成实例的数据，修改状态，原数据入历史表
            if DKX.STATUS_CD != '1100' then
              insert into PROD_OFFER_REL_HIS
                (HIS_ID,
                 PROD_OFFER_RELA_ID,
                 OFFER_A_ID,
                 OFFER_Z_ID,
                 ROLE_CD,
                 RELATION_TYPE_CD,
                 EFF_DATE,
                 EXP_DATE,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 HOT_SPOT_NO,
                 AREA_ID,
                 REGION_CD,
                 UPDATE_STAFF,
                 CREATE_STAFF,
                 SYNC_CUST,
                 EFFECTIVE_TYPE,
                 DEFAULT_TIME_PERIOD,
                 EXPIRE_TYPE,
                 RULE_TYPE)
              values
                (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,
                 DKX.PROD_OFFER_RELA_ID,
                 DKX.OFFER_A_ID,
                 DKX.OFFER_Z_ID,
                 DKX.ROLE_CD,
                 DKX.RELATION_TYPE_CD,
                 DKX.EFF_DATE,
                 DKX.EXP_DATE,
                 DKX.STATUS_CD,
                 DKX.STATUS_DATE,
                 DKX.CREATE_DATE,
                 DKX.UPDATE_DATE,
                 DKX.HOT_SPOT_NO,
                 DKX.AREA_ID,
                 DKX.REGION_CD,
                 DKX.UPDATE_STAFF,
                 DKX.CREATE_STAFF,
                 DKX.SYNC_CUST,
                 DKX.EFFECTIVE_TYPE,
                 DKX.DEFAULT_TIME_PERIOD,
                 DKX.EXPIRE_TYPE,
                 DKX.RULE_TYPE);
              update PROD_OFFER_REL
                 set status_cd = '1100', update_date = sysdate
               where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
              v_upcount := v_upcount + 1;
            end if;
          else
            delete from PROD_OFFER_REL
             where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
            v_delcount := v_delcount + 1;
          end if;
        END LOOP;
        if v_upcount > 0 then
          v_remark := '1.0销售品"' || v_mdsename ||
                      '"入2.0后为可选包,不能将套餐关联数据作为关联可选包配置导入;且要置失效已入2.0销售品"' ||
                      v_prodoffername || '"关联可选包数据';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_OFFER_REL',
             v_prodofferid,
             'OFFER_A_ID',
             'p_mdseSpecPriceRelaIn',
             SYSDATE,
             v_upcount,
             v_remark);
        end if;
        if v_delcount > 0 then
          v_remark := '1.0销售品"' || v_mdsename ||
                      '"入2.0后为可选包,不能将套餐关联数据作为关联可选包配置导入;且要删除已导入2.0销售品"' ||
                      v_prodoffername || '"关联可选包数据';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_OFFER_REL',
             v_prodofferid,
             'OFFER_A_ID',
             'p_mdseSpecPriceRelaIn',
             SYSDATE,
             v_delcount,
             v_remark);
        end if;
        str_msg := v_prodoffername || '为可选包,不能做为可选关系的A端,修改PROD_OFFER_REL"' ||
                   to_char(v_upcount) || '"条数据;删除PROD_OFFER_REL"' ||
                   to_char(v_delcount) || '"条数据';
        return;
      end if;
      str_msg := v_prodoffername || '为可选包,不能做为可选关系的A端';
      return;
    end if;
    --取福州地区和省级以外的数据, by niud, 120508
    FOR KX IN (select pp.price_id, pp.name, pm.cfg_area_id
                 from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                      price_plan@lk_crmv1                  pp
                where pm.price_id = pp.price_id
                  and pp.state = '70A'
                  and pm.mdse_spec_id = v_mdsespecid
                  and pm.cfg_area_id between 3 and 10) LOOP
      --新增数据
      --根据1.0的名称查询对应2.0的可选包销售品
      select count(*)
        into v_cnt
        from prod_offer
       where PROD_OFFER_NAME = KX.Name
         and OFFER_TYPE = '12'
         and OFFER_SUB_TYPE = 'T04';
      if v_cnt = 1 then
        select prod_offer_id
          into v_kxprodofferid
          from prod_offer
         where PROD_OFFER_NAME = KX.Name
           and OFFER_TYPE = '12'
           and OFFER_SUB_TYPE = 'T04';
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = v_prodofferid
           and por.offer_z_id = v_kxprodofferid
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_ID.Nextval,
             v_prodofferid,
             v_kxprodofferid,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             kx.cfg_area_id,
             1,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_count := v_count + 1;
        else
          --数据库已经有数据，但是有可能是置失效状态的，可以恢复原先的失效数据
          select count(*)
            into v_cnt
            from prod_offer_rel por
           where por.offer_a_id = v_prodofferid
             and por.offer_z_id = v_kxprodofferid
             and por.area_id = kx.cfg_area_id
             and por.relation_type_cd = '100000'
             and NVL(por.status_cd, '1000') in ('1000', '1100');
          if v_cnt = 1 then
            select por.prod_offer_rela_id
              into v_cnt
              from prod_offer_rel por
             where por.offer_a_id = v_prodofferid
               and por.offer_z_id = v_kxprodofferid
               and por.area_id = kx.cfg_area_id
               and por.relation_type_cd = '100000'
               and NVL(por.status_cd, '1000') in ('1000', '1100');
            select status_cd
              into v_state
              from prod_offer_rel por
             where por.prod_offer_rela_id = v_cnt;
            if v_state != '1000' then
              update prod_offer_rel
                 set status_cd = '1000', update_date = sysdate
               where prod_offer_rela_id = v_cnt;
              v_upcount := v_upcount + 1;
            end if;
          end if;
        end if;
      end if;
    END LOOP;
    --删除不符合数据
    FOR DKX IN (select por.*
                  from prod_offer_rel por, prod_offer o
                 where por.offer_z_id = o.prod_offer_id
                   and por.relation_type_cd = '100000'
                   and o.OFFER_TYPE != '12'
                   and o.OFFER_TYPE != '13'
                   and o.OFFER_SUB_TYPE != 'T04'
                   and por.offer_a_id = v_prodofferid) LOOP
      select count(*)
        into v_cnt
        from prod_offer_inst_rel poir
       where poir.prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
      if v_cnt > 0 then
        --已经生成实例的数据，修改状态，原数据入历史表
        if DKX.STATUS_CD = '1000' THEN
          insert into PROD_OFFER_REL_HIS
            (HIS_ID,
             PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,
             DKX.PROD_OFFER_RELA_ID,
             DKX.OFFER_A_ID,
             DKX.OFFER_Z_ID,
             DKX.ROLE_CD,
             DKX.RELATION_TYPE_CD,
             DKX.EFF_DATE,
             DKX.EXP_DATE,
             DKX.STATUS_CD,
             DKX.STATUS_DATE,
             DKX.CREATE_DATE,
             DKX.UPDATE_DATE,
             DKX.HOT_SPOT_NO,
             DKX.AREA_ID,
             DKX.REGION_CD,
             DKX.UPDATE_STAFF,
             DKX.CREATE_STAFF,
             DKX.SYNC_CUST,
             DKX.EFFECTIVE_TYPE,
             DKX.DEFAULT_TIME_PERIOD,
             DKX.EXPIRE_TYPE,
             DKX.RULE_TYPE);
          update PROD_OFFER_REL
             set status_cd = '1100', update_date = sysdate
           where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
          v_upcount := v_upcount + 1;
        END IF;
      else
        delete from PROD_OFFER_REL
         where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
        v_delcount := v_delcount + 1;
      end if;
    END LOOP;
    --日志记录
    if v_count > 0 then
      v_remark := '1.0销售品"' || v_mdsename || '"套餐关联数据,导入2.0销售品"' ||
                  v_prodoffername || '"关联可选包数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         v_prodofferid,
         'OFFER_A_ID',
         'p_mdseSpecPriceRelaIn',
         SYSDATE,
         v_count,
         v_remark);
    end if;
    if v_upcount > 0 then
      v_remark := '1.0销售品"' || v_mdsename ||
                  '"套餐关联数据,因Z端类型不为可选包,要置失效已导入2.0销售品"' || v_prodoffername ||
                  '"关联可选包数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         v_prodofferid,
         'OFFER_A_ID',
         'p_mdseSpecPriceRelaIn',
         SYSDATE,
         v_upcount,
         v_remark);
    end if;
    if v_delcount > 0 then
      v_remark := '1.0销售品"' || v_mdsename ||
                  '"套餐关联数据,因Z端类型不为可选包,要删除已导入2.0销售品"' || v_prodoffername ||
                  '"关联可选包数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         v_prodofferid,
         'OFFER_A_ID',
         'p_mdseSpecPriceRelaIn',
         SYSDATE,
         v_delcount,
         v_remark);
    end if;
    str_msg := '导入PROD_OFFER_REL"' || to_char(v_count) ||
               '"条数据;修改PROD_OFFER_REL"' || to_char(v_upcount) ||
               '"条数据;删除PROD_OFFER_REL"' || to_char(v_delcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := '导入PROD_OFFER_REL数据失败p_mdseSpecPriceRelaIn:' || sqlerrm;
  end;

  PROCEDURE p_mdseSpecCDMAPriceRelaIn(str_msg out VARCHAR2) is
    v_cnt           number; --是否存在数据
    v_kxprodofferid number; --可选包规格
    v_count         number; --数据
    v_upcount       number; --修改数据
    v_delcount      number; --删除数据
    v_allcount      number; --总数据
    v_remark        varchar2(2000); --备注
    v_state         varchar2(10); --状态
    v_upallcount    number; --修改总数据
    v_delallcount   number; --删除总数据
  begin
    v_allcount    := 0;
    v_upallcount  := 0;
    v_delallcount := 0;
    FOR TYMDSE IN (select o.prod_offer_id,
                          o.prod_offer_name,
                          pp.name,
                          pp.price_id
                     from prefer_mdse_price_spec_rela@lk_crmv1 pr,
                          price_plan@lk_crmv1                  pp,
                          mdse_ys_lisy_new                     myx,---取新的规格映射表（modify by lisy）
                          prod_offer                           o
                    where pr.mdse_spec_id = 610290109
                      and pr.cfg_area_id = 1
                      and pp.price_id = pr.price_id
                      and pp.yd_subclass = 1
                      and pr.state = '70A'
                      and myx.id_v1 = pp.price_id
                      and myx.id_v2 = o.prod_offer_id
                      and o.offer_type in ('10', '11')
                      and o.offer_sub_type = 'T01') LOOP
      v_count    := 0;
      v_delcount := 0;
      v_upcount  := 0;
      --取省级数据天翼适用套餐的数据
      FOR KX IN (select o.prod_offer_id,
                        o.prod_offer_name,
                        pp.price_id,
                        pp.name
                   from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                        price_plan@lk_crmv1                  pp,
                        mdse_ys_lisy_new                     myx,---取新的规格映射表（modify by lisy）
                        prod_offer                           o
                  where pm.price_id = pp.price_id
                    and pp.state = '70A'
                    and pm.mdse_spec_id = 610290109
                    and pm.cfg_area_id = 1
                    and myx.id_v1 = pp.price_id
                    and myx.id_v2 = o.prod_offer_id
                    and o.offer_type = '12'
                    and o.offer_sub_type = 'T04') LOOP
        v_kxprodofferid := KX.Prod_Offer_Id;
        select count(*)
          into v_cnt
          from mdse_spec_rela@lk_crmv1
         where ((mdse_spec_ida = TYMDSE.price_id and
               mdse_spec_idb = KX.price_id) or
               (mdse_spec_idb = TYMDSE.price_id and
               mdse_spec_ida = KX.price_id))
           and rela_type = '102';
        if v_cnt = 0 then
          --如果没有互斥关系
          select count(*)
            into v_cnt
            from prod_offer_rel por
           where por.offer_a_id = TYMDSE.PROD_OFFER_ID
             and por.offer_z_id = v_kxprodofferid
             and por.relation_type_cd = '100000';
          if v_cnt = 0 then
            insert into PROD_OFFER_REL
              (PROD_OFFER_RELA_ID,
               OFFER_A_ID,
               OFFER_Z_ID,
               ROLE_CD,
               RELATION_TYPE_CD,
               EFF_DATE,
               EXP_DATE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               HOT_SPOT_NO,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               SYNC_CUST,
               EFFECTIVE_TYPE,
               DEFAULT_TIME_PERIOD,
               EXPIRE_TYPE,
               RULE_TYPE)
            values
              (SEQ_PROD_OFFER_REL_ID.Nextval,
               TYMDSE.PROD_OFFER_ID,
               v_kxprodofferid,
               null,
               '100000',
               sysdate,
               null,
               '1000',
               sysdate,
               sysdate,
               null,
               null,
               1,
               1,
               49822,
               49822,
               null,
               null,
               null,
               null,
               null);
            v_count    := v_count + 1;
            v_allcount := v_allcount + 1;
          else
            --数据库已经有数据，但是有可能是置失效状态的，可以恢复原先的失效数据
            select count(*)
              into v_cnt
              from prod_offer_rel por
             where por.offer_a_id = TYMDSE.PROD_OFFER_ID
               and por.offer_z_id = v_kxprodofferid
               and por.relation_type_cd = '100000'
               and NVL(por.status_cd, '1000') in ('1000', '1100');
            if v_cnt = 1 then
              select por.prod_offer_rela_id
                into v_cnt
                from prod_offer_rel por
               where por.offer_a_id = TYMDSE.PROD_OFFER_ID
                 and por.offer_z_id = v_kxprodofferid
                 and por.relation_type_cd = '100000'
                 and NVL(por.status_cd, '1000') in ('1000', '1100');
              select por.status_cd
                into v_state
                from prod_offer_rel por
               where por.prod_offer_rela_id = v_cnt;
              if v_state != '1000' then
                update prod_offer_rel
                   set status_cd = '1000', update_date = sysdate
                 where prod_offer_rela_id = v_cnt;
                v_upcount    := v_upcount + 1;
                v_upallcount := v_upallcount + 1;
              end if;
            end if;
          end if;
        else
          --有互斥关系的情况，如果生成可选关系数据，要删除
          select count(*)
            into v_cnt
            from prod_offer_rel por
           where por.offer_a_id = TYMDSE.PROD_OFFER_ID
             and por.offer_z_id = v_kxprodofferid
             and por.relation_type_cd = '100000';
          if v_cnt > 0 then
            --删除不符合数据
            FOR DKX IN (select por.*
                          from prod_offer_rel por
                         where por.offer_a_id = TYMDSE.PROD_OFFER_ID
                           and por.offer_z_id = v_kxprodofferid
                           and por.relation_type_cd = '100000') LOOP
              select count(*)
                into v_cnt
                from prod_offer_inst_rel poir
               where poir.prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
              if v_cnt > 0 then
                --已经生成实例的数据，修改状态，原数据入历史表
                if DKX.Status_Cd != '1100' then
                  insert into PROD_OFFER_REL_HIS
                    (HIS_ID,
                     PROD_OFFER_RELA_ID,
                     OFFER_A_ID,
                     OFFER_Z_ID,
                     ROLE_CD,
                     RELATION_TYPE_CD,
                     EFF_DATE,
                     EXP_DATE,
                     STATUS_CD,
                     STATUS_DATE,
                     CREATE_DATE,
                     UPDATE_DATE,
                     HOT_SPOT_NO,
                     AREA_ID,
                     REGION_CD,
                     UPDATE_STAFF,
                     CREATE_STAFF,
                     SYNC_CUST,
                     EFFECTIVE_TYPE,
                     DEFAULT_TIME_PERIOD,
                     EXPIRE_TYPE,
                     RULE_TYPE)
                  values
                    (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,
                     DKX.PROD_OFFER_RELA_ID,
                     DKX.OFFER_A_ID,
                     DKX.OFFER_Z_ID,
                     DKX.ROLE_CD,
                     DKX.RELATION_TYPE_CD,
                     DKX.EFF_DATE,
                     DKX.EXP_DATE,
                     DKX.STATUS_CD,
                     DKX.STATUS_DATE,
                     DKX.CREATE_DATE,
                     DKX.UPDATE_DATE,
                     DKX.HOT_SPOT_NO,
                     DKX.AREA_ID,
                     DKX.REGION_CD,
                     DKX.UPDATE_STAFF,
                     DKX.CREATE_STAFF,
                     DKX.SYNC_CUST,
                     DKX.EFFECTIVE_TYPE,
                     DKX.DEFAULT_TIME_PERIOD,
                     DKX.EXPIRE_TYPE,
                     DKX.RULE_TYPE);
                  update PROD_OFFER_REL
                     set status_cd = '1100', update_date = sysdate
                   where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
                  v_upcount    := v_upcount + 1;
                  v_upallcount := v_upallcount + 1;
                end if;
              else
                delete from PROD_OFFER_REL
                 where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
                v_delcount    := v_delcount + 1;
                v_delallcount := v_delallcount + 1;
              end if;
            END LOOP;
          end if;
        end if;
      END LOOP;
      --删除不符合数据
      FOR DKX IN (select por.*
                    from prod_offer_rel por, prod_offer o
                   where por.offer_z_id = o.prod_offer_id
                     and por.relation_type_cd = '100000'
                     and o.OFFER_TYPE != '12'
                     and o.OFFER_SUB_TYPE != 'T04'
                     and o.OFFER_TYPE != '13'
                     and por.offer_a_id = TYMDSE.PROD_OFFER_ID) LOOP
        select count(*)
          into v_cnt
          from prod_offer_inst_rel poir
         where poir.prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
        if v_cnt > 0 then
          --已经生成实例的数据，修改状态，原数据入历史表
          if DKX.STATUS_CD != '1100' THEN
            insert into PROD_OFFER_REL_HIS
              (HIS_ID,
               PROD_OFFER_RELA_ID,
               OFFER_A_ID,
               OFFER_Z_ID,
               ROLE_CD,
               RELATION_TYPE_CD,
               EFF_DATE,
               EXP_DATE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               HOT_SPOT_NO,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               SYNC_CUST,
               EFFECTIVE_TYPE,
               DEFAULT_TIME_PERIOD,
               EXPIRE_TYPE,
               RULE_TYPE)
            values
              (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,
               DKX.PROD_OFFER_RELA_ID,
               DKX.OFFER_A_ID,
               DKX.OFFER_Z_ID,
               DKX.ROLE_CD,
               DKX.RELATION_TYPE_CD,
               DKX.EFF_DATE,
               DKX.EXP_DATE,
               DKX.STATUS_CD,
               DKX.STATUS_DATE,
               DKX.CREATE_DATE,
               DKX.UPDATE_DATE,
               DKX.HOT_SPOT_NO,
               DKX.AREA_ID,
               DKX.REGION_CD,
               DKX.UPDATE_STAFF,
               DKX.CREATE_STAFF,
               DKX.SYNC_CUST,
               DKX.EFFECTIVE_TYPE,
               DKX.DEFAULT_TIME_PERIOD,
               DKX.EXPIRE_TYPE,
               DKX.RULE_TYPE);
            update PROD_OFFER_REL
               set status_cd = '1100', update_date = sysdate
             where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
            v_upcount    := v_upcount + 1;
            v_upallcount := v_upallcount + 1;
          END IF;
        else
          delete from PROD_OFFER_REL
           where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
          v_delcount    := v_delcount + 1;
          v_delallcount := v_delallcount + 1;
        end if;
      END LOOP;
      --日志记录
      if v_count > 0 then
        v_remark := '天翼套餐销售品"' || TYMDSE.PROD_OFFER_NAME || '"导入2.0关联可选包数据';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           TYMDSE.PROD_OFFER_ID,
           'OFFER_A_ID',
           'p_mdseSpecCDMAPriceRelaIn',
           SYSDATE,
           v_count,
           v_remark);
      end if;
      if v_upcount > 0 then
        v_remark := '天翼套餐销售品"' || TYMDSE.PROD_OFFER_NAME ||
                    '"套餐关联数据,导入2.0关联可选包数据';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           TYMDSE.PROD_OFFER_ID,
           'OFFER_A_ID',
           'p_mdseSpecCDMAPriceRelaIn',
           SYSDATE,
           v_upcount,
           v_remark);
      end if;
      if v_delcount > 0 then
        v_remark := '天翼套餐销售品"' || TYMDSE.PROD_OFFER_NAME ||
                    '"套餐关联数据,因Z端类型不为可选包,要删除已导入2.0关联可选包数据';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           TYMDSE.PROD_OFFER_ID,
           'OFFER_A_ID',
           'p_mdseSpecCDMAPriceRelaIn',
           SYSDATE,
           v_delcount,
           v_remark);
      end if;
    END LOOP;

    /*--删除不适用的A端
     FOR TYMDSE IN(select a1.price_id_v1 price_id,
             a3.prod_offer_id,
             a3.prod_offer_name,
             a3.offer_type,
             a3.exp_date
        from TYMDSE_PRICE_LISY a1, mdse_ys_xul a2, prod_offer a3
       where a1.price_id_v1 = a2.offer_id_1
         and a2.offer_id_2 = a3.prod_offer_id
         and a3.offer_type = '11'
         and a3.prod_offer_id not in
          (select o.prod_offer_id
             from prefer_mdse_price_spec_rela@lk_crmv1 pr,
                  price_plan@lk_crmv1                  pp,
                  MDSE_YS_XUL                          myx,
                  prod_offer                           o
            where pr.mdse_spec_id = 610290109
              and pr.cfg_area_id = 1
              and pp.price_id = pr.price_id
              and pp.yd_subclass = 1
              and pr.state = '70A'
              and myx.offer_id_1 = pp.price_id
              and myx.offer_id_2 = o.prod_offer_id
              and o.offer_type in ('10', '11')
              and o.offer_sub_type = 'T01'))LOOP
      v_delcount:=0;
      v_upcount:=0;
         --取省级数据天翼适用套餐的数据
      FOR KX IN (select o.prod_offer_id, o.prod_offer_name, pp.price_id, pp.name
          from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
               price_plan@lk_crmv1                  pp,
               mdse_ys_xul                          myx,
               prod_offer                           o
         where pm.price_id = pp.price_id
           and pp.state = '70A'
           and pm.mdse_spec_id = 610290109
           and pm.cfg_area_id = 1
           and myx.offer_id_1 = pp.price_id
           and myx.offer_id_2 = o.prod_offer_id
           and o.offer_type = '12'
           and o.offer_sub_type = 'T04' ) LOOP
       v_kxprodofferid:=KX.Prod_Offer_Id;
       select count(*) into v_cnt from prod_offer_rel por where por.offer_a_id=TYMDSE.PROD_OFFER_ID and por.offer_z_id=v_kxprodofferid and por.relation_type_cd='100000' and  NVL(por.status_cd, '1000')='1000';
       if v_cnt>0 then
        --删除关联数据
        FOR DKX IN (select por.*
               from prod_offer_rel por
              where  por.offer_a_id=TYMDSE.PROD_OFFER_ID
                 and por.offer_z_id=v_kxprodofferid
                 and por.relation_type_cd='100000') LOOP
                select count(*) into v_cnt from prod_offer_inst_rel poir where poir.prod_offer_rela_id=DKX.PROD_OFFER_RELA_ID;
                if v_cnt >0 then --已经生成实例的数据，修改状态，原数据入历史表
                  if DKX.STATUS_CD!='1100' then
                     insert into PROD_OFFER_REL_HIS (HIS_ID,PROD_OFFER_RELA_ID, OFFER_A_ID, OFFER_Z_ID, ROLE_CD, RELATION_TYPE_CD, EFF_DATE, EXP_DATE, STATUS_CD, STATUS_DATE, CREATE_DATE, UPDATE_DATE, HOT_SPOT_NO, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, SYNC_CUST, EFFECTIVE_TYPE, DEFAULT_TIME_PERIOD, EXPIRE_TYPE, RULE_TYPE)
                       values (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,DKX.PROD_OFFER_RELA_ID, DKX.OFFER_A_ID, DKX.OFFER_Z_ID, DKX.ROLE_CD, DKX.RELATION_TYPE_CD, DKX.EFF_DATE, DKX.EXP_DATE, DKX.STATUS_CD,DKX.STATUS_DATE, DKX.CREATE_DATE, DKX.UPDATE_DATE, DKX.HOT_SPOT_NO, DKX.AREA_ID, DKX.REGION_CD, DKX.UPDATE_STAFF, DKX.CREATE_STAFF, DKX.SYNC_CUST, DKX.EFFECTIVE_TYPE, DKX.DEFAULT_TIME_PERIOD, DKX.EXPIRE_TYPE, DKX.RULE_TYPE);
                     update PROD_OFFER_REL set status_cd='1100',update_date=sysdate where prod_offer_rela_id=DKX.PROD_OFFER_RELA_ID;
                     v_upcount:=v_upcount+1;
                     v_upallcount:=v_upallcount+1;
                  end if;
                else
                  delete from PROD_OFFER_REL where prod_offer_rela_id=DKX.PROD_OFFER_RELA_ID;
                  v_delcount:=v_delcount+1;
                  v_delallcount:=v_delallcount+1;
                end if;
         END LOOP;
       end if;
      END LOOP;
       --日志记录
      v_remark:='套餐销售品"'||TYMDSE.PROD_OFFER_NAME||'"套餐关联数据,修改导入2.0关联可选包数据';
      insert into CRM1_CFG_SYNC (ID, TABLE_NAME, OBJ_ID, OBJ_TYPE, SYNC_METHO, SYNC_DATE, SYNC_COUNT, REMARK)
       values (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL, 'PROD_OFFER_REL', TYMDSE.PROD_OFFER_ID, 'OFFER_A_ID', 'p_mdseSpecCDMAPriceRelaIn',SYSDATE, v_upcount, v_remark);
      v_remark:='套餐销售品"'||TYMDSE.PROD_OFFER_NAME||'"套餐关联数据,因停售等原因不再作为天翼套餐销售品,要删除已导入2.0关联可选包数据';
      insert into CRM1_CFG_SYNC (ID, TABLE_NAME, OBJ_ID, OBJ_TYPE, SYNC_METHO, SYNC_DATE, SYNC_COUNT, REMARK)
       values (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL, 'PROD_OFFER_REL', TYMDSE.PROD_OFFER_ID, 'OFFER_A_ID', 'p_mdseSpecCDMAPriceRelaIn',SYSDATE, v_delcount, v_remark);
    END LOOP;*/
    str_msg := '导入PROD_OFFER_REL"' || to_char(v_allcount) ||
               '"条数据;修改PROD_OFFER_REL"' || to_char(v_upallcount) ||
               '"条数据;删除PROD_OFFER_REL"' || to_char(v_delallcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := '导入PROD_OFFER_REL数据失败p_mdseSpecPriceRelaIn:' || sqlerrm;
  end;

  PROCEDURE p_oldMaterialIn(str_msg out VARCHAR2) is
    v_cnt    number; --查询数
    v_count  number; --插入总数
    v_remark varchar2(2000); --备注
  begin
    v_count := 0;
    FOR MA IN (select bb.prod_offer_id, bb.prod_offer_name, aa.product_id
                 from offer_prod_rel aa, prod_offer bb
                where bb.prod_offer_id = aa.prod_offer_id
                  and bb.status_cd = '1000'
                  AND aa.rule_type != '13'
                  and bb.offer_type in ('10', '11')
                  and aa.product_id in
                      ('800298351', '800298301', '800298360', '800298362',
                       '800298729', '800000000', '800298312', '800298306',
                       '800298304', '800000001', '800003975', '800000003',
                       '800298758', '800298377', '800298378', '800003976',
                       '800298387', '800299272', '800299275', '800299286',
                       '800298499', '800299283', '800298967', '800298421',
                       '800000091', '800298302', '800298425', '800000338',
                       '610007605', '610007606')
                  and aa.status_cd = '1000') LOOP
      select count(*)
        into v_cnt
        from prod_offer_rel por
       where por.offer_a_id = MA.Prod_Offer_Id
         and por.offer_z_id = 800298609
         and por.relation_type_cd = '100000';
      if v_cnt = 0 then
        insert into PROD_OFFER_REL
          (PROD_OFFER_RELA_ID,
           OFFER_A_ID,
           OFFER_Z_ID,
           ROLE_CD,
           RELATION_TYPE_CD,
           EFF_DATE,
           EXP_DATE,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           HOT_SPOT_NO,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           SYNC_CUST,
           EFFECTIVE_TYPE,
           DEFAULT_TIME_PERIOD,
           EXPIRE_TYPE,
           RULE_TYPE)
        values
          (SEQ_PROD_OFFER_REL_ID.Nextval,
           MA.Prod_Offer_Id,
           800298609,
           null,
           '100000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           null,
           null,
           1,
           1,
           49822,
           49822,
           null,
           null,
           null,
           null,
           null);
        v_count := v_count + 1;
      end if;
    END LOOP;
    v_remark := '1.0旧实物关联数据导入2.0销售品关联可选关系';
    insert into CRM1_CFG_SYNC
      (ID,
       TABLE_NAME,
       OBJ_ID,
       OBJ_TYPE,
       SYNC_METHO,
       SYNC_DATE,
       SYNC_COUNT,
       REMARK)
    values
      (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
       'PROD_OFFER_REL',
       '800298609',
       'OFFER_Z_ID',
       'p_oldMaterialIn',
       SYSDATE,
       v_count,
       v_remark);
    str_msg := '导入PROD_OFFER_REL"' || to_char(v_count) || '"条数据';

  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_oldMaterialIn:' || sqlerrm;
  end;

  PROCEDURE p_newMaterialIn(str_msg out VARCHAR2) is
    v_cnt          number; --查询数
    v_count        number; --插入总数
    v_oldofferid   number; --旧的销售品ID
    v_oldoffername varchar2(100); --旧的销售品名称
    v_remark       varchar2(2000); --备注
    v_allcount     number; --总数据
  begin
    v_allcount   := 0;
    v_oldofferid := 0;
    v_count      := 0;
    FOR MA IN (select r.offer_prod_rela_id,
                      z.product_name 产品名称,
                      o.prod_offer_name p_prod_offer_name,
                      o.prod_offer_id p_prod_offer_id,
                      z.product_offer_name m_prod_offer_name,
                      mo.prod_offer_id m_prod_offer_id
                 from offer_prod_rel            r,
                      prod_offer                o,
                      product                   p,
                      prod_offer                mo,
                      CRM1_MATERAIL_MAP_ZHENGCL z
                where p.product_name = z.product_name
                  and p.product_id = r.product_id
                  and o.prod_offer_id = r.prod_offer_id
                  and o.offer_type in ('10', '11')
                  and mo.prod_offer_name = z.product_offer_name
                  and r.rule_type != '13'
                  and r.status_cd = '1000'
                order by o.prod_offer_id) LOOP
      select count(*)
        into v_cnt
        from prod_offer_rel por
       where por.offer_a_id = MA.p_prod_offer_id
         and por.offer_z_id = MA.m_prod_offer_id
         and por.relation_type_cd = '100000';
      if v_cnt = 0 then
        insert into PROD_OFFER_REL
          (PROD_OFFER_RELA_ID,
           OFFER_A_ID,
           OFFER_Z_ID,
           ROLE_CD,
           RELATION_TYPE_CD,
           EFF_DATE,
           EXP_DATE,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           HOT_SPOT_NO,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           SYNC_CUST,
           EFFECTIVE_TYPE,
           DEFAULT_TIME_PERIOD,
           EXPIRE_TYPE,
           RULE_TYPE)
        values
          (SEQ_PROD_OFFER_REL_ID.Nextval,
           MA.p_prod_offer_id,
           MA.m_prod_offer_id,
           null,
           '100000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           null,
           null,
           1,
           1,
           49822,
           49822,
           null,
           null,
           null,
           null,
           null);
        v_count    := v_count + 1;
        v_allcount := v_allcount + 1;
      end if;
      if v_oldofferid = 0 then
        v_oldofferid   := MA.p_Prod_Offer_Id;
        v_oldoffername := MA.P_PROD_OFFER_NAME;
      end if;
      if v_oldofferid != 0 and v_oldofferid != MA.p_Prod_Offer_Id and
         v_count > 0 then
        v_remark := '1.0新实物关联,导入' || v_oldoffername || '销售品关联终端促销包可选关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           v_oldofferid,
           'OFFER_A_ID',
           'p_newMaterialIn',
           SYSDATE,
           v_count,
           v_remark);
        v_oldofferid   := MA.p_prod_offer_id;
        v_oldoffername := MA.P_PROD_OFFER_NAME;
        v_count        := 0;
      end if;
    END LOOP;
    str_msg := '导入PROD_OFFER_REL"' || to_char(v_allcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_newMaterialIn:' || sqlerrm;
  end;

  PROCEDURE p_roleInProdRelRestrictOffer(str_msg out VARCHAR2) is
    v_cnt             number; --查询数
    v_oldprodrelaId   number; --旧的群组类产品与原子产品的关联关系
    v_oldprodrelaId2  number; --旧的群组类产品与原子产品的关联关系
    v_restrictId      number; --产品关联销售品ID
    v_count           number; --插入数
    v_pallcount       number; --总数据
    v_oallcount       number; --总数据
    v_oldprodofferid  number; --旧的2.0销售品规格
    v_porcount        number; --插入prod_offer_rel数 帽子上的适用套餐
    v_porcount2       number; --插入prod_offer_rel数 其它角色包上的适用套餐
    v_allporcount     number; --插入prod_offer_rel总数
    v_orrpcount       number; --插入offer_Rel_Restrict_Prod数
    v_allorrpcount    number; --插入offer_Rel_Restrict_Prod总数
    v_prodofferrelaid number; --prod_offer_rel.rela_id
    v_infoname        varchar2(1000); --信息说明
    v_remark          varchar2(2000); --备注
    v_seqid           number; --seq取值
  begin
    v_pallcount       := 0;
    v_oallcount       := 0;
    v_oldprodrelaId   := 0;
    v_oldprodofferid  := 0;
    v_allporcount     := 0;
    v_allorrpcount    := 0;
    v_prodofferrelaid := 0;
    v_porcount        := 0;
    v_oldprodrelaId2  := 0;
    v_orrpcount       := 0;
    /*查询1.0组合类在2.0落地为基础接入类销售品的数据
      1.角色包上的套餐落地为套餐销售品的数据。根据角色查询
      2.合并上原组合类角色包上适用销售品在1.0落为基础销售品的数据。也根据角色查询
    */
    FOR PreferOfferRelaOffer IN (select a.prefer_spec_id        prefer_spec_id,
                                        pmsr.rela_id            prefer_role_id,
                                        c.prod_offer_id         prod_offer_id,
                                        c.prod_offer_name       prod_offer_name,
                                        r.product_rel_id        product_rel_id,
                                        prr.role_name           role_name,
                                        p.product_id            product_a_id,
                                        p.product_name          product_a_name,
                                        pz.product_id           product_z_id,
                                        pz.product_name         product_z_name,
                                        po.prod_offer_id        rela_prod_offer_id,
                                        po.prod_offer_name      rela_prod_offer_name,
                                        opr2.offer_prod_rela_id rela_offer_prod_rela_id,
                                        pmpsr.CFG_AREA_ID       cfg_area_id
                                   from prefer_price_spec@lk_crmv1           a,
                                        mdse_ys_lisy_new                     b, ---取新的规格隐射表（modify by lisy）
                                        prod_offer                           c,
                                        offer_prod_rel                       opr,
                                        product                              p,
                                        product_relation                     r,
                                        product_rel_role                     prr,
                                        product                              pz,
                                        prod_map_zhengcl                     pm,
                                        prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                                        PREFER_MDSE_SPEC_RELA@lk_crmv1       pmsr,
                                        PM_SPECIAL_MDSE_SPEC@lk_crmv1        psms,
                                        mdse_spec@lk_crmv1                   ms,
                                        mdse_ys_lisy_new                     myx, ---取新的规格隐射表（modify by lisy）
                                        prod_offer                           po,
                                        offer_prod_rel                       opr2
                                  where a.prefer_spec_id = b.id_v1
                                    and b.id_v2 = c.prod_offer_id
                                    and c.offer_type = '10'
                                    and c.offer_sub_type = 'T01'
                                    and opr.prod_offer_id = c.Prod_Offer_Id
                                    and opr.rule_type != '13'
                                    and p.product_id = opr.product_id
                                    and p.product_type = '13'
                                    and opr.status_cd = '1000'
                                    and p.product_id = r.product_a_id
                                    and r.product_z_id = pz.product_id --2.0产品规格
                                    and r.relation_type_cd = '100300' --构成关系
                                    and prr.product_id = p.product_id
                                    and pmsr.name = prr.role_name
                                    and prr.role_cd = r.role_cd
                                    and pmsr.prefer_spec_id =
                                        a.prefer_spec_id
                                    and pmpsr.CFG_AREA_ID=10 --区域
                                    AND pmpsr.RELA_MDSE_ID = pmsr.rela_id
                                    and pmsr.rela_id = psms.role_id
                                    and psms.mdse_spec_id = ms.mdse_spec_id
                                    and pm.product_id = pz.product_id
                                    and ms.prod_spec_id = pm.prod_spec_id --1.0产品规格
                                    and pmpsr.price_id = myx.id_v1
                                    and myx.id_v2 = po.prod_offer_id
                                    and po.offer_type = '11'
                                    and opr2.product_id = pz.product_id
                                    and opr2.prod_offer_id =
                                        po.prod_offer_id
                                 union
                                 select a.prefer_spec_id        prefer_spec_id,
                                        pmsr.rela_id            prefer_role_id,
                                        c.prod_offer_id         prod_offer_id,
                                        c.prod_offer_name       prod_offer_name,
                                        r.product_rel_id        product_rel_id,
                                        prr.role_name           role_name,
                                        p.product_id            product_a_id,
                                        p.product_name          product_a_name,
                                        pz.product_id           product_z_id,
                                        pz.product_name         product_z_name,
                                        po.prod_offer_id        rela_prod_offer_id,
                                        po.prod_offer_name      rela_prod_offer_name,
                                        opr2.offer_prod_rela_id rela_offer_prod_rela_id,
                                        1                       cfg_area_id
                                   from prefer_price_spec@lk_crmv1     a,
                                        mdse_ys_lisy_new               b, ---取新的规格隐射表（modify by lisy）
                                        prod_offer                     c,
                                        offer_prod_rel                 opr,
                                        product                        p,
                                        product_relation               r,
                                        product_rel_role               prr,
                                        product                        pz,
                                        prod_map_zhengcl               pm,
                                        PREFER_MDSE_SPEC_RELA@lk_crmv1 pmsr,
                                        PM_SPECIAL_MDSE_SPEC@lk_crmv1  psms,
                                        mdse_spec@lk_crmv1             ms,
                                        mdse_ys_lisy_new               myx, ---取新的规格隐射表（modify by lisy）
                                        prod_offer                     po,
                                        offer_prod_rel                 opr2
                                  where a.prefer_spec_id = b.id_v1
                                    and b.id_v2 = c.prod_offer_id
                                    and c.offer_type = '10'
                                    and c.offer_sub_type = 'T01'
                                    and opr.prod_offer_id = c.Prod_Offer_Id
                                    and opr.rule_type != '13'
                                    and p.product_id = opr.product_id
                                    and p.product_type = '13'
                                    and opr.status_cd = '1000'
                                    and p.product_id = r.product_a_id
                                    and r.product_z_id = pz.product_id --2.0产品规格
                                    and r.relation_type_cd = '100300' --构成关系
                                    and prr.product_id = p.product_id
                                    and pmsr.name = prr.role_name
                                    and prr.role_cd = r.role_cd
                                    and pmsr.prefer_spec_id =
                                        a.prefer_spec_id
                                    and pmsr.rela_id = psms.role_id
                                    and psms.mdse_spec_id = ms.mdse_spec_id
                                    and pm.product_id = pz.product_id
                                    and ms.prod_spec_id = pm.prod_spec_id --1.0产品规格
                                    and psms.mdse_spec_id = myx.id_v1
                                    and myx.id_v2 = po.prod_offer_id
                                    and po.offer_type = '10'
                                    and opr2.product_id = pz.product_id
                                    and opr2.prod_offer_id =
                                        po.prod_offer_id
                                  order by prod_offer_id, product_z_id) LOOP
      --产品关联导入数据日志记录
      if v_oldprodrelaId = 0 or
         (v_oldprodrelaId > 0 and
         v_oldprodrelaId != PreferOfferRelaOffer.product_rel_id) then
        if v_oldprodrelaId > 0 and v_count > 0 then
          select p1.product_name || '与' || p2.product_name || '的' ||
                 v.attr_value_name
            into v_infoname
            from product_relation r, product p1, product p2, attr_value v
           where v.attr_id = 7691
             and v.attr_value = r.relation_type_cd
             and r.product_rel_id = v_oldprodrelaId
             and r.product_a_id = p1.product_id
             and r.product_z_id = p2.product_id;
          v_remark := '1.0角色上适用套餐,导入"' || v_infoname || '"的产品关联销售品约束表';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_REL_RESTRICT_OFFER',
             v_oldprodrelaId,
             'PRODUCT_REL_ID',
             'p_roleInProdRelRestrictOffer',
             SYSDATE,
             v_count,
             v_remark);
        end if;
        v_oldprodrelaId := PreferOfferRelaOffer.product_rel_id;
        v_count         := 0;
      end if;
      --是否2.0已经有配置产品关系上限制销售品约束.没配才插入数据
      select count(*)
        into v_cnt
        from Prod_Rel_Restrict_Offer
       where product_rel_id = PreferOfferRelaOffer.product_rel_id
         and rela_offer_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id;
      if v_cnt = 0 then
        --插入PROD_REL_RESTRICT_OFFER
        select SEQ_PROD_REL_RESTRICT_OFFER_ID.nextval
          into v_seqid
          from dual;
        insert into PROD_REL_RESTRICT_OFFER
          (RESTRICT_ID,
           PRODUCT_REL_ID,
           RESTRICT_TYPE,
           RELA_OFFER_ID,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF)
        values
          (v_seqid,
           PreferOfferRelaOffer.product_rel_id,
           '10',
           PreferOfferRelaOffer.Rela_Prod_Offer_Id,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           PreferOfferRelaOffer.cfg_area_id,
           null,
           49822,
           49822);
        v_restrictId := v_seqid;
        v_pallcount  := v_pallcount + 1;
        v_count      := v_count + 1;
      elsif v_cnt = 1 then
        select RESTRICT_ID
          into v_restrictId
          from Prod_Rel_Restrict_Offer
         where product_rel_id = PreferOfferRelaOffer.product_rel_id
           and rela_offer_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id;
      end if;
      select count(*)
        into v_cnt
        from OBJ_REL_CFG
       where (OBJ_CLASS_ID = 0 or OBJ_CLASS_ID is null)
         and (OBJ_ID = 0 or OBJ_ID is null)
         and CFG_CLASS_ID = 64855
         and CFG_ID = v_restrictId;
      if v_cnt = 0 then
        --关联表OBJ_REL_CFG也要插入
        insert into OBJ_REL_CFG
          (OBJ_REL_CFG_ID,
           OBJ_CLASS_ID,
           OBJ_ID,
           CFG_CLASS_ID,
           CFG_ID,
           AREA_ID,
           REGION_CD,
           CREATE_DATE,
           CREATE_STAFF,
           STATUS_CD,
           STATUS_DATE,
           UPDATE_DATE,
           UPDATE_STAFF)
        values
          (seq_obj_rel_cfg_id.nextval,
           null,
           0,
           64855,
           v_seqid,
           10,----区域
           null,
           sysdate,
           49822,
           '1000',
           sysdate,
           sysdate,
           49822);
        v_oallcount := v_oallcount + 1;
      end if;
      --查询帽子上的适用套餐,落地2.0为可选包的情况。之间建立可选关系
      if v_oldprodofferid = 0 or
         (v_oldprodofferid > 0 and
         v_oldprodofferid != PreferOfferRelaOffer.Prod_Offer_Id) then
        FOR MOFFER IN (SELECT distinct PO.PROD_OFFER_ID, PO.PROD_OFFER_NAME
                         FROM PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 PMPSR,
                              PREFER_MDSE_SPEC_RELA@lk_crmv1       PMSR,
                              MDSE_YS_LISY_NEW                     MYX, ---取新的规格隐射表（modify by lisy）
                              PROD_OFFER                           PO
                        WHERE PMPSR.rela_mdse_id = PMSR.RELA_ID
                          AND PMSR.ID_TYPE = '1'
                          AND PMPSR.CFG_AREA_ID=10---区域
                          AND PMPSR.PRICE_ID = MYX.ID_V1
                          AND MYX.ID_V2 = PO.PROD_OFFER_ID
                          AND PO.OFFER_TYPE = '12'
                          AND PO.OFFER_SUB_TYPE = 'T04'
                          AND PMSR.prefer_spec_id =
                              PreferOfferRelaOffer.Prefer_Spec_Id) LOOP
          select count(*)
            into v_cnt
            from prod_offer_rel por
           where por.offer_a_id = PreferOfferRelaOffer.Prod_Offer_Id
             and por.offer_z_id = MOFFER.PROD_OFFER_ID
             and por.relation_type_cd = '100000';
          if v_cnt = 0 then
            insert into PROD_OFFER_REL
              (PROD_OFFER_RELA_ID,
               OFFER_A_ID,
               OFFER_Z_ID,
               ROLE_CD,
               RELATION_TYPE_CD,
               EFF_DATE,
               EXP_DATE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               HOT_SPOT_NO,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               SYNC_CUST,
               EFFECTIVE_TYPE,
               DEFAULT_TIME_PERIOD,
               EXPIRE_TYPE,
               RULE_TYPE)
            values
              (SEQ_PROD_OFFER_REL_ID.nextval,
               PreferOfferRelaOffer.Prod_Offer_Id,
               MOFFER.PROD_OFFER_ID,
               null,
               '100000',
               sysdate,
               null,
               '1000',
               sysdate,
               sysdate,
               null,
               null,
               10,---区域
               null,
               49822,
               49822,
               null,
               null,
               null,
               null,
               null);
            v_porcount    := v_porcount + 1;
            v_allporcount := v_allporcount + 1;
          end if;
        END LOOP;
        if v_porcount > 0 then
          v_remark := '1.0角色上适用套餐,导入"' ||
                      PreferOfferRelaOffer.Prod_offer_name || '"与可选包的可选关系';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_OFFER_REL',
             PreferOfferRelaOffer.Prod_Offer_Id,
             'OFFER_A_ID',
             'p_roleInProdRelRestrictOffer',
             SYSDATE,
             v_porcount,
             v_remark);
        end if;
        v_porcount       := 0;
        v_oldprodofferid := PreferOfferRelaOffer.Prod_Offer_Id;
      end if;
      /*其它角色包上的适用套餐 要与同角色的产品关系上的套餐销售品（基础销售品）配置可选关系
      如果这个可选包只能角色上受理，则要增加“可选包组合产品约束”*/
      v_porcount2 := 0;
      FOR KxbProdOffer IN (select pmrsr.rela_mdse_id,
                                  pmrsr.price_id,
                                  po.prod_offer_id,
                                  po.prod_offer_name
                             from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pmrsr,
                                  mdse_ys_lisy_new                     myx, ---取新的规格隐射表（modify by lisy）
                                  prod_offer                           po
                            where pmrsr.CFG_AREA_ID='9'----区域
                              and pmrsr.rela_mdse_id =
                                  PreferOfferRelaOffer.Prefer_Role_Id --1.0的角色包
                              and pmrsr.price_id = myx.id_v1
                              and myx.id_v2 = po.prod_offer_id
                              and po.offer_type = '12'
                              and po.offer_sub_type = 'T04') LOOP
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
           and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          select SEQ_PROD_OFFER_REL_ID.nextval
            into v_prodofferrelaid
            from dual;
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (v_prodofferrelaid,
             PreferOfferRelaOffer.Rela_Prod_Offer_Id,
             KxbProdOffer.Prod_Offer_Id,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             '10',---区域
             null,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_porcount2   := v_porcount2 + 1;
          v_allporcount := v_allporcount + 1;
        elsif v_cnt = 1 then
          select por.prod_offer_rela_id
            into v_prodofferrelaid
            from prod_offer_rel por
           where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
             and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
             and por.relation_type_cd = '100000';
        else
          v_prodofferrelaid := 0;
        end if;
        if v_prodofferrelaid > 0 then
          --判断可选包是否只能在角色上受理
          select count(*)
            into v_cnt
            from prefer_mdse_price_spec_rela@lk_crmv1
           where price_id = KxbProdOffer.Prod_Offer_Id
             and mdse_spec_id > 0
             and rela_mdse_id = -1
             and state = '70A'
             and cfg_area_id ='6';----区域
          if v_cnt = 0 then
            --帽子与产品关联关系 作为可选包组合产品约束的日志记录
            if v_oldprodrelaId2 = 0 or
               (v_oldprodrelaId2 > 0 and
               v_oldprodrelaId2 != PreferOfferRelaOffer.product_rel_id) then
              if v_oldprodrelaId2 > 0 and v_orrpcount > 0 then
                select p1.product_name || '与' || p2.product_name || '的' ||
                       v.attr_value_name
                  into v_infoname
                  from product_relation r,
                       product          p1,
                       product          p2,
                       attr_value       v
                 where v.attr_id = 7691
                   and v.attr_value = r.relation_type_cd
                   and r.product_rel_id = v_oldprodrelaId
                   and r.product_a_id = p1.product_id
                   and r.product_z_id = p2.product_id;
                v_remark := '1.0角色上适用套餐,导入"' || v_infoname ||
                            '"的可选包组合产品约束表';
                insert into CRM1_CFG_SYNC
                  (ID,
                   TABLE_NAME,
                   OBJ_ID,
                   OBJ_TYPE,
                   SYNC_METHO,
                   SYNC_DATE,
                   SYNC_COUNT,
                   REMARK)
                values
                  (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                   'OFFER_REL_RESTRICT_PROD',
                   v_oldprodrelaId2,
                   'PRODUCT_REL_ID',
                   'p_roleInProdRelRestrictOffer',
                   SYSDATE,
                   v_orrpcount,
                   v_remark);
              end if;
              v_oldprodrelaId2 := PreferOfferRelaOffer.product_rel_id;
              v_orrpcount      := 0;
            end if;
            select count(*)
              into v_cnt
              from OFFER_REL_RESTRICT_PROD orrp
             where orrp.prod_offer_rela_id = v_prodofferrelaid
               and orrp.product_rel_id =
                   PreferOfferRelaOffer.Product_Rel_Id
               and orrp.offer_prod_rela_id =
                   PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id
               and orrp.conf_type = '10';
            if v_cnt = 0 then
              insert into OFFER_REL_RESTRICT_PROD
                (OFFER_REL_RESTRICT_PROD_ID,
                 OFFER_PROD_RELA_ID,
                 PROD_OFFER_RELA_ID,
                 PRODUCT_REL_ID,
                 RULE_TYPE,
                 CREATE_DATE,
                 AREA_ID,
                 REGION_CD,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_STAFF,
                 UPDATE_DATE,
                 UPDATE_STAFF,
                 CONF_TYPE)
              values
                (SEQ_OFFER_REL_RESTRICT_PROD_ID.Nextval,
                 PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id,
                 v_prodofferrelaid,
                 PreferOfferRelaOffer.Product_Rel_Id,
                 '10',
                 sysdate,
                 10,----区域
                 null,
                 '1000',
                 sysdate,
                 49822,
                 sysdate,
                 49822,
                 '10');
              v_orrpcount    := v_orrpcount + 1;
              v_allorrpcount := v_allorrpcount + 1;
            end if;
          end if;
        end if;
      END LOOP;
      --记录其它角色上的可选包可选关系日志
      if v_porcount2 > 0 then
        v_remark := '1.0角色上适用套餐,导入' ||
                    PreferOfferRelaOffer.Rela_Prod_Offer_Name ||
                    '建立与原角色包上适用套餐的可选包的可选关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           PreferOfferRelaOffer.Rela_Prod_Offer_Id,
           'OFFER_A_ID',
           'p_roleInProdRelRestrictOffer',
           SYSDATE,
           v_porcount2,
           v_remark);
      end if;
    END LOOP;
    if v_oldprodrelaId > 0 and v_count > 0 then
      select p1.product_name || '与' || p2.product_name || '的' ||
             v.attr_value_name
        into v_infoname
        from product_relation r, product p1, product p2, attr_value v
       where v.attr_id = 7691
         and v.attr_value = r.relation_type_cd
         and r.product_rel_id = v_oldprodrelaId
         and r.product_a_id = p1.product_id
         and r.product_z_id = p2.product_id;
      v_remark := '1.0角色上适用套餐,导入"' || v_infoname || '"的产品关联销售品约束表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_REL_RESTRICT_OFFER',
         v_oldprodrelaId,
         'PRODUCT_REL_ID',
         'p_roleInProdRelRestrictOffer',
         SYSDATE,
         v_count,
         v_remark);
    end if;
    if v_oallcount > 0 then
      v_remark := '1.0角色上适用套餐,导入关联OBJ_REL_CFG数据OBJ_ID=0 AND CFG_CLASS_ID=64855';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'OBJ_REL_CFG',
         64855,
         'CFG_CLASS_ID',
         'p_roleInProdRelRestrictOffer',
         SYSDATE,
         v_oallcount,
         v_remark);
    end if;
    if v_oldprodrelaId2 > 0 and v_orrpcount > 0 then
      select p1.product_name || '与' || p2.product_name || '的' ||
             v.attr_value_name
        into v_infoname
        from product_relation r, product p1, product p2, attr_value v
       where v.attr_id = 7691
         and v.attr_value = r.relation_type_cd
         and r.product_rel_id = v_oldprodrelaId
         and r.product_a_id = p1.product_id
         and r.product_z_id = p2.product_id;
      v_remark := '1.0角色上适用套餐,导入"' || v_infoname || '"的可选包组合产品约束表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'OFFER_REL_RESTRICT_PROD',
         v_oldprodrelaId2,
         'PRODUCT_REL_ID',
         'p_roleInProdRelRestrictOffer',
         SYSDATE,
         v_orrpcount,
         v_remark);
    end if;
    str_msg := '导入PROD_REL_RESTRICT_OFFER"' || to_char(v_pallcount) ||
               '"条数据;导入OBJ_REL_CFG"' || to_char(v_oallcount) ||
               '"条数据;导入PROD_OFFER_REL"' || to_char(v_allporcount) ||
               '"条数据;导入OFFER_REL_RESTRICT_PROD"' || to_char(v_allorrpcount) ||
               '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_roleInProdRelRestrictOffer:' || sqlerrm;
  end;

  PROCEDURE p_roleInOfferProdRestRelaOffer(str_msg out VARCHAR2) is
    v_cnt                     number; --查询数
    v_remark                  varchar2(2000); --备注
    v_oldofferprodrelaid      number; --旧的销售品产品关联ID
    v_oprrocount              number; --插入产品实例关联销售品约束数
    v_alloprrocount           number; --插入产品实例关联销售品约束总数据
    v_oprcount                number; --插入销售品关联约束数
    v_alloprcount             number; --插入销售品关联约束总数据
    v_prodofferrelaid         number; --可选关系关联Id
    v_oldkxbofferprodrelaid   number; --旧的可选群组类销售品与产品的关联关系Id
    v_oldkxbofferprodrelaname varchar2(200); --旧的可选群组类销售品与产品的关联名称
    v_porcount                number; --插入的可选包销售品约束数
    v_allporcount             number; --插入的可选包销售品约束总数
    v_infoname                varchar2(200); --名称
  begin
    v_alloprrocount         := 0;
    v_alloprcount           := 0;
    v_allporcount           := 0;
    v_oldofferprodrelaid    := 0;
    v_prodofferrelaid       := 0;
    v_oldkxbofferprodrelaid := 0;
    /*查询1.0组合类在2.0落地为可选群组类销售品.
      1.角色包上的套餐落地为套餐销售品的数据。根据角色查询
      2.合并上原组合类角色包上适用销售品在1.0落为基础销售品的数据。也根据角色查询
    */
    FOR PreferOfferRelaOffer IN (select po.prod_offer_id        prod_offer_id,
                                        po.prod_offer_name      prod_offer_name,
                                        opr.offer_prod_rela_id  offer_prod_rela_id,
                                        p.product_id            product_id,
                                        p.product_name          product_name,
                                        b.rela_id               rela_id,
                                        b.name                  name,
                                        oprr.role_cd            role_cd,
                                        oprr.role_name          role_name,
                                        f.prod_offer_id         rela_prod_offer_id,
                                        f.prod_offer_name       rela_prod_offer_name,
                                        opr2.offer_prod_rela_id rela_offer_prod_rela_id
                                   from prefer_price_spec@lk_crmv1           pps,
                                        mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                                        prod_offer                           po,
                                        offer_prod_rel                       opr,
                                        Offer_Prod_Rel_Role                  oprr,
                                        product                              p,
                                        prod_map_zhengcl                     pmz,
                                        PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 a,
                                        PREFER_MDSE_SPEC_RELA@lk_crmv1       b,
                                        PM_SPECIAL_MDSE_SPEC@lk_crmv1        c,
                                        mdse_spec@lk_crmv1                   d,
                                        mdse_ys_lisy_new                     e, ---取新的规格映射表（modify by lisy）
                                        prod_offer                           f,
                                        offer_prod_rel                       opr2
                                  where pps.prefer_spec_id = myx.id_v1
                                    and myx.id_v2 = po.prod_offer_id
                                    and po.offer_type = '12'
                                    and po.offer_sub_type = 'T05'
                                    and opr.prod_offer_id = po.prod_offer_id
                                    and opr.rule_type != '13'
                                    and opr.product_id = p.product_id
                                    and oprr.prod_offer_id =
                                        po.prod_offer_id
                                    and oprr.role_cd = opr.role_cd
                                    and oprr.role_name = b.name --增加1.0与2.0的角色包一致
                                    and b.prefer_spec_id =
                                        pps.Prefer_Spec_Id
                                    and a.CFG_AREA_ID='9'----区域
                                    AND a.RELA_MDSE_ID = b.rela_id
                                    and b.rela_id = c.role_id
                                    and c.mdse_spec_id = d.mdse_spec_id
                                    and pmz.product_id = p.product_id
                                    and d.prod_spec_id = pmz.prod_spec_id --1.0产品规格
                                    and a.price_id = e.id_v1
                                    and e.id_v2 = f.prod_offer_id
                                    and f.offer_type = '11'
                                    and f.status_cd<>'1100'
                                    and opr2.prod_offer_id = f.prod_offer_id
                                    and opr2.product_id = p.product_id
                                    and opr2.rule_type != '13'
                                 union
                                 select po.prod_offer_id        prod_offer_id,
                                        po.prod_offer_name      prod_offer_name,
                                        opr.offer_prod_rela_id  offer_prod_rela_id,
                                        p.product_id            product_id,
                                        p.product_name          product_name,
                                        b.rela_id               rela_id,
                                        b.name                  name,
                                        oprr.role_cd            role_cd,
                                        oprr.role_name          role_name,
                                        f.prod_offer_id         rela_prod_offer_id,
                                        f.prod_offer_name       rela_prod_offer_name,
                                        opr2.offer_prod_rela_id rela_offer_prod_rela_id
                                   from prefer_price_spec@lk_crmv1     pps,
                                        mdse_ys_lisy_new               myx, ---取新的规格映射表（modify by lisy）
                                        prod_offer                     po,
                                        offer_prod_rel                 opr,
                                        Offer_Prod_Rel_Role            oprr,
                                        product                        p,
                                        prod_map_zhengcl               pmz,
                                        PREFER_MDSE_SPEC_RELA@lk_crmv1 b,
                                        PM_SPECIAL_MDSE_SPEC@lk_crmv1  c,
                                        mdse_spec@lk_crmv1             d,
                                        mdse_ys_lisy_new               e, ---取新的规格映射表（modify by lisy）
                                        prod_offer                     f,
                                        offer_prod_rel                 opr2
                                  where pps.prefer_spec_id = myx.id_v1
                                    and myx.id_v2 = po.prod_offer_id
                                    and po.offer_type = '12'
                                    and po.offer_sub_type = 'T05'
                                    and opr.prod_offer_id = po.prod_offer_id
                                    and opr.rule_type != '13'
                                    and opr.product_id = p.product_id
                                    and oprr.prod_offer_id =
                                        po.prod_offer_id
                                    and oprr.role_cd = opr.role_cd
                                    and oprr.role_name = b.name --增加1.0与2.0的角色包一致
                                    and b.prefer_spec_id =
                                        pps.Prefer_Spec_Id
                                    and b.rela_id = c.role_id
                                    and c.mdse_spec_id = d.mdse_spec_id
                                    and pmz.product_id = p.product_id
                                    and d.prod_spec_id = pmz.prod_spec_id --1.0产品规格
                                    and d.mdse_spec_id = e.id_v1
                                    and e.id_v2 = f.prod_offer_id
                                    and f.offer_type = '10'
                                    and f.offer_sub_type = 'T01'
                                    and f.status_cd<>'1100'
                                    and opr2.prod_offer_id = f.prod_offer_id
                                    and opr2.product_id = p.product_id
                                    and opr2.rule_type != '13'
                                  order by prod_offer_id,
                                           product_id,
                                           offer_prod_rela_id,
                                           rela_prod_offer_id) LOOP
      --导入数据日志记录
      if v_oldofferprodrelaid = 0 or
         (v_oldofferprodrelaid > 0 and
         v_oldofferprodrelaid != PreferOfferRelaOffer.offer_prod_rela_id) then
        if v_oldofferprodrelaid > 0 and v_oprrocount > 0 then
          select o.prod_offer_name || ',' || p.product_name
            into v_infoname
            from offer_prod_rel r, prod_offer o, product p
           where r.offer_prod_rela_id = v_oldofferprodrelaid
             and r.prod_offer_id = o.prod_offer_id
             and r.product_id = p.product_id;
          v_remark := '1.0角色上适用套餐,导入' || v_infoname || '产品实例关联的销售品约束表';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'OFFER_PROD_RESTRICT_RELA_OFFER',
             v_oldofferprodrelaid,
             'OFFER_PROD_RELA_ID',
             'p_roleInOfferProdRestRelaOffer',
             SYSDATE,
             v_oprrocount,
             v_remark);
        end if;
        v_oldofferprodrelaid := PreferOfferRelaOffer.offer_prod_rela_id;
        v_oprrocount         := 0;
      end if;
      --是否2.0已经有配置销售品产品关系上产品实例关联销售品约束.没配才插入数据
      select count(*)
        into v_cnt
        from Offer_Prod_Restrict_Rela_Offer
       WHERE OFFER_PROD_RELA_ID = PreferOfferRelaOffer.offer_prod_rela_id
         and rela_offer_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id;
      if v_cnt = 0 then
        insert into OFFER_PROD_RESTRICT_RELA_OFFER
          (RESTRICT_ID,
           OFFER_PROD_RELA_ID,
           RESTRICT_TYPE,
           RELA_OFFER_ID,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF)
        values
          (SEQ_OPR_RELA_OFFER_ID.Nextval,
           PreferOfferRelaOffer.offer_prod_rela_id,
           '10',
           PreferOfferRelaOffer.Rela_Prod_Offer_Id,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           '9',---区域
           null,
           49822,
           49822);
        v_alloprrocount := v_alloprrocount + 1;
        v_oprrocount    := v_oprrocount + 1;
      end if;
      /*查询角色包上的适用套餐，落地为可选包的数据。要跟以上2.0套餐销售品以及基础销售品都要建立可选关系
        如果在1.0中该适用套餐只适用于该角色包，要另外再加上“可选包销售品约束”
      */
      v_oprcount := 0;
      FOR KxbProdOffer IN (select pmrsr.rela_mdse_id,
                                  pmrsr.price_id,
                                  po.prod_offer_id,
                                  po.prod_offer_name
                             from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pmrsr,
                                  mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                                  prod_offer                           po
                            where pmrsr.CFG_AREA_ID ='9'---区域
                              and pmrsr.rela_mdse_id =
                                  PreferOfferRelaOffer.Rela_Id --1.0的角色包
                              and pmrsr.price_id = myx.id_v1
                              and myx.id_v2 = po.prod_offer_id
                              and po.offer_type = '12'
                              and po.offer_sub_type = 'T04') LOOP
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
           and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          select SEQ_PROD_OFFER_REL_ID.nextval
            into v_prodofferrelaid
            from dual;
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (v_prodofferrelaid,
             PreferOfferRelaOffer.Rela_Prod_Offer_Id,
             KxbProdOffer.Prod_Offer_Id,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             '9',----区域
             null,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_oprcount    := v_oprcount + 1;
          v_alloprcount := v_alloprcount + 1;
        elsif v_cnt = 1 then
          select por.prod_offer_rela_id
            into v_prodofferrelaid
            from prod_offer_rel por
           where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
             and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
             and por.relation_type_cd = '100000';
        else
          v_prodofferrelaid := 0;
        end if;
        if v_prodofferrelaid > 0 then
          --判断可选包是否只能在角色上受理
          select count(*)
            into v_cnt
            from prefer_mdse_price_spec_rela@lk_crmv1
           where price_id = KxbProdOffer.Prod_Offer_Id
             and mdse_spec_id > 0
             and rela_mdse_id = -1
             and state = '70A'
             and cfg_area_id='9';----区域
          if v_cnt = 0 then
            --角色可选包与产品关联关系 作为可选包销售品约束的日志记录
            if v_oldkxbofferprodrelaid = 0 or
               (v_oldkxbofferprodrelaid > 0 and
               v_oldkxbofferprodrelaid !=
               PreferOfferRelaOffer.Offer_Prod_Rela_Id) then
              if v_oldkxbofferprodrelaid > 0 and v_porcount > 0 then
                v_remark := '1.0角色上适用套餐,导入作为Z端"' ||
                            v_oldkxbofferprodrelaname || '"的可选包销售品约束';
                insert into CRM1_CFG_SYNC
                  (ID,
                   TABLE_NAME,
                   OBJ_ID,
                   OBJ_TYPE,
                   SYNC_METHO,
                   SYNC_DATE,
                   SYNC_COUNT,
                   REMARK)
                values
                  (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                   'PROD_OFFER_REL_RESTRICT',
                   v_oldkxbofferprodrelaid,
                   'OFFER_PROD_REL_ID_Z',
                   'p_roleInOfferProdRestRelaOffer',
                   SYSDATE,
                   v_porcount,
                   v_remark);
              end if;
              v_oldkxbofferprodrelaid   := PreferOfferRelaOffer.Offer_Prod_Rela_Id;
              v_oldkxbofferprodrelaname := PreferOfferRelaOffer.prod_offer_name || '关联' ||
                                           PreferOfferRelaOffer.Product_Name;
              v_porcount                := 0;
            end if;
            select count(*)
              into v_cnt
              from PROD_OFFER_REL_RESTRICT porr
             where porr.prod_offer_rel_id = v_prodofferrelaid
               and porr.offer_prod_rel_id_a =
                   PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id
               and porr.offer_prod_rel_id_z =
                   PreferOfferRelaOffer.Offer_Prod_Rela_Id
               and porr.rule_type = '10';
            if v_cnt = 0 then
              insert into PROD_OFFER_REL_RESTRICT
                (PROD_OFFER_REL_RESTRICT_ID,
                 PROD_OFFER_REL_ID,
                 OFFER_PROD_REL_ID_A,
                 OFFER_PROD_REL_ID_Z,
                 CREATE_DATE,
                 AREA_ID,
                 REGION_CD,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_STAFF,
                 UPDATE_DATE,
                 UPDATE_STAFF,
                 RULE_TYPE)
              values
                (SEQ_PROD_OFFER_REL_RESTRICT_ID.Nextval,
                 v_prodofferrelaid,
                 PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id,
                 PreferOfferRelaOffer.Offer_Prod_Rela_Id,
                 sysdate,
                 '9',-----区域
                 null,
                 '1000',
                 sysdate,
                 49822,
                 sysdate,
                 49822,
                 '10');
              v_porcount    := v_porcount + 1;
              v_allporcount := v_allporcount + 1;
            end if;
          end if;
        end if;
      END LOOP;
      --记录可选包可选关系日志
      if v_oprcount > 0 then
        v_remark := '1.0角色上适用套餐,导入' ||
                    PreferOfferRelaOffer.Rela_Prod_Offer_Name ||
                    '建立与原角色包上适用套餐的可选包的可选关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           PreferOfferRelaOffer.Rela_Prod_Offer_Id,
           'OFFER_A_ID',
           'p_roleInOfferProdRestRelaOffer',
           SYSDATE,
           v_oprcount,
           v_remark);
      end if;
    END LOOP;
    if v_oldofferprodrelaid > 0 and v_oprrocount > 0 then
      select o.prod_offer_name || ',' || p.product_name
        into v_infoname
        from offer_prod_rel r, prod_offer o, product p
       where r.offer_prod_rela_id = v_oldofferprodrelaid
         and r.prod_offer_id = o.prod_offer_id
         and r.product_id = p.product_id;
      v_remark := '1.0角色上适用套餐,导入' || v_infoname || '产品实例关联的销售品约束表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'OFFER_PROD_RESTRICT_RELA_OFFER',
         v_oldofferprodrelaid,
         'OFFER_PROD_RELA_ID',
         'p_roleInOfferProdRestRelaOffer',
         SYSDATE,
         v_oprrocount,
         v_remark);
    end if;
    if v_oldkxbofferprodrelaid > 0 and v_porcount > 0 then
      v_remark := '1.0角色上适用套餐,导入作为Z端"' || v_oldkxbofferprodrelaname ||
                  '"的可选包销售品约束';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL_RESTRICT',
         v_oldkxbofferprodrelaid,
         'OFFER_PROD_REL_ID_Z',
         'p_roleInOfferProdRestRelaOffer',
         SYSDATE,
         v_porcount,
         v_remark);
    end if;
    str_msg := '导入OFFER_PROD_RESTRICT_RELA_OFFER表"' ||
               to_char(v_alloprrocount) || '"条数据;导入PROD_OFFER_REL表"' ||
               to_char(v_alloprcount) || '"条数据;导入PROD_OFFER_REL_RESTRICT表"' ||
               to_char(v_allporcount) || '"条数据;';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_roleInOfferProdRestRelaOffer:' || sqlerrm;
  end;

  PROCEDURE p_productRelationIn(str_msg out VARCHAR2) is
    v_cnt           number; --查询数
    v_pcount        number; --插入产品关联数
    v_ocount        number; --插入销售品约束数
    v_ccount        number; --插入关联约束数
    v_remark        varchar2(2000); --备注
    v_seqid         number;
    v_oldproductId  number; --旧的产品ID
    v_infoname      varchar2(200); --备注名称
    v_prodrelaId    number; --产品关联ID
    v_oldprodrelaId number; --旧的产品关联ID
    v_restrictId    number; --产品关联销售品约束Id
    v_oldrestrictId number; --旧的产品关联销售品约束Id
    v_allPcount     number; --产品关联总数据
    v_allOcount     number; --产品关联销售品约束总数据
    v_allCcount     number; --obj_rela_cfg总数据
  begin
    v_allPcount     := 0;
    v_allOcount     := 0;
    v_allCcount     := 0;
    v_oldprodrelaId := 0;
    v_oldproductId  := 0;
    v_oldrestrictId := 0;
    --查1.0销售品关联，落地到2.0后的产品应该有的关联数据,无线宽带数据卡的，对应到2.0的产品不是移动语音，而是无线宽带数据卡
    FOR ProdRela IN (select p1.prod_spec_id      cmr1_y_prod_spec_id,
                            p1.name              cmr1_y_prod_name,
                            m1.mdse_spec_id      crm1_y_mdse_spec_id,
                            m1.name              crm1_y_mdse_name,
                            p2.prod_spec_id      crm1_m_prod_spec_id,
                            p2.name              crm1_m_prod_name,
                            m2.mdse_spec_id      crm1_m_mdse_spec_id,
                            m2.name              crm1_m_mdse_name,
                            a.rela_type          crm1_rela_type,
                            m.old_rela_type_name crm1_rela_type_name,
                            --2.0源跟目标与1.0的源目标是相反的
                            pm2.product_id          crm2_y_product_id,
                            pm2.product_name        crm2_y_product_name,
                            mp2.id_v2               crm2_y_mdse_id,
                            mp2.name_v2             crm2_y_mdse_name,
                            opr2.offer_prod_rela_id crm2_y_offer_prod_rela_id,
                            pm1.product_id          crm2_m_product_id,
                            pm1.product_name        crm2_m_product_name,
                            mp1.id_v2               crm2_m_mdse_id,
                            mp1.name_v2             crm2_m_mdse_name,
                            opr1.offer_prod_rela_id crm2_m_offer_prod_rela_id,
                            m.new_rela_type         crm2_rela_type,
                            m.new_rela_type_name    crm2_rela_type_name,
                            a.cfg_area_id           crm1_cfg_area_id
                       from mdse_spec_rela@lk_crmv1 a,
                            mdse_spec@lk_crmv1      m1,
                            mdse_spec@lk_crmv1      m2,
                            crm2_mdse_rela_type_map m,
                            prod_spec@lk_crmv1      p1,
                            prod_spec@lk_crmv1      p2,
                            prod_map_zhengcl        pm1,
                            prod_map_zhengcl        pm2,
                            mdse_ys_lisy_new        mp1, ---取新的规格映射表（modify by lisy）
                            mdse_ys_lisy_new        mp2, ---取新的规格映射表（modify by lisy）
                            prod_offer              o1,
                            prod_offer              o2,
                            offer_prod_rel          opr1,
                            offer_prod_rel          opr2
                      where a.mdse_spec_ida = m1.mdse_spec_id
                        and a.mdse_spec_idb = m2.mdse_spec_id
                        and m1.prod_spec_id = p1.prod_spec_id
                        and m2.prod_spec_id = p2.prod_spec_id
                        and m1.type != '102'
                        and m2.type != '102'
                        and m1.state != '70X'
                        and m2.state != '70X'
                        and m1.mdse_spec_id not in
                            (select mdse_spec_id
                               from mdse_node@lk_crmv1
                              where catalog_id = 1)
                        and a.rela_type = m.old_rela_type
                        and m.new_rela_type != '无'
                        and m.sync != 'N'
                        and m.new_rela_type <> '109920' ----主副关系的不处理（特殊配置，以目前系统配置为准）add by lisy
                        and a.cfg_area_id in (1, 2) ---lisy说明：取省级跟福州本地的并集，个人认为有误，若2有配置数据，应只取2,2无数据才取1
                        and a.state = '70A'
                        and pm1.prod_spec_id = p1.prod_spec_id
                        and pm2.prod_spec_id = p2.prod_spec_id
                        and mp1.id_v1 = m1.mdse_spec_id
                        and mp1.id_v2 = o1.prod_offer_id
                        and mp2.id_v1 = m2.mdse_spec_id
                        and mp2.id_v2 = o2.prod_offer_id
                        and o1.offer_type in ('10', '11')
                        and o1.status_cd = '1000'
                        and o2.offer_type in ('10', '11')
                        and o2.status_cd = '1000'
                        and opr1.product_id = pm1.product_id
                        and opr1.prod_offer_id = o1.prod_offer_id
                        and opr1.status_cd = '1000'
                        and opr2.product_id = pm2.product_id
                        and opr2.prod_offer_id = o2.prod_offer_id
                        and opr2.status_cd = '1000'
                        and opr1.rule_type in ('10', '11', '12')
                        and opr2.rule_type in ('10', '11', '12')
                     union
                     select pm1.prod_spec_id     cmr1_y_prod_spec_id,
                            pm1.prod_spec_name   cmr1_y_prod_name,
                            m1.mdse_spec_id      crm1_y_mdse_spec_id,
                            m1.name              crm1_y_mdse_name,
                            pm2.prod_spec_id     crm1_m_prod_spec_id,
                            pm2.prod_spec_name   crm1_m_prod_name,
                            m2.mdse_spec_id      crm1_m_mdse_spec_id,
                            m2.name              crm1_m_mdse_name,
                            a.rela_type          crm1_rela_type,
                            m.old_rela_type_name crm1_rela_type_name,
                            --2.0源跟目标与1.0的源目标是相反的
                            pm2.product_id          crm2_y_product_id,
                            pm2.product_name        crm2_y_product_name,
                            mp2.id_v2               crm2_y_mdse_id,
                            mp2.name_v2             crm2_y_mdse_name,
                            opr2.offer_prod_rela_id crm2_y_offer_prod_rela_id,
                            pm1.product_id          crm2_m_product_id,
                            pm1.product_name        crm2_m_product_name,
                            mp1.id_v2               crm2_m_mdse_id,
                            mp1.name_v2             crm2_m_mdse_name,
                            opr1.offer_prod_rela_id crm2_m_offer_prod_rela_id,
                            m.new_rela_type         crm2_rela_type,
                            m.new_rela_type_name    crm2_rela_type_name,
                            a.cfg_area_id           crm1_cfg_area_id
                       from mdse_spec_rela@lk_crmv1 a,
                            mdse_spec@lk_crmv1      m1,
                            mdse_spec@lk_crmv1      m2,
                            crm2_mdse_rela_type_map m,
                            prod_map_zhengcl        pm1,
                            prod_map_zhengcl        pm2,
                            mdse_ys_lisy_new        mp1, ---取新的规格映射表（modify by lisy）
                            mdse_ys_lisy_new        mp2, ---取新的规格映射表（modify by lisy）
                            prod_offer              o1,
                            prod_offer              o2,
                            offer_prod_rel          opr1,
                            offer_prod_rel          opr2
                      where a.mdse_spec_ida = m1.mdse_spec_id
                        and a.mdse_spec_idb = m2.mdse_spec_id
                        and ((m1.mdse_spec_id = 610317985 and
                            pm1.prod_spec_id = m1.mdse_spec_id and
                            pm2.prod_spec_id = m2.prod_spec_id) or
                            (m2.mdse_spec_id = 610317985 and
                            pm2.prod_spec_id = m2.mdse_spec_id and
                            pm1.prod_spec_id = m1.prod_spec_id))
                        and a.rela_type = m.old_rela_type
                        and m.new_rela_type != '无'
                        and m.sync != 'N'
                        and m.new_rela_type <> '109920' ----主副关系的不处理（特殊配置，以目前系统配置为准）add by lisy
                        and a.cfg_area_id in (1, 2)
                        and a.state = '70A'
                        and mp1.id_v1 = m1.mdse_spec_id
                        and mp1.id_v2 = o1.prod_offer_id
                        and mp2.id_v1 = m2.mdse_spec_id
                        and mp2.id_v2 = o2.prod_offer_id
                        and o1.offer_type in ('10', '11')
                        and o1.status_cd = '1000'
                        and o2.offer_type in ('10', '11')
                        and o2.status_cd = '1000'
                        and opr1.product_id = pm1.product_id
                        and opr1.prod_offer_id = o1.prod_offer_id
                        and opr1.status_cd = '1000'
                        and opr2.product_id = pm2.product_id
                        and opr2.prod_offer_id = o2.prod_offer_id
                        and opr2.status_cd = '1000'
                        and opr1.rule_type in ('10', '11', '12')
                        and opr2.rule_type in ('10', '11', '12')
                      order by crm2_y_product_id,
                               crm2_m_product_id,
                               crm2_rela_type,
                               crm1_m_mdse_spec_id,
                               crm1_y_mdse_spec_id) LOOP
      ------------------------步骤1 插入产品关联数据。------------------------------------------------
      --产品关联导入数据日志记录
      if v_oldproductId = 0 or
         (v_oldproductId > 0 and
         v_oldproductId != ProdRela.Crm2_y_Product_Id) then
        if v_oldproductId > 0 and v_pcount > 0 then
          select p.product_name
            into v_infoname
            from product p
           where p.product_id = v_oldproductId;
          v_remark := '1.0销售品关联,导入源产品为"' || v_infoname || '"的产品关联表';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PRODUCT_RELATION',
             v_oldproductId,
             'PRODUCT_A_ID',
             'p_productRelationIn',
             SYSDATE,
             v_pcount,
             v_remark);
        end if;
        v_oldproductId := ProdRela.Crm2_y_Product_Id;
        v_pcount       := 0;
      end if;
      --判断是否有产品关系数据
      select count(*)
        into v_cnt
        from product_relation r
       where r.product_a_id = ProdRela.Crm2_y_Product_Id
         and r.product_z_id = ProdRela.Crm2_m_Product_Id
         and r.relation_type_cd = ProdRela.Crm2_Rela_Type
         and r.status_cd = '1000';
      if v_cnt = 0 then
        select SEQ_PRODUCT_REL_ID.nextval into v_seqid from dual;
        v_prodrelaId := v_seqid;
        --插入产品关联数据
        insert into PRODUCT_RELATION
          (PRODUCT_REL_ID,
           RELATION_TYPE_CD,
           PRODUCT_A_ID,
           PRODUCT_Z_ID,
           ROLE_CD,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           HOT_SPOT_NO,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           MIN_COUNT,
           MAX_COUNT,
           SYNC_CUST,
           EXIST_TYPE,
           REL_GROUP_ALIAS)
        values
          (v_prodrelaId,
           ProdRela.Crm2_Rela_Type,
           ProdRela.Crm2_y_Product_Id,
           ProdRela.Crm2_m_Product_Id,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           1,
           1,
           49822,
           49822,
           null,
           null,
           null,
           null,
           null);
        v_pcount    := v_pcount + 1;
        v_allPcount := v_allPcount + 1;
      elsif v_cnt = 1 then
        select r.product_rel_id
          into v_prodrelaId
          from product_relation r
         where r.product_a_id = ProdRela.Crm2_y_Product_Id
           and r.product_z_id = ProdRela.Crm2_m_Product_Id
           and r.relation_type_cd = ProdRela.Crm2_Rela_Type
           and r.status_cd = '1000';
      else
        v_prodrelaId := 0;
      end if;
      ------------------------步骤2 插入产品关联销售品数据。------------------------------------------------
      if v_prodrelaId != 0 then
        --产品关联销售品导入数据日志记录
       -- if v_oldprodrelaId = 0 or
         --  (v_oldprodrelaId > 0 and v_oldprodrelaId != v_prodrelaId) then --modify by zhengxf
          if v_oldprodrelaId > 0 and v_ocount > 0 then
            select p1.product_name || ',' || p2.product_name || ',' ||
                   v.attr_value_name
              into v_infoname
              from product_relation r, product p1, product p2, attr_value v
             where v.attr_id = 7691
               and v.attr_value = r.relation_type_cd
               and r.product_rel_id = v_oldprodrelaId
               and r.product_a_id = p1.product_id
               and r.product_z_id = p2.product_id;
            v_remark := '1.0销售品关联,导入"' || v_infoname || '"产品关联销售品约束表';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'PROD_REL_RESTRICT_OFFER',
               v_oldprodrelaId,
               'PRODUCT_REL_ID',
               'p_productRelationIn',
               SYSDATE,
               v_ocount,
               v_remark);
          end if;
          v_oldprodrelaId := v_prodrelaId;
          v_ocount        := 0;
          --是否2.0已经有配置产品关系上限制销售品约束.没配才插入数据
          select count(*)
            into v_cnt
            from Prod_Rel_Restrict_Offer
           where product_rel_id = v_prodrelaId
             and rela_offer_id = ProdRela.crm2_m_mdse_id;
          if v_cnt = 0 then
            --插入PROD_REL_RESTRICT_OFFER
            select SEQ_PROD_REL_RESTRICT_OFFER_ID.nextval
              into v_seqid
              from dual;
            insert into PROD_REL_RESTRICT_OFFER
              (RESTRICT_ID,
               PRODUCT_REL_ID,
               RESTRICT_TYPE,
               RELA_OFFER_ID,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF)
            values
              (v_seqid,
               v_prodrelaId,
               '10',
               ProdRela.crm2_m_mdse_id,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               1,
               11,
               49822,
               49822);
            v_restrictId := v_seqid;
            v_allOcount  := v_allOcount + 1;
            v_ocount     := v_ocount + 1;
          elsif v_cnt = 1 then
            select RESTRICT_ID
              into v_restrictId
              from Prod_Rel_Restrict_Offer
             where product_rel_id = v_prodrelaId
               and rela_offer_id = ProdRela.crm2_m_mdse_id;
          else
            v_restrictId := 0;
          end if;
          ------------------------步骤3 插入关联表OBJ_REL_CFG数据。------------------------------------------------
          if v_restrictId > 0 then
            --关联表OBJ_REL_CFG导入数据日志记录
            if v_oldrestrictId = 0 or
               (v_oldrestrictId > 0 and v_oldrestrictId != v_restrictId) then
              if v_oldrestrictId > 0 and v_ccount > 0 then
                select p1.product_name || '"与"' || p2.product_name || '"的' ||
                       v.attr_value_name || '上,关联销售品"' ||
                       po.prod_offer_name
                  into v_infoname
                  from PROD_REL_RESTRICT_OFFER prro,
                       product_relation        pr,
                       product                 p1,
                       product                 p2,
                       prod_offer              po,
                       attr_value              v
                 where v.attr_id = 7691
                   and v.attr_value = pr.relation_type_cd
                   and prro.product_rel_id = pr.product_rel_id
                   and prro.rela_offer_id = po.prod_offer_id
                   and pr.product_a_id = p1.product_id
                   and pr.product_z_id = p2.product_id
                   and prro.restrict_id = v_oldrestrictId;
                v_remark := '1.0销售品关联,导入"' || v_infoname ||
                            '"关联表OBJ_REL_CFG.OBJ_CLASS_ID=102 AND CFG_CLASS_ID=64855';
                insert into CRM1_CFG_SYNC
                  (ID,
                   TABLE_NAME,
                   OBJ_ID,
                   OBJ_TYPE,
                   SYNC_METHO,
                   SYNC_DATE,
                   SYNC_COUNT,
                   REMARK)
                values
                  (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                   'OBJ_REL_CFG',
                   v_oldrestrictId,
                   'CFG_ID',
                   'p_productRelationIn',
                   SYSDATE,
                   v_ccount,
                   v_remark);
              end if;
              v_oldrestrictId := v_restrictId;
              v_ccount        := 0;
              --关联表OBJ_REL_CFG也要插入
              --先查询是否有直接配置在产品关系上的obj_rel_Cfg,有的话，以下可以都不用导入了
              select count(*)
                into v_cnt
                from OBJ_REL_CFG
               where (OBJ_CLASS_ID is null or OBJ_CLASS_ID = 0)
                 and OBJ_ID = 0
                 and CFG_CLASS_ID = 64855
                 and CFG_ID = v_restrictId;
              if v_cnt = 0 then
                select count(*)
                  into v_cnt
                  from OBJ_REL_CFG
                 where OBJ_CLASS_ID = '102'
                   and OBJ_ID = ProdRela.crm2_y_offer_prod_rela_id
                   and CFG_CLASS_ID = 64855
                   and CFG_ID = v_restrictId;
                --插入与2.0销售品直接关联的数据
                if v_cnt = 0 then
                  insert into OBJ_REL_CFG
                    (OBJ_REL_CFG_ID,
                     OBJ_CLASS_ID,
                     OBJ_ID,
                     CFG_CLASS_ID,
                     CFG_ID,
                     AREA_ID,
                     REGION_CD,
                     CREATE_DATE,
                     CREATE_STAFF,
                     STATUS_CD,
                     STATUS_DATE,
                     UPDATE_DATE,
                     UPDATE_STAFF)
                  values
                    (seq_obj_rel_cfg_id.nextval,
                     102,
                     ProdRela.crm2_y_offer_prod_rela_id,
                     64855,
                     v_restrictId,
                     1,
                     11,
                     sysdate,
                     49822,
                     '1000',
                     sysdate,
                     sysdate,
                     49822);
                  v_allCcount := v_allCcount + 1;
                  v_ccount    := v_ccount + 1;
                end if;
                --关联插入2.0A端销售品对应套餐销售品 与 产品关联销售品的obj_rel_cfg关系
                FOR AMdsePriceRela IN (select opr.offer_prod_rela_id,
                                              o.prod_offer_id,
                                              o.prod_offer_name
                                         from mdse_spec@lk_crmv1                   s,
                                              prefer_mdse_price_spec_rela@lk_crmv1 r,
                                              price_plan@lk_crmv1                  p,
                                              mdse_ys_lisy_new                     m, ---取新的规格映射表（modify by lisy）
                                              prod_offer                           o,
                                              offer_prod_rel                       opr
                                        where s.type = '101'
                                          and s.mdse_spec_id =
                                              r.mdse_spec_id
                                          and r.price_id = p.price_id
                                          and r.state = '70A'
                                          and r.cfg_area_id in (1, 2)
                                          and s.mdse_spec_id =
                                              ProdRela.Crm1_m_Mdse_Spec_Id
                                          and m.id_v1 = p.price_id
                                          and m.id_v2 = o.prod_offer_id
                                          and o.offer_type = '11'
                                          and opr.prod_offer_id =
                                              o.prod_offer_id
                                          and opr.product_id =
                                              ProdRela.Crm2_y_Product_Id
                                          and opr.status_cd = '1000'
                                          and opr.rule_type in
                                              ('10', '11', '12')
                                       union
                                       select opr.offer_prod_rela_id,
                                              o.prod_offer_id,
                                              o.prod_offer_name
                                         from prod_offer     o,
                                              offer_prod_rel opr
                                        where o.offer_busi_type = '1'
                                          and offer_sub_type='T01' --modify by zhengxf
                                          --and 610290109 =
                                              --ProdRela.Crm1_m_Mdse_Spec_Id
                                          and opr.prod_offer_id =
                                              o.prod_offer_id
                                          and opr.product_id =
                                              ProdRela.Crm2_y_Product_Id
                                          and opr.status_cd in ('1000','1099') --modify by zhengxf 停售也需要加入
                                          and opr.rule_type in
                                              ('10', '11', '12') --如果是天翼销售品还要加e家和商务领航关联
                                       ) LOOP
                  select count(*)
                    into v_cnt
                    from OBJ_REL_CFG
                   where OBJ_CLASS_ID = '102'
                     and OBJ_ID = AMdsePriceRela.offer_prod_rela_id
                     and CFG_CLASS_ID = 64855
                     and CFG_ID = v_restrictId;
                  if v_cnt = 0 then
                    insert into OBJ_REL_CFG
                      (OBJ_REL_CFG_ID,
                       OBJ_CLASS_ID,
                       OBJ_ID,
                       CFG_CLASS_ID,
                       CFG_ID,
                       AREA_ID,
                       REGION_CD,
                       CREATE_DATE,
                       CREATE_STAFF,
                       STATUS_CD,
                       STATUS_DATE,
                       UPDATE_DATE,
                       UPDATE_STAFF)
                    values
                      (seq_obj_rel_cfg_id.nextval,
                       102,
                       AMdsePriceRela.offer_prod_rela_id,
                       64855,
                       v_restrictId,
                       1,
                       11,
                       sysdate,
                       49822,
                       '1000',
                       sysdate,
                       sysdate,
                       49822);
                    v_allCcount := v_allCcount + 1;
                    v_ccount    := v_ccount + 1;
                  end if;
                END LOOP;
              end if;
            end if;
          end if;
          ------------------------步骤4 插入产品关联套餐销售品数据。------------------------------------------------
          --除了直接对应的销售品要导入外,销售品对应的套餐销售品也要导入
          FOR MdsePriceRela IN (select o.prod_offer_id, o.prod_offer_name
                                /* s.mdse_spec_id,
                                                                                                     s.name mdse_name,
                                                                                                     p.price_id,
                                                                                                     p.name price_name*/
                                  from mdse_spec@lk_crmv1                   s,
                                       prefer_mdse_price_spec_rela@lk_crmv1 r,
                                       price_plan@lk_crmv1                  p,
                                       mdse_ys_lisy_new                     m, ----取新的规格映射表（modify by lisy）
                                       prod_offer                           o,
                                       offer_prod_rel                       opr
                                 where s.type = '101'
                                   and s.mdse_spec_id = r.mdse_spec_id
                                   and r.price_id = p.price_id
                                   and r.state = '70A'
                                   and r.cfg_area_id in (1, 2)
                                   and s.mdse_spec_id =
                                       ProdRela.Crm1_y_Mdse_Spec_Id
                                   and m.id_v1 = p.price_id
                                   and m.id_v2 = o.prod_offer_id
                                   and o.offer_type = '11'
                                   and opr.prod_offer_id = o.prod_offer_id
                                   and opr.product_id =
                                       ProdRela.Crm2_m_Product_Id
                                   and opr.status_cd = '1000'
                                   and opr.rule_type in ('10', '11', '12')
                                union
                                select o.prod_offer_id, o.prod_offer_name
                                  from prod_offer o
                                 where o.offer_busi_type = '1'
                                   and offer_sub_type='T01' --modify by zhengxf
                                   --and 610290109 =
                                       --ProdRela.Crm1_y_Mdse_Spec_Id --如果是天翼销售品还要加e家和商务领航关联
                                   and status_cd in ('1000','1099')    --modify by zhengxf
                                ) LOOP
            --是否2.0已经有配置产品关系上限制销售品约束.没配才插入数据
            select count(*)
              into v_cnt
              from Prod_Rel_Restrict_Offer
             where product_rel_id = v_prodrelaId
               and rela_offer_id = MdsePriceRela.Prod_Offer_Id;
            if v_cnt = 0 then
              --插入PROD_REL_RESTRICT_OFFER
              select SEQ_PROD_REL_RESTRICT_OFFER_ID.nextval
                into v_seqid
                from dual;
              insert into PROD_REL_RESTRICT_OFFER
                (RESTRICT_ID,
                 PRODUCT_REL_ID,
                 RESTRICT_TYPE,
                 RELA_OFFER_ID,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 AREA_ID,
                 REGION_CD,
                 UPDATE_STAFF,
                 CREATE_STAFF)
              values
                (v_seqid,
                 v_prodrelaId,
                 '10',
                 MdsePriceRela.Prod_Offer_Id,
                 '1000',
                 sysdate,
                 sysdate,
                 sysdate,
                 1,
                 11,
                 49822,
                 49822);
              v_restrictId := v_seqid;
              v_allOcount  := v_allOcount + 1;
              v_ocount     := v_ocount + 1;
            elsif v_cnt = 1 then
              select RESTRICT_ID
                into v_restrictId
                from Prod_Rel_Restrict_Offer
               where product_rel_id = v_prodrelaId
                 and rela_offer_id = MdsePriceRela.Prod_Offer_Id;
            else
              v_restrictId := 0;
            end if;
            ------------------------步骤5 插入关联表OBJ_REL_CFG数据。------------------------------------------------
            if v_restrictId > 0 then
              --关联表OBJ_REL_CFG导入数据日志记录
              if v_oldrestrictId = 0 or
                 (v_oldrestrictId > 0 and v_oldrestrictId != v_restrictId) then
                if v_oldrestrictId > 0 and v_ccount > 0 then
                  select p1.product_name || '"与"' || p2.product_name || '"的' ||
                         v.attr_value_name || '上,关联销售品"' ||
                         po.prod_offer_name
                    into v_infoname
                    from PROD_REL_RESTRICT_OFFER prro,
                         product_relation        pr,
                         product                 p1,
                         product                 p2,
                         prod_offer              po,
                         attr_value              v
                   where v.attr_id = 7691
                     and v.attr_value = pr.relation_type_cd
                     and prro.product_rel_id = pr.product_rel_id
                     and prro.rela_offer_id = po.prod_offer_id
                     and pr.product_a_id = p1.product_id
                     and pr.product_z_id = p2.product_id
                     and prro.restrict_id = v_oldrestrictId;
                  v_remark := '1.0销售品关联,导入"' || v_infoname ||
                              '"关联表OBJ_REL_CFG.OBJ_CLASS_ID=102 AND CFG_CLASS_ID=64855';
                  insert into CRM1_CFG_SYNC
                    (ID,
                     TABLE_NAME,
                     OBJ_ID,
                     OBJ_TYPE,
                     SYNC_METHO,
                     SYNC_DATE,
                     SYNC_COUNT,
                     REMARK)
                  values
                    (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                     'OBJ_REL_CFG',
                     v_oldrestrictId,
                     'CFG_ID',
                     'p_productRelationIn',
                     SYSDATE,
                     v_ccount,
                     v_remark);
                end if;
                v_oldrestrictId := v_restrictId;
                v_ccount        := 0;

                --关联表OBJ_REL_CFG也要插入
                --先查询是否有直接配置在产品关系上的obj_rel_Cfg,有的话，以下可以都不用导入了
                select count(*)
                  into v_cnt
                  from OBJ_REL_CFG
                 where (OBJ_CLASS_ID is null or OBJ_CLASS_ID = 0)
                   and OBJ_ID = 0
                   and CFG_CLASS_ID = 64855
                   and CFG_ID = v_restrictId;
                if v_cnt = 0 then
                  select count(*)
                    into v_cnt
                    from OBJ_REL_CFG
                   where OBJ_CLASS_ID = '102'
                     and OBJ_ID = ProdRela.crm2_y_offer_prod_rela_id
                     and CFG_CLASS_ID = 64855
                     and CFG_ID = v_restrictId;
                  --插入与2.0套餐销售品关联的数据
                  if v_cnt = 0 then
                    insert into OBJ_REL_CFG
                      (OBJ_REL_CFG_ID,
                       OBJ_CLASS_ID,
                       OBJ_ID,
                       CFG_CLASS_ID,
                       CFG_ID,
                       AREA_ID,
                       REGION_CD,
                       CREATE_DATE,
                       CREATE_STAFF,
                       STATUS_CD,
                       STATUS_DATE,
                       UPDATE_DATE,
                       UPDATE_STAFF)
                    values
                      (seq_obj_rel_cfg_id.nextval,
                       102,
                       ProdRela.crm2_y_offer_prod_rela_id,
                       64855,
                       v_restrictId,
                       1,
                       11,
                       sysdate,
                       49822,
                       '1000',
                       sysdate,
                       sysdate,
                       49822);
                    v_allCcount := v_allCcount + 1;
                    v_ccount    := v_ccount + 1;
                  end if;
                  --关联插入2.0A端销售品对应套餐销售品 与 产品关联销售品的obj_rel_cfg关系
                  FOR AMdsePriceRela IN (select opr.offer_prod_rela_id,
                                                o.prod_offer_id,
                                                o.prod_offer_name
                                           from mdse_spec@lk_crmv1                   s,
                                                prefer_mdse_price_spec_rela@lk_crmv1 r,
                                                price_plan@lk_crmv1                  p,
                                                mdse_ys_lisy_new                     m, ----取新的规格映射表（modify by lisy）
                                                prod_offer                           o,
                                                offer_prod_rel                       opr
                                          where s.type = '101'
                                            and s.mdse_spec_id =
                                                r.mdse_spec_id
                                            and r.price_id = p.price_id
                                            and r.state = '70A'
                                            and r.cfg_area_id in (1, 2)
                                            and s.mdse_spec_id =
                                                ProdRela.Crm1_m_Mdse_Spec_Id
                                            and m.id_v1 = p.price_id
                                            and m.id_v2 = o.prod_offer_id
                                            and o.offer_type = '11'
                                            and opr.prod_offer_id =
                                                o.prod_offer_id
                                            and opr.product_id =
                                                ProdRela.Crm2_y_Product_Id
                                            and opr.status_cd = '1000'
                                            and opr.rule_type in
                                                ('10', '11', '12')
                                         union
                                         select opr.offer_prod_rela_id,
                                                o.prod_offer_id,
                                                o.prod_offer_name
                                           from prod_offer     o,
                                                offer_prod_rel opr
                                          where o.offer_busi_type = '1'
                                            and offer_sub_type='T01' --modify by zhengxf
                                            --and 610290109 =
                                                --ProdRela.Crm1_m_Mdse_Spec_Id
                                            and opr.prod_offer_id =
                                                o.prod_offer_id
                                            and opr.product_id =
                                                ProdRela.Crm2_y_Product_Id
                                            and opr.status_cd in ('1000','1099')  --modify by zhengxf
                                            and opr.rule_type in
                                                ('10', '11', '12') --如果是天翼销售品还要加e家和商务领航关联
                                         ) LOOP
                    select count(*)
                      into v_cnt
                      from OBJ_REL_CFG
                     where OBJ_CLASS_ID = '102'
                       and OBJ_ID = AMdsePriceRela.offer_prod_rela_id
                       and CFG_CLASS_ID = 64855
                       and CFG_ID = v_restrictId;
                    --插入与2.0销售品直接关联的数据
                    if v_cnt = 0 then
                      insert into OBJ_REL_CFG
                        (OBJ_REL_CFG_ID,
                         OBJ_CLASS_ID,
                         OBJ_ID,
                         CFG_CLASS_ID,
                         CFG_ID,
                         AREA_ID,
                         REGION_CD,
                         CREATE_DATE,
                         CREATE_STAFF,
                         STATUS_CD,
                         STATUS_DATE,
                         UPDATE_DATE,
                         UPDATE_STAFF)
                      values
                        (seq_obj_rel_cfg_id.nextval,
                         102,
                         AMdsePriceRela.offer_prod_rela_id,
                         64855,
                         v_restrictId,
                         1,
                         11,
                         sysdate,
                         49822,
                         '1000',
                         sysdate,
                         sysdate,
                         49822);
                      v_allCcount := v_allCcount + 1;
                      v_ccount    := v_ccount + 1;
                    end if;
                  END LOOP;
                end if;
              end if;
            end if;
          END LOOP;
        end if;
      --end if; --modify by zhengxf
    END LOOP;
    --补充日志，以上写法会造成最后一条日志没记录
    if v_oldproductId > 0 and v_pcount > 0 then
      select p.product_name
        into v_infoname
        from product p
       where p.product_id = v_oldproductId;
      v_remark := '1.0销售品关联,导入源产品为"' || v_infoname || '"的产品关联表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PRODUCT_RELATION',
         v_oldproductId,
         'PRODUCT_A_ID',
         'p_productRelationIn',
         SYSDATE,
         v_pcount,
         v_remark);
    end if;

    if v_oldprodrelaId > 0 and v_ocount > 0 then
      select p1.product_name || ',' || p2.product_name || ',' ||
             v.attr_value_name
        into v_infoname
        from product_relation r, product p1, product p2, attr_value v
       where v.attr_id = 7691
         and v.attr_value = r.relation_type_cd
         and r.product_rel_id = v_oldprodrelaId
         and r.product_a_id = p1.product_id
         and r.product_z_id = p2.product_id;
      v_remark := '1.0销售品关联,导入"' || v_infoname || '"产品关联销售品约束表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_REL_RESTRICT_OFFER',
         v_oldprodrelaId,
         'PRODUCT_REL_ID',
         'p_productRelationIn',
         SYSDATE,
         v_ocount,
         v_remark);
    end if;

    if v_oldrestrictId > 0 and v_ccount > 0 then
      select p1.product_name || '"与"' || p2.product_name || '"的' ||
             v.attr_value_name || '上,关联销售品"' || po.prod_offer_name
        into v_infoname
        from PROD_REL_RESTRICT_OFFER prro,
             product_relation        pr,
             product                 p1,
             product                 p2,
             prod_offer              po,
             attr_value              v
       where v.attr_id = 7691
         and v.attr_value = pr.relation_type_cd
         and prro.product_rel_id = pr.product_rel_id
         and prro.rela_offer_id = po.prod_offer_id
         and pr.product_a_id = p1.product_id
         and pr.product_z_id = p2.product_id
         and prro.restrict_id = v_oldrestrictId;
      v_remark := '1.0销售品关联,导入"' || v_infoname ||
                  '"关联表OBJ_REL_CFG.OBJ_CLASS_ID=102 AND CFG_CLASS_ID=64855';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'OBJ_REL_CFG',
         v_oldrestrictId,
         'CFG_ID',
         'p_productRelationIn',
         SYSDATE,
         v_ccount,
         v_remark);
    end if;
    str_msg := '导入PRODUCT_RELATION"' || to_char(v_allPcount) ||
               '"条数据;导入PROD_REL_RESTRICT_OFFER"' || to_char(v_allOcount) ||
               '"条数据;导入OBJ_REL_CFG"' || to_char(v_allCcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_productRelationIn:' || sqlerrm;
  end;

  PROCEDURE p_priceInProdOfferRela(i_prodofferid in number, --2.0的销售品（1.0为基本套餐，2.0落地为可选包，或者套餐销售品）
                                   str_msg       out VARCHAR2) is
    v_priceid   number; --1.0的基本套餐规格
    v_offertype varchar2(10); --销售品类型
    v_oldprodId number; --旧的产品Id
    v_cnt       number; --查询数
    v_count     number; --插入总数
    v_remark    varchar2(2000); --备注
  begin
    v_oldprodId := 0;
    v_count     := 0;
    select count(*)
      into v_cnt
      from prod_offer          po,
           mdse_ys_lisy_new    myx, ---取新的规格映射表（modify by lisy）
           price_plan@lk_crmv1 p
     where po.prod_offer_id = myx.id_v2
       and myx.id_v1 = p.price_id
       and po.prod_offer_id = i_prodofferid;
    if v_cnt != 1 then
      str_msg := '输入的2.0销售品规格有误' || i_prodofferid;
      return;
    else
      select p.price_id
        into v_priceid
        from prod_offer          po,
             mdse_ys_lisy_new    myx, ---取新的规格映射表（modify by lisy）
             price_plan@lk_crmv1 p
       where po.prod_offer_id = myx.id_v2
         and myx.id_v1 = p.price_id
         and po.prod_offer_id = i_prodofferid;
    end if;
    select offer_type
      into v_offertype
      from prod_offer
     where prod_offer_id = i_prodofferid;
    if v_offertype = '12' then
      --1.0基本套餐落地到2.0为可选包
      FOR JProdOffer IN (select po.prod_offer_name,
                                po.prod_offer_id,
                                p.product_id,
                                p.product_name
                           from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                                mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                                prod_offer                           po,
                                offer_prod_rel                       opr,
                                product                              p
                          where pmpsr.price_id = v_priceid
                            and pmpsr.mdse_spec_id = myx.id_v1
                            and myx.id_v2 = po.prod_offer_id
                            and pmpsr.cfg_area_id in (1, 2)
                            and po.offer_type = '10'
                            and po.offer_sub_type = 'T01'
                            and opr.prod_offer_id = po.prod_offer_id
                            and opr.product_id = p.product_id
                            and opr.status_cd = '1000'
                            and opr.rule_type in ('10', '11', '12')
                          order by p.product_id, po.prod_offer_id) LOOP
        --导入2.0直接对应的基础类销售品与可选包的关联
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = JProdOffer.Prod_Offer_Id
           and por.offer_z_id = i_prodofferid
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_ID.Nextval,
             JProdOffer.Prod_Offer_Id,
             i_prodofferid,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             1,
             1,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_count := v_count + 1;
        end if;
        if v_oldprodId = 0 or
           (v_oldprodId > 0 and v_oldprodId != JProdOffer.Product_Id) then
          v_oldprodId := JProdOffer.Product_Id;
          --通过2.0产品查询对应的套餐销售品数据，该数据也要跟可选包建立关联
          FOR TProdOffer IN (select p.product_name,
                                    po.prod_offer_name,
                                    po.prod_offer_id
                               from offer_prod_rel opr,
                                    product        p,
                                    prod_offer     po
                              where opr.product_id = p.product_id
                                and opr.prod_offer_id = po.prod_offer_id
                                and opr.status_cd = '1000'
                                and opr.rule_type in ('10', '11', '12')
                                and po.offer_type = '11'
                                and po.offer_sub_type = 'T01'
                                and p.product_id = JProdOffer.Product_Id
                                and (po.offer_busi_type is null or
                                    po.offer_busi_type = '0')
                                and po.prod_offer_id not in --套餐销售品不能关联群组产品组合产品
                                    (select opr2.prod_offer_id
                                       from offer_prod_rel opr2, product p2
                                      where opr2.product_id = p2.product_id
                                        and opr2.status_cd = '1000'
                                        and opr2.rule_type in
                                            ('10', '11', '12')
                                        and p2.product_type != '10')
                                and po.prod_offer_id not in --套餐销售品不能对应原1.0互斥的基本套餐
                                    (select myx.id_v2
                                       from mdse_spec_rela@lk_crmv1 msr,
                                            mdse_ys_lisy_new        myx --取新的规格映射表（modify by lisy）
                                      where msr.mdse_spec_ida = v_priceid
                                        and msr.rela_type = '102'
                                        and msr.mdse_spec_idb = myx.id_v1
                                        and myx.id_v2 is not null
                                     union
                                     select myx.id_v2
                                       from mdse_spec_rela@lk_crmv1 msr,
                                            mdse_ys_lisy_new        myx ---取新的规格映射表（modify by lisy）
                                      where msr.mdse_spec_idb = v_priceid
                                        and msr.rela_type = '102'
                                        and msr.mdse_spec_ida = myx.id_v1
                                        and myx.id_v2 is not null)) LOOP
            --导入2.0对应的套餐销售品与可选包的关联
            select count(*)
              into v_cnt
              from prod_offer_rel por
             where por.offer_a_id = TProdOffer.Prod_Offer_Id
               and por.offer_z_id = i_prodofferid
               and por.relation_type_cd = '100000';
            if v_cnt = 0 then
              insert into PROD_OFFER_REL
                (PROD_OFFER_RELA_ID,
                 OFFER_A_ID,
                 OFFER_Z_ID,
                 ROLE_CD,
                 RELATION_TYPE_CD,
                 EFF_DATE,
                 EXP_DATE,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 HOT_SPOT_NO,
                 AREA_ID,
                 REGION_CD,
                 UPDATE_STAFF,
                 CREATE_STAFF,
                 SYNC_CUST,
                 EFFECTIVE_TYPE,
                 DEFAULT_TIME_PERIOD,
                 EXPIRE_TYPE,
                 RULE_TYPE)
              values
                (SEQ_PROD_OFFER_REL_ID.Nextval,
                 TProdOffer.Prod_Offer_Id,
                 i_prodofferid,
                 null,
                 '100000',
                 sysdate,
                 null,
                 '1000',
                 sysdate,
                 sysdate,
                 null,
                 null,
                 1,
                 1,
                 49822,
                 49822,
                 null,
                 null,
                 null,
                 null,
                 null);
              v_count := v_count + 1;
            end if;
          END LOOP;
        end if;
      END LOOP;
      v_remark := '1.0的基本套餐,2.0落地为可选包' || i_prodofferid ||
                  '作为Z端导入2.0销售品关联可选包数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         i_prodofferid,
         'OFFER_Z_ID',
         'p_priceInProdOfferRela',
         SYSDATE,
         v_count,
         v_remark);
    elsif v_offertype = '11' then
      --1.0基本套餐落地到2.0为套餐销售品
      For TProdOffer IN (select distinct po2.prod_offer_id,
                                         po2.prod_offer_name
                           from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                                mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                                prod_offer                           po,
                                offer_prod_rel                       opr,
                                prefer_mdse_price_spec_rela@lk_crmv1 pmpsr2,
                                mdse_ys_lisy_new                     myx2, ---取新的规格映射表（modify by lisy）
                                prod_offer                           po2
                          where pmpsr.price_id = v_priceid
                            and pmpsr.mdse_spec_id = myx.id_v1
                            and myx.id_v2 = po.prod_offer_id
                            and pmpsr.cfg_area_id in (1, 2)
                            and po.offer_type = '10'
                            and po.offer_sub_type = 'T01'
                            and opr.prod_offer_id = po.prod_offer_id
                            and opr.status_cd = '1000'
                            and opr.rule_type in ('10', '11', '12')
                            and pmpsr2.mdse_spec_id = pmpsr.mdse_spec_id --其它的适用套餐在2.0中落地为可选包的，与这些可选包建立可选关系
                            and pmpsr2.price_id = myx2.id_v1
                            and myx2.id_v2 = po2.prod_offer_id
                            and pmpsr2.cfg_area_id in (1, 2)
                            and po2.offer_type = '12'
                            and po2.offer_sub_type = 'T04'
                            and pmpsr2.price_id != v_priceid
                            and pmpsr2.price_id not in --过滤1.0中是互斥关系的套餐数据
                                (select msr.mdse_spec_idb
                                   from mdse_spec_rela@lk_crmv1 msr
                                  where msr.mdse_spec_ida = v_priceid
                                    and msr.rela_type = '102'
                                 union
                                 select msr.mdse_spec_idb
                                   from mdse_spec_rela@lk_crmv1 msr
                                  where msr.mdse_spec_idb = v_priceid
                                    and msr.rela_type = '102')) LOOP
        --导入套餐销售品与可选包的关联
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_z_id = TProdOffer.Prod_Offer_Id
           and por.offer_a_id = i_prodofferid
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_ID.Nextval,
             i_prodofferid,
             TProdOffer.Prod_Offer_Id,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             1,
             1,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_count := v_count + 1;
        end if;
      End LOOP;
      v_remark := '1.0的基本套餐,2.0落地为套餐销售品' || i_prodofferid ||
                  '作为A端导入2.0销售品关联可选包数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         i_prodofferid,
         'OFFER_A_ID',
         'p_priceInProdOfferRela',
         SYSDATE,
         v_count,
         v_remark);
    else
      str_msg := '输入的2.0销售品类型有误' || v_offertype;
      return;
    end if;
    str_msg := '导入PROD_OFFER_REL"' || to_char(v_count) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_priceInProdOfferRela:' || sqlerrm;
  end;

  PROCEDURE p_priceOutProdOfferRela(i_prodofferid in number, --2.0的销售品（1.0为基本套餐，2.0落地为可选包，或者套餐销售品）
                                    str_msg       out VARCHAR2) is
    v_priceid   number; --1.0套餐规格
    v_offertype varchar2(10); --销售品类型
    v_cnt       number; --查询数
    v_upcount   number; --修改总数
    v_delcount  number; --修改总数
    v_remark    varchar2(2000); --备注
  begin
    v_upcount  := 0;
    v_delcount := 0;
    select count(*)
      into v_cnt
      from prod_offer          po,
           mdse_ys_lisy_new    myx, ---取新的规格映射表（modify by lisy）
           price_plan@lk_crmv1 p
     where po.prod_offer_id = myx.id_v2
       and myx.id_v1 = p.price_id
       and po.prod_offer_id = i_prodofferid;
    if v_cnt != 1 then
      str_msg := '输入的2.0销售品规格有误' || i_prodofferid;
      return;
    else
      select p.price_id
        into v_priceid
        from prod_offer          po,
             mdse_ys_lisy_new    myx, ---取新的规格映射表（modify by lisy）
             price_plan@lk_crmv1 p
       where po.prod_offer_id = myx.id_v2
         and myx.id_v1 = p.price_id
         and po.prod_offer_id = i_prodofferid;
    end if;
    select offer_type
      into v_offertype
      from prod_offer
     where prod_offer_id = i_prodofferid;
    if v_offertype = '12' then
      --1.0基本套餐落地到2.0为可选包
      FOR DKX IN (select *
                    from prod_offer_rel
                   where offer_a_id = i_prodofferid
                     and relation_type_cd = '100000' --1.不能作为可选关系的A端
                  union
                  select por.*
                    from prod_offer_rel por, prod_offer po
                   where por.offer_z_id = i_prodofferid
                     and por.relation_type_cd = '100000'
                     and po.prod_offer_id = por.offer_a_id
                     and po.prod_offer_id in --套餐销售品不能关联群组产品组合产品
                         (select opr2.prod_offer_id
                            from offer_prod_rel opr2, product p2
                           where opr2.product_id = p2.product_id
                             and opr2.status_cd = '1000'
                             and opr2.rule_type in ('10', '11', '12')
                             and p2.product_type != '10')
                  /* union
                                  select por.*
                                    from prod_offer_rel por, prod_offer po
                                   where por.offer_z_id = i_prodofferid
                                     and por.relation_type_cd = '10'
                                     and po.prod_offer_id = por.offer_a_id
                                     and po.offer_busi_type='1' --e家商务领航先清除*/
                  union
                  select por.*
                    from prod_offer_rel por, prod_offer po
                   where por.offer_z_id = i_prodofferid
                     and por.relation_type_cd = '100000'
                     and po.prod_offer_id = por.offer_a_id --可选关系A端的不能为可选包
                     and (po.offer_type = '12' or po.offer_type = '13')
                  union
                  select por.*
                    from prod_offer_rel por, mdse_ys_lisy_new myx --取新的规格映射表(modify by lisy)
                   where por.offer_z_id = i_prodofferid
                     and por.relation_type_cd = '100000'
                     and myx.id_v2 = por.offer_a_id
                     and myx.id_v1 in --1.0中对应基本套餐是互斥状态的，要删除
                         (select myx.id_v2
                            from mdse_spec_rela@lk_crmv1 msr,
                                 mdse_ys_lisy_new        myx ----取新的规格映射表（modify by lisy）
                           where msr.mdse_spec_ida = v_priceid
                             and msr.rela_type = '102'
                             and msr.mdse_spec_idb = myx.id_v1
                          union
                          select myx.id_v2
                            from mdse_spec_rela@lk_crmv1 msr,
                                 mdse_ys_lisy_new        myx ---取新的规格映射表（modify by lisy）
                           where msr.mdse_spec_idb = v_priceid
                             and msr.rela_type = '102'
                             and msr.mdse_spec_ida = myx.id_v1)) LOOP
        select count(*)
          into v_cnt
          from prod_offer_inst_rel poir
         where poir.prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
        if v_cnt > 0 then
          --已经生成实例的数据，修改状态，原数据入历史表
          if DKX.Status_Cd != '1100' or DKX.Status_Cd is null then
            insert into PROD_OFFER_REL_HIS
              (HIS_ID,
               PROD_OFFER_RELA_ID,
               OFFER_A_ID,
               OFFER_Z_ID,
               ROLE_CD,
               RELATION_TYPE_CD,
               EFF_DATE,
               EXP_DATE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               HOT_SPOT_NO,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               SYNC_CUST,
               EFFECTIVE_TYPE,
               DEFAULT_TIME_PERIOD,
               EXPIRE_TYPE,
               RULE_TYPE)
            values
              (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,
               DKX.PROD_OFFER_RELA_ID,
               DKX.OFFER_A_ID,
               DKX.OFFER_Z_ID,
               DKX.ROLE_CD,
               DKX.RELATION_TYPE_CD,
               DKX.EFF_DATE,
               DKX.EXP_DATE,
               DKX.STATUS_CD,
               DKX.STATUS_DATE,
               DKX.CREATE_DATE,
               DKX.UPDATE_DATE,
               DKX.HOT_SPOT_NO,
               DKX.AREA_ID,
               DKX.REGION_CD,
               DKX.UPDATE_STAFF,
               DKX.CREATE_STAFF,
               DKX.SYNC_CUST,
               DKX.EFFECTIVE_TYPE,
               DKX.DEFAULT_TIME_PERIOD,
               DKX.EXPIRE_TYPE,
               DKX.RULE_TYPE);
            update PROD_OFFER_REL
               set status_cd = '1100', update_date = sysdate
             where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
            v_upcount := v_upcount + 1;
          end if;
        else
          --没实例直接删除。
          delete from PROD_OFFER_REL
           where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
          v_delcount := v_delcount + 1;
        end if;
      END LOOP;
    elsif v_offertype = '11' then
      --1.0基本套餐落地到2.0为套餐销售品
      FOR DKX IN (select por.*
                    from prod_offer_rel por, prod_offer po
                   where por.offer_z_id = i_prodofferid
                     and por.relation_type_cd = '100000' --作为可选关系Z端的要删除
                  union
                  select por.*
                    from prod_offer_rel por, prod_offer po
                   where por.offer_a_id = i_prodofferid
                     and por.relation_type_cd = '100000'
                     and po.prod_offer_id = por.offer_z_id
                     and po.offer_type != '12'
                     and po.offer_type != '13' --Z端不是可选包和促销包的也是要删除
                  union
                  select por.*
                    from prod_offer_rel por, mdse_ys_lisy_new myx
                   where por.offer_a_id = i_prodofferid
                     and por.relation_type_cd = '100000'
                     and myx.id_v2 = por.offer_z_id
                     and myx.id_v1 in
                         (select myx.id_v2
                            from mdse_spec_rela@lk_crmv1 msr,
                                 mdse_ys_lisy_new        myx ---取新的规格映射表(modify by lisy)
                           where msr.mdse_spec_ida = v_priceid
                             and msr.rela_type = '102'
                             and msr.mdse_spec_idb = myx.id_v1
                          union
                          select myx.id_v2
                            from mdse_spec_rela@lk_crmv1 msr,
                                 mdse_ys_lisy_new        myx ---取新的规格映射表(modify by lisy)
                           where msr.mdse_spec_idb = v_priceid
                             and msr.rela_type = '102'
                             and msr.mdse_spec_ida = myx.id_v1)) LOOP
        select count(*)
          into v_cnt
          from prod_offer_inst_rel poir
         where poir.prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
        if v_cnt > 0 then
          --已经生成实例的数据，修改状态，原数据入历史表
          if DKX.Status_Cd != '1100' or DKX.Status_Cd is null then
            insert into PROD_OFFER_REL_HIS
              (HIS_ID,
               PROD_OFFER_RELA_ID,
               OFFER_A_ID,
               OFFER_Z_ID,
               ROLE_CD,
               RELATION_TYPE_CD,
               EFF_DATE,
               EXP_DATE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               HOT_SPOT_NO,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               SYNC_CUST,
               EFFECTIVE_TYPE,
               DEFAULT_TIME_PERIOD,
               EXPIRE_TYPE,
               RULE_TYPE)
            values
              (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,
               DKX.PROD_OFFER_RELA_ID,
               DKX.OFFER_A_ID,
               DKX.OFFER_Z_ID,
               DKX.ROLE_CD,
               DKX.RELATION_TYPE_CD,
               DKX.EFF_DATE,
               DKX.EXP_DATE,
               DKX.STATUS_CD,
               DKX.STATUS_DATE,
               DKX.CREATE_DATE,
               DKX.UPDATE_DATE,
               DKX.HOT_SPOT_NO,
               DKX.AREA_ID,
               DKX.REGION_CD,
               DKX.UPDATE_STAFF,
               DKX.CREATE_STAFF,
               DKX.SYNC_CUST,
               DKX.EFFECTIVE_TYPE,
               DKX.DEFAULT_TIME_PERIOD,
               DKX.EXPIRE_TYPE,
               DKX.RULE_TYPE);
            update PROD_OFFER_REL
               set status_cd = '1100', update_date = sysdate
             where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
            v_upcount := v_upcount + 1;
          end if;
        else
          --没实例直接删除。
          delete from PROD_OFFER_REL
           where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
          v_delcount := v_delcount + 1;
        end if;
      END LOOP;
    else
      str_msg := '输入的2.0销售品类型有误' || v_offertype;
      return;
    end if;
    if v_upcount > 0 then
      v_remark := '1.0基本套餐,2.0落地为"' || i_prodofferid ||
                  ',因为规则不满足,失效销售品可选包关联数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         i_prodofferid,
         'OFFER_A_ID,OFFER_Z_ID',
         'p_priceOutProdOfferRela',
         SYSDATE,
         v_upcount,
         v_remark);
    end if;
    if v_delcount > 0 then
      v_remark := '1.0基本套餐,2.0落地为"' || i_prodofferid ||
                  ',因为规则不满足,删除销售品可选包关联数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         i_prodofferid,
         'OFFER_A_ID,OFFER_Z_ID',
         'p_priceOutProdOfferRela',
         SYSDATE,
         v_delcount,
         v_remark);
    end if;
    str_msg := '修改PROD_OFFER_REL"' || to_char(v_upcount) ||
               '"条数据;删除PROD_OFFER_REL"' || to_char(v_delcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_priceOutProdOfferRela:' || sqlerrm;
  end;

  PROCEDURE p_feaSpecRelaInProdRela(str_msg out VARCHAR2) is
    v_cnt          number; --查询数
    v_oldprodId    number; --产品A端ID
    v_oldprodrelId number; --旧的产品关联实例
    v_prodrelId    number; --产品关联实例
    v_pcount       number; --插入product_relation数
    v_ocount       number; --插入obj_cfg_rel数
    v_pallcount    number; --插入product_relation总数
    v_oallcount    number; --插入obj_cfg_rel总数
    v_infoname     varchar2(100); --信息名称
    v_remark       varchar2(2000); --备注
  begin
    v_pallcount    := 0;
    v_oallcount    := 0;
    v_oldprodId    := 0;
    v_oldprodrelId := 0;
    FOR FR in (select /* f1.name, f2.name, ps.name,*/
                prtm.new_rela_type_name new_rela_type_name,
                prtm.new_rela_type      new_rela_type,
                p2.product_id           a_product_id, --2.0的关系源目标与1.0是相反的
                p2.product_name         a_product_name,
                p1.product_id           z_product_id,
                p1.product_name         z_product_name,
                pmz.product_id          rela_product_id,
                pmz.product_name        rela_product_name
                 from prod_fea_spec_rela@lk_crmv1 r,
                      prod_fea_spec@lk_crmv1      f1,
                      prod_fea_spec@lk_crmv1      f2,
                      FEA_SPEC_MAP_ZHENGCL        fsmz1,
                      FEA_SPEC_MAP_ZHENGCL        fsmz2,
                      product                     p1,
                      product                     p2,
                      prod_spec@lk_crmv1          ps,
                      prod_map_zhengcl            pmz,
                      crm2_prod_rela_type_map     prtm
                where r.fea_id_a = f1.fea_spec_id
                  and r.fea_id_b = f2.fea_spec_id
                  and r.cfg_area_id in (1, 2)
                  and ps.prod_spec_id = f1.prod_spec_id
                  and r.rela_type != '0'
                  and fsmz1.fea_spec_id = f1.fea_spec_id
                  and fsmz2.fea_spec_id = f2.fea_spec_id
                  and fsmz1.g_product_id is not null
                  and fsmz2.g_product_id is not null
                  and pmz.prod_spec_id = ps.prod_spec_id
                  and prtm.old_rela_type = r.rela_type
                  and p1.product_id = fsmz1.g_product_id
                  and p1.product_type = '10'
                  and p1.prod_func_type = '102'
                  and p2.product_id = fsmz2.g_product_id
                  and p2.product_type = '10'
                  and p2.prod_func_type = '102'
                order by p2.product_id,
                         p1.product_id,
                         prtm.new_rela_type,
                         ps.prod_spec_id) LOOP
      if v_oldprodId = 0 or
         (v_oldprodId > 0 and v_oldprodId != FR.a_Product_Id) then
        if v_oldprodId > 0 and v_pcount > 0 then
          select p.product_name
            into v_infoname
            from product p
           where p.product_id = v_oldprodId;
          v_remark := '1.0程控特性关联数据,导入A端产品为' || v_infoname || '的2.0产品关系表';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PRODUCT_RELATION',
             v_oldprodId,
             'PRODUCT_A_ID',
             'p_feaSpecRelaInProdRela',
             SYSDATE,
             v_pcount,
             v_remark);
        end if;
        v_oldprodId := FR.a_Product_Id;
        v_pcount    := 0;
      end if;
      --PRODUCT_RELATION数据插入
      select count(*)
        into v_cnt
        from product_relation pr
       where pr.product_a_id = fr.a_product_id
         and pr.product_z_id = fr.z_product_id
         and pr.relation_type_cd = fr.new_rela_type;
      if v_cnt = 1 then
        select pr.product_rel_id
          into v_prodrelId
          from product_relation pr
         where pr.product_a_id = fr.a_product_id
           and pr.product_z_id = fr.z_product_id
           and pr.relation_type_cd = fr.new_rela_type;
      elsif v_cnt = 0 then
        select SEQ_PRODUCT_REL_ID.nextval into v_prodrelId from dual;
        --插入产品关联数据
        insert into PRODUCT_RELATION
          (PRODUCT_REL_ID,
           RELATION_TYPE_CD,
           PRODUCT_A_ID,
           PRODUCT_Z_ID,
           ROLE_CD,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           HOT_SPOT_NO,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           MIN_COUNT,
           MAX_COUNT,
           SYNC_CUST,
           EXIST_TYPE,
           REL_GROUP_ALIAS)
        values
          (v_prodrelId,
           fr.new_rela_type,
           fr.a_product_id,
           fr.z_product_id,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           1,
           1,
           49822,
           49822,
           null,
           null,
           null,
           null,
           null);
        v_pcount    := v_pcount + 1;
        v_pallcount := v_pallcount + 1;
      else
        v_prodrelId := 0;
      end if;
      if v_prodrelId > 0 then
        if v_oldprodrelId = 0 or
           (v_oldprodrelId > 0 and v_oldprodrelId != v_prodrelId) then
          if v_oldprodrelId > 0 and v_ocount > 0 then
            v_remark := '1.0程控特性关联数据,导入关联OBJ_REL_CFG数据obj_class_id=2 and cfg_class_id=70';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'OBJ_REL_CFG',
               v_oldprodrelId,
               'CFG_ID',
               'p_feaSpecRelaInProdRela',
               SYSDATE,
               v_ocount,
               v_remark);
          end if;
          v_oldprodrelId := v_prodrelId;
          v_ocount       := 0;
        end if;
        --OBJ_REL_CFG表数据插入
        select count(*)
          into v_cnt
          from OBJ_REL_CFG orc
         where orc.obj_class_id = 2
           and orc.cfg_class_id = 70
           and orc.cfg_id = v_prodrelId
           and orc.obj_id = fr.rela_product_id;
        if v_cnt = 0 then
          insert into OBJ_REL_CFG
            (OBJ_REL_CFG_ID,
             OBJ_CLASS_ID,
             OBJ_ID,
             CFG_CLASS_ID,
             CFG_ID,
             AREA_ID,
             REGION_CD,
             CREATE_DATE,
             CREATE_STAFF,
             STATUS_CD,
             STATUS_DATE,
             UPDATE_DATE,
             UPDATE_STAFF)
          values
            (seq_obj_rel_cfg_id.nextval,
             2,
             FR.Rela_Product_Id,
             70,
             v_prodrelId,
             1,
             11,
             sysdate,
             49822,
             '1000',
             sysdate,
             sysdate,
             49822);
          v_oallcount := v_oallcount + 1;
          v_ocount    := v_ocount + 1;
        end if;
      end if;
    END LOOP;
    if v_oldprodId > 0 and v_pcount > 0 then
      select p.product_name
        into v_infoname
        from product p
       where p.product_id = v_oldprodId;
      v_remark := '1.0程控特性关联数据,导入A端产品为' || v_infoname || '的2.0产品关系表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PRODUCT_RELATION',
         v_oldprodId,
         'PRODUCT_A_ID',
         'p_feaSpecRelaInProdRela',
         SYSDATE,
         v_pcount,
         v_remark);
    end if;
    if v_oldprodrelId > 0 and v_ocount > 0 then
      v_remark := '1.0程控特性关联数据,导入关联OBJ_REL_CFG数据obj_class_id=2 and cfg_class_id=70';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'OBJ_REL_CFG',
         v_oldprodrelId,
         'CFG_ID',
         'p_feaSpecRelaInProdRela',
         SYSDATE,
         v_ocount,
         v_remark);
    end if;
    str_msg := 'PRODUCT_RELATION"' || to_char(v_pallcount) ||
               '"条数据;OBJ_REL_CFG"' || to_char(v_oallcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_feaSpecRelaInProdRela:' || sqlerrm;
  end;

  PROCEDURE p_eHomeKXBPriceIn(i_preferspecid in number, --1.0 e家销售品规格
                              str_msg        out VARCHAR2) is
    v_oldeprodofferid         number; --旧的2.0e家套餐销售品规格
    v_oldeprodoffername       varchar2(100); --旧的2.0e家套餐销售品名称
    v_oldkxbprodofferid       number; --旧的2.0可选包销售品规格
    v_oldkxbprodoffername     varchar2(100); --旧的2.0可选包销售品名称
    v_oldofferprodrelaid      number; --旧的2.0角色可选包与产品的关联关系Id
    v_oldofferprodrelaname    varchar2(100); --旧的2.0角色可选包与产品的关联关系名称
    v_oldprodofferid          number; --旧的2.0基础销售品规格
    v_oldprodoffername        varchar2(100); --旧的2.0基础销售品规格
    v_prodofferrelaid         number; --销售品可选关联关系Id
    v_oldkxbofferprodrelaid   number; --旧的2.0角色可选包与产品的关联关系Id
    v_oldkxbofferprodrelaname varchar2(100); --旧的2.0角色可选包与产品的关联关系名称
    v_cnt                     number; --查询数
    v_ocount                  number; --插入销售品关联数
    v_allocount               number; --插入销售品关联总数
    v_pcount                  number; --插入产品与销售品关联数
    v_allpcount               number; --插入产品与销售品关联总数
    v_opocount                number; --插入产品实例关联销售品约束数
    v_allopocount             number; --插入产品实例关联销售品约束总数
    v_porcount                number; --插入可选包销售品约束数
    v_allporcount             number; --插入可选包销售品约束总数
    v_remark                  varchar2(2000); --备注
  begin
    v_allocount   := 0;
    v_allpcount   := 0;
    v_allopocount := 0;
    v_allporcount := 0;
    --先判断1.0的e家是否在2.0有落地为基础销售品
    select count(*)
      into v_cnt
      from mdse_ys_lisy_new myx, ---取新的规格映射表（modify by lisy）
           prod_offer       po
     where myx.id_v1 = i_preferspecid
       and myx.id_v2 = po.prod_offer_id
       and po.offer_type = '11'
       and po.offer_sub_type = 'T01';
    if v_cnt > 0 then
      /*步骤1.帽子上的适用套餐落地为可选包或促销包，与2.0的e家销售品直接建立可选关系。
      基础包上的适用套餐落地为可选包或促销，且在1.0中没有配置适用分组，也是与2.0的e家销售品直接建立可选关系*/
      v_oldeprodofferid   := 0;
      v_oldeprodoffername := '';
      FOR KXOFFER IN (select po1.prod_offer_id   E_PROD_OFFER_ID,
                             po1.prod_offer_name E_PROD_OFFER_NAME,
                             po.prod_offer_id    KXB_PROD_OFFER_ID,
                             po.prod_offer_name  KXB_PROD_OFFER_NAME
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.id_type = '1' --帽子
                         and pmpsr.cfg_area_id='10'----区域
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                      UNION
                      select po1.prod_offer_id   E_PROD_OFFER_ID,
                             po1.prod_offer_name E_PROD_OFFER_NAME,
                             po.prod_offer_id    KXB_PROD_OFFER_ID,
                             po.prod_offer_name  KXB_PROD_OFFER_NAME
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.role_type = '001' --基础包
                         and pmpsr.cfg_area_id='10'---区域
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                         and not exists
                       (select obj_id
                                from pm_extend_restrict@lk_crmv1 per
                               where per.restrict_type = '174'
                                 and per.obj_type = 'TCSPGL'
                                 and per.obj_id = pmpsr.rela_id)
                       order by E_PROD_OFFER_ID, KXB_PROD_OFFER_ID) LOOP
        --e家直接与可选包建立关系的日志记录
        if v_oldeprodofferid = 0 or
           (v_oldeprodofferid > 0 and
           v_oldeprodofferid != KXOFFER.e_Prod_Offer_Id) then
          if v_oldeprodofferid > 0 and v_ocount > 0 then
            v_remark := 'e家帽子和基础包上的无分组适用套餐(2.0落地为可选包),在2.0中导入与"' ||
                        v_oldeprodoffername || '"的可选关系';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'PROD_OFFER_REL',
               v_oldeprodofferid,
               'OFFER_A_ID',
               'p_eHomeKXBPriceIn_S1',
               SYSDATE,
               v_ocount,
               v_remark);
          end if;
          v_oldeprodofferid   := KXOFFER.e_Prod_Offer_Id;
          v_oldeprodoffername := KXOFFER.e_Prod_Offer_Name;
          v_ocount            := 0;
        end if;
        --插入2.0e家套餐销售品与可选包的可选关系
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = KXOFFER.e_Prod_Offer_Id
           and por.offer_z_id = KXOFFER.KXB_PROD_OFFER_ID
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_ID.Nextval,
             KXOFFER.e_Prod_Offer_Id,
             KXOFFER.Kxb_Prod_Offer_Id,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             '10',---区域
             null,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_ocount    := v_ocount + 1;
          v_allocount := v_allocount + 1;
        end if;
      END LOOP;
      --日志补充
      if v_oldeprodofferid > 0 and v_ocount > 0 then
        v_remark := 'e家帽子和基础包上的无分组适用套餐(2.0落地为可选包),在2.0中导入与"' ||
                    v_oldeprodoffername || '"的可选关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           v_oldeprodofferid,
           'OFFER_A_ID',
           'p_eHomeKXBPriceIn_S1',
           SYSDATE,
           v_ocount,
           v_remark);
      end if;
      /*步骤2.基础包上的适用套餐落地为可选包或促销包，且在1.0中有配置适用分组，除了可选包与2.0的e家销售品建立可选关系外;
          可选包还要配置与分组的产品的引用关系(如果与产品已经有可选关系了，则将原先的可选关系改成引用关系)
              天翼共享包上的适用套餐落地为可选包或保销包，除了可选包与2.0的e家销售品建立可选关系外;
          可选包还要配置与移动语音的引用关系(如果与产品已经有可选关系了，则将原先的可选关系改成引用关系)
      */
      v_oldeprodofferid     := 0;
      v_oldeprodoffername   := '';
      v_oldkxbprodofferid   := 0;
      v_oldkxbprodoffername := '';
      FOR KXOFFER IN (select po1.prod_offer_id e_prod_offer_id,
                             po1.prod_offer_name e_prod_offer_name,
                             po.prod_offer_id kxb_prod_offer_id,
                             po.prod_offer_name kxb_prod_offer_name,
                             pmz.product_id,
                             pmz.product_name,
                             po.offer_type offer_type
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1,
                             pm_extend_restrict@lk_crmv1          per,
                             prod_map_zhengcl                     pmz
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.role_type = '001' --基础包
                         and pmpsr.cfg_area_id='10'----区域
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                         and pmpsr.rela_id = per.obj_id
                         and per.restrict_type = '174'
                         and per.obj_type = 'TCSPGL'
                         and per.restrict_value = pmz.group_type
                      union
                      select po1.prod_offer_id e_prod_offer_id,
                             po1.prod_offer_name e_prod_offer_name,
                             po.prod_offer_id kxb_prod_offer_id,
                             po.prod_offer_name kxb_prod_offer_name,
                             800000002 product_id,
                             '移动语音' product_name,
                             po.offer_type offer_type
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.name like '%天翼共享包%'
                         and pmpsr.cfg_area_id='10'---区域
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                      union
                      select po1.prod_offer_id e_prod_offer_id,
                             po1.prod_offer_name e_prod_offer_name,
                             po.prod_offer_id kxb_prod_offer_id,
                             po.prod_offer_name kxb_prod_offer_name,
                             800000003 product_id,
                             '小灵通' product_name,
                             po.offer_type offer_type
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.name in ('小灵通可选包','超无包')
                         and pmpsr.cfg_area_id ='10'---区域
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                       order by e_prod_offer_id, kxb_prod_offer_id) LOOP
        --e家与可选包建立关系的日志记录
        if v_oldeprodofferid = 0 or
           (v_oldeprodofferid > 0 and
           v_oldeprodofferid != KXOFFER.e_Prod_Offer_Id) then
          if v_oldeprodofferid > 0 and v_ocount > 0 then
            v_remark := 'e家天翼共享包和基础包上的有分组适用套餐(2.0落地为可选包),在2.0中导入与"' ||
                        v_oldeprodoffername || '"的可选关系';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'PROD_OFFER_REL',
               v_oldeprodofferid,
               'OFFER_A_ID',
               'p_eHomeKXBPriceIn_S2',
               SYSDATE,
               v_ocount,
               v_remark);
          end if;
          v_oldeprodofferid   := KXOFFER.e_Prod_Offer_Id;
          v_oldeprodoffername := KXOFFER.e_Prod_Offer_Name;
          v_ocount            := 0;
        end if;
        --插入2.0e家套餐销售品与可选包的可选关系
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = KXOFFER.e_Prod_Offer_Id
           and por.offer_z_id = KXOFFER.KXB_PROD_OFFER_ID
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_ID.Nextval,
             KXOFFER.e_Prod_Offer_Id,
             KXOFFER.Kxb_Prod_Offer_Id,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             10,----区域
             null,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_ocount    := v_ocount + 1;
          v_allocount := v_allocount + 1;
        end if;
        --可选包与产品建立关系的日志记录
        if v_oldkxbprodofferid = 0 or
           (v_oldkxbprodofferid > 0 and
           v_oldkxbprodofferid != KXOFFER.Kxb_Prod_Offer_Id) then
          if v_oldkxbprodofferid > 0 and v_pcount > 0 then
            v_remark := 'e家天翼共享包和基础包的有分组适用套餐(2.0落地为可选包),在2.0中导入"' ||
                        v_oldkxbprodoffername || '"的引用关系';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'OFFER_PROD_REL',
               v_oldkxbprodofferid,
               'PROD_OFFER_ID',
               'p_eHomeKXBPriceIn_S2',
               SYSDATE,
               v_pcount,
               v_remark);
          end if;
          v_oldkxbprodofferid   := KXOFFER.Kxb_Prod_Offer_Id;
          v_oldkxbprodoffername := KXOFFER.Kxb_Prod_Offer_Name;
          v_pcount              := 0;
        end if;
        --插入可选包与产品的引用关系，如果已经有可选关系，则将原关系类型改成引用关系
        select count(*)
          into v_cnt
          from offer_prod_rel opr
         where opr.prod_offer_id = KXOFFER.Kxb_Prod_Offer_Id
           and opr.product_id = KXOFFER.PRODUCT_ID
           and opr.rule_type = '14';  --引用关系
        --判断是否存在引用关系并且落地为可选包
        if v_cnt = 0 and KXOFFER.Offer_Type = '12' then
          select count(*)
            into v_cnt
            from offer_prod_rel opr
           where opr.prod_offer_id = KXOFFER.Kxb_Prod_Offer_Id
             and opr.product_id = KXOFFER.PRODUCT_ID
             and opr.rule_type = '10'; --可选关系
          if v_cnt = 1 then
            FOR ORR IN (SELECT *
                          FROM offer_prod_rel opr
                         where opr.prod_offer_id = KXOFFER.Kxb_Prod_Offer_Id
                           and opr.product_id = KXOFFER.PRODUCT_ID
                           and opr.rule_type = '10') LOOP
              insert into OFFER_PROD_REL_HIS
                (HIS_ID,
                 OFFER_PROD_RELA_ID,
                 PRODUCT_ID,
                 PROD_OFFER_ID,
                 ROLE_CD,
                 MAX_COUNT,
                 MIN_COUNT,
                 RULE_TYPE,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 PARENT_RELA_ID,
                 AREA_ID,
                 REGION_CD,
                 UPDATE_STAFF,
                 CREATE_STAFF,
                 IS_DEFAULT,
                 EXIST_TYPE,
                 SYNC_CUST,
                 HOT_SPOT_NO,
                 EFFECTIVE_TYPE,
                 DEFAULT_TIME_PERIOD,
                 EXPIRE_TYPE)
              values
                (SEQ_OFFER_PROD_REL_HIS_ID.Nextval,
                 ORR.OFFER_PROD_RELA_ID,
                 ORR.Product_Id,
                 ORR.PROD_OFFER_ID,
                 ORR.ROLE_CD,
                 ORR.MAX_COUNT,
                 ORR.MIN_COUNT,
                 ORR.RULE_TYPE,
                 ORR.STATUS_CD,
                 ORR.STATUS_DATE,
                 ORR.CREATE_DATE,
                 ORR.UPDATE_DATE,
                 ORR.PARENT_RELA_ID,
                 ORR.AREA_ID,
                 ORR.REGION_CD,
                 ORR.UPDATE_STAFF,
                 ORR.CREATE_STAFF,
                 ORR.IS_DEFAULT,
                 ORR.EXIST_TYPE,
                 ORR.SYNC_CUST,
                 ORR.HOT_SPOT_NO,
                 ORR.EFFECTIVE_TYPE,
                 ORR.DEFAULT_TIME_PERIOD,
                 ORR.EXPIRE_TYPE);
              update offer_prod_rel
                 set rule_type = '14', update_date = sysdate
               where OFFER_PROD_RELA_ID = ORR.OFFER_PROD_RELA_ID;
              v_pcount    := v_pcount + 1;
              v_allpcount := v_allpcount + 1;
            END LOOP;
          else
            insert into OFFER_PROD_REL
              (OFFER_PROD_RELA_ID,
               PRODUCT_ID,
               PROD_OFFER_ID,
               ROLE_CD,
               MAX_COUNT,
               MIN_COUNT,
               RULE_TYPE,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               PARENT_RELA_ID,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               IS_DEFAULT,
               EXIST_TYPE,
               SYNC_CUST,
               HOT_SPOT_NO,
               EFFECTIVE_TYPE,
               DEFAULT_TIME_PERIOD,
               EXPIRE_TYPE)
            values
              (SEQ_OFFER_PROD_REL_ID.Nextval,
               KXOFFER.Product_Id,
               KXOFFER.Kxb_Prod_Offer_Id,
               null,
               null,
               null,
               '14',
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               10,----区域
               null,
               49822,
               49822,
               null,
               null,
               null,
               null,
               null,
               null,
               null);
            v_pcount    := v_pcount + 1;
            v_allpcount := v_allpcount + 1;
          end if;
        end if;
      END LOOP;
      --日志补充
      if v_oldeprodofferid > 0 and v_ocount > 0 then
        v_remark := 'e家天翼共享包和基础包上的有分组适用套餐(2.0落地为可选包),在2.0中导入与"' ||
                    v_oldeprodoffername || '"的可选关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           v_oldeprodofferid,
           'OFFER_A_ID',
           'p_eHomeKXBPriceIn_S2',
           SYSDATE,
           v_ocount,
           v_remark);
      end if;
      if v_oldkxbprodofferid > 0 and v_pcount > 0 then
        v_remark := 'e家天翼共享包和基础包的有分组适用套餐(2.0落地为可选包),在2.0中导入"' ||
                    v_oldkxbprodoffername || '"的引用关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'OFFER_PROD_REL',
           v_oldkxbprodofferid,
           'PROD_OFFER_ID',
           'p_eHomeKXBPriceIn_S2',
           SYSDATE,
           v_pcount,
           v_remark);
      end if;

      /*步骤3.角色包名为“XX可选包”上的适用套餐落地为可选包的情况。
          1.角色包本身落地为可选包，要先确认角色可选包与产品的关系关系，且1.0中角色包内适用的销售品，要关联到这个关系上。
          2.角色包内适用的销售品上，与落地为可选包的适用套餐建立可选关系。
          3.如果这个适用套餐可选包，只能在角色包上才能受理，还要再加个配置，在第二点的销售品可选关系上增加“可选包销售品约束”，关联对应的e家角色包可选包。
      */
      v_oldofferprodrelaid      := 0;
      v_oldprodoffername        := '';
      v_oldprodofferid          := 0;
      v_oldofferprodrelaname    := '';
      v_oldkxbofferprodrelaid   := 0;
      v_oldkxbofferprodrelaname := '';
      v_ocount                  := 0;
      FOR KXBOFFER IN (select po.prod_offer_id        KXB_Prod_offer_id,
                              po.prod_offer_name      KXB_Prod_offer_name,
                              spo.prod_offer_id       GL_prod_offer_id,
                              spo.prod_offer_name     GL_prod_offer_name,
                              p.product_id            product_id,
                              p.product_name          product_name,
                              kopr.offer_prod_rela_id GL_offer_prod_rela_id,
                              opr.offer_prod_rela_id  KXB_offer_prod_rela_id,
                              kpo.prod_offer_id       SKXB_Prod_offer_id,
                              kpo.prod_offer_name     SKXB_Prod_offer_name,
                              pmpsr.price_id          SKXB_Price_id
                         from prefer_mdse_spec_rela@lk_crmv1       pmsr,
                              pm_special_mdse_spec@lk_crmv1        psms,
                              mdse_spec@lk_crmv1                   ms,
                              role_map_zhengcl                     rmz,
                              prod_offer                           po,
                              prod_offer                           spo,
                              mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                              prod_map_zhengcl                     pmz,
                              product                              p,
                              offer_prod_rel                       opr,
                              prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                              mdse_ys_lisy_new                     kmyx, ---取新的规格映射表（modify by lisy）
                              prod_offer                           kpo,
                              offer_prod_rel                       kopr
                        where pmsr.prefer_spec_id = i_preferspecid
                          and pmsr.rela_id = rmz.role_id
                          and rmz.prod_offer_id = po.prod_offer_id
                          and po.offer_type = '12'
                          and po.offer_sub_type = 'T04'
                          and psms.role_id = pmsr.rela_id
                          and ms.mdse_spec_id = psms.mdse_spec_id
                          and ms.mdse_spec_id = myx.id_v1
                          and myx.id_v2 = spo.prod_offer_id
                          and spo.offer_type = '10'
                          and spo.status_cd<>'1100'
                          and ms.prod_spec_id = pmz.prod_spec_id
                          and pmz.product_id = p.product_id
                          and p.product_type = '10'
                          and opr.prod_offer_id = po.prod_offer_id
                          and opr.product_id = p.product_id
                          and opr.rule_type in ('10', '11', '12')
                          and kopr.prod_offer_id = spo.prod_offer_id
                          and kopr.product_id = p.product_id
                          and kopr.rule_type in ('10', '11', '12')
                          and pmpsr.rela_mdse_id = pmsr.rela_id
                          and pmpsr.price_id = kmyx.id_v1
                          and kmyx.id_v2 = kpo.prod_offer_id
                          and kpo.offer_type = '12'
                          and kpo.offer_sub_type = 'T04'
                          and kpo.status_cd<>'1100'
                          and pmpsr.cfg_area_id ='10'---区域
                        order by po.prod_offer_id,
                                 product_id,
                                 gl_prod_offer_id,
                                 skxb_prod_offer_id) LOOP
        --1.角色包本身落地为可选包，要先确认角色可选包与产品的关系关系，且1.0中角色包内适用的销售品，要关联到这个关系上。
        --角色可选包与产品关联关系上的关联销售品实例日志记录
        /*
        if v_oldofferprodrelaid = 0 or
           (v_oldofferprodrelaid > 0 and
           v_oldofferprodrelaid != KXBOFFER.Kxb_Offer_Prod_Rela_Id) then
          if v_oldofferprodrelaid > 0 and v_opocount > 0 then
            v_remark := 'e家可选包上的适用套餐(2.0落地为可选包),在2.0中导入"' ||
                        v_oldofferprodrelaname || '"的产品实例关联销售品约束';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'OFFER_PROD_RESTRICT_RELA_OFFER',
               v_oldofferprodrelaid,
               'OFFER_PROD_RELA_ID',
               'p_eHomeKXBPriceIn_S3',
               SYSDATE,
               v_opocount,
               v_remark);
          end if;
          v_oldofferprodrelaid   := KXBOFFER.Kxb_Offer_Prod_Rela_Id;
          v_oldofferprodrelaname := KXBOFFER.Kxb_Prod_Offer_Name || '关联' ||
                                    KXBOFFER.Product_Name;
          v_opocount             := 0;
        end if;
        --产品实例关系销售品约束
        select count(*)
          into v_cnt
          from Offer_Prod_Restrict_Rela_Offer oprro
         where oprro.offer_prod_rela_id = KXBOFFER.Kxb_Offer_Prod_Rela_Id
           and oprro.rela_offer_id = KXBOFFER.Gl_Prod_Offer_Id;
        if v_cnt = 0 then
          insert into OFFER_PROD_RESTRICT_RELA_OFFER
            (RESTRICT_ID,
             OFFER_PROD_RELA_ID,
             RESTRICT_TYPE,
             RELA_OFFER_ID,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF)
          values
            (SEQ_OPR_RELA_OFFER_ID.Nextval,
             KXBOFFER.Kxb_Offer_Prod_Rela_Id,
             '10',
             KXBOFFER.Gl_Prod_Offer_Id,
             '1000',
             sysdate,
             sysdate,
             sysdate,
             1,
             1,
             49822,
             49822);
          v_opocount    := v_opocount + 1;
          v_allopocount := v_allopocount + 1;
        end if;
        */
        --2.角色包内适用的销售品，与落地为可选包的适用套餐建立可选关系。
        if v_oldprodofferid = 0 or
           (v_oldprodofferid > 0 and
           v_oldprodofferid != KXBOFFER.Gl_Prod_Offer_Id) then
          if v_oldprodofferid > 0 and v_ocount > 0 then
            v_remark := 'e家可选包上的适用套餐(2.0落地为可选包),在2.0中导入"' ||
                        v_oldprodoffername || '"为A端的销售品可选关联数据';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'PROD_OFFER_REL',
               v_oldprodofferid,
               'OFFER_A_ID',
               'p_eHomeKXBPriceIn_S3',
               SYSDATE,
               v_ocount,
               v_remark);
          end if;
          v_oldprodofferid   := KXBOFFER.Gl_Prod_Offer_Id;
          v_oldprodoffername := KXBOFFER.Gl_Prod_Offer_Name;
          v_ocount           := 0;
        end if;
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = KXBOFFER.Gl_Prod_Offer_Id
           and por.offer_z_id = KXBOFFER.SKXB_PROD_OFFER_ID
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          select SEQ_PROD_OFFER_REL_ID.nextval
            into v_prodofferrelaid
            from dual;
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (v_prodofferrelaid,
             KXBOFFER.Gl_Prod_Offer_Id,
             KXBOFFER.SKXB_PROD_OFFER_ID,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             10,---区域
             null,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_ocount    := v_ocount + 1;
          v_allocount := v_allocount + 1;
        elsif v_cnt = 1 then
          select por.prod_offer_rela_id
            into v_prodofferrelaid
            from prod_offer_rel por
           where por.offer_a_id = KXBOFFER.Gl_Prod_Offer_Id
             and por.offer_z_id = KXBOFFER.SKXB_PROD_OFFER_ID
             and por.relation_type_cd = '100000';
        else
          v_prodofferrelaid := 0;
        end if;
        --3.如果这个适用套餐可选包，只能在角色包上才能受理，还要再加个配置，在第二点的销售品可选关系上增加“可选包销售品约束”，关联对应的e家角色包可选包。
        if v_prodofferrelaid > 0 then
          select count(*)
            into v_cnt
            from prefer_mdse_price_spec_rela@lk_crmv1
           where price_id = kxboffer.Skxb_Price_Id
             and mdse_spec_id > 0
             and rela_mdse_id = -1
             and state = '70A'
             and cfg_area_id='10';----区域
          if v_cnt = 0 then
            --只能在角色上受理
            --角色可选包与产品关联关系 作为可选包销售品约束的日志记录
            if v_oldkxbofferprodrelaid = 0 or
               (v_oldkxbofferprodrelaid > 0 and
               v_oldkxbofferprodrelaid != KXBOFFER.Kxb_Offer_Prod_Rela_Id) then
              if v_oldkxbofferprodrelaid > 0 and v_porcount > 0 then
                v_remark := 'e家可选包上的适用套餐(2.0落地为可选包),在2.0中导入"' ||
                            v_oldkxbofferprodrelaname || '"的可选包销售品约束';
                insert into CRM1_CFG_SYNC
                  (ID,
                   TABLE_NAME,
                   OBJ_ID,
                   OBJ_TYPE,
                   SYNC_METHO,
                   SYNC_DATE,
                   SYNC_COUNT,
                   REMARK)
                values
                  (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                   'PROD_OFFER_REL_RESTRICT',
                   v_oldkxbofferprodrelaid,
                   'OFFER_PROD_REL_ID_Z',
                   'p_eHomeKXBPriceIn_S3',
                   SYSDATE,
                   v_porcount,
                   v_remark);
              end if;
              v_oldkxbofferprodrelaid   := KXBOFFER.Kxb_Offer_Prod_Rela_Id;
              v_oldkxbofferprodrelaname := KXBOFFER.Kxb_Prod_Offer_Name || '关联' ||
                                           KXBOFFER.Product_Name;
              v_porcount                := 0;
            end if;
            select count(*)
              into v_cnt
              from PROD_OFFER_REL_RESTRICT porr
             where porr.prod_offer_rel_id = v_prodofferrelaid
               and porr.offer_prod_rel_id_a =
                   KXBOFFER.Gl_Offer_Prod_Rela_Id
               and porr.offer_prod_rel_id_z =
                   KXBOFFER.Kxb_Offer_Prod_Rela_Id
               and porr.rule_type = '10';
            if v_cnt = 0 then
              insert into PROD_OFFER_REL_RESTRICT
                (PROD_OFFER_REL_RESTRICT_ID,
                 PROD_OFFER_REL_ID,
                 OFFER_PROD_REL_ID_A,
                 OFFER_PROD_REL_ID_Z,
                 CREATE_DATE,
                 AREA_ID,
                 REGION_CD,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_STAFF,
                 UPDATE_DATE,
                 UPDATE_STAFF,
                 RULE_TYPE)
              values
                (SEQ_PROD_OFFER_REL_RESTRICT_ID.Nextval,
                 v_prodofferrelaid,
                 KXBOFFER.Gl_Offer_Prod_Rela_Id,
                 KXBOFFER.Kxb_Offer_Prod_Rela_Id,
                 sysdate,
                 10,----区域
                 null,
                 '1000',
                 sysdate,
                 49822,
                 sysdate,
                 49822,
                 '10');
              v_porcount    := v_porcount + 1;
              v_allporcount := v_allporcount + 1;
            end if;
          end if;
        end if;
      END LOOP;
      --日志补充
      --1.角色可选包与产品关联关系上的关联销售品实例日志记录
      if v_oldofferprodrelaid > 0 and v_opocount > 0 then
        v_remark := 'e家可选包上的适用套餐(2.0落地为可选包),在2.0中导入"' ||
                    v_oldofferprodrelaname || '"的产品实例关联销售品约束';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'OFFER_PROD_RESTRICT_RELA_OFFER',
           v_oldofferprodrelaid,
           'OFFER_PROD_RELA_ID',
           'p_eHomeKXBPriceIn_S3',
           SYSDATE,
           v_opocount,
           v_remark);
      end if;
      --2.角色包内适用的销售品，与落地为可选包的适用套餐建立可选关系日志
      if v_oldprodofferid > 0 and v_ocount > 0 then
        v_remark := 'e家可选包上的适用套餐(2.0落地为可选包),在2.0中导入"' || v_oldprodoffername ||
                    '"为A端的销售品可选关联数据';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           v_oldprodofferid,
           'OFFER_A_ID',
           'p_eHomeKXBPriceIn_S3',
           SYSDATE,
           v_ocount,
           v_remark);
      end if;
      --3.角色可选包与产品关联关系 作为可选包销售品约束的日志记录
      if v_oldkxbofferprodrelaid > 0 and v_porcount > 0 then
        v_remark := 'e家可选包上的适用套餐(2.0落地为可选包),在2.0中导入"' ||
                    v_oldkxbofferprodrelaname || '"的可选包销售品约束';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL_RESTRICT',
           v_oldkxbofferprodrelaid,
           'OFFER_PROD_REL_ID_Z',
           'p_eHomeKXBPriceIn_S3',
           SYSDATE,
           v_porcount,
           v_remark);
      end if;
    else
      str_msg := '输入的1.0e家规格' || i_preferspecid || '在2.0没有落地的套餐销售品数据，请确认输入';
    end if;
    str_msg := '导入PROD_OFFER_REL"' || to_char(v_allocount) ||
               '"条数据;导入OFFER_PROD_REL"' || to_char(v_allpcount) ||
               '"条数据;导入OFFER_PROD_RESTRICT_RELA_OFFER"' ||
               to_char(v_allopocount) || '"条数据;导入PROD_OFFER_REL_RESTRICT"' ||
               to_char(v_allporcount) || '"条数据;';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_eHomeKXBPriceIn:' || sqlerrm;
  end;

  ----查询1.0e家规格（执行脚本输入参数时使用）--- add by lisy
  /*
  select cc.prod_offer_id,
         cc.prod_offer_name,
         cc.status_cd,
         cc.offer_type,
         cc.area_id,
         dd.id_v1,
         dd.name_v1
    from prod_offer cc, mdse_ys_lisy_new dd
   where cc.prod_offer_id = dd.id_v2
     and cc.offer_busi_type = '1'
     and cc.area_id in ('1', '2')
     and cc.status_cd <> '1100'
     and cc.prod_offer_name not like '%商务领航%'
   order by dd.id_v1
  */

  PROCEDURE p_prodOfferAttrWinIn(str_msg out VARCHAR2) is
    v_winid      number; --窗口Id
    v_wincode    varchar2(100); --窗口code
    v_winname    varchar2(100); --窗口名称
    v_gridcompid number; --表格控件Id
    v_cnt        number; --查询数
    v_count      number; --插入数
    v_allcount   number; --插入总数
    v_remark     varchar2(2000); --备注
  begin
    v_count    := 0;
    v_allcount := 0;
    FOR POW IN (select distinct poawz.*
                  from prod_offer_attr             poa,
                       attr_spec                   a,
                       prod_offer                  po,
                       PROD_OFFER_ATTR_WIN_ZHENGCL poawz,
                       CUST_PRICE_ATTR_ZHENGCL     cpaz
                 where poa.attr_id = a.attr_id
                   and poa.prod_offer_id = po.prod_offer_id
                   and poawz.prod_offer_id = poa.prod_offer_id
                   and cpaz.attr_id = a.attr_id) LOOP
      select count(*)
        into v_cnt
        from SYS_CLASS_REL_OBJ
       where class_id = POW.Prod_Offer_Id
         and event_id = 500
         and obj_type = 'WIN'
         and area_id in (1, 2);
      if v_cnt = 0 then
        --销售品没有配置窗口页面，则从窗口开始添加
        select SEQ_SYS_WINDOW_ID.nextval into v_winid from dual;
        v_wincode := POW.Prod_Offer_Id || '-500WIN';
        v_winname := pow.prod_offer_name || '-订购';
        insert into SYS_WINDOW
          (WIN_ID,
           WIN_CODE,
           WIN_NAME,
           WIN_HINT,
           WIN_DESC,
           WIN_EXPR,
           WIN_ARGS,
           CLASS_ID,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           ROOT_COMPONET,
           WIN_URL,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           WIN_ZUL)
        values
          (v_winid,
           v_wincode,
           v_winname,
           null,
           null,
           null,
           null,
           POW.Prod_Offer_Id,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           null,
           2,
           11,
           49822,
           49822,
           null);
        insert into SYS_CLASS_REL_OBJ
          (CLASS_OBJ_RELA_ID,
           CLASS_ID,
           EVENT_ID,
           OBJ_TYPE,
           OBJ_ID,
           RELA_REGION,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           SUB_CLASS_ID,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF)
        values
          (seq_sys_class_rel_obj_id.nextval,
           POW.Prod_Offer_Id,
           500,
           'WIN',
           v_winid,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           2,
           11,
           49822,
           49822);
        v_allcount := v_allcount + 2;
        --记录日志
        v_remark := '针对订购动作导入"' || pow.prod_offer_name || '"的页面表';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'SYS_WINDOW',
           POW.Prod_Offer_Id,
           'CLASS_ID',
           'p_prodOfferAttrWinIn',
           SYSDATE,
           1,
           v_remark);
        v_remark := '针对订购动作导入"' || pow.prod_offer_name || '"的页面关联销售品表';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'SYS_CLASS_REL_OBJ',
           POW.Prod_Offer_Id,
           'CLASS_ID',
           'p_prodOfferAttrWinIn',
           SYSDATE,
           1,
           v_remark);
      elsif v_cnt = 1 then
        select obj_id
          into v_winid
          from SYS_CLASS_REL_OBJ
         where class_id = POW.Prod_Offer_Id
           and event_id = 500
           and obj_type = 'WIN'
           and area_id in (1, 2);
      else
        v_winid := 0;
      end if;
      if v_winid > 0 then
        --查询是否窗口内已经配置了客户化参数，已经配了就不用加了
        select count(*)
          into v_cnt
          from prod_offer_attr         poa,
               attr_spec               a,
               CUST_PRICE_ATTR_ZHENGCL cpaz,
               SYS_WIN_COMPONET        swc
         where poa.attr_id = a.attr_id
           and poa.prod_offer_id = POW.Prod_Offer_Id
           and cpaz.attr_id = a.attr_id
           and swc.attr_id = a.attr_id
           and swc.win_id = v_winid;
        if v_cnt = 0 then
          v_count := 0;
          --先插入表格控件
          select SEQ_SYS_WIN_COMPONET_ID.nextval
            into v_gridcompid
            from dual;
          insert into SYS_WIN_COMPONET
            (COMPONET_ID,
             ATTR_ID,
             WIN_ID,
             PARENT_COMPONET_ID,
             COMPONET_CODE,
             COMPONET_NAME,
             COMPONE_THINT,
             COMPONET_DESC,
             IS_DISPLAY,
             DISPLAY_EXPR,
             DISPLAY_WIGHT,
             DISPLAY_HEIGHT,
             DISPLAY_STYLE,
             READ_ONLY,
             DISPLAY_ORDER,
             IS_NEWLINE,
             POSITIONX,
             POSITIONY,
             BIND_EXPR,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             COMPONET_TYPE,
             PARAM1,
             PARAM2,
             COMPONET_CATALOG,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             CLASS_ID,
             PROC_DEFAULT)
          values
            (v_gridcompid,
             -1,
             v_winid,
             null,
             'GRID',
             '表格',
             null,
             null,
             1,
             null,
             null,
             null,
             'hide',
             0,
             1,
             1,
             3,
             1,
             null,
             '1000',
             sysdate,
             sysdate,
             sysdate,
             'panelgrid',
             null,
             null,
             'LAYOUT',
             2,
             11,
             49822,
             49822,
             null,
             1);
          v_count    := v_count + 1;
          v_allcount := v_allcount + 1;
          FOR poas IN (select a.*
                         from prod_offer_attr         poa,
                              attr_spec               a,
                              CUST_PRICE_ATTR_ZHENGCL cpaz
                        where poa.attr_id = a.attr_id
                          and poa.prod_offer_id = POW.Prod_Offer_Id
                          and cpaz.attr_id = a.attr_id) LOOP
            if poas.attr_type = 'T3' then
              insert into SYS_WIN_COMPONET
                (COMPONET_ID,
                 ATTR_ID,
                 WIN_ID,
                 PARENT_COMPONET_ID,
                 COMPONET_CODE,
                 COMPONET_NAME,
                 COMPONE_THINT,
                 COMPONET_DESC,
                 IS_DISPLAY,
                 DISPLAY_EXPR,
                 DISPLAY_WIGHT,
                 DISPLAY_HEIGHT,
                 DISPLAY_STYLE,
                 READ_ONLY,
                 DISPLAY_ORDER,
                 IS_NEWLINE,
                 POSITIONX,
                 POSITIONY,
                 BIND_EXPR,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 COMPONET_TYPE,
                 PARAM1,
                 PARAM2,
                 COMPONET_CATALOG,
                 AREA_ID,
                 REGION_CD,
                 UPDATE_STAFF,
                 CREATE_STAFF,
                 CLASS_ID,
                 PROC_DEFAULT)
              values
                (SEQ_SYS_WIN_COMPONET_ID.nextval,
                 poas.attr_id,
                 v_winid,
                 v_gridcompid,
                 poas.attr_cd,
                 poas.attr_name,
                 poas.attr_desc,
                 poas.attr_desc,
                 1,
                 null,
                 null,
                 null,
                 null,
                 0,
                 v_count,
                 0,
                 1,
                 1,
                 null,
                 '1000',
                 sysdate,
                 sysdate,
                 sysdate,
                 'selectlist',
                 null,
                 null,
                 'INPUT',
                 2,
                 11,
                 49822,
                 49822,
                 -6,
                 1);
            else
              insert into SYS_WIN_COMPONET
                (COMPONET_ID,
                 ATTR_ID,
                 WIN_ID,
                 PARENT_COMPONET_ID,
                 COMPONET_CODE,
                 COMPONET_NAME,
                 COMPONE_THINT,
                 COMPONET_DESC,
                 IS_DISPLAY,
                 DISPLAY_EXPR,
                 DISPLAY_WIGHT,
                 DISPLAY_HEIGHT,
                 DISPLAY_STYLE,
                 READ_ONLY,
                 DISPLAY_ORDER,
                 IS_NEWLINE,
                 POSITIONX,
                 POSITIONY,
                 BIND_EXPR,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 COMPONET_TYPE,
                 PARAM1,
                 PARAM2,
                 COMPONET_CATALOG,
                 AREA_ID,
                 REGION_CD,
                 UPDATE_STAFF,
                 CREATE_STAFF,
                 CLASS_ID,
                 PROC_DEFAULT)
              values
                (SEQ_SYS_WIN_COMPONET_ID.nextval,
                 poas.attr_id,
                 v_winid,
                 v_gridcompid,
                 poas.attr_cd,
                 poas.attr_name,
                 poas.attr_desc,
                 poas.attr_desc,
                 1,
                 null,
                 null,
                 null,
                 null,
                 0,
                 v_count,
                 0,
                 1,
                 1,
                 null,
                 '1000',
                 sysdate,
                 sysdate,
                 sysdate,
                 'text',
                 null,
                 null,
                 'INPUT',
                 2,
                 11,
                 49822,
                 49822,
                 -6,
                 1);
            end if;
            v_count    := v_count + 1;
            v_allcount := v_allcount + 1;
          END LOOP;
          v_remark := '针对订购动作导入"' || pow.prod_offer_name || '"的页面组建表';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'SYS_WIN_COMPONET',
             v_winid,
             'WIN_ID',
             'p_prodOfferAttrWinIn',
             SYSDATE,
             v_count,
             v_remark);
        end if;
      end if;
    END LOOP;
    str_msg := '导入页面显示"' || to_char(v_allcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_prodOfferAttrWinIn:' || sqlerrm;
  end;

  PROCEDURE p_prodOfferAttrBX(str_msg out VARCHAR2) is
    v_count number; --修改数
  begin
    v_count := 0;
    FOR ATS IN (select ats.*
                  from CUST_PRICE_ATTR_ZHENGCL cpaz, attr_spec ats
                 where cpaz.attr_id = ats.attr_id
                   and (ats.is_nullable is null or ats.is_nullable != '1')) LOOP
      insert into ATTR_SPEC_HIS
        (HIS_ID,
         ATTR_ID,
         ATTR_CD,
         ATTR_NAME,
         ATTR_DESC,
         ATTR_VALUE_TYPE,
         DEFAULT_VALUE,
         VALUE_FROM,
         VALUE_TO,
         IS_UNIQUE,
         IS_NULLABLE,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         CLASS_ID,
         ATTR_TYPE,
         JAVA_CODE,
         ATTR_SEQ,
         CNS_TYPE,
         REF_CLASS_ID,
         ATTR_LEVEL,
         IS_DANY_ATTR,
         IS_MULTI_VALUE,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         IS_PRINT,
         ATTR_LENGTH,
         CODE_BUILDER,
         CODE_PARAM1,
         COMPLETE_FLAG,
         VISIBLE_FLAG,
         ATTR_FORMAT,
         CNS_TYPE_EXTRA,
         IS_POST,
         EXPIRE_TYPE,
         HB_POST,
         EXT_ATTR_NBR,
         DEFAULT_TIME_PERIOD)
      values
        (SEQ_ATTR_SPEC_HIS_ID.NEXTVAL,
         ATS.ATTR_ID,
         ATS.ATTR_CD,
         ATS.ATTR_NAME,
         ATS.ATTR_DESC,
         ATS.ATTR_VALUE_TYPE,
         ATS.DEFAULT_VALUE,
         ATS.VALUE_FROM,
         ATS.VALUE_TO,
         ATS.IS_UNIQUE,
         ATS.IS_NULLABLE,
         ATS.STATUS_CD,
         ATS.STATUS_DATE,
         ATS.CREATE_DATE,
         ATS.CLASS_ID,
         ATS.ATTR_TYPE,
         ATS.JAVA_CODE,
         ATS.ATTR_SEQ,
         ATS.CNS_TYPE,
         ATS.REF_CLASS_ID,
         ATS.ATTR_LEVEL,
         ATS.IS_DANY_ATTR,
         ATS.IS_MULTI_VALUE,
         ATS.AREA_ID,
         ATS.REGION_CD,
         ATS.UPDATE_STAFF,
         ATS.CREATE_STAFF,
         ATS.IS_PRINT,
         ATS.ATTR_LENGTH,
         ATS.CODE_BUILDER,
         ATS.CODE_PARAM1,
         ATS.COMPLETE_FLAG,
         ATS.VISIBLE_FLAG,
         ATS.ATTR_FORMAT,
         ATS.CNS_TYPE_EXTRA,
         ATS.IS_POST,
         ATS.EXPIRE_TYPE,
         ATS.HB_POST,
         ATS.EXT_ATTR_NBR,
         ATS.DEFAULT_TIME_PERIOD);
      update attr_spec set is_nullable = '1' where attr_id = ats.attr_id;
      v_count := v_count + 1;
    END LOOP;
    str_msg := '修改客户化参数属性为必选"' || to_char(v_count) || '"条数据';
    insert into CRM1_CFG_SYNC
      (ID,
       TABLE_NAME,
       OBJ_ID,
       OBJ_TYPE,
       SYNC_METHO,
       SYNC_DATE,
       SYNC_COUNT,
       REMARK)
    values
      (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
       'ATTR_SPEC',
       0,
       '0',
       'p_prodOfferAttrBX',
       SYSDATE,
       v_count,
       str_msg);
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_prodOfferAttrBX:' || sqlerrm;
  end;

  PROCEDURE p_prodOfferAttrMRQZ(str_msg out VARCHAR2) is
    v_count number; --修改数
  begin
    v_count := 0;
    FOR AllPoa IN (select poa.prod_offer_attr_id
                     from CUST_PRICE_ATTR_ZHENGCL cpaz,
                          prod_offer_attr         poa,
                          attr_spec               ats,
                          prod_offer_attr_Value   poav
                    where cpaz.attr_id = poa.attr_id
                      and ats.attr_id = poa.attr_id
                      and ats.attr_type = 'T3'
                      and poa.prod_offer_attr_id = poav.prod_offer_attr_id
                    group by poa.prod_offer_attr_id
                   having count(*) = 1) LOOP
      FOR Poa IN (SELECT poa.*,
                         ats.attr_name,
                         atv.attr_value_id,
                         atv.attr_value_name,
                         atv.attr_value
                    FROM prod_offer_attr       poa,
                         attr_spec             ats,
                         prod_offer_attr_value poav,
                         attr_value            atv
                   where poa.prod_offer_attr_id = AllPoa.Prod_Offer_Attr_Id
                     and poa.attr_id = ats.attr_id
                     and poa.prod_offer_attr_id = poav.prod_offer_attr_id
                     and atv.attr_value_id = poav.attr_value_id) LOOP
        if (Poa.Default_Value is null) or
           (Poa.Default_Value is not null and
           Poa.Default_Value <> Poa.attr_value) then
          insert into PROD_OFFER_ATTR_HIS
            (HIS_ID,
             PROD_OFFER_ATTR_ID,
             PROD_OFFER_ID,
             ATTR_ID,
             DEFAULT_VALUE,
             MIN_VALUE,
             MAX_VALUE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF)
          values
            (SEQ_PROD_OFFER_ATTR_HIS_ID.Nextval,
             Poa.PROD_OFFER_ATTR_ID,
             Poa.PROD_OFFER_ID,
             Poa.ATTR_ID,
             Poa.DEFAULT_VALUE,
             Poa.MIN_VALUE,
             Poa.MAX_VALUE,
             Poa.STATUS_CD,
             Poa.STATUS_DATE,
             Poa.CREATE_DATE,
             Poa.UPDATE_DATE,
             Poa.AREA_ID,
             Poa.REGION_CD,
             Poa.UPDATE_STAFF,
             Poa.CREATE_STAFF);
          update PROD_OFFER_ATTR
             set Default_Value = Poa.Attr_Value, Update_Date = sysdate
           where PROD_OFFER_ATTR_ID = Poa.Prod_Offer_Attr_Id;
          v_count := v_count + 1;
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_OFFER_ATTR',
             Poa.Prod_Offer_Attr_Id,
             'PROD_OFFER_ATTR_ID',
             'p_prodOfferAttrMRQZ',
             SYSDATE,
             1,
             str_msg);
        end if;
      END LOOP;
    END LOOP;
    str_msg := '修改销售品客户化参数属性默认值"' || to_char(v_count) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_prodOfferAttrMRQZ:' || sqlerrm;
  end;

  PROCEDURE p_minusTable(i_tablename in VARCHAR2, --1.0的表名
                         i_tablekey  in VARCHAR2, --1.0的表对应主键
                         str_msg     out VARCHAR2) is
    v_cnt            number;
    v_count          number;
    v_tablename      VARCHAR2(100); --要同步的配置表 例如 MDSE_SPEC_RELA
    v_crm1tablename  VARCHAR2(100); --旧数据表：CRM2.0备份过来的1.0同名配置表 例如 O_MDSE_SPEC_RELA
    v_nowtablename   VARCHAR2(100); --新数据表：CRM2.0备份过来的1.0同名最新配置表 例如 N_MDSE_SPEC_RELA
    v_minustablename VARCHAR2(100); --差异表 例如 M_MDSE_SPEC_RELA
    v_tablekey       VARCHAR2(20);
    v_sql            VARCHAR2(2000);
    v_type           number; --标示表是CRM还是计费, by niud, 120213
  begin
    v_tablekey       := upper(i_tablekey);
    v_tablename      := upper(i_tablename);
    v_crm1tablename  := 'O_' || v_tablename;
    v_minustablename := 'M_' || v_tablename;
    v_nowtablename   := 'N_' || v_tablename;

    select count(*)
      into v_cnt
      from sync_server_table@lk_crmv1
     where table_name = v_tablename;
    if v_cnt = 0 then
      /*增加计费定价客餐的几张表的配置比对, by niud, 120213*/
      select count(*)
        into v_cnt
        from sync_server_table
       where table_name = v_tablename;
      if v_cnt = 0 then
        str_msg := '处理的表' || i_tablename || '不是配置表,请确认!';
        return;
      else
        v_type := 2; --计费表
      end if;
    else
      v_type := 1; --CRM表
    end if;
    v_tablename := v_tablename || '@lk_crmv1'; --目前先加用测链接，之后可以改成生产链接
    if v_type = 2 then
      v_tablename := 'bill.' || v_tablename; --计费属主, by niud, 120213
    end if;
    --判断是否存在差异表，如果没用就新建一个，有的话将数据清空掉
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_minustablename;
    if v_cnt = 0 then
      v_sql := 'create table ' || v_minustablename || ' as select * from ' ||
               v_tablename || ' where 1=2';
      execute immediate v_sql;
    else
      v_sql := 'delete from ' || v_minustablename;
      execute immediate v_sql;
      --删除字段MINUS_OP
      v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
               v_minustablename || ''' and column_name =''MINUS_OP''';
      execute immediate v_sql
        into v_cnt;
      if v_cnt = 1 then
        v_sql := 'ALTER TABLE ' || v_minustablename ||
                 ' drop column MINUS_OP';
        execute immediate v_sql;
      end if;
      --删除字段SYNC_OP
      v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
               v_minustablename || ''' and column_name =''SYNC_OP''';
      execute immediate v_sql
        into v_cnt;
      if v_cnt = 1 then
        v_sql := 'ALTER TABLE ' || v_minustablename ||
                 ' drop column SYNC_OP';
        execute immediate v_sql;
      end if;
    end if;
    --判断传入的键是否存在表，不存在直接报错
    v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
             v_minustablename || ''' and column_name =''' || v_tablekey || '''';
    execute immediate v_sql
      into v_cnt;
    if v_cnt = 0 then
      str_msg := v_tablekey || '不是配置表' || i_tablename || '上的字段,请确认!';
      return;
    end if;

    --同步最新的数据
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_nowtablename;
    if v_cnt = 0 then
      v_sql := 'create table ' || v_nowtablename || ' as select * from ' ||
               v_tablename;
      execute immediate v_sql;
    else
      v_sql := 'delete from ' || v_nowtablename;
      execute immediate v_sql;
      v_sql := 'insert into ' || v_nowtablename || ' select * from ' ||
               v_tablename;
      execute immediate v_sql;
    end if;
    --判断是否存在配置表，如果没有就直接从最新表里面复制创建一个
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_crm1tablename;
    if v_cnt = 0 then
      v_sql := 'create table ' || v_crm1tablename || ' as select * from ' ||
               v_nowtablename;
      execute immediate v_sql;
    end if;
    --比对最新数据表与配置表的差异数据
    --1.要删除的数据导入差异表
    v_sql := 'INSERT INTO ' || v_minustablename || ' select * from ' ||
             v_crm1tablename || ' o where not exists (select 1 from ' ||
             v_nowtablename || ' where ' || v_tablekey || '=o.' ||
             v_tablekey || ')';
    execute immediate v_sql;
    --2.要新增的数据导入差异表
    v_sql := 'INSERT INTO ' || v_minustablename || ' select * from ' ||
             v_nowtablename || ' n where not exists (select 1 from ' ||
             v_crm1tablename || ' where ' || v_tablekey || '=n.' ||
             v_tablekey || ')';
    execute immediate v_sql;
    --3.变更的数据导入差异表
    v_sql := 'INSERT INTO ' || v_minustablename || ' select * from ' ||
             v_nowtablename || ' n where exists (select 1 from ' ||
             v_crm1tablename || ' where ' || v_tablekey || '=n.' ||
             v_tablekey || ') minus select * from ' || v_crm1tablename;
    execute immediate v_sql;

    --对差异表增加一个字段来判断操作类型
    v_sql := 'ALTER TABLE ' || v_minustablename ||
             ' ADD MINUS_OP VARCHAR2(6)';
    execute immediate v_sql;
    --对之前导入的数据置操作类型
    --1.删除DEL
    v_sql := 'update ' || v_minustablename ||
             ' set MINUS_OP=''DEL'' where ' || v_tablekey || ' in( select ' ||
             v_tablekey || ' from ' || v_crm1tablename ||
             ' o where not exists (select 1 from ' || v_nowtablename ||
             ' where ' || v_tablekey || '=o.' || v_tablekey || '))';
    execute immediate v_sql;
    --2.新增ADD
    v_sql := 'update ' || v_minustablename ||
             ' set MINUS_OP=''ADD'' where ' || v_tablekey || ' in( select ' ||
             v_tablekey || ' from ' || v_nowtablename ||
             ' n where not exists (select 1 from ' || v_crm1tablename ||
             ' where ' || v_tablekey || '=n.' || v_tablekey || '))';
    execute immediate v_sql;
    --3.变更UPDATE
    v_sql := 'update ' || v_minustablename ||
             ' set MINUS_OP=''UPDATE'' where ' || v_tablekey ||
             ' in( select ' || v_tablekey || '  from (select * from ' ||
             v_nowtablename || ' n where exists (select 1 from ' ||
             v_crm1tablename || ' where ' || v_tablekey || '=n.' ||
             v_tablekey || ') minus select * from ' || v_crm1tablename ||
             ') a)';
    execute immediate v_sql;

    --对差异表再增加一个是否同步的字段来判断是否已经将新数据同步给旧数据了
    v_sql := 'ALTER TABLE ' || v_minustablename ||
             ' ADD SYNC_OP VARCHAR2(1)';
    execute immediate v_sql;
    v_sql := 'update ' || v_minustablename || ' set SYNC_OP=''N''';
    execute immediate v_sql;

    v_sql := 'select count(*) from ' || v_minustablename;
    execute immediate v_sql
      into v_count;
    str_msg := i_tablename || '与本地表相比,有差异' || to_char(v_count) || '条数据';
    insert into CRM1_CFG_SYNC
      (ID,
       TABLE_NAME,
       OBJ_ID,
       OBJ_TYPE,
       SYNC_METHO,
       SYNC_DATE,
       SYNC_COUNT,
       REMARK)
    values
      (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
       v_minustablename,
       0,
       0,
       'p_minusTable',
       SYSDATE,
       v_count,
       str_msg);

  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_minusTable:' || sqlerrm;
  end;

  PROCEDURE p_minusJoinTable(i_tablename in VARCHAR2, --1.0的表名
                             i_tablekey  in VARCHAR2, --1.0的表对应主键
                             str_msg     out VARCHAR2) is
    v_cnt            number;
    v_count          number;
    v_tablename      VARCHAR2(100); --要同步的配置表 例如 MDSE_SPEC_RELA
    v_crm1tablename  VARCHAR2(100); --旧数据表：CRM2.0备份过来的1.0同名配置表 例如 O_MDSE_SPEC_RELA
    v_nowtablename   VARCHAR2(100); --新数据表：CRM2.0备份过来的1.0同名最新配置表 例如 N_MDSE_SPEC_RELA
    v_minustablename VARCHAR2(100); --差异表 例如 M_MDSE_SPEC_RELA
    v_temptablename  VARCHAR2(100); --临时表 例如 T_MDSE_SPEC_RELA
    v_tablekey       VARCHAR2(20);
    v_sql            VARCHAR2(2000);
  begin
    v_tablekey       := upper(i_tablekey);
    v_tablename      := upper(i_tablename);
    v_crm1tablename  := 'O_' || v_tablename;
    v_minustablename := 'M_' || v_tablename;
    v_nowtablename   := 'N_' || v_tablename;
    v_temptablename  := 'T_' || v_tablename;

    --判断新数据表，旧数据表，差异数据表是否存在
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_nowtablename;
    if v_cnt = 0 then
      str_msg := '不存在新数据表' || v_nowtablename || ',请确认!';
      return;
    end if;
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_crm1tablename;
    if v_cnt = 0 then
      str_msg := '不存在旧数据表' || v_crm1tablename || ',请确认!';
      return;
    end if;
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_minustablename;
    if v_cnt = 0 then
      str_msg := '不存在差异表' || v_minustablename || ',请确认!';
      return;
    end if;

    --临时表处理
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_temptablename;
    if v_cnt > 0 then
      v_sql := 'drop table ' || v_temptablename;
      execute immediate v_sql;
    end if;
    v_sql := 'create table ' || v_temptablename || ' as select * from ' ||
             v_minustablename || ' where sync_op=''N''';
    execute immediate v_sql;

    --删除字段MINUS_OP
    v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
             v_temptablename || ''' and column_name =''MINUS_OP''';
    execute immediate v_sql
      into v_cnt;
    if v_cnt = 1 then
      v_sql := 'ALTER TABLE ' || v_temptablename || ' drop column MINUS_OP';
      execute immediate v_sql;
    end if;
    --删除字段SYNC_OP
    v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
             v_temptablename || ''' and column_name =''SYNC_OP''';
    execute immediate v_sql
      into v_cnt;
    if v_cnt = 1 then
      v_sql := 'ALTER TABLE ' || v_temptablename || ' drop column SYNC_OP';
      execute immediate v_sql;
    end if;

    --根据差异表操作类型处理旧数据
    --1.要新增的数据导入旧数据表
    v_sql := 'INSERT INTO ' || v_crm1tablename || ' select * from ' ||
             v_temptablename || ' t where exists (select 1 from ' ||
             v_minustablename ||
             ' where  minus_op=''ADD'' and sync_op=''N'' and ' ||
             v_tablekey || '=t.' || v_tablekey || ')';
    execute immediate v_sql;
    --2.要删除的数据从旧数据表去掉
    v_sql := 'DELETE FROM ' || v_crm1tablename ||
             ' o where exists (select 1 from ' || v_minustablename ||
             ' where  sync_op=''N'' and minus_op=''DEL'' and ' ||
             v_tablekey || '=o.' || v_tablekey || ')';
    execute immediate v_sql;
    --3.变更的数据,先从旧数据表删除后，再将新数据导入
    v_sql := 'DELETE FROM ' || v_crm1tablename ||
             ' o where exists (select 1 from ' || v_minustablename ||
             ' where  sync_op=''N'' and minus_op=''UPDATE'' and ' ||
             v_tablekey || '=o.' || v_tablekey || ')';
    execute immediate v_sql;
    v_sql := 'INSERT INTO ' || v_crm1tablename || ' select * from ' ||
             v_temptablename || ' t where exists (select 1 from ' ||
             v_minustablename ||
             ' where  minus_op=''UPDATE'' and sync_op=''N'' and ' ||
             v_tablekey || '=t.' || v_tablekey || ')';
    execute immediate v_sql;

    v_sql := 'select count(*) from ' || v_minustablename ||
             ' where sync_op=''N''';
    execute immediate v_sql
      into v_count;
    --处理完差异数据后，将处理的数据SYNC_OP置为Y
    v_sql := 'update ' || v_minustablename ||
             ' set SYNC_OP=''Y'' where SYNC_OP=''N'' ';
    execute immediate v_sql;

    str_msg := v_crm1tablename || '已经合并处理了最新的' || to_char(v_count) || '条数据';
    insert into CRM1_CFG_SYNC
      (ID,
       TABLE_NAME,
       OBJ_ID,
       OBJ_TYPE,
       SYNC_METHO,
       SYNC_DATE,
       SYNC_COUNT,
       REMARK)
    values
      (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
       v_minustablename,
       0,
       0,
       'p_minusJoinTable',
       SYSDATE,
       v_count,
       str_msg);

  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_minusJoinTable:' || sqlerrm;
  end;

  PROCEDURE p_allMdseSpecPriceRelaIn(str_msg out VARCHAR2) is
    v_cnt              number; --是否存在数据
    v_count            number; --数据
    v_allcount         number; --总数据
    v_upcount          number; --修改数据
    v_delcount         number; --删除数据
    v_upallcount       number; --修改总数据
    v_delallcount      number; --删除总数据
    v_remark           varchar2(2000); --备注
    v_oldprodofferid   number; --旧的销售品Id
    v_oldprodoffername varchar2(100); --旧的销售品名称
  begin
    v_oldprodoffername := '';
    v_oldprodofferid   := 0;
    v_count            := 0;
    v_allcount         := 0;
    v_upcount          := 0;
    v_delcount         := 0;
    v_upallcount       := 0;
    v_delallcount      := 0;
    FOR KXPO in (select po1.prod_offer_id   JC_PROD_OFFER_ID,
                        po1.prod_offer_name JC_PROD_OFFER_NAME,
                        po2.prod_offer_id   KXB_PROD_OFFER_ID,
                        po2.prod_offer_name KXB_PROD_OFFER_NAME
                   from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm,
                        price_plan@lk_crmv1                  pp,
                        mdse_spec@lk_crmv1                   ms,
                        mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                        mdse_ys_lisy_new                     myx2, ---取新的规格映射表（modify by lisy）
                        prod_offer                           po1,
                        prod_offer                           po2
                  where pm.price_id = pp.price_id
                    and pp.state = '70A'
                    and pm.mdse_spec_id = ms.mdse_spec_id
                    and pm.rela_type = '101'
                    and pm.cfg_area_id between 3 and 10
                    and pp.price_id = myx2.id_v1
                    and myx2.id_v2 = po2.prod_offer_id
                    and ((po2.OFFER_TYPE = '12' and
                        po2.OFFER_SUB_TYPE = 'T04') or
                        po2.OFFER_TYPE = '13') --1.0基本套餐落地2.0为可选包或者促销包
                    and ms.mdse_spec_id = myx1.id_v1
                    and myx1.id_v2 = po1.prod_offer_id
                    and po1.offer_type = '10' --1.0销售品落地2.0为基础销售品
                  order by po1.prod_offer_id, po2.prod_offer_id) LOOP
      --导入数据日志记录
      if v_oldprodofferid = 0 or (v_oldprodofferid > 0 and
         v_oldprodofferid != KXPO.Jc_Prod_Offer_Id) then
        if v_oldprodofferid > 0 and v_count > 0 then
          v_remark := '1.0销售品"' || v_oldprodoffername ||
                      '"基本套餐关联数据,导入2.0销售品关联可选包数据';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_OFFER_REL',
             v_oldprodofferid,
             'OFFER_A_ID',
             'p_allMdseSpecPriceRelaIn',
             SYSDATE,
             v_count,
             v_remark);
        end if;
        v_oldprodofferid   := KXPO.Jc_Prod_Offer_Id;
        v_oldprodoffername := KXPO.Jc_Prod_Offer_Name;
        v_count            := 0;
      end if;
      --判断是否已经有可选关联数据
      select count(*)
        into v_cnt
        from prod_offer_rel por
       where por.offer_a_id = KXPO.JC_PROD_OFFER_ID
         and por.offer_z_id = KXPO.KXB_PROD_OFFER_ID
         and por.relation_type_cd = '100000';
      if v_cnt = 0 then
        insert into PROD_OFFER_REL
          (PROD_OFFER_RELA_ID,
           OFFER_A_ID,
           OFFER_Z_ID,
           ROLE_CD,
           RELATION_TYPE_CD,
           EFF_DATE,
           EXP_DATE,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           HOT_SPOT_NO,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           SYNC_CUST,
           EFFECTIVE_TYPE,
           DEFAULT_TIME_PERIOD,
           EXPIRE_TYPE,
           RULE_TYPE)
        values
          (SEQ_PROD_OFFER_REL_ID.Nextval,
           KXPO.JC_PROD_OFFER_ID,
           KXPO.KXB_PROD_OFFER_ID,
           null,
           '100000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           null,
           null,
           1,
           1,
           49822,
           49822,
           null,
           null,
           null,
           null,
           null);
        v_count    := v_count + 1;
        v_allcount := v_allcount + 1;
      end if;
    END LOOP;
    --日志记录
    if v_oldprodofferid > 0 and v_count > 0 then
      v_remark := '1.0销售品"' || v_oldprodoffername ||
                  '"基本套餐关联数据,导入2.0销售品关联可选包数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         v_oldprodofferid,
         'OFFER_A_ID',
         'p_allMdseSpecPriceRelaIn',
         SYSDATE,
         v_count,
         v_remark);
    end if;
    v_oldprodofferid   := 0;
    v_oldprodoffername := '';
    FOR DKX IN (select por.*, po1.prod_offer_name
                  from prod_offer_rel por, prod_offer po1, prod_offer po2
                 where por.offer_a_id = po1.prod_offer_id
                   and por.offer_z_id = po2.prod_offer_id
                   and (((po1.OFFER_TYPE = '12' and
                       po1.OFFER_SUB_TYPE = 'T04') or
                       po1.OFFER_TYPE = '13') or
                       (po2.offer_type = '10' and po2.offer_type = '11'))
                   AND por.relation_type_cd = '100000'
                 order by po1.prod_offer_id) LOOP
      if v_oldprodofferid = 0 or
         (v_oldprodofferid > 0 and v_oldprodofferid != DKX.offer_a_id) then
        if v_oldprodofferid > 0 and v_upcount > 0 then
          v_remark := '1.0销售品"' || v_oldprodoffername ||
                      '"可选关联数据,因为销售品类型不符合,要置为失效状态';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_OFFER_REL',
             v_oldprodofferid,
             'OFFER_A_ID',
             'p_allMdseSpecPriceRelaIn',
             SYSDATE,
             v_upcount,
             v_remark);
        end if;
        if v_oldprodofferid > 0 and v_delcount > 0 then
          v_remark := '1.0销售品"' || v_oldprodoffername ||
                      '"可选关联数据,因为销售品类型不符合,要删除关系数据';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PROD_OFFER_REL',
             v_oldprodofferid,
             'OFFER_A_ID',
             'p_allMdseSpecPriceRelaIn',
             SYSDATE,
             v_delcount,
             v_remark);
        end if;
        v_oldprodofferid   := DKX.offer_a_id;
        v_oldprodoffername := DKX.prod_offer_name;
        v_upcount          := 0;
        v_delcount         := 0;
      end if;

      select count(*)
        into v_cnt
        from prod_offer_inst_rel poir
       where poir.prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
      if v_cnt > 0 then
        --已经生成实例的数据，修改状态，原数据入历史表
        if DKX.Status_Cd != '1100' then
          insert into PROD_OFFER_REL_HIS
            (HIS_ID,
             PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_HIS_ID.Nextval,
             DKX.PROD_OFFER_RELA_ID,
             DKX.OFFER_A_ID,
             DKX.OFFER_Z_ID,
             DKX.ROLE_CD,
             DKX.RELATION_TYPE_CD,
             DKX.EFF_DATE,
             DKX.EXP_DATE,
             DKX.STATUS_CD,
             DKX.STATUS_DATE,
             DKX.CREATE_DATE,
             DKX.UPDATE_DATE,
             DKX.HOT_SPOT_NO,
             DKX.AREA_ID,
             DKX.REGION_CD,
             DKX.UPDATE_STAFF,
             DKX.CREATE_STAFF,
             DKX.SYNC_CUST,
             DKX.EFFECTIVE_TYPE,
             DKX.DEFAULT_TIME_PERIOD,
             DKX.EXPIRE_TYPE,
             DKX.RULE_TYPE);
          update PROD_OFFER_REL
             set status_cd = '1100', update_date = sysdate
           where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
          v_upcount    := v_upcount + 1;
          v_upallcount := v_upallcount + 1;
        end if;
      else
        delete from PROD_OFFER_REL
         where prod_offer_rela_id = DKX.PROD_OFFER_RELA_ID;
        v_delcount    := v_delcount + 1;
        v_delallcount := v_delallcount + 1;
      end if;
    END LOOP;
    if v_oldprodofferid > 0 and v_upcount > 0 then
      v_remark := '1.0销售品"' || v_oldprodoffername ||
                  '"可选关联数据,因为销售品类型不符合,要置为失效状态';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         v_oldprodofferid,
         'OFFER_A_ID',
         'p_allMdseSpecPriceRelaIn',
         SYSDATE,
         v_upcount,
         v_remark);
    end if;
    if v_oldprodofferid > 0 and v_delcount > 0 then
      v_remark := '1.0销售品"' || v_oldprodoffername ||
                  '"可选关联数据,因为销售品类型不符合,要删除关系数据';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         v_oldprodofferid,
         'OFFER_A_ID',
         'p_allMdseSpecPriceRelaIn',
         SYSDATE,
         v_delcount,
         v_remark);
    end if;
    str_msg := '导入PROD_OFFER_REL:' || to_char(v_allcount) || '条数据，修改' ||
               to_char(v_upallcount) || '条数据，删除' || to_char(v_delallcount) ||
               '条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := '导入PROD_OFFER_REL数据失败p_allMdseSpecPriceRelaIn:' || sqlerrm;
  end;

  PROCEDURE p_eHome_KXB_Prod_rel(i_preferspecid in number,str_msg out VARCHAR2) is
    vcount number;
  begin
 ---1. 获取e家基础包上的适用套餐落地为可选包，且在1.0中有配置适用分组 针对基础包固话、宽带、移动语音、小灵通
 for voffer in (select a.prod_offer_rela_id prod_offer_rela_id,
                 c.offer_prod_rela_id offer_prod_rela_id
        from prod_offer_rel a,
       (select distinct po1.prod_offer_id e_prod_offer_id,
                        po1.prod_offer_name e_prod_offer_name,
                        po.prod_offer_id kxb_prod_offer_id,
                        po.prod_offer_name kxb_prod_offer_name,
                        pmz.product_id,
                        pmz.product_name
          from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
               prefer_mdse_spec_rela@lk_crmv1       pmsr,
               mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
               prod_offer                           po,
               mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
               prod_offer                           po1,
               pm_extend_restrict@lk_crmv1          per,
               prod_map_zhengcl                     pmz
         where pmpsr.rela_mdse_id = pmsr.rela_id
           and pmsr.prefer_spec_id = i_preferspecid  --1.0e家销售品id
           and pmsr.role_type = '001' --基础包
           and pmpsr.cfg_area_id in (1, 2)
           and pmpsr.state = '70A'
           and myx.id_v1 = pmpsr.price_id
           and myx.id_v2 = po.prod_offer_id
           and po.offer_type = '12'
           and po.offer_sub_type = 'T04'
           and myx1.id_v1 = i_preferspecid  --1.0e家销售品id
           and myx1.id_v2 = po1.prod_offer_id
           and po1.offer_type = '11'
           and po1.offer_sub_type = 'T01'
           and pmpsr.rela_id = per.obj_id
           and per.restrict_type = '174'
           and per.obj_type = 'TCSPGL'
           and per.restrict_value = pmz.group_type
           and po.status_cd <> '1100'
           and pmz.product_id in
               (800000000, 800000002, 800000008, 800000003)) b,
       offer_prod_rel c
 where a.offer_a_id = b.e_prod_offer_id
   and a.offer_z_id = b.kxb_prod_offer_id
   and a.status_cd = '1000'
   and b.product_id = c.product_id
   and b.e_prod_offer_id = c.prod_offer_id
   and c.role_cd in (1, 2, 3, 2187)
   and c.status_cd = '1000') loop

  select count(*) into vcount from offer_rel_restrict_prod where offer_prod_rela_id=voffer.offer_prod_rela_id and prod_offer_rela_id=voffer.prod_offer_rela_id;
  if vcount=0 then
   insert into offer_rel_restrict_prod
    values
   (SEQ_OFFER_REL_RESTRICT_PROD_ID.NEXTVAL,
    voffer.offer_prod_rela_id,
    voffer.prod_offer_rela_id,
    null,
    16,
    sysdate,
    2,
    11,
    '1000',
    sysdate,
    49822,
    sysdate,
    49822,
    '12');
    end if;
end loop;
    commit;
  --2.获取e家天翼共享包上的适用套餐落地为可选包,过滤掉存在基础包中无分组可选包-------
      --2223天翼共享包（停售）/2224 10版天翼共享包/2225 天翼共享包（新）

for voffer in (
 select a.prod_offer_rela_id prod_offer_rela_id,
        c.offer_prod_rela_id offer_prod_rela_id
   from prod_offer_rel a,
        (select distinct po1.prod_offer_id e_prod_offer_id,
                         po1.prod_offer_name e_prod_offer_name,
                         po.prod_offer_id kxb_prod_offer_id,
                         po.prod_offer_name kxb_prod_offer_name,
                         800000002 product_id,
                         '移动语音' product_name
           from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                prefer_mdse_spec_rela@lk_crmv1       pmsr,
                mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                prod_offer                           po,
                mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                prod_offer                           po1
          where pmpsr.rela_mdse_id = pmsr.rela_id
            and pmsr.prefer_spec_id = i_preferspecid --1.0e家销售品id
            and pmsr.name like '%天翼共享包%'
            and pmpsr.cfg_area_id in (1, 2)
            and pmpsr.state = '70A'
            and myx.id_v1 = pmpsr.price_id
            and myx.id_v2 = po.prod_offer_id
            and po.offer_type = '12'
            and po.offer_sub_type = 'T04'
            and myx1.id_v1 = i_preferspecid --1.0e家销售品id
            and myx1.id_v2 = po1.prod_offer_id
            and po1.offer_type = '11'
            and po1.offer_sub_type = 'T01'
            and po.prod_offer_id not in (
             select distinct
                             po.prod_offer_id    KXB_PROD_OFFER_ID
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.role_type = '001' --基础包
                         and pmpsr.cfg_area_id in (1, 2)
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                         and not exists
                        (select obj_id
                                from pm_extend_restrict@lk_crmv1 per
                               where per.restrict_type = '174'
                                 and per.obj_type = 'TCSPGL'
                                 and per.obj_id = pmpsr.rela_id))) b,
        offer_prod_rel c
  where a.offer_a_id = b.e_prod_offer_id
    and a.offer_z_id = b.kxb_prod_offer_id
    and a.status_cd = '1000'
    and b.product_id = c.product_id
    and b.e_prod_offer_id = c.prod_offer_id
    and c.role_cd in (2223, 2224, 2225)
    and c.status_cd = '1000') loop

  select count(*) into vcount from offer_rel_restrict_prod where offer_prod_rela_id=voffer.offer_prod_rela_id and prod_offer_rela_id=voffer.prod_offer_rela_id;
  if vcount=0 then
   insert into offer_rel_restrict_prod
    values
   (SEQ_OFFER_REL_RESTRICT_PROD_ID.NEXTVAL,
    voffer.offer_prod_rela_id,
    voffer.prod_offer_rela_id,
    null,
    16,
    sysdate,
    2,
    11,
    '1000',
    sysdate,
    49822,
    sysdate,
    49822,
    '12');
    end if;
 end loop;
 commit;
 --3.获取e家小灵通可选包和超无包上的适用套餐落地为可选包,过滤掉存在基础包中无分组可选包
 for voffer in (select a.prod_offer_rela_id prod_offer_rela_id,
        c.offer_prod_rela_id offer_prod_rela_id
   from prod_offer_rel a,
        (select distinct po1.prod_offer_id e_prod_offer_id,
                         po1.prod_offer_name e_prod_offer_name,
                         po.prod_offer_id kxb_prod_offer_id,
                         po.prod_offer_name kxb_prod_offer_name,
                         800000003 product_id,
                          '小灵通' product_name
           from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                prefer_mdse_spec_rela@lk_crmv1       pmsr,
                mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                prod_offer                           po,
                mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                prod_offer                           po1
          where pmpsr.rela_mdse_id = pmsr.rela_id
            and pmsr.prefer_spec_id = i_preferspecid --1.0e家销售品id
            and pmsr.name in ('小灵通可选包','超无包')
            and pmpsr.cfg_area_id in (1, 2)
            and pmpsr.state = '70A'
            and myx.id_v1 = pmpsr.price_id
            and myx.id_v2 = po.prod_offer_id
            and po.offer_type = '12'
            and po.offer_sub_type = 'T04'
            and myx1.id_v1 = i_preferspecid --1.0e家销售品id
            and myx1.id_v2 = po1.prod_offer_id
            and po1.offer_type = '11'
            and po1.offer_sub_type = 'T01'
            and po.prod_offer_id not in (
             select distinct
                             po.prod_offer_id    KXB_PROD_OFFER_ID
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.role_type = '001' --基础包
                         and pmpsr.cfg_area_id in (1, 2)
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                         and not exists
                        (select obj_id
                                from pm_extend_restrict@lk_crmv1 per
                               where per.restrict_type = '174'
                                 and per.obj_type = 'TCSPGL'
                                 and per.obj_id = pmpsr.rela_id))) b,
        offer_prod_rel c
  where a.offer_a_id = b.e_prod_offer_id
    and a.offer_z_id = b.kxb_prod_offer_id
    and a.status_cd = '1000'
    and b.product_id = c.product_id
    and b.e_prod_offer_id = c.prod_offer_id
    and c.role_cd in (2943,2944)
    and c.status_cd = '1000') loop
   select count(*) into vcount from offer_rel_restrict_prod where offer_prod_rela_id=voffer.offer_prod_rela_id and prod_offer_rela_id=voffer.prod_offer_rela_id;
  if vcount=0 then
   insert into offer_rel_restrict_prod
    values
   (SEQ_OFFER_REL_RESTRICT_PROD_ID.NEXTVAL,
    voffer.offer_prod_rela_id,
    voffer.prod_offer_rela_id,
    null,
    16,
    sysdate,
    2,
    11,
    '1000',
    sysdate,
    49822,
    sysdate,
    49822,
    '12');
    end if;
 end loop;
 commit;
 EXCEPTION
    WHEN OTHERS THEN
      str_msg := '导入offer_rel_restrict_prod数据失败p_eHome_KXB_Prod_rel:' || sqlerrm;
  end p_eHome_KXB_Prod_rel;
end PKG_CRM2_CFG_IN_AREA;
/
