CREATE PACKAGE           PK_CRM1_TO_CRM2_DATA_GJ IS

  -- Author  : CHENDZH
  -- Created : 2011-02-14
  -- Purpose : CRM2.0入围测试档案数据割接
  -- Create Version: 1.0.0.0
  -- Modify Date :

  -- 输入参数:
  --
  -- 输出参数:
  --  　　 o_err_id  out  number：错误编码
  --　    o_err_msg  out  number：错误信息
  -- 备注:
  --     在割接程序运行时，如果想中断程序运行，请执行以下语句：!!!!!!!!!!!!!
  --               UPDATE archive_gj_log
  --                  SET state='T'                --'T': 中断割接,退出割接
  --                WHERE table_name=:tab_name;    --过程中定义的处理表名
  --               COMMIT;
  --
  --     在数据倒换之前，请确认以下表是否存在且数据是否准确:
  --        1. archive_gj_code_conv 新旧代码转换表，必须跟据实际情况生成数据!!!!!!
  --        2. archive_gj_log  割接过程日志记录表，没有则创建!!!!!!
  --        3. archive_gj_err_log 割接过程错误信息记录表，没有则创建!!!!!!
  --        4. 创建相关表SEQ : seq_archive_gj_err_log_seq
  --
  --************************************************************
  --*                         公用函数                         *
  --************************************************************

  --   初始化割接进度记录
  PROCEDURE INIT_PROG(I_AREA_ID IN NUMBER, I_MODEL IN VARCHAR2,
                      I_TABLE_NAME IN VARCHAR2, I_TOTAL_ROWS IN NUMBER);

  --  更新割接进度记录
  PROCEDURE UPDATE_PROG(I_AREA_ID IN NUMBER, I_MODEL IN VARCHAR2,
                        I_TABLE_NAME IN VARCHAR2, I_END_DATE IN DATE,
                        I_TOTAL_ROWS IN NUMBER, I_SUCCESS_ROWS IN NUMBER,
                        I_FAIL_ROWS IN NUMBER, I_STATE IN VARCHAR2,
                        I_REMARKS IN VARCHAR2);

  --   记载错误信息
  PROCEDURE WRITE_GJ_LOG(I_AREA_CODE_ID IN NUMBER, I_MODEL IN VARCHAR2,
                         I_TABLE_NAME IN VARCHAR2, I_ID IN VARCHAR2,
                         I_ERR_ID IN VARCHAR2, I_ERR_MSG IN VARCHAR2);

  --   判断相应割接模块程序是否应该中断退出。
  FUNCTION IS_BREAK(I_AREA_ID IN NUMBER, I_MODEL IN VARCHAR2,
                    I_TABLE_NAME IN VARCHAR2) RETURN BOOLEAN;

  --    割接代码转换。
  FUNCTION CODE_CONV(I_FIELD_NAME IN VARCHAR2,
                     --转换字段名
                     I_TYPE_ID IN VARCHAR2,
                     --转换类型
                     I_OLD_CODE IN VARCHAR2,
                     --旧系统代码
                     O_NEW_CODE OUT VARCHAR2
                     --新系统代码
                     ) RETURN BOOLEAN;
  FUNCTION CODE_CONV1(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV2(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV3(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV4(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV5(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV6(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV7(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV8(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  FUNCTION CODE_CONV9(I_FIELD_NAME IN VARCHAR2,
                      --转换字段名
                      I_TYPE_ID IN VARCHAR2,
                      --转换类型
                      I_OLD_CODE IN VARCHAR2,
                      --旧系统代码
                      O_NEW_CODE OUT VARCHAR2
                      --新系统代码
                      ) RETURN BOOLEAN;
  --************************************************************
  --*                         割接程序                         *
  --************************************************************

  --    产品实例割接主过程
  PROCEDURE MAIN_PROD_INST(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART1(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART2(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART3(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART4(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART5(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART6(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART7(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_PART8(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ACCT(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_PROD_INST_REL(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART1(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART2(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART3(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART4(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART5(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART6(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART7(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_REL_PART8(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART1(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART2(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART3(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART4(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART5(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART6(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART7(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_INST_ATTR_PART8(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART1(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART2(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART3(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART4(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART5(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART6(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART7(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_PART8(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_REL(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_PROD_OFFER_INST_ATTR(O_ERR_ID OUT NUMBER,
                                      O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P1(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P2(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P3(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P4(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P5(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P6(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P7(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_OFFER_INST_ATTR_P8(O_ERR_ID OUT NUMBER,
                                         O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_OFFER_PROD_INST_REL(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART1(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART2(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART3(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART4(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART5(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART6(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART7(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_OFFER_PROD_INST_REL_PART8(O_ERR_ID OUT NUMBER,
                                           O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_CUST(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_PART1(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_PART2(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_PART3(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_PART4(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_CUST_EXTERNAL_ATTR(O_ERR_ID OUT NUMBER,
                                    O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_PARTY(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PARTY_PART1(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PARTY_PART2(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PARTY_PART3(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PARTY_PART4(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_PARTY_CONTACT_INFO(O_ERR_ID OUT NUMBER,
                                    O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_ACCOUNT(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_ACCOUNT_PART1(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_ACCOUNT_PART2(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_PAYMENT_PLAN(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_PROD_OFFER_MEMBER_INST(O_ERR_ID OUT NUMBER,
                                        O_ERR_MSG OUT VARCHAR2);

  PROCEDURE MAIN_CREDIT_LIMIT(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_TEMP_CREDIT_LIMIT(O_ERR_ID OUT NUMBER,
                                   O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_REL(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_CREDIT(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_CERTIFICATION(O_ERR_ID OUT NUMBER,
                                    O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PARTY_ATTRIBUTE(O_ERR_ID OUT NUMBER,
                                 O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PARTY_ATTRIBUTE_PART1(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PARTY_ATTRIBUTE_PART2(O_ERR_ID OUT NUMBER,
                                       O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CUST_BRAND_LABEL(O_ERR_ID OUT NUMBER,
                                  O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_CY_RELATION_TYPE(O_ERR_ID OUT NUMBER,
                                  O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_PROD_AREA_RELA(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_BANK_ACCOUNT_INFO(O_ERR_ID OUT NUMBER,
                                   O_ERR_MSG OUT VARCHAR2);
  PROCEDURE MAIN_IVPN_NBR(O_ERR_ID OUT NUMBER, O_ERR_MSG OUT VARCHAR2);

  -------------------------------
  --   产品实例割接转换过程
  FUNCTION DEAL_PROD_INST(REC_INST IN CRM_PROD_INST%ROWTYPE,
                          -- 实例
                          V_STEP OUT VARCHAR2,
                          -- 代码段标识
                          V_ERR_MSG OUT VARCHAR2
                          -- 错误信息
                          ) RETURN BOOLEAN;

  FUNCTION DEAL_PROD_INST_ACCT(REC_INST IN CRM_PROD_INST_ACCT%ROWTYPE,
                               -- 实例
                               V_STEP OUT VARCHAR2,
                               -- 代码段标识
                               V_ERR_MSG OUT VARCHAR2
                               -- 错误信息
                               ) RETURN BOOLEAN;
  FUNCTION DEAL_PROD_INST_REL(REC_INST IN CRM_PROD_INST_REL%ROWTYPE,
                              -- 实例
                              V_STEP OUT VARCHAR2,
                              -- 代码段标识
                              V_ERR_MSG OUT VARCHAR2
                              -- 错误信息
                              ) RETURN BOOLEAN;
  FUNCTION DEAL_PROD_INST_ATTR(REC_INST IN CRM_PROD_INST_ATTR%ROWTYPE,
                               -- 实例
                               V_STEP OUT VARCHAR2,
                               -- 代码段标识
                               V_ERR_MSG OUT VARCHAR2
                               -- 错误信息
                               ) RETURN BOOLEAN;

  FUNCTION DEAL_PROD_OFFER_INST(REC_INST IN CRM_PROD_OFFER_INST%ROWTYPE,
                                -- 实例
                                V_STEP OUT VARCHAR2,
                                -- 代码段标识
                                V_ERR_MSG OUT VARCHAR2
                                -- 错误信息
                                ) RETURN BOOLEAN;

  FUNCTION DEAL_PROD_OFFER_INST_REL(REC_INST IN CRM_PROD_OFFER_INST_REL%ROWTYPE,
                                    -- 实例
                                    V_STEP OUT VARCHAR2,
                                    -- 代码段标识
                                    V_ERR_MSG OUT VARCHAR2
                                    -- 错误信息
                                    ) RETURN BOOLEAN;

  FUNCTION DEAL_PROD_OFFER_INST_ATTR(REC_INST IN CRM_PROD_OFFER_INST_ATTR%ROWTYPE,
                                     -- 实例
                                     V_STEP OUT VARCHAR2,
                                     -- 代码段标识
                                     V_ERR_MSG OUT VARCHAR2
                                     -- 错误信息
                                     ) RETURN BOOLEAN;

  FUNCTION DEAL_OFFER_PROD_INST_REL(REC_INST IN CRM_OFFER_PROD_INST_REL%ROWTYPE,
                                    -- 实例
                                    V_STEP OUT VARCHAR2,
                                    -- 代码段标识
                                    V_ERR_MSG OUT VARCHAR2
                                    -- 错误信息
                                    ) RETURN BOOLEAN;

  FUNCTION DEAL_CUST(REC_INST IN CRM_CUST%ROWTYPE,
                     -- 实例
                     V_STEP OUT VARCHAR2,
                     -- 代码段标识
                     V_ERR_MSG OUT VARCHAR2
                     -- 错误信息
                     ) RETURN BOOLEAN;

  FUNCTION DEAL_CUST_EXTERNAL_ATTR(REC_INST IN CRM_CUST_EXTERNAL_ATTR%ROWTYPE,
                                   -- 实例
                                   V_STEP OUT VARCHAR2,
                                   -- 代码段标识
                                   V_ERR_MSG OUT VARCHAR2
                                   -- 错误信息
                                   ) RETURN BOOLEAN;

  FUNCTION DEAL_PARTY(REC_INST IN CRM_PARTY%ROWTYPE,
                      -- 实例
                      V_STEP OUT VARCHAR2,
                      -- 代码段标识
                      V_ERR_MSG OUT VARCHAR2
                      -- 错误信息
                      ) RETURN BOOLEAN;

  FUNCTION DEAL_PARTY_CONTACT_INFO(REC_INST IN CRM_PARTY_CONTACT_INFO%ROWTYPE,
                                   -- 实例
                                   V_STEP OUT VARCHAR2,
                                   -- 代码段标识
                                   V_ERR_MSG OUT VARCHAR2
                                   -- 错误信息
                                   ) RETURN BOOLEAN;

  FUNCTION DEAL_ACCOUNT(REC_INST IN CRM_ACCOUNT%ROWTYPE,
                        -- 实例
                        V_STEP OUT VARCHAR2,
                        -- 代码段标识
                        V_ERR_MSG OUT VARCHAR2
                        -- 错误信息
                        ) RETURN BOOLEAN;

  FUNCTION DEAL_PAYMENT_PLAN(REC_INST IN CRM_PAYMENT_PLAN%ROWTYPE,
                             -- 实例
                             V_STEP OUT VARCHAR2,
                             -- 代码段标识
                             V_ERR_MSG OUT VARCHAR2
                             -- 错误信息
                             ) RETURN BOOLEAN;

  FUNCTION DEAL_PROD_OFFER_MEMBER_INST(REC_INST IN CRM_PROD_OFFER_MEMBER_INST%ROWTYPE,
                                       -- 实例
                                       V_STEP OUT VARCHAR2,
                                       -- 代码段标识
                                       V_ERR_MSG OUT VARCHAR2
                                       -- 错误信息
                                       ) RETURN BOOLEAN;

  FUNCTION DEAL_CREDIT_LIMIT(REC_INST IN CRM_CREDIT_LIMIT%ROWTYPE,
                             -- 实例
                             V_STEP OUT VARCHAR2,
                             -- 代码段标识
                             V_ERR_MSG OUT VARCHAR2
                             -- 错误信息
                             ) RETURN BOOLEAN;
  FUNCTION DEAL_TEMP_CREDIT_LIMIT(REC_INST IN CRM_CREDIT_LIMIT%ROWTYPE,
                                  -- 实例
                                  V_STEP OUT VARCHAR2,
                                  -- 代码段标识
                                  V_ERR_MSG OUT VARCHAR2
                                  -- 错误信息
                                  ) RETURN BOOLEAN;
  FUNCTION DEAL_CUST_REL(REC_INST IN CRM_CUST_REL%ROWTYPE,
                         -- 实例
                         V_STEP OUT VARCHAR2,
                         -- 代码段标识
                         V_ERR_MSG OUT VARCHAR2
                         -- 错误信息
                         ) RETURN BOOLEAN;
  FUNCTION DEAL_CUST_CREDIT(REC_INST IN CRM_CUST_CREDIT%ROWTYPE,
                            -- 实例
                            V_STEP OUT VARCHAR2,
                            -- 代码段标识
                            V_ERR_MSG OUT VARCHAR2
                            -- 错误信息
                            ) RETURN BOOLEAN;
  FUNCTION DEAL_CUST_CERTIFICATION(REC_INST IN CRM_CUST_CERTIFICATION%ROWTYPE,
                                   -- 实例
                                   V_STEP OUT VARCHAR2,
                                   -- 代码段标识
                                   V_ERR_MSG OUT VARCHAR2
                                   -- 错误信息
                                   ) RETURN BOOLEAN;
  FUNCTION DEAL_PARTY_ATTRIBUTE(REC_INST IN CRM_PARTY_ATTRIBUTE%ROWTYPE,
                                -- 实例
                                V_STEP OUT VARCHAR2,
                                -- 代码段标识
                                V_ERR_MSG OUT VARCHAR2
                                -- 错误信息
                                ) RETURN BOOLEAN;
  FUNCTION DEAL_CUST_BRAND_LABEL(REC_INST IN CRM_CUST_BRAND_LABEL%ROWTYPE,
                                 -- 实例
                                 V_STEP OUT VARCHAR2,
                                 -- 代码段标识
                                 V_ERR_MSG OUT VARCHAR2
                                 -- 错误信息
                                 ) RETURN BOOLEAN;

  FUNCTION DEAL_CY_RELATION_TYPE(REC_INST IN CRM_PARTY_RELATION%ROWTYPE,
                                 -- 实例
                                 V_STEP OUT VARCHAR2,
                                 -- 代码段标识
                                 V_ERR_MSG OUT VARCHAR2
                                 -- 错误信息
                                 ) RETURN BOOLEAN;
  FUNCTION DEAL_PROD_AREA_RELA(REC_INST IN CRM_PROD_AREA_RELA%ROWTYPE,
                               -- 实例
                               V_STEP OUT VARCHAR2,
                               -- 代码段标识
                               V_ERR_MSG OUT VARCHAR2
                               -- 错误信息
                               ) RETURN BOOLEAN;
  FUNCTION DEAL_BANK_ACCOUNT_INFO(REC_INST IN CRM_BANK_ACCOUNT_INFO%ROWTYPE,
                                  -- 实例
                                  V_STEP OUT VARCHAR2,
                                  -- 代码段标识
                                  V_ERR_MSG OUT VARCHAR2
                                  -- 错误信息
                                  ) RETURN BOOLEAN;
  FUNCTION DEAL_IVPN_NBR(REC_INST IN CRM_IVPN_NBR%ROWTYPE,
                         -- 实例
                         V_STEP OUT VARCHAR2,
                         -- 代码段标识
                         V_ERR_MSG OUT VARCHAR2
                         -- 错误信息
                         ) RETURN BOOLEAN;
  ----------临时补割数据用------------
  PROCEDURE TMP_MAIN_PROD_OFFER_INST(O_ERR_ID OUT NUMBER,
                                     O_ERR_MSG OUT VARCHAR2);
  ------------------------------------

END PK_CRM1_TO_CRM2_DATA_GJ;
/
