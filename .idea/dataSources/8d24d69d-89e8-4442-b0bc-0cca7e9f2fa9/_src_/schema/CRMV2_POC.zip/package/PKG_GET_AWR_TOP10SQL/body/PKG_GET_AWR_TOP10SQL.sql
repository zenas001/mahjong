CREATE PACKAGE BODY           PKG_get_awr_top10sql IS

 PROCEDURE get_awr_top10sql IS
    begin_snap      NUMBER;
    begin_snap_time DATE;
    end_snap        NUMBER;
    end_snap_time   DATE;
    batch_id        NUMBER;
  BEGIN
    FOR cur IN (SELECT DISTINCT t1.dbid, ---数据库id
                                t2.instance_number, ---实例编号
                                t1.snap_id, ---快照ID
                                end_interval_time + 0 snap_time ----快照结束时间
                  FROM dba_hist_snapshot t1, dba_hist_database_instance t2
                 WHERE t1.dbid = t2.dbid
                   AND t1.instance_number = t2.instance_number
                   AND to_char(t1.end_interval_time + 0, 'HH24MI') IN
                       ('1000', '1600')
                   AND trunc(t1.end_interval_time + 0) = trunc(SYSDATE)) LOOP
      begin_snap      := cur.snap_id;
      begin_snap_time := cur.snap_time;
      end_snap        := cur.snap_id + 2;
      end_snap_time   := cur.snap_time + 1 / 24;
      SELECT seq_pkg_mnt_wzy_awr.nextval
        INTO batch_id
        FROM dual;

      INSERT INTO wh_monitor_awr_top10_sql
        SELECT batch_id,
               cur.instance_number inst_number,
               begin_snap_time     begin_snap_time,
               end_snap_time       end_snap_time,

               nvl((sqt.elap / 1000000), to_number(NULL)) elapsed_time,
               nvl((sqt.cput / 1000000), to_number(NULL)) cpu_time,
               nvl((sqt.iot / 1000000), to_number(NULL)) io_wait_time,
               sqt.exec,
               decode(sqt.exec, 0, to_number(NULL),
                      (sqt.elap / sqt.exec / 1000000)) elapsed_time_per_exec,

               (100 *
               (sqt.elap / (SELECT (SUM(e.value) - SUM(b.value))
                               FROM dba_hist_sys_time_model e,
                                    dba_hist_sys_time_model b
                              WHERE e.snap_id = end_snap
                                AND e.dbid = cur.dbid
                                AND e.instance_number = cur.instance_number
                                AND e.stat_name = 'DB time'
                                AND b.snap_id = begin_snap
                                AND b.dbid = cur.dbid
                                AND b.instance_number = cur.instance_number
                                AND b.stat_name = 'DB time'))) total_percent,
               sqt.cput cpu_percent,
               100 * nvl((sqt.iot / 1000000), to_number(NULL)) /
               nvl((sqt.elap / 1000000), to_number(NULL)) io_percent,
               sqt.sql_id,
               to_clob(decode(sqt.module, NULL, NULL,
                              'Module: ' || sqt.module)) module,
               nvl(st.sql_text, to_clob(' ** SQL Text Not Available ** ')) sql_text,
               parsing_schema_name,
               sqt.dskr,
               sysdate
          FROM (SELECT sql_id,
                       MAX(module) module,
                       SUM(elapsed_time_delta) elap,
                       SUM(cpu_time_delta) cput,
                       SUM(executions_delta) exec,
                       SUM(iowait_delta) iot,
                       MAX(parsing_schema_name) parsing_schema_name,
                       sum(disk_reads_delta) dskr
                  FROM dba_hist_sqlstat
                 WHERE dbid = cur.dbid
                   AND instance_number = cur.instance_number
                   AND begin_snap < snap_id
                   AND snap_id <= end_snap
                 GROUP BY sql_id) sqt,
               dba_hist_sqltext st
         WHERE st.sql_id(+) = sqt.sql_id
           AND st.dbid(+) = cur.dbid
         ORDER BY nvl(sqt.elap, -1) DESC, sqt.sql_id;
      COMMIT;
    END LOOP;
    COMMIT;
  END;
END PKG_get_awr_top10sql;
/
