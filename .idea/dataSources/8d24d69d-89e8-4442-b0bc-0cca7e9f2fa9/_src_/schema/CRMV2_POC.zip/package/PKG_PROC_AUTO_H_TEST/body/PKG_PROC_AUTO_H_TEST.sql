CREATE package body           PKG_PROC_AUTO_H_TEST is

  -- Author  : zhengcl
  -- Created : 2012/8/2
  -- Purpose : 提供Job自动执行所有自动处理过程
  procedure prodAutoProc is
    v_message varchar(4000);
    str_msg   varchar(2000);
    v_seq     number;
  begin
    v_seq     := 0;
    v_message := 'Begin PKG_PROC_AUTO_H_TEST.optionalOfferAttrProcForProd.optionalOfferProcForProd time:' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);

    --0.可选包参数到期,拆除可选包也拆除产品的处理,或者续约
    v_message := v_message || 'Begin optionalOfferAttrProcForProd time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    optionalOfferAttrProcForProd(str_msg);
    v_message := v_message || 'End optionalOfferAttrProcForProd time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);

    --1.可选包到期,拆除可选包也拆除产品的处理
    v_message := v_message || 'Begin optionalOfferProcForProd time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    optionalOfferProcForProd(str_msg);
    v_message := v_message || 'End optionalOfferProcForProd time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);

    v_message := v_message || 'End PKG_PROC_AUTO_H_TEST.optionalOfferAttrProcForProd.optionalOfferProcForProd time:' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
  EXCEPTION
    WHEN OTHERS THEN
      v_message := v_message || to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') ||
                   'Error' || sqlerrm;
      v_seq     := saveLogInfo(v_seq, v_message);
  end;

  procedure prodAutoProc2 is
    v_message varchar(4000);
    str_msg   varchar(2000);
    v_seq     number;
  begin
    v_seq     := 0;
    v_message := 'Begin PKG_PROC_AUTO_H_TEST.stopRemainNumber.procFuncBaseOffer time:' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    --1.停保复机
    v_message := v_message || 'Begin stopRemainNumber time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    stopRemainNumber(str_msg);
    v_message := v_message || 'End stopRemainNumber time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    --4.功能基础销售品到期拆除
    v_message := v_message || 'Begin procFuncBaseOffer time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    procFuncBaseOffer(str_msg);
    v_message := v_message || 'End procFuncBaseOffer time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    v_message := v_message ||
                 'End PKG_PROC_AUTO_H_TEST.stopRemainNumber.procFuncBaseOffer time:' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
  EXCEPTION
    WHEN OTHERS THEN
      v_message := v_message || to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') ||
                   'Error' || sqlerrm;
      v_seq     := saveLogInfo(v_seq, v_message);
  end;

  procedure prodAutoProc3 is
    v_message varchar(4000);
    str_msg   varchar(2000);
    v_seq     number;
  begin
    v_seq     := 0;
    v_message := 'Begin PKG_PROC_AUTO_H_TEST.optionalGroupOfferProc.procAccBaseOffer.changeNumbers time:' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    --2.可选包群组到期,只拆除退出可选包群组的处理
    v_message := v_message || 'Begin optionalGroupOfferProc time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    optionalGroupOfferProc(str_msg);
    v_message := v_message || 'End optionalGroupOfferProc time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    --3.接入类基础销售品到期拆除 先屏蔽待评估后再开启
    v_message := v_message || 'Begin procAccBaseOffer time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    procAccBaseOffer(str_msg);
    v_message := v_message || 'End procAccBaseOffer time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    --5.改号通知音
    v_message := v_message || 'Begin changeNumbers time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    changeNumbers(str_msg);
    v_message := v_message || 'End changeNumbers time:' ||
                 to_char(sysdate, 'hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    v_message := v_message ||
                 'End PKG_PROC_AUTO_H_TEST.optionalGroupOfferProc.procAccBaseOffer.changeNumbers time:' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
  EXCEPTION
    WHEN OTHERS THEN
      v_message := v_message || to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') ||
                   'Error' || sqlerrm;
      v_seq     := saveLogInfo(v_seq, v_message);
  end;

  -- Author  : LITTLEHUI
  -- Created : 2012/6/25 09:11:27
  -- Purpose : 停机保号到期自动复机
  procedure stopRemainNumber(str_msg out varchar) is
    o_auto_proc_queue_id number;
    base_offer_inst_id   number;
    --prod_inst_attr_spec  number;
    isT01      number;
    datacount  number;
    retResult  number;
    stop_reson varchar2(30);
  begin
    datacount := 0;
    retResult := 0;
    for stopedProdInst in (select a.prod_inst_id,
                                  c.java_code,
                                  a.area_id,
                                  b.attr_id,
                                  b.prod_inst_attr_id,
                                  b.attr_value,
                                  d.prod_offer_inst_id as base_prod_offer_inst_id,
                                  f.AREA_ID base_prod_offer_area_id,
                                  f.REGION_CD base_prod_offer_region_cd
                             from prod_inst           a,
                                  prod_inst_attr      b,
                                  attr_spec           c,
                                  offer_prod_inst_rel d,
                                  prod_offer          e,
                                  prod_offer_inst     f,
                                  product             g
                            where a.status_cd = '120000'
                              and b.prod_inst_id = a.prod_inst_id
                              and b.attr_id = c.attr_id
                              and b.attr_id = 800000271 --复机日期属性
                              and b.attr_value <=
                                  to_char(sysdate, 'yyyy-mm-dd')
                              and a.prod_inst_id = d.prod_inst_id
                              and d.status_cd = '1000'
                              and a.product_id = g.product_id
                              and g.product_type = '10'
                              and f.prod_offer_inst_id =
                                  d.prod_offer_inst_id
                              and f.prod_offer_id = e.prod_offer_id
                              and e.offer_type in ('10', '11')) LOOP
      --判断是否有'SO_SERViSTOP_USER', 'SO_SERViSTOP_RTLS'属性
      select count(a.prod_inst_id)
        into retResult
        from prod_inst_attr a, attr_spec b
       where a.prod_inst_id = stopedProdInst.prod_inst_id
         and a.attr_id = b.attr_id
         and b.java_code in ('SO_SERViSTOP_USER', 'SO_SERViSTOP_RTLS');
      if (retResult <> 1) then
        goto looptear;
      end if;
      select b.java_code
        into stop_reson
        from prod_inst_attr a, attr_spec b
       where a.prod_inst_id = stopedProdInst.prod_inst_id
         and a.attr_id = b.attr_id
         and b.java_code in ('SO_SERViSTOP_USER', 'SO_SERViSTOP_RTLS');
      base_offer_inst_id := stopedProdInst.base_prod_offer_inst_id;
      if (stop_reson = 'SO_SERViSTOP_USER') then
        --用户申请停机处理
        --泉州地区,宁德地区不做处理
        if (stopedProdInst.area_id = 4 or stopedProdInst.area_id = 6) then
          goto ENDUSERSTOP;
        end if;
        if (IsHasOfferInQueue(base_offer_inst_id, 'ProdOfferInst') = 0) and
           (IsHasOfferInQueue(stopedProdInst.prod_inst_id, 'ProdInst') = 0) then
          o_auto_proc_queue_id := InsertIntoOAutoProcQueueByArea(0,
                                                                 base_offer_inst_id,
                                                                 'ProdOfferInst',
                                                                 '3020500000',
                                                                 'MOD',
                                                                 '200098',
                                                                 '停机保号停机到期自动复机处理(主销售品)',
                                                                 stopedProdInst.base_prod_offer_area_id,
                                                                 stopedProdInst.base_prod_offer_region_cd);

          o_auto_proc_queue_id := InsertIntoOAutoProcQueue(o_auto_proc_queue_id,
                                                           stopedProdInst.prod_inst_id,
                                                           'ProdInst',
                                                           '4070100002',
                                                           'MOD',
                                                           '200098',
                                                           '停机保号停机到期自动复机处理(产品)');
          --800000374--停机日期
          --800000271--复机日期
          for stopedProdInstAttr in (select a.prod_inst_attr_id, a.attr_id
                                       from prod_inst_attr a
                                      where a.prod_inst_id =
                                            stopedProdInst.prod_inst_id
                                        and a.attr_id in
                                            (800000253, 800000254, 800000271,
                                             800000374)) loop
            if stopedProdInstAttr.attr_id = 800000271 then
              retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                   stopedProdInstAttr.attr_id,
                                                   'EA',
                                                   stopedProdInstAttr.prod_inst_attr_id,
                                                   'DELETE',
                                                   null,
                                                   'recoverDateCheck',
                                                   '-1',
                                                   null,
                                                   '停机保号停机到期停机属性处理(属性)');
            else
              retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                   stopedProdInstAttr.attr_id,
                                                   'EA',
                                                   stopedProdInstAttr.prod_inst_attr_id,
                                                   'DELETE',
                                                   null,
                                                   null,
                                                   null,
                                                   null,
                                                   '停机保号停机到期停机属性处理(属性)');
            end if;
          end loop;
          --datacount := datacount + 1;
          commit;
        end if;
        <<ENDUSERSTOP>>
        NULL;
      end if;
      if (stop_reson = 'SO_SERViSTOP_RTLS') then
        --停机保号处理
        --判断是否是单产品
        select count(*)
          into isT01
          from prod_offer_inst a, prod_offer b
         where a.prod_offer_inst_id = base_offer_inst_id
           and a.prod_offer_id = b.prod_offer_id
           and b.offer_sub_type = 'T01';
        if (isT01 = 1) and
           (IsHasOfferInQueue(base_offer_inst_id, 'ProdOfferInst') = 0) and
           (IsHasOfferInQueue(stopedProdInst.prod_inst_id, 'ProdInst') = 0) then
          o_auto_proc_queue_id := InsertIntoOAutoProcQueueByArea(0,
                                                                 base_offer_inst_id,
                                                                 'ProdOfferInst',
                                                                 '3020500000',
                                                                 'MOD',
                                                                 '200098',
                                                                 '挂失停机到期自动复机处理(主销售品)',
                                                                 stopedProdInst.base_prod_offer_area_id,
                                                                 stopedProdInst.base_prod_offer_region_cd);

          o_auto_proc_queue_id := InsertIntoOAutoProcQueue(o_auto_proc_queue_id,
                                                           stopedProdInst.prod_inst_id,
                                                           'ProdInst',
                                                           '4070100001',
                                                           'MOD',
                                                           '200098',
                                                           '挂失停机到期自动复机处理(产品)');

          --800000374--停机日期
          --800000271--复机日期
          for stopedProdInstAttr in (select a.prod_inst_attr_id, a.attr_id
                                       from prod_inst_attr a
                                      where a.prod_inst_id =
                                            stopedProdInst.prod_inst_id
                                        and a.attr_id in
                                            (800000253, 800000254, 800000271,
                                             800000374)) loop
            if stopedProdInstAttr.attr_id = 800000271 then
              retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                   stopedProdInstAttr.attr_id,
                                                   'EA',
                                                   stopedProdInstAttr.prod_inst_attr_id,
                                                   'DELETE',
                                                   null,
                                                   'recoverDateCheck',
                                                   '-1',
                                                   null,
                                                   '停机保号停机到期停机属性处理(属性)');
            else
              retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                   stopedProdInstAttr.attr_id,
                                                   'EA',
                                                   stopedProdInstAttr.prod_inst_attr_id,
                                                   'DELETE',
                                                   null,
                                                   null,
                                                   null,
                                                   null,
                                                   '挂失停机到期停机属性处理(属性)');
            end if;
          end loop;
          commit;
        end if; --T01
      end if; --SO_SERViSTOP_RTLS
      if datacount > 0 then
        goto outline;
      end if;
      <<looptear>>
      NULL;
    END LOOP;
    <<outline>>
    NULL;

    str_msg := 'success';

  end stopRemainNumber;

  procedure optionalOfferProcOnlyOffer(i_mode  in number,
                                       i_int   in number,
                                       str_msg out varchar) is
    datacount           number;
    backcount           number;
    v_seq               number;
    v_message           varchar(4000);
    v_sub_message       varchar(4000);
    begin_time          varchar(40);
    end_time            varchar(40);
    minutime            number;
    v_direct_proc_flag  number; --该标识为1表示exp_proc_method = '2'的情况,自动处理档案,不生成订单.
    v_cnt               number;
    v_rela_prod_inst_id number;
    --v_area_code           varchar2(10);
  begin
    -- 获取在用的到期可选包
    datacount          := 0;
    v_seq              := 0;
    v_direct_proc_flag := 1; --到期拆可选包默认都是自动档案处理.
    if i_mode = 0 then
      v_message := ',第二尾数为偶数,';
    else
      v_message := ',第二尾数为奇数,';
    end if;
    v_message := '尾数为' || i_int || v_message;
    v_message := 'Begin ' || v_message ||
                 'PKG_PROC_AUTO_H_TEST.optionalOfferProcOnlyOffer :' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';     ';
    v_seq     := saveLogInfo(v_seq, v_message);
    --气象时报天翼联名卡体验包特殊处理 800009108
    if i_int = 8 and i_mode = 0 then
      update prod_offer_inst a
         set a.exp_date = a.exp_date - 3, update_date = sysdate
       where exp_date > sysdate
         and exp_date < sysdate + 3
         and a.prod_offer_id = 800009108;
      commit;
    end if;
    for prodOfferProc in (SELECT *
                            FROM prod_offer
                           where offer_type in ('12', '13')
                             and offer_sub_type = 'T04'
                             and exp_proc_method = '2'
                             and ((substr(prod_offer_id, -1, 1) = i_int and
                                 mod(substr(prod_offer_id, -2, 1), 2) =
                                 i_mode) or (i_int = -1 and i_mode = -1))) loop
      datacount     := datacount + 1;
      v_sub_message := v_message || ' Begin NO.(' || datacount ||
                       ')prodOffer:' || prodOfferProc.Prod_Offer_Name ||
                       prodOfferProc.Prod_Offer_Id || '  time:' ||
                       to_char(sysdate, 'hh24:mi:ss') || ';     ';
      v_seq         := saveLogInfo(v_seq, v_sub_message);

      begin_time         := to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss');
      v_direct_proc_flag := IsCanDirectProc(prodOfferProc.Prod_Offer_Id);
      --zhengcl crm00062882 优化语句，取消prod_offer_inst_attr判断，取消union all.统一移到插入队列前判断。
      for optionalOfferInst in (select a.exp_date,
                                       a.eff_date,
                                       a.end_auto,
                                       b.prod_offer_id,
                                       b.exp_proc_method,
                                       c.related_prod_offer_inst_id as prod_offer_inst_id,
                                       c.rela_prod_offer_inst_id as base_offer_inst_id,
                                       g.area_id,
                                       g.region_cd
                                  from prod_offer_inst     a,
                                       prod_offer          b,
                                       prod_offer_inst_rel c,
                                       prod_offer_inst     g
                                 where a.prod_offer_id = b.prod_offer_id
                                   and a.exp_date < sysdate
                                   and a.status_cd = '1000'
                                   and b.offer_type in ('12', '13')
                                   and b.offer_sub_type = 'T04'
                                   and b.exp_proc_method = '2'
                                   and c.related_prod_offer_inst_id =
                                       a.prod_offer_inst_id
                                   and c.status_cd = '1000'
                                   and g.prod_offer_inst_id =
                                       c.rela_prod_offer_inst_id
                                  --and a.eff_date != a.exp_date --zhengcl 20150608 crm00062573 更改为插入队列前判断
                                   --and a.prod_offer_inst_id = 2992795948 -----测试
                                   and b.prod_offer_id =
                                       prodOfferProc.Prod_Offer_Id) loop
        --zhengcl 20150507 v_exp_proc_method=2,v_direct_proc_flag=0的情况,增加产品队列
        v_rela_prod_inst_id := 0; --默认产品实例为0,到期拆可选包不需要产品实例Id
        if v_direct_proc_flag = 0 then
          select count(*)
            into v_cnt
            from offer_prod_inst_rel
           where prod_offer_inst_id = optionalOfferInst.Prod_Offer_Inst_Id;
          if v_cnt = 1 then
            select prod_inst_id
              into v_rela_prod_inst_id
              from offer_prod_inst_rel
             where prod_offer_inst_id =
                   optionalOfferInst.Prod_Offer_Inst_Id;
          end if;
        end if;
        backcount := optionalAutoProcQueue(optionalOfferInst.Prod_Offer_Id,
                                           optionalOfferInst.Prod_Offer_Inst_Id,
                                           optionalOfferInst.Base_Offer_Inst_Id,
                                           optionalOfferInst.Exp_Proc_Method,
                                           v_rela_prod_inst_id,
                                           optionalOfferInst.Area_Id,
                                           optionalOfferInst.Region_Cd,
                                           optionalOfferInst.Eff_Date,
                                           optionalOfferInst.Exp_Date,
                                           v_direct_proc_flag);
      end loop;
      end_time := to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss');
      select ceil((to_date(end_time, 'yyyy-mm-dd-hh24:mi:ss') -
                  to_date(begin_time, 'yyyy-mm-dd-hh24:mi:ss')) * 24 * 60)
        into minutime
        FROM DUAL;
      if (minutime > 30) then
        v_message := v_message || ' NO.(' || datacount || ')prodOffer:' ||
                     prodOfferProc.Prod_Offer_Name ||
                     prodOfferProc.Prod_Offer_Id || '  out time:' ||
                     minutime || 'minute;     ';
        v_seq     := saveLogInfo(v_seq, v_message);
      end if;
    end loop;
    str_msg   := 'success';
    v_message := v_sub_message || '总计:[' || datacount ||
                 '] End PKG_PROC_AUTO_H_TEST.optionalOfferProcOnlyOffer time:' ||
                 to_char(sysdate, 'yyyy-mm-dd-hh24:mi:ss') || ';    ';
    v_seq     := saveLogInfo(v_seq, v_message);
    --exception
  end optionalOfferProcOnlyOffer;

  procedure optionalOfferProcOnlyOffer2(str_msg out varchar) is
    backcount number;
    --v_area_code           varchar2(10);
  begin
    -- 获取在用的到期可选包
    --气象时报天翼联名卡体验包特殊处理 800009108
    update prod_offer_inst a
       set a.exp_date = a.exp_date - 3, update_date = sysdate
     where exp_date > sysdate
       and exp_date < sysdate + 3
       and a.prod_offer_id = 800009108;
    commit;

    for optionalOfferInst in (select a.exp_date,
                                     a.eff_date,
                                     a.end_auto,
                                     b.prod_offer_id,
                                     b.exp_proc_method,
                                     c.related_prod_offer_inst_id as prod_offer_inst_id,
                                     c.rela_prod_offer_inst_id as base_offer_inst_id,
                                     g.area_id,
                                     g.region_cd
                                from prod_offer_inst     a,
                                     prod_offer          b,
                                     prod_offer_inst_rel c,
                                     prod_offer_inst     g
                               where a.prod_offer_id = b.prod_offer_id
                                 and a.exp_date < sysdate
                                 and a.status_cd = '1000'
                                 and b.offer_type in ('12', '13')
                                 and b.offer_sub_type = 'T04'
                                 and b.exp_proc_method = '2'
                                 and c.related_prod_offer_inst_id =
                                     a.prod_offer_inst_id
                                 and c.status_cd = '1000'
                                 and g.prod_offer_inst_id =
                                     c.rela_prod_offer_inst_id
                                 --and a.eff_date != a.exp_date --zhengcl 20150608 crm00062573 更改为插入队列前判断
                                ) loop
      backcount := optionalAutoProcQueue(optionalOfferInst.Prod_Offer_Id,
                                         optionalOfferInst.Prod_Offer_Inst_Id,
                                         optionalOfferInst.Base_Offer_Inst_Id,
                                         optionalOfferInst.Exp_Proc_Method,
                                         0,
                                         optionalOfferInst.Area_Id,
                                         optionalOfferInst.Region_Cd,
                                         optionalOfferInst.Eff_Date,
                                         optionalOfferInst.Exp_Date,
                                         1);
    end loop;

    str_msg := 'success';
    --exception
  end optionalOfferProcOnlyOffer2;

  procedure optionalOfferProcForProd(str_msg out varchar) is
    datacount number;
  begin
    -- 获取在用的到期可选包
    for optionalOfferInst in (select a.exp_date,
                                     a.eff_date,
                                     a.end_auto,
                                     b.prod_offer_id,
                                     b.exp_proc_method,
                                     c.related_prod_offer_inst_id as prod_offer_inst_id,
                                     c.rela_prod_offer_inst_id as base_offer_inst_id,
                                     d.prod_inst_id as rela_prod_inst_id,
                                     e.area_code,
                                     g.area_id,
                                     g.region_cd
                                from prod_offer_inst     a,
                                     prod_offer          b,
                                     prod_offer_inst_rel c,
                                     offer_prod_inst_rel d,
                                     prod_inst           e,
                                     product             f,
                                     prod_offer_inst     g
                               where a.prod_offer_id = b.prod_offer_id
                                 and a.exp_date < sysdate
                                 and a.status_cd = '1000'
                                 and b.offer_type in ('12', '13')
                                 and b.offer_sub_type in ('T04', 'T05')
                                 and (b.exp_proc_method = '5' or
                                     b.exp_proc_method = '6')
                                 and c.related_prod_offer_inst_id =
                                     a.prod_offer_inst_id
                                 and c.status_cd = '1000'
                                 and d.prod_offer_inst_id =
                                     c.related_prod_offer_inst_id
                                 and d.status_cd = '1000'
                                 and f.product_id = e.product_id
                                 and f.prod_func_type = '101'
                                 and e.prod_inst_id = d.prod_inst_id
                                 and g.prod_offer_inst_id =
                                     c.rela_prod_offer_inst_id
                                 --and a.prod_offer_inst_id=2502677592-------测试
                                 --and a.eff_date != a.exp_date --zhengcl 20150608 crm00062573 更改为插入队列前判断
                                ) loop

      datacount := optionalAutoProcQueue(optionalOfferInst.Prod_Offer_Id,
                                         optionalOfferInst.Prod_Offer_Inst_Id,
                                         optionalOfferInst.Base_Offer_Inst_Id,
                                         optionalOfferInst.Exp_Proc_Method,
                                         optionalOfferInst.Rela_Prod_Inst_Id,
                                         optionalOfferInst.Area_Id,
                                         optionalOfferInst.Region_Cd,
                                         optionalOfferInst.Eff_Date,
                                         optionalOfferInst.Exp_Date,
                                         0);

    end loop;
    NULL;
    str_msg := 'success';
    --exception
  end optionalOfferProcForProd;

  procedure optionalGroupOfferProc(str_msg out varchar) is
    retResult            number;
    o_auto_proc_queue_id number;
    inst_action_type     varchar2(12);
    inst_status          varchar2(12);
    inst_src_type        varchar2(12); --可选包动作
    v_exp_eff_judge      boolean; --该标识为true，则生成队列数据；生失效时间一致，且小于当前时间+1个月才为false，不生成队列数据。
  begin
    -- 获取在用的到期可选包
    for prodOfferProc in (SELECT *
                            FROM prod_offer
                           where offer_type in ('12', '13')
                             and offer_sub_type = 'T05'
                             and exp_proc_method = '2') loop
      for optionalOfferInst in (select a.exp_date,
                                       a.eff_date,
                                       a.prod_offer_inst_id,
                                       b.prod_offer_id,
                                       b.exp_proc_method,
                                       a.area_id,
                                       a.region_cd
                                  from prod_offer_inst a, prod_offer b
                                 where a.prod_offer_id = b.prod_offer_id
                                   and a.exp_date < sysdate
                                   and a.status_cd = '1000'
                                   and b.offer_type in ('12', '13')
                                   and b.offer_sub_type = 'T05'
                                   and b.exp_proc_method = '2'
                                   and b.prod_offer_id =
                                       prodOfferProc.prod_offer_id
                                   --and a.eff_date != a.exp_date --zhengcl 20150608 crm00062573 更改为插入队列前判断
                                    ) loop
        case
          when optionalOfferInst.exp_proc_method = '2' then
            --到期自动退订
            inst_status      := '200097'; --直接处理档案
            inst_action_type := '3030100000'; --退订
            inst_src_type    := 'DELETE';
        end case;
      /*zhengcl 20150608 crm00062573 v_exp_eff_judge默认为true，则生成队列数据；
        生失效时间一致，且小于当前时间+1个月才为false，不生成队列数据。*/
        v_exp_eff_judge := true;
        if optionalOfferInst.Exp_Date = optionalOfferInst.Eff_Date then
          v_exp_eff_judge := false;
          if optionalOfferInst.Exp_Date < add_months(SYSDATE, -1) then
            v_exp_eff_judge := true;
          end if;
        end if;
        if (v_exp_eff_judge = true) and
           (IsHasOfferInQueue(optionalOfferInst.prod_offer_inst_id,
                             'ProdOfferInst') = 0) then
          o_auto_proc_queue_id := InsertIntoOAutoProcQueueByArea(0,
                                                                 optionalOfferInst.prod_offer_inst_id,
                                                                 'ProdOfferInst',
                                                                 inst_action_type,
                                                                 inst_src_type,
                                                                 inst_status,
                                                                 '可选群组类销售品到期入队列',
                                                                 optionalOfferInst.area_id,
                                                                 optionalOfferInst.region_cd);
          retResult            := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                          0,
                                                          'CHNCD',
                                                          0,
                                                          'INSERT',
                                                          '600105B021',
                                                          null,
                                                          null,
                                                          null,
                                                          '可选群组类销售品到期，对应主销售品属性入属性队列');
          retResult            := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                          0,
                                                          'directProcBF',
                                                          0,
                                                          '',
                                                          '',
                                                          '',
                                                          '',
                                                          'optionGroupOfferDirectProc',
                                                          '可选群组类销售品到期，对应主销售品属性入属性队列');

        end if;
      end loop;
      commit;
    end loop;
    NULL;
    str_msg := 'success';
    --exception
  end optionalGroupOfferProc;

  procedure optionalOfferAttrProcForProd(str_msg out varchar) is
    datacount          number;
    expProcMeth        varchar(2);
    v_direct_proc_flag varchar(10); --该标识为yes标识为exp_proc_method = '2'的情况,自动处理档案.不为"yes"则标识要生成正常订单.
  begin
    v_direct_proc_flag := 1; --到期拆可选包默认都是自动档案处理.
    -- 获取在用的到期可选包
    for optionalOfferInst in (select a.exp_date,
                                     a.eff_date,
                                     a.end_auto,
                                     b.prod_offer_id,
                                     c.related_prod_offer_inst_id as prod_offer_inst_id,
                                     c.rela_prod_offer_inst_id as base_offer_inst_id,
                                     d.prod_inst_id as rela_prod_inst_id,
                                     e.area_code,
                                     g.area_id,
                                     g.region_cd,
                                     h.attr_value_id
                                from prod_offer_inst      a,
                                     prod_offer           b,
                                     prod_offer_inst_rel  c,
                                     offer_prod_inst_rel  d,
                                     prod_inst            e,
                                     product              f,
                                     prod_offer_inst      g,
                                     prod_offer_inst_attr h
                               where a.prod_offer_id = b.prod_offer_id
                                 and a.EXP_DATE < SYSDATE
                                 and a.status_cd = '1000'
                                 and b.offer_type in ('12', '13')
                                 and b.offer_sub_type = 'T04'
                                 and a.prod_offer_inst_id =
                                     h.prod_offer_inst_id
                                 and h.status_cd = '1000'
                                 and h.attr_id = 800003959
                                 and c.related_prod_offer_inst_id =
                                     a.prod_offer_inst_id
                                 and c.status_cd = '1000'
                                 and d.prod_offer_inst_id =
                                     c.related_prod_offer_inst_id
                                 and d.status_cd = '1000'
                                 and f.product_id = e.product_id
                                 and f.prod_func_type = '101'
                                 and e.prod_inst_id = d.prod_inst_id
                                 and g.prod_offer_inst_id =
                                     c.rela_prod_offer_inst_id
                                 --and a.eff_date != a.exp_date--zhengcl 20150608 crm00062573 更改为插入队列前判断 --zhengcl 20150608 crm00062573 更改为插入队列前判断
                                 ) loop

      if optionalOfferInst.Attr_Value_Id = 800019254 then
        --自动续约
        expProcMeth := '0';
      elsif optionalOfferInst.Attr_Value_Id = 800019255 then
        --自动拆机
        expProcMeth := '2';
      end if;
      if expProcMeth = '0' or expProcMeth = '2' then
        v_direct_proc_flag := IsCanDirectProc(optionalOfferInst.Prod_Offer_Id);
        datacount          := optionalAutoProcQueue(optionalOfferInst.Prod_Offer_Id,
                                                    optionalOfferInst.Prod_Offer_Inst_Id,
                                                    optionalOfferInst.Base_Offer_Inst_Id,
                                                    expProcMeth,
                                                    optionalOfferInst.Rela_Prod_Inst_Id,
                                                    optionalOfferInst.Area_Id,
                                                    optionalOfferInst.Region_Cd,
                                                    optionalOfferInst.Eff_Date,
                                                    optionalOfferInst.Exp_Date,
                                                    v_direct_proc_flag);
      end if;
    end loop;
    NULL;
    str_msg := 'success';
    --exception
  end optionalOfferAttrProcForProd;

 function optionalAutoProcQueue(v_prod_offer_id      in number,
                                v_prod_offer_inst_id in number,
                                v_base_offer_inst_id in number,
                                v_exp_proc_method    in varchar2,
                                v_rela_prod_inst_id  in number,
                                v_area_id            in number,
                                v_region_cd          in number,
                                v_eff_date           in date,
                                v_exp_date           in date,
                                v_direct_proc_flag   in number)
   return number is
   inst_action_type      varchar2(12);
   inst_status           varchar2(12);
   o_auto_proc_queue_id  number;
   retResult             number;
   base_inst_action_type varchar2(12);
   base_inst_src_type    varchar2(12); --主销售品动作
   inst_src_type         varchar2(12); --可选包动作
   is_need_prod_attr     number;
   prod_inst_action_type varchar2(12); --关联产品动作类型
   prod_inst_src_type    varchar2(12); --关联产品动作编码
   prod_attr_id          number; --需要插入产品属性ID
   o_prod_proc_queue_id  number; --产品队列标识
   base_prod_inst_id     number; ----主产品实例ID
   sub_prod_inst_id      number; --可选包拆除引发拆除程控ID
   v_new_exp_date        date;
   v_exp_eff_judge       boolean; --该标识为true，则生成队列数据；生失效时间一致，且小于当前时间+1个月才为false，不生成队列数据。
   v_cnt                 number; --zhengcl crm00062882 v_exp_eff_judge标识增加判断宽带续约属性延期一个月的校验。
 begin
   is_need_prod_attr := 0; --是否需要产品实例操作
   base_prod_inst_id := v_rela_prod_inst_id;
   case
     when v_exp_proc_method = '0' then
       --到期自动续约
       --获取
       SELECT ADD_MONTHS(exp_date, 12)
         INTO v_new_exp_date
         FROM PROD_OFFER_INST
        where PROD_OFFER_INST_ID = v_prod_offer_inst_id;
       --将满足条件的可选类销售品到期时间自动延长12个月
       update PROD_OFFER_INST
          set exp_date = v_new_exp_date, update_date = sysdate
        where PROD_OFFER_INST_ID = v_prod_offer_inst_id;
       --通过计费批量通知接口，通知计费。
       InsertIntoIntfInsBillingUpdate('PROD_OFFER_INST',
                                      'PROD_OFFER_INST_ID',
                                      v_prod_offer_inst_id,
                                      '到期自动续约处理延长12个月',
                                      v_area_id);
       ---可选包属性失效时间也要延长.
       for optionAttrInst in (SELECT *
                                FROM prod_offer_inst_attr
                               where prod_offer_inst_id =
                                     v_prod_offer_inst_id) loop
         update prod_offer_inst_attr
            set exp_date = v_new_exp_date, update_date = sysdate
          where prod_offer_inst_attr.prod_offer_inst_attr_id =
                optionAttrInst.Prod_Offer_Inst_Attr_Id;
         --失效时间属性,更改属性值
         if optionAttrInst.Attr_Id = 800000794 then
           update prod_offer_inst_attr
              set attr_value = to_char(v_new_exp_date, 'yyyy-MM-dd')
            where prod_offer_inst_attr.prod_offer_inst_attr_id =
                  optionAttrInst.Prod_Offer_Inst_Attr_Id;
         end if;
         ---如果属性本身是失效时间的,则属性值本身也要改.
         InsertIntoIntfInsBillingUpdate('PROD_OFFER_INST_ATTR',
                                        'PROD_OFFER_INST_ATTR_ID',
                                        optionAttrInst.Prod_Offer_Inst_Attr_Id,
                                        '到期自动续约处理延长12个月',
                                        v_area_id);
       end loop;

       commit;
       return 1;
     when v_exp_proc_method = '2' then
       --到期自动退订
       inst_status           := '200098';
       inst_action_type      := '3030100000'; --退订
       inst_src_type         := 'DELETE';
       base_inst_action_type := '3020500000'; --主销售品变更
       base_inst_src_type    := 'MOD';
       is_need_prod_attr     := 0;
     when v_exp_proc_method = '3' then
       --停机
       inst_status           := '200098';
       inst_action_type      := '3030100000'; --可选包删
       inst_src_type         := 'DELETE';
       base_inst_action_type := '3020500000'; --主销售品变更
       base_inst_src_type    := 'MOD';
       is_need_prod_attr     := 1;
       prod_inst_action_type := '4060100002'; --关联产品停机
       prod_inst_src_type    := 'MOD'; --关联产品动作
       prod_attr_id          := 800000253; --用户申请停机
     when v_exp_proc_method = '5' then
       --拆机
       --2012-9-15  modidy by 黄森都 原先是200098， 改成200099状态，生成队列数据用于观察
       inst_status           := '200099';
       inst_action_type      := '3030100000'; --可选包删
       inst_src_type         := 'DELETE';
       base_inst_action_type := '3030100000'; --主销售品删
       base_inst_src_type    := 'DELETE';
       is_need_prod_attr     := 1;
       prod_inst_action_type := '4020100000'; --产品拆机
       prod_inst_src_type    := 'DELETE';
     when v_exp_proc_method = '6' then
       --拆机停
       inst_status           := '200098';
       inst_action_type      := '3030100000'; --可选包拆
       inst_src_type         := 'DELETE';
       base_inst_action_type := '3020500000'; --主销售品变更
       base_inst_src_type    := 'MOD';
       is_need_prod_attr     := 1;
       prod_inst_action_type := '4060199999';
       prod_inst_src_type    := 'MOD';
       prod_attr_id          := 800000250; --拆机停-预拆机
   end case;
 --zhengcl 20150507 v_exp_proc_method=2,v_direct_proc_flag=0,且原先没有产品动作的情况,增加产品队列
   if v_direct_proc_flag = 0 and v_exp_proc_method = 2 and
      v_rela_prod_inst_id > 0 and is_need_prod_attr = 0 then
     is_need_prod_attr     := 1;
     prod_inst_action_type := '4040800000'; --关联产品属性变更
     prod_inst_src_type    := 'MOD'; --关联产品动作
   end if;
   /*zhengcl crm00062573 crm00062882 v_exp_eff_judge默认为true，则生成队列数据；
   生失效时间一致或有宽带续约属性，且小于当前时间+1个月才为false，可以延期一个月再插入队列不生成队列数据。*/
   v_exp_eff_judge := true;
    SELECT count(*)
       into v_cnt
       FROM prod_offer_inst_attr
      where attr_id = 800002919
        and status_cd = '1000'
        and prod_offer_inst_id = v_prod_offer_inst_id;
   if v_eff_date = v_exp_date or v_cnt > 0 then
     v_exp_eff_judge := false;
     if v_exp_date < add_months(SYSDATE, -1) then
       v_exp_eff_judge := true;
     end if;
   end if;
   --主销售品进列表
   o_auto_proc_queue_id := IsHasSameInstInQueue(v_base_offer_inst_id,
                                                'ProdOfferInst',
                                                '可选类销售品到期，对应主销售品入队列');
   /*
   1.满足生失效时间的要求 v_exp_eff_judge为true
   2.不存在v_base_offer_inst_id（主套餐）的到期队列，或者v_base_offer_inst_id存在'可选类销售品到期，对应主销售品入队列'的队列。
   3.不存在v_prod_offer_inst_id（可选包）的到期队列
   4.不需要产品标识，或者需要产品标识且对应的产品实例v_rela_prod_inst_id不存在到期队列。
   以上都满足，才能插入新的队列数据。
   */
   if (v_exp_eff_judge = true) and
      ((IsHasOfferInQueue(v_base_offer_inst_id, 'ProdOfferInst') = 0) or(o_auto_proc_queue_id > 0)) and
      (IsHasOfferInQueue(v_prod_offer_inst_id, 'ProdOfferInst') = 0) and
      (is_need_prod_attr <> 1 or(is_need_prod_attr = 1 and(IsHasOfferInQueue(v_rela_prod_inst_id, 'ProdInst') = 0))) then
     if o_auto_proc_queue_id = 0 then
       o_auto_proc_queue_id := InsertIntoOAutoProcQueueByArea(0,
                                                              v_base_offer_inst_id,
                                                              'ProdOfferInst',
                                                              base_inst_action_type,
                                                              base_inst_src_type,
                                                              inst_status,
                                                              '可选类销售品到期，对应主销售品入队列',
                                                              v_area_id,
                                                              v_region_cd);
       retResult            := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                       0,
                                                       'CHNCD',
                                                       0,
                                                       'INSERT',
                                                       '600105B021',
                                                       null,
                                                       null,
                                                       null,
                                                       '可选类销售品到期，对应主销售品属性入属性队列');
     end if;
     retResult := InsertIntoOAutoProcQueue(o_auto_proc_queue_id,
                                           v_prod_offer_inst_id,
                                           'ProdOfferInst',
                                           inst_action_type,
                                           inst_src_type,
                                           inst_status,
                                           '可选类销售品到期，可选包入队列');
     retResult := InsertIntoProcQueueAttr(retResult,
                                          0,
                                          'CHECK',
                                          0,
                                          null,
                                          null,
                                          'expDateCheck',
                                          '-1',
                                          null,
                                          '可选类销售品到期，可选包拆除校验属性入属性队列');
     if (v_eff_date = v_exp_date) and
        (IsHasAttrInQueue(o_auto_proc_queue_id,
                          0,
                          'validateAF',
                          0,
                          'yearLanValidate',
                          '',
                          '',
                          '') = 0) then
       retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                            0,
                                            'validateAF',
                                            0,
                                            'yearLanValidate',
                                            '',
                                            null,
                                            null,
                                            null,
                                            '可选类销售品到期，对应主销售品属性入属性队列');
     end if;
     --可选包到期拆除的情况,要插入一条属性,有该属性的队列是直接档案处理,不生成订单的.
     if (v_exp_proc_method = '2') and (v_direct_proc_flag = 1) and
        (v_prod_offer_id <> 800009108) and (v_eff_date <> v_exp_date) and
        (IsHasAttrInQueue(o_auto_proc_queue_id,
                          0,
                          'directProcBF',
                          0,
                          '',
                          '',
                          '',
                          'optionDirectProc') = 0) then
       retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                            0,
                                            'directProcBF',
                                            0,
                                            '',
                                            '',
                                            '',
                                            '',
                                            'optionDirectProc',
                                            '可选类销售品到期，对应主销售品属性入属性队列');
       --zhengcl crm00052976 有'directProcBF'属性的，状态改成'200097'，分轮训处理。
       update o_auto_proc_queue
          set status_cd = '200097'
        where queue_id = o_auto_proc_queue_id;
     end if;
     if (v_exp_proc_method <> '2') and
        (IsHasAttrInQueue(o_auto_proc_queue_id,
                          0,
                          'directProcBF',
                          0,
                          '',
                          '',
                          '',
                          'optionDirectProc') > 0) then
       delete from proc_queue_attr
        where queue_id = o_auto_proc_queue_id
          and obj_type = 'directProcBF'
          and valid_param2 = 'optionDirectProc';
       --zhengcl crm00052976 删除'directProcBF'属性的，状态恢复成'200098'。
       update o_auto_proc_queue
          set status_cd = '200098'
        where queue_id = o_auto_proc_queue_id;
     end if;
     --关联产品需要如队列
     if (is_need_prod_attr = 1) then
       o_prod_proc_queue_id := InsertIntoOAutoProcQueue(o_auto_proc_queue_id,
                                                        v_rela_prod_inst_id,
                                                        'ProdInst',
                                                        prod_inst_action_type,
                                                        prod_inst_src_type,
                                                        inst_status,
                                                        '可选类销售品到期，关联产品入队列');
       --如果产品是4060199999拆机停和4060100002停机
       if (prod_inst_action_type in ('4060100002', '4060199999')) then
         retResult := InsertIntoProcQueueAttr(o_prod_proc_queue_id,
                                              prod_attr_id,
                                              'EA',
                                              0,
                                              'INSERT',
                                              '1',
                                              null,
                                              null,
                                              null,
                                              '可选包到期引发产品动作，属性入属性队列');
         --用户申请停机的情况，要插入停机时间
         if (prod_inst_action_type = '4060100002') then
           retResult := InsertIntoProcQueueAttr(o_prod_proc_queue_id,
                                                '800000374',
                                                'EA',
                                                0,
                                                'INSERT',
                                                to_char(sysdate,
                                                        'yyyy-mm-dd'),
                                                null,
                                                null,
                                                null,
                                                '可选包到期引发产品动作，属性入属性队列');

         end if; --prod_inst_action_type
       end if;
     end if; --prod_inst_action_type
     ---气象时报天翼联名卡体验包800009108 到期 拆除 气象时报
     if v_prod_offer_id = 800009108 then
       if v_rela_prod_inst_id = 0 then
         SELECT count(*)
           into base_prod_inst_id
           FROM offer_prod_inst_rel opir
          where opir.prod_offer_inst_id = v_prod_offer_inst_id
            and opir.status_cd = '1000';
         if (base_prod_inst_id = 1) then
           SELECT opir.prod_inst_id
             into base_prod_inst_id
             FROM offer_prod_inst_rel opir
            where opir.prod_offer_inst_id = v_prod_offer_inst_id
              and opir.status_cd = '1000';
         end if;
       end if;
       if base_prod_inst_id > 1 then
         sub_prod_inst_id := IsHasQXSB(base_prod_inst_id);
       end if;
       if sub_prod_inst_id > 0 then
         --是否有气象时报程控
         o_prod_proc_queue_id := IsHasSameInstInQueue(base_prod_inst_id,
                                                      'ProdInst',
                                                      '可选类销售品到期，关联产品入队列');
         if o_prod_proc_queue_id = 0 then
           o_prod_proc_queue_id := InsertIntoOAutoProcQueue(o_auto_proc_queue_id,
                                                            base_prod_inst_id,
                                                            'ProdInst',
                                                            '3020500000',
                                                            'MOD',
                                                            inst_status,
                                                            '可选类销售品到期，关联产品入队列');
         end if;
         retResult := InsertIntoOAutoProcQueue(o_prod_proc_queue_id,
                                               sub_prod_inst_id,
                                               'ProdInst',
                                               '3030100000',
                                               'DELETE',
                                               inst_status,
                                               '可选类销售品到期拆除,引发功能类基础销售品拆除');
       end if;
     end if;
   end if; --is_need_prod_attr
   commit;
   --寻找与可选包，促销包强制依赖的可选包或者促销包--两端都找来
   begin
     for mustRelatedOptionaloffer in (select distinct b.related_prod_offer_inst_id as prod_offer_inst_id
                                        from prod_offer_inst     e,
                                             prod_offer          f,
                                             prod_offer_rel      g,
                                             prod_offer_inst_rel b
                                       where b.rela_prod_offer_inst_id =
                                             v_prod_offer_inst_id
                                         and b.prod_offer_rela_id =
                                             g.prod_offer_rela_id
                                         and g.relation_type_cd = '109998'
                                         and b.status_cd = '1000'
                                         and b.rela_prod_offer_inst_id =
                                             e.prod_offer_inst_id
                                         and e.prod_offer_id =
                                             f.prod_offer_id
                                         and f.offer_type in ('12', '13')
                                         and f.offer_sub_type in
                                             ('T04', 'T05')
                                      union (select distinct a.rela_prod_offer_inst_id
                                              from prod_offer_inst     c,
                                                   prod_offer          d,
                                                   prod_offer_rel      h,
                                                   prod_offer_inst_rel a
                                             where a.related_prod_offer_inst_id =
                                                   v_prod_offer_inst_id
                                               and a.prod_offer_rela_id =
                                                   h.prod_offer_rela_id
                                               and h.relation_type_cd =
                                                   '109998'
                                               and a.status_cd = '1000'
                                               and a.related_prod_offer_inst_id =
                                                   c.prod_offer_inst_id
                                               and d.prod_offer_id =
                                                   c.prod_offer_id
                                               and d.offer_type in
                                                   ('12', '13')
                                               and d.offer_sub_type in
                                                   ('T04', 'T05'))

                                      ) loop
       if (IsHasOfferInQueue(mustRelatedOptionaloffer.prod_offer_inst_id,
                             'ProdOfferInst') = 0) then
         retResult := InsertIntoOAutoProcQueue(o_auto_proc_queue_id,
                                               mustRelatedOptionaloffer.prod_offer_inst_id,
                                               'ProdOfferInst',
                                               inst_action_type,
                                               'DELETE',
                                               inst_status,
                                               '可选类销售品到期，被依赖可选包入队列');
         retResult := InsertIntoProcQueueAttr(retResult,
                                              0,
                                              'CHECK',
                                              0,
                                              null,
                                              null,
                                              'expDateCheck',
                                              '-1',
                                              null,
                                              '可选类销售品到期，被依赖可选包拆除校验属性入属性队列');
       end if;
     end loop;
     commit;
   end;
   /*zhengcl 20120823 1.0自动续约是通过读取套餐参数的配置，不是从基本信息里面获取到期处理方式。
    --2.0目前数据是直接拷自1.0的基本信息，所以还是先屏蔽掉。
   if (optionalOfferInst.exp_proc_method = 0) then
     --到期自动续约
     --将满足条件的可选类销售品到期时间自动延长12个月
     update prod_offer_inst po
        set po.exp_date = ADD_MONTHS(po.exp_date, 12)
      where po.prod_offer_inst_id = optionalOfferInst.prod_offer_inst_id;
     --datacount := datacount + 1;
     --通过计费批量通知接口，通知计费。
     v_area_code := SUBSTR(optionalOfferInst.Area_Code,
                           2,
                           LENGTH(optionalOfferInst.Area_Code));
     basejk.pkg_common.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('PROD_OFFER_INST',
                                                                'PROD_OFFER_INST_ID',
                                                                optionalOfferInst.prod_offer_inst_id,
                                                                '到期自动处理延长12个月',
                                                                '1002',
                                                                '可选包到期自动延长12个月',
                                                                '',
                                                                v_area_code);
     commit;
   end if;*/
   return 1;
 end;

  function baseOfferAutoProcQueue(v_base_offer_inst_id in number,
                                  v_prod_offer_id      in number,
                                  v_exp_proc_method    in varchar2,
                                  v_ibs_offer_type     in varchar2,
                                  v_area_id            in number,
                                  v_region_cd          in number,
                                  v_attrDelete         in number)
    return number is
    inst_status_cd         varchar2(6);
    offer_inst_action_type varchar2(12); --主销售品动作
    offer_inst_src_type    varchar2(6); --主销售品动作类型
    prod_inst_action_type  varchar2(12); --关联产品动作
    prod_inst_src_type     varchar2(6); --关联产品动作类型
    offer_queue_id         number; ---主销售品队列ID
    v_count                number;
    retResult              number;
  begin
    inst_status_cd := '200098';
    case
      when v_exp_proc_method = '2' then
        offer_inst_action_type := '3030100000'; --主套餐拆除
        offer_inst_src_type    := 'DELETE';
        prod_inst_action_type  := '4020100000'; --产品拆机
        prod_inst_src_type     := 'DELETE';
      when v_exp_proc_method = '5' then
        offer_inst_action_type := '3030100000'; --主套餐拆除
        offer_inst_src_type    := 'DELETE';
        prod_inst_action_type  := '4020100000'; --产品拆机
        prod_inst_src_type     := 'DELETE';
    end case;
    if (IsHasOfferInQueue(v_base_offer_inst_id, 'ProdOfferInst') = 0) then
      begin
        --判断对应产品实例是否已经有在队列表中了
        select count(*)
          into v_count
          from o_auto_proc_queue
         where src_type = 'ProdInst'
           and src_inst_id in
               (select pi.prod_inst_id
                  from offer_prod_inst_rel opin, prod_inst pi, product p
                 where opin.prod_offer_inst_id = v_base_offer_inst_id
                   and opin.prod_inst_id = pi.prod_inst_id
                   and pi.product_id = p.product_id
                   and opin.status_cd = '1000'
                   and p.prod_func_type = '101');

        if v_count = 0 then
          --插入接入类销售品删除的数据
          offer_queue_id := InsertIntoOAutoProcQueueByArea(0,
                                                           v_base_offer_inst_id,
                                                           'ProdOfferInst',
                                                           offer_inst_action_type,
                                                           offer_inst_src_type,
                                                           inst_status_cd,
                                                           '接入类基础销售品到期处理',
                                                           v_area_id,
                                                           v_region_cd);
          retResult      := InsertIntoProcQueueAttr(offer_queue_id,
                                                    0,
                                                    'CHNCD',
                                                    0,
                                                    'INSERT',
                                                    '600105B021',
                                                    null,
                                                    null,
                                                    null,
                                                    '接入类基础销售品到期处理，对应主销售品属性入属性队列');
          if v_attrDelete = 0 then--v_attrDelete为1标识是因为有“数据卡使用时长(天)”属性引发的队列，不判断失效时间
            retResult := InsertIntoProcQueueAttr(offer_queue_id,
                                                 0,
                                                 'CHECK',
                                                 0,
                                                 null,
                                                 null,
                                                 'expDateCheck',
                                                 '-1',
                                                 null,
                                                 '接入类基础销售品到期处理，对应主销售品属性入属性队列');
          end if;
          for relaProdInst in (select pi.prod_inst_id
                                 from offer_prod_inst_rel opin,
                                      prod_inst           pi,
                                      product             p
                                where opin.prod_offer_inst_id =
                                      v_base_offer_inst_id
                                  and opin.prod_inst_id = pi.prod_inst_id
                                  and pi.product_id = p.product_id
                                  and opin.status_cd = '1000'
                                  and p.prod_func_type = '101') loop
            if v_ibs_offer_type = '10020' then
              --多接入类的情况，下挂产品实例，增加变更动作 目前暂时不处理，已经在查询语句中过滤了
              retResult := InsertIntoOAutoProcQueue(offer_queue_id,
                                                    relaProdInst.prod_inst_id,
                                                    'ProdInst',
                                                    '3020500000',
                                                    'MOD',
                                                    inst_status_cd,
                                                    '多接入类基础销售品到期处理引发产品动作');

            else
              --单接入类的情况，下挂产品实例，增加删除动作
              retResult := InsertIntoOAutoProcQueue(offer_queue_id,
                                                    relaProdInst.prod_inst_id,
                                                    'ProdInst',
                                                    prod_inst_action_type,
                                                    prod_inst_src_type,
                                                    inst_status_cd,
                                                    '接入类基础销售品到期处理');

            end if;
          end loop;
        end if;
        commit;
      end;
    end if;
    return 1;
  end;

  -- Author  : LITTLEHUI
  -- Created : 2012/6/15 17:31:27
  -- Purpose : 接入类基础销售品  接入类销售品自动续约的情况暂时不处理,多接入类销售品的情况也不处理
  procedure procAccBaseOffer(str_msg out varchar) is
    inst_action_type varchar2(12);
    inst_status_cd   varchar2(12);
    src_type         varchar(12);
    retResult        number;
    offer_queue_id   number;
    v_count          number;
    v_funResult      number;
    v_attrDelete     number; ----是有“数据卡使用时长(天)”属性的生成的退订标识.1：因为属性生成退订标识，0:因为到期生成退订标识。
    v_addQueueFlag   number; ----生成队列标识。1：要生成队列，0：不生成队列。
  begin
    -- 获取在用的到期接入类基础销售品
    v_attrDelete := 0;
    v_addQueueFlag:= 0;
    for accBaseOffer in (select prod_offer_id
                           from prod_offer
                          where (exp_proc_method = '2' or
                                exp_proc_method = '5')
                            and offer_type in ('10', '11')
                            and offer_sub_type = 'T01'
                            --and prod_offer_id = 901313222 -------------------测试
                            and ibs_offer_type != '10020') loop
      --zhengcl 如果有配置数据卡使用时长(天)，走特别分支
      select count(*)
        into v_count
        from prod_offer_attr
       where attr_id = 800078981
         and prod_offer_id = accBaseOffer.Prod_Offer_Id
         and status_cd = '1000';
      if v_count > 0 then
        for accBaseOfferInst in (select a.prod_offer_inst_id,
                                        a.exp_date,
                                        a.end_auto,
                                        b.prod_offer_id,
                                        b.exp_proc_method,
                                        b.ibs_offer_type,
                                        a.area_id,
                                        a.region_cd
                                   from prod_offer_inst a, prod_offer b
                                  where a.prod_offer_id = b.prod_offer_id
                                    and a.status_cd = '1000'
                                    --and a.prod_offer_inst_id = 2945581645--------------测试
                                    and b.prod_offer_id =
                                        accBaseOffer.Prod_Offer_Id) loop
          select count(*)
            into v_count
            from prod_offer_inst_attr
           where attr_id = 800078981
             and prod_offer_inst_id = accBaseOfferInst.Prod_Offer_Inst_Id;
          v_attrDelete   := 0; ----初始化为0，如果有“数据卡使用时长(天)”属性设置为1
          v_addQueueFlag := 0; ----初始化为0，如果有“数据卡使用时长(天)”属性或者可选包到期设置为1，插入队列
          if v_count > 0 then
            v_attrDelete   := 1;
            v_addQueueFlag := 1;
          elsif accBaseOfferInst.Exp_Date < sysdate then
            v_addQueueFlag := 1;
          end if;
          if v_addQueueFlag = 1 then
            v_funResult := baseOfferAutoProcQueue(accBaseOfferInst.Prod_Offer_Inst_Id,
                                                  accBaseOfferInst.Prod_Offer_Id,
                                                  accBaseOfferInst.Exp_Proc_Method,
                                                  accBaseOfferInst.Ibs_Offer_Type,
                                                  accBaseOfferInst.Area_Id,
                                                  accBaseOfferInst.Region_Cd,
                                                  v_attrDelete);
          end if;
        end loop;
      else
        for accBaseOfferInst in (select a.prod_offer_inst_id,
                                        a.exp_date,
                                        a.end_auto,
                                        b.prod_offer_id,
                                        b.exp_proc_method,
                                        b.ibs_offer_type,
                                        a.area_id,
                                        a.region_cd
                                   from prod_offer_inst a, prod_offer b
                                  where a.prod_offer_id = b.prod_offer_id
                                    and a.exp_date < sysdate
                                    and a.status_cd = '1000'
                                    --and a.prod_offer_inst_id=2945974831--------------测试
                                    and b.prod_offer_id =
                                        accBaseOffer.Prod_Offer_Id) loop
          v_funResult := baseOfferAutoProcQueue(accBaseOfferInst.Prod_Offer_Inst_Id,
                                                accBaseOfferInst.Prod_Offer_Id,
                                                accBaseOfferInst.Exp_Proc_Method,
                                                accBaseOfferInst.Ibs_Offer_Type,
                                                accBaseOfferInst.Area_Id,
                                                accBaseOfferInst.Region_Cd,
                                                0);
        end loop;
      end if;
    end loop;
    str_msg := 'success';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'exception';
  end;

  -- Author  : LITTLEHUI
  -- Created : 2012/6/18 17:31:27
  -- Purpose : 功能基础销售品
  procedure procFuncBaseOffer(str_msg out varchar) is
    inst_action_type     varchar2(12);
    inst_status_cd       varchar2(12);
    o_auto_proc_queue_id number;
    /*prod_offer_inst_spec number;
    prod_inst_spec       number;
    s_prod_inst_id       number;*/
    retResult          number;
    datacount          number;
    add_product_id     number;
    prod_proc_queue_id number;
  begin
    -- 获取在用的到期功能类销售品
    datacount := 0;
    for funcBaseOfferInst in (select a.prod_offer_inst_id,
                                     a.exp_date,
                                     a.end_auto,
                                     b.prod_offer_id,
                                     c.prod_inst_id as fun_prod_inst_id,
                                     d.acc_prod_inst_id,
                                     b.prod_offer_name,
                                     af.prod_offer_inst_id base_offer_inst_id,
                                     bf.area_id,
                                     bf.region_cd
                                from prod_offer_inst     a,
                                     prod_offer          b,
                                     offer_prod_inst_rel c,
                                     prod_inst           d,
                                     offer_prod_inst_rel af,
                                     prod_offer_inst     bf,
                                     prod_offer          cf,
                                     prod_inst           pi
                               where a.prod_offer_id = b.prod_offer_id
                                 and a.exp_date < sysdate
                                 and a.status_cd = '1000'
                                 and b.offer_type = '10'
                                 and b.offer_sub_type = 'T02'
                                 and b.exp_proc_method = '2'
                                 and c.prod_offer_inst_id =
                                     a.prod_offer_inst_id
                                 and c.status_cd = '1000'
                                 and d.prod_inst_id = c.prod_inst_id
                                 and af.prod_inst_id = d.acc_prod_inst_id
                                 and af.prod_offer_inst_id =
                                     bf.prod_offer_inst_id
                                 and bf.prod_offer_id = cf.prod_offer_id
                                 and cf.offer_type in ('10', '11')
                                 and af.status_cd = '1000'
                                 AND pi.prod_inst_id = d.acc_prod_inst_id
                                 AND pi.status_cd != '120000') loop
      inst_status_cd   := '200098';
      inst_action_type := '3020500000';
      begin
        o_auto_proc_queue_id := IsHasSameInstInQueue(funcBaseOfferInst.base_offer_inst_id,
                                                     'ProdOfferInst',
                                                     '功能类基础销售品到期处理主销售品入队列');
        prod_proc_queue_id   := IsHasSameInstInQueue(funcBaseOfferInst.acc_prod_inst_id,
                                                     'ProdInst',
                                                     '功能类基础销售品到期处理构成产品入队列');
        if ((IsHasOfferInQueue(funcBaseOfferInst.base_offer_inst_id,
                               'ProdOfferInst') = 0) or
           (o_auto_proc_queue_id > 0)) and ((IsHasOfferInQueue(funcBaseOfferInst.acc_prod_inst_id,
                                                               'ProdInst') = 0) or
           (prod_proc_queue_id > 0)) and
           (IsHasOfferInQueue(funcBaseOfferInst.fun_prod_inst_id,
                              'ProdInst') = 0) then
          if o_auto_proc_queue_id = 0 then
            o_auto_proc_queue_id := InsertIntoOAutoProcQueueByArea(0,
                                                                   funcBaseOfferInst.base_offer_inst_id,
                                                                   'ProdOfferInst',
                                                                   '3020500000',
                                                                   'MOD',
                                                                   inst_status_cd,
                                                                   '功能类基础销售品到期处理主销售品入队列',
                                                                   funcBaseOfferInst.Area_Id,
                                                                   funcBaseOfferInst.Region_Cd);
          end if;
          if prod_proc_queue_id = 0 then
            prod_proc_queue_id := InsertIntoOAutoProcQueue(o_auto_proc_queue_id,
                                                           funcBaseOfferInst.acc_prod_inst_id,
                                                           'ProdInst',
                                                           '3020500000',
                                                           'MOD',
                                                           inst_status_cd,
                                                           '功能类基础销售品到期处理构成产品入队列');
          end if;
          retResult := InsertIntoOAutoProcQueue(prod_proc_queue_id,
                                                funcBaseOfferInst.fun_prod_inst_id,
                                                'ProdInst',
                                                '3030100000',
                                                'DELETE',
                                                inst_status_cd,
                                                '功能类基础销售品到期处理程控入队列');
          retResult := InsertIntoProcQueueAttr(retResult,
                                               0,
                                               'CHECK',
                                               0,
                                               null,
                                               null,
                                               'expDateCheck',
                                               '-1',
                                               null,
                                               '到期功能类基础销售品,增加属性校验判断');
          --拆除国际长途，国际漫游需补装国内长途国内漫游
          --（--800001727国际长途--800001592国际漫游）
          --product_id 800000330--国内漫游800303463--国内长途
          if (funcBaseOfferInst.prod_offer_id in (800001727, 800001592)) then
            if (funcBaseOfferInst.prod_offer_id = 800001727) then
              add_product_id := 800303463;
            end if;
            if (funcBaseOfferInst.prod_offer_id = 800001592) then
              add_product_id := 800000330;
            end if;
            retResult := InsertIntoOAutoProcQueue(prod_proc_queue_id,
                                                  add_product_id,
                                                  'Product',
                                                  '3010100000',
                                                  'ADD',
                                                  inst_status_cd,
                                                  '补装国内长途,国内漫游');
          end if;
        end if;
        commit;
        /*
        --获得要拆的产品ID
        select a.prod_inst_id
          into s_prod_inst_id
          from prod_inst a, prod_offer_inst b, offer_prod_inst_rel c
         where c.prod_offer_inst_id = funcBaseOfferInst.prod_offer_inst_id
           and b.prod_offer_inst_id = funcBaseOfferInst.prod_offer_inst_id
           and a.prod_inst_id = c.prod_inst_id;
        select product_id a
          into prod_inst_spec
          from prod_inst a
         where a.prod_inst_id = s_prod_inst_id;
        retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                             prod_inst_spec,
                                             'funProd',
                                             s_prod_inst_id,
                                             'DELETE',
                                             '拆除功能类基础销售品关联的功能类产品');*/

      end;
      --获取强制选择的可选包
      /*
        begin
          for mustRelaOfferInst in (select a.prod_offer_inst_id,
                                           d.prod_offer_id
                                      from prod_offer_inst     a,
                                           prod_inst           b,
                                           offer_prod_inst_rel c,
                                           prod_offer          d,
                                           offer_prod_rel      e
                                     where b.prod_inst_id = s_prod_inst_id
                                       and b.prod_inst_id = c.prod_inst_id
                                       and a.prod_offer_inst_id =
                                           c.prod_offer_inst_id
                                       and c.offer_prod_rel_id =
                                           e.offer_prod_rela_id
                                       and a.prod_offer_id = d.prod_offer_id
                                       and e.rule_type = '12' --强制选择
                                       and (d.offer_type in ('12', '10') or
                                           d.offer_sub_type = 'T02') --12可选包
                                    ) loop
            -- and a.prod_offer_inst not IN ()
            --插入要拆的可选包
            retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                                 mustRelaOfferInst.prod_offer_id,
                                                 'funOffer',
                                                 mustRelaOfferInst.prod_offer_inst_id,
                                                 'DELETE',
                                                 '功能类基础销售品拆除强制依赖可选包');

          end loop;
          commit;

        end;
      */
      /*
      begin
        --获取拆除产品关联的可选类产品
        for mustRelaProdInst IN (select a.prod_inst_id
                                   from prod_inst        a,
                                        prod_inst_rel    b,
                                        product          c,
                                        product_relation d
                                  where a.prod_inst_id = b.prod_inst_a_id
                                    and b.product_rel_id = d.product_rel_id
                                    and c.product_id = d.product_Z_id
                                    and d.relation_type_cd = '12' --强制依赖
                                    and a.prod_inst_id = prod_inst_id) loop
          --插入要拆的产品
          retResult := InsertIntoProcQueueAttr(o_auto_proc_queue_id,
                                               prod_inst_spec,
                                               'funProd',
                                               mustRelaProdInst.prod_inst_id,
                                               'DELETE',
                                               '功能类基础销售品拆除强制依赖功能类产品');
        end loop;
        commit;
      end;
      */
      if (datacount = 1) then
        goto outline;
      end if;
      <<endloop>>
      NULL;
    end loop;
    <<outline>>
    NULL;
    str_msg := 'success';

  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'exception';
  end;

  procedure changeNumbers(str_msg out varchar) is
    /*inst_action_type     varchar2(12);
    inst_status_cd       varchar2(12);
    o_auto_proc_queue_id number;
    prod_offer_inst_spec number;
    prod_inst_spec       number;
    base_offer_inst_id   number;
    s_prod_inst_id       number;*/
    retResult number;
    datacount number;
    add_mon   number;
  begin
    /* 通过改号通知时长来判断
    800000488 1个月
    800000489 2个月
    800000490 3个月
    800000491 4个月
    800000492 5个月
    800000493 6个月*/
    datacount := 0;
    for changeNumberProduct in (select a.attr_value_id,
                                       a.create_date,
                                       b.prod_inst_id,
                                       b.status_cd,
                                       b.area_id,
                                       b.common_region_id
                                  from prod_inst_attr a, prod_inst b
                                 where a.attr_id = 800000270 --改号通知时长
                                   and b.prod_inst_id = a.prod_inst_id
                                   and b.status_cd = '100000') loop
      case
        when changeNumberProduct.attr_value_id = 800000488 then
          add_mon := 1;
        when changeNumberProduct.attr_value_id = 800000489 then
          add_mon := 2;
        when changeNumberProduct.attr_value_id = 800000490 then
          add_mon := 3;
        when changeNumberProduct.attr_value_id = 800000491 then
          add_mon := 4;
        when changeNumberProduct.attr_value_id = 800000492 then
          add_mon := 5;
        when changeNumberProduct.attr_value_id = 800000493 then
          add_mon := 6;
        else
          add_mon := 1;
      end case;
      if (ADD_MONTHS(changeNumberProduct.create_date, add_mon) < sysdate) and
         (IsHasOfferInQueue(changeNumberProduct.prod_inst_id, 'ProdInst') = 0) then
        --到期拆除
        retResult := InsertIntoOAutoProcQueueByArea(0,
                                                    changeNumberProduct.prod_inst_id,
                                                    'ProdInst',
                                                    '3030100000',
                                                    'DELETE',
                                                    '200098',
                                                    '改号通知到期自动拆机处理',
                                                    changeNumberProduct.Area_Id,
                                                    changeNumberProduct.Common_Region_Id);
        commit;
        --datacount := datacount + 1;

      end if; --create_date
      if (datacount > 0) then
        goto outloop;
      end if;
    end loop;
    <<outloop>>
    null;
    str_msg := 'success';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'exception';
  end changeNumbers;

  PROCEDURE procOptionOfferNotOrder(i_queue_id      IN o_auto_proc_queue.queue_id%TYPE, ---主队列ID
                                    o_result        OUT VARCHAR2,
                                    o_msg           OUT VARCHAR2,
                                    o_cust_order_id OUT customer_order.cust_order_id%TYPE) ---产生的订单ID
   IS
    v_cust_so_number       customer_order.cust_so_number%TYPE; --订单流水号
    v_cust_order_id        customer_order.cust_order_id%TYPE; --订单id
    v_offer_order_item_id  order_item.order_item_id%TYPE; --销售品订单项id
    v_option_order_item_id order_item.order_item_id%TYPE; --可选包订单项id
    v_prod_offer_inst      prod_offer_inst%ROWTYPE; --主销售品实例
    v_channel_nbr          channel.channel_nbr%TYPE; -- 渠道编码
    v_auto_queue           o_auto_proc_queue%ROWTYPE; --队列
    v_option_offer_inst    prod_offer_inst%ROWTYPE; --可选包销售品实例
    v_option_auto_queue    o_auto_proc_queue%ROWTYPE; --可选包队列
    v_intf_staff_id        number; --接口工号
    v_intf_org_id          NUMBER; --接口团队
    v_count                number; --数量
  BEGIN
    o_result        := 'FALSE';
    o_cust_order_id := 0;
    v_intf_staff_id := 51447;
    v_intf_org_id   := 1020001;
    /*****************************************************************************************
      1. 校验数据
    ******************************************************************************************/
    ---获取队列对象
    BEGIN
      SELECT *
        INTO v_auto_queue
        FROM o_auto_proc_queue a
       WHERE a.queue_id = i_queue_id;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        o_msg := '产生订单失败. 队列不存在.队列id: ' || i_queue_id || '    ' || SQLERRM;
        RETURN;
    END;
    ---可选包是否已经延期或者失效了
    SELECT count(*)
      into v_count
      FROM prod_offer_inst poi, o_auto_proc_queue oa, prod_offer po
     where oa.super_queue_id = i_queue_id
       and po.prod_offer_id = poi.prod_offer_id
       and oa.src_type = 'ProdOfferInst'
       and oa.src_inst_id = poi.prod_offer_inst_id
       and (poi.status_cd = '1100' or poi.exp_date > sysdate or
           po.exp_proc_method != 2);
    if v_count > 0 then
      delete proc_queue_attr
       where queue_id = v_auto_queue.queue_id
         and obj_type = 'directProcBF'
         and valid_param2 = 'optionDirectProc';
      commit;
      o_msg := '当前队列无到期可选包要处理';
      RETURN;
    end if;
    ----获取主销售品
    BEGIN
      SELECT b.*
        INTO v_prod_offer_inst
        FROM o_auto_proc_queue a, prod_offer_inst b
       WHERE a.src_inst_id = b.prod_offer_inst_id
         AND a.queue_id = i_queue_id;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        o_msg := '产生订单失败. 主销售品实例不存在.队列id: ' || i_queue_id || '    ' ||
                 SQLERRM;
        RETURN;
    END;

    SELECT nvl(a.obj_value, '600105B017')
      INTO v_channel_nbr
      FROM proc_queue_attr a
     WHERE a.queue_id = i_queue_id
       AND a.obj_type = 'CHNCD';
    IF v_channel_nbr IS NULL THEN
      o_msg := '产生订单失败. 渠道编码属性不存在.队列id: ' || i_queue_id || '    ' ||
               SQLERRM;
      --raise_application_error(-20203, o_msg);
      RETURN;
    END IF;
    --判断是否有购机消费卷
    select count(*)
      into v_count
      from mkt_res_Inst_attr      a,
           mkt_res_inst_attr_rela b,
           prod_offer_inst        oi,
           offer_prod_inst_rel    r,
           prod_inst              p
     where a.attr_id = b.attr_id
       and b.mkt_res_type_id = '610005445'
       and a.attr_value = p.acc_nbr
       and oi.prod_offer_inst_id = r.prod_offer_inst_id
       and r.prod_inst_id = p.prod_inst_id
       and oi.prod_offer_inst_id = v_prod_offer_inst.prod_offer_inst_id
       and exists
     (select 1
              from mkt_res_Inst_attr a2,
                   o_auto_proc_queue q,
                   prod_offer_inst   poi
             where a2.attr_value = to_char(poi.prod_offer_id)
               and q.src_inst_id = poi.prod_offer_inst_id
               and q.super_queue_id = v_auto_queue.queue_id
               and q.src_type = 'ProdOfferInst'
               and a2.mkt_res_inst_id = a.mkt_res_inst_id);
    if v_count > 0 then
      delete proc_queue_attr
       where queue_id = v_auto_queue.queue_id
         and obj_type = 'directProcBF'
         and valid_param2 = 'optionDirectProc';
      commit;
      o_msg := '当前号码有购机消费券,不能直接处理档案!';
      RETURN;
    end if;
    --过滤指定动作的在途单
    SELECT count(*)
      into v_count
      FROM order_item_act_rela oiar,
           order_item          oi,
           order_item          oi2,
           attr_value          a
     where oi.order_item_obj_id = v_prod_offer_inst.prod_offer_inst_id
       and oi.class_id = 6
       and oi.cust_order_id = oi2.cust_order_id
       and oi2.order_item_id = oiar.order_item_id
       and a.attr_id = 950000970
       and a.attr_value = oiar.service_offer_id;
    if v_count > 0 then
      o_msg := '当前号码有在途单!';
      RETURN;
    end if;

    /*****************************************************************************************
      2. 订单处理
    ******************************************************************************************/
    --生成新的订单流水号
    SELECT 'FJ' || TO_CHAR(SYSDATE, 'YYYYMMDD') ||
           LPAD(TO_CHAR(SEQ_CUSTOMER_ORDER_SO_NUMBER.NEXTVAL), 8, '0')
      INTO v_cust_so_number
      FROM DUAL;

    --订单id
    SELECT seq_customer_order_id.nextval INTO v_cust_order_id FROM dual;
    --插订单
    INSERT INTO customer_order_his
      (cust_order_id,
       customer_interaction_event_id,
       channel_id,
       cust_id,
       staff_id,
       cust_so_number,
       cust_order_type,
       status_cd,
       status_date,
       pre_handle_flag,
       handle_people_name,
       priority,
       reason,
       create_date,
       update_date,
       accept_time,
       ext_cust_order_id,
       lan_id,
       remark,
       book_time,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       org_id,
       his_id,
       order_from,
       db_inst_id,
       proc_priority)
      SELECT v_cust_order_id, --CUST_ORDER_ID,
             NULL, --CUSTOMER_INTERACTION_EVENT_ID,
             (SELECT c.channel_id
                FROM channel c
               WHERE c.channel_nbr = v_channel_nbr
                 AND rownum = 1), --CHANNEL_ID,
             v_prod_offer_inst.cust_id, --CUST_ID,
             v_intf_staff_id, --STAFF_ID,
             v_cust_so_number, --CUST_SO_NUMBER,
             '101', --CUST_ORDER_TYPE,???
             '300000', --STATUS_CD,(300000: 竣工)
             SYSDATE, --STATUS_DATE,
             NULL, --PRE_HANDLE_FLAG,
             NULL, --HANDLE_PEOPLE_NAME,
             '100', --PRIORITY,
             NULL, --REASON,
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             SYSDATE, --ACCEPT_TIME,
             NULL, --EXT_CUST_ORDER_ID,
             NULL, --LAN_ID,
             NULL, --REMARK,
             NULL, --BOOK_TIME,
             v_auto_queue.area_id, --AREA_ID,
             v_auto_queue.region_cd, --REGION_CD,
             v_intf_staff_id, --UPDATE_STAFF,
             v_intf_staff_id, --CREATE_STAFF,
             v_intf_org_id, --ORG_ID,
             seq_customer_order_his_id.nextval, --HIS_ID,
             v_channel_nbr, --ORDER_FROM,
             NULL, --DB_INST_ID,
             NULL --PROC_PRIORITY,
        FROM dual;

    ---插销售品订单项
    SELECT seq_order_item_id.nextval INTO v_offer_order_item_id FROM dual;
    INSERT INTO order_item_his
      (order_item_id,
       cust_order_id,
       order_item_cd,
       cust_worksheet_id,
       status_cd,
       status_date,
       status_change_reason,
       priority,
       pre_handle_flag,
       handle_time,
       archive_date,
       finish_time,
       order_item_obj_id,
       install_time_segment_id,
       begin_time_segment_id,
       service_offer_id,
       create_date,
       update_date,
       reason,
       ext_order_item_id,
       lan_id,
       class_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       his_id,
       order_class_id,
       db_inst_id,
       pf_process_flag,
       proc_priority)
      SELECT v_offer_order_item_id, --ORDER_ITEM_ID,
             v_cust_order_id, --CUST_ORDER_ID,
             '1200', --ORDER_ITEM_CD,(1200: 销售品订单项)
             NULL, --CUST_WORKSHEET_ID,
             '300000', --STATUS_CD,(300000: 竣工)
             SYSDATE, --STATUS_DATE,
             NULL, --STATUS_CHANGE_REASON,
             NULL, --PRIORITY,
             NULL, --PRE_HANDLE_FLAG,
             NULL, --HANDLE_TIME,
             SYSDATE, --ARCHIVE_DATE,
             SYSDATE, --FINISH_TIME,
             v_prod_offer_inst.prod_offer_inst_id, --ORDER_ITEM_OBJ_ID,
             NULL, --INSTALL_TIME_SEGMENT_ID,
             NULL, --BEGIN_TIME_SEGMENT_ID,
             503, --SERVICE_OFFER_ID,--503: 变更
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             NULL, --REASON,
             NULL, --EXT_ORDER_ITEM_ID,
             NULL, --LAN_ID,
             6, --CLASS_ID,
             v_auto_queue.area_id, --AREA_ID,
             v_auto_queue.region_cd, --REGION_CD,
             v_intf_staff_id, --UPDATE_STAFF,
             v_intf_staff_id, --CREATE_STAFF,
             seq_order_item_his_id.nextval, --HIS_ID,
             NULL, --ORDER_CLASS_ID,
             NULL, --DB_INST_ID,
             NULL, --PF_PROCESS_FLAG,
             NULL --PROC_PRIORITY,
        FROM dual;

    ---处理子队列的可选包
    FOR rec IN (SELECT *
                  FROM o_auto_proc_queue oap
                 WHERE oap.super_queue_id = i_queue_id) LOOP
      ---获取队列对象
      BEGIN
        SELECT *
          INTO v_option_auto_queue
          FROM o_auto_proc_queue a
         WHERE a.queue_id = rec.queue_id;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          o_msg := '产生订单失败. 子队列不存在.队列id: ' || rec.queue_id || '    ' ||
                   SQLERRM;
          --raise_application_error(-20204, o_msg);
          RETURN;
      END;

      ----获取销售品
      BEGIN
        SELECT b.*
          INTO v_option_offer_inst
          FROM o_auto_proc_queue a, prod_offer_inst b
         WHERE a.src_inst_id = b.prod_offer_inst_id
           AND a.queue_id = rec.queue_id;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          o_msg := '产生订单失败. 可选包实例不存在.队列id: ' || rec.queue_id || '    ' ||
                   SQLERRM;
          --raise_application_error(-20205, o_msg);
          RETURN;
      END;

      ---插销售品订单项
      SELECT seq_order_item_id.nextval
        INTO v_option_order_item_id
        FROM dual;
      INSERT INTO order_item_his
        (order_item_id,
         cust_order_id,
         order_item_cd,
         cust_worksheet_id,
         status_cd,
         status_date,
         status_change_reason,
         priority,
         pre_handle_flag,
         handle_time,
         archive_date,
         finish_time,
         order_item_obj_id,
         install_time_segment_id,
         begin_time_segment_id,
         service_offer_id,
         create_date,
         update_date,
         reason,
         ext_order_item_id,
         lan_id,
         class_id,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id,
         order_class_id,
         db_inst_id,
         pf_process_flag,
         proc_priority)
        SELECT v_option_order_item_id, --ORDER_ITEM_ID,
               v_cust_order_id, --CUST_ORDER_ID,
               '1200', --ORDER_ITEM_CD,(1200: 销售品订单项)
               NULL, --CUST_WORKSHEET_ID,
               '300000', --STATUS_CD,(300000: 竣工)
               SYSDATE, --STATUS_DATE,
               NULL, --STATUS_CHANGE_REASON,
               NULL, --PRIORITY,
               NULL, --PRE_HANDLE_FLAG,
               NULL, --HANDLE_TIME,
               SYSDATE, --ARCHIVE_DATE,
               SYSDATE, --FINISH_TIME,
               v_option_offer_inst.prod_offer_inst_id, --ORDER_ITEM_OBJ_ID,
               NULL, --INSTALL_TIME_SEGMENT_ID,
               NULL, --BEGIN_TIME_SEGMENT_ID,
               501, --SERVICE_OFFER_ID,--503: 变更
               SYSDATE, --CREATE_DATE,
               SYSDATE, --UPDATE_DATE,
               NULL, --REASON,
               NULL, --EXT_ORDER_ITEM_ID,
               NULL, --LAN_ID,
               6, --CLASS_ID,
               v_option_auto_queue.area_id, --AREA_ID,
               v_option_auto_queue.region_cd, --REGION_CD,
               v_intf_staff_id, --UPDATE_STAFF,
               v_intf_staff_id, --CREATE_STAFF,
               seq_order_item_his_id.nextval, --HIS_ID,
               NULL, --ORDER_CLASS_ID,
               NULL, --DB_INST_ID,
               NULL, --PF_PROCESS_FLAG,
               NULL --PROC_PRIORITY,
          FROM dual;

      INSERT INTO order_item_rel_his
        (product_order_rel_id,
         a_order_item_id,
         z_order_item_id,
         order_rel_type,
         status_cd,
         status_date,
         create_date,
         update_date,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         db_inst_id,
         his_id)
        SELECT seq_order_item_rel_id.nextval, ---product_order_rel_id
               v_offer_order_item_id, ---a_order_item_id
               v_option_order_item_id, --z_order_item_id
               '10', --order_rel_type
               '1000', --status_cd
               SYSDATE, --status_date
               SYSDATE, --create_date
               SYSDATE, --update_date
               v_option_auto_queue.area_id, --AREA_ID,
               v_option_auto_queue.region_cd, --REGION_CD,
               v_intf_staff_id, --UPDATE_STAFF,
               v_intf_staff_id, --CREATE_STAFF,
               NULL,
               seq_order_item_rel_his_id.nextval
          FROM dual;

      /*****************************************************************************************
            3. 档案处理
      ******************************************************************************************/
      -- 1.offer_prod_inst_rel
      FOR v_offer_prod_inst_rel IN (SELECT *
                                      FROM OFFER_PROD_INST_REL
                                     WHERE prod_offer_inst_id =
                                           v_option_offer_inst.prod_offer_inst_id) LOOP
        insert into OFFER_PROD_INST_REL_HIS
          (HIS_ID,
           OFFER_PROD_INST_REL_ID,
           PROD_INST_ID,
           PROD_OFFER_INST_ID,
           ROLE_CD,
           OFFER_PROD_INST_REL_ROLE_ID,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           EFF_DATE,
           EXP_DATE,
           UPDATE_DATE,
           PROC_SERIAL,
           OFFER_PROD_REL_ID,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           REC_UPDATE_DATE,
           EXT_FLAG)
        values
          (SEQ_OFFER_PROD_INST_REL_HIS_ID.NEXTVAL,
           v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ID,
           v_offer_prod_inst_rel.PROD_INST_ID,
           v_offer_prod_inst_rel.PROD_OFFER_INST_ID,
           v_offer_prod_inst_rel.ROLE_CD,
           v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ROLE_ID,
           '1100',
           v_offer_prod_inst_rel.STATUS_DATE,
           v_offer_prod_inst_rel.CREATE_DATE,
           v_offer_prod_inst_rel.EFF_DATE,
           v_option_offer_inst.exp_date,
           sysdate,
           v_option_order_item_id,
           v_offer_prod_inst_rel.OFFER_PROD_REL_ID,
           v_offer_prod_inst_rel.AREA_ID,
           v_offer_prod_inst_rel.REGION_CD,
           v_offer_prod_inst_rel.UPDATE_STAFF,
           v_offer_prod_inst_rel.CREATE_STAFF,
           sysdate,
           v_offer_prod_inst_rel.EXT_FLAG);

        delete OFFER_PROD_INST_REL
         where OFFER_PROD_INST_REL_ID =
               v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ID;

        InsertIntoIntfInsBillingUpdate('OFFER_PROD_INST_REL',
                                       'OFFER_PROD_INST_REL_ID',
                                       v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ID,
                                       '可选包到期归档',
                                       v_offer_prod_inst_rel.area_id);
      END LOOP;

      --2.PROD_OFFER_INST_REL
      FOR v_prod_offer_inst_rel IN (SELECT *
                                      FROM PROD_OFFER_INST_REL
                                     WHERE RELATED_PROD_OFFER_INST_ID =
                                           v_option_offer_inst.prod_offer_inst_id) LOOP

        insert into PROD_OFFER_INST_REL_HIS
          (HIS_ID,
           PROD_OFFER_INST_REL_ID,
           RELA_PROD_OFFER_INST_ID,
           RELATED_PROD_OFFER_INST_ID,
           ROLE_CD,
           PROD_OFFER_INST_REL_ROLE_ID,
           RELATION_TYPE_CD,
           STATUS_CD,
           EFF_DATE,
           EXP_DATE,
           CREATE_DATE,
           STATUS_DATE,
           REGION_A,
           REGION_B,
           UPDATE_DATE,
           PROC_SERIAL,
           PROD_OFFER_RELA_ID,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           REC_UPDATE_DATE)
        values
          (SEQ_PROD_OFFER_INST_REL_HIS_ID.NEXTVAL,
           v_prod_offer_inst_rel.PROD_OFFER_INST_REL_ID,
           v_prod_offer_inst_rel.RELA_PROD_OFFER_INST_ID,
           v_prod_offer_inst_rel.RELATED_PROD_OFFER_INST_ID,
           v_prod_offer_inst_rel.ROLE_CD,
           v_prod_offer_inst_rel.PROD_OFFER_INST_REL_ROLE_ID,
           v_prod_offer_inst_rel.RELATION_TYPE_CD,
           '1100',
           v_prod_offer_inst_rel.EFF_DATE,
           v_option_offer_inst.exp_date,
           v_prod_offer_inst_rel.CREATE_DATE,
           v_prod_offer_inst_rel.STATUS_DATE,
           v_prod_offer_inst_rel.REGION_A,
           v_prod_offer_inst_rel.REGION_B,
           sysdate,
           v_offer_order_item_id,
           v_prod_offer_inst_rel.PROD_OFFER_RELA_ID,
           v_prod_offer_inst_rel.AREA_ID,
           v_prod_offer_inst_rel.REGION_CD,
           v_prod_offer_inst_rel.UPDATE_STAFF,
           v_prod_offer_inst_rel.CREATE_STAFF,
           sysdate);

        DELETE PROD_OFFER_INST_REL
         WHERE PROD_OFFER_INST_REL_ID =
               v_prod_offer_inst_rel.Prod_Offer_Inst_Rel_Id;

        InsertIntoIntfInsBillingUpdate('PROD_OFFER_INST_REL',
                                       'PROD_OFFER_INST_REL_ID',
                                       v_prod_offer_inst_rel.Prod_Offer_Inst_Rel_Id,
                                       '可选包到期归档',
                                       v_prod_offer_inst_rel.area_id);

      END LOOP;

      --3.PROD_OFFER_INST
      insert into PROD_OFFER_INST_HIS
        (HIS_ID,
         PROD_OFFER_INST_ID,
         PROD_OFFER_ID,
         CUST_ID,
         CHANNEL_ID,
         CREATE_DATE,
         STATUS_CD,
         STATUS_DATE,
         EFF_DATE,
         EXP_DATE,
         REGION,
         UPDATE_DATE,
         PROC_SERIAL,
         EXT_PROD_OFFER_INST_ID,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         TRIAL_EFF_DATE,
         TRIAL_EXP_DATE,
         REC_UPDATE_DATE,
         SERVICE_NBR,
         VERSION,
         REMARK,
         WH_REMARK,
         EXT_FLAG1,
         EXT_FLAG2)
      values
        (seq_prod_offer_inst_his_id.nextval,
         v_option_offer_inst.PROD_OFFER_INST_ID,
         v_option_offer_inst.PROD_OFFER_ID,
         v_option_offer_inst.CUST_ID,
         v_option_offer_inst.CHANNEL_ID,
         v_option_offer_inst.CREATE_DATE,
         '1100',
         v_option_offer_inst.STATUS_DATE,
         v_option_offer_inst.EFF_DATE,
         v_option_offer_inst.EXP_DATE,
         v_option_offer_inst.REGION,
         v_option_offer_inst.UPDATE_DATE,
         v_option_order_item_id,
         v_option_offer_inst.EXT_PROD_OFFER_INST_ID,
         v_option_offer_inst.AREA_ID,
         v_option_offer_inst.REGION_CD,
         v_option_offer_inst.UPDATE_STAFF,
         v_option_offer_inst.CREATE_STAFF,
         v_option_offer_inst.TRIAL_EFF_DATE,
         v_option_offer_inst.TRIAL_EXP_DATE,
         sysdate,
         v_option_offer_inst.SERVICE_NBR,
         v_option_offer_inst.VERSION,
         v_option_offer_inst.REMARK,
         v_option_offer_inst.WH_REMARK,
         v_option_offer_inst.EXT_FLAG1,
         v_option_offer_inst.EXT_FLAG2);

      update PROD_OFFER_INST
         set status_cd   = '1100',
             status_date = sysdate,
             update_date = sysdate,
             proc_serial = v_option_order_item_id
       where PROD_OFFER_INST_ID = v_option_offer_inst.prod_offer_inst_id;

      InsertIntoIntfInsBillingUpdate('PROD_OFFER_INST',
                                     'PROD_OFFER_INST_ID',
                                     v_option_offer_inst.prod_offer_inst_id,
                                     '可选包到期归档',
                                     v_option_offer_inst.area_id);

      --4.PROD_OFFER_INST_ATTR
      FOR v_option_offer_inst_attr IN (SELECT *
                                         FROM PROD_OFFER_INST_ATTR
                                        WHERE PROD_OFFER_INST_ID =
                                              v_option_offer_inst.prod_offer_inst_id) LOOP

        insert into PROD_OFFER_INST_ATTR_HIS
          (HIS_ID,
           PROD_OFFER_INST_ATTR_ID,
           PROD_OFFER_INST_ID,
           ATTR_ID,
           ATTR_VALUE_ID,
           ATTR_VALUE,
           CREATE_DATE,
           EXP_DATE,
           EFF_DATE,
           STATUS_DATE,
           STATUS_CD,
           UPDATE_DATE,
           PROC_SERIAL,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           REC_UPDATE_DATE,
           VERSION)
        values
          (SEQ_PROD_OFFER_INST_ATTR_2_ID.NEXTVAL,
           v_option_offer_inst_attr.PROD_OFFER_INST_ATTR_ID,
           v_option_offer_inst_attr.PROD_OFFER_INST_ID,
           v_option_offer_inst_attr.ATTR_ID,
           v_option_offer_inst_attr.ATTR_VALUE_ID,
           v_option_offer_inst_attr.ATTR_VALUE,
           v_option_offer_inst_attr.CREATE_DATE,
           v_option_offer_inst_attr.EXP_DATE,
           v_option_offer_inst_attr.EFF_DATE,
           v_option_offer_inst_attr.STATUS_DATE,
           '1100',
           v_option_offer_inst_attr.UPDATE_DATE,
           v_option_order_item_id,
           v_option_offer_inst_attr.AREA_ID,
           v_option_offer_inst_attr.REGION_CD,
           v_option_offer_inst_attr.UPDATE_STAFF,
           v_option_offer_inst_attr.CREATE_STAFF,
           SYSDATE,
           v_option_offer_inst_attr.VERSION);

        UPDATE PROD_OFFER_INST_ATTR
           SET STATUS_CD   = '1100',
               status_date = sysdate,
               update_date = sysdate,
               proc_serial = v_option_order_item_id
         WHERE PROD_OFFER_INST_ATTR_ID =
               v_option_offer_inst_attr.PROD_OFFER_INST_ATTR_ID;

        InsertIntoIntfInsBillingUpdate('PROD_OFFER_INST_ATTR',
                                       'PROD_OFFER_INST_ATTR_ID',
                                       v_option_offer_inst_attr.PROD_OFFER_INST_ATTR_ID,
                                       '可选包到期归档',
                                       v_option_offer_inst_attr.area_id);

      END LOOP;

    END LOOP;
    commit;
    o_result        := 'TRUE';
    o_cust_order_id := v_cust_order_id;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_msg := '产生订单失败. 主队列id: ' || i_queue_id || '    ' || SQLERRM;
      RETURN;
  END;

  PROCEDURE procOptionGroupOfferNotOrder(i_queue_id      IN o_auto_proc_queue.queue_id%TYPE, ---主队列ID
                                         o_result        OUT VARCHAR2,
                                         o_msg           OUT VARCHAR2,
                                         o_cust_order_id OUT customer_order.cust_order_id%TYPE) ---产生的订单ID
   IS
    v_cust_so_number      customer_order.cust_so_number%TYPE; --订单流水号
    v_cust_order_id       customer_order.cust_order_id%TYPE; --订单id
    v_offer_order_item_id order_item.order_item_id%TYPE; --可选群组销售品订单项id
    v_prod_offer_inst     prod_offer_inst%ROWTYPE; --主销售品实例
    v_channel_nbr         channel.channel_nbr%TYPE; -- 渠道编码
    v_auto_queue          o_auto_proc_queue%ROWTYPE; --队列
    v_intf_staff_id       number; --接口工号
    v_intf_org_id         NUMBER; --接口团队
    v_count               number; --数量
  BEGIN
    o_result        := 'FALSE';
    o_cust_order_id := 0;
    v_intf_staff_id := 51447;
    v_intf_org_id   := 1020001;
    /*****************************************************************************************
      1. 校验数据
    ******************************************************************************************/
    ---获取队列对象
    BEGIN
      SELECT *
        INTO v_auto_queue
        FROM o_auto_proc_queue a
       WHERE a.queue_id = i_queue_id;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        o_msg := '产生订单失败. 队列不存在.队列id: ' || i_queue_id || '    ' || SQLERRM;
        RETURN;
    END;
    ---可选群组是否已经延期或者失效了
    SELECT count(*)
      into v_count
      FROM prod_offer_inst poi, o_auto_proc_queue oa, prod_offer po
     where oa.queue_id = i_queue_id
       and po.prod_offer_id = poi.prod_offer_id
       and oa.src_type = 'ProdOfferInst'
       and oa.src_inst_id = poi.prod_offer_inst_id
       and (poi.status_cd = '1100' or poi.exp_date > sysdate or
           po.exp_proc_method != 2);
    if v_count > 0 then
      o_msg := '当前队列无到期可选群组类要处理';
      RETURN;
    end if;
    ----获取主销售品
    BEGIN
      SELECT b.*
        INTO v_prod_offer_inst
        FROM o_auto_proc_queue a, prod_offer_inst b
       WHERE a.src_inst_id = b.prod_offer_inst_id
         AND a.queue_id = i_queue_id;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
        o_msg := '产生订单失败. 主销售品实例不存在.队列id: ' || i_queue_id || '    ' ||
                 SQLERRM;
        RETURN;
    END;

    SELECT nvl(a.obj_value, '600105B017')
      INTO v_channel_nbr
      FROM proc_queue_attr a
     WHERE a.queue_id = i_queue_id
       AND a.obj_type = 'CHNCD';
    IF v_channel_nbr IS NULL THEN
      o_msg := '产生订单失败. 渠道编码属性不存在.队列id: ' || i_queue_id || '    ' ||
               SQLERRM;
      --raise_application_error(-20203, o_msg);
      RETURN;
    END IF;
    --过滤指定动作的在途单
    SELECT count(*)
      into v_count
      FROM order_item oi
     where oi.order_item_obj_id = v_prod_offer_inst.prod_offer_inst_id
       and oi.class_id = 6
       and oi.service_offer_id = 501;
    if v_count > 0 then
      o_msg := '当前可选群组类已有在途退订单!';
      RETURN;
    end if;

    /*****************************************************************************************
      2. 订单处理
    ******************************************************************************************/
    --生成新的订单流水号
    SELECT 'FJ' || TO_CHAR(SYSDATE, 'YYYYMMDD') ||
           LPAD(TO_CHAR(SEQ_CUSTOMER_ORDER_SO_NUMBER.NEXTVAL), 8, '0')
      INTO v_cust_so_number
      FROM DUAL;

    --订单id
    SELECT seq_customer_order_id.nextval INTO v_cust_order_id FROM dual;
    --插订单
    INSERT INTO customer_order_his
      (cust_order_id,
       customer_interaction_event_id,
       channel_id,
       cust_id,
       staff_id,
       cust_so_number,
       cust_order_type,
       status_cd,
       status_date,
       pre_handle_flag,
       handle_people_name,
       priority,
       reason,
       create_date,
       update_date,
       accept_time,
       ext_cust_order_id,
       lan_id,
       remark,
       book_time,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       org_id,
       his_id,
       order_from,
       db_inst_id,
       proc_priority)
      SELECT v_cust_order_id, --CUST_ORDER_ID,
             NULL, --CUSTOMER_INTERACTION_EVENT_ID,
             (SELECT c.channel_id
                FROM channel c
               WHERE c.channel_nbr = v_channel_nbr
                 AND rownum = 1), --CHANNEL_ID,
             v_prod_offer_inst.cust_id, --CUST_ID,
             v_intf_staff_id, --STAFF_ID,
             v_cust_so_number, --CUST_SO_NUMBER,
             '101', --CUST_ORDER_TYPE,???
             '300000', --STATUS_CD,(300000: 竣工)
             SYSDATE, --STATUS_DATE,
             NULL, --PRE_HANDLE_FLAG,
             NULL, --HANDLE_PEOPLE_NAME,
             '100', --PRIORITY,
             NULL, --REASON,
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             SYSDATE, --ACCEPT_TIME,
             NULL, --EXT_CUST_ORDER_ID,
             NULL, --LAN_ID,
             NULL, --REMARK,
             NULL, --BOOK_TIME,
             v_auto_queue.area_id, --AREA_ID,
             v_auto_queue.region_cd, --REGION_CD,
             v_intf_staff_id, --UPDATE_STAFF,
             v_intf_staff_id, --CREATE_STAFF,
             v_intf_org_id, --ORG_ID,
             seq_customer_order_his_id.nextval, --HIS_ID,
             v_channel_nbr, --ORDER_FROM,
             NULL, --DB_INST_ID,
             NULL --PROC_PRIORITY,
        FROM dual;

    ---插销售品订单项
    SELECT seq_order_item_id.nextval INTO v_offer_order_item_id FROM dual;
    INSERT INTO order_item_his
      (order_item_id,
       cust_order_id,
       order_item_cd,
       cust_worksheet_id,
       status_cd,
       status_date,
       status_change_reason,
       priority,
       pre_handle_flag,
       handle_time,
       archive_date,
       finish_time,
       order_item_obj_id,
       install_time_segment_id,
       begin_time_segment_id,
       service_offer_id,
       create_date,
       update_date,
       reason,
       ext_order_item_id,
       lan_id,
       class_id,
       area_id,
       region_cd,
       update_staff,
       create_staff,
       his_id,
       order_class_id,
       db_inst_id,
       pf_process_flag,
       proc_priority)
      SELECT v_offer_order_item_id, --ORDER_ITEM_ID,
             v_cust_order_id, --CUST_ORDER_ID,
             '1200', --ORDER_ITEM_CD,(1200: 销售品订单项)
             NULL, --CUST_WORKSHEET_ID,
             '300000', --STATUS_CD,(300000: 竣工)
             SYSDATE, --STATUS_DATE,
             NULL, --STATUS_CHANGE_REASON,
             NULL, --PRIORITY,
             NULL, --PRE_HANDLE_FLAG,
             NULL, --HANDLE_TIME,
             SYSDATE, --ARCHIVE_DATE,
             SYSDATE, --FINISH_TIME,
             v_prod_offer_inst.prod_offer_inst_id, --ORDER_ITEM_OBJ_ID,
             NULL, --INSTALL_TIME_SEGMENT_ID,
             NULL, --BEGIN_TIME_SEGMENT_ID,
             501, --SERVICE_OFFER_ID,--501: 退订
             SYSDATE, --CREATE_DATE,
             SYSDATE, --UPDATE_DATE,
             NULL, --REASON,
             NULL, --EXT_ORDER_ITEM_ID,
             NULL, --LAN_ID,
             6, --CLASS_ID,
             v_auto_queue.area_id, --AREA_ID,
             v_auto_queue.region_cd, --REGION_CD,
             v_intf_staff_id, --UPDATE_STAFF,
             v_intf_staff_id, --CREATE_STAFF,
             seq_order_item_his_id.nextval, --HIS_ID,
             NULL, --ORDER_CLASS_ID,
             NULL, --DB_INST_ID,
             NULL, --PF_PROCESS_FLAG,
             NULL --PROC_PRIORITY,
        FROM dual;

    /*****************************************************************************************
          3. 档案处理
    ******************************************************************************************/
    -- 1.offer_prod_inst_rel
    FOR v_offer_prod_inst_rel IN (SELECT *
                                    FROM OFFER_PROD_INST_REL
                                   WHERE prod_offer_inst_id =
                                         v_prod_offer_inst.prod_offer_inst_id) LOOP
      insert into OFFER_PROD_INST_REL_HIS
        (HIS_ID,
         OFFER_PROD_INST_REL_ID,
         PROD_INST_ID,
         PROD_OFFER_INST_ID,
         ROLE_CD,
         OFFER_PROD_INST_REL_ROLE_ID,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         EFF_DATE,
         EXP_DATE,
         UPDATE_DATE,
         PROC_SERIAL,
         OFFER_PROD_REL_ID,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         REC_UPDATE_DATE,
         EXT_FLAG)
      values
        (SEQ_OFFER_PROD_INST_REL_HIS_ID.NEXTVAL,
         v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ID,
         v_offer_prod_inst_rel.PROD_INST_ID,
         v_offer_prod_inst_rel.PROD_OFFER_INST_ID,
         v_offer_prod_inst_rel.ROLE_CD,
         v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ROLE_ID,
         '1100',
         v_offer_prod_inst_rel.STATUS_DATE,
         v_offer_prod_inst_rel.CREATE_DATE,
         v_offer_prod_inst_rel.EFF_DATE,
         v_offer_prod_inst_rel.EXP_DATE,
         sysdate,
         v_offer_order_item_id,
         v_offer_prod_inst_rel.OFFER_PROD_REL_ID,
         v_offer_prod_inst_rel.AREA_ID,
         v_offer_prod_inst_rel.REGION_CD,
         v_offer_prod_inst_rel.UPDATE_STAFF,
         v_offer_prod_inst_rel.CREATE_STAFF,
         sysdate,
         v_offer_prod_inst_rel.EXT_FLAG);

      delete OFFER_PROD_INST_REL
       where OFFER_PROD_INST_REL_ID =
             v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ID;

      InsertIntoIntfInsBillingUpdate('OFFER_PROD_INST_REL',
                                     'OFFER_PROD_INST_REL_ID',
                                     v_offer_prod_inst_rel.OFFER_PROD_INST_REL_ID,
                                     '可选群组到期归档',
                                     v_offer_prod_inst_rel.area_id);
    END LOOP;
    --1.2 PROD_OFFER_MEMBER_INST
    FOR v_prod_offer_member_inst IN (SELECT *
                                       FROM PROD_OFFER_MEMBER_INST
                                      WHERE prod_offer_inst_id =
                                            v_prod_offer_inst.prod_offer_inst_id) LOOP
      insert into PROD_OFFER_MEMBER_INST_HIS
        (HIS_ID,
         MEMBER_INST_ID,
         PROD_OFFER_INST_ID,
         MEMBER_ID,
         PROD_OFFER_MEMBER_ID,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         EFF_DATE,
         EXP_DATE,
         AREA_ID,
         REGION_CD,
         CREATE_STAFF,
         UPDATE_DATE,
         UPDATE_STAFF,
         ROLE_CD,
         REC_UPDATE_DATE,
         BANK_ID,
         BANK_ACCOUNT)
      values
        (SEQ_PROD_OFFER_MEMBER_HIS_ID.Nextval,
         v_prod_offer_member_inst.Member_Inst_Id,
         v_prod_offer_member_inst.Prod_Offer_Inst_Id,
         v_prod_offer_member_inst.Member_Id,
         v_prod_offer_member_inst.Prod_Offer_Member_Id,
         '1100',
         v_prod_offer_member_inst.Status_Date,
         v_prod_offer_member_inst.Create_Date,
         v_prod_offer_member_inst.Eff_Date,
         v_prod_offer_member_inst.Exp_Date,
         v_prod_offer_member_inst.Area_Id,
         v_prod_offer_member_inst.Region_Cd,
         v_prod_offer_member_inst.Create_Staff,
         sysdate,
         v_prod_offer_member_inst.Update_Staff,
         v_prod_offer_member_inst.Role_Cd,
         sysdate,
         v_prod_offer_member_inst.bank_id,
         v_prod_offer_member_inst.bank_account);

      delete PROD_OFFER_MEMBER_INST
       where Member_Inst_Id = v_prod_offer_member_inst.Member_Inst_Id;

      InsertIntoIntfInsBillingUpdate('PROD_OFFER_MEMBER_INST',
                                     'MEMBER_INST_ID',
                                     v_prod_offer_member_inst.Member_Inst_Id,
                                     '可选群组到期归档',
                                     v_prod_offer_member_inst.area_id);
    END LOOP;
    --2.PROD_OFFER_INST
    insert into PROD_OFFER_INST_HIS
      (HIS_ID,
       PROD_OFFER_INST_ID,
       PROD_OFFER_ID,
       CUST_ID,
       CHANNEL_ID,
       CREATE_DATE,
       STATUS_CD,
       STATUS_DATE,
       EFF_DATE,
       EXP_DATE,
       REGION,
       UPDATE_DATE,
       PROC_SERIAL,
       EXT_PROD_OFFER_INST_ID,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       TRIAL_EFF_DATE,
       TRIAL_EXP_DATE,
       REC_UPDATE_DATE,
       SERVICE_NBR,
       VERSION,
       REMARK,
       WH_REMARK,
       EXT_FLAG1,
       EXT_FLAG2)
    values
      (seq_prod_offer_inst_his_id.nextval,
       v_prod_offer_inst.PROD_OFFER_INST_ID,
       v_prod_offer_inst.PROD_OFFER_ID,
       v_prod_offer_inst.CUST_ID,
       v_prod_offer_inst.CHANNEL_ID,
       v_prod_offer_inst.CREATE_DATE,
       '1100',
       v_prod_offer_inst.STATUS_DATE,
       v_prod_offer_inst.EFF_DATE,
       v_prod_offer_inst.EXP_DATE,
       v_prod_offer_inst.REGION,
       v_prod_offer_inst.UPDATE_DATE,
       v_offer_order_item_id,
       v_prod_offer_inst.EXT_PROD_OFFER_INST_ID,
       v_prod_offer_inst.AREA_ID,
       v_prod_offer_inst.REGION_CD,
       v_prod_offer_inst.UPDATE_STAFF,
       v_prod_offer_inst.CREATE_STAFF,
       v_prod_offer_inst.TRIAL_EFF_DATE,
       v_prod_offer_inst.TRIAL_EXP_DATE,
       sysdate,
       v_prod_offer_inst.SERVICE_NBR,
       v_prod_offer_inst.VERSION,
       v_prod_offer_inst.REMARK,
       v_prod_offer_inst.WH_REMARK,
       v_prod_offer_inst.EXT_FLAG1,
       v_prod_offer_inst.EXT_FLAG2);

    update PROD_OFFER_INST
       set status_cd   = '1100',
           status_date = sysdate,
           update_date = sysdate,
           proc_serial = v_offer_order_item_id
     where PROD_OFFER_INST_ID = v_prod_offer_inst.prod_offer_inst_id;

    InsertIntoIntfInsBillingUpdate('PROD_OFFER_INST',
                                   'PROD_OFFER_INST_ID',
                                   v_prod_offer_inst.prod_offer_inst_id,
                                   '可选群组到期归档',
                                   v_prod_offer_inst.area_id);
    --3.PROD_OFFER_INST_ATTR
    FOR v_option_offer_inst_attr IN (SELECT *
                                       FROM PROD_OFFER_INST_ATTR
                                      WHERE PROD_OFFER_INST_ID =
                                            v_prod_offer_inst.prod_offer_inst_id) LOOP

      insert into PROD_OFFER_INST_ATTR_HIS
        (HIS_ID,
         PROD_OFFER_INST_ATTR_ID,
         PROD_OFFER_INST_ID,
         ATTR_ID,
         ATTR_VALUE_ID,
         ATTR_VALUE,
         CREATE_DATE,
         EXP_DATE,
         EFF_DATE,
         STATUS_DATE,
         STATUS_CD,
         UPDATE_DATE,
         PROC_SERIAL,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         REC_UPDATE_DATE,
         VERSION)
      values
        (SEQ_PROD_OFFER_INST_ATTR_2_ID.NEXTVAL,
         v_option_offer_inst_attr.PROD_OFFER_INST_ATTR_ID,
         v_option_offer_inst_attr.PROD_OFFER_INST_ID,
         v_option_offer_inst_attr.ATTR_ID,
         v_option_offer_inst_attr.ATTR_VALUE_ID,
         v_option_offer_inst_attr.ATTR_VALUE,
         v_option_offer_inst_attr.CREATE_DATE,
         v_option_offer_inst_attr.EXP_DATE,
         v_option_offer_inst_attr.EFF_DATE,
         v_option_offer_inst_attr.STATUS_DATE,
         '1100',
         v_option_offer_inst_attr.UPDATE_DATE,
         v_offer_order_item_id,
         v_option_offer_inst_attr.AREA_ID,
         v_option_offer_inst_attr.REGION_CD,
         v_option_offer_inst_attr.UPDATE_STAFF,
         v_option_offer_inst_attr.CREATE_STAFF,
         SYSDATE,
         v_option_offer_inst_attr.VERSION);

      UPDATE PROD_OFFER_INST_ATTR
         SET STATUS_CD   = '1100',
             status_date = sysdate,
             update_date = sysdate,
             proc_serial = v_offer_order_item_id
       WHERE PROD_OFFER_INST_ATTR_ID =
             v_option_offer_inst_attr.PROD_OFFER_INST_ATTR_ID;

      InsertIntoIntfInsBillingUpdate('PROD_OFFER_INST_ATTR',
                                     'PROD_OFFER_INST_ATTR_ID',
                                     v_option_offer_inst_attr.PROD_OFFER_INST_ATTR_ID,
                                     '可选群组到期归档',
                                     v_option_offer_inst_attr.area_id);
    END LOOP;
    commit;
    o_result        := 'TRUE';
    o_cust_order_id := v_cust_order_id;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_msg := '产生订单失败. 主队列id: ' || i_queue_id || '    ' || SQLERRM;
      RETURN;
  END;

  PROCEDURE InsertIntoIntfInsBillingUpdate(tableName  in varchar2,
                                           columnName in varchar2,
                                           keyId      in number,
                                           topic      in varchar2,
                                           areaId     in number) is
    v_area_nbr number;
  begin
    SELECT area_nbr
      into v_area_nbr
      FROM area_code
     where region_id = areaId;
    basejk.pkg_common.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF(tableName,
                                                               columnName,
                                                               keyId,
                                                               topic,
                                                               '1005',
                                                               topic,
                                                               '',
                                                               v_area_nbr);
  end;
  -- Author  : LITTLEHUI
  -- Created : 2012/6/20 16:12:45
  -- Purpose : 插入队列
  function InsertIntoOAutoProcQueue(SUPER_QUEUE_ID in number,
                                    SRC_INST_ID    in number,
                                    SRC_TYPE       in varchar2,
                                    SRC_ACTION     in varchar2,
                                    PROC_TYPE      in varchar2,
                                    STATUS_CD      in varchar2,
                                    QUEUE_DESC     in varchar2) return number is
    o_auto_queue_id number;
  begin
    select seq_o_auto_proc_queue_id.nextval into o_auto_queue_id from dual;
    insert into o_auto_proc_queue
      (QUEUE_ID,
       SUPER_QUEUE_ID,
       SRC_INST_ID,
       SRC_TYPE,
       SRC_ACTION,
       PROC_TYPE,
       CREATE_DATE,
       STATUS_CD,
       QUEUE_DESC,
       STATUS_DATE,
       UPDATE_DATE)
    values
      (o_auto_queue_id,
       SUPER_QUEUE_ID,
       SRC_INST_ID,
       SRC_TYPE,
       SRC_ACTION,
       PROC_TYPE,
       sysdate,
       STATUS_CD,
       QUEUE_DESC,
       sysdate,
       sysdate);
    return o_auto_queue_id;
  end; --insert
  /*
    主单要加上区域
  */
  function InsertIntoOAutoProcQueueByArea(SUPER_QUEUE_ID in number,
                                          SRC_INST_ID    in number,
                                          SRC_TYPE       in varchar2,
                                          SRC_ACTION     in varchar2,
                                          PROC_TYPE      in varchar2,
                                          STATUS_CD      in varchar2,
                                          QUEUE_DESC     in varchar2,
                                          AREA_ID        in number,
                                          REGION_CD      in number)
    return number is
    o_auto_queue_id number;
  begin
    select seq_o_auto_proc_queue_id.nextval into o_auto_queue_id from dual;
    insert into o_auto_proc_queue
      (QUEUE_ID,
       SUPER_QUEUE_ID,
       SRC_INST_ID,
       SRC_TYPE,
       SRC_ACTION,
       PROC_TYPE,
       CREATE_DATE,
       STATUS_CD,
       QUEUE_DESC,
       STATUS_DATE,
       UPDATE_DATE,
       AREA_ID,
       REGION_CD)
    values
      (o_auto_queue_id,
       SUPER_QUEUE_ID,
       SRC_INST_ID,
       SRC_TYPE,
       SRC_ACTION,
       PROC_TYPE,
       sysdate,
       STATUS_CD,
       QUEUE_DESC,
       sysdate,
       sysdate,
       AREA_ID,
       REGION_CD);
    return o_auto_queue_id;
  end; --insert
  -- Author  : LITTLEHUI
  -- Created : 2012/6/20 16:13:26
  -- Purpose : 插入属性队列
  function InsertIntoProcQueueAttr(QUEUE_ID     in number,
                                   OBJ_SPEC     in number,
                                   OBJ_TYPE     in varchar2,
                                   OBJ_ID       in number,
                                   PROC_TYPE    in varchar2,
                                   OBJ_VALUE    in varchar2,
                                   VALID_BEAN   in varchar2,
                                   VALID_PARAM1 in varchar2,
                                   VALID_PARAM2 in varchar2,
                                   REMARK       in varchar2) return number is
    proc_queue_attr_id number;
  begin
    select seq_proc_queue_attr_id.nextval
      into proc_queue_attr_id
      from dual;
    insert into proc_queue_attr
      (ATTR_ID,
       SUPER_ATTR_ID,
       QUEUE_ID,
       OBJ_SPEC,
       OBJ_TYPE,
       OBJ_ID,
       PROC_TYPE,
       OBJ_VALUE,
       VALID_BEAN,
       VALID_PARAM1,
       VALID_PARAM2,
       REMARK,
       CREATE_DATE,
       UPDATE_DATE)
    values
      (proc_queue_attr_id,
       0,
       QUEUE_ID,
       OBJ_SPEC,
       OBJ_TYPE,
       OBJ_ID,
       PROC_TYPE,
       OBJ_VALUE,
       VALID_BEAN,
       VALID_PARAM1,
       VALID_PARAM2,
       REMARK,
       sysdate,
       sysdate);
    return proc_queue_attr_id;
  end; --insert

  -- Author  : LITTLEHUI
  -- Created : 2012/6/25 17:35:55
  -- Purpose : 检测销售品是否已入自动队列
  function IsHasOfferInQueue(instId in number, srcType in varchar)
    return number is
    isHas number;
  begin
    select count(*)
      into isHas
      from o_auto_proc_queue a
     where a.src_inst_id = instId
       and a.src_type = srcType;
    return isHas;
  end;
  /*
    检测销售品是否已入自动队列,增加同一过程方法的判断
    zhengcl
  */
  function IsHasSameInstInQueue(instId    in number,
                                srcType   in varchar,
                                queueDesc in varchar) return number is
    isHas   number;
    queueId number;
  begin
    queueId := 0;
    select count(*)
      into isHas
      from o_auto_proc_queue a
     where a.src_inst_id = instId
       and a.src_type = srcType
       and a.queue_desc = queueDesc;
    if isHas = 1 then
      select a.queue_id
        into queueId
        from o_auto_proc_queue a
       where a.src_inst_id = instId
         and a.src_type = srcType
         and a.queue_desc = queueDesc;
    end if;
    return queueId;
  end;

  /*
    记录执行情况日志
  */
  function saveLogInfo(l_logId in number, str_message in varchar)
    return number is
    v_result number;
  begin
    v_result := l_logId;
    if l_logId <= 0 then
      select LOG_INF_ID_SEQ.Nextval into v_result from dual;
      insert into LOG_INF
        (LOG_ID,
         CODE_ID,
         OPERATOR_TYPE,
         OPERATOR_ID,
         CREATE_DATE,
         IP_ADDRESS,
         LOG_DESC,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF)
      values
        (v_result,
         null,
         20,
         1,
         sysdate,
         'PKG_PROC_AUTO_H_TEST',
         str_message,
         null,
         null,
         null,
         null);
    else
      update log_inf set LOG_DESC = str_message where log_id = l_logId;
    end if;
    commit;
    return v_result;
  exception
    WHEN OTHERS THEN
      v_result := 0;
      return v_result;
  end;
  function IsHasAttrInQueue(QUEUE_ID     in number,
                            OBJ_SPEC     in number,
                            OBJ_TYPE     in varchar2,
                            OBJ_ID       in number,
                            PROC_TYPE    in varchar2,
                            OBJ_VALUE    in varchar2,
                            VALID_BEAN   in varchar2,
                            VALID_PARAM2 in varchar2) return number is
    isHas number;
    v_sql VARCHAR2(2000);
    l_queue_id number;
  begin
    /*    select count(*)
      into isHas
      from proc_queue_attr a
     where a.queue_id = QUEUE_ID
       and a.obj_spec = OBJ_SPEC
       and a.obj_type = OBJ_TYPE
       and a.obj_id = OBJ_ID
       and a.proc_type = PROC_TYPE
       and a.obj_value = OBJ_VALUE;
    return isHas;*/
    --crm00063474 zhengcl 更改成绑定变量
    l_queue_id:=QUEUE_ID;
    v_sql := 'select count(*) from proc_queue_attr where QUEUE_ID=:l_queue_id and OBJ_SPEC =''' || OBJ_SPEC ||
             ''' and OBJ_TYPE =''' || OBJ_TYPE || ''' and OBJ_ID =''' ||
             OBJ_ID || '''';
    if LENGTH(PROC_TYPE) > 0 then
      v_sql := v_sql || ' and PROC_TYPE =''' || PROC_TYPE || '''';
    end if;
    if LENGTH(OBJ_VALUE) > 0 then
      v_sql := v_sql || ' and OBJ_VALUE =''' || OBJ_VALUE || '''';
    end if;
    if LENGTH(VALID_BEAN) > 0 then
      v_sql := v_sql || ' and VALID_BEAN =''' || VALID_BEAN || '''';
    end if;
    if LENGTH(VALID_PARAM2) > 0 then
      v_sql := v_sql || ' and VALID_PARAM2 =''' || VALID_PARAM2 || '''';
    end if;
    execute immediate v_sql
      into isHas
      using l_queue_id;
    return isHas;
  end;

  --是否是预开通的实例
  function IsYKT(i_prodInstId in number) return number is
    v_cnt number;
  begin
    v_cnt := 0;
    SELECT count('x')
      INTO v_cnt
      FROM PROD_INST P, PROD_INST_ATTR A
     WHERE P.STATUS_CD = '140000'
       AND P.PROD_INST_ID = A.PROD_INST_ID
       AND A.ATTR_ID IN (800000280, 800000312)
       AND A.STATUS_CD = '1000'
       AND P.PROD_INST_ID = i_prodInstId;
    return v_cnt;
  end; --IsYKT

  function IsHasQXSB(prodInstId in number) return number is
    isHas      number;
    qxsbInstId number;
  begin
    qxsbInstId := 0;

    SELECT count(*)
      into isHas
      FROM prod_inst_rel pir, prod_inst pi, product p
     where pir.prod_inst_a_id = prodInstId
       and pir.prod_inst_z_id = pi.prod_inst_id
       and pi.product_id = p.product_id
       and pi.status_cd = '100000'
       and regexp_like(p.product_name, '气象时报');

    if isHas = 1 then
      SELECT pi.prod_inst_id
        into qxsbInstId
        FROM prod_inst_rel pir, prod_inst pi, product p
       where pir.prod_inst_a_id = prodInstId
         and pir.prod_inst_z_id = pi.prod_inst_id
         and pi.product_id = p.product_id
         and pi.status_cd = '100000'
         and regexp_like(p.product_name, '气象时报');
    end if;
    return qxsbInstId;
  end;

  /*是否是可直接处理档案,外部前提exp_proc_method必须是2,
   1.提速包到期要算速率,不能直接档案处理,要生成订单
   2.退订要发短信的可选包，不能直接档案出来，要生成订单 zhengcl 20151210 crm00068482
  */
  function IsCanDirectProc(i_prodOfferId in number) return number is
    v_cnt    number;
    v_result number;
  begin
    v_result := 1; --默认1为可以直接档案处理，返回0表示要生成正常订单
    SELECT count('x')
      INTO v_cnt
      FROM attr_value v, attr_spec a
     where v.attr_id = a.attr_id
       and v.status_cd='1000'
       and a.java_code in
           ('autoUpSpeedOne', 'autoNetAgeUpSpeed',
            'autoUpOptionAppointSpeed', 'autoUpOptionOnlyUpAppointSpeed',
            'PKG_PROC_AUTO_H_TEST_SET_NOTE_OFFER')
       and v.attr_value = to_char(i_prodOfferId);
    if v_cnt > 0 then
      v_result := 0; --返回0,不能直接档案处理,要生成订单
      return v_result;
    end if;
    return v_result;
  end; --IsCanDirectProc

end PKG_PROC_AUTO_H_TEST;
/
