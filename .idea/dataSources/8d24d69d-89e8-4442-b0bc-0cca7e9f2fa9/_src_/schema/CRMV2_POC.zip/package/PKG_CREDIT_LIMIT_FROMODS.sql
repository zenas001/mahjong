CREATE PACKAGE           PKG_CREDIT_LIMIT_FROMODS IS

  -- AUTHOR  : LIUJR
  -- CREATED : 2009-07-14 15:46:03
  -- PURPOSE : 从ODS更新客户的授信额度 增量接口
  --  注：需要建立JOB
  /******************************************
  VARIABLE JOB NUMBER;
  BEGIN
    SYS.DBMS_JOB.SUBMIT(JOB => :JOB,
                        WHAT => 'BEGIN
  PKG_CUST_QUOTA_FROMODS.MAIN_PROC ;
  END;',
                        NEXT_DATE => TRUNC(SYSDATE)+1/24,
                        INTERVAL => 'TRUNC(SYSDATE+1) + 1/24');
    COMMIT;
  END;
  *****************************************/

  FUNCTION INSERT_INTO_LOG(OBJ_ID   IN NUMBER,
                           MSG      IN VARCHAR2,
                           ERR_INFO IN CLOB) RETURN BOOLEAN;
  --从ODS获取帐期授信额度
  PROCEDURE GET_CREDIT_LIMIT_FROM_ODS;

  --判断积分客户的临时授信额度是否在有效期
  FUNCTION JUDGE_TEMP_CREDIT_LIMIT_VALID(V1_CUSTID IN NUMBER) RETURN INTEGER;

  --增量取授信额度
  PROCEDURE KH_CREDIT_LIMIT_INCREMENT;

  --并传计费批量接口
  PROCEDURE SYNC_CREDIT_LIMIT_DATA_2_JF(V2_CREDIT_LIMIT_ID IN NUMBER);

  --主处理过程
  PROCEDURE MAIN_PROC;

END PKG_CREDIT_LIMIT_FROMODS;
/
