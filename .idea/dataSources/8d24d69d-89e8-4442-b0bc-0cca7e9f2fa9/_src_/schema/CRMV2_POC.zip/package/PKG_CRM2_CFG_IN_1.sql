CREATE package           PKG_CRM2_CFG_IN_1 is

  -- Author  : ZHENGCL
  -- Created : 2011-12-01 10:39:36
  -- Purpose : crm2.0部分配置导入过程
  -- 同步后记录到CRM1_CFG_SYNC表中
  /*CRM1.0基本销售品与基本套餐关系导入    2.0销售品与可选包的可选关系
    1.根据输入的基础销售品，查询1.0中基本销售品直接适用的基本套餐数据，根据名称查询出对应的2.0的可选包数据，建立基础类销售品与可选包之间的可选关系。
    2.删除之前的错误数据：
      a.当前的输入的销售品类型变更,更改为可选包且细类为可选销售品，或者促销包的情况。则要删除原先作为可选关系A端的数据
      b.当前的输入的销售品作为A端，z端数据不为可选包且细类为可选销售品，或者促销包的情况，也都删除
  */
  PROCEDURE p_mdseSpecPriceRelaIn(prod_offer_sql in VARCHAR2, --2.0销售品规格查询脚本
                                  v_remark       in VARCHAR2, -- 记录备注信息
                                  str_msg        out VARCHAR2);

  /*CRM1.0 天翼与基本套餐关系导入    2.0天翼套餐销售品与可选包的可选关系
    1.查询1.0天翼适用套餐在2.0落地为套餐销售品细类为接入类的数据，作为A端
       查询1.0天翼适用套餐在2.0落地为可选包细类为可选类销售品的数据，作为Z端
       建立销售品的可选关系。
    2.过滤套餐销售品与可选包，对应1.0基本套餐有互斥关系的数据。如果已经生成关联数据了，有实例的置失效，没实例的直接删除。
    3.删除1.0天翼适用套餐在2.0落地为套餐销售品细类为接入类的数据，作为A端，但是Z端非可选包和促销包的数据。如果已经生成关联数据了，有实例的置失效，没实例的直接删除。
  */

  PROCEDURE p_mdseSpecCDMAPriceRelaIn(prod_offer_sql in VARCHAR2, --2.0销售品规格查询脚本
                                      v_remark       in VARCHAR2, -- 记录备注信息
                                      str_msg        out VARCHAR2);

  PROCEDURE p_eHomePriceRelaIn(prod_offer_sql in VARCHAR2, --2.0销售品规格查询脚本
                               v_remark       in VARCHAR2, -- 记录备注信息
                               str_msg        out VARCHAR2);

end PKG_CRM2_CFG_IN_1;
/
