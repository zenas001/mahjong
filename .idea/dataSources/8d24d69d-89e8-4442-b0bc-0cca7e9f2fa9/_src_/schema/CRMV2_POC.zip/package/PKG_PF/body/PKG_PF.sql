CREATE package body           PKG_PF is

  -- 协调通信外部编码
  C_EXT_PROD_ID constant VARCHAR2(255) := '610005545';
  -- 构成关系
  C_RELATION_TYPE_100300 constant VARCHAR2(6) := '100300';

  -- Author  : OUZHF
  -- Created : 2012/7/13 9:11:49
  -- Purpose :
  /*-------------------------------------------------
  协同通信业务号码查询
  PF需要查询某号码属于哪个协同通信群组产品时，调用此接口
  Author  : ouzhf
  Created : 2012-07-13
  -------------------------------------------------*/
  PROCEDURE PROC_QUERY_ACCOUNT_BY_ID(I_PROD_INST_ID IN NUMBER, --成员实例标识
                                     O_ACC_NBR      OUT VARCHAR2, --成员实例标识所在的在用的协同通信的业务号码
                                     O_ERR_CODE     OUT NUMBER, --返回值：0-成功 ；1-失败
                                     O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                     ) IS
    V_CNT             NUMBER;
  BEGIN
    --协同通信
    SELECT C.ACC_NBR
      INTO O_ACC_NBR
      FROM PROD_INST A, PROD_INST_REL B, PROD_INST C, PRODUCT D
     WHERE A.PROD_INST_ID = B.PROD_INST_Z_ID
       AND B.RELATION_TYPE_CD = C_RELATION_TYPE_100300
       AND B.PROD_INST_A_ID = C.PROD_INST_ID
       AND C.PRODUCT_ID = D.PRODUCT_ID
       AND D.EXT_PROD_ID = C_EXT_PROD_ID
       AND A.PROD_INST_ID = I_PROD_INST_ID;

    SELECT COUNT(1) INTO V_CNT
      FROM INTF_CODE_MAPPING
     WHERE SOURCE_NAME = '翼聊业务号码最后一位'
       AND DESTINATION_CODE = O_ACC_NBR ;

    IF V_CNT > 0 THEN
      O_ACC_NBR := '';
    END IF;

    O_ERR_CODE := 0;
    O_ERR_MSG  := '成功';
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := sqlerrm;
      RETURN;
  END;

  /************************************************************************
  Function  ：此过程是根据产品实例查询关联从产品的相关信息。
  该过程提供pf调用。
  Author　  ：Wangjianjun
  Date      : 2012-07-26
  Parameter :
              I_PROD_INST_ID  ---产品实例ID
              O_RETURN_STR    --关联从信息
              包括关联从产品实例，关联从产品规格，关联类型，之间用逗号隔开，多个该组合列表使用分号隔开
              O_ERR_CODE      --返回编码（0 成功 1 失败）
              O_ERR_MSG       --返回信息
  ************************************************************************/
  PROCEDURE PROC_QUERY_REL_PRODUCT(I_PROD_INST_ID IN NUMBER, --产品实例ID
                                   O_RETURN_STR   OUT VARCHAR2, --关联从信息,包括关联从产品实例，关联从产品规格，关联类型，之间用逗号隔开，多个该组合列表使用分号隔开
                                   O_ERR_CODE     OUT NUMBER, --返回编码（0 成功 1 失败）
                                   O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                   ) IS
  BEGIN

    O_RETURN_STR := '';
    begin
      -- 非构成关系，主从关系，绑定关系,共线关系,计费号码关系,同号关系,同址关系,主副关系,主资关系 从A端查Z端
      for rec in (select b.prod_inst_id, c.ext_prod_id, a.relation_type_cd
                    from prod_inst_rel a, prod_inst b, product c
                   where a.prod_inst_a_id = i_prod_inst_id
                     and a.prod_inst_z_id = b.prod_inst_id
                     and b.product_id = c.product_id
                     and a.relation_type_cd not in
                         ('100300', '100600', '109950', '109980', '109930',
                          '109910', '109990', '109920', '109940')
                     and a.status_cd = '1000') loop
        O_RETURN_STR := O_RETURN_STR || rec.prod_inst_id || ',' ||
                        rec.ext_prod_id || ',' || rec.relation_type_cd || ';';
      end loop;
      -- 绑定关系,共线关系,计费号码关系,同号关系,同址关系,主副关系,主资关系 从Z端查A端
      for rec in (select b.prod_inst_id, c.ext_prod_id, a.relation_type_cd
                    from prod_inst_rel a, prod_inst b, product c
                   where a.prod_inst_z_id = i_prod_inst_id
                     and a.prod_inst_a_id = b.prod_inst_id
                     and b.product_id = c.product_id
                     and a.relation_type_cd in
                         ('109950', '109980', '109930', '109910', '109990',
                          '109920', '109940')
                     and a.status_cd = '1000') loop
        O_RETURN_STR := O_RETURN_STR || rec.prod_inst_id || ',' ||
                        rec.ext_prod_id || ',' || rec.relation_type_cd || ';';
      end loop;
      O_ERR_CODE := 0;
      O_ERR_MSG  := '';
    EXCEPTION
      WHEN OTHERS THEN
        O_RETURN_STR := '';
        O_ERR_CODE   := 1;
        O_ERR_MSG    := sqlerrm;
    end;

  END PROC_QUERY_REL_PRODUCT;

  /************************************************************************
  Function  ：此过程是根据产品实例查询产品的属性信息。
  该过程提供pf调用。
  Author　  ：Wangjianjun
  Date      : 2012-07-26
  Parameter :
              I_PROD_INST_ID --产品实例ID
              O_FACT_SPEED   --实际速率
              O_UP_SPEED     --上行速率
              O_DOWN_SPEED   --下行速率
              O_MAX_LINK     --最大连接数
              O_BIND_TYPE    --漫游方式
              O_FLAG         --业务标识（0 未定义 1 是）
              --O_FLAG是由多位组成，有新的需求再扩展位数，比如
              --查询的宽带是承载iTV、是e8-2套餐的宽带、是承载商铺管家业务，那么oO_FLAG返回111
              --查询的宽带是承载iTV、不是e8-2套餐的宽带、不是承载商铺管家业务，那么O_FLAG返回100 等等
              O_WIRELESS     --漫游/MANYOU  区域漫游/QYMANYOU  不漫游/BMANYOU
              O_ACCOUNT      --宽带帐号
              O_USE_SAMETIME --WLAN和有线是否同时使用（是/WYTSSYY、否/WYKSSYN）
              O_ERR_CODE     --返回编码（0 成功 1 失败）
              O_ERR_MSG      --返回具体的错误信息
  ************************************************************************/
  PROCEDURE PROC_GET_PROD_INST_ATTR(I_PROD_INST_ID IN NUMBER, --产品实例ID
                                    O_FACT_SPEED   OUT VARCHAR2, --实际速率
                                    O_UP_SPEED     OUT VARCHAR2, --上行速率
                                    O_DOWN_SPEED   OUT VARCHAR2, --下行速率
                                    O_MAX_LINK     OUT VARCHAR2, --最大连接数
                                    O_BIND_TYPE    OUT VARCHAR2, --宽带线路绑定
                                    O_FLAG         OUT VARCHAR2, --业务标识（0 未定义 1 是）
                                    --o_flag是由多位组成，有新的需求再扩展位数，比如
                                    --查询的宽带是承载iTV、是e8-2套餐的宽带、是承载商铺管家业务，那么o_flag返回111
                                    --查询的宽带是承载iTV、不是e8-2套餐的宽带、不是承载商铺管家业务，那么o_flag返回100 等等
                                    O_WIRELESS     OUT VARCHAR2, --开通方式 不漫游/省内漫游/国内漫游/国际漫游
                                    O_ACCOUNT      OUT VARCHAR2, --宽带帐号
                                    O_USE_SAMETIME OUT VARCHAR2, --WLAN和有线是否同时使用（是/WYTSSYY、否/WYKSSYN）
                                    O_ERR_CODE     OUT NUMBER, --返回编码（0 成功 1 失败）
                                    O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                    ) IS
    v_count        NUMBER := 0; --变量
    v_flag1        varchar2(2) := '0';
    v_flag2        varchar2(2) := '0';
    v_flag3        varchar2(2) := '0';
    v_flag4        varchar2(2) := '0';
    v_flag5        varchar2(2) := '0';
    v_area_id      NUMBER(10) := 0; --变量   本地网标识
    v_cdma_speed   varchar2(50) := '0';
    v_product_id   product.product_id%type;
    v_prod_inst_id prod_inst.prod_inst_id%type;
    v_cwrdsy_value prod_inst_attr.attr_value%type;
  BEGIN
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';
    begin
      select a.product_id, a.account, a.area_id
        into v_product_id, o_account, v_area_id
        from prod_inst a
       where a.prod_inst_id = I_PROD_INST_ID;
    exception
      when no_data_found then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '产品实例不存在';
        return;
    end;

    /*
    crm1.0 cq 20090827 CDMA
    若PF传入的输入参数i_prod_inst_id为“CDMA业务”产品，CRM返回该产品实例上“校园宽带”附属产品的速率。
    另外，“校园宽带”附属产品档案落地时不区分上行速率和下行速率，而是合并为“速率”特性，
    特性取值形态如“128K/512K”、“512K/4M”等。
    输出参数取值如下：
    o_fact_speed  NULL
    o_up_speed    取“校园宽带”附属产品下级特性“速率”属性取值的前半部分
    o_down_speed  取“校园宽带”附属产品下级特性“速率”属性取值的后半部分
    o_max_link    1
    o_bind_type   不漫游
    o_flag        000
    o_wireless    取“CDMA业务”产品实例上“无线宽带”附属产品的“漫游范围”特性；找不到，默认为“不漫游”
    o_account     手机号码
    */
    if v_product_id = 800000002 then
      o_max_link   := '1';
      o_bind_type  := '';
      o_flag       := '000';
      o_fact_speed := '';
      begin
        select c.prod_inst_z_id
          into v_prod_inst_id
          from prod_inst a, product b, prod_inst_rel c, prod_inst d
         where a.prod_inst_id = c.prod_inst_a_id
           and c.prod_inst_z_id = d.prod_inst_id
           and d.product_id = b.product_id
           and b.ext_prod_id in ('800000574', '800000575', '800000576')
           and c.relation_type_cd = '100600'
           and a.prod_inst_id = i_prod_inst_id;
        begin
          select b.attr_value_name
            into v_cdma_speed
            from prod_inst_attr a, attr_value b
          -- where a.prod_inst_id = i_prod_inst_id  这里应该用v_prod_inst_id 作为条件取
            where a.prod_inst_id = v_prod_inst_id
            and a.attr_value_id = b.attr_value_id
            and a.attr_id = 800000315;
        exception
          when no_data_found then
            null;
        end;
        if v_cdma_speed != '0' then
          o_up_speed   := substr(v_cdma_speed,
                                 1,
                                 instr(v_cdma_speed, '/') - 1);
          o_down_speed := substr(v_cdma_speed, instr(v_cdma_speed, '/') + 1);
        end if;
      exception
        when others then
          null;
      end;

      o_wireless := '';
      begin
        select c.prod_inst_z_id
          into v_prod_inst_id
          from prod_inst a, product b, prod_inst_rel c, prod_inst d
         where a.prod_inst_id = c.prod_inst_a_id
           and c.prod_inst_z_id = d.prod_inst_id
           and d.product_id = b.product_id
           and b.ext_prod_id = '800296774'
           and c.relation_type_cd = '100600'
           and a.prod_inst_id = i_prod_inst_id;

        /*
        crm00040788 ：“热点使用”值是“关闭” 的，请直接O_WIRELESS返回“BMY” 即不漫游关闭WiFi的意思
        800003585	CWRDSYY	启用
        800003618	GBWLAN	关闭
        */
        --热点使用
        begin
          select a.attr_value
            into v_cwrdsy_value
            from prod_inst_attr a
           where a.prod_inst_id = v_prod_inst_id
             and a.attr_id = 800001645;
        exception
          when no_data_found then
            v_cwrdsy_value := 'GBWLAN';
        end;
        --开通方式
        IF (v_cwrdsy_value = 'GBWLAN') THEN
	        O_WIRELESS := 'BMY';
        ELSE
          begin
            select decode(a.attr_value,800003245,'QGMY',800003404,'SNMY',a.attr_value)
              into o_wireless
              from prod_inst_attr a
             where a.prod_inst_id = v_prod_inst_id
               and a.attr_id = 800001617;
          exception
            when no_data_found then
              null;
          end;
        END IF;
      exception
        when others then
          null;
      end;
      return;
    end if;
    --实际速率
    begin
      select b.attr_value_name
        into O_FACT_SPEED
        from prod_inst_attr a, attr_value b
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_value_id = b.attr_value_id
         and a.attr_id = 800000283;
    exception
      when no_data_found then
        null;
    end;
    --上行速率
/*    begin
      select b.attr_value_name
        into O_UP_SPEED
        from prod_inst_attr a, attr_value b
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_value_id = b.attr_value_id
         and a.attr_id = 800000260;
    exception
      when no_data_found then
        null;
    end;*/
    /*  crm00039206
    【解决方案】吴端景(吴端景) 17:02:47
    那确认的结果就是：先取实际上行速率，没有实际上行速率就取上行速率，
    如果两个都没有的话，按照速率模板返回或者返回空。 这个是正确的处理逻辑。
    */
    --800013726 实际上行速率 800000260  上行速率
    begin
      select b.attr_value_name
        into O_UP_SPEED
        from prod_inst_attr a, attr_value b
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_value_id = b.attr_value_id
         and a.attr_id = 800013726;
    exception
      when no_data_found then
        begin
            select b.attr_value_name
              into O_UP_SPEED
              from prod_inst_attr a, attr_value b
             where a.prod_inst_id = i_prod_inst_id
               and a.attr_value_id = b.attr_value_id
               and a.attr_id = 800000260;
        exception
           when others then
             null;
        end;
      when others then
         null;
    end;

    --下行速率
    begin
      select b.attr_value_name
        into O_DOWN_SPEED
        from prod_inst_attr a, attr_value b
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_value_id = b.attr_value_id
         and a.attr_id = 800000315;
    exception
      when no_data_found then
        null;
    end;
    --最大连接数
    begin
      select a.attr_value
        into O_MAX_LINK
        from prod_inst_attr a
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_id = 800000316;
    exception
      when no_data_found then
        null;
    end;
    --宽带线路绑定
    begin
      select a.attr_value
        into O_BIND_TYPE
        from prod_inst_attr a
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_id = 800000281;
    exception
      when no_data_found then
        null;
    end;

    --帐号
    begin
      select a.account
        into o_account
        from prod_inst a
       where a.prod_inst_id = i_prod_inst_id;
    exception
      when no_data_found then
        null;
    end;
    --WLAN和有线是否同时使用
    begin
      select a.attr_value
        into O_USE_SAMETIME
        from prod_inst_attr a
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_id = 800001617;
    exception
      when no_data_found then
        null;
    end;
    --开通方式
    begin
      select a.attr_value
        into o_wireless
        from prod_inst_attr a
       where a.prod_inst_id = i_prod_inst_id
         and a.attr_id = 800000328;
    exception
      when no_data_found then
        null;
    end;
    -- 绑定关系,共线关系,计费号码关系,同号关系,同址关系,主副关系,主资关系 从Z端查A端
    select count(1)
      into v_count
      from product b, prod_inst_rel c, prod_inst d
     where c.prod_inst_a_id = d.prod_inst_id
       and d.product_id = b.product_id
       and b.ext_prod_id = '594000155' --ITV
       and c.relation_type_cd = '109950'
       and c.prod_inst_z_id = i_prod_inst_id
       and c.status_cd = '1000';
    if v_count > 0 then
      v_flag1 := '1';
    end if;

    select count(1)
      into v_count
      from offer_prod_inst_rel a, prod_offer_inst b, prod_offer c
     where a.prod_offer_inst_id = b.prod_offer_inst_id
       and b.prod_offer_id = c.prod_offer_id
       and c.ext_offer_nbr in ('800006802', '800006803') --E8-2
       and a.prod_inst_id = i_prod_inst_id
       and a.status_cd = '1000';
    if v_count > 0 then
      v_flag2 := '1';
    end if;

    select count(1)
      into v_count
      from product b, prod_inst_rel c, prod_inst d
     where c.prod_inst_a_id = d.prod_inst_id
       and d.product_id = b.product_id
       and b.ext_prod_id = '610004685' --全球眼大众版
       and c.relation_type_cd = '100300' --构成关系
       and c.prod_inst_z_id = i_prod_inst_id
       and c.status_cd = '1000';
    if v_count > 0 then
      v_flag3 := '1';
    end if;

    /*
    此需求针对全省都做此判断（泉州的e8终端落地方案与其他地市不同，对泉州本地网，o_flag第4位都返回0即可）；
    */
    if v_area_id <> 6 then
      select count(1)
        into v_count
        from product b, prod_inst_rel c, prod_inst d
       where c.prod_inst_a_id = d.prod_inst_id
         and d.product_id = b.product_id
         and b.ext_prod_id = '610001601' --e8终端
         and c.relation_type_cd = '109940' --主资关系
         and c.prod_inst_z_id = i_prod_inst_id
         and c.status_cd = '1000';
      if v_count > 0 then
        v_flag4 := '1';
      end if;
    end if;
    --第5位：表示用户IP类型值  0-默认值、1-单栈V4
    select count(1)
      into v_count
      from prod_inst_attr a
     where a.prod_inst_id = i_prod_inst_id
       and a.status_cd = '1000'
       and a. attr_id = 800061959
       and attr_value_id = 900053334;
    if v_count > 0 then
      v_flag5 := '1';
    end if;

    o_flag := v_flag1 || v_flag2 || v_flag3 || v_flag4 || v_flag5;
  exception
    when others then
      o_up_speed     := '';
      o_down_speed   := '';
      o_max_link     := '';
      o_bind_type    := '';
      o_flag         := '0';
      o_wireless     := '';
      o_account      := '';
      o_use_sametime := '';
  END PROC_GET_PROD_INST_ATTR;

  /*-------------------------------------------------
  产品是否停机查询
  提供PF查询产品是否停机（判断产品包含“挂失停机/欠费单停/欠费双停/违章停机/用户申请停机/预拆机”返回停机标识）时，调用此接口
  Author  : ouzhf
  Created : 2012-08-15
  -------------------------------------------------*/
  PROCEDURE PROC_PROD_STOP_STATUS(I_PROD_INST_ID IN NUMBER, --成员实例标识
                               -- O_IS_STOP      OUT VARCHAR2, --是否停机标识： 1-单停状态（欠费单停）；2-双停状态（挂失停机/欠费双停/违章停机/用户申请停机/预拆机）；3-未激活（预开通）；4-未激活（充值开通）；0-其他状态
                                  O_IS_STOP      OUT VARCHAR2, --是否停机标识： 1-单停状态（欠费单停）；2-PROD_INST.STATUS_CD = 109998 预拆机；3-未激活（预开通）；4-未激活（充值开通）；0-其他状态
                                                               --5-双停状态（挂失停机）;6-双停状态（欠费双停);7-双停状态（违章停机);8-双停状态（用户申请停机); 9-双停状态（预拆机）
                                  O_ERR_CODE     OUT NUMBER, --返回值：0-成功 ；1-失败
                                  O_ERR_MSG      OUT VARCHAR2 --返回具体的错误信息
                                  ) IS
    V_STATUS_CD VARCHAR2(6);
    V_COUNT     NUMBER;
  BEGIN
    O_IS_STOP  := 0; --默认其他状态
    O_ERR_CODE := 0;
    O_ERR_MSG  := '成功';

    --查询产品状态
    /*
    120000  停机
    109998  预拆机
    140000  未激活
        */
    SELECT STATUS_CD
      INTO V_STATUS_CD
      FROM PROD_INST
     WHERE PROD_INST_ID = I_PROD_INST_ID
       AND STATUS_CD <> '110000'; --去除拆机状态110000
    IF V_STATUS_CD = '109998' THEN
      O_IS_STOP := 2;
      RETURN;
    ELSIF V_STATUS_CD = '140000' THEN
      /*
      800000312 充值开通
      800000280 预开通
                */
      --预开通
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID || '' = 800000280
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 3;
        RETURN;
      END IF;
      --充值开通
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID || '' = 800000312
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 4;
        RETURN;
      END IF;
    ELSE
      /*
      800000250  预拆机
      800000251  欠费双停
      800000252  违章停机
      800000253  用户申请停机
      800000254  挂失停机
      800013054  欠费单停
          */
      --双停
      --TTP22954 BEGIN  FJCRMV2.0_BUG_泉州市_过程PROC_PROD_STOP_STATUS改造
/*      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID IN
             (800000250, 800000251, 800000252, 800000253, 800000254)

         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 2;
        RETURN;
      END IF;*/

      /*5-双停状态（挂失停机）  800000254
        6-双停状态（欠费双停);  800000251
        7-双停状态（违章停机);  800000252
        8-双停状态（用户申请停机);  800000253
        9-双停状态（预拆机)     800000250
        */

      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID = 800000254
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 5 ;
        RETURN;
      END IF;

      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID = 800000251
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 6 ;
        RETURN;
      END IF;

      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID = 800000252
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 7 ;
        RETURN;
      END IF;

      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID = 800000253
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 8 ;
        RETURN;
      END IF;

      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID = 800000250
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 9 ;
        RETURN;
      END IF;

      --TTP22954 END

      --单停
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR A
       WHERE ATTR_ID || '' = 800013054
         AND STATUS_CD = '1000'
         AND PROD_INST_ID = I_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        O_IS_STOP := 1;
        RETURN;
      END IF;
    END IF;

    O_ERR_CODE := 0;
    O_ERR_MSG  := '成功';
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := sqlerrm;
      RETURN;
  END PROC_PROD_STOP_STATUS;

end PKG_PF;
/
