CREATE PACKAGE BODY           PKG_YSJH IS
  /*
    --积分数据上传
    PROCEDURE PROC_YSJH_MAIN(V_FLAG OUT VARCHAR2) IS
      V_TASK_CLASS  VARCHAR2(20) := '1003'; --过程名
      V_ERRORCODE   VARCHAR2(20);
      V_ERRORTEXT   VARCHAR2(254);
      N_DEAL_BATCH  NUMBER(20); --处理批次
      D_BEGIN_DATE  DATE;
      D_END_DATE    DATE;
      V_CYCLE_TYPE  CHAR(1) := 'D'; --处理周期类型
      N_TASK_CYCLE  NUMBER(10); --周期
      N_HANDLE_STEP NUMBER(1); --步骤
      N_NO          NUMBER(20);
    BEGIN
      --取处理开始时间
      SELECT SYSDATE INTO D_BEGIN_DATE FROM DUAL;
      --生成处理任务
      PROC_TASK_INSERT(N_DEAL_BATCH, --任务批次
                       V_TASK_CLASS, --过程代码
                       1, --总步骤
                       V_CYCLE_TYPE, --周期类型
                       N_TASK_CYCLE, --任务周期  OUT
                       N_HANDLE_STEP, --任务步骤  OUT
                       V_FLAG); --处理标志  OUT

      IF V_FLAG = 'S' AND N_HANDLE_STEP = 0 THEN
        --1.1  实物终端参数
        EXECUTE IMMEDIATE 'TRUNCATE TABLE NX_CRM_COL_DEF';
        INSERT INTO NX_CRM_COL_DEF
          (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
          SELECT 'STORE', SS.STORE_ID, SS.STORE_NAME, '0', 3
            FROM CRMV1.MKT_RESO_STORE SS
           WHERE SS.STATE IN ('70A', '70N');
        COMMIT;

        EXECUTE IMMEDIATE 'TRUNCATE TABLE NX_CRM_STAFF';
        INSERT INTO NX_CRM_STAFF
          (STAFF_ID, STAFF_NAME, STAFF_CODE, ORG_ID, CUR_GRADE)
          SELECT S.STAFF_ID,
                 S.STAFF_NAME,
                 S.STAFF_CODE,
                 S.ORG_ID,
                 (SELECT MAX(LEVEL)
                    FROM CRMV2.ORGANIZATION
                   START WITH ORG_ID = S.ORG_ID
                  CONNECT BY PRIOR PARENT_ORG_ID = ORG_ID)
            FROM STAFF S
           WHERE S.STATUS_CD = '1000';
        COMMIT;

        EXECUTE IMMEDIATE 'TRUNCATE TABLE NX_CRM_ORGANIZATION';
        INSERT INTO NX_CRM_ORGANIZATION
          (ORG_ID,
           ORG_NAME,
           PARENT_ORG_ID,
           REGION_ID,
           REGION_NAME,
           UP_REGION_ID,
           UP_REGION_NAME)
          SELECT O.ORG_ID,
                 O.ORG_NAME,
                 O.PARENT_ORG_ID,
                 CR1.COMMON_REGION_ID,
                 CR1.REGION_NAME，CR2.COMMON_REGION_ID,
                 CR2.REGION_NAME
            FROM CRMV2.ORGANIZATION  O,
                 CRMV2.COMMON_REGION CR1,
                 CRMV2.COMMON_REGION CR2
           WHERE O.STATUS_CD = '1000'
             AND O.ORG_ID > 1000 --取宁夏组织
             AND O.AREA_ID = CR1.COMMON_REGION_ID
             AND CR1.UP_REGION_ID = CR2.COMMON_REGION_ID(+);
        COMMIT;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SQLERRM);
        V_FLAG := SQLERRM;
    END;
  */
  PROCEDURE PROC_NX_CRM_SERV_DATA(V_FLAG OUT VARCHAR2) IS

  BEGIN
    -- 先清除数据
    EXECUTE IMMEDIATE 'TRUNCATE TABLE NX_CRM_SERV_DATA';

    -- 代理商预存充值费用
    INSERT INTO NX_CRM_SERV_DATA
      (PROD_INST_ID,
       REGION_ID,
       ACCT_ITEM_TYPE_ID,
       AMOUNT,
       CUST_ORDER_ID,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       MOBILE_INCOME,
       STAFF_ID,
       ORG_ID,
       DATA_SRC_TYPE,
       SYSTEM_ID,
       TAX,
       TAX_RATE,
       AFTER_TAX,
       REPORT_MODE,
       GENERAL_TAXER)
      SELECT 0,
             O.REGION_CD,
             999, -- 代理商充值
             ATAR.AIRFULL_VALUE,
             ATAR.SERIAL_ID,
             '0',
             '1',
             ATAR.AIRFULL_DATE,
             '100000',
             NULL,
             ATAR.STAFF_ID,
             ATAR.TEAM_ID,
             '201',
             '3',
             0,
             0,
             ATAR.AIRFULL_VALUE / 100,
             2,
             'NO'
        FROM CRMV2.AGENT_TEAM_AIRFULL_RECORD ATAR, CRMV2.ORGANIZATION O
       WHERE ATAR.AIRFULL_VALUE != 0
         AND ATAR.TEAM_ID = O.ORG_ID
         AND ATAR.STAFF_ID NOT IN (1309, 400125671, 62700, 334627)
         AND ATAR.AIRFULL_STATE = '10A';
    COMMIT;

    -- 代理商押金
    INSERT INTO NX_CRM_SERV_DATA
      (PROD_INST_ID,
       REGION_ID,
       ACCT_ITEM_TYPE_ID,
       AMOUNT,
       CUST_ORDER_ID,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       MOBILE_INCOME,
       STAFF_ID,
       ORG_ID,
       DATA_SRC_TYPE,
       SYSTEM_ID,
       TAX,
       TAX_RATE,
       AFTER_TAX,
       REPORT_MODE,
       GENERAL_TAXER)
      SELECT 0,
             O.REGION_CD,
             888, -- 代理商押金
             CF.FEE_VALUE * 100,
             CF.OPERATORS_FEE_ID,
             CF.OPERATORS_FEE_ID,
             '1',
             CF.CREATE_DATE,
             '100000',
             NULL,
             CF.CREATE_STAFF,
             CF.CREATE_ORG,
             '201',
             '3',
             0,
             0,
             CF.FEE_VALUE / 100,
             2,
             'NO'
        FROM CRMV2.OPERATORS_FEE CF, CRMV2.ORGANIZATION O
       WHERE CF.STATUS_CD = '1000'
         AND CF.FEE_VALUE != 0
         AND CF.CREATE_ORG = O.ORG_ID
         AND CF.CREATE_STAFF NOT IN (1309, 400125671, 62700, 334627);
    COMMIT;

    -- 与用户相关的通信费用
    INSERT INTO NX_CRM_SERV_DATA
      (PROD_INST_ID,
       REGION_ID,
       ACCT_ITEM_TYPE_ID,
       AMOUNT,
       CUST_ORDER_ID,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       MOBILE_INCOME,
       STAFF_ID,
       ORG_ID,
       DATA_SRC_TYPE,
       SYSTEM_ID,
       TAX,
       TAX_RATE,
       AFTER_TAX,
       REPORT_MODE,
       GENERAL_TAXER)
      SELECT A.PROD_INST_ID PROD_INST_ID,
             C.REGION_CD REGION_ID,
             A.ACCT_ITEM_TYPE_ID ACCT_ITEM_TYPE_ID,
             C.BILL_AMOUNT AMOUNT,
             A.ACCT_ITEM_ID CUST_ORDER_ID,
             A.CUST_SO_NUMBER PAYMENT_ID,
             DECODE(A.STATUS_CD, '5JB', '1', '2') FEE_FLAG,
             C.PAYMENT_DATE PAYMENT_DATE,
             B.PAYMENT_METHOD_CD PAYMENT_METHOD,
             (SELECT DECODE(P.ATTR_VALUE,
                            NULL,
                            NULL,
                            '集团集采',
                            '1',
                            '省公司集采',
                            '2',
                            '3G(条码)',
                            '3',
                            '代理商自采',
                            '4',
                            '分公司自采',
                            '5',
                            '双模(条码)',
                            '6',
                            '龙终端',
                            '7',
                            '电信自采',
                            '8',
                            '代理商铺货',
                            '9',
                            '99')
                FROM (SELECT H.BUY_PROD_ID,
                             (SELECT K.ATTR_VALUE
                                FROM CRMV2.MKT_RES_INST_ATTR K
                               WHERE K.MKT_RES_INST_ID = J.MKT_RES_INST_ID
                                 AND K.ATTR_ID = '760001113') ATTR_VALUE
                        FROM CRMV2.MKT_OCCUPY   H,
                             CRMV2.PROD_INST    L,
                             CRMV2.MKT_RES_INST J
                       WHERE J.MKT_RES_INST_ID = H.MKT_RESO_ID
                         AND L.PRODUCT_ID IN (401754, 401731)
                         AND L.PROD_INST_ID = H.BUY_PROD_ID
                         AND H.BUY_PROD_ID = L.PROD_INST_ID) P
               WHERE P.BUY_PROD_ID = A.PROD_INST_ID
                 AND ROWNUM = 1) MOBILE_INCOME,
             C.STAFF_ID STAFF_ID,
             C.ORG_ID ORG_ID,
             '201' DATA_SRC_TYPE,
             '3' SYSTEM_ID,
             TO_NUMBER(TRIM(TO_CHAR(NVL(A.TAX, 0) / 100,
                                    '99999999999999.99'))) TAX,
             NVL(A.TAX_RATE, 0) / 100 TAX_RATE,
             C.BILL_AMOUNT / 100 -
             TO_NUMBER(TRIM(TO_CHAR(NVL(A.TAX, 0) / 100,
                                    '99999999999999.99'))) AFTER_TAX,
             (SELECT REPORT_MODE
                FROM CRMV2.ACCT_ITEM_TYPE AI
               WHERE AI.ACCT_ITEM_TYPE_ID = A.ACCT_ITEM_TYPE_ID
                 AND ROWNUM <= 1) REPORT_MODE,
             DECODE((SELECT CA.ATTR_VALUE
                      FROM CRMV2.CUST_EXTERNAL_ATTR CA
                     WHERE CA.CUST_ID = A.CUST_ID
                       AND CA.ATTR_ID = 950003213),
                    'YES',
                    'YES',
                    'NO') GENERAL_TAXER
        FROM CRMV2.ACCT_ITEM A, CRMV2.PAYMENT B, CRMV2.BILL C
       WHERE A.STATUS_CD IN ('5JB', '5JC')
         AND A.CUST_SO_NUMBER IS NOT NULL
         AND A.BILL_ID = C.BILL_ID
         AND B.BILL_ID = C.BILL_ID
         AND B.AMOUNT != 0
            -- fzboo add20131227
         AND C.STAFF_ID IS NOT NULL
         AND C.STAFF_ID NOT IN (1309, 400125671, 62700, 334627)
         AND A.ACCT_ITEM_TYPE_ID NOT IN (98, 400600, 400601)
         AND A.SOURCE != 'MATERIAL';
    COMMIT;

    -- 与用户相关的通信费用(历史表)
    INSERT INTO NX_CRM_SERV_DATA
      (PROD_INST_ID,
       REGION_ID,
       ACCT_ITEM_TYPE_ID,
       AMOUNT,
       CUST_ORDER_ID,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       MOBILE_INCOME,
       STAFF_ID,
       ORG_ID,
       DATA_SRC_TYPE,
       SYSTEM_ID,
       TAX,
       TAX_RATE,
       AFTER_TAX,
       REPORT_MODE,
       GENERAL_TAXER)
      SELECT A.PROD_INST_ID PROD_INST_ID,
             C.REGION_CD REGION_ID,
             A.ACCT_ITEM_TYPE_ID ACCT_ITEM_TYPE_ID,
             C.BILL_AMOUNT AMOUNT,
             A.ACCT_ITEM_ID CUST_ORDER_ID,
             A.CUST_SO_NUMBER PAYMENT_ID,
             DECODE(A.STATUS_CD, '5JB', '1', '2') FEE_FLAG,
             C.PAYMENT_DATE PAYMENT_DATE,
             B.PAYMENT_METHOD_CD PAYMENT_METHOD,
             (SELECT DECODE(P.ATTR_VALUE,
                            NULL,
                            NULL,
                            '集团集采',
                            '1',
                            '省公司集采',
                            '2',
                            '3G(条码)',
                            '3',
                            '代理商自采',
                            '4',
                            '分公司自采',
                            '5',
                            '双模(条码)',
                            '6',
                            '龙终端',
                            '7',
                            '电信自采',
                            '8',
                            '代理商铺货',
                            '9',
                            '99')
                FROM (SELECT H.BUY_PROD_ID,
                             (SELECT K.ATTR_VALUE
                                FROM CRMV2.MKT_RES_INST_ATTR K
                               WHERE K.MKT_RES_INST_ID = J.MKT_RES_INST_ID
                                 AND K.ATTR_ID = '760001113') ATTR_VALUE
                        FROM CRMV2.MKT_OCCUPY   H,
                             CRMV2.PROD_INST    L,
                             CRMV2.MKT_RES_INST J
                       WHERE J.MKT_RES_INST_ID = H.MKT_RESO_ID
                         AND L.PRODUCT_ID IN (401754, 401731)
                         AND L.PROD_INST_ID = H.BUY_PROD_ID
                         AND H.BUY_PROD_ID = L.PROD_INST_ID) P
               WHERE P.BUY_PROD_ID = A.PROD_INST_ID
                 AND ROWNUM = 1) MOBILE_INCOME,
             C.STAFF_ID STAFF_ID,
             C.ORG_ID ORG_ID,
             '201' DATA_SRC_TYPE,
             '3' SYSTEM_ID,
             TO_NUMBER(TRIM(TO_CHAR(NVL(A.TAX, 0) / 100,
                                    '99999999999999.99'))) TAX,
             NVL(A.TAX_RATE, 0) / 100 TAX_RATE,
             C.BILL_AMOUNT / 100 -
             TO_NUMBER(TRIM(TO_CHAR(NVL(A.TAX, 0) / 100,
                                    '99999999999999.99'))) AFTER_TAX,
             (SELECT REPORT_MODE
                FROM CRMV2.ACCT_ITEM_TYPE AI
               WHERE AI.ACCT_ITEM_TYPE_ID = A.ACCT_ITEM_TYPE_ID
                 AND ROWNUM <= 1) REPORT_MODE,
             DECODE((SELECT CA.ATTR_VALUE
                      FROM CRMV2.CUST_EXTERNAL_ATTR CA
                     WHERE CA.CUST_ID = A.CUST_ID
                       AND CA.ATTR_ID = 950003213),
                    'YES',
                    'YES',
                    'NO') GENERAL_TAXER
        FROM CRMV2.ACCT_ITEM_HIS A, CRMV2.PAYMENT B, CRMV2.BILL C
       WHERE A.STATUS_CD IN ('5JB', '5JC')
         AND A.CUST_SO_NUMBER IS NOT NULL
         AND A.BILL_ID = C.BILL_ID
         and B.BILL_ID = C.BILL_ID
         AND B.AMOUNT != 0
            -- fzboo add20131227
         AND C.STAFF_ID IS NOT NULL
         AND C.STAFF_ID NOT IN (1309, 400125671, 62700, 334627)
         AND A.ACCT_ITEM_TYPE_ID NOT IN (98, 400600, 400601)
         AND A.SOURCE != 'MATERIAL';
    COMMIT;

    -- 远程写卡UIM20元
    INSERT INTO NX_CRM_SERV_DATA
      (PROD_INST_ID,
       REGION_ID,
       ACCT_ITEM_TYPE_ID,
       AMOUNT,
       CUST_ORDER_ID,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       MOBILE_INCOME,
       STAFF_ID,
       ORG_ID,
       DATA_SRC_TYPE,
       SYSTEM_ID,
       TAX,
       TAX_RATE,
       AFTER_TAX,
       REPORT_MODE,
       GENERAL_TAXER)
      SELECT (SELECT P.PROD_INST_ID
                FROM CRMV2.PROD_INST P
               WHERE P.ACC_NBR = A.PHONENUM
                 AND P.STATUS_CD != '110000') PROD_INST_ID,
             (SELECT P.COMMON_REGION_ID
                FROM CRMV2.PROD_INST P
               WHERE P.ACC_NBR = A.PHONENUM
                 AND P.STATUS_CD != '110000') REGION_ID,
             133 ACCT_ITEM_TYPE_ID,
             A.MONNEY,
             NULL CUST_ORDER_ID,
             A.SERIAL PAYMENT_ID,
             DECODE(A.STATE, '5JB', '1', '2') FEE_FLAG,
             A.CREATEDATE PAYMENT_DATE,
             '100000' PAYMENT_METHOD,
             (SELECT DECODE(P.ATTR_VALUE,
                            NULL,
                            NULL,
                            '集团集采',
                            '1',
                            '省公司集采',
                            '2',
                            '3G(条码)',
                            '3',
                            '代理商自采',
                            '4',
                            '分公司自采',
                            '5',
                            '双模(条码)',
                            '6',
                            '龙终端',
                            '7',
                            '电信自采',
                            '8',
                            '代理商铺货',
                            '9',
                            '99')
                FROM (SELECT H.BUY_PROD_ID,
                             (SELECT K.ATTR_VALUE
                                FROM CRMV2.MKT_RES_INST_ATTR K
                               WHERE K.MKT_RES_INST_ID = J.MKT_RES_INST_ID
                                 AND K.ATTR_ID = '760001113') ATTR_VALUE
                        FROM CRMV2.MKT_OCCUPY   H,
                             CRMV2.PROD_INST    L,
                             CRMV2.MKT_RES_INST J
                       WHERE J.MKT_RES_INST_ID = H.MKT_RESO_ID
                         AND L.PRODUCT_ID IN (401754, 401731)
                         AND L.PROD_INST_ID = H.BUY_PROD_ID
                         AND H.BUY_PROD_ID = L.PROD_INST_ID) P
               WHERE P.BUY_PROD_ID =
                     (SELECT P.PROD_INST_ID
                        FROM CRMV2.PROD_INST P
                       WHERE P.ACC_NBR = A.PHONENUM
                         AND P.STATUS_CD != '110000')
                 AND ROWNUM = 1) MOBILE_INCOME,
             A.STAFFID STAFF_ID,
             A.TEAMID ORG_ID,
             '201' DATA_SRC_TYPE,
             '3' SYSTEM_ID,
             TO_NUMBER(TRIM(TO_CHAR(A.MONNEY / 100 / (1 + 0.17) * 0.17,
                                    '99999999999999.99'))) TAX,
             0.17 TAX_RATE,
             A.MONNEY / 100 -
             TO_NUMBER(TRIM(TO_CHAR(A.MONNEY / 100 / (1 + 0.17) * 0.17,
                                    '99999999999999.99'))) AFTER_TAX,
             (SELECT REPORT_MODE
                FROM CRMV2.ACCT_ITEM_TYPE AI
               WHERE AI.ACCT_ITEM_TYPE_ID = 133
                 AND ROWNUM <= 1) REPORT_MODE,
             'NO'
        FROM CRMV2.REMOTE_WRITE_CARD A
       WHERE A.STATE = '5JB'
         AND A.MONNEY = '2000.0'
         AND NOT EXISTS
       (SELECT 'x' FROM CRMV2.PROD_INST P WHERE P.ACC_NBR = A.PHONENUM);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      V_FLAG := SQLERRM;
  END;

  PROCEDURE PROC_NX_CRM_NOSERV_DATA(V_FLAG OUT VARCHAR2) IS

  BEGIN
    -- 先清除数据
    EXECUTE IMMEDIATE 'DELETE FROM NX_CRM_NOSERV_DATA WHERE TYPE IS NULL';

    -- 实物销售
    INSERT INTO NX_CRM_NOSERV_DATA
      (ACCT_ITEM_TYPE_ID,
       AMOUNT,
       SPEC_AMOUNT,
       STORE_ID,
       MOBILE_INCOME,
       CUST_ORDER_ID,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       STAFF_ID,
       ORG_ID,
       DATA_SRC_TYPE,
       SYSTEM_ID,
       TYPE,
       TAX,
       TAX_RATE,
       AFTER_TAX,
       REPORT_MODE,
       GENERAL_TAXER)
      SELECT T.ACCT_ITEM_TYPE_ID ACCT_ITEM_TYPE_ID,
             SUM(T.AMOUNT) AMOUNT,
             T.SPEC_AMOUNT SPEC_AMOUNT,
             T.STORE_ID STORE_ID,
             DECODE(T.MOBILE_INCOME,
                    NULL,
                    NULL,
                    '集团集采',
                    '1',
                    '省公司集采',
                    '2',
                    '3G(条码)',
                    '3',
                    '代理商自采',
                    '4',
                    '分公司自采',
                    '5',
                    '双模(条码)',
                    '6',
                    '龙终端',
                    '7',
                    '电信自采',
                    '8',
                    '代理商铺货',
                    '9',
                    '99') MOBILE_INCOME,
             T.CUST_ORDER_ID CUST_ORDER_ID,
             T.PAYMENT_ID PAYMENT_ID,
             DECODE(T.FEE_FLAG, '70A', 1, 2) FEE_FLAG,
             T.PAYMENT_DATE PAYMENT_DATE,
             T.PAYMENT_METHOD PAYMENT_METHOD,
             T.STAFF_ID STAFF_ID,
             T.ORG_ID ORG_ID,
             T.DATA_SRC_TYPE DATA_SRC_TYPE,
             T.SYSTEM_ID SYSTEM_ID,
             NULL TYPE,
             SUM(T.TAX) TAX,
             T.TAX_RATE TAX_RATE,
             SUM(T.AFTER_TAX) AFTER_TAX,
             T.REPORT_MODE,
             T.GENERAL_TAXER
        FROM (SELECT F.MKT_RES_ID ACCT_ITEM_TYPE_ID,
                     G.AMOUNT AMOUNT,
                     F.AMOUNT SPEC_AMOUNT,
                     NULL STORE_ID,
                     NULL MOBILE_INCOME,
                     A.ORDER_ID CUST_ORDER_ID,
                     A.ORDER_NUMBER PAYMENT_ID,
                     A.PAYED_STATE FEE_FLAG,
                     A.CREA_DATE PAYMENT_DATE,
                     G.PAYMENT_METHOD_CD PAYMENT_METHOD,
                     A.STAFF_ID STAFF_ID,
                     A.TEAM_ID ORG_ID,
                     202 DATA_SRC_TYPE,
                     3 SYSTEM_ID,
                     TO_NUMBER(TRIM(TO_CHAR(G.AMOUNT / 100 /
                                            (1 + NVL(F.TAX_RATE / 100, 0)) *
                                            NVL(F.TAX_RATE / 100, 0),
                                            '99999999999999.99'))) TAX,
                     NVL(F.TAX_RATE, 0) / 100 TAX_RATE,
                     G.AMOUNT / 100 -
                     TO_NUMBER(TRIM(TO_CHAR(G.AMOUNT / 100 /
                                            (1 + NVL(F.TAX_RATE / 100, 0)) *
                                            NVL(F.TAX_RATE / 100, 0),
                                            '99999999999999.99'))) AFTER_TAX,
                     (SELECT REPORT_MODE
                        FROM CRMV2.ACCT_ITEM_TYPE AI
                       WHERE AI.ACCT_ITEM_TYPE_ID = F.ACCT_ITEM_TYPE_ID
                         AND ROWNUM <= 1) REPORT_MODE,
                     DECODE((SELECT CA.ATTR_VALUE
                              FROM CRMV2.CUST_EXTERNAL_ATTR CA
                             WHERE CA.CUST_ID = F.CUST_ID
                               AND CA.ATTR_ID = 950003213),
                            'YES',
                            'YES',
                            'NO') GENERAL_TAXER
                FROM CRMV2.MKT_RESO_ORDER A,
                     CRMV2.ACCT_ITEM_HIS  F,
                     CRMV2.PAYMENT        G
               WHERE A.ORDER_TYPE = '2'
                 AND A.ORDER_REASON = '801'
                 AND A.PAYED_STATE = '70A'
                 AND F.CUST_SO_NUMBER = A.ORDER_NUMBER
                 AND F.SOURCE = 'MATERIAL'
                 AND F.STATUS_CD IN ('5JB', '5JC')
                 AND G.BILL_ID = F.BILL_ID
              UNION ALL
              SELECT F.MKT_RES_ID ACCT_ITEM_TYPE_ID,
                     -G.AMOUNT AMOUNT,
                     -F.AMOUNT SPEC_AMOUNT, -- 退货为负值
                     NULL STORE_ID,
                     NULL MOBILE_INCOME,
                     A.ORDER_ID CUST_ORDER_ID,
                     A.ORDER_NUMBER PAYMENT_ID,
                     A.PAYED_STATE FEE_FLAG,
                     A.CREA_DATE PAYMENT_DATE,
                     G.PAYMENT_METHOD_CD PAYMENT_METHOD,
                     A.STAFF_ID STAFF_ID,
                     A.TEAM_ID ORG_ID,
                     202 DATA_SRC_TYPE,
                     3 SYSTEM_ID,
                     TO_NUMBER(TRIM(TO_CHAR(-G.AMOUNT / 100 /
                                            (1 + NVL(F.TAX_RATE / 100, 0)) *
                                            NVL(F.TAX_RATE / 100, 0),
                                            '99999999999999.99'))) TAX,
                     NVL(F.TAX_RATE, 0) / 100 TAX_RATE,
                     -G.AMOUNT / 100 -
                     TO_NUMBER(TRIM(TO_CHAR(-G.AMOUNT / 100 /
                                            (1 + NVL(F.TAX_RATE / 100, 0)) *
                                            NVL(F.TAX_RATE / 100, 0),
                                            '99999999999999.99'))) AFTER_TAX,
                     (SELECT REPORT_MODE
                        FROM CRMV2.ACCT_ITEM_TYPE AI
                       WHERE AI.ACCT_ITEM_TYPE_ID = F.ACCT_ITEM_TYPE_ID
                         AND ROWNUM <= 1) REPORT_MODE,
                     DECODE((SELECT CA.ATTR_VALUE
                              FROM CRMV2.CUST_EXTERNAL_ATTR CA
                             WHERE CA.CUST_ID = F.CUST_ID
                               AND CA.ATTR_ID = 950003213),
                            'YES',
                            'YES',
                            'NO') GENERAL_TAXER
                FROM CRMV2.MKT_RESO_ORDER A,
                     CRMV2.ACCT_ITEM_HIS  F,
                     CRMV2.PAYMENT        G
               WHERE A.ORDER_TYPE = '1'
                 AND A.ORDER_REASON = '803'
                 AND A.PAYED_STATE = '70A'
                 AND F.CUST_SO_NUMBER = A.ORDER_NUMBER
                 AND F.SOURCE = 'MATERIAL'
                 AND F.STATUS_CD IN ('5JB', '5JC')
                 AND G.BILL_ID = F.BILL_ID) T
       WHERE T.ORG_ID NOT IN (SELECT ID FROM NX_DLS)
         AND T.STAFF_ID IS NOT NULL
         AND (T.STORE_ID IS NULL OR T.STORE_ID NOT IN (416386, 418991))
         AND (T.MOBILE_INCOME IS NULL OR T.MOBILE_INCOME != '代理商自采')
       GROUP BY T.ACCT_ITEM_TYPE_ID,
                T.SPEC_AMOUNT,
                T.STORE_ID,
                T.MOBILE_INCOME,
                T.CUST_ORDER_ID,
                T.PAYMENT_ID,
                T.FEE_FLAG,
                T.PAYMENT_DATE,
                T.PAYMENT_METHOD,
                T.STAFF_ID,
                T.ORG_ID,
                T.DATA_SRC_TYPE,
                T.SYSTEM_ID,
                T.TAX_RATE,
                T.REPORT_MODE,
                T.GENERAL_TAXER;
    COMMIT;

    -- 先清除数据
    EXECUTE IMMEDIATE 'TRUNCATE TABLE VAT_CONTRACT';

    -- 合约计划中终端款算税接口表（在途的）
    INSERT INTO VAT_CONTRACT
      (CUST_ORDER_ID,
       PROD_OFFER_INST_ID,
       ACCT_ITEM_TYPE_ID,
       COST_PRICE,
       REAL_AMOUNT,
       TAXABLE_AMOUNT,
       TAX_RATE,
       TAX,
       AFTER_TAX,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       STAFF_ID,
       ORG_ID,
       CREATE_DATE)
      SELECT A.CUST_ORDER_ID,
             A.PROD_OFFER_INST_ID,
             A.ACCT_ITEM_TYPE_ID,
             A.COST_PRICE,
             A.REAL_AMOUNT,
             A.TAXABLE_AMOUNT,
             A.TAX_RATE,
             A.TAX,
             A.AFTER_TAX,
             A.CUST_ORDER_ID,
             DECODE(B.STATUS_CD, '5JB', '1', '2') FEE_FLAG,
             D.PAYMENT_DATE,
             C.PAYMENT_METHOD_CD PAYMENT_METHOD,
             A.CREATE_STAFF,
             A.CREATE_ORG,
             (SELECT T.ACCEPT_TIME
                FROM CRMV2.CUSTOMER_ORDER T
               WHERE T.CUST_ORDER_ID = A.CUST_ORDER_ID
                 AND ROWNUM <= 1) CREATE_DATE
        FROM CRMV2.ACCT_ITEM_AS_SALE A,
             CRMV2.ACCT_ITEM         B,
             CRMV2.PAYMENT           C,
             CRMV2.BILL              D
       WHERE B.ACCT_ITEM_CODE = A.ACCT_ITEM_ID
         AND B.BILL_ID = C.BILL_ID
         AND C.BILL_ID = D.BILL_ID;

    -- 合约计划中终端款算税接口表(竣工的)
    INSERT INTO VAT_CONTRACT
      (CUST_ORDER_ID,
       PROD_OFFER_INST_ID,
       ACCT_ITEM_TYPE_ID,
       COST_PRICE,
       REAL_AMOUNT,
       TAXABLE_AMOUNT,
       TAX_RATE,
       TAX,
       AFTER_TAX,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       STAFF_ID,
       ORG_ID,
       CREATE_DATE)
      SELECT A.CUST_ORDER_ID,
             A.PROD_OFFER_INST_ID,
             A.ACCT_ITEM_TYPE_ID,
             A.COST_PRICE,
             A.REAL_AMOUNT,
             A.TAXABLE_AMOUNT,
             A.TAX_RATE,
             A.TAX,
             A.AFTER_TAX,
             A.CUST_ORDER_ID,
             DECODE(B.STATUS_CD, '5JB', '1', '2') FEE_FLAG,
             D.PAYMENT_DATE,
             C.PAYMENT_METHOD_CD PAYMENT_METHOD,
             A.CREATE_STAFF,
             A.CREATE_ORG,
             (SELECT T.ACCEPT_TIME
                FROM CRMV2.CUSTOMER_ORDER_HIS T
               WHERE T.CUST_ORDER_ID = A.CUST_ORDER_ID
                 AND ROWNUM <= 1) CREATE_DATE
        FROM CRMV2.ACCT_ITEM_AS_SALE A,
             CRMV2.ACCT_ITEM_HIS     B,
             CRMV2.PAYMENT           C,
             CRMV2.BILL              D
       WHERE B.ACCT_ITEM_CODE = A.ACCT_ITEM_ID
         AND B.BILL_ID = C.BILL_ID
         AND C.BILL_ID = D.BILL_ID;
    COMMIT;

    -- 先清除数据
    EXECUTE IMMEDIATE 'TRUNCATE TABLE VAT_CARD_FOR_FREE';

    -- 赠送全业务电信卡算税接口表
    INSERT INTO VAT_CARD_FOR_FREE
      (ACCT_ITEM_TYPE_ID,
       SPEC_AMOUNT,
       AMOUNT,
       TAX_RATE,
       TAX,
       CUST_ORDER_ID,
       PAYMENT_ID,
       FEE_FLAG,
       PAYMENT_DATE,
       PAYMENT_METHOD,
       STAFF_ID,
       ORG_ID,
       CREATE_DATE)
      SELECT T.ACCT_ITEM_TYPE_ID ACCT_ITEM_TYPE_ID,
             T.SPEC_AMOUNT SPEC_AMOUNT,
             SUM(T.AMOUNT) AMOUNT,
             T.TAX_RATE TAX_RATE,
             SUM(T.TAX) TAX,
             T.CUST_ORDER_ID CUST_ORDER_ID,
             T.PAYMENT_ID PAYMENT_ID,
             DECODE(T.FEE_FLAG, '70A', 1, 2) FEE_FLAG,
             T.PAYMENT_DATE PAYMENT_DATE,
             T.PAYMENT_METHOD PAYMENT_METHOD,
             T.STAFF_ID STAFF_ID,
             T.ORG_ID ORG_ID,
             T.CREA_DATE CREATE_DATE
        FROM (SELECT F.ACCT_ITEM_TYPE_ID,
                     F.AMOUNT SPEC_AMOUNT,
                     G.AMOUNT AMOUNT,
                     NVL(F.TAX_RATE, 0) / 100 TAX_RATE,
                     F.AMOUNT / 100 / (1 + NVL(F.TAX_RATE, 0) / 100) *
                     NVL(F.TAX_RATE, 0) / 100 TAX,
                     A.ORDER_ID CUST_ORDER_ID,
                     A.ORDER_ID PAYMENT_ID,
                     A.PAYED_STATE FEE_FLAG,
                     A.CREA_DATE PAYMENT_DATE,
                     G.PAYMENT_METHOD_CD PAYMENT_METHOD,
                     A.STAFF_ID STAFF_ID,
                     A.TEAM_ID ORG_ID,
                     A.CREA_DATE
                FROM CRMV2.MKT_RESO_ORDER      A,
                     CRMV1.MKT_RESO_ORDER_ITEM B,
                     CRMV2.MKT_RESOURCE        C,
                     CRMV2.ACCT_ITEM_HIS       F,
                     CRMV2.PAYMENT             G
               WHERE A.ORDER_TYPE = '2'
                 AND A.ORDER_REASON = '801'
                 AND A.PAYED_STATE = '70A'
                 AND A.CREA_DATE > TO_DATE('20140601', 'YYYYMMDD') -- 2014年6月1日之后的数据
                 AND A.ORDER_ID = B.ORDER_ID
                 AND B.MKT_RESO_SPEC_ID = C.MKT_RES_ID
                 AND C.MKT_RES_NAME LIKE '%全业务充值卡%'
                 AND B.SINGLE_PRICE = 0
                 AND F.CUST_SO_NUMBER = A.ORDER_NUMBER
                 AND F.MKT_RES_ID = B.MKT_RESO_SPEC_ID
                 AND F.SOURCE = 'MATERIAL'
                 AND F.STATUS_CD IN ('5JB', '5JC')
                 AND G.BILL_ID = F.BILL_ID
                 AND G.AMOUNT = 0) T
       WHERE T.ORG_ID NOT IN (SELECT ID FROM NX_DLS)
         AND T.STAFF_ID IS NOT NULL
       GROUP BY T.ACCT_ITEM_TYPE_ID,
                T.SPEC_AMOUNT,
                T.CUST_ORDER_ID,
                T.PAYMENT_ID,
                T.FEE_FLAG,
                T.PAYMENT_DATE,
                T.PAYMENT_METHOD,
                T.STAFF_ID,
                T.ORG_ID,
                T.TAX_RATE,
                T.CREA_DATE;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      V_FLAG := SQLERRM;
  END;

  PROCEDURE PROC_NX_CRM_POINT_EXCHANGE(V_FLAG OUT VARCHAR2) IS

  BEGIN
    -- 先清除临时表的数据
    EXECUTE IMMEDIATE 'TRUNCATE TABLE TMP_POINT_EXCHANGE_DETAIL';

    -- 去积分兑换记录与积分规则一对一关系（若积分兑换多个积分规则，则随机取一个一对一）
    INSERT INTO TMP_POINT_EXCHANGE_DETAIL
      (POINT_EXCHANGE_DETAIL_ID,
       POINT_SERVICE_REC_ID,
       RULE_ID,
       EXCHANGE_TYPE,
       TAX_RATE)
      SELECT PD.POINT_EXCHANGE_DETAIL_ID,
             PD.POINT_SERVICE_REC_ID,
             PR.RULE_ID,
             PR.EXCHANGE_TYPE,
             PR.TAX_RATE
        FROM CRMV2.POINT_EXCHANGE_DETAIL PD, CRMV2.POINT_RULE PR
       WHERE PD.RULE_ID = PR.RULE_ID
         AND PD.POINT_EXCHANGE_DETAIL_ID IN
             (SELECT M.POINT_EXCHANGE_DETAIL_ID
                FROM CRMV2.POINT_EXCHANGE_DETAIL M
               WHERE M.POINT_SERVICE_REC_ID = PD.POINT_SERVICE_REC_ID
                 AND ROWNUM <= 1);
    COMMIT;

    -- 先清除本月的数据
    DELETE FROM NX_CRM_POINT_EXCHANGE A
     WHERE TRUNC(A.CREATE_DATE, 'MM') = TRUNC(SYSDATE - 1, 'MM');
    COMMIT;

    -- 积分兑换（实物和活动）和返销
    INSERT INTO NX_CRM_POINT_EXCHANGE
      (SERIES,
       AMOUNT,
       DISC_OFFER_TYPE,
       FEE_FLAG,
       CREATE_DATE,
       STAFF_ID,
       ORG_ID,
       EXCHANGE_TYPE,
       TAX,
       TAX_RATE,
       AFTER_TAX,
       POINT_FLAG,
       REPORT_MODE)
      SELECT T.EXT_SERIES,
             T.SERVICE_POINT,
             T.POINT_SERVICE_TYPE,
             DECODE(T.POINT_SERVICE_TYPE, '10', '1', '11', '1', '15', '2') FEE_FLAG,
             T.CREATE_DATE,
             T.CREATE_STAFF,
             T.EXT_ORG_ID,
             T.EXCHANGE_TYPE,
             TO_NUMBER(TRIM(TO_CHAR(DECODE(T.POINT_FLAG,
                                           '1',
                                           T.SERVICE_POINT / 100 /
                                           (1 + T.TAX_RATE) * T.TAX_RATE,
                                           '2',
                                           0),
                                    '99999999999999.99'))) TAX, -- 税金
             TO_NUMBER(TRIM(TO_CHAR(DECODE(T.POINT_FLAG,
                                           '1',
                                           T.TAX_RATE,
                                           '2',
                                           0),
                                    '99999999999999.99'))) TAX_RATE, -- 税率
             T.SERVICE_POINT / 100 -
             TO_NUMBER(TRIM(TO_CHAR(DECODE(T.POINT_FLAG,
                                           '1',
                                           T.SERVICE_POINT / 100 /
                                           (1 + T.TAX_RATE) * T.TAX_RATE,
                                           '2',
                                           0),
                                    '99999999999999.99'))) AFTER_TAX, -- 税后金额
             T.POINT_FLAG POINT_FLAG, -- 新老积分标识：1-新积分、2-旧积分
             DECODE(T.RULE_ID,
                    NULL,
                    NULL,
                    DECODE(T.TAX_RATE, 0.17, '1', '2')) REPORT_MODE -- 集团的是空，税率是17%的是1-属地申报，其它为2-汇总申报
        FROM (SELECT A.EXT_SERIES,
                     -D.POINT_CHANGE SERVICE_POINT,
                     A.POINT_SERVICE_TYPE,
                     A.CREATE_DATE,
                     A.CREATE_STAFF,
                     A.EXT_ORG_ID,
                     B.RULE_ID,
                     B.EXCHANGE_TYPE,
                     (CASE
                       WHEN E.EXT_ACCT_CYCLE >=
                            TO_CHAR(ADD_MONTHS(SYSDATE - 1, -1), 'YYYYMM') AND
                            E.EXT_ACCT_CYCLE != '201405' THEN
                        '1'
                       ELSE
                        '2'
                     END) POINT_FLAG,
                     NVL(B.TAX_RATE, 0) TAX_RATE
                FROM CRMV2.POINT_SERVICE_REC        A,
                     TMP_POINT_EXCHANGE_DETAIL      B, -- 临时表
                     CRMV2.POINT_ACCT_CHNG_REC      C,
                     CRMV2.POINT_ACCT_BALA_CHNG_REC D,
                     CRMV2.POINT_ACCT_BALA          E
               WHERE A.POINT_SERVICE_TYPE IN ('10', '11', '15') -- 兑换类型：10-兑换、11-活动、15-返销
                 AND A.CREATE_STAFF NOT IN ('68840', '53060')
                 AND A.POINT_SERVICE_REC_ID = B.POINT_SERVICE_REC_ID(+)
                 AND TRUNC(A.CREATE_DATE, 'MM') = TRUNC(SYSDATE - 1, 'MM')
                 AND C.POINT_SERVICE_REC_ID = A.POINT_SERVICE_REC_ID
                 AND D.POINT_ACCT_CHNG_REC_ID = C.POINT_ACCT_CHNG_REC_ID
                 AND E.POINT_ACCT_BALA_ID = D.POINT_ACCT_BALA_ID) T;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      V_FLAG := SQLERRM;
  END;

  PROCEDURE PROC_NX_CRM_COL_DEF(V_FLAG OUT VARCHAR2) IS

  BEGIN
    -- 先清除数据
    EXECUTE IMMEDIATE 'TRUNCATE TABLE NX_CRM_COL_DEF';

    -- 实物终端参数
    INSERT INTO NX_CRM_COL_DEF
      (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
      SELECT 'PROD_ID', MR.MKT_RES_ID, MR.MKT_RES_NAME, '0', 3
        FROM CRMV2.MKT_RESOURCE MR
       WHERE MR.STATUS_CD = '1000';
    -- 实物终端仓库
    INSERT INTO NX_CRM_COL_DEF
      (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
      SELECT 'STORE', SS.STORE_ID, SS.STORE_NAME, '0', 3
        FROM CRMV1.MKT_RESO_STORE SS
       WHERE SS.STATE IN ('70A', '70N');
    -- ACCT_ITEM_TYPE_ID 账目项
    INSERT INTO NX_CRM_COL_DEF
      (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
      SELECT 'ACCT_ITEM_TYPE_ID',
             AIT.ACCT_ITEM_TYPE_ID,
             AIT.ACCT_ITEM_NAME,
             '0',
             3
        FROM CRMV2.ACCT_ITEM_TYPE AIT
       WHERE AIT.STATUS_CD = '1000';
    -- 客户战略分群
    INSERT INTO NX_CRM_COL_DEF
      (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
      SELECT 'CUST_GRP_TYPE', AV.ATTR_VALUE, AV.ATTR_DESC, '0', 3
        FROM CRMV2.ATTR_VALUE AV
       WHERE AV.ATTR_ID = 68;
    -- 客户战略分群子群
    INSERT INTO NX_CRM_COL_DEF
      (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
      SELECT 'CUST_SUN_TYPE', AV.ATTR_VALUE, AV.ATTR_DESC, '0', 3
        FROM CRMV2.ATTR_VALUE AV
       WHERE AV.ATTR_ID = 46;
    -- 付费方式
    INSERT INTO NX_CRM_COL_DEF
      (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
      SELECT 'PAYMENT_METHOD',
             PM.PAYMENT_METHOD_ID,
             PM.PAYMENT_METHOD_NAME,
             '0',
             3
        FROM CRMV2.PAYMENT_METHOD PM
       WHERE PM.STATUS_CD = '1000';
    -- 基础销售品
    INSERT INTO NX_CRM_COL_DEF
      (COLUMN_NAME, COLUMN_VALUE, VALUE_NAME, FLAG, SYSTEM_ID)
      SELECT 'PROD_ID', PO.PROD_OFFER_ID, PO.PROD_OFFER_NAME, '0', 3
        FROM CRMV2.PROD_OFFER PO
       WHERE PO.STATUS_CD = '1000'
         AND PO.OFFER_TYPE = '10';
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      V_FLAG := SQLERRM;
  END;

  PROCEDURE PROC_NX_CRM_STAFF_ORG(V_FLAG OUT VARCHAR2) IS

  BEGIN
    -- 工号与团队架构资料表
    EXECUTE IMMEDIATE 'TRUNCATE TABLE NX_CRM_STAFF_ORG';
    INSERT INTO NX_CRM_STAFF_ORG
      (STAFF_ID,
       STAFF_NAME,
       STAFF_CODE,
       ORG_ID_1,
       ORG_NAME_1,
       ORG_ID_2,
       ORG_NAME_2,
       ORG_ID_3,
       ORG_NAME_3,
       ORG_ID_4,
       ORG_NAME_4,
       ORG_ID_5,
       ORG_NAME_5,
       ORG_ID_6,
       ORG_NAME_6,
       CUR_GRADE,
       SYSTEM_ID)
      SELECT C.STAFF_ID STAFF_ID,
             D.PARTY_NAME STAFF_NAME,
             C.STAFF_CODE STAFF_NO,
             (SELECT TE4.ORG_ID
                FROM CRMV2.ORGANIZATION TE4
               WHERE TE4.ORG_ID =
                     (SELECT TE3.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE3
                       WHERE TE3.ORG_ID =
                             (SELECT TE2.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE2
                               WHERE TE2.ORG_ID =
                                     (SELECT TE1.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE1
                                       WHERE TE1.ORG_ID =
                                             (SELECT TE.PARENT_ORG_ID
                                                FROM CRMV2.ORGANIZATION TE
                                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))))) TEAM_1_ID,
             (SELECT TE4.ORG_NAME
                FROM CRMV2.ORGANIZATION TE4
               WHERE TE4.ORG_ID =
                     (SELECT TE3.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE3
                       WHERE TE3.ORG_ID =
                             (SELECT TE2.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE2
                               WHERE TE2.ORG_ID =
                                     (SELECT TE1.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE1
                                       WHERE TE1.ORG_ID =
                                             (SELECT TE.PARENT_ORG_ID
                                                FROM CRMV2.ORGANIZATION TE
                                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))))) TEAM_1_NAME,
             (SELECT TE3.ORG_ID
                FROM CRMV2.ORGANIZATION TE3
               WHERE TE3.ORG_ID =
                     (SELECT TE2.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE2
                       WHERE TE2.ORG_ID =
                             (SELECT TE1.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE1
                               WHERE TE1.ORG_ID =
                                     (SELECT TE.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE
                                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)))) TEAM_2_ID,
             (SELECT TE3.ORG_NAME
                FROM CRMV2.ORGANIZATION TE3
               WHERE TE3.ORG_ID =
                     (SELECT TE2.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE2
                       WHERE TE2.ORG_ID =
                             (SELECT TE1.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE1
                               WHERE TE1.ORG_ID =
                                     (SELECT TE.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE
                                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)))) TEAM_2_NAME,
             (SELECT TE2.ORG_ID
                FROM CRMV2.ORGANIZATION TE2
               WHERE TE2.ORG_ID =
                     (SELECT TE1.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE1
                       WHERE TE1.ORG_ID =
                             (SELECT TE.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE
                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))) TEAM_3_ID,
             (SELECT TE2.ORG_NAME
                FROM CRMV2.ORGANIZATION TE2
               WHERE TE2.ORG_ID =
                     (SELECT TE1.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE1
                       WHERE TE1.ORG_ID =
                             (SELECT TE.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE
                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))) TEAM_3_NAME,
             (SELECT TE1.ORG_ID
                FROM CRMV2.ORGANIZATION TE1
               WHERE TE1.ORG_ID =
                     (SELECT TE.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE
                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)) TEAM_4_ID,
             (SELECT TE1.ORG_NAME
                FROM CRMV2.ORGANIZATION TE1
               WHERE TE1.ORG_ID =
                     (SELECT TE.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE
                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)) TEAM_5_NAME,
             (SELECT TE.ORG_ID
                FROM CRMV2.ORGANIZATION TE
               WHERE TE.ORG_ID = A.PARENT_ORG_ID) TEAM_5_ID,
             (SELECT TE.ORG_NAME
                FROM CRMV2.ORGANIZATION TE
               WHERE TE.ORG_ID = A.PARENT_ORG_ID) TEAM_5_NAME,
             A.ORG_ID TEAM_6_ID,
             A.TEAM_NAME TEAM_6_NAME,
             A.TT CUR_GRADE,
             3 SYSTEM_ID
        FROM (SELECT ORG_ID,
                     ORG_NAME      TEAM_NAME,
                     PARENT_ORG_ID,
                     AREA_ID,
                     LEVEL         TT
                FROM CRMV2.ORGANIZATION
               START WITH ORG_ID = 1001
              CONNECT BY PRIOR ORG_ID = PARENT_ORG_ID) A,
             CRMV2.STAFF_POSITION B,
             CRMV2.SYSTEM_USER C,
             CRMV2.PARTY D,
             CRMV2.STAFF G,
             CRMV2.POSITION H
       WHERE A.ORG_ID = B.ORG_ID
         AND B.STAFF_ID = C.STAFF_ID
         AND B.STAFF_ID = G.STAFF_ID
         AND H.POSITION_ID = B.POSITION_ID
         AND G.PARTY_ID = D.PARTY_ID(+)
            /*
            AND (EXISTS
                 (SELECT 'X'
                    FROM CRMV2.STAFF_POSITION X, CRMV2.ORG_ROLE_POSITION_REL Y
                   WHERE Y.STAFF_POSITION_A_ID = B.STAFF_POSITION_ID
                     AND Y.STAFF_POSITION_Z_ID = X.STAFF_POSITION_ID) OR EXISTS
                 (SELECT 'X'
                    FROM CRMV2.STAFF_LIMIT P, CRMV2.PRIVILEGE Q
                   WHERE P.SYSTEM_USER_ID = B.STAFF_ID
                     AND P.ORG_ID = B.ORG_ID
                     AND P.PRIVILEGE_ID = Q.PRIVILEGE_ID
                     AND Q.PRIVILEGE_TYPE = 1100))
            */
         AND B.STATUS_CD = '1000'
         AND C.STATUS_CD = '1000'
         AND B.ORG_ID NOT IN ('18', '255', '256', '13939', '110040');
    COMMIT;
    -- 补充工号
    INSERT INTO NX_CRM_STAFF_ORG
      (STAFF_ID,
       STAFF_NAME,
       STAFF_CODE,
       ORG_ID_1,
       ORG_NAME_1,
       ORG_ID_2,
       ORG_NAME_2,
       ORG_ID_3,
       ORG_NAME_3,
       ORG_ID_4,
       ORG_NAME_4,
       ORG_ID_5,
       ORG_NAME_5,
       ORG_ID_6,
       ORG_NAME_6,
       CUR_GRADE,
       SYSTEM_ID)
      SELECT C.STAFF_ID STAFF_ID,
             D.PARTY_NAME STAFF_NAME,
             C.STAFF_CODE STAFF_NO,
             (SELECT TE4.ORG_ID
                FROM CRMV2.ORGANIZATION TE4
               WHERE TE4.ORG_ID =
                     (SELECT TE3.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE3
                       WHERE TE3.ORG_ID =
                             (SELECT TE2.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE2
                               WHERE TE2.ORG_ID =
                                     (SELECT TE1.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE1
                                       WHERE TE1.ORG_ID =
                                             (SELECT TE.PARENT_ORG_ID
                                                FROM CRMV2.ORGANIZATION TE
                                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))))) TEAM_1_ID,
             (SELECT TE4.ORG_NAME
                FROM CRMV2.ORGANIZATION TE4
               WHERE TE4.ORG_ID =
                     (SELECT TE3.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE3
                       WHERE TE3.ORG_ID =
                             (SELECT TE2.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE2
                               WHERE TE2.ORG_ID =
                                     (SELECT TE1.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE1
                                       WHERE TE1.ORG_ID =
                                             (SELECT TE.PARENT_ORG_ID
                                                FROM CRMV2.ORGANIZATION TE
                                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))))) TEAM_1_NAME,
             (SELECT TE3.ORG_ID
                FROM CRMV2.ORGANIZATION TE3
               WHERE TE3.ORG_ID =
                     (SELECT TE2.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE2
                       WHERE TE2.ORG_ID =
                             (SELECT TE1.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE1
                               WHERE TE1.ORG_ID =
                                     (SELECT TE.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE
                                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)))) TEAM_2_ID,
             (SELECT TE3.ORG_NAME
                FROM CRMV2.ORGANIZATION TE3
               WHERE TE3.ORG_ID =
                     (SELECT TE2.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE2
                       WHERE TE2.ORG_ID =
                             (SELECT TE1.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE1
                               WHERE TE1.ORG_ID =
                                     (SELECT TE.PARENT_ORG_ID
                                        FROM CRMV2.ORGANIZATION TE
                                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)))) TEAM_2_NAME,
             (SELECT TE2.ORG_ID
                FROM CRMV2.ORGANIZATION TE2
               WHERE TE2.ORG_ID =
                     (SELECT TE1.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE1
                       WHERE TE1.ORG_ID =
                             (SELECT TE.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE
                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))) TEAM_3_ID,
             (SELECT TE2.ORG_NAME
                FROM CRMV2.ORGANIZATION TE2
               WHERE TE2.ORG_ID =
                     (SELECT TE1.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE1
                       WHERE TE1.ORG_ID =
                             (SELECT TE.PARENT_ORG_ID
                                FROM CRMV2.ORGANIZATION TE
                               WHERE TE.ORG_ID = A.PARENT_ORG_ID))) TEAM_3_NAME,
             (SELECT TE1.ORG_ID
                FROM CRMV2.ORGANIZATION TE1
               WHERE TE1.ORG_ID =
                     (SELECT TE.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE
                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)) TEAM_4_ID,
             (SELECT TE1.ORG_NAME
                FROM CRMV2.ORGANIZATION TE1
               WHERE TE1.ORG_ID =
                     (SELECT TE.PARENT_ORG_ID
                        FROM CRMV2.ORGANIZATION TE
                       WHERE TE.ORG_ID = A.PARENT_ORG_ID)) TEAM_5_NAME,
             (SELECT TE.ORG_ID
                FROM CRMV2.ORGANIZATION TE
               WHERE TE.ORG_ID = A.PARENT_ORG_ID) TEAM_5_ID,
             (SELECT TE.ORG_NAME
                FROM CRMV2.ORGANIZATION TE
               WHERE TE.ORG_ID = A.PARENT_ORG_ID) TEAM_5_NAME,
             A.ORG_ID TEAM_6_ID,
             A.TEAM_NAME TEAM_6_NAME,
             A.TT CUR_GRADE,
             3 SYSTEM_ID
        FROM (SELECT ORG_ID,
                     ORG_NAME      TEAM_NAME,
                     PARENT_ORG_ID,
                     AREA_ID,
                     LEVEL         TT
                FROM CRMV2.ORGANIZATION
               START WITH ORG_ID = 1001
              CONNECT BY PRIOR ORG_ID = PARENT_ORG_ID) A,
             CRMV2.STAFF_POSITION B,
             CRMV2.SYSTEM_USER C,
             CRMV2.PARTY D,
             CRMV2.STAFF E
       WHERE A.ORG_ID = B.ORG_ID
         AND B.STAFF_ID = C.STAFF_ID
         AND B.STAFF_ID = E.STAFF_ID
         AND E.PARTY_ID = D.PARTY_ID(+)
         AND B.STATUS_CD = '1000'
         AND C.STATUS_CD = '1000'
         AND NOT EXISTS (SELECT 'X'
                FROM NX_CRM_STAFF_ORG X
               WHERE X.STAFF_ID = B.STAFF_ID);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM);
      V_FLAG := SQLERRM;
  END;

  PROCEDURE PROC_TASK_INSERT(IO_DEAL_BATCH  VARCHAR2, --任务批次
                             IO_TASK_CLASS  VARCHAR2, --过程代码
                             IO_STEP        VARCHAR2, --总步骤
                             IO_CYCLE_TYPE  VARCHAR2, --周期类型
                             IO_TASK_CYCLE  VARCHAR2, --任务周期  OUT
                             IO_HANDLE_STEP VARCHAR2, --任务步骤  OUT
                             IO_FLAG        VARCHAR2) IS --处理标志  OUT

  BEGIN
    NULL;
  END;

END PKG_YSJH;
/
