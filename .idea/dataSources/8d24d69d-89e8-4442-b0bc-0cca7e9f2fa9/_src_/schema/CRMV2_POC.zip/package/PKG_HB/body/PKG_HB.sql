CREATE PACKAGE BODY           PKG_HB IS
  /*------------------------------------------------------------------------------------------------
  套餐续缴或新装充值开通调用此过程插入接口表，生成申请单
  Author  : g.caijx
  Created : 2012-02-07
  */
  PROCEDURE PROC_PREFER_EXTEND(I_PROD_OFFER_INST_ID IN NUMBER, --续费对应的销售品实例标识
                               O_ERR_CODE           OUT NUMBER, --错误编码（0--成功 1--失败）
                               O_ERR_MSG            OUT VARCHAR2) --错误信息
   IS
    V_COUNT        NUMBER;
    V_PROD_INST_ID NUMBER;

    V_PRODUCT_CODE    INTF_SO_SERV.PRODUCT_CODE%TYPE;
    V_ACC_NBR         INTF_SO_SERV.ACC_NBR%TYPE;
    V_AREA_ID         INTF_SO_SERV.AREA_ID%TYPE;
    V_AREA_CODE       INTF_SO_SERV.AREA_CODE%TYPE;
    V_INTF_SO_SERV_ID INTF_SO_SERV.INTF_SO_SERV_ID%TYPE;

    V_BUSI_CODE            INTF_SO_BUSI.BUSI_CODE%TYPE;
    V_INTF_SO_BUSI_ID      INTF_SO_BUSI.INTF_SO_BUSI_ID%TYPE;
    V_EXT_OFFER_NBR_A      INTF_SO_BUSI.BUSI_CODE%TYPE; --A端销售品的EXT_OFFER_NBR
    V_PROD_OFFER_INST_ID_A INTF_SO_BUSI.OBJ_ID%TYPE; --A端销售品的PROD_OFFER_INST_ID

    V_INTF_SO_ATTR_ID INTF_SO_ATTR.INTF_SO_ATTR_ID%TYPE;
    V_EXP_MONTH       INTF_SO_ATTR.ATTR_VALUE%TYPE;
    V_EXP_DATE        INTF_SO_ATTR.ATTR_VALUE%TYPE;

    V_CHANNEL_NBR        INTF_SO_SERV.CHANNEL_NBR%TYPE;
    V_SERVICE_OFFER_CODE INTF_SO_BUSI.SERVICE_OFFER_CODE%TYPE;

    V_T01_PROD_OFFER_INST_ID  PROD_OFFER_INST.PROD_OFFER_INST_ID%TYPE;
    V_ACC_CNT                 NUMBER;
    VO_PROD_OFFER_ID PROD_OFFER.PROD_OFFER_ID%TYPE;
    BILLCZKT_OFFER_FLAG NUMBER;
  BEGIN
    O_ERR_CODE           := 0;
    V_CHANNEL_NBR        := '600105B003'; --[宽带年缴续缴-计费]
    V_SERVICE_OFFER_CODE := '3020400000'; --[续订]

    --判断I_PROD_OFFER_INST_ID 是否存在
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PROD_OFFER_INST POI
     WHERE POI.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID;
    IF V_COUNT = 0 THEN
      O_ERR_MSG  := '销售品实例不存在!';
      O_ERR_CODE := 1;
      RETURN;
    END IF;

    --根据销售品实例查接入类产品实例
    BEGIN
      /*SELECT R.PROD_INST_ID
       INTO V_PROD_INST_ID
       FROM OFFER_PROD_INST_REL R
       JOIN PROD_INST PI ON PI.PROD_INST_ID = R.PROD_INST_ID
       JOIN PRODUCT P ON P.PRODUCT_ID = PI.PRODUCT_ID
      WHERE R.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID
        AND P.PROD_FUNC_TYPE = '101'
        AND ROWNUM < 2;*/
      SELECT E.PROD_INST_ID, C.PROD_OFFER_INST_ID, D.EXT_OFFER_NBR
        INTO V_PROD_INST_ID, V_PROD_OFFER_INST_ID_A, V_EXT_OFFER_NBR_A
        FROM PROD_OFFER_INST     A, --年缴套餐
             PROD_OFFER_INST_REL B,
             PROD_OFFER_INST     C, --e家套餐或有线宽带等
             PROD_OFFER          D,
             OFFER_PROD_INST_REL E,
             PROD_INST           F,
             PRODUCT             G
       WHERE A.PROD_OFFER_INST_ID = B.RELATED_PROD_OFFER_INST_ID
         AND B.RELA_PROD_OFFER_INST_ID = C.PROD_OFFER_INST_ID
         AND C.PROD_OFFER_ID = D.PROD_OFFER_ID
         AND C.PROD_OFFER_INST_ID = E.PROD_OFFER_INST_ID
         AND E.PROD_INST_ID = F.PROD_INST_ID
         AND F.PRODUCT_ID = G.PRODUCT_ID
         AND A.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID
         AND G.PROD_FUNC_TYPE = '101' --随机一笔e家产品
         AND F.STATUS_CD <> '110000'
         AND C.STATUS_CD <> '110000'
         AND ROWNUM < 2;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_MSG  := '根据销售品实例查不到接入类产品实例';
        O_ERR_CODE := 1;
        RETURN;
    END;

    /*--获取A端销售品实例
    BEGIN
      SELECT PO.EXT_OFFER_NBR, POI.PROD_OFFER_INST_ID
        INTO V_EXT_OFFER_NBR_A, V_PROD_OFFER_INST_ID_A
        FROM PROD_OFFER_INST POI
        JOIN PROD_OFFER PO ON PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
       WHERE POI.PROD_OFFER_INST_ID =
             (SELECT R.RELA_PROD_OFFER_INST_ID
                FROM PROD_OFFER_INST_REL R
               WHERE R.RELATED_PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID
                 AND ROWNUM < 2);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_MSG  := '查不到A端销售品';
        O_ERR_CODE := 1;
        RETURN;
    END;*/

    --1、查询产品实例、业务功能编码查询INTF_SO_SERV判断是否存在待处理的记录
    /*SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_SO_SERV S
     WHERE S.PROD_INST_ID = V_PROD_INST_ID
       AND S.CHANNEL_NBR = V_CHANNEL_NBR
       AND S.STATE NOT IN ('70C','70D');*/
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_SO_SERV S
      JOIN INTF_SO_BUSI B
        ON B.INTF_SO_SERV_ID = S.INTF_SO_SERV_ID
     WHERE B.OBJ_ID = I_PROD_OFFER_INST_ID
       AND B.BUSI_TYPE = '1200'
       AND S.CHANNEL_NBR = V_CHANNEL_NBR
       AND S.STATE NOT IN ('70C', '70D')
       AND ROWNUM = 1;
    IF V_COUNT > 0 THEN
      O_ERR_MSG  := '已有续费在途申请,不能发起续费';
      O_ERR_CODE := 1;
      RETURN;
    END IF;

    --2、查询产品产品实例是否存在预拆机属性
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PROD_INST_ATTR A
     WHERE A.PROD_INST_ID = V_PROD_INST_ID
       AND A.ATTR_ID = 800000250; --800000250: '预拆机'

    IF V_COUNT > 0 THEN
      O_ERR_MSG  := '已办理拆机停,不能发起续费';
      O_ERR_CODE := 1;
      RETURN;
    END IF;

    --3、查询是否存在拆机在途单
    SELECT COUNT(*)
      INTO V_COUNT
      FROM ORDER_ITEM A
     WHERE A.CLASS_ID = 4
       AND A.ORDER_ITEM_OBJ_ID = V_PROD_INST_ID
       AND STATUS_CD <> '300000'
       AND STATUS_CD <> '401300'
       AND A.SERVICE_OFFER_ID = 101; --101: 拆机 4020100000

    IF V_COUNT > 0 THEN
      O_ERR_MSG  := '有拆机在途单,不能发起续费';
      O_ERR_CODE := 1;
      RETURN;
    END IF;

    --4、查询是否存在续订或退订在途单
    SELECT COUNT(*)
      INTO V_COUNT
      FROM ORDER_ITEM A
     WHERE A.CLASS_ID = 6
       AND A.ORDER_ITEM_OBJ_ID = I_PROD_OFFER_INST_ID
       AND STATUS_CD <> '300000'
       AND STATUS_CD <> '401300'
       AND A.SERVICE_OFFER_ID IN (501, 502); --502: 续订 3020400000; 501: 退订  3030100000

    IF V_COUNT > 0 THEN
      O_ERR_MSG  := '有续订或退订在途单,不能发起续费';
      O_ERR_CODE := 1;
      RETURN;
    END IF;
    --查询销售品A是否存在退订[服务提供编码3030100000]在途单
    SELECT COUNT(*)
      INTO V_COUNT
      FROM ORDER_ITEM A
     WHERE A.CLASS_ID = 6
       AND A.ORDER_ITEM_OBJ_ID = V_PROD_OFFER_INST_ID_A
       AND STATUS_CD <> '300000'
       AND STATUS_CD <> '401300'
       AND A.SERVICE_OFFER_ID = 501; --501: 退订  3030100000

    IF V_COUNT > 0 THEN
      O_ERR_MSG  := 'A端销售品存在退订在途单,不能发起续费';
      O_ERR_CODE := 1;
      RETURN;
    END IF;


    --TTP21131 BEGIN
    --5 多接入类销售品不做处理,退出
    BEGIN
      SELECT POI.PROD_OFFER_INST_ID INTO V_T01_PROD_OFFER_INST_ID
        FROM PROD_OFFER PO,
             PROD_OFFER_INST POI,
             OFFER_PROD_INST_REL OPIR
       WHERE PO.OFFER_SUB_TYPE = 'T01'
         AND POI.STATUS_CD <> '1100'
         AND PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
         AND OPIR.STATUS_CD <> '1100'
         AND POI.PROD_OFFER_INST_ID = OPIR.PROD_OFFER_INST_ID
         AND OPIR.PROD_INST_ID = V_PROD_INST_ID;
    EXCEPTION
        WHEN NO_DATA_FOUND  THEN
            BEGIN
                SELECT POI.PROD_OFFER_INST_ID INTO V_T01_PROD_OFFER_INST_ID
                  FROM PROD_OFFER PO,
                       PROD_OFFER_INST POI,
                       PROD_OFFER_INST_REL POIR
                 WHERE PO.OFFER_SUB_TYPE = 'T01'
                   AND POI.STATUS_CD <> '1100'
                   AND PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
                   AND POIR.STATUS_CD <> '1100'
                   AND POI.PROD_OFFER_INST_ID = POIR.RELA_PROD_OFFER_INST_ID
                   AND POIR.RELATED_PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID ;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                O_ERR_MSG  := '找不到T01销售品！';
                O_ERR_CODE := 1;
                RETURN;
              WHEN OTHERS THEN
                O_ERR_MSG  := '找T01销售品出错！';
                O_ERR_CODE := 1;
                RETURN;
            END;
        WHEN OTHERS THEN
            O_ERR_MSG  := '找T01销售品出错！';
            O_ERR_CODE := 1;
            RETURN;
     END;

    SELECT COUNT(1) INTO V_ACC_CNT
      FROM PRODUCT   P,
           PROD_INST PI,
           OFFER_PROD_INST_REL OPIR
     WHERE P.PROD_FUNC_TYPE = 101
       AND PI.PRODUCT_ID = P.PRODUCT_ID
       AND PI.STATUS_CD <> '110000'
       AND OPIR.PROD_INST_ID = PI.PROD_INST_ID
       AND OPIR.STATUS_CD <> '1100'
       AND OPIR.PROD_OFFER_INST_ID = V_T01_PROD_OFFER_INST_ID  ;

  /*  IF V_COUNT > 1 THEN
      O_ERR_MSG  := '销售品含多个接入类产品,不能发起续费';
      O_ERR_CODE := 1;
      RETURN;
    END IF;  */

    --6 接入类产品如果是停机保号，退出
    SELECT COUNT(1) INTO V_COUNT
      FROM PROD_INST_ATTR
     WHERE STATUS_CD <> '1100'
       AND ATTR_ID = 800000253
       AND PROD_INST_ID = V_PROD_INST_ID;

    IF V_COUNT > 0 AND V_ACC_CNT<= 1 THEN
      O_ERR_MSG  := '对应接入类产品实例处于停机保号状态,不能发起续费';
      O_ERR_CODE := 1;
      RETURN;
    END IF;

    --TTP21131 END

    BEGIN
      --记录标准对象服务INTF_SO_SERV
      SELECT SEQ_INTF_SO_SERV_ID.NEXTVAL INTO V_INTF_SO_SERV_ID FROM DUAL;

      SELECT P.EXT_PROD_ID, PI.ACC_NBR, PI.AREA_ID, PI.AREA_CODE
        INTO V_PRODUCT_CODE, V_ACC_NBR, V_AREA_ID, V_AREA_CODE
        FROM PROD_INST PI
        JOIN PRODUCT P ON P.PRODUCT_ID = PI.PRODUCT_ID
       WHERE PI.PROD_INST_ID = V_PROD_INST_ID;

      INSERT INTO INTF_SO_SERV
        (INTF_SO_SERV_ID,
         ACC_NBR,
         PRODUCT_CODE,
         AREA_ID,
         PROD_INST_ID,
         CHANNEL_NBR,
         AREA_CODE)
      VALUES
        (V_INTF_SO_SERV_ID,
         V_ACC_NBR,
         V_PRODUCT_CODE,
         V_AREA_ID,
         V_PROD_INST_ID,
         V_CHANNEL_NBR, --[宽带年缴续缴-计费]
         V_AREA_CODE);

      --1 记录标准对象业务INTF_SO_BUSI
      SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL INTO V_INTF_SO_BUSI_ID FROM DUAL;

      INSERT INTO INTF_SO_BUSI
        (INTF_SO_BUSI_ID,
         INTF_SO_SERV_ID,
         SERIAL_SEQ,
         BUSI_CODE,
         BUSI_TYPE,
         SERVICE_OFFER_CODE,
         OBJ_ID,
         ACTION_TYPE)
      VALUES
        (V_INTF_SO_BUSI_ID,
         V_INTF_SO_SERV_ID,
         0,
         V_EXT_OFFER_NBR_A,
         '1200',
         V_SERVICE_OFFER_CODE, --[续订]
         V_PROD_OFFER_INST_ID_A,
         'M'); --[更新]

      --2 记录标准对象业务INTF_SO_BUSI
      SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL INTO V_INTF_SO_BUSI_ID FROM DUAL;

      SELECT PO.EXT_OFFER_NBR
        INTO V_BUSI_CODE
        FROM PROD_OFFER_INST POI
        JOIN PROD_OFFER PO ON PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
       WHERE POI.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID;

      INSERT INTO INTF_SO_BUSI
        (INTF_SO_BUSI_ID,
         INTF_SO_SERV_ID,
         SERIAL_SEQ,
         BUSI_CODE,
         BUSI_TYPE,
         SERVICE_OFFER_CODE,
         OBJ_ID,
         ACTION_TYPE)
      VALUES
        (V_INTF_SO_BUSI_ID,
         V_INTF_SO_SERV_ID,
         0,
         V_BUSI_CODE,
         '1200',
         V_SERVICE_OFFER_CODE, --[续订]
         I_PROD_OFFER_INST_ID,
         'M'); --[更新]

      --1 记录标准对象属性INTF_SO_ATTR
      --fangjin(方金) 09:05:39  crm00067315
      --判断下 是那几个可选包的话就不校验这个属性
      select po.prod_offer_id
        into VO_PROD_OFFER_ID
        from prod_offer_inst poi, prod_offer po
       where poi.prod_offer_id = po.prod_offer_id
         and poi.prod_offer_inst_id = I_PROD_OFFER_INST_ID;
      BILLCZKT_OFFER_FLAG :=FUNC_BILLCZKT_OFFER_CHECK(VO_PROD_OFFER_ID);
      if BILLCZKT_OFFER_FLAG =0 then
          SELECT A.ATTR_VALUE
            INTO V_EXP_MONTH
            FROM PROD_OFFER_INST_ATTR A
           WHERE A.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID
             AND A.ATTR_ID = 800001917; --800001917(590001917): 套餐优惠时长（年缴）
         else
           V_EXP_MONTH:=FUNC_BILLCZKT_EXP_MONTH(VO_PROD_OFFER_ID);
         end if;
      SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL INTO V_INTF_SO_ATTR_ID FROM DUAL;
      INSERT INTO INTF_SO_ATTR
        (INTF_SO_ATTR_ID,
         INTF_SO_SERV_ID,
         INTF_SO_BUSI_ID,
         SERIAL_SEQ,
         ATTR_NBR,
         ATTR_VALUE)
      VALUES
        (V_INTF_SO_ATTR_ID,
         V_INTF_SO_SERV_ID,
         V_INTF_SO_BUSI_ID,
         0,
         '590013907', --590013907[套餐续缴时长]
         V_EXP_MONTH);

      --2 记录标准对象属性INTF_SO_ATTR
      SELECT POI.EXP_DATE
        INTO V_EXP_DATE
        FROM PROD_OFFER_INST POI
       WHERE POI.PROD_OFFER_INST_ID = I_PROD_OFFER_INST_ID;

      SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL INTO V_INTF_SO_ATTR_ID FROM DUAL;
      INSERT INTO INTF_SO_ATTR
        (INTF_SO_ATTR_ID,
         INTF_SO_SERV_ID,
         INTF_SO_BUSI_ID,
         SERIAL_SEQ,
         ATTR_NBR,
         ATTR_VALUE)
      VALUES
        (V_INTF_SO_ATTR_ID,
         V_INTF_SO_SERV_ID,
         V_INTF_SO_BUSI_ID,
         0,
         '590004530', --590004530[定价要素：套餐失效时间]
         TO_CHAR(ADD_MONTHS(V_EXP_DATE,V_EXP_MONTH), 'yyyymmdd'));
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_MSG  := SUBSTR(SQLERRM,1,1000);
        O_ERR_CODE := 1;
    END;

  END PROC_PREFER_EXTEND;

  /*------------------------------------------------------------------------------------------------
      短期宽带未续约发起到期停
      Author  : g.caijx
      Created : 2012-03-07
  */
  PROCEDURE PROC_AUTO_BILL_CJT(I_AREA_CODE    IN VARCHAR2, --区号，比如福州0591
                               I_PROD_INST_ID IN VARCHAR2, --接入类产品实例标识
                               O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                               O_ERR_MSG      OUT VARCHAR2, --错误信息
                               O_SERIAL       OUT VARCHAR2) --处理序列号

   IS
    V_COUNT           NUMBER;
    V_PROD_FUNC_TYPE  PRODUCT.PROD_FUNC_TYPE%TYPE;
    V_PRODUCT_CODE    INTF_SO_SERV.PRODUCT_CODE%TYPE;
    V_ACC_NBR         INTF_SO_SERV.ACC_NBR%TYPE;
    V_AREA_ID         INTF_SO_SERV.AREA_ID%TYPE;
    V_INTF_SO_SERV_ID INTF_SO_SERV.INTF_SO_SERV_ID%TYPE;

    V_INTF_SO_BUSI_ID INTF_SO_BUSI.INTF_SO_BUSI_ID%TYPE;
    V_BUSI_CODE       INTF_SO_BUSI.BUSI_CODE%TYPE;

    V_INTF_SO_ATTR_ID INTF_SO_ATTR.INTF_SO_ATTR_ID%TYPE;
  BEGIN
    O_ERR_CODE := '0';

    --查询INTF_SO_SERV判断是否存在待处理的记录，如果存在反馈失败，处理结束。
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_SO_SERV S
     WHERE S.PROD_INST_ID = I_PROD_INST_ID
       AND S.CHANNEL_NBR = '600105B002'
       AND S.STATE NOT IN ('70C','70D');

    IF V_COUNT > 0 THEN
      O_ERR_MSG  := '该产品实例已有在途申请';
      O_ERR_CODE := 1;
      RETURN;
    END IF;

    /*查询产品是否在用，是否存在，是否是接入类产品*/
    BEGIN
      SELECT P.EXT_PROD_ID, PI.ACC_NBR, PI.AREA_ID, P.PROD_FUNC_TYPE
        INTO V_PRODUCT_CODE, V_ACC_NBR, V_AREA_ID, V_PROD_FUNC_TYPE
        FROM PROD_INST PI
        JOIN PRODUCT P ON PI.PRODUCT_ID = P.PRODUCT_ID
       WHERE PI.PROD_INST_ID = I_PROD_INST_ID
         AND PI.AREA_CODE = I_AREA_CODE
         AND PI.STATUS_CD <> '110000'
         AND ROWNUM <= 1;

      IF V_PROD_FUNC_TYPE <> '101' THEN
        O_ERR_MSG  := '该产品不是接入类产品: ' || I_PROD_INST_ID;
        O_ERR_CODE := '1';
        RETURN;
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        O_ERR_MSG  := '产品不存在或不在用';
        O_ERR_CODE := '1';
        RETURN;
    END;

    /*判断是否有在途单*/
    IF PKG_COMMON.FNC_IS_ON_ROAD(I_PROD_INST_ID) THEN
      O_ERR_MSG  := '有在途单';
      O_ERR_CODE := '1';
      RETURN;
    END IF;

    BEGIN
      --记录标准对象服务INTF_SO_SERV（业务功能类型为‘PT’，接口编码为计费、服务提供编码待定）
      SELECT SEQ_INTF_SO_SERV_ID.NEXTVAL INTO V_INTF_SO_SERV_ID FROM DUAL;
      INSERT INTO INTF_SO_SERV
        (INTF_SO_SERV_ID,
         ACC_NBR,
         PRODUCT_CODE,
         AREA_ID,
         PROD_INST_ID,
         CHANNEL_NBR,
         AREA_CODE)
      VALUES
        (V_INTF_SO_SERV_ID,
         V_ACC_NBR,
         V_PRODUCT_CODE,
         V_AREA_ID,
         I_PROD_INST_ID,
         '600105B002', --[宽带到期预拆机-计费]）
         I_AREA_CODE);

      --记录标准对象业务INTF_SO_BUSI
      SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL INTO V_INTF_SO_BUSI_ID FROM DUAL;

      SELECT P.EXT_PROD_ID
        INTO V_BUSI_CODE
        FROM PROD_INST PI
        JOIN PRODUCT P ON P.PRODUCT_ID = PI.PRODUCT_ID
       WHERE PI.PROD_INST_ID = I_PROD_INST_ID;

      INSERT INTO INTF_SO_BUSI
        (INTF_SO_BUSI_ID,
         INTF_SO_SERV_ID,
         SERIAL_SEQ,
         BUSI_CODE,
         BUSI_TYPE,
         SERVICE_OFFER_CODE,
         OBJ_ID,
         ACTION_TYPE)
      VALUES
        (V_INTF_SO_BUSI_ID,
         V_INTF_SO_SERV_ID,
         0,
         V_BUSI_CODE,
         '1300',
         '4040100000', --[改产品信息]
         I_PROD_INST_ID,
         'M'); --[更新]

      --写入标准对象属性INTF_SO_ATTR（属性编码为590000250，标准对象业务标识为空）
      SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL INTO V_INTF_SO_ATTR_ID FROM DUAL;
      INSERT INTO INTF_SO_ATTR
        (INTF_SO_ATTR_ID,
         INTF_SO_SERV_ID,
         INTF_SO_BUSI_ID,
         SERIAL_SEQ,
         ATTR_NBR,
         ATTR_VALUE)
      VALUES
        (V_INTF_SO_ATTR_ID,
         V_INTF_SO_SERV_ID,
         V_INTF_SO_BUSI_ID,
         0,
         '590000250', --[预拆机]
         '1');

      O_SERIAL := V_INTF_SO_ATTR_ID;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_MSG  := '插表出错: ' || SUBSTR(SQLERRM,1,1000);
        O_ERR_CODE := '1';
        RETURN;
    END;
  END PROC_AUTO_BILL_CJT;

  /*------------------------------------------------------------------------------------------------
      用于用户充值成功后，计费通知CRM系统
      Author  : g.caijx
      Created : 2012-03-07
  */
  PROCEDURE PROC_CHARGE_COMPLETET(I_AREA_CODE  IN VARCHAR2, --区号，比如福州0591
                                  I_ACC_NBR    IN VARCHAR2, --接入号码
                                  I_PRODUCT_ID IN NUMBER, --接入产品规格标识
                                  O_ERR_CODE   OUT NUMBER, --错误编码（0--成功 1--失败）
                                  O_ERR_MSG    OUT VARCHAR2) --错误信息
   IS
    V_COUNT   NUMBER;
    V_ATTR_ID ATTR_SPEC.ATTR_ID%TYPE;

    V_PRODUCT_CODE    INTF_SO_SERV.PRODUCT_CODE%TYPE;
    V_PROD_INST_ID    INTF_SO_SERV.PROD_INST_ID%TYPE;
    V_INTF_SO_SERV_ID INTF_SO_SERV.INTF_SO_SERV_ID%TYPE;
    V_AREA_ID         INTF_SO_SERV.AREA_ID%TYPE;
    V_AREA_CODE       PROD_INST.AREA_CODE%TYPE;

    V_INTF_SO_BUSI_ID INTF_SO_BUSI.INTF_SO_BUSI_ID%TYPE;
    V_BUSI_CODE       INTF_SO_BUSI.BUSI_CODE%TYPE;

    V_INTF_SO_ATTR_ID INTF_SO_ATTR.INTF_SO_ATTR_ID%TYPE;
  BEGIN
    O_ERR_CODE := 0;

    --根据区号、接入号码、接入号码规格查询产品实例表并查询17（预开通）或18（充值开通）的数据
    BEGIN
      SELECT PI.AREA_CODE, PI.PROD_INST_ID
        INTO V_AREA_CODE, V_PROD_INST_ID
        FROM PROD_INST PI
       WHERE PI.PRODUCT_ID = I_PRODUCT_ID
         AND PI.ACC_NBR = I_ACC_NBR
         AND PI.AREA_CODE = I_AREA_CODE
         AND PI.STATUS_CD <> '110000';
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查不到号码';
        RETURN;
    END;

    /*判断是否有在途单*/
    IF PKG_COMMON.FNC_IS_ON_ROAD(V_PROD_INST_ID) THEN
      O_ERR_MSG  := '有在途单';
      O_ERR_CODE := '1';
      RETURN;
    END IF;

    --查询INTF_SO_SERV判断是否存在待处理的记录，如果存在反馈失败，处理结束。
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_SO_SERV S
     WHERE S.PROD_INST_ID = V_PROD_INST_ID
       AND S.CHANNEL_NBR = '600105B001'
       AND S.STATE NOT IN ('70C','70D');

    IF V_COUNT > 0 THEN
      O_ERR_MSG  := '该产品实例已有在途申请';
      O_ERR_CODE := 1;
      RETURN;
    END IF;

    --判断产品实例是否为 [未激活(预开通)] 状态
    BEGIN
      SELECT A.ATTR_ID
        INTO V_ATTR_ID
        FROM PROD_INST PI
        JOIN PROD_INST_ATTR A ON A.PROD_INST_ID = PI.PROD_INST_ID
       WHERE PI.PROD_INST_ID = V_PROD_INST_ID
         AND PI.STATUS_CD = '140000' --未激活(预开通)
         AND A.ATTR_ID IN (800000280, 800000312) --800000280: 预开通, 800000312: 充值开通
      ;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_CODE := 1;
        O_ERR_MSG  := '号码状态不为[预开通]';
        RETURN;
    END;

    BEGIN
      --记录标准对象服务INTF_SO_SERV
      SELECT SEQ_INTF_SO_SERV_ID.NEXTVAL INTO V_INTF_SO_SERV_ID FROM DUAL;

      SELECT P.EXT_PROD_ID, PI.AREA_ID
        INTO V_PRODUCT_CODE, V_AREA_ID
        FROM PROD_INST PI
        JOIN PRODUCT P ON PI.PRODUCT_ID = P.PRODUCT_ID
       WHERE PI.PROD_INST_ID = V_PROD_INST_ID;

      INSERT INTO INTF_SO_SERV
        (INTF_SO_SERV_ID,
         ACC_NBR,
         PRODUCT_CODE,
         AREA_ID,
         PROD_INST_ID,
         CHANNEL_NBR,
         AREA_CODE)
      VALUES
        (V_INTF_SO_SERV_ID,
         I_ACC_NBR,
         V_PRODUCT_CODE,
         V_AREA_ID,
         V_PROD_INST_ID,
         '600105B001', --[拨打充值开通-计费]
         I_AREA_CODE);

      --记录标准对象业务INTF_SO_BUSI
      SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL INTO V_INTF_SO_BUSI_ID FROM DUAL;

      SELECT P.EXT_PROD_ID
        INTO V_BUSI_CODE
        FROM PROD_INST PI
        JOIN PRODUCT P ON P.PRODUCT_ID = PI.PRODUCT_ID
       WHERE PI.PROD_INST_ID = V_PROD_INST_ID;

      INSERT INTO INTF_SO_BUSI
        (INTF_SO_BUSI_ID,
         INTF_SO_SERV_ID,
         SERIAL_SEQ,
         BUSI_CODE,
         BUSI_TYPE,
         SERVICE_OFFER_CODE,
         OBJ_ID,
         ACTION_TYPE)
      VALUES
        (V_INTF_SO_BUSI_ID,
         V_INTF_SO_SERV_ID,
         0,
         V_BUSI_CODE,
         '1300',
         '4040100000', --[改产品信息]
         V_PROD_INST_ID,
         'M'); --[更新]

      --写入标准对象属性INTF_SO_ATTR
      SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL INTO V_INTF_SO_ATTR_ID FROM DUAL;
      INSERT INTO INTF_SO_ATTR
        (INTF_SO_ATTR_ID,
         INTF_SO_SERV_ID,
         INTF_SO_BUSI_ID,
         SERIAL_SEQ,
         ATTR_NBR,
         ATTR_VALUE)
      VALUES
        (V_INTF_SO_ATTR_ID,
         V_INTF_SO_SERV_ID,
         V_INTF_SO_BUSI_ID,
         0,
         DECODE(V_ATTR_ID,
                800000280,
                '590000280',
                800000312,
                '590000312',
                NULL), --590000280[预开通]/590000312[充值开通]
         NULL);

      --预开通激活，发起可选包变更单，使可选包的档案变更也走计费增量接口
      FOR REC IN (select POI.PROD_OFFER_INST_ID, PO.EXT_OFFER_NBR
                    from OFFER_PROD_INST_REL OPIR,
                         PROD_OFFER_INST     POI,
                         PROD_OFFER          PO
                   where OPIR.PROD_INST_ID = V_PROD_INST_ID
                     and OPIR.PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
                     and POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
                     and PO.OFFER_SUB_TYPE IN ('T04','T01')) LOOP
        --记录标准对象业务INTF_SO_BUSI
        SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL
          INTO V_INTF_SO_BUSI_ID
          FROM DUAL;

        INSERT INTO INTF_SO_BUSI
          (INTF_SO_BUSI_ID,
           INTF_SO_SERV_ID,
           SERIAL_SEQ,
           BUSI_CODE,
           BUSI_TYPE,
           SERVICE_OFFER_CODE,
           OBJ_ID,
           ACTION_TYPE)
        VALUES
          (V_INTF_SO_BUSI_ID,
           V_INTF_SO_SERV_ID,
           0,
           REC.EXT_OFFER_NBR,
           '1200',
           '3020500000', --[销售品变更]
           REC.PROD_OFFER_INST_ID,
           'M'); --[更新]
        --写入标准对象属性INTF_SO_ATTR
        SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL
          INTO V_INTF_SO_ATTR_ID
          FROM DUAL;
        INSERT INTO INTF_SO_ATTR
          (INTF_SO_ATTR_ID,
           INTF_SO_SERV_ID,
           INTF_SO_BUSI_ID,
           SERIAL_SEQ,
           ATTR_NBR,
           ATTR_VALUE)
        VALUES
          (V_INTF_SO_ATTR_ID,
           V_INTF_SO_SERV_ID,
           V_INTF_SO_BUSI_ID,
           0,
           '590039666', --预开通激活-可选包
           'Y');
      END LOOP;

      --如果输入的产品是移动语音接入类产品（800000002）
      IF I_PRODUCT_ID = 800000002 THEN
        --查询该移动语音是否包含一卡双芯功能类产品（800551826）
        SELECT COUNT(*)
          INTO V_COUNT
          FROM PROD_INST_REL R
          JOIN PROD_INST ZPI ON ZPI.PROD_INST_ID = R.PROD_INST_Z_ID
         WHERE R.PROD_INST_A_ID = V_PROD_INST_ID
           AND ZPI.PRODUCT_ID = 800551826;
        IF V_COUNT > 0 THEN
          SELECT P.EXT_PROD_ID
            INTO V_PRODUCT_CODE
            FROM PRODUCT P
           WHERE P.PRODUCT_ID = 800000007;
          --根据主副关系（109920)找到对应Z端无线宽带（800000007）记录标准对象服务INTF_SO_SERV
          FOR REC IN (SELECT ZPI.*
                        FROM PROD_INST_REL R
                        JOIN PROD_INST ZPI ON ZPI.PROD_INST_ID =
                                              R.PROD_INST_Z_ID
                       WHERE R.PROD_INST_A_ID = V_PROD_INST_ID
                         AND R.RELATION_TYPE_CD = '109920'
                         AND ZPI.PRODUCT_ID = 800000007
                         AND ZPI.STATUS_CD = '140000') LOOP

            SELECT SEQ_INTF_SO_SERV_ID.NEXTVAL
              INTO V_INTF_SO_SERV_ID
              FROM DUAL;
            INSERT INTO INTF_SO_SERV
              (INTF_SO_SERV_ID,
               ACC_NBR,
               PRODUCT_CODE,
               AREA_ID,
               PROD_INST_ID,
               CHANNEL_NBR,
               AREA_CODE)
            VALUES
              (V_INTF_SO_SERV_ID,
               REC.ACC_NBR,
               V_PRODUCT_CODE,
               REC.AREA_ID,
               REC.PROD_INST_ID,
               '600105B001', --[拨打充值开通-计费]
               REC.AREA_CODE);

            --记录标准对象业务INTF_SO_BUSI
            SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL
              INTO V_INTF_SO_BUSI_ID
              FROM DUAL;

            SELECT P.EXT_PROD_ID
              INTO V_BUSI_CODE
              FROM PROD_INST PI
              JOIN PRODUCT P ON P.PRODUCT_ID = PI.PRODUCT_ID
             WHERE PI.PROD_INST_ID = REC.PROD_INST_ID;

            INSERT INTO INTF_SO_BUSI
              (INTF_SO_BUSI_ID,
               INTF_SO_SERV_ID,
               SERIAL_SEQ,
               BUSI_CODE,
               BUSI_TYPE,
               SERVICE_OFFER_CODE,
               OBJ_ID,
               ACTION_TYPE)
            VALUES
              (V_INTF_SO_BUSI_ID,
               V_INTF_SO_SERV_ID,
               0,
               V_BUSI_CODE,
               '1300',
               '4040100000', --[改产品信息]
               REC.PROD_INST_ID,
               'M'); --[更新]

            --写入标准对象属性INTF_SO_ATTR
            SELECT A.ATTR_ID
              INTO V_ATTR_ID
              FROM PROD_INST PI
              JOIN PROD_INST_ATTR A ON A.PROD_INST_ID = PI.PROD_INST_ID
             WHERE PI.PROD_INST_ID = REC.PROD_INST_ID
               AND A.ATTR_ID IN (800000280, 800000312) --800000280: 预开通, 800000312: 充值开通
            ;
            SELECT SEQ_INTF_SO_ATTR_ID.NEXTVAL
              INTO V_INTF_SO_ATTR_ID
              FROM DUAL;
            INSERT INTO INTF_SO_ATTR
              (INTF_SO_ATTR_ID,
               INTF_SO_SERV_ID,
               INTF_SO_BUSI_ID,
               SERIAL_SEQ,
               ATTR_NBR,
               ATTR_VALUE)
            VALUES
              (V_INTF_SO_ATTR_ID,
               V_INTF_SO_SERV_ID,
               V_INTF_SO_BUSI_ID,
               0,
               DECODE(V_ATTR_ID,
                      800000280,
                      '590000280',
                      800000312,
                      '590000312',
                      NULL), --590000280[预开通]/590000312[充值开通]
               NULL);
          END LOOP;
        END IF;
      END IF;
      RETURN;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_MSG  := SUBSTR(SQLERRM,1,1000);
        O_ERR_CODE := 1;
        RETURN;
    END;
  END PROC_CHARGE_COMPLETET;

  /*------------------------------------------------------------------------------------------------
      用于电话用户充值开通时计费判断需要收多少费用才运行开通
      Author  : g.caijx
      Created : 2012-03-07
  */
  PROCEDURE PROC_QUERY_CHARGE(I_AREA_CODE  IN VARCHAR2, --区号，比如福州0591
                              I_ACC_NBR    IN VARCHAR2, --接入号码
                              I_PRODUCT_ID IN NUMBER, --接入产品规格标识
                              O_CHARGE     OUT NUMBER, --充值金额（单位：分）
                              O_MODE_TYPE  OUT NUMBER, --开通类型（0--充值开通 1--固网开通  4--拨打开通、预开通）
                              O_PRE_FEE    OUT VARCHAR2, --预存金额（单位：分）
                              O_ERR_CODE   OUT NUMBER, --错误编码（0--成功 1--失败 2--实名制认证失败）
                              O_ERR_MSG    OUT VARCHAR2) --错误信息
   IS
    V_PROD_INST_ID   PROD_INST.PROD_INST_ID%TYPE;
    V_AREA_CODE      PROD_INST.AREA_CODE%TYPE;
    V_ATTR_ID        ATTR_SPEC.ATTR_ID%TYPE;
    V_CUST_SO_NUMBER ACCT_ITEM.CUST_SO_NUMBER%TYPE;

    V_CHARGE_CODE VARCHAR2(2);
    V_PRE_PRICE   NUMBER;
    V_PRE_FEE     NUMBER;
    V_NO_CERT  number;
  BEGIN
    O_ERR_CODE := 0;
    /*
    拨开开通或充值开通xlt_pim_info
    纵横放卡SOA--CRM入库SOB--计费充值成功或拨打成功SOC--CRM产生档案SOD
    福州流程： 代办点可以对SOB的数据更新赠送金额、充值金额，模式，添加套餐
    */
    BEGIN
      SELECT CHARGE_MODE, NVL(PRE_PRICE, 0), NVL(PRE_FEE, 0)
        INTO V_CHARGE_CODE, V_PRE_PRICE, V_PRE_FEE
        FROM XLT_PIM_INFO
       WHERE AREA_CODE = I_AREA_CODE
         AND ACC_NBR = I_ACC_NBR
         AND PROD_SPEC_ID = I_PRODUCT_ID
         AND (STATE = 'SOA' OR STATE = 'SOB')
         AND ROWNUM < 2;

      IF V_CHARGE_CODE = '1' THEN
        O_MODE_TYPE := 4; --拨开开通
      ELSE
        O_MODE_TYPE := 0; --充值开通
      END IF;
      O_CHARGE  := V_PRE_PRICE; --充值开通返回充值金额
      O_PRE_FEE := V_PRE_FEE; --赠送金额（预存金额）
        EXCEPTION
           WHEN OTHERS THEN

        /*预开通单或固网开通单处理**/
        BEGIN
          SELECT PI.AREA_CODE, PI.PROD_INST_ID
            INTO V_AREA_CODE, V_PROD_INST_ID
            FROM PROD_INST PI
           WHERE PI.PRODUCT_ID = I_PRODUCT_ID
             AND PI.ACC_NBR = I_ACC_NBR
             AND PI.AREA_CODE = I_AREA_CODE
             AND PI.STATUS_CD <> '110000';
        EXCEPTION
          WHEN OTHERS THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := '查不到号码';
            RETURN;
        END;
        /*判断是否是非实名制用户  LIXUAN-2013-9-9*/
        BEGIN
          SELECT count(*)
            INTO V_NO_CERT
            FROM PROD_INST PI,PROD_INST_ATTR PIA,ATTR_SPEC  ASS
           WHERE PI.PRODUCT_ID = I_PRODUCT_ID
             AND PI.PROD_INST_ID = PIA.PROD_INST_ID
             AND PIA.ATTR_ID  = ASS.ATTR_ID
             AND PI.ACC_NBR = I_ACC_NBR
             AND PI.AREA_CODE = I_AREA_CODE
             AND PI.STATUS_CD <> '110000'
             AND ASS.Ext_Attr_Nbr ='590040526';
          IF  V_NO_CERT =1  THEN
              --O_ERR_CODE := 1;
              O_ERR_CODE := 2;
              O_ERR_MSG  := '非实名制用户，不允许开通转正！';
              RETURN;
          END IF;
           EXCEPTION
          WHEN OTHERS THEN
            --O_ERR_CODE := 1;
            O_ERR_CODE := 2;
            O_ERR_MSG  := '实名制验证失败';
            RETURN;
        END;
/*------------------------------------------------------*/
        BEGIN
          SELECT A.ATTR_ID
            INTO V_ATTR_ID
            FROM PROD_INST PI
            JOIN PROD_INST_ATTR A ON A.PROD_INST_ID = PI.PROD_INST_ID
           WHERE PI.PROD_INST_ID = V_PROD_INST_ID
             AND PI.STATUS_CD = '140000' --未激活(预开通)
             AND A.ATTR_ID IN (800000280, 800000312) --800000280: 预开通, 800000312: 充值开通
          ;
        EXCEPTION
          WHEN OTHERS THEN
            O_ERR_CODE := 1;
            O_ERR_MSG  := '号码状态不为[预开通]';
            RETURN;
        END;

        --如果是（预开通）：开通类型返回4，充值金额与预存金额均返回0。
        IF V_ATTR_ID = 800000280 THEN
          ---800000280: 预开通
          O_MODE_TYPE := 4;
          O_CHARGE    := 0;
          O_PRE_FEE   := 0;
        ELSIF V_ATTR_ID = 800000312 THEN
          --800000312:  充值开通
          --如果是（充值开通）
          --福州地区的移动语音，如果是开通类型返回0，充值金额返回30元，预存金额返回0。
          IF V_AREA_CODE = '0591' THEN
            O_MODE_TYPE := 0;
            O_CHARGE    := 3000;
            O_PRE_FEE   := 0;
          ELSE
            /*其他情况，开通类型返回1，充值金额处理如下：
            扫描一次性费用账目表
            （根据付费类型为充值（140101）、
            账目项动作类型（NORMAL）、
            接入类产品实例、
            接入类产品实例对应的竣工单流水号查询ACCT_ITEM）
            对AMOUNT进行求和（单位是毫），
            预存金额返回0。*/
            O_MODE_TYPE := 1;

            --查接入类产品实例对应的竣工单流水号(不合理...)
            BEGIN
              SELECT CO.CUST_SO_NUMBER
                INTO V_CUST_SO_NUMBER
                FROM ORDER_ITEM_HIS OI
                JOIN CUSTOMER_ORDER_HIS CO ON CO.CUST_ORDER_ID =
                                              OI.CUST_ORDER_ID
               WHERE OI.ORDER_ITEM_OBJ_ID = V_PROD_INST_ID
                 AND OI.CLASS_ID = 4
                 AND ROWNUM <= 1;
            EXCEPTION
              WHEN OTHERS THEN
                V_CUST_SO_NUMBER := NULL;
            END;

            IF V_CUST_SO_NUMBER IS NULL THEN
              O_CHARGE := 0;
            ELSE
              SELECT NVL(SUM(NVL(AI.AMOUNT, 0)), 0) / 100 --1分=100毫
                INTO O_CHARGE
                FROM ACCT_ITEM AI
               WHERE AI.PROD_INST_ID = V_PROD_INST_ID
                 AND AI.PAYMENT_MODE = '140101'
                 AND AI.ACTION_TYPE = 'NORMAL'
                 AND AI.CUST_SO_NUMBER = V_CUST_SO_NUMBER;
            END IF;

            O_PRE_FEE := 0;
          END IF;
        END IF;
    END;
  END PROC_QUERY_CHARGE;

  /*-------------------------------------------------
    欠费拆机拆机停到期拆。
    Author  : g.caijx
    Created : 2012-03-07
  -------------------------------------------------*/
  PROCEDURE PROC_AUTO_BILL_CJ(I_AREA_CODE    IN VARCHAR2, --区号，比如福州0591
                              I_PROD_INST_ID IN VARCHAR2, --接入类产品实例标识
                              I_ACTION_TYPE  IN VARCHAR2, --动作类型（1:自主拆机 2：欠费拆机 3:担保租机违约拆机）
                              O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                              O_ERR_MSG      OUT VARCHAR2, --错误信息
                              O_SERIAL       OUT VARCHAR2 --处理序列号
                              ) IS
    V_COUNT NUMBER;

    V_CHANNEL_NBR INTF_SO_SERV.CHANNEL_NBR%TYPE;

    V_PROD_INST PROD_INST%ROWTYPE;
    V_PROD_OFFER_INST PROD_OFFER_INST%ROWTYPE;--主销售品实例
    V_SERIAL VARCHAR2(30);

    TYPE TYPE_PROD_INST_ID_LIST IS TABLE OF PROD_INST.PROD_INST_ID%TYPE;
    V_RH_PROD_INST_IDS   TYPE_PROD_INST_ID_LIST;--融合套餐产品实例id
    V_LX_PROD_INST_IDS   TYPE_PROD_INST_ID_LIST;--乐享套餐产品实例id
  BEGIN
    O_SERIAL   := 0;
    O_ERR_CODE := 1;

    --判断是否是自主拆机或欠费拆机，如果不是返回失败，处理结束。
    IF I_ACTION_TYPE = '1' THEN
      V_CHANNEL_NBR := '600105B004'; --渠道编码600105B004[自主拆机-计费]
    ELSIF I_ACTION_TYPE = '2' THEN
      V_CHANNEL_NBR := '600105B005'; --渠道编码600105B005[欠费拆机-计费]
    ELSIF I_ACTION_TYPE = '3' THEN
      V_CHANNEL_NBR := '600105A084'; --渠道编码600105A084[担保租机违约拆机-计费]
    ELSE
      O_ERR_MSG := '输入的动作类型错误!';
      RETURN;
    END IF;

    --查询INTF_SO_SERV判断是否存在待处理的记录，如果存在反馈失败，处理结束。
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_SO_SERV S
      JOIN INTF_SO_BUSI B
        ON B.INTF_SO_SERV_ID = S.INTF_SO_SERV_ID
     WHERE (S.PROD_INST_ID = I_PROD_INST_ID OR
           (B.OBJ_ID = I_PROD_INST_ID AND B.BUSI_TYPE = '1300'))
       AND S.CHANNEL_NBR IN ('600105B004', '600105B005')
       AND S.STATE NOT IN ('70C', '70D')
       AND ROWNUM = 1;
    IF V_COUNT > 0 THEN
      O_ERR_MSG := '该产品实例已有在途申请';
      RETURN;
    END IF;

    --查询产品是否在用，是否存在，是否是接入类产品
    BEGIN
      SELECT PI.*
        INTO V_PROD_INST
        FROM PROD_INST PI
        JOIN PRODUCT P
          ON P.PRODUCT_ID = PI.PRODUCT_ID
       WHERE PI.PROD_INST_ID = I_PROD_INST_ID
         AND PI.AREA_CODE = I_AREA_CODE
         AND P.PROD_FUNC_TYPE = '101'
         AND PI.STATUS_CD <> '110000';
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_MSG := '产品不存在或不是接入类产品';
        RETURN;
    END;

    --判断是否有在途单
    IF PKG_COMMON.FNC_IS_ON_ROAD(I_PROD_INST_ID) THEN
      O_ERR_MSG := '有在途单';
      RETURN;
    END IF;

    BEGIN
      IF I_ACTION_TYPE = 1 THEN
        --1: 自主拆机
        --判断是否有预拆机属性
        SELECT COUNT(*)
          INTO V_COUNT
          FROM PROD_INST_ATTR A
         WHERE A.PROD_INST_ID = I_PROD_INST_ID
           AND A.ATTR_ID = 800000250 --800000250: 预拆机
           AND A.STATUS_CD = '1000';
        IF V_COUNT = 0 THEN
          O_ERR_MSG := '该产品实例不存在[预拆机]属性';
          RETURN;
        END IF;

        --执行拆机
        PROC_DO_CJ(I_PROD_INST_ID      => V_PROD_INST.PROD_INST_ID,
                   I_PARENT_SO_SERV_ID => NULL,
                   I_IS_CHILD_CJ       => FALSE,
                   I_CHANNEL_NBR       => V_CHANNEL_NBR,
                   O_SERIAL            => O_SERIAL);
      ELSIF I_ACTION_TYPE = 2 OR I_ACTION_TYPE = 3 THEN  --CRM00051900 加动作3处理
        --2：欠费拆机
        --先拆I_PROD_INST_ID
        PROC_DO_CJ(I_PROD_INST_ID      => I_PROD_INST_ID,
                   I_PARENT_SO_SERV_ID => NULL,
                   I_IS_CHILD_CJ       => FALSE,
                   I_CHANNEL_NBR       => V_CHANNEL_NBR,
                   O_SERIAL            => O_SERIAL);

        --再进行融合套餐拆机---------
        --查询主销售品
        BEGIN
          SELECT POI.*
            INTO V_PROD_OFFER_INST
            FROM OFFER_PROD_INST_REL R
            JOIN PROD_OFFER_INST POI
              ON POI.PROD_OFFER_INST_ID = R.PROD_OFFER_INST_ID
            JOIN PROD_OFFER PO
              ON PO.PROD_OFFER_ID = POI.PROD_OFFER_ID
           WHERE PO.OFFER_SUB_TYPE = 'T01'
             AND R.PROD_INST_ID = I_PROD_INST_ID
             AND ROWNUM = 1;
        EXCEPTION
          WHEN OTHERS THEN
            O_ERR_MSG := '查不到主销售品';
            RETURN;
        END;
        --判断是否是融合套餐
        SELECT COUNT(*)
          INTO V_COUNT
          FROM INTF_RH_CJ_CONFIG C
         WHERE C.PROD_OFFER_ID = V_PROD_OFFER_INST.PROD_OFFER_ID
         AND C.STATE = '1000'
         ;
        IF V_COUNT > 0 THEN
          --获取融合套餐下所有接入类产品, 不包含I_PROD_INST_ID
          SELECT IR.PROD_INST_ID BULK COLLECT
            INTO V_RH_PROD_INST_IDS
            FROM OFFER_PROD_INST_REL IR
            JOIN PROD_INST PI
              ON PI.PROD_INST_ID = IR.PROD_INST_ID
            JOIN PRODUCT P
              ON P.PRODUCT_ID = PI.PRODUCT_ID
           WHERE IR.PROD_OFFER_INST_ID =
                 V_PROD_OFFER_INST.PROD_OFFER_INST_ID
             AND IR.PROD_INST_ID <> I_PROD_INST_ID --除去计费的那个产品实例
             AND P.PROD_FUNC_TYPE = '101' --接入类
             AND PI.STATUS_CD <> '110000' --110000: 拆机
             ;

          FOR I IN 1 .. V_RH_PROD_INST_IDS.COUNT LOOP
            --先拆融合套餐下的产品实例
            PROC_DO_CJ(I_PROD_INST_ID      => V_RH_PROD_INST_IDS(I),
                       I_PARENT_SO_SERV_ID => O_SERIAL,
                       I_IS_CHILD_CJ       => TRUE,
                       I_CHANNEL_NBR       => V_CHANNEL_NBR,
                       O_SERIAL            => V_SERIAL);
          END LOOP;

          FOR I IN 1 .. V_RH_PROD_INST_IDS.COUNT LOOP
            --再关联拆机
            PROC_RELA_CJ(I_PROD_INST_ID      => V_RH_PROD_INST_IDS(I),
                         I_PARENT_SO_SERV_ID => O_SERIAL,
                         I_CHANNEL_NBR       => V_CHANNEL_NBR);
          END LOOP;
        END IF;

        --进行乐享套餐副卡、共享包拆机---------
        --判断是否是乐享套餐 拆的是移动语音主卡，且存在其它移动语音
        SELECT COUNT(*)
          INTO V_COUNT
          FROM OFFER_PROD_INST_REL OPIR,
               PROD_INST           PI_MAIN
         WHERE OPIR.PROD_OFFER_INST_ID = V_PROD_OFFER_INST.Prod_Offer_Inst_Id
         AND OPIR.STATUS_CD = '1000'
         AND OPIR.ROLE_CD = '3083'
         AND OPIR.PROD_INST_ID = I_PROD_INST_ID
         AND OPIR.PROD_INST_ID = PI_MAIN.PROD_INST_ID
         AND PI_MAIN.PRODUCT_ID  = 800000002
         AND EXISTS
         (SELECT 1 FROM OFFER_PROD_INST_REL OPIR2,
                        PROD_INST           PI_SECOND
           WHERE OPIR2.PROD_OFFER_INST_ID = V_PROD_OFFER_INST.PROD_OFFER_INST_ID
             AND OPIR2.PROD_INST_ID = PI_SECOND.PROD_INST_ID
             AND PI_SECOND.STATUS_CD <> 110000
             AND PI_SECOND.PRODUCT_ID = 800000002
             AND OPIR2.STATUS_CD = '1000'
          --   AND OPIR2.ROLE_CD = '3084'
             );
        IF V_COUNT > 0 THEN
          --获取乐享套餐下所有接入类产品, 不包含I_PROD_INST_ID
          SELECT IR.PROD_INST_ID BULK COLLECT
            INTO V_LX_PROD_INST_IDS
            FROM OFFER_PROD_INST_REL IR
            JOIN PROD_INST PI
              ON PI.PROD_INST_ID = IR.PROD_INST_ID
            JOIN PRODUCT P
              ON P.PRODUCT_ID = PI.PRODUCT_ID
           WHERE IR.PROD_OFFER_INST_ID = V_PROD_OFFER_INST.PROD_OFFER_INST_ID
             AND IR.PROD_INST_ID <> I_PROD_INST_ID --除去计费的那个产品实例
             AND P.PROD_FUNC_TYPE = '101' --接入类
             AND PI.STATUS_CD <> '110000' --110000: 拆机
             ;

          FOR I IN 1 .. V_LX_PROD_INST_IDS.COUNT LOOP
            --先拆乐享套餐下的产品实例
            PROC_DO_CJ(I_PROD_INST_ID      => V_LX_PROD_INST_IDS(I),
                       I_PARENT_SO_SERV_ID => O_SERIAL,
                       I_IS_CHILD_CJ       => TRUE,
                       I_CHANNEL_NBR       => V_CHANNEL_NBR,
                       O_SERIAL            => V_SERIAL);
          END LOOP;

          FOR I IN 1 .. V_LX_PROD_INST_IDS.COUNT LOOP
            --再关联拆机
            PROC_RELA_CJ(I_PROD_INST_ID      => V_LX_PROD_INST_IDS(I),
                         I_PARENT_SO_SERV_ID => O_SERIAL,
                         I_CHANNEL_NBR       => V_CHANNEL_NBR);
          END LOOP;

        END IF;

        --然后关联拆I_PROD_INST_ID
        PROC_RELA_CJ(I_PROD_INST_ID      => I_PROD_INST_ID,
                     I_PARENT_SO_SERV_ID => O_SERIAL,
                     I_CHANNEL_NBR       => V_CHANNEL_NBR);
      END IF;

      O_ERR_CODE := 0;
    EXCEPTION
      WHEN OTHERS THEN
        O_ERR_MSG := SUBSTR(SQLERRM,1,1000);
    END;
  END;

  /*-------------------------------------------------
    关联拆机
  -------------------------------------------------*/
  PROCEDURE PROC_RELA_CJ(I_PROD_INST_ID      IN PROD_INST.PROD_INST_ID%TYPE,
                         I_PARENT_SO_SERV_ID IN VARCHAR2, --父intf_so_serv_id
                         I_CHANNEL_NBR       IN INTF_SO_SERV.CHANNEL_NBR%TYPE
                         ) IS
    V_COUNT NUMBER;
    V_INTF_CJ_CONFIG INTF_CJ_CONFIG%ROWTYPE;
  BEGIN
    --取过程传入的接入类产品关联的产品
    --INTF_CJ_CONFIG.FUNC_PRODUCT_ID是指这两个有关联的产品都要包含的程控
    FOR REC IN (
                --I_PROD_INST_ID作为A端取Z端的产品实例
                SELECT PIZ.PROD_INST_ID,
                       PZ.PROD_FUNC_TYPE,
                       R.RELATION_TYPE_CD,
                       PIA.PRODUCT_ID PRODUCT_ID_A,
                       PIZ.PRODUCT_ID PRODUCT_ID_Z,
                       PIZ.AREA_ID,
                       'CA' DIRECTION
                  FROM PROD_INST_REL R
                  JOIN PROD_INST PIZ
                    ON PIZ.PROD_INST_ID = R.PROD_INST_Z_ID
                  JOIN PRODUCT PZ
                    ON PZ.PRODUCT_ID = PIZ.PRODUCT_ID
                  JOIN PROD_INST PIA
                    ON PIA.PROD_INST_ID = R.PROD_INST_A_ID
                 WHERE R.PROD_INST_A_ID = I_PROD_INST_ID
                UNION
                --I_PROD_INST_ID作为Z端取A端的产品实例
                SELECT PIA.PROD_INST_ID,
                       PA.PROD_FUNC_TYPE,
                       R.RELATION_TYPE_CD,
                       PIA.PRODUCT_ID PRODUCT_ID_A,
                       PIZ.PRODUCT_ID PRODUCT_ID_Z,
                       PIA.AREA_ID,
                       'CZ' DIRECTION
                  FROM PROD_INST_REL R
                  JOIN PROD_INST PIA
                    ON PIA.PROD_INST_ID = R.PROD_INST_A_ID
                  JOIN PRODUCT PA
                    ON PA.PRODUCT_ID = PIA.PRODUCT_ID
                  JOIN PROD_INST PIZ
                    ON PIZ.PROD_INST_ID = R.PROD_INST_Z_ID
                 WHERE R.PROD_INST_Z_ID = I_PROD_INST_ID
                 ) LOOP

      --判断关联的产品是否是接入类. 101: 接入类
      IF REC.PROD_FUNC_TYPE = '101' THEN
        --判断是否在INTF_CJ_CONFIG有配置, 如果有配置才执行拆机
        BEGIN
          SELECT C.*
            INTO V_INTF_CJ_CONFIG
            FROM INTF_CJ_CONFIG C
           WHERE C.DIRECTION = REC.DIRECTION
             AND C.RELATION_TYPE = REC.RELATION_TYPE_CD
             AND (C.PRODUCT_A_ID = REC.PRODUCT_ID_A OR
                 C.PRODUCT_A_ID IS NULL)
             AND (C.PRODUCT_Z_ID = REC.PRODUCT_ID_Z OR
                 C.PRODUCT_Z_ID IS NULL)
             AND (C.AREA_ID = REC.AREA_ID OR
                 C.AREA_ID IS NULL)
             AND ROWNUM = 1;

          V_COUNT := 1;--有配置则置为1
        EXCEPTION
          WHEN OTHERS THEN
          V_COUNT := 0;--没配置则置为0
        END;

        IF V_COUNT = 1 THEN
          --V_INTF_CJ_CONFIG.FUNC_PRODUCT_ID: I_PROD_INST_ID, REC.PROD_INST_ID这两个产品实例都要包含的程控
          --如果没有配置FUNC_PRODUCT_ID, 则关联的产品REC.PROD_INST_ID可以直接拆机掉
          --否则需要判断I_PROD_INST_ID, REC.PROD_INST_ID和V_INTF_CJ_CONFIG.FUNC_PRODUCT_ID要构成三角关系.
          --满足这样的关系才能把关联的产品实例REC.PROD_INST_ID拆掉
          IF V_INTF_CJ_CONFIG.FUNC_PRODUCT_ID IS NULL THEN
            --递归拆机
            PROC_BILL_CJ_JFGX(I_PROD_INST_ID      => REC.PROD_INST_ID,
                              I_PARENT_SO_SERV_ID => I_PARENT_SO_SERV_ID,
                              I_CHANNEL_NBR       => I_CHANNEL_NBR);
          ELSE
            --判断三角关系
            --即: 判断I_PROD_INST_ID下挂的程控是否也是REC.PROD_INST_ID的程控
            SELECT COUNT(*)
              INTO V_COUNT
              FROM PROD_INST_REL R
              JOIN PROD_INST PIZ
                ON PIZ.PROD_INST_ID = R.PROD_INST_Z_ID
             WHERE R.PROD_INST_A_ID = I_PROD_INST_ID
               AND INSTR(V_INTF_CJ_CONFIG.FUNC_PRODUCT_ID, PIZ.PRODUCT_ID) <> 0 --说明有指定的功能类产品
               AND EXISTS
             (SELECT RR.PROD_INST_Z_ID
                      FROM PROD_INST_REL RR
                     WHERE RR.PROD_INST_A_ID = REC.PROD_INST_ID
                       AND RR.PROD_INST_Z_ID = R.PROD_INST_Z_ID)
               AND ROWNUM = 1;
            IF V_COUNT > 0 THEN
              --递归拆机
              PROC_BILL_CJ_JFGX(I_PROD_INST_ID      => REC.PROD_INST_ID,
                                I_PARENT_SO_SERV_ID => I_PARENT_SO_SERV_ID,
                                I_CHANNEL_NBR       => I_CHANNEL_NBR);
            END IF;
          END IF;
        END IF;
      END IF;
    END LOOP;
  END;

  /*-------------------------------------------------
    递归拆机
  -------------------------------------------------*/
  PROCEDURE PROC_BILL_CJ_JFGX(I_PROD_INST_ID      IN PROD_INST.PROD_INST_ID%TYPE,
                              I_PARENT_SO_SERV_ID IN VARCHAR2, --父intf_so_serv_id
                              I_CHANNEL_NBR       IN INTF_SO_SERV.CHANNEL_NBR%TYPE
                              ) IS
    V_COUNT  NUMBER(10);
    V_SERIAL VARCHAR2(30);
  BEGIN
    --执行拆机
    PROC_DO_CJ(I_PROD_INST_ID      => I_PROD_INST_ID,
               I_PARENT_SO_SERV_ID => I_PARENT_SO_SERV_ID,
               I_IS_CHILD_CJ       => TRUE,
               I_CHANNEL_NBR       => I_CHANNEL_NBR,
               O_SERIAL            => V_SERIAL);

    --递归
    FOR REC IN (SELECT PIA.PROD_INST_ID,
                       PA.PROD_FUNC_TYPE,
                       R.RELATION_TYPE_CD,
                       PIA.PRODUCT_ID PRODUCT_ID_A,
                       PIZ.PRODUCT_ID PRODUCT_ID_Z,
                       PIA.AREA_ID,
                       'DZ' DIRECTION --DZ: 从Z端找A端, 然后执行递归拆
                  FROM PROD_INST_REL R
                  JOIN PROD_INST PIZ
                    ON PIZ.PROD_INST_ID = R.PROD_INST_Z_ID
                  JOIN PROD_INST PIA
                    ON PIA.PROD_INST_ID = R.PROD_INST_A_ID
                  JOIN PRODUCT PA
                    ON PA.PRODUCT_ID = PIA.PRODUCT_ID
                 WHERE R.PROD_INST_Z_ID = I_PROD_INST_ID) LOOP
      IF REC.PROD_FUNC_TYPE = '101' THEN
        --判断是否在INTF_CJ_CONFIG有配置, 如果有配置才执行拆机
        SELECT COUNT(*)
          INTO V_COUNT
          FROM INTF_CJ_CONFIG C
         WHERE C.DIRECTION = REC.DIRECTION
           AND C.RELATION_TYPE = REC.RELATION_TYPE_CD
           AND (C.PRODUCT_A_ID = REC.PRODUCT_ID_A OR C.PRODUCT_A_ID IS NULL)
           AND (C.PRODUCT_Z_ID = REC.PRODUCT_ID_Z OR C.PRODUCT_Z_ID IS NULL)
           AND (C.AREA_ID = REC.AREA_ID OR C.AREA_ID IS NULL)
           AND ROWNUM = 1;

        IF V_COUNT > 0 THEN
          --递归拆机
          PROC_BILL_CJ_JFGX(I_PROD_INST_ID      => REC.PROD_INST_ID,
                            I_PARENT_SO_SERV_ID => V_SERIAL,
                            I_CHANNEL_NBR       => I_CHANNEL_NBR);
        END IF;
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20201,
                              '递归拆机失败. 产品实例id: ' || I_PROD_INST_ID ||
                              CHR(13) || SUBSTR(SQLERRM,1,1000));
  END;

  /*-------------------------------------------------
    执行拆机
  -------------------------------------------------*/
  PROCEDURE PROC_DO_CJ(I_PROD_INST_ID      IN PROD_INST.PROD_INST_ID%TYPE, --欲拆的产品实例id
                       I_PARENT_SO_SERV_ID IN VARCHAR2, --父intf_so_serv_id
                       I_IS_CHILD_CJ       IN BOOLEAN,  --是否为非计费发起号码拆机，包括融合套餐下其他号码拆机和对应的关联拆机和递归拆机
                       I_CHANNEL_NBR       IN INTF_SO_SERV.CHANNEL_NBR%TYPE,
                       O_SERIAL            OUT VARCHAR2 --INTF_SO_SERV_ID
                       ) IS
    V_COUNT NUMBER;

    V_PRODUCT PRODUCT%ROWTYPE;

    --V_INTF_LOG_INFO_ID INTF_LOG_INFO.INTF_LOG_INFO_ID%TYPE;
    V_INTF_SO_SERV_ID  INTF_SO_SERV.INTF_SO_SERV_ID%TYPE;
    V_INTF_SO_BUSI_ID  INTF_SO_BUSI.INTF_SO_BUSI_ID%TYPE;

    V_PROD_INST PROD_INST%ROWTYPE;
    --V_PARENT_SO_SERV   INTF_SO_SERV%ROWTYPE;
    E_INSERT_EXCEPTION EXCEPTION;--intf_so_serv插入成功判断
    V_PRODUCT_ID                 PROD_INST.PRODUCT_ID%TYPE;
    V_PARENT_PROD_INST_ID        PROD_INST.PROD_INST_ID%TYPE;
    V_INTF_SO_BUSI_REL_ID        INTF_SO_BUSI_REL.INTF_SO_BUSI_REL_ID%TYPE;
    V_PARENT_INTF_SO_BUSI_ID     INTF_SO_BUSI.INTF_SO_BUSI_ID%TYPE;
  BEGIN
    SELECT *
      INTO V_PROD_INST
      FROM PROD_INST PI
     WHERE PI.PROD_INST_ID = I_PROD_INST_ID;

    --查询INTF_SO_SERV, INTF_SO_BUSI判断是否存在待处理的记录
    SELECT COUNT(*)
      INTO V_COUNT
      FROM INTF_SO_SERV S
      JOIN INTF_SO_BUSI B
        ON B.INTF_SO_SERV_ID = S.INTF_SO_SERV_ID
     WHERE (S.PROD_INST_ID = V_PROD_INST.PROD_INST_ID OR
           (B.OBJ_ID = V_PROD_INST.PROD_INST_ID AND B.BUSI_TYPE = '1300'))
       AND S.CHANNEL_NBR IN ('600105B004', '600105B005')
       AND S.STATE NOT IN ('70C', '70D')
       AND ROWNUM = 1;
    IF V_COUNT > 0 THEN
       /*crm00055570 问题单  g.zhenglzh
         关联拆机后又关联到自身，return 一个空值
         解决：判断当前的判断是否是当前正常处理的的处理，过滤掉自身拆机的判断
       */
      SELECT S.INTF_SO_SERV_ID
      INTO V_INTF_SO_SERV_ID
      FROM INTF_SO_SERV S
      JOIN INTF_SO_BUSI B
        ON B.INTF_SO_SERV_ID = S.INTF_SO_SERV_ID
     WHERE (S.PROD_INST_ID = V_PROD_INST.PROD_INST_ID OR
           (B.OBJ_ID = V_PROD_INST.PROD_INST_ID AND B.BUSI_TYPE = '1300'))
       AND S.CHANNEL_NBR IN ('600105B004', '600105B005')
       AND S.STATE NOT IN ('70C', '70D')
       AND ROWNUM = 1;
       IF V_INTF_SO_SERV_ID = I_PARENT_SO_SERV_ID THEN
         O_SERIAL := V_INTF_SO_SERV_ID;
       END IF;
         RETURN;
    END IF;

    --判断是否有在途单
    IF PKG_COMMON.FNC_IS_ON_ROAD(I_PROD_INST_ID) THEN
      RAISE_APPLICATION_ERROR(-20101, '有在途单');
    END IF;

    --取product
    SELECT *
      INTO V_PRODUCT
      FROM PRODUCT P
     WHERE P.PRODUCT_ID = V_PROD_INST.PRODUCT_ID;

    --记录INTF_SO_SERV
    IF I_IS_CHILD_CJ THEN
      V_INTF_SO_SERV_ID := I_PARENT_SO_SERV_ID;
    ELSE
      SELECT SEQ_INTF_SO_SERV_ID.NEXTVAL INTO V_INTF_SO_SERV_ID FROM DUAL;
      INSERT INTO INTF_SO_SERV
        (INTF_SO_SERV_ID,
         ACC_NBR,
         PRODUCT_CODE,
         AREA_ID,
         PROD_INST_ID,
         CHANNEL_NBR,
         AREA_CODE)
      VALUES
        (V_INTF_SO_SERV_ID,
         V_PROD_INST.ACC_NBR,
         V_PRODUCT.EXT_PROD_ID,
         V_PROD_INST.AREA_ID,
         V_PROD_INST.PROD_INST_ID,
         I_CHANNEL_NBR, --[欠费拆机-计费]
         V_PROD_INST.AREA_CODE);
         --插入异常处理
         IF SQL%ROWCOUNT <> 1 THEN
            RAISE  E_INSERT_EXCEPTION;
         END IF;
    END IF;

    --记录INTF_SO_BUSI
    SELECT SEQ_INTF_SO_BUSI_ID.NEXTVAL INTO V_INTF_SO_BUSI_ID FROM DUAL;
    INSERT INTO INTF_SO_BUSI
      (INTF_SO_BUSI_ID,
       INTF_SO_SERV_ID,
       SERIAL_SEQ,
       BUSI_CODE,
       BUSI_TYPE,
       SERVICE_OFFER_CODE,
       OBJ_ID,
       ACTION_TYPE)
    VALUES
      (V_INTF_SO_BUSI_ID,
       V_INTF_SO_SERV_ID,
       0,
       V_PRODUCT.EXT_PROD_ID,
       '1300',
       '4020100000', --[拆机]
       V_PROD_INST.PROD_INST_ID,
       'D');
    --欠费拆机，添加拆机类型属性
    IF I_CHANNEL_NBR = '600105B005' THEN
      INSERT INTO INTF_SO_ATTR
        (INTF_SO_ATTR_ID,
         INTF_SO_SERV_ID,
         INTF_SO_BUSI_ID,
         SERIAL_SEQ,
         ATTR_NBR,
         ATTR_VALUE,
         REMARK)
        VALUES
        (SEQ_INTF_SO_ATTR_ID.NEXTVAL,
         V_INTF_SO_SERV_ID,
         V_INTF_SO_BUSI_ID,
         '0',
         '590000321',
         '1',
         '');
    END IF;

    --欠费拆机并且是被关联的拆机,
    IF I_CHANNEL_NBR = '600105B005' AND I_IS_CHILD_CJ THEN
      SELECT PRODUCT_ID
        INTO V_PRODUCT_ID
        FROM PROD_INST
       WHERE PROD_INST_ID = I_PROD_INST_ID;
       IF V_PRODUCT_ID = 800000087 THEN
         SELECT PROD_INST_ID INTO V_PARENT_PROD_INST_ID
           FROM INTF_SO_SERV
          WHERE INTF_SO_SERV_ID = V_INTF_SO_SERV_ID;
         SELECT INTF_SO_BUSI_ID INTO  V_PARENT_INTF_SO_BUSI_ID
           FROM INTF_SO_BUSI
          WHERE INTF_SO_SERV_ID = V_INTF_SO_SERV_ID
            AND OBJ_ID = V_PARENT_PROD_INST_ID;
         FOR CUR IN (
          SELECT PROD_INST_REL_ID
            FROM PROD_INST_REL
           WHERE PROD_INST_Z_ID = V_PARENT_PROD_INST_ID
             AND PROD_INST_A_ID = I_PROD_INST_ID
             AND STATUS_CD <> 1100
             ) LOOP

            INSERT INTO INTF_SO_BUSI_REL
              (INTF_SO_BUSI_REL_ID,
               INTF_SO_BUSI_A_ID,
               INTF_SO_BUSI_Z_ID,
               ACTION_TYPE )
            VALUES
              (CUR.PROD_INST_REL_ID,
               V_PARENT_INTF_SO_BUSI_ID,
               V_INTF_SO_BUSI_ID,
               'D');
         END LOOP;
       END IF;
    END IF;


/*
    --轮训处处理，只插入成功的记录，计费就不需要回滚操作
    --写入拆机日志INTF_LOG_INFO
    IF I_PARENT_SO_SERV_ID IS NOT NULL THEN
       SELECT S.*
        INTO V_PARENT_SO_SERV
        FROM INTF_SO_SERV S
       WHERE S.INTF_SO_SERV_ID = I_PARENT_SO_SERV_ID;
      SELECT SEQ_INTF_LOG_INFO_ID.NEXTVAL INTO V_INTF_LOG_INFO_ID FROM DUAL;
      INSERT INTO INTF_LOG_INFO
        (INTF_LOG_INFO_ID,
         INTF_SO_SERV_ID,
         PROD_INST_ID,
         AREA_CODE,
         ACC_NBR,
         CHANNEL_NBR,
         RELA_PROD_INST_ID)
      VALUES
        (V_INTF_LOG_INFO_ID,
         V_INTF_SO_SERV_ID,
         V_PARENT_SO_SERV.PROD_INST_ID,
         V_PROD_INST.AREA_CODE,
         V_PROD_INST.ACC_NBR,
         I_CHANNEL_NBR,
         V_PROD_INST.PROD_INST_ID);
    END IF;*/

    O_SERIAL := V_INTF_SO_SERV_ID;
  EXCEPTION
    WHEN E_INSERT_EXCEPTION THEN
      RAISE_APPLICATION_ERROR(-20001,
                              '拆机失败. 产品实例id: ' || V_PROD_INST.PROD_INST_ID ||
                              CHR(13) || 'INTF_SO_SERV表插入失败，请重新发起');
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20101,
                              '拆机失败. 产品实例id: ' || V_PROD_INST.PROD_INST_ID ||
                              CHR(13) || SUBSTR(SQLERRM,1,1000));
  END;

  /*
      根据订单流水号, 判断是否可以划拨
      0--成功 1--失败
      Author  : zhenggw
      Created : 2012-03-07
  */
FUNCTION FUNC_CHECK_ORDER_ITEM_INFO(IN_ORDER_ITEM_ID IN NUMBER,
                                      OUT_ERR_MSG      OUT VARCHAR2)
    RETURN NUMBER IS
    -- PRAGMA AUTONOMOUS_TRANSACTION;  crm00053713
    V_CONFIG_COUNT  NUMBER := 0; --可选包产品是否有配置关系
    V_PROD_OFFER_ID NUMBER := 0;
    V_OFFER_SUB_TYPE varchar2(30):='';
    V_PROD_OFFER_EXPIRE_TYPE varchar2(30):='';
    V_COUNT                  NUMBER(10);
    AN_FLAG                  NUMBER := 0;
    V_PROD_OFFER_INST_ID     NUMBER(12);
    V_REL_PROD_INST_ID       NUMBER(12);
    V_REL_PROD_OFFER_INST_ID NUMBER(12);
    NEW_FLAG                 NUMBER := 0;
    XD_FLAG                  NUMBER := 0;

    V_OFFER_EXP_DATE DATE; --套餐失效时间

    V_ORDER_ITEM_STATUS_CD varchar2(30) := ''; --订单项状态

    V_SERVICE_OFFER_ID varchar2(30) := ''; --订单项动作
    V_CNT              NUMBER(10) := 0;
  BEGIN
    --续订单
    SELECT DECODE(COUNT(*), 1, 1, 0)
      INTO XD_FLAG
      FROM ORDER_ITEM OI, CUSTOMER_ORDER CO
     WHERE OI.CUST_ORDER_ID = CO.CUST_ORDER_ID
       AND OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
       AND CO.STATUS_CD = '101300'
       AND OI.SERVICE_OFFER_ID = '502';
    --订购单
    SELECT DECODE(COUNT(*), 1, 1, 0)
      INTO NEW_FLAG
      FROM ORDER_ITEM_HIS OI
     WHERE OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
       AND (OI.SERVICE_OFFER_ID = '500' OR OI.SERVICE_OFFER_ID = '502');

    IF (XD_FLAG = 0 AND NEW_FLAG = 0) THEN
      select DECODE(COUNT(*), 1, 1, 0)
        INTO V_CNT
        from ORDER_ITEM A
       WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;

      IF V_CNT > 0 THEN
        select A.STATUS_CD, A.SERVICE_OFFER_ID
          INTO V_ORDER_ITEM_STATUS_CD, V_SERVICE_OFFER_ID
          from ORDER_ITEM A
         WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 续订单订单项状态要求为101300，订单动作要求为502；' ||
                       '而目前订单项的状态为' || V_ORDER_ITEM_STATUS_CD || ',订单项的动作为' ||
                       V_SERVICE_OFFER_ID;
      ELSE
        select DECODE(COUNT(*), 1, 1, 0)
          INTO V_CNT
          from ORDER_ITEM_HIS A
         WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
        IF V_CNT > 0 THEN
          select A.STATUS_CD, A.SERVICE_OFFER_ID
            INTO V_ORDER_ITEM_STATUS_CD, V_SERVICE_OFFER_ID
            from ORDER_ITEM_HIS A
           WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
          OUT_ERR_MSG := IN_ORDER_ITEM_ID ||
                         ' 订购单订单项状态要求为300000，订单动作要求为500；' || '而目前订单项的状态为' ||
                         V_ORDER_ITEM_STATUS_CD || ',订单项的动作为' ||
                         V_SERVICE_OFFER_ID;

        END IF;
      END IF;
      IF  V_CNT=0 THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 订单项ID有误,不存在该订单项';
      END IF;
/*      insert into proc_log
      values
        ('ORDER_ITEM',
         'ORDER_ITEM_ID',
         OUT_ERR_MSG,
         sysdate,
         IN_ORDER_ITEM_ID);*/
      -- commit; crm00052306
      RETURN 1;
    END IF;

    IF (XD_FLAG = 1) THEN
      --续订单
      --找订单关联的可选包销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID, POI.EXP_DATE, poi.prod_offer_id
          INTO V_PROD_OFFER_INST_ID, V_OFFER_EXP_DATE, V_PROD_OFFER_ID
          FROM ORDER_ITEM O, PROD_OFFER_INST POI
         WHERE O.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
           AND O.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
           --crm00060286 对于销售品的关联限定只找销售品 zhenglzh
           AND O.ORDER_ITEM_CD = '1200';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到订单项关联的可选包实例，不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306

          RETURN 1;
      END;
      --找可选包关联的销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID
          INTO V_REL_PROD_OFFER_INST_ID
          FROM PROD_OFFER_INST_REL POIR, PROD_OFFER_INST POI, PROD_OFFER PO
         WHERE POIR.RELA_PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
           AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
           AND POIR.RELATED_PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
           AND PO.OFFER_SUB_TYPE IN ('T01', 'T05');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到可选包关联的销售品实例，不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
      END;

      select count(*)
        into V_CONFIG_COUNT
        from  offer_prod_rel a
       where a.prod_offer_id = V_PROD_OFFER_ID
         and a.status_cd = 1000;
      --找可选包关联的产品实例
    if V_CONFIG_COUNT>0 then
     BEGIN
        SELECT PI.PROD_INST_ID
          INTO V_REL_PROD_INST_ID
          FROM OFFER_PROD_INST_REL OPIR, PROD_INST PI, PRODUCT P
         WHERE OPIR.PROD_INST_ID = PI.PROD_INST_ID
           AND PI.PRODUCT_ID = P.PRODUCT_ID
           AND P.PROD_FUNC_TYPE = '101'
           AND OPIR.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID;
      EXCEPTION
        WHEN OTHERS THEN
          OUT_ERR_MSG := SUBSTR(SQLERRM,1,1000) || '';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
           RETURN 1;
      END;
    end if;
      --判断订单项是可选包，且是充值开通
      SELECT DECODE(COUNT(*), 0, 0, 1)
        INTO AN_FLAG
        FROM ORDER_ITEM      OI,
             ACCT_ITEM       AI,
             PROD_OFFER_INST POI,
             PROD_OFFER      PO
       WHERE OI.ORDER_ITEM_ID = AI.ORDER_ITEM_ID
         AND OI.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
         AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
         AND AI.CHARGE_METHOD = '140101'
         AND PO.OFFER_SUB_TYPE = 'T04'
         AND OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
         --crm00060286 对于销售品的关联限定只找销售品 zhenglzh
         AND OI.ORDER_ITEM_CD = '1200';
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包不是充值开通的付款方式';
/*        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);*/
        -- commit; crm00052306
        RETURN 1;
      END IF;
      --判断套餐是否已经过了失效期
      --查询输入的年缴套餐是否包含“到期处理方式”（ 属性ID=800002919），
      --如果有，在失效时间再延迟1个月的时间内，计费发起的查询都返回可以划拨
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_OFFER_INST_ATTR A
       WHERE A.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
         AND A.ATTR_ID = 800002919;--800002919: xm_宽带续约标识专用
      IF V_COUNT > 0 THEN
        --失效时间再延迟1个月
        V_OFFER_EXP_DATE := ADD_MONTHS(V_OFFER_EXP_DATE, 1);
      END IF;

      IF V_OFFER_EXP_DATE < SYSDATE THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 套餐已经过了失效期';

/*        insert into proc_log
        values
          ('PROD_OFFER_INST',
           'PROD_OFFER_INST_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);*/
        -- commit; crm00052306
        RETURN 1;
      END IF;

      --可选包有关联的产品实例需要判断关联产品实例的状态
      IF V_REL_PROD_INST_ID IS NOT NULL THEN
        --关联产品处于停机不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '120000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于停机不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
        --关联产品处于未激活(预开通)不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '140000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于未激活(预开通)不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
        --关联产品的订单处于撤销中不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.STATUS_CD = '401399'
           --crm00060286 对于产品实例的关联限定只找产品实例 zhenglzh
           AND OI.ORDER_ITEM_CD = '1300';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品订单撤销中不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
        --关联产品存在拆机单不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.SERVICE_OFFER_ID = '101'
           --crm00060286 对于产品实例的关联限定只找产品实例 zhenglzh
           AND OI.ORDER_ITEM_CD = '1300';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品存在拆机单不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
      END IF;
      --可选包关联的销售品处于退订中不能发起
      SELECT DECODE(COUNT(*), 0, 1, 0)
        INTO AN_FLAG
        FROM PROD_OFFER_INST POI, ORDER_ITEM OI
       WHERE POI.PROD_OFFER_INST_ID = OI.ORDER_ITEM_OBJ_ID
         AND PROD_OFFER_INST_ID = V_REL_PROD_OFFER_INST_ID
         AND OI.SERVICE_OFFER_ID = '501'
         --crm00060286 对于销售品的关联限定只找销售品 zhenglzh
         AND OI.ORDER_ITEM_CD = '1200';
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联的销售品处于退订中不能发起';
/*        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);*/
        -- commit; crm00052306
        RETURN 1;
      END IF;

      RETURN 0;
    END IF;
    IF (NEW_FLAG = 1) THEN
      --订购单
      --找订单关联的可选包销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID, POI.EXP_DATE, poi.prod_offer_id,po.offer_sub_type,po.expire_type
          INTO V_PROD_OFFER_INST_ID, V_OFFER_EXP_DATE, V_PROD_OFFER_ID,V_OFFER_SUB_TYPE,V_PROD_OFFER_EXPIRE_TYPE
          FROM ORDER_ITEM_HIS O, PROD_OFFER_INST POI,prod_offer po
         WHERE O.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
           AND O.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
           and po.prod_offer_id=poi.prod_offer_id
           --crm00060286 对于销售品的关联限定只找销售品 zhenglzh
     AND O.ORDER_ITEM_CD = '1200';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到订单项关联的可选包实例，不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
      END;
      /*如果是竣工后立即失效的可选包，直接返回成功 crm00045420 */
      IF V_PROD_OFFER_EXPIRE_TYPE ='3' THEN
         RETURN 0;
      END IF;
        /*如果是T01，是充值开通 直接返回成功*/
      IF V_OFFER_SUB_TYPE ='T01' THEN

       --判断订单项是可选包，且是充值开通
      SELECT DECODE(COUNT(*), 0, 0, 1)
        INTO AN_FLAG
        FROM
             PROD_OFFER_INST POI
       WHERE POI.PROD_OFFER_INST_ID =V_PROD_OFFER_INST_ID
       AND POI.EFF_DATE=POI.EXP_DATE
       AND POI.EFF_DATE IS NOT NULL ;
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 销售品不是充值开通的付款方式';
/*        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);*/
        -- commit; crm00052306
        RETURN 1;
      END IF;
      RETURN 0;

      END IF;


      --找可选包关联的销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID
          INTO V_REL_PROD_OFFER_INST_ID
          FROM PROD_OFFER_INST_REL POIR, PROD_OFFER_INST POI, PROD_OFFER PO
         WHERE POIR.RELA_PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
           AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
           AND POIR.RELATED_PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
           AND PO.OFFER_SUB_TYPE IN ('T01', 'T05');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到可选包关联的销售品实例，不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
      END;
            select count(*)
        into V_CONFIG_COUNT
        from offer_prod_rel a
       where a.prod_offer_id = V_PROD_OFFER_ID
         and a.status_cd = 1000;
      --找可选包关联的产品实例
    if V_CONFIG_COUNT>0 then

      --找可选包关联的产品实例
      BEGIN
        SELECT PI.PROD_INST_ID
          INTO V_REL_PROD_INST_ID
          FROM OFFER_PROD_INST_REL OPIR, PROD_INST PI, PRODUCT P
         WHERE OPIR.PROD_INST_ID = PI.PROD_INST_ID
           AND PI.PRODUCT_ID = P.PRODUCT_ID
           AND P.PROD_FUNC_TYPE = '101'
           AND OPIR.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID;
      EXCEPTION
        WHEN OTHERS THEN
          OUT_ERR_MSG := SUBSTR(SQLERRM,1,1000) || '';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
    RETURN 1;
       END;
      end if;
      --判断订单项是可选包，且是充值开通
      SELECT DECODE(COUNT(*), 0, 0, 1)
        INTO AN_FLAG
        FROM ORDER_ITEM_HIS OI, ACCT_ITEM_HIS AI, PROD_OFFER_INST POI, PROD_OFFER PO
       WHERE OI.ORDER_ITEM_ID = AI.ORDER_ITEM_ID
         AND OI.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
         AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
         AND AI.CHARGE_METHOD = '140101'
         AND PO.OFFER_SUB_TYPE = 'T04'
         AND POI.EFF_DATE = POI.EXP_DATE
         AND OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
         --crm00060286 对于销售品的关联限定只找销售品 zhenglzh
   AND OI.ORDER_ITEM_CD = '1200';
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包不是充值开通的付款方式';
/*        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);*/
        -- commit; crm00052306
        RETURN 1;
      END IF;
      --判断套餐是否已经过了失效期
      --查询输入的年缴套餐是否包含“到期处理方式”（ 属性ID=800002919），
      --如果有，在失效时间再延迟1个月的时间内，计费发起的查询都返回可以划拨
      --与曾翔确认，新装的不需要此逻辑crm00049220
      /*SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_OFFER_INST_ATTR A
       WHERE A.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
         AND A.ATTR_ID = 800002919;--800002919: xm_宽带续约标识专用
      IF V_COUNT > 0 THEN
        --失效时间再延迟1个月
        V_OFFER_EXP_DATE := ADD_MONTHS(V_OFFER_EXP_DATE, 1);
      END IF;*/

      IF V_OFFER_EXP_DATE < SYSDATE THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 套餐已经过了失效期';
/*        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);*/
        -- commit; crm00052306
        RETURN 1;
      END IF;

      --可选包有关联的产品实例需要判断关联产品实例的状态
      IF V_REL_PROD_INST_ID IS NOT NULL THEN
        --关联产品处于停机不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '120000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于停机不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
        --关联产品处于未激活(预开通)不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '140000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于未激活(预开通)不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
        --关联产品的订单处于撤销中不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.STATUS_CD = '401399'
           --crm00060286 对于产品实例的关联限定只找产品实例 zhenglzh
           AND OI.ORDER_ITEM_CD = '1300';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品订单撤销中不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
        --关联产品存在拆机单不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.SERVICE_OFFER_ID = '101'
           --crm00060286 对于产品实例的关联限定只找产品实例 zhenglzh
           AND OI.ORDER_ITEM_CD = '1300';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品存在拆机单不能发起';
/*          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);*/
          -- commit; crm00052306
          RETURN 1;
        END IF;
      END IF;
      --可选包关联的销售品处于退订中不能发起
      SELECT DECODE(COUNT(*), 0, 1, 0)
        INTO AN_FLAG
        FROM PROD_OFFER_INST POI, ORDER_ITEM OI
       WHERE POI.PROD_OFFER_INST_ID = OI.ORDER_ITEM_OBJ_ID
         AND PROD_OFFER_INST_ID = V_REL_PROD_OFFER_INST_ID
         AND OI.SERVICE_OFFER_ID = '501'
         --crm00060286 对于销售品的关联限定只找销售品 zhenglzh
   AND OI.ORDER_ITEM_CD = '1200';
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联的销售品处于退订中不能发起';
/*        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);*/
        -- commit; crm00052306
        RETURN 1;
      END IF;

       --可选包处于退订中不能发起
      SELECT DECODE(COUNT(*), 0, 1, 0)
        INTO AN_FLAG
        FROM PROD_OFFER_INST POI, ORDER_ITEM OI
       WHERE POI.PROD_OFFER_INST_ID = OI.ORDER_ITEM_OBJ_ID
         AND PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
         AND OI.SERVICE_OFFER_ID = '501'
         --crm00060286 对于销售品的关联限定只找销售品 zhenglzh
   AND OI.ORDER_ITEM_CD = '1200';
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包处于退订中不能发起';
        RETURN 1;
      END IF;

      RETURN 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 其它未知错误' || SUBSTR(SQLERRM,1,1000);
/*      insert into proc_log
      values
        ('ORDER_ITEM',
         'ORDER_ITEM_ID',
         OUT_ERR_MSG,
         sysdate,
         IN_ORDER_ITEM_ID);*/
      -- commit; crm00052306
      RETURN 1;
  END;


  PROCEDURE PROC_INVOICE_UPDATE(I_INVOICE_CODE IN VARCHAR2, --发票代码
                                I_INVOICE_NUM  IN VARCHAR2, --发票号码
                                I_STATE        IN VARCHAR2, --状态
                                O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                                O_ERR_MSG      OUT VARCHAR2) is
    PRAGMA AUTONOMOUS_TRANSACTION; --实现自治事务处理
    V_MKT_RESO_ID NUMBER;
  BEGIN
    SELECT NVL(MAX(A.MKT_RESO_ID), 0)
      INTO V_MKT_RESO_ID
      FROM MKT_RESOURCE A
     WHERE A.MKT_RESO_SPEC_TYPE = '610007666'
       AND A.MKT_RESO_KEY =
           CONCAT(CONCAT(I_INVOICE_CODE, ';'), I_INVOICE_NUM);
    IF V_MKT_RESO_ID = 0 THEN
      O_ERR_CODE := '1'; --失败返回值
      O_ERR_MSG  := '未找到对应记录';
    ELSE
      UPDATE MKT_RESOURCE A
         SET A.STATE            = I_STATE,
             A.REAL_MODIFY_DATE = SYSDATE,
             REMARKS            = REMARKS || '计费更新状态'
       WHERE A.MKT_RESO_ID = V_MKT_RESO_ID;
      COMMIT;
      O_ERR_CODE := '0'; --成功返回值
      O_ERR_MSG  := '更新成功';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_CODE := '1'; --失败返回值
      O_ERR_MSG := SUBSTR(SQLERRM,1,1000);
      ROLLBACK;
  END PROC_INVOICE_UPDATE;

  --密码验证
  FUNCTION FUNC_PASSWORD_CHECK(I_AREA_CODE  IN VARCHAR2, --区号，如福州0591
                               I_PRODUCT_ID IN NUMBER, --产品规格编码，如普通电话800000000，移动语音800000002
                               I_ACC_NBR    IN VARCHAR2, --业务号码，如有线宽带5910480051105、移动语音18959190160
                               I_PWD        IN VARCHAR2, --密码值（明文），验证顺序统一密码-->帐号密码-->密码，三个都未找到对应返回失败
                               O_ERR_MSG    OUT VARCHAR2) --错误信息
   RETURN NUMBER IS
    ---0 验证成功 1 失败或异常
    V_COUNT        NUMBER;
    V_PROD_INST_ID NUMBER(12);
    V_RESULT       NUMBER;
    V_DESSTR       VARCHAR2(64); --加密值
    V_ATTR_VALUE   VARCHAR2(64);
  BEGIN
    IF I_AREA_CODE IS NULL OR I_PRODUCT_ID IS NULL OR I_ACC_NBR IS NULL OR
       I_PWD IS NULL THEN
      O_ERR_MSG := '输入不正确，不能为空！';
      RETURN 1;
    END IF;
    --验证档案是否正确
    SELECT COUNT(*)
      INTO V_COUNT
      FROM PROD_INST
     WHERE AREA_CODE = I_AREA_CODE
       AND PRODUCT_ID = I_PRODUCT_ID
       AND ACC_NBR = I_ACC_NBR
       AND STATUS_CD <> '110000';
    IF V_COUNT > 0 THEN
      SELECT PROD_INST_ID
        INTO V_PROD_INST_ID
        FROM PROD_INST
       WHERE AREA_CODE = I_AREA_CODE
         AND PRODUCT_ID = I_PRODUCT_ID
         AND ACC_NBR = I_ACC_NBR
         AND STATUS_CD <> '110000'
         AND ROWNUM = 1;
      --验证统一密码(已加密）
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR
       WHERE STATUS_CD = '1000'
         AND ATTR_ID = '800004515'
         AND PROD_INST_ID = V_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        SELECT ATTR_VALUE
          INTO V_ATTR_VALUE
          FROM PROD_INST_ATTR
         WHERE STATUS_CD = '1000'
           AND ATTR_ID = '800004515'
           AND PROD_INST_ID = V_PROD_INST_ID
           AND ROWNUM = 1;
        --输入密码可逆加密
        PKG_UTIL.PROC_ENCRY_NEW(I_PWD, V_DESSTR, V_RESULT, O_ERR_MSG);
        IF V_RESULT = 0 AND V_DESSTR = V_ATTR_VALUE THEN
          O_ERR_MSG := '统一密码验证成功！';
          RETURN 0;
        END IF;
      END IF;

      --验证帐号密码(已加密）
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR
       WHERE STATUS_CD = '1000'
         AND ATTR_ID = '800000329'
         AND PROD_INST_ID = V_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        SELECT ATTR_VALUE
          INTO V_ATTR_VALUE
          FROM PROD_INST_ATTR
         WHERE STATUS_CD = '1000'
           AND ATTR_ID = '800000329'
           AND PROD_INST_ID = V_PROD_INST_ID
           AND ROWNUM = 1;
        --帐号密码可逆加密
        PKG_UTIL.PROC_ENCRY_NEW(I_PWD, V_DESSTR, V_RESULT, O_ERR_MSG);
        IF V_RESULT = 0 AND V_DESSTR = V_ATTR_VALUE THEN
          O_ERR_MSG := '帐号密码验证成功！';
          RETURN 0;
        END IF;
      END IF;

      --验证密码(已加密）
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_INST_ATTR
       WHERE STATUS_CD = '1000'
         AND ATTR_ID = '800000366'
         AND PROD_INST_ID = V_PROD_INST_ID;
      IF V_COUNT > 0 THEN
        SELECT ATTR_VALUE
          INTO V_ATTR_VALUE
          FROM PROD_INST_ATTR
         WHERE STATUS_CD = '1000'
           AND ATTR_ID = '800000366'
           AND PROD_INST_ID = V_PROD_INST_ID
           AND ROWNUM = 1;
        --密码MD5加密
        PKG_UTIL.PROC_USER_ENCRYPT(I_PWD, V_DESSTR);
        IF V_DESSTR = V_ATTR_VALUE THEN
          O_ERR_MSG := '密码验证成功！';
          RETURN 0;
        END IF;
      END IF;

    ELSE
      O_ERR_MSG := '号码不存在！';
      RETURN 1;
    END IF;
    O_ERR_MSG := '密码验证失败！';
    RETURN 1;
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_MSG := '异常错误：' || SUBSTR(SQLERRM,1,1000);
      RETURN 1;
  END;

  PROCEDURE PROC_CRM_IVPNNBR_UPDATE(I_REC_ID    IN NUMBER,
                                    I_OLD_STATE IN VARCHAR2,
                                    I_NEW_STATE IN VARCHAR2,
                                    O_ERR_CODE  OUT NUMBER, --错误编码（0--成功 1--失败）
                                    O_ERR_MSG   OUT VARCHAR2) IS
    /*crm00025421    需求单    子单_OCS用户切换到HB用户余额费用转移的需求_后台
    后台编写一个存储过程Update_ivpnnbr_forjf，供计费BILL用户调用，
    用来修改ivpn_nbr表的state状态；由计费传入rec_id，old_state,new_state;
    传出参数：result；CRM根据计费传入的rec_id(IVPN_NBR表的主键),
    修改ivpn_nbr表的state，由old_state改为new_state;
    若old_state无法匹配或查不到对应记录，则返回修改失败标志给计费result=1；
    若修改成功，则返回结果为修改成功result=0;存储过程内部不做提交，
    由计费段保持事务处理一致；*/
    V_COUNT NUMBER;
  BEGIN
    SELECT COUNT(*)
      INTO V_COUNT
      FROM IVPN_NBR
     WHERE REC_ID = I_REC_ID
       AND NVL(STATUS_CD, 'NULL') = I_OLD_STATE;
    IF V_COUNT = 0 THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '查不到对应记录！';
      RETURN;
    END IF;
    IF I_NEW_STATE = 'NULL' THEN
      UPDATE IVPN_NBR
         SET STATUS_CD = NULL
       WHERE REC_ID = I_REC_ID
         AND NVL(STATUS_CD, 'NULL') = I_OLD_STATE;
    ELSE
      UPDATE IVPN_NBR
         SET STATUS_CD = I_NEW_STATE
       WHERE REC_ID = I_REC_ID
         AND NVL(STATUS_CD, 'NULL') = I_OLD_STATE;
    END IF;
    O_ERR_CODE := 0;
    O_ERR_MSG  := '处理成功！';
  EXCEPTION
    WHEN OTHERS THEN
      O_ERR_CODE := 1;
      O_ERR_MSG  := '异常信息：' || SUBSTR(SQLERRM,1,1000);
  END;

  FUNCTION FUNC_BILLCZKT_OFFER_CHECK(VO_PROD_OFFER_ID IN NUMBER)
           RETURN NUMBER IS
           VO_PZ_PROD_OFFER_ID number;
           ---0 不存在 1 存在
           BEGIN
           FOR VO_PZ_PROD_OFFER_ID IN (select av.attr_value
                                from attr_spec  asp,
                                     attr_value av
                               where asp.attr_id = av.attr_id
                                 and asp.class_id = -99
                                 and asp.status_cd = '1000'
                                 and av.status_cd = '1000'
                                 and asp.java_code = 'BILLCZKT_OFFER') LOOP
                                 if VO_PZ_PROD_OFFER_ID.attr_value = VO_PROD_OFFER_ID then
                                    return 1;
                                  end if;
            END LOOP;
                RETURN 0;
   END;

   FUNCTION FUNC_BILLCZKT_EXP_MONTH(VO_PROD_OFFER_ID IN NUMBER)
     RETURN NUMBER IS
     unit_valid PROD_OFFER.DEFAULT_UNIT_VALID%TYPE;
     time_period PROD_OFFER.DEFAULT_TIME_PERIOD%TYPE;
     begin
       select po.default_unit_valid,po.default_time_period into unit_valid,time_period  from prod_offer po where po.prod_offer_id = VO_PROD_OFFER_ID;
       if unit_valid = '0' then --年
         return time_period*12;
         end if;
       if unit_valid = '1' then --月
           return time_period;
        end if;
        if unit_valid = '2' then --日
             return time_period/30;
        end if;
    end;

END PKG_HB;
/
