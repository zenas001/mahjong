CREATE PACKAGE BODY           PKG_MARK_DEL_100M is

  PROCEDURE PKG_MARK_DEL IS
    V_AREA_NBR                 varchar2(50);
    count_num                  number;
    temp_cust_external_attr_id number;
    temp_cust_id               number;
    CURSOR prod_inst_attr IS
      select pia.prod_inst_id, pia.prod_inst_attr_id, rownum
        from prod_inst_attr pia
       where pia.attr_id = 800082042
         and exists (select 1
                from crmv2.prod_inst_attr piaa
               where piaa.prod_inst_id = pia.prod_inst_id
                 and piaa.attr_value_id = 800000431);
  begin
    for cur in prod_inst_attr loop
      --区域
      SELECT A.AREA_NBR
        INTO V_AREA_NBR
        FROM AREA_CODE A, COMMON_REGION B, PROD_INST C
       WHERE A.REGION_ID = B.COMMON_REGION_ID
         AND B.COMMON_REGION_ID = C.AREA_ID
         AND C.PROD_INST_ID = cur.prod_inst_id;

      delete from prod_inst_attr pia
       where pia.prod_inst_attr_id = cur.prod_inst_attr_id;
      pkg_common.PROC_INTF_INS_BILLING_UPDATE('PROD_INST_ATTR',
                                              'PROD_INST_ATTR_ID',
                                              cur.prod_inst_attr_id,
                                              '有线宽带实际速率等于100M,产品上不需要打标,问题单号:crm00077315',
                                              '1002',
                                              '有线宽带实际速率等于100M,产品上不需要打标,问题单号:crm00077315',
                                              '',
                                              V_AREA_NBR);
      select count(1)
        into count_num
        from prod_inst pi, cust_external_attr c
       where pi.owner_cust_id = c.cust_id
         and pi.prod_inst_id = cur.prod_inst_id
         and c.attr_id = 800082045;
      if count_num > 0 then
        select c.cust_external_attr_id, c.cust_id
          into temp_cust_external_attr_id, temp_cust_id
          from prod_inst pi, cust_external_attr c
         where pi.owner_cust_id = c.cust_id
           and pi.prod_inst_id = cur.prod_inst_id
           and c.attr_id = 800082045;

        --区域
        SELECT A.AREA_NBR
          INTO V_AREA_NBR
          FROM AREA_CODE A, COMMON_REGION B, CUST C
         WHERE A.REGION_ID = B.COMMON_REGION_ID
           AND B.COMMON_REGION_ID = C.AREA_ID
           AND C.CUST_ID = temp_cust_id;

        delete from cust_external_attr c
         where c.cust_external_attr_id = temp_cust_external_attr_id;
        pkg_common.PROC_INTF_INS_BILLING_UPDATE('CUST_EXTERNAL_ATTR',
                                                'CUST_EXTERNAL_ATTR_ID',
                                                temp_cust_external_attr_id,
                                                '有线宽带实际速率等于100M,客户上不需要打标,问题单号:crm00077315',
                                                '1002',
                                                '有线宽带实际速率等于100M,客户上不需要打标,问题单号:crm00077315',
                                                '',
                                                V_AREA_NBR);
      end if;
      IF MOD(cur.rownum, 1000) = 0 then
        COMMIT;
      END if;
      COMMIT;
    end loop;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  end PKG_MARK_DEL;

END PKG_MARK_DEL_100M;
/
