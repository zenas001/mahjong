CREATE package           PKG_PPM is

  -- Author  : chenjy
  -- Created : 2014/8/22
  -- Purpose : ppm


  /* ppm 插入两级编码映射 */
  PROCEDURE PROC_INTF_DEP_CODE_MAP(
                      I_OBJECT_TYPE   IN VARCHAR2,--对象类型  0100：产品规格编码 0200销售品规格编码：0300：营销资源细类编码
                      I_CHANNEL_NBR IN VARCHAR2,--渠道编码
                      I_SOURCE_CODE IN VARCHAR2,--源系统编码
                      I_SOURCE_NAME IN VARCHAR2,--源系统编码名称
                      I_TARGET_CODE IN VARCHAR2,--目标系统编码
                      I_TARGET_NAME IN VARCHAR2,--目标系统编码名称
                      I_IS_DEFAULT IN VARCHAR2,--存在一对多映射时,默认选择这条映射. 1: 默认, NULL: 不默认
                      I_OBJECT_NBR IN VARCHAR2,--产品编码（以业务部门为准
                      O_RESULT      OUT VARCHAR2--执行结果
                     );
 PROCEDURE PROC_PPM_SYNC_PCRF_CFG (I_PROD_OFFER_ID    IN VARCHAR2,
                                  I_PROD_OFFER_NAME  IN VARCHAR2,
                                  I_EXT_OFFER_NBR    IN VARCHAR2,
                                  O_RESULT           OUT VARCHAR2,  --TRUE成功 FALSE失败
                                  O_MSG              OUT VARCHAR2) ;


 -- Author  : XIELY-FFCS
 -- Created : 2015/1/4 10:44:58
 -- Purpose : PKG_PPM
PROCEDURE PROC_PPM_SYNC_ATTR_AUTO_ADD(I_PROD_OFFER_ID   IN VARCHAR2,
                                      I_PROD_OFFER_NAME IN VARCHAR2,
                                      I_ATTR_ID         IN VARCHAR2,
                                      I_ATTR_DESC       IN VARCHAR2,
                                      O_RESULT          OUT VARCHAR2, --TRUE成功 FALSE失败
                                      O_MSG             OUT VARCHAR2 --失败信息
                                      );
-- Author  : LINQF
-- Created : 2015/5/12 10:44:58
-- Purpose : PKG_PPM
PROCEDURE SYNC_OFFER_TO_CRM_TEST(I_PROD_OFFER_ID   IN VARCHAR2,
                                 I_REMARK IN VARCHAR2,
                                 O_RESULT          OUT VARCHAR2, --TRUE成功 FALSE失败
                                 O_MSG             OUT VARCHAR2 --失败信息
                                 );
-- Author  : LINXI
-- Created : 2015/6/1 10:01:58
-- Purpose : PKG_PPM
PROCEDURE SYNC_OFFER_MLTZ_TO_CRM(I_PROD_OFFER_ID   IN VARCHAR2,
                                 I_REMARK IN VARCHAR2,
                                 i_offer_catlg_loc_id IN VARCHAR2,
                                 O_RESULT          OUT VARCHAR2, --TRUE成功 FALSE失败
                                 O_MSG             OUT VARCHAR2 --失败信息
                                 );
end PKG_PPM;
/
