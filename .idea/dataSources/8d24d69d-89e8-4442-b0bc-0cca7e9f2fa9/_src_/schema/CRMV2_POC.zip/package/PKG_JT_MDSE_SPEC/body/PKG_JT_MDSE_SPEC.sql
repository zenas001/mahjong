CREATE package body           PKG_JT_MDSE_SPEC is

PROCEDURE saveLocalSpecToJtMdse(i_localspecId    in number,      --CRM本地规格
                                                  i_parentNodeId   in number,      --集团树父节点
                                                  i_staff          in VARCHAR2,      --受理工号
                                                  o_return    out number,      --成功标识
                                                  o_nodeid    out number,      --新创建的节点标识
                                                  str_msg     out VARCHAR2) is
  cnt                   number;
  l_catalogid           number;                --目录树ID
  v_parentnodecode        varchar2(40);        --父节点code
  v_jtmdsemaxcode         varchar2(40);        --目录下的最大节点
  v_newjtmdsecode         varchar2(40);        --新的销售品节点
  v_begincode             varchar2(40);        --编码前缀
  v_parentbegincode             varchar2(40);        --目录编码前缀
  l_parentcodelength      number;             --目录编码长度
  l_zero                  number;              --新节点的0长度
  i                       number;              --循环变量
  v_jtmdsetype            varchar2(6);        --集团销售品的类型
  v_localmdsetype            varchar2(6);        --本地销售品的类型
  v_jtmdsename            varchar2(100);        --集团销售品名称 与CRM销售品名称一致
  l_jtmdsespecid          number;             --集团销售品规格
  l_jtmdsenodeid          number;             --集团销售品目录节点ID
begin
  o_return:=0;
  o_nodeid:=0;
  select count('x') into cnt from jt_mdse_spec_mapping where local_spec_id=i_localspecId;
  if cnt>0 then
    str_msg :='该本地销售品已有映射的集团销售品,无法添加';
    return;
  end if;
  --1.获取mdse_node.catalog_id
  begin
   select code,catalog_id into v_parentnodecode,l_catalogid from mdse_node where node_id=i_parentNodeId and type='0' and catalog_id in(select cat_id from mdse_catalog_spec where type='6');
  exception
    when no_data_found then
      str_msg :='父节点有误,请重新放置';
      return;
  end;

 --2.获取jt_mdse_spec.type 7的话是可选包002、8是促销003、9是政企协议004、其余是销售品001
  v_begincode:= substr(v_parentnodecode, 0,1);
  if v_begincode=7 then
     v_jtmdsetype:='002';
  elsif v_begincode=8 then
     v_jtmdsetype:='003';
  elsif v_begincode=9 then
     v_jtmdsetype:='004';
  else
     v_jtmdsetype:='001';
  end if;

 --3.获取jt_mdse_spec.code值.
   select count('x') --查询当前目录下是否已有销售品
    into cnt
    from mdse_node_rela
   where parent_node_id = i_parentNodeId
     and exists (select 'x'
            from mdse_node n, jt_mdse_spec s
           where n.mdse_spec_id = s.mdse_spec_id
             and n.node_id = mdse_node_rela.node_id)
     and rela_type = '0';
  if cnt>0 then
   --已经有销售品
     select count('x') into cnt from mdse_node
       where node_id in (select node_id from mdse_node_rela where parent_node_id = i_parentNodeId) and type = '0';
     if cnt>0 then
      str_msg :='当前目录非最底层,请重新放置';
      return;
     end if;

     select max(s.code)
      into v_jtmdsemaxcode
      from mdse_node n, mdse_node_rela r, jt_mdse_spec s
     where n.node_id = r.node_id
       and n.mdse_spec_id = s.mdse_spec_id
       and r.parent_node_id = i_parentNodeId
       and rela_type = '0';
     v_newjtmdsecode := to_char(to_number(v_jtmdsemaxcode)+1) ;
  else
   --当前还是空目录
    l_parentcodelength :=length(v_parentnodecode);
    l_zero:=16-l_parentcodelength;
    if l_zero<=0 then
       str_msg :='当前目录的编码异常,请确认是否变更目录';
       return;
    end if;
    v_newjtmdsecode:=to_char(to_number(v_parentnodecode)*10);
    for i in 1 .. l_zero-1 loop
     v_newjtmdsecode:=to_char(to_number(v_newjtmdsecode)*10);
    end loop;
    v_newjtmdsecode:=to_char(to_number(v_newjtmdsecode)+1) ;
  end if;
  --验证Code是否唯一
  select count('x') into cnt from jt_mdse_spec where code = v_newjtmdsecode;
  if cnt>0 then
   for i in 1.. 100 loop
    v_newjtmdsecode:=to_char(to_number(v_newjtmdsecode)+1);
    select count('x') into cnt from jt_mdse_spec where code = v_newjtmdsecode;
    if cnt=0 then
     exit;
    end if;
   end loop;
   if cnt>0 then
     str_msg :='当前目录的编码重复异常,请确认是否变更目录';
     return;
   end if;
  end if;
 --销售品前5位加入集团校验规则，可选包前3位（促销、政企协议前4位）
  if v_jtmdsetype='001' then
     l_parentcodelength:=5;
  elsif v_jtmdsetype='002' then
     l_parentcodelength:=3;
  else
     l_parentcodelength:=4;
  end if;
     v_parentbegincode:=substr(v_parentnodecode, 0, l_parentcodelength);
     v_begincode := substr(v_newjtmdsecode, 0, l_parentcodelength);
  if v_parentbegincode!=v_begincode then
     str_msg :='新节点的编码超过当前设定的编码,请确认是否变更目录';
     return;
  end if;
 --4.获取jt_mdse_spec.name ,jt_mdse_spec_mapping.LOCAL_SPEC_TYPE
  begin
   select type,name into v_localmdsetype,v_jtmdsename from mdse_spec where mdse_spec_id=i_localspecId;
  exception
    when no_data_found then
      begin
        select type,name into v_localmdsetype,v_jtmdsename from price_plan where price_id=i_localspecId;
      exception
       when no_data_found then
         begin
          select type,name into v_localmdsetype,v_jtmdsename from prefer_price_spec where prefer_spec_id=i_localspecId;
         exception
          when no_data_found then
            str_msg :='当前规格查询不到本地销售品,请确认输入';
            return;
         end;
       end;
   end;
 -- 5.生成数据
 --jt_mdse_spec
  select JT_MDSE_SPEC_ID_SEQ.NEXTVAL into l_jtmdsespecid from dual;
  insert into JT_MDSE_SPEC (MDSE_SPEC_ID, CODE, NAME, TYPE, STAFF_ID, CREATE_DATE, MODIFY_DATE, STATE, REMARK)
    values (l_jtmdsespecid, v_newjtmdsecode, v_jtmdsename, v_jtmdsetype, i_staff, sysdate, null, '70A', null);
 --mdse_node
  select MDSE_SPEC_ID_SEQ.NEXTVAL into l_jtmdsenodeid from dual;
  insert into MDSE_NODE (NODE_ID, CODE, NAME, CATALOG_ID, MDSE_SPEC_ID, TYPE, CREATE_DATE, MODIFY_DATE, STAFF_ID, NODE_ORDER, ALIAS_NAME, ENSURE_LEVEL, APPLY_AREA)
    values (l_jtmdsenodeid, v_newjtmdsecode, v_jtmdsename, l_catalogid, l_jtmdsespecid, v_jtmdsetype, sysdate, null, i_staff, PM_NODE_ORDER_SEQ.Nextval, null, null, null);
 --mdse_node_rela
  insert into MDSE_NODE_RELA (PARENT_NODE_ID, NODE_ID, RELA_TYPE, RELA_ID, NODE_ORDER)
    values (i_parentNodeId, l_jtmdsenodeid, '0', MDSE_NODE_RELA_ID_SEQ.NEXTVAL, 0);
 --jt_mdse_spec_mapping
  insert into JT_MDSE_SPEC_MAPPING (MAPPING_ID, MDSE_SPEC_ID, LOCAL_SPEC_ID, LOCAL_SPEC_TYPE, CREATE_DATE, STATE, REMARK)
    values (JT_MDSE_SPEC_MAPPING_ID_SEQ.NEXTVAL, l_jtmdsespecid,i_localspecId,v_localmdsetype, sysdate, '70A', null);
 --crm_mdse_spec_total
  select count(*) into cnt from crm_mdse_spec_total where mdse_spec_id=i_localspecId;
  if cnt>0 then
    update crm_mdse_spec_total set MAP_FLAG='Y' where mdse_spec_id=i_localspecId;
  end if;

  o_nodeid:=l_jtmdsenodeid;
  o_return:=1;
  str_msg:='生成集团销售品映射数据成功!';
 EXCEPTION
  WHEN OTHERS THEN
    str_msg := 'saveLocalSpecToJtMdse:'||sqlerrm;
end;


PROCEDURE changeLocalSpecCleanState(i_localspecId    in number,      --CRM本地规格
                                                  i_cleanstate   in VARCHAR2,      --清理状态
                                                  o_return    out number,      --成功标识
                                                  str_msg     out VARCHAR2) is --返回信息d
 cnt                   number;
 v_state               VARCHAR2(10);
 v_expdate                date;
 begin
   o_return:=0;
   select count(*) into cnt  from crm_mdse_spec_total where mdse_spec_id=i_localspecId;
   if cnt>0 then
      select nvl(exp_date,sysdate),nvl(state,'70A') into v_expdate,v_state from crm_mdse_spec_total where mdse_spec_id=i_localspecId;
      if(v_expdate<sysdate or v_state='70I') and i_cleanstate='70A' then
        str_msg :='清理状态选择错误,已停售的销售品不能选在售状态';
        return;
      end if;

      update crm_mdse_spec_total set CLAEN_STATUS=i_cleanstate where mdse_spec_id=i_localspecId;
      str_msg :='更改清理状态成功';
      o_return:=1;
      return;
   else
     str_msg :='CRM销售品汇总表未找到对应的数据';
     return;
   end if;
 EXCEPTION
  WHEN OTHERS THEN
    str_msg := 'changeLocalSpecCleanState:'||sqlerrm;
 end;

PROCEDURE delJtMdseToLocalspec(i_jtmdsespecid    in number,      --集团销售品规格
                                                  o_return    out number,      --成功标识
                                                  str_msg     out VARCHAR2) is
  cnt                   number;
  v_catalogid           number;                --目录树ID
  v_nodeid              number;                --集团销售品nodeid
begin
  o_return:=0;

  select count(*) into cnt from jt_mdse_spec where mdse_spec_id=i_jtmdsespecid;
  if cnt=0 then
     str_msg :='要删除的集团销售品不存在,请确认数据';
     return;
  end if;
  --1.获取mdse_node.catalog_id
  begin
   select cat_id into v_catalogid from mdse_catalog_spec where type='6' ;
  exception
    when no_data_found then
      str_msg :='集团销售树有误,请确认数据';
      return;
  end;
  --2.获取mdse_node.node_id
  begin
   select node_id into v_nodeid from mdse_node where catalog_id=v_catalogid and mdse_spec_id=i_jtmdsespecid;
  exception
    when no_data_found then
      str_msg :='集团销售品的节点有误,请确认数据';
      return;
  end;

 --3.删除基础数据
 --jt_mdse_spec
  delete from jt_mdse_spec where mdse_spec_id=i_jtmdsespecid;
 --mdse_node
  delete from mdse_node where node_id=v_nodeid;
 --mdse_node_rela
  delete from mdse_node_rela where node_id=v_nodeid;

 --4.删除映射信息
  BEGIN
      FOR R_PSM IN (SELECT * FROM JT_MDSE_SPEC_MAPPING WHERE MDSE_SPEC_ID=i_jtmdsespecid) LOOP
          --crm_mdse_spec_total
         select count(*) into cnt from jt_mdse_spec_mapping where mdse_spec_id!=i_jtmdsespecid and local_spec_id=R_PSM.local_spec_id;
         if cnt=0 then
           select count(*) into cnt from crm_mdse_spec_total where mdse_spec_id=R_PSM.local_spec_id and MAP_FLAG='Y';
           if cnt>0 then
              update crm_mdse_spec_total set MAP_FLAG='N' where mdse_spec_id=R_PSM.local_spec_id;
           end if;
         end if;
         -- jt_mdse_spec_mapping_attr;
         delete from jt_mdse_spec_mapping_attr where mapping_id =R_PSM.mapping_id;
         -- jt_mdse_spec_mapping
         delete from jt_mdse_spec_mapping where mapping_id =R_PSM.mapping_id;
      END LOOP;
  END;
  o_return:=1;
  str_msg:='删除集团销售品数据成功!';
 EXCEPTION
  WHEN OTHERS THEN
    str_msg := 'delJtMdseToLocalspec:'||sqlerrm;
end;

PROCEDURE getJtMdseFromLocalspec(i_localspecId   in number, --CRM销售品规格
                                 i_keyid         in number, --要映射表的主键
                                 i_agreeid       in number, --协议号
                                 o_jtmdsespecId  out number) is
  --集团销售品规格
  v_localspecId number;
  v_cnt         number;
  v_subcnt      number;
  v_mappingId   number;
begin
  o_jtmdsespecId := 0;
  v_localspecId  := i_localspecId;
  select count(*) into v_cnt from mdse_spec where mdse_spec_id=i_localspecId and type='107';
  if v_cnt>0 then
    select prefer_spec_id
      into v_localspecId
      from prefer_price_spec
     where mdse_spec_id = i_localspecId;
  end if;
  select count(*)
    into v_cnt
    from jt_mdse_spec_mapping
   where local_spec_id = v_localspecId
     and state = '70A';
  if v_cnt = 0 then
    --没有集团销售品映射
    o_jtmdsespecId := 0;
    return;
  elsif v_cnt = 1 then
    --有1条集团销售品映射
    select mapping_id, mdse_spec_id
      into v_mappingId, o_jtmdsespecId
      from jt_mdse_spec_mapping
     where local_spec_id = v_localspecId
       and state = '70A';
    select count(*)
      into v_subcnt
      from jt_mdse_spec_mapping_attr
     where mapping_id = v_mappingId
       and state = '70A';
    if v_subcnt > 0 then
      if (IsMapAttr(v_mappingId, i_keyId,i_agreeid) = 1) then
        return;
      else
        o_jtmdsespecId := 0;
        return;
      end if;
    else
      return;
    end if;
  else
    --有多条集团销售品映射，满足其中一条就可以了
    FOR R_JSM IN (SELECT MDSE_SPEC_ID, MAPPING_ID
                    FROM jt_mdse_spec_mapping
                   where local_spec_id = v_localspecId
                     and state = '70A') LOOP
      if (IsMapAttr(R_JSM.MAPPING_ID, i_keyId,i_agreeid) = 1) then
        o_jtmdsespecId := R_JSM.MDSE_SPEC_ID;
        return;
      end if;
    END LOOP;
  end if;
EXCEPTION
  WHEN OTHERS THEN
    o_jtmdsespecId := 0;
    return;
end;

function IsMapAttr(i_mappingId in number,
                   i_keyId     in number,
                   i_agreeid   in number) return number is
  v_return     number;
  v_cnt        number;
  v_paramvalue VARCHAR2(80);
begin
  v_return := 1; --默认都匹配
  FOR R_JSMA IN (SELECT ATTR_TYPE, ATTR_OBJ, ATTR_VALUE
                   FROM jt_mdse_spec_mapping_attr
                  where mapping_id = i_mappingId
                    and state = '70A') LOOP
    if R_JSMA.ATTR_TYPE = '001' then
      --客户化参数
      if i_keyId = 0 then
        v_return := 0; --主键ID为0，无法查询参数，直接返回不匹配
        return v_return;
      end if;
      select count(*)
        into v_cnt
        from bill.cust_price_plan_param
       where mdse_id = i_keyId;
      if v_cnt = 0 then
        v_return := 0; --无参数，无法匹配参数
        return v_return;
      else
        if i_agreeid > 0 then--如果有传协议号，根据协议号查询
          begin
            select info_val
              into v_paramvalue
              from bill.cust_price_plan_param
             where mdse_id = i_keyId
               and pricing_param_value_id = R_JSMA.ATTR_OBJ
               and agree_id = i_agreeid;
          exception
            when no_data_found then
              begin
                select info_val
                  into v_paramvalue
                  from (select *
                          from bill.cust_price_plan_param
                         where mdse_id = i_keyId
                           and pricing_param_value_id = R_JSMA.ATTR_OBJ
                           and state = '00D'
                         order by state_date desc) a
                 where rownum < 2;
              exception
                when no_data_found then
                  v_return := 0;
                  return v_return;
              end;
          end;
        else
          begin
            select info_val
              into v_paramvalue
              from (select *
                      from bill.cust_price_plan_param
                     where mdse_id = i_keyId
                       and pricing_param_value_id = R_JSMA.ATTR_OBJ
                       and state in ('00A', '00B')
                     order by state_date desc) a
             where rownum < 2;
          exception
            when no_data_found then
              begin
                select info_val
                  into v_paramvalue
                  from (select *
                          from bill.cust_price_plan_param
                         where mdse_id = i_keyId
                           and pricing_param_value_id = R_JSMA.ATTR_OBJ
                           and state = '00D'
                         order by state_date desc) a
                 where rownum < 2;
              exception
                when no_data_found then
                  v_return := 0;
                  return v_return;
              end;
          end;
        end if;
        if v_paramvalue <> R_JSMA.ATTR_VALUE then
          v_return := 0;
          return v_return;
        end if;
      end if;
    end if;
  END LOOP;

  return v_return;
end; --IsYKT

end PKG_JT_MDSE_SPEC;
/
