CREATE PACKAGE BODY           PKG_COUNT_NUMBER2 is
  --全省在网客户，个人有效证件客户（士兵证、警官证、军官证、户口本、身份证、港澳台通行证、护照），
  --一个证件号码名下在用的移动语音、无线宽带、天翼副号、集团一卡双号副号码、一卡双号虚号码
  PROCEDURE PKG_YD_WX IS
    mobile_use_count      number;
    mobile_use_count_temp number;
    mobile_own_count      number;
    party_name            varchar(50);
    cert_mobile_number    number;
    CURSOR party_certification IS
      select p.party_id, p.cert_type, p.cert_number, rownum
        from crmv2.party_certification p
       where p.cert_type in ('1', '2', '3', '4', '12', '14', '22')
       and p.cert_number = '350823199011132615';
  begin
    for cur in party_certification loop
      select count(1)
        into cert_mobile_number
        from crmv2.cert_mobile_num c
       where c.cert_number = cur.cert_number;
      if cert_mobile_number = 0 then
        mobile_own_count      := 0;
        mobile_use_count      := 0;
        mobile_use_count_temp := 0;
        for temp_cur in (Select a.cust_id, rownum
                           From crmv2.Cust                a,
                                crmv2.Prod_Inst           b,
                                crmv2.party_certification pc
                          Where a.Cust_Id = b.Owner_Cust_Id
                            and pc.cert_number = cur.cert_number
                            and b.product_id in
                                (800000002, 800000007, 900283009, 800575119,
                                 901132803)
                            And b.Status_Cd != '110000'
                            And b.Status_Cd != '140000'
                            and a.party_id = pc.party_id
                            and exists
                          (select 1
                                   from crmv2.cust_external_attr c
                                  where c.cust_id = a.cust_id
                                    and c.attr_id = 950023250)) loop
          mobile_own_count := temp_cur.rownum;
          --证件号码有作为产权客户的证件类型是单位有效证件（组织机构代码证、工商营业执照、事业单位法人证件、社会团体法人登记证书、单位证明（含公章））的移动语音产品的使用客户的数量；
          select count(1)
            into mobile_use_count_temp
            from crmv2.prod_inst pi
           where pi.use_cust_id = temp_cur.cust_id
             and pi.product_id in
                 (800000002, 800000007, 900283009, 800575119, 901132803)
             And pi.Status_Cd != '110000'
             And pi.Status_Cd != '140000'
             and exists
           (select 1
                    from crmv2.cust c, crmv2.party_certification pc
                   where c.cust_id = pi.owner_cust_id
                     and c.party_id = pc.party_id
                     and pc.cert_type in ('7', '6', '40', '39', '15'));
          if mobile_use_count_temp > 0 then
            mobile_use_count := mobile_use_count + mobile_use_count_temp;
          end if;
        end loop;
        if mobile_own_count != 0 or mobile_use_count != 0 then
          select p.party_name
            into party_name
            from crmv2.party_certification pc, crmv2.party p
           where p.party_id = pc.party_id
             and pc.cert_number = cur.cert_number
             and p.party_name is not null
             and rownum = 1;
          insert into crmv2.cert_mobile_num
            (CERT_MOBILE_NUM_ID,
             CERT_TYPE,
             CERT_NUMBER,
             CUST_NAME,
             MOBILE_OWNER_NUM,
             MOBILE_USER_NUM,
             CREATE_DATE,
             UPDATE_DATE,
             STATUS_DATE)
          values
            (crmv2.seq_CERT_MOBILE_NUM_ID.nextval,
             cur.cert_type,
             cur.cert_number,
             party_name,
             mobile_own_count,
             mobile_use_count,
             sysdate,
             sysdate,
             sysdate);
        end if;
      end if;
      IF MOD(cur.rownum, 5000) = 0 then
        COMMIT;
      END if;
      COMMIT;
    end loop;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  end PKG_YD_WX;

END PKG_COUNT_NUMBER2;
/
