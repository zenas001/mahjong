CREATE PACKAGE           PKG_YSJH IS

 --PROCEDURE PROC_YSJH_MAIN(v_flag out varchar2);

 PROCEDURE PROC_TASK_INSERT( IO_deal_batch VARCHAR2,   --任务批次
                IO_task_class  VARCHAR2,   --过程代码
                IO_STEP        VARCHAR2,    --总步骤
                IO_cycle_type   VARCHAR2,   --周期类型
                IO_task_cycle   VARCHAR2,   --任务周期  out
                IO_handle_step  VARCHAR2,  --任务步骤  out
                IO_flag         VARCHAR2 );       --处理标志  out
--实物终端参数
 PROCEDURE PROC_NX_CRM_COL_DEF(v_flag out varchar2);
 --与用户相关的通信费用数据表及代理商预存充值费用/代理商押金费用
 PROCEDURE PROC_NX_CRM_SERV_DATA(v_flag out varchar2);
 --与用户无关的--终端、设备费用数据表/与用户无关的--售卡费用数据表
 PROCEDURE PROC_NX_CRM_NOSERV_DATA(v_flag out varchar2);
 --CRM积分兑换费用接口
 PROCEDURE PROC_NX_CRM_POINT_EXCHANGE(v_flag out varchar2);
 --工号与组织关系
 PROCEDURE PROC_NX_CRM_STAFF_ORG(v_flag out varchar2);
END PKG_YSJH;
/
