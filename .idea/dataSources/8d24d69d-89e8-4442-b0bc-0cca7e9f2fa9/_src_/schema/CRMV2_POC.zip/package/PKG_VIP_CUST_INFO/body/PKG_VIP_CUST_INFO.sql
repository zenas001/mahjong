CREATE PACKAGE BODY           pkg_vip_cust_info IS

  FUNCTION func_check_switch_state(table_name       IN VARCHAR2,
                                   o_begin_cycle_id OUT VARCHAR2)
    RETURN BOOLEAN IS
    /*
    功能说明：判断传入的表名在开关表中对应的状态，如果为3则返回True
    编写日期：2012/5/31
    编写人：林志强
    */

    i_flag           NUMBER;
    str_msg          VARCHAR2(2000);
    i_begin_cycle_id VARCHAR2(40);
  BEGIN
    BEGIN
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO i_begin_cycle_id
        FROM  crmv2.doone_int_status_0727 a
       WHERE lower(a.src_table_name) = lower(table_name)
         AND a.area_code = '590';

      o_begin_cycle_id := i_begin_cycle_id;

      SELECT a.flag
        INTO i_flag
        FROM  crmv2.doone_int_status_0727 a
       WHERE lower(a.src_table_name) = lower(table_name)
         AND a.flag = 3
         AND a.begin_cycle_id = i_begin_cycle_id
         AND a.area_code = '590'and  rownum < 2;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval,
           '查询开关状态' || table_name,
           str_msg,
           SYSDATE);
        COMMIT;
        RETURN FALSE;
    END;

    IF i_flag = 3 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END;

  FUNCTION func_insert_member_info_his(i_member_code IN VARCHAR2)
    RETURN BOOLEAN IS
    /*
    功能说明：将info记录插入2表
    编写日期：2012/5/31
    编写人：林志强
    */
    str_msg  VARCHAR2(2000);
    I_HIS_ID NUMBER;
  BEGIN
    BEGIN
      SELECT seq_club_member_info_his_id.nextval INTO I_HIS_ID FROM DUAL;
      INSERT INTO club_member_info_his
        (club_member_info_id,
         member_code,
         membership_level,
         id_card,
         password,
         vip_eff_date,
         vip_exp_date,
         cust_staff,
         vip_card_nbr,
         card_state,
         card_send_date,
         card_exp_date,
         integral_group,
         e_value,
         used_integral,
         curr_integral,
         cycle_curr_integral,
         cycle_used_integral,
         cycle_new_integral,
         assess_date,
         create_staff,
         update_date,
         club_info,
         area_id,
         region_cd,
         vip_area_code,
         vip_area_id,
         his_id)
        (SELECT club_member_info_id,
                member_code,
                membership_level,
                id_card,
                password,
                vip_eff_date,
                vip_exp_date,
                cust_staff,
                vip_card_nbr,
                card_state,
                card_send_date,
                card_exp_date,
                integral_group,
                e_value,
                used_integral,
                curr_integral,
                cycle_curr_integral,
                cycle_used_integral,
                cycle_new_integral,
                assess_date,
                create_staff,
                update_date,
                club_info,
                area_id,
                region_cd,
                vip_area_code,
                vip_area_id,
                I_HIS_ID
           FROM club_member_info a
          WHERE a.member_code = i_member_code);

      /*crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。
      BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CLUB_MEMBER_INFO_HIS',
                                                                            'HIS_ID',
                                                                            I_HIS_ID,
                                                                            'pkg_vip_cust_info 插入历史',
                                                                            '1002',
                                                                            'pkg_vip_cust_info 插入历史',
                                                                            '51447',
                                                                            '590');*/
      /* PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CLUB_MEMBER_INFO_HIS',
      'HIS_ID',
      I_HIS_ID,
      'pkg_vip_cust_info 插入历史',
      '1002',
      'pkg_vip_cust_info 插入历史',
      '51447',
      '590');*/
      ds_ins_intf_ins_ds_update_wh('CLUB_MEMBER_INFO_HIS',
                                   'HIS_ID',
                                   I_HIS_ID,
                                   'pkg_vip_cust_info 插入历史',
                                   '',
                                   'CREATE',
                                   '');
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval,
           '插入积分历史表' || i_member_code,
           str_msg,
           SYSDATE);
        COMMIT;
        RETURN FALSE;
    END;
    RETURN TRUE;
  END;

  FUNCTION func_insert_club_member_his(i_member_code IN VARCHAR2,
                                       i_party_id    IN NUMBER,
                                       i_cust_id     IN NUMBER)
    RETURN BOOLEAN IS
    /*
    功能说明：将clubmember记录插入2表
    编写日期：2012/5/31
    编写人：林志强
    */
    str_msg  VARCHAR2(2000);
    I_HIS_ID NUMBER;
  BEGIN
    BEGIN
      SELECT seq_club_member_id.nextval INTO I_HIS_ID FROM DUAL;

      INSERT INTO club_member_his
        (member_id,
         club_id,
         party_id,
         member_code,
         member_name,
         id_card,
         password,
         membership_level,
         assess_date,
         eff_date,
         exp_date,
         enter_date,
         status_cd,
         status_date,
         create_date,
         update_date,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         cust_staff,
         integral_group,
         e_value,
         used_integral,
         curr_integral,
         cycle_curr_integral,
         cycle_used_integral,
         cycle_new_integral,
         club_info,
         cust_id,
         his_id)
        (SELECT member_id,
                club_id,
                party_id,
                member_code,
                member_name,
                id_card,
                password,
                membership_level,
                assess_date,
                eff_date,
                exp_date,
                enter_date,
                status_cd,
                status_date,
                create_date,
                update_date,
                area_id,
                region_cd,
                update_staff,
                create_staff,
                cust_staff,
                integral_group,
                e_value,
                used_integral,
                curr_integral,
                cycle_curr_integral,
                cycle_used_integral,
                cycle_new_integral,
                club_info,
                cust_id,
                I_HIS_ID
           FROM club_member a
          WHERE a.member_code = i_member_code
            AND a.party_id = i_party_id
            AND a.cust_id = i_cust_id);
      /*crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。
      BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CLUB_MEMBER_HIS',
                                                                          'HIS_ID',
                                                                          I_HIS_ID,
                                                                          'pkg_vip_cust_info 插入历史',
                                                                          '1002',
                                                                          'pkg_vip_cust_info 插入历史',
                                                                          '51447',
                                                                          '590');*/
      /* PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CLUB_MEMBER_HIS',
      'HIS_ID',
      I_HIS_ID,
      'pkg_vip_cust_info 插入历史',
      '1002',
      'pkg_vip_cust_info 插入历史',
      '51447',
      '590');*/
      ds_ins_intf_ins_ds_update_wh('CLUB_MEMBER_HIS',
                                   'HIS_ID',
                                   I_HIS_ID,
                                   'pkg_vip_cust_info 插入历史',
                                   '',
                                   'CREATE',
                                   '');
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval,
           '插入关联历史表' || i_member_code || '-' || i_cust_id,
           str_msg,
           SYSDATE);
        COMMIT;
        RETURN FALSE;
    END;
    RETURN TRUE;
  END;

  FUNCTION func_convert_meta_data(i_vip_level IN VARCHAR2) RETURN VARCHAR2 IS
    /*
    功能说明：将中文级别转化为主数据对应的值
    编写日期：2012/6/7
    编写人：林志强
    */
    return_str VARCHAR2(12);
    in_char    VARCHAR2(20);
  BEGIN
    in_char := i_vip_level;
    /*
    IF in_char = '普通兑换资格'
    THEN
      in_char := '普通';
    END IF;
    */
    BEGIN
      SELECT av.attr_value
        INTO return_str
        FROM attr_value av, attr_spec ap, sys_class sc
       WHERE sc.table_name = 'CLUB_MEMBER_INFO'
         AND sc.class_id = ap.class_id
         AND ap.java_code = 'membershipLevel'
         AND ap.attr_id = av.attr_id
         AND av.attr_desc = in_char;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN i_vip_level;
    END;
    RETURN return_str;
  END;

  PROCEDURE proc_insert_vip_rela_info2temp IS
    /*
    功能说明：插入积分关联数据到临时表
    编写日期：2012/8/23
    编写人：林志强
    */
    str_msg VARCHAR2(2000);
    i_count NUMBER := 0;
  BEGIN
    BEGIN
      EXECUTE IMMEDIATE 'truncate table vip_info_rela_temp';

      INSERT INTO vip_info_rela_temp
        (cust_id, vip_nbr, area_id, area_code, opter_type)
        SELECT to_char(cust_id),
               vip_nbr,
               nvl(area_id, '00'),
               nvl(area_code, '00'),
               'UPDATE'
          FROM crmv2.vip_cust_rela_info_all_0627
         WHERE /*area_code = '0591'*/
         1 = 1
        MINUS
        SELECT to_char(cust_id),
               member_code,
               nvl(vip_area_id, '00'),
               nvl(vip_area_code, '00'),
               'UPDATE'
          FROM club_member
         WHERE /*vip_area_code = '0591'*/
         1 = 1;
      COMMIT;
      SELECT COUNT(*) INTO i_count FROM vip_info_rela_temp;
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval,
         '更新vip关联信息记录数' || i_count,
         '',
         SYSDATE);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval, '插入关联临时表', str_msg, SYSDATE);
        COMMIT;
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;

  PROCEDURE proc_insert_vip_info2temp IS
    /*
    功能说明：插入积分数据到临时表
    编写日期：2012/8/23
    编写人：林志强
    */
    i_count NUMBER := 0;
    str_msg VARCHAR2(2000);
  BEGIN

    BEGIN
      EXECUTE IMMEDIATE 'truncate table vip_info_temp'; --执行语句：删除表内容并释放空间
      INSERT INTO vip_info_temp
        (vip_nbr,
         id_card,
         cardno,
         vip_level,
         anure_time,
         abate_time,
         integral_group,
         evalue,
         used_integr,
         curr_integr,
         area_id,
         areacode,
         cycle_curr_integral,
         cycle_used_integral,
         cycle_new_integral,
         vip_card_state,
         card_send_day,
         card_exp_day,
         club_info,
         opter_type)
        SELECT vip_nbr,
               id_card,
               cardno,
               func_convert_meta_data(vip_level),
               anure_time,
               abate_time,
               integral_group,
               evalue,
               used_integr,
               curr_integr,
               area_id,
               areacode,
               cycle_curr_integral,
               cycle_used_integral,
               cycle_new_integral,
               vip_card_state,
               card_send_day,
               card_exp_day,
               club_info,
               'UPDATE'
          FROM crmv2.vip_cust_info_all_0627
         WHERE /*areacode = '0591'*/
         1 = 1
        MINUS
        SELECT member_code,
               a.id_card,
               vip_card_nbr,
               (SELECT d.attr_desc
                  FROM attr_value d, attr_spec b, sys_class c
                 WHERE d.attr_id = b.attr_id
                   AND d.attr_value = a.membership_level
                   AND b.class_id = c.class_id
                   AND c.table_name = 'CLUB_MEMBER_INFO'
                   AND b.java_code = 'membershipLevel'),
               to_char(vip_eff_date, 'yyyymmddhh24miss'),
               to_char(vip_exp_date, 'yyyymmddhh24miss'),
               to_char(integral_group),
               to_char(e_value),
               to_char(used_integral),
               to_char(curr_integral),
               vip_area_id,
               vip_area_code,
               to_char(cycle_curr_integral),
               to_char(cycle_used_integral),
               to_char(cycle_new_integral),
               card_state,
               to_char(card_send_date, 'yyyymmdd'),
               to_char(card_exp_date, 'yyyymmdd'),
               club_info,
               'UPDATE'
          FROM club_member_info a
         WHERE /*a.vip_area_code = '0591'*/
         1 = 1;
      COMMIT;
      SELECT COUNT(*) INTO i_count FROM vip_info_temp;
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval,
         '更新vip信息记录数' || i_count,
         '',
         SYSDATE);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval, '插入积分临时表', str_msg, SYSDATE);
        COMMIT;
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;
  PROCEDURE proc_create_vip_info_log IS
    /*
    功能说明：创建日志表
    编写日期：2016/7/1
    编写人：苏巧娟
    */
    v_str_sql1 VARCHAR2(2000);
    v_str_sql2 VARCHAR2(2000);
    v_str_sql  VARCHAR2(2000);
  BEGIN
    v_str_sql1 := 'drop table vip_cust_info_all_temp';
    execute immediate v_str_sql1;
    v_str_sql := 'CREATE TABLE vip_info_synchro_log as(LOG_ID NUMBER(12) NOT NULL,
                                         INT_NAME VARCHAR2(100),
                                         INT_DEF VARCHAR2(100),
                                         SRC_TABLE_NAME NUMBER(9),
                                         FLAG VARCHAR2(4000),
                                         BEGIN_CYCLE_ID VARCHAR2(20),
                                         CREATE_DATE DATE,
                                         UPDATE_DATE DATE)';
    execute immediate v_str_sql;
    v_str_sql2 := 'create sequence seq_vip_info_synchro_log_id minvalue 1 maxvalue 999999999999999999999999999';
    execute immediate v_str_sql2;
  END;
  PROCEDURE proc_create_vip_cust_info_all IS
    /*
    功能说明：全量取积分数据，建表
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    --i_count NUMBER := 0;
    --str_msg VARCHAR2(2000);
    v_str_sql1 VARCHAR2(2000);
    v_str_sql  VARCHAR2(2000);
  BEGIN
    v_str_sql1 := 'drop table vip_cust_info_all_temp';
    execute immediate v_str_sql1;
    v_str_sql := 'create table vip_cust_info_all_temp as
      SELECT vip_nbr,
             id_card,
             cardno,
             func_convert_meta_data(vip_level) vip_level,
             anure_time,
             abate_time,
             integral_group,
             evalue,
             used_integr,
             curr_integr,
             area_id,
             areacode,
             cycle_curr_integral,
             cycle_used_integral,
             cycle_new_integral,
             vip_card_state,
             card_send_day,
             card_exp_day,
             club_info,
             ''UPDATE'' opter_type
        FROM crmv2.vip_cust_info_all_0627
       where 1 = 1)';
    execute immediate v_str_sql;
  END;
  PROCEDURE proc_minus_vip_cust_info_all IS
    /*
    功能说明：插入积分数据到临时表
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    i_begin_cycle_id VARCHAR2(40);
    str_msg          VARCHAR2(2000);
    v_str_sql1       VARCHAR2(2000);
    v_str_sql        VARCHAR2(2000);
    i_count           NUMBER(9);
  BEGIN
    BEGIN
      v_str_sql1 := 'drop table minus_vip_cust_info_all';
      execute immediate v_str_sql1;
 v_str_sql := 'create table minus_vip_cust_info_all as
        SELECT vip_nbr,
               id_card,
               cardno,
               vip_level,
               anure_time,
               abate_time,
               integral_group,
               evalue,
               used_integr,
               curr_integr,
               area_id,
               areacode,
               cycle_curr_integral,
               cycle_used_integral,
               cycle_new_integral,
               vip_card_state,
               card_send_day,
               card_exp_day,
               club_info,
               opter_type
          FROM vip_cust_info_all_temp
         WHERE
         1 = 1
        MINUS
        SELECT member_code,
               a.id_card,
               vip_card_nbr,
               (SELECT d.attr_desc
                  FROM attr_value d, attr_spec b, sys_class c
                 WHERE d.attr_id = b.attr_id
                   AND d.attr_value = a.membership_level
                   AND b.class_id = c.class_id
                   AND c.table_name = ''CLUB_MEMBER_INFO''
                   AND b.java_code = ''membershipLevel''),
               to_char(vip_eff_date, ''yyyymmddhh24miss''),
               to_char(vip_exp_date, ''yyyymmddhh24miss''),
               to_char(integral_group),
               to_char(e_value),
               to_char(used_integral),
               to_char(curr_integral),
               vip_area_id,
               vip_area_code,
               to_char(cycle_curr_integral),
               to_char(cycle_used_integral),
               to_char(cycle_new_integral),
               card_state,
               to_char(card_send_date, ''yyyymmdd''),
               to_char(card_exp_date, ''yyyymmdd''),
               club_info,
               ''UPDATE'' opter_type
          FROM club_member_info a
         WHERE 1 = 1';
      execute immediate v_str_sql;
      COMMIT;
      SELECT COUNT(*) INTO i_count FROM minus_vip_cust_info_all;
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval,
         '更新vip信息记录数' || i_count,
         '',
         SYSDATE);
      COMMIT;
      --全量取积分表数据成功，向日志表插入一条数据。标识为0（已取数据）
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO i_begin_cycle_id
        FROM  crmv2.doone_int_status_0727 a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all'
         AND a.area_code = '590';

      INSERT INTO vip_info_synchro_log
        (LOG_ID,
         INT_NAME,
         INT_DEF,
         SRC_OWNER,
         SRC_TABLE_NAME,
         FLAG,
         BEGIN_CYCLE_ID,
         CREATE_DATE,
         UPDATE_DATE)
      VALUES
        (seq_vip_info_synchro_log_id.nextval,
         'VIP_INFO_FROM_JF',
         'CRM',
         'JF',
         'minus_vip_cust_info_all',
         '0',
         i_begin_cycle_id,
         SYSDATE,
         SYSDATE);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval, '插入积分临时表', str_msg, SYSDATE);
        COMMIT;
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;
  PROCEDURE proc_update_club_member_info_1 IS
    /*
    功能说明：同步club_member_info数据
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    i                     NUMBER := 0;
    i_opt                 VARCHAR2(12);
    i_result              BOOLEAN;
    str_msg               VARCHAR2(2000);
    v_cnt                 NUMBER := 0;
    v_level               VARCHAR2(12);
    I_CLUB_MEMBER_INFO_ID NUMBER;
    v_club_member_info_id number;
  BEGIN
    /*FOR rec IN (SELECT *
     FROM crmv2.vip_cust_info_all_0627 a
    WHERE a.areacode = '0591')*/
    FOR rec IN (SELECT *
                  FROM minus_vip_cust_info_all
                 where mod(vip_nbr, 1) = 0) LOOP
      BEGIN
        i_opt := rec.opter_type;
        i     := i + 1;
        IF i_opt = 'UPDATE' THEN

          SELECT COUNT(*)
            INTO v_cnt
            FROM club_member_info a
           WHERE a.member_code = rec.vip_nbr;

          IF v_cnt > 0 THEN
            i_result := func_insert_member_info_his(rec.vip_nbr);

            SELECT nvl(a.membership_level, '0')
              INTO v_level
              FROM club_member_info a
             WHERE a.member_code = rec.vip_nbr;

            UPDATE club_member_info a
               SET a.membership_level    = rec.vip_level,
                   a.id_card             = rec.id_card,
                   a.vip_eff_date        = to_date(rec.anure_time,
                                                   'YYYYMMDDhh24miss'),
                   a.vip_exp_date        = to_date(rec.abate_time,
                                                   'YYYYMMDDhh24miss'),
                   a.vip_card_nbr        = rec.cardno,
                   a.card_state          = rec.vip_card_state,
                   a.card_send_date      = to_date(rec.card_send_day,
                                                   'YYYYMMDDhh24miss'),
                   a.card_exp_date       = to_date(rec.card_exp_day,
                                                   'YYYYMMDDhh24miss'),
                   a.integral_group      = rec.integral_group,
                   a.e_value             = rec.evalue,
                   a.used_integral       = rec.used_integr,
                   a.curr_integral       = rec.curr_integr,
                   a.cycle_curr_integral = rec.cycle_curr_integral,
                   a.cycle_used_integral = rec.cycle_used_integral,
                   a.cycle_new_integral  = rec.cycle_new_integral,
                   a.club_info           = rec.club_info,
                   a.vip_area_code       = rec.areacode,
                   a.vip_area_id         = rec.area_id,
                   a.update_date         = SYSDATE,
                   a.create_staff        = -1
             WHERE a.member_code = rec.vip_nbr
            returning a.club_member_info_id into v_club_member_info_id;

            crmv2.pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER_INFO',
                                                          'CLUB_MEMBER_INFO_ID',
                                                          v_club_member_info_id,
                                                          'PKG_VIP_CUST_INFO 修改club_member_info记录',
                                                          '1002',
                                                          'PKG_VIP_CUST_INFO 修改club_member_info记录',
                                                          '',
                                                          '590');

            IF (v_level <> nvl(rec.vip_level, '0')) THEN
              ----增加当vip信息变更时，同步更新关联的客户关联记录的vip级别
              FOR memberrec IN (SELECT *
                                  FROM club_member cm
                                 WHERE cm.member_code = rec.vip_nbr) LOOP

                i_result := func_insert_club_member_his(rec.vip_nbr,
                                                        memberrec.party_id,
                                                        memberrec.cust_id);

                UPDATE club_member a
                   SET a.membership_level = (SELECT b.membership_level
                                               FROM club_member_info b
                                              WHERE b.member_code =
                                                    memberrec.member_code)
                 WHERE a.party_id = memberrec.party_id
                   AND a.cust_id = memberrec.cust_id;
                --送计费批量接口

                /*    crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
                    basejk.pkg_common.proc_intf_ins_billing_update@lk_crm2intf('CLUB_MEMBER', 'MEMBER_ID', memberrec.member_id, 'PKG_VIP_CUST_INFO 修改VIP记录', '1002', 'PKG_VIP_CUST_INFO 修改VIP记录', '', '590');
                */
                pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER',
                                                        'MEMBER_ID',
                                                        memberrec.member_id,
                                                        'PKG_VIP_CUST_INFO 修改VIP记录',
                                                        '1002',
                                                        'PKG_VIP_CUST_INFO 修改VIP记录',
                                                        '',
                                                        '590');

              END LOOP;
            END IF;
          ELSE
            SELECT seq_club_member_info_id.nextval
              INTO I_CLUB_MEMBER_INFO_ID
              FROM DUAL;
            INSERT INTO club_member_info
              (club_member_info_id,
               member_code,
               membership_level,
               id_card,
               password,
               vip_eff_date,
               vip_exp_date,
               cust_staff,
               vip_card_nbr,
               card_state,
               card_send_date,
               card_exp_date,
               integral_group,
               e_value,
               used_integral,
               curr_integral,
               cycle_curr_integral,
               cycle_used_integral,
               cycle_new_integral,
               assess_date,
               create_staff,
               update_date,
               club_info,
               area_id,
               region_cd,
               vip_area_code,
               vip_area_id)
            VALUES
              (I_CLUB_MEMBER_INFO_ID,
               rec.vip_nbr,
               rec.vip_level,
               rec.id_card,
               '',
               to_date(rec.anure_time, 'YYYYMMDDhh24miss'),
               to_date(rec.abate_time, 'YYYYMMDDhh24miss'),
               '',
               rec.cardno,
               rec.vip_card_state,
               to_date(rec.card_send_day, 'YYYYMMDDhh24miss'),
               to_date(rec.card_exp_day, 'YYYYMMDDhh24miss'),
               rec.integral_group,
               rec.evalue,
               rec.used_integr,
               rec.curr_integr,
               rec.cycle_curr_integral,
               rec.cycle_used_integral,
               rec.cycle_new_integral,
               '',
               -1,
               SYSDATE,
               rec.club_info,
               NULL,
               NULL,
               rec.areacode,
               rec.area_id);
            /*    crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
            BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CLUB_MEMBER_INFO',
                                                                                 'CLUB_MEMBER_INFO_ID',
                                                                                 I_CLUB_MEMBER_INFO_ID,
                                                                                 'pkg_vip_cust_info 插入',
                                                                                 '1002',
                                                                                 'pkg_vip_cust_info 插入',
                                                                                 '51447',
                                                                                 '590');*/
            PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CLUB_MEMBER_INFO',
                                                    'CLUB_MEMBER_INFO_ID',
                                                    I_CLUB_MEMBER_INFO_ID,
                                                    'pkg_vip_cust_info 插入',
                                                    '1002',
                                                    'pkg_vip_cust_info 插入',
                                                    '51447',
                                                    '590');

          END IF;

        END IF;

        IF i > 1000 THEN
          COMMIT;
          i := 0;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             '更新vip信息' || rec.vip_nbr,
             str_msg,
             SYSDATE);
          --update minus_vip_cust_info_all t set t.flag = 1; --更新后，修改临时表的状态标识字段
          COMMIT;
          --ROLLBACK;
          --RETURN;
          NULL;
      END;
    END LOOP;
    BEGIN
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;
  PROCEDURE proc_create_vip_cust_rela_info IS
    /*
    功能说明：全量取积分关联数据，建表
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    --str_msg   VARCHAR2(2000);
    v_str_sql VARCHAR2(2000);
  BEGIN
    v_str_sql := 'create table vip_cust_rela_info_all_temp as
      SELECT to_char(cust_id) cust_id,
             vip_nbr,
             nvl(area_id, ''00'') area_id,
             nvl(area_code, ''00'') area_code,
             ''UPDATE'' opter_type
        FROM crmv2.vip_cust_rela_info_all_0627
       where 1 = 1';
    execute immediate v_str_sql;
  END;
  PROCEDURE proc_minus_vip_cust_rela_info IS
    /*
    功能说明：插入积分关联数据到临时表
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    i_count      NUMBER(9);
    i_begin_cycle_id VARCHAR2(40);
    v_str_sql        VARCHAR2(2000);
    str_msg          VARCHAR2(2000);
  BEGIN
    BEGIN
      v_str_sql := 'create table minus_vip_cust_rela_info_all as
        SELECT cust_id, vip_nbr, area_id, area_code, opter_type, '' flag
          FROM vip_cust_rela_info_all_temp
         WHERE 1 = 1
        MINUS
        SELECT to_char(cust_id),
               member_code,
               nvl(vip_area_id, ''00''),
               nvl(vip_area_code, ''00''),
               ''UPDATE'' opter_type,
               '' flag
          FROM club_member
         WHERE 1 = 1';
      execute immediate v_str_sql;
      COMMIT;
      SELECT COUNT(*) INTO i_count FROM vip_info_rela_temp;
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval,
         '更新vip关联信息记录数' || i_count,
         '',
         SYSDATE);
      COMMIT;
      --全量取积分表数据成功，向日志表插入一条数据。标识为0（已取数据）
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO i_begin_cycle_id
        FROM  crmv2.doone_int_status_0727 a
       WHERE lower(a.src_table_name) = 'vip_cust_rela_info_all'
         AND a.area_code = '590';

      INSERT INTO vip_info_synchro_log
        ( --LOG_ID,
         INT_NAME,
         INT_DEF,
         SRC_OWNER,
         SRC_TABLE_NAME,
         FLAG,
         BEGIN_CYCLE_ID,
         CREATE_DATE,
         UPDATE_DATE)
      VALUES
        ( --seq_vip_info_synchro_log_id.nextval,
         'VIP_INFO_FROM_JF',
         'CRM',
         'JF',
         'minus_vip_cust_rela_info_all',
         '0',
         i_begin_cycle_id,
         SYSDATE,
         SYSDATE);
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        str_msg := substr(SQLERRM, 0, 1000);
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval, '插入关联临时表', str_msg, SYSDATE);
        COMMIT;
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;
  PROCEDURE proc_update_club_member_new(i_proc_count    IN NUMBER,
                                       i_proc_number     IN NUMBER) IS
    /*
    功能说明：同步club_member数据
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    i           NUMBER := 0;
    i_opt       VARCHAR2(12);
    i_result    BOOLEAN;
    i_party_id  NUMBER;
    i_member_id NUMBER := 0;
    str_msg     VARCHAR2(2000);
    v_cnt       NUMBER := 0;
  BEGIN
    FOR rec IN (SELECT *
                  FROM minus_vip_cust_rela_info_all
                 where mod(cust_id, i_proc_count) = i_proc_number) LOOP

      BEGIN
        i_opt := rec.opter_type;
        i     := i + 1;
        IF i_opt = 'UPDATE' THEN

          SELECT c.party_id
            INTO i_party_id
            FROM cust c
           WHERE c.cust_id = rec.cust_id;

          SELECT COUNT(*)
            INTO v_cnt
            FROM club_member a
           WHERE a.party_id = i_party_id
             AND a.cust_id = rec.cust_id;

          IF v_cnt > 0 THEN

            i_result := func_insert_club_member_his(rec.vip_nbr,
                                                    i_party_id,
                                                    rec.cust_id);

            SELECT a.member_id
              INTO i_member_id
              FROM club_member a
             WHERE a.party_id = i_party_id
               AND a.cust_id = rec.cust_id;

            UPDATE club_member a
               SET a.member_code      = rec.vip_nbr,
                   a.membership_level = (SELECT b.membership_level
                                           FROM club_member_info b
                                          WHERE b.member_code = rec.vip_nbr),
                   a.status_cd        = '1000',
                   a.status_date      = SYSDATE,
                   a.update_date      = SYSDATE,
                   a.create_staff     = -1,
                   a.vip_area_code    = rec.area_code,
                   a.vip_area_id      = rec.area_id

             WHERE a.party_id = i_party_id
               AND a.cust_id = rec.cust_id;

            --送计费批量接口
            /*  crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
            basejk.pkg_common.proc_intf_ins_billing_update@lk_crm2intf('CLUB_MEMBER', 'MEMBER_ID', i_member_id, 'PKG_VIP_CUST_INFO 修改VIP记录', '1002', 'PKG_VIP_CUST_INFO 修改VIP记录', '', '590');*/
            pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER',
                                                    'MEMBER_ID',
                                                    i_member_id,
                                                    'PKG_VIP_CUST_INFO 修改VIP记录',
                                                    '1002',
                                                    'PKG_VIP_CUST_INFO 修改VIP记录',
                                                    '',
                                                    '590');

          ELSE
            SELECT seq_club_member_id.nextval INTO i_member_id FROM dual;
            INSERT INTO club_member
              (member_id,
               member_code,
               membership_level,
               party_id,
               cust_id,
               status_cd,
               status_date,
               create_date,
               create_staff,
               update_date,
               update_staff,
               vip_area_code,
               vip_area_id)
            VALUES
              (i_member_id,
               rec.vip_nbr,
               (SELECT b.membership_level
                  FROM club_member_info b
                 WHERE b.member_code = rec.vip_nbr),
               i_party_id,
               rec.cust_id,
               '1000',
               SYSDATE,
               SYSDATE,
               -1,
               SYSDATE,
               -1,
               rec.area_code,
               rec.area_id);
            --送计费批量接口
            /*     crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
            basejk.pkg_common.proc_intf_ins_billing_update@lk_crm2intf('CLUB_MEMBER', 'MEMBER_ID', i_member_id, 'PKG_VIP_CUST_INFO 新增VIP记录', '1002', 'PKG_VIP_CUST_INFO 新增VIP记录', '', '590');
            */
            pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER',
                                                    'MEMBER_ID',
                                                    i_member_id,
                                                    'PKG_VIP_CUST_INFO 新增VIP记录',
                                                    '1002',
                                                    'PKG_VIP_CUST_INFO 新增VIP记录',
                                                    '',
                                                    '590');
          END IF;
        END IF;

        IF i > 1000 THEN
          COMMIT;
          i := 0;
        END IF;
         update minus_vip_cust_rela_info_all t set t.flag = 0; --更新后，修改临时表的状态标识字段
      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             '更新vip关联信息' || rec.vip_nbr || '-' || rec.cust_id,
             str_msg,
             SYSDATE);
          update minus_vip_cust_rela_info_all t set t.flag = 1; --更新后，修改临时表的状态标识字段
          COMMIT;
          --ROLLBACK;
          --RETURN;
          NULL;
      END;
    END LOOP;
    BEGIN
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;
  PROCEDURE proc_update_club_member_info IS
    /*
    功能说明：同步club_member_info数据
    编写日期：2012/5/31
    编写人：林志强
    */
    i                     NUMBER := 0;
    i_opt                 VARCHAR2(12);
    i_result              BOOLEAN;
    str_msg               VARCHAR2(2000);
    v_cnt                 NUMBER := 0;
    v_level               VARCHAR2(12);
    I_CLUB_MEMBER_INFO_ID NUMBER;
    v_club_member_info_id number;
  BEGIN
    /*FOR rec IN (SELECT *
     FROM crmv2.vip_cust_info_all_0627 a
    WHERE a.areacode = '0591')*/
    FOR rec IN (SELECT * FROM vip_info_temp) LOOP
      BEGIN
        i_opt := rec.opter_type;
        i     := i + 1;
        IF i_opt = 'UPDATE' THEN

          SELECT COUNT(*)
            INTO v_cnt
            FROM club_member_info a
           WHERE a.member_code = rec.vip_nbr;

          IF v_cnt > 0 THEN
            i_result := func_insert_member_info_his(rec.vip_nbr);

            SELECT nvl(a.membership_level, '0')
              INTO v_level
              FROM club_member_info a
             WHERE a.member_code = rec.vip_nbr;

            UPDATE club_member_info a
               SET a.membership_level    = rec.vip_level,
                   a.id_card             = rec.id_card,
                   a.vip_eff_date        = to_date(rec.anure_time,
                                                   'YYYYMMDDhh24miss'),
                   a.vip_exp_date        = to_date(rec.abate_time,
                                                   'YYYYMMDDhh24miss'),
                   a.vip_card_nbr        = rec.cardno,
                   a.card_state          = rec.vip_card_state,
                   a.card_send_date      = to_date(rec.card_send_day,
                                                   'YYYYMMDDhh24miss'),
                   a.card_exp_date       = to_date(rec.card_exp_day,
                                                   'YYYYMMDDhh24miss'),
                   a.integral_group      = rec.integral_group,
                   a.e_value             = rec.evalue,
                   a.used_integral       = rec.used_integr,
                   a.curr_integral       = rec.curr_integr,
                   a.cycle_curr_integral = rec.cycle_curr_integral,
                   a.cycle_used_integral = rec.cycle_used_integral,
                   a.cycle_new_integral  = rec.cycle_new_integral,
                   a.club_info           = rec.club_info,
                   a.vip_area_code       = rec.areacode,
                   a.vip_area_id         = rec.area_id,
                   a.update_date         = SYSDATE,
                   a.create_staff        = -1
             WHERE a.member_code = rec.vip_nbr
            returning a.club_member_info_id into v_club_member_info_id;

            crmv2.pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER_INFO',
                                                          'CLUB_MEMBER_INFO_ID',
                                                          v_club_member_info_id,
                                                          'PKG_VIP_CUST_INFO 修改club_member_info记录',
                                                          '1002',
                                                          'PKG_VIP_CUST_INFO 修改club_member_info记录',
                                                          '',
                                                          '590');

            IF (v_level <> nvl(rec.vip_level, '0')) THEN
              ----增加当vip信息变更时，同步更新关联的客户关联记录的vip级别
              FOR memberrec IN (SELECT *
                                  FROM club_member cm
                                 WHERE cm.member_code = rec.vip_nbr) LOOP

                i_result := func_insert_club_member_his(rec.vip_nbr,
                                                        memberrec.party_id,
                                                        memberrec.cust_id);

                UPDATE club_member a
                   SET a.membership_level = (SELECT b.membership_level
                                               FROM club_member_info b
                                              WHERE b.member_code =
                                                    memberrec.member_code)
                 WHERE a.party_id = memberrec.party_id
                   AND a.cust_id = memberrec.cust_id;
                --送计费批量接口

                /*    crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
                    basejk.pkg_common.proc_intf_ins_billing_update@lk_crm2intf('CLUB_MEMBER', 'MEMBER_ID', memberrec.member_id, 'PKG_VIP_CUST_INFO 修改VIP记录', '1002', 'PKG_VIP_CUST_INFO 修改VIP记录', '', '590');
                */
                pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER',
                                                        'MEMBER_ID',
                                                        memberrec.member_id,
                                                        'PKG_VIP_CUST_INFO 修改VIP记录',
                                                        '1002',
                                                        'PKG_VIP_CUST_INFO 修改VIP记录',
                                                        '',
                                                        '590');

              END LOOP;
            END IF;
          ELSE
            SELECT seq_club_member_info_id.nextval
              INTO I_CLUB_MEMBER_INFO_ID
              FROM DUAL;
            INSERT INTO club_member_info
              (club_member_info_id,
               member_code,
               membership_level,
               id_card,
               password,
               vip_eff_date,
               vip_exp_date,
               cust_staff,
               vip_card_nbr,
               card_state,
               card_send_date,
               card_exp_date,
               integral_group,
               e_value,
               used_integral,
               curr_integral,
               cycle_curr_integral,
               cycle_used_integral,
               cycle_new_integral,
               assess_date,
               create_staff,
               update_date,
               club_info,
               area_id,
               region_cd,
               vip_area_code,
               vip_area_id)
            VALUES
              (I_CLUB_MEMBER_INFO_ID,
               rec.vip_nbr,
               rec.vip_level,
               rec.id_card,
               '',
               to_date(rec.anure_time, 'YYYYMMDDhh24miss'),
               to_date(rec.abate_time, 'YYYYMMDDhh24miss'),
               '',
               rec.cardno,
               rec.vip_card_state,
               to_date(rec.card_send_day, 'YYYYMMDDhh24miss'),
               to_date(rec.card_exp_day, 'YYYYMMDDhh24miss'),
               rec.integral_group,
               rec.evalue,
               rec.used_integr,
               rec.curr_integr,
               rec.cycle_curr_integral,
               rec.cycle_used_integral,
               rec.cycle_new_integral,
               '',
               -1,
               SYSDATE,
               rec.club_info,
               NULL,
               NULL,
               rec.areacode,
               rec.area_id);
            /*    crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
            BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CLUB_MEMBER_INFO',
                                                                                 'CLUB_MEMBER_INFO_ID',
                                                                                 I_CLUB_MEMBER_INFO_ID,
                                                                                 'pkg_vip_cust_info 插入',
                                                                                 '1002',
                                                                                 'pkg_vip_cust_info 插入',
                                                                                 '51447',
                                                                                 '590');*/
            PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CLUB_MEMBER_INFO',
                                                    'CLUB_MEMBER_INFO_ID',
                                                    I_CLUB_MEMBER_INFO_ID,
                                                    'pkg_vip_cust_info 插入',
                                                    '1002',
                                                    'pkg_vip_cust_info 插入',
                                                    '51447',
                                                    '590');

          END IF;

        END IF;

        IF i > 1000 THEN
          COMMIT;
          i := 0;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             '更新vip信息' || rec.vip_nbr,
             str_msg,
             SYSDATE);
          COMMIT;
          --ROLLBACK;
          --RETURN;
          NULL;
      END;
    END LOOP;
    BEGIN
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;

  PROCEDURE proc_update_club_member IS
    /*
    功能说明：同步club_member数据
    编写日期：2012/5/31
    编写人：林志强
    */
    i           NUMBER := 0;
    i_opt       VARCHAR2(12);
    i_result    BOOLEAN;
    i_party_id  NUMBER;
    i_member_id NUMBER := 0;
    str_msg     VARCHAR2(2000);
    v_cnt       NUMBER := 0;
  BEGIN
    FOR rec IN (SELECT * FROM vip_info_rela_temp) LOOP

      BEGIN
        i_opt := rec.opter_type;
        i     := i + 1;
        IF i_opt = 'UPDATE' THEN

          SELECT c.party_id
            INTO i_party_id
            FROM cust c
           WHERE c.cust_id = rec.cust_id;

          SELECT COUNT(*)
            INTO v_cnt
            FROM club_member a
           WHERE a.party_id = i_party_id
             AND a.cust_id = rec.cust_id;

          IF v_cnt > 0 THEN

            i_result := func_insert_club_member_his(rec.vip_nbr,
                                                    i_party_id,
                                                    rec.cust_id);

            SELECT a.member_id
              INTO i_member_id
              FROM club_member a
             WHERE a.party_id = i_party_id
               AND a.cust_id = rec.cust_id;

            UPDATE club_member a
               SET a.member_code      = rec.vip_nbr,
                   a.membership_level = (SELECT b.membership_level
                                           FROM club_member_info b
                                          WHERE b.member_code = rec.vip_nbr),
                   a.status_cd        = '1000',
                   a.status_date      = SYSDATE,
                   a.update_date      = SYSDATE,
                   a.create_staff     = -1,
                   a.vip_area_code    = rec.area_code,
                   a.vip_area_id      = rec.area_id

             WHERE a.party_id = i_party_id
               AND a.cust_id = rec.cust_id;

            --送计费批量接口
            /*  crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
            basejk.pkg_common.proc_intf_ins_billing_update@lk_crm2intf('CLUB_MEMBER', 'MEMBER_ID', i_member_id, 'PKG_VIP_CUST_INFO 修改VIP记录', '1002', 'PKG_VIP_CUST_INFO 修改VIP记录', '', '590');*/
            pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER',
                                                    'MEMBER_ID',
                                                    i_member_id,
                                                    'PKG_VIP_CUST_INFO 修改VIP记录',
                                                    '1002',
                                                    'PKG_VIP_CUST_INFO 修改VIP记录',
                                                    '',
                                                    '590');

          ELSE
            SELECT seq_club_member_id.nextval INTO i_member_id FROM dual;
            INSERT INTO club_member
              (member_id,
               member_code,
               membership_level,
               party_id,
               cust_id,
               status_cd,
               status_date,
               create_date,
               create_staff,
               update_date,
               update_staff,
               vip_area_code,
               vip_area_id)
            VALUES
              (i_member_id,
               rec.vip_nbr,
               (SELECT b.membership_level
                  FROM club_member_info b
                 WHERE b.member_code = rec.vip_nbr),
               i_party_id,
               rec.cust_id,
               '1000',
               SYSDATE,
               SYSDATE,
               -1,
               SYSDATE,
               -1,
               rec.area_code,
               rec.area_id);
            --送计费批量接口
            /*     crm00076122FJCRMV2.0_BUG_福建省_生产环境增加增量计费的轮询。 liufzh 20160517
            basejk.pkg_common.proc_intf_ins_billing_update@lk_crm2intf('CLUB_MEMBER', 'MEMBER_ID', i_member_id, 'PKG_VIP_CUST_INFO 新增VIP记录', '1002', 'PKG_VIP_CUST_INFO 新增VIP记录', '', '590');
            */
            pkg_common.proc_intf_ins_billing_update('CLUB_MEMBER',
                                                    'MEMBER_ID',
                                                    i_member_id,
                                                    'PKG_VIP_CUST_INFO 新增VIP记录',
                                                    '1002',
                                                    'PKG_VIP_CUST_INFO 新增VIP记录',
                                                    '',
                                                    '590');
          END IF;
        END IF;

        IF i > 1000 THEN
          COMMIT;
          i := 0;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             '更新vip关联信息' || rec.vip_nbr || '-' || rec.cust_id,
             str_msg,
             SYSDATE);
          COMMIT;
          --ROLLBACK;
          --RETURN;
          NULL;
      END;
    END LOOP;
    BEGIN
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        --ROLLBACK;
        --RETURN;
        NULL;
    END;
  END;

  PROCEDURE proc_sync_vip_info IS
    /*
    功能说明：同步数据到CRM
    编写日期：2012/5/31
    编写人：林志强
    */
    i_result  BOOLEAN;
    i_result2 BOOLEAN;

    o_begin_cycle_id1  VARCHAR2(40);
    o_begin_cycle_id2  VARCHAR2(40);
    str_msg            VARCHAR2(2000);
    vip_begin_cycle_id VARCHAR2(40); --积分的时间
    crm_begin_cycle_id VARCHAR2(40); --CRM的时间
    flag               VARCHAR2(40);
  BEGIN
    --i_begin_cycle_id := to_char(SYSDATE - 1, 'YYYYMMDD');

    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '同步开始', '', SYSDATE);
    COMMIT;

    i_result := func_check_switch_state('INTF_DAPM_CUST_POINT',
                                        o_begin_cycle_id1);

    i_result2 := func_check_switch_state('INTF_DAPM_EVT_POINT',
                                         o_begin_cycle_id2);

    IF i_result = TRUE AND i_result2 = TRUE THEN
      /**取记录到临时表**/
      /**mod by:suqj date:2016-06-29**/
      --proc_insert_vip_info2temp;
      proc_create_vip_cust_info_all;--1
      proc_minus_vip_cust_info_all;--2
      /**更新club_member_info**/
      --proc_update_club_member_info;
      --1、取积分的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO vip_begin_cycle_id
        FROM  crmv2.doone_int_status_0727 a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all'
         AND a.area_code = '590';
      --2、取crm日志表的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO crm_begin_cycle_id
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all';
      --3、取crm日志表的标识
      SELECT a.flag
        INTO flag
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all'
         AND a.begin_cycle_id = crm_begin_cycle_id;
      --临时表的时间和积分的时间相同，并且标识为0（取表成功）时，更新数据
      if vip_begin_cycle_id = crm_begin_cycle_id and flag = 0 then
        proc_update_club_member_info_1;
        update vip_info_synchro_log a
           set a.flag = 1, a.update_date = sysdate
         where lower(a.src_table_name) = 'vip_cust_info_all'
           AND a.begin_cycle_id = crm_begin_cycle_id; --更新成功
      end if;
      /**修改开关表状态**/
      UPDATE  crmv2.doone_int_status_0727 a
         SET a.flag = 4, a.crm_end_time = SYSDATE
       WHERE lower(a.src_table_name) = lower('vip_cust_info_all')
         AND a.flag = 3
         AND a.begin_cycle_id = o_begin_cycle_id1
         AND a.area_code = '590';
      COMMIT;
      /**取记录到临时表**/
      /**mod by:suqj date:2016-06-29**/
      --proc_insert_vip_rela_info2temp;
      proc_create_vip_cust_rela_info;
      proc_minus_vip_cust_rela_info;
      /**更新club_member**/
      --proc_update_club_member;
      proc_update_club_member_new(5,1);
      /**修改开关表状态**/
      UPDATE  crmv2.doone_int_status_0727 a
         SET a.flag = 4, a.crm_end_time = SYSDATE
       WHERE lower(a.src_table_name) = lower('vip_cust_rela_info_all')
         AND a.flag = 3
         AND a.begin_cycle_id = o_begin_cycle_id2
         AND a.area_code = '590';
      COMMIT;
     /* BEGIN
      ODSPUB.P_NOTI_VIP_V2@LK_CRM2ODS;
      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             '调用ODSPUB.P_NOTI_VIP_V2过程失败',
             str_msg,
             SYSDATE);
          COMMIT;
      END;*/
    END IF;

    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '同步结束', '', SYSDATE);
    COMMIT;

  END;
  PROCEDURE proc_sync_vip_info_1 IS
    /*
    功能说明：同步数据到CRM
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    i_result  BOOLEAN;
    i_result2 BOOLEAN;

    o_begin_cycle_id1  VARCHAR2(40);
    o_begin_cycle_id2  VARCHAR2(40);
    str_msg            VARCHAR2(2000);
    crm_begin_cycle_id VARCHAR2(40); --CRM的时间
    flag               VARCHAR2(40);
  BEGIN

    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '取积分记录到临时表开始', '', SYSDATE);
    COMMIT;

    i_result := func_check_switch_state('vip_cust_info_all',
                                        o_begin_cycle_id1);

    i_result2 := func_check_switch_state('vip_cust_rela_info_all',
                                         o_begin_cycle_id2);

    IF i_result = TRUE AND i_result2 = TRUE THEN
      /**取记录到临时表**/
      /**mod by:suqj date:2016-06-29**/
      --proc_insert_vip_info2temp;
      --1、取crm日志表的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO crm_begin_cycle_id
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all';
      --2、取crm日志表的标识

      if crm_begin_cycle_id<>o_begin_cycle_id1 then
        proc_create_vip_cust_info_all;
        proc_minus_vip_cust_info_all;
      end if;

      /**取记录到临时表**/
      /**mod by:suqj date:2016-06-29**/
      --proc_insert_vip_rela_info2temp;--1、取crm日志表的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO crm_begin_cycle_id
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_rela_info_all';
      --2、取crm日志表的标识

      if  crm_begin_cycle_id<>o_begin_cycle_id2 then
        proc_create_vip_cust_rela_info;
        proc_minus_vip_cust_rela_info;
      end if;

     /* BEGIN
        ODSPUB.P_NOTI_VIP_V2@LK_CRM2ODS;
      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             '调用ODSPUB.P_NOTI_VIP_V2过程失败',
             str_msg,
             SYSDATE);
          COMMIT;
      END;*/
    END IF;

    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '取积分记录到临时表结束', '', SYSDATE);
    COMMIT;
  END;
  PROCEDURE proc_sync_vip_info_2 IS
    /*
    功能说明：同步数据到CRM
    编写日期：2016/6/29
    编写人：苏巧娟
    */
    i_result  BOOLEAN;
    i_result2 BOOLEAN;

    o_begin_cycle_id1  VARCHAR2(40);
    o_begin_cycle_id2  VARCHAR2(40);
    str_msg            VARCHAR2(2000);
    vip_begin_cycle_id VARCHAR2(40); --积分的时间
    crm_begin_cycle_id VARCHAR2(40); --CRM的时间
    flag               VARCHAR2(40);
  BEGIN
    --i_begin_cycle_id := to_char(SYSDATE - 1, 'YYYYMMDD');

    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '更新开始', '', SYSDATE);
    COMMIT;

    i_result := func_check_switch_state('vip_cust_info_all',
                                        o_begin_cycle_id1);

    i_result2 := func_check_switch_state('vip_cust_rela_info_all',
                                         o_begin_cycle_id2);

    IF i_result = TRUE AND i_result2 = TRUE THEN
      /**更新club_member_info**/
      --proc_update_club_member_info;
      --1、取积分的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO vip_begin_cycle_id
        FROM  crmv2.doone_int_status_0727 a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all'
         AND a.area_code = '590';
      --2、取crm日志表的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO crm_begin_cycle_id
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all';
      --3、取crm日志表的标识
      SELECT a.flag
        INTO flag
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_info_all'
         AND a.begin_cycle_id = crm_begin_cycle_id;
      --临时表的时间和积分的时间相同，并且标识为0（取表成功）时，更新数据
      if vip_begin_cycle_id = crm_begin_cycle_id and flag = 0 then
        proc_update_club_member_info;
        update vip_info_synchro_log a
           set a.flag = 1, a.update_date = sysdate
         where lower(a.src_table_name) = 'vip_cust_info_all'
           AND a.begin_cycle_id = crm_begin_cycle_id; --更新成功
      end if;
      /**修改开关表状态**/
      UPDATE  crmv2.doone_int_status_0727 a
         SET a.flag = 4, a.crm_end_time = SYSDATE
       WHERE lower(a.src_table_name) = lower('vip_cust_info_all')
         AND a.flag = 3
         AND a.begin_cycle_id = o_begin_cycle_id1
         AND a.area_code = '590';
      COMMIT;

      /**更新club_member**/
      --proc_update_club_member;--1、取积分的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO vip_begin_cycle_id
        FROM  crmv2.doone_int_status_0727 a
       WHERE lower(a.src_table_name) = 'vip_cust_rela_info_all'
         AND a.area_code = '590';
      --2、取crm日志表的时间
      SELECT nvl(MAX(a.begin_cycle_id), 0)
        INTO crm_begin_cycle_id
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_rela_info_all';
      --3、取crm日志表的标识
      SELECT a.flag
        INTO flag
        FROM vip_info_synchro_log a
       WHERE lower(a.src_table_name) = 'vip_cust_rela_info_all'
         AND a.begin_cycle_id = crm_begin_cycle_id;
      --临时表的时间和积分的时间相同，并且标识为0（取表成功）时，更新数据
      if vip_begin_cycle_id = crm_begin_cycle_id and flag = 0 then
        proc_update_club_member_new(5,1);
        update vip_info_synchro_log a
           set a.flag = 1, a.update_date = sysdate
         where lower(a.src_table_name) = 'vip_cust_rela_info_all'
           AND a.begin_cycle_id = crm_begin_cycle_id; --更新成功
      end if;

      /**修改开关表状态**/
      UPDATE  crmv2.doone_int_status_0727 a
         SET a.flag = 4, a.crm_end_time = SYSDATE
       WHERE lower(a.src_table_name) = lower('vip_cust_rela_info_all')
         AND a.flag = 3
         AND a.begin_cycle_id = o_begin_cycle_id2
         AND a.area_code = '590';
      COMMIT;
     /* BEGIN
        ODSPUB.P_NOTI_VIP_V2@LK_CRM2ODS;
      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             '调用ODSPUB.P_NOTI_VIP_V2过程失败',
             str_msg,
             SYSDATE);
          COMMIT;
      END;*/
    END IF;

    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '更新结束', '', SYSDATE);
    COMMIT;

  END;

END pkg_vip_cust_info;
/
