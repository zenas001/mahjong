CREATE PACKAGE           PKG_SMS IS

  -- Author  : renl
  -- Created : 2012-03-22
  -- Purpose : 短厅接口

  /*亲情号码查询接口，用于查询T7亲情套餐的亲情号码。*/
  PROCEDURE PROC_QUERY_PROD_OFFER_ATTR(I_AREA_CODE     IN VARCHAR2, --区域，如：福州0591
                                       I_ACC_NBR       IN VARCHAR2, --号码
                                       I_EXT_PROD_ID   IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                       I_EXT_OFFER_NBR IN VARCHAR2, --销售品外部编码，T7亲情套餐：800008363
                                       I_EXT_ATTR_NBR  IN VARCHAR2, --销售品属性外部编码，亲情号码：590007624
                                       O_ERR_CODE      OUT NUMBER, --错误编码（0--成功 1--失败）
                                       O_ERR_MSG       OUT VARCHAR2, --错误信息
                                       O_RESULT        OUT VARCHAR2 --结果信息（成功时返回亲情号码，失败时为空）
                                       );

  /*宽带密码验证接口，验证宽带密码的同时，返回宽带速率、新装时间、业务号码和产品规格。*/
  PROCEDURE PROC_QUERY_KD_INFO(I_ACCOUNT      IN VARCHAR2, --宽带帐号，如：454309392@fzadsl
                               I_EXT_ATTR_NBR IN VARCHAR2, --属性编码，如：（下行）速率的产品属性编码：590000315
                               O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                               O_ERR_MSG      OUT VARCHAR2, -- 错误信息
                               O_ACC_NBR      OUT VARCHAR2, --接入号码
                               O_EXT_PROD_ID  OUT VARCHAR2, --接入类产品外部编码，如：有线宽带610007605
                               O_FINISH_TIME  OUT VARCHAR2, --竣工时间，格式：YYYYMMDDHH24MISS
                               O_ATTR_VALUE   OUT VARCHAR2 --如ADSL：下行速率，LAN：速率
                               );

  /*
  查询天翼超无及小灵通携号转网的手机号码。
  根据小灵通或固话号码查询“小灵通带号转网”的手机号码及天翼超无的手机号码,
  或根据天翼超无的手机号码查询“小灵通带号转网”前的小灵通号码。
  */
  PROCEDURE PROC_QUERY_XHZW(I_AREA_CODE    IN VARCHAR2, --区域，如：福州0591
                            I_EXT_PROD_ID  IN VARCHAR2, --功能类产品外部编码，小灵通带号转网：800000570
                            I_EXT_ATTR_NBR IN VARCHAR2, --属性编码，小灵通号码：590001385
                            I_ACC_NBR      IN VARCHAR2, --查询方式为0时，为小灵通或固话号码，如：24883552；查询方式为1时，为手机号码，如：15359121897）
                            I_TYPE         IN VARCHAR2, --查询方式：（0--根据小灵通号码查手机号码 1--根据手机号码查小灵通号码）
                            O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                            O_ERR_MSG      OUT VARCHAR2, --错误信息
                            O_RESULT       OUT VARCHAR2 --对应的天翼手机号码
                            );

  /*查询号码的属性，根据接入号码和C4区域查询号码的规格*/
  PROCEDURE PROC_QUERY_PROD_SPEC(I_AREA_CODE    IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR      IN VARCHAR2, --接入号码，如：15359121897）
                                 O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG      OUT VARCHAR2, --错误信息
                                 O_EXT_PROD_ID  OUT VARCHAR2, --接入类产品外部编码
                                 O_PRODUCT_NAME OUT VARCHAR2 --产品名称
                                 );

  /*天翼号码无线宽带关联主副卡查询，以传入的接入号码为主卡（或副卡）查询关联的副卡（或主卡）*/
  PROCEDURE PROC_QUERY_DOUBLE_NUMBER(I_AREA_CODE        IN VARCHAR2, --区域，如：福州0591
                                     I_ACC_NBR          IN VARCHAR2, --接入号码（主号或从号，如：15359121897）
                                     I_EXT_FUNC_PROD_ID IN VARCHAR2, --功能类产品外部编码，一卡双芯：800551826
                                     O_ERR_CODE         OUT NUMBER, --错误编码（0--成功 1--失败）
                                     O_ERR_MSG          OUT VARCHAR2, --错误信息
                                     O_RELA_ACC_NBR     OUT VARCHAR2, --关联接入号码（主号或从号，如：15359121897）
                                     O_TYPE             OUT VARCHAR2 --传入接入号码的类别（1：主卡，2：副卡）
                                     );

  /*查询天翼是否开通无线宽带程控，查询无线宽带的热点属性，及传入号码是否天翼同号*/
  PROCEDURE PROC_QUERY_CDMA_WLAN(I_AREA_CODE        IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR          IN VARCHAR2, --接入号码，如：15359121897
                                 I_EXT_PROD_ID      IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                 I_EXT_FUNC_PROD_ID IN VARCHAR2, --功能类产品外部编码，无线宽带WLAN：800296774
                                 I_EXT_ATTR_NBR     IN VARCHAR2, --属性外部编码，热点开通：590001645
                                 O_ERR_CODE         OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG          OUT VARCHAR2, --错误信息
                                 O_IS_OPEN          OUT VARCHAR2, --是否开通（0--未开通，1--已开通）
                                 O_HOT_SPOT         OUT VARCHAR2, --热点属性（Y--开启，N--关闭）
                                 O_TYPE             OUT VARCHAR2 --号码类别，（1：普通手机，>1：天翼同号）
                                 );

  /*查询客户下在用的邮箱地址。*/
  PROCEDURE PROC_QUERY_MAIL_ADDR(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_RESULT      OUT VARCHAR2 --结果信息（成功时返回邮箱地址，失败时为空）
                                 );

  /*绑定或取消客户下在用的邮箱地址。*/
  PROCEDURE PROC_HANDLE_MAIL_ADDR(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                  I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                  I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                  I_MAIL_ADDR   IN VARCHAR2, --邮箱地址，如13305027420@189.cn
                                  I_USE_TYPE    IN VARCHAR2, --邮箱用途，如：账单推送、广告推送
                                  I_SOURCE      IN VARCHAR2, --来源，如网厅、掌厅、短厅等
                                  I_ACTION      IN VARCHAR2, --动作，A：绑定，R：取消
                                  O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                  O_ERR_MSG     OUT VARCHAR2 --错误信息
                                  );

  /*查询USIM卡类型及（付费类型、是否记名客户）*/
  PROCEDURE PROC_QUERY_USIM_TYPE(I_AREA_CODE      IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR        IN VARCHAR2, --接入号码，如：15359121897
                                 I_EXT_PROD_ID    IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                 O_USIM_TYPE      OUT VARCHAR2, --USIM卡类型代码
                                 O_USIM_TYPE_NAME OUT VARCHAR2, --USIM卡类型名称
                                 O_PAY_TYPE       OUT VARCHAR2, --付费类型
                                 O_IS_JM          OUT VARCHAR2, --是否记名客户
                                 O_VIP_LEVEL      OUT VARCHAR2, --客户VIP级别（金卡，银卡，钻石卡，普通兑换资格）
                                 O_ERR_CODE       OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG        OUT VARCHAR2 --错误信息
                                 );

  /*查询亲情短号户主及成员信息*/
  PROCEDURE PROC_QUERY_QQDH_MEMBER(I_AREA_CODE        IN VARCHAR2, --区域，如：福州0591
                                   I_ACC_NBR          IN VARCHAR2, --接入号码，如：15359121897
                                   I_EXT_PROD_ID      IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                   O_ERR_CODE         OUT NUMBER, --错误编码（0--成功 1--失败）
                                   O_ERR_MSG          OUT VARCHAR2, --错误信息
                                   O_HOST_NBR         OUT VARCHAR2, --户主号码
                                   O_HOST_SHORT_NBR   OUT VARCHAR2, --户主短号
                                   O_HOST_STATUS_CD   OUT VARCHAR2, --户主号码状态
                                   O_MEMBER_NBR       OUT VARCHAR2, --家庭成员号码，多个时用逗号隔开
                                   O_MEMBER_SHORT_NBR OUT VARCHAR2, --家庭成员短号，多个时用逗号隔开，顺序与号码对应
                                   O_MEMBER_STATUS_CD OUT VARCHAR2, --家庭成员号码状态，多个时用逗号隔开，顺序与号码对应
                                   O_JTDH_NBR         OUT VARCHAR2 -- 家庭短号本身的号码
                                   );

  /*查询业务号码是否能受理一键通*/
  PROCEDURE PROC_QUERY_IS_ENABLE_YJT(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                     I_ACC_NBR     IN VARCHAR2, --接入号码，如：15359121897
                                     I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                     O_ERR_CODE    OUT NUMBER, --错误编码（0--成功(允许受理） 1--失败）
                                     O_ERR_MSG     OUT VARCHAR2, --错误信息
                                     O_RESULT      OUT VARCHAR2 --结果信息
                                     );

  /*查询业务号码的包类型及所在E家的基础包号码*/
  PROCEDURE PROC_QUERY_BASE_SHARE_PACK(I_AREA_CODE     IN VARCHAR2, --区域，如：福州0591
                                       I_ACC_NBR       IN VARCHAR2, --接入号码，如：15359121897
                                       I_EXT_PROD_ID   IN VARCHAR2, --接入类产品外部编码，移动语音：610003886
                                       O_ERR_CODE      OUT NUMBER, --错误编码（0--成功(允许受理） 1--失败）
                                       O_ERR_MSG       OUT VARCHAR2, --错误信息
                                       O_PACK_TYPE     OUT VARCHAR2, --1:基础包  2：共享包 0：两者均不是
                                       O_BASE_PACK_NBR OUT VARCHAR2 --E家的基础包的天翼号码和固话号码
                                       );

  /*查询代理商编码对应的发展团队和发展员工*/
  PROCEDURE PROC_QUERY_PARTNER(I_CHANNEL_NBR IN VARCHAR2, --完整的代理商编码，如：5913570000378
                               O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                               O_ERR_MSG     OUT VARCHAR2, --错误信息
                               O_ORG_ID      OUT VARCHAR2, --发展团队ID
                               O_STAFF_ID    OUT VARCHAR2 --发展员工ID，多个时用逗号隔开
                               );
 /* 亲情网查询 */
  PROCEDURE PROC_QUERY_OFFER_REL_INFO(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591
                                 I_ACC_NBR     IN VARCHAR2, --业务号码
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_ZHU_HAO   OUT VARCHAR2, --主号
                                 O_ZHU_HAO_AREA  OUT VARCHAR2, --主号区域
                                 O_FU_HAO OUT VARCHAR2,
                                 O_FU_HAO_AREA OUT VARCHAR2
                                 );

END PKG_SMS;
/
