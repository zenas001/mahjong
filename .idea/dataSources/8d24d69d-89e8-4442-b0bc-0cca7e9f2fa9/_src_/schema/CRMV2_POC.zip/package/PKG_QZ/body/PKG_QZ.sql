CREATE package body           PKG_QZ is
  /*  create table qz_prod_offer_config
  (
         prod_offer_Id number(12),
         prod_offer_name varchar2(500),
         balance varchar2(1),
         flag number(1),
         state varchar2(1)
  );

  grant update on QZ_PROD_OFFER_CONFIG to qzzhangll;
  grant delete on QZ_PROD_OFFER_CONFIG to qzzhangll;
  grant insert on QZ_PROD_OFFER_CONFIG to qzzhangll;

  grant update on QZ_PROD_OFFER_CONFIG to qzchenyl;
  grant delete on QZ_PROD_OFFER_CONFIG to qzchenyl;
  grant insert on QZ_PROD_OFFER_CONFIG to qzchenyl;

  grant update on QZ_PROD_OFFER_CONFIG to qzwangsw;
  grant delete on QZ_PROD_OFFER_CONFIG to qzwangsw;
  grant insert on QZ_PROD_OFFER_CONFIG to qzwangsw;*/

  procedure delete_price(in_account    in varchar2,
                         in_offername  in varchar2,
                         i_exp_date    in varchar2, --失效时间
                         iremark       in varchar2, --修改备注
                         in_modi_staff in varchar2, --修改人
                         o_msg         out varchar2) is
    --执行过程返回信息
    iexp_date date;
    -- v_offer_type crmv2.prod_offer.offer_type%TYPE;
    v_date date := sysdate + 1 / 120;
    --v_ip         varchar2(100);
    --v_host       varchar2(100);
    -- v_user       varchar2(100);
    v_staff              varchar2(100);
    v_n                  number(10);
    v_prod_offer_Inst_id number(10);
    v_remark             varchar2(100);

    ---备份表中需要的字段
    v_bstaff varchar2(100);

  begin

    /*
      1）  允许取消配置表有配置的基本套餐
    （2） 入参：号码、套餐名、失效时间（yyyy-mm-dd）、流程id、修改人（根据登录工号自动获得传入）
    （3） 出参：是否成功，不成功要返回报错信息
    （4） 相关要求：
    A.  入参必须都要填，未填的返回报错，说明哪个入参没有填写
    B.  判断传入的流程id是否是>3500000的7位数字，否则返回报错信息：流程id有误
    C.  判断传入的套餐名是否有在配置表中配置，且flag=1 and state=’A’，查无记录的返回报错信息：
    套餐名有误或该套餐不允许修改
    D.  判断传入的失效时间是否小于当月1日，是的话返回报错信息：失效日期不能早于当然月1日
    E.  判断用户档案上是否有需取消的套餐，如果没有则返回报错信息：号码有误或号码上无此套餐
    F.  取消号码上的套餐时需将套餐转历史表，并将失效时间置为传入的失效时间
    G.  处理成功后，从配置表判断BALANCE=’Y’，则提示：处理成功，请注意余额是否要冻结
    H.  修改结果需送往外系统，如ODS
    I.  原1.0函数可参考cjh_price_delete_to_qz

      */

    --------------------------------参数准确性判断----------------------------
    --A.  入参必须都要填，未填的返回报错，说明哪个入参没有填写
    if replace(in_account, ' ', '') is null then
      o_msg := '号码未填写';
      return;
    elsif replace(in_offername, ' ', '') is null then
      o_msg := '套餐名未填写';
      return;
    elsif replace(i_exp_date, ' ', '') is null then
      o_msg := '失效时间未填写';
      return;
    elsif replace(iremark, ' ', '') is null then
      o_msg := '流程ID未填写';
      return;
    elsif replace(in_modi_staff, ' ', '') is null then
      o_msg := '修改人员未填写';
      return;
    end if;

    -- B.  判断传入的流程id是否是>3500000的7位数字，否则返回报错信息：流程id有误

    begin
      if to_number(iremark) <= 3500000 then

        o_msg := '流程ID输入有误，请重新输入';
        return;
      end if;

    exception
      when others then
        o_msg := '流程ID输入有误，请重新输入';
        return;
    end;

    --C.  判断传入的套餐名是否有在配置表中配置，
    --且flag=1 and state=’A’，查无记录的返回报错信息：
    --套餐名有误或该套餐不允许修改

    select count(1)
      into v_n
      from itsc_crmv2.qz_prod_offer_config
     where prod_offer_name = replace(in_offername, ' ', '')
       and flag = '1'
       and state = 'A';

    if v_n = 0 then
      o_msg := '套餐名有误或该套餐不允许修改';
      return;
    end if;

    --D.  判断传入的失效时间是否小于当月1日，
    --是的话返回报错信息：失效日期不能早于当然月1日
    iexp_date := to_date(i_exp_date, 'yyyy-mm-dd');

    if iexp_date < to_date(to_char(sysdate, 'yyyymm') || '01', 'yyyymmdd') then
      o_msg := '失效日期不能早于当然月1日';
      return;
    end if;

    v_staff  := replace(in_modi_staff, ' ', '');
    v_remark := 'flow_id=' || iremark;

    --备份数据提取

    select SYS_CONTEXT('USERENV', 'SESSION_USER') into v_bstaff from dual;

    if v_bstaff = 'CRMV2' then
      v_bstaff := v_staff;
    end if;

    ----------------------------------------------------------------------------

    ----------------------删除套餐-------------------------------------------------

    begin
      -- E.  判断用户档案上是否有需取消的套餐，如果没有则返回报错信息：
      --号码有误或号码上无此套餐

      select a.prod_offer_inst_id
        into v_prod_offer_Inst_id
        from crmv2.prod_offer_Inst           a,
             crmv2.prod_inst                 b,
             crmv2.offer_prod_inst_rel       c,
             itsc_crmv2.qz_prod_offer_config d
       where b.acc_nbr = replace(in_account, ' ', '')
         and b.status_cd not in ('130000', '110000')
         and b.prod_inst_id = c.prod_inst_id
         and c.status_cd in ('1299', '1000')
         and c.prod_offer_inst_id = a.prod_offer_inst_id
         and a.status_cd in ('1299', '1000')
         and a.prod_offer_id = d.prod_offer_id
         and d.prod_offer_name = replace(in_offername, ' ', '')
         and b.area_id = '6';

    exception
      when others then
        o_msg := '号码有误或号码上无此套餐';
        return;
    end;

    --删除销售品
    insert into itsc_crmv2.obj_update_bill_bak
      (TABLE_NAME,
       COL_NAME,
       KEY_ID,
       MODI_REASON,
       MODI_STAFF,
       MODI_DATE,
       AREA_ID)
      select 'prod_offer_inst',
             'prod_offer_inst_id',
             prod_offer_inst_id,
             iremark,
             v_staff,
             sysdate,
             area_id
        from prod_offer_inst a
       where prod_offer_inst_id = v_prod_offer_inst_id
         and status_cd in (1299, 1000);

    v_date := sysdate + 1 / 120;

    insert into crmv2.prod_offer_inst_his
      (PROD_OFFER_INST_ID,
       PROD_OFFER_ID,
       CUST_ID,
       CHANNEL_ID,
       CREATE_DATE,
       STATUS_CD,
       STATUS_DATE,
       EFF_DATE,
       EXP_DATE,
       REGION,
       UPDATE_DATE,
       PROC_SERIAL,
       EXT_PROD_OFFER_INST_ID,
       LAN_ID,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       HIS_ID,
       REC_UPDATE_DATE,
       TRIAL_EFF_DATE,
       TRIAL_EXP_DATE,
       SERVICE_NBR,
       VERSION)
      select PROD_OFFER_INST_ID,
             PROD_OFFER_ID,
             CUST_ID,
             CHANNEL_ID,
             CREATE_DATE,
             decode(status_cd, 1299, 1299, 1100),
             STATUS_DATE,
             EFF_DATE,
             iexp_date,
             REGION,
             sysdate + 1 / 24,
             PROC_SERIAL,
             EXT_PROD_OFFER_INST_ID,
             null,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             crmv2.seq_prod_offer_inst_his_id.nextval,
             v_date,
             TRIAL_EFF_DATE,
             TRIAL_EXP_DATE,
             SERVICE_NBR,
             VERSION
        from crmv2.prod_offer_inst
       where prod_offer_inst_id = v_prod_offer_inst_id
         and status_cd in (1299, 1000);

    update crmv2.prod_offer_inst
       set exp_date    = iexp_date,
           status_date = v_date,
           status_cd   = '1100',
           update_date = sysdate + 1 / 24
     where prod_offer_inst_id = v_prod_offer_inst_id
       and status_cd in (1299, 1000);

    --删除销售品属性
    for rec in (select *
                  from crmv2.prod_offer_inst_attr
                 where prod_offer_inst_id = v_prod_offer_inst_id
                   and status_cd in (1299, 1000)) loop

      insert into itsc_crmv2.obj_update_bill_bak
        (TABLE_NAME,
         COL_NAME,
         KEY_ID,
         MODI_REASON,
         MODI_STAFF,
         MODI_DATE,
         AREA_ID)
        select 'prod_offer_inst_attr',
               'prod_offer_inst_attr_id',
               prod_offer_inst_attr_id,
               v_remark,
               v_staff,
               sysdate,
               area_id
          from prod_offer_inst_attr a
         where prod_offer_inst_id = v_prod_offer_inst_id
           and status_cd in (1299, 1000);

      insert into crmv2.prod_offer_inst_attr_his
        (PROD_OFFER_INST_ATTR_ID,
         PROD_OFFER_INST_ID,
         ATTR_ID,
         ATTR_VALUE_ID,
         ATTR_VALUE,
         CREATE_DATE,
         EXP_DATE,
         EFF_DATE,
         STATUS_DATE,
         STATUS_CD,
         UPDATE_DATE,
         PROC_SERIAL,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         HIS_ID,
         REC_UPDATE_DATE,
         VERSION)
        select PROD_OFFER_INST_ATTR_ID,
               PROD_OFFER_INST_ID,
               ATTR_ID,
               ATTR_VALUE_ID,
               ATTR_VALUE,
               CREATE_DATE,
               iexp_date,
               EFF_DATE,
               STATUS_DATE,
               decode(status_cd, 1299, 1299, 1100),
               sysdate + 1 / 24,
               PROC_SERIAL,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               crmv2.seq_prod_offer_inst_attr_2_id.nextval,
               v_date,
               VERSION
          from crmv2.prod_offer_inst_attr
         where prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id
           and status_cd in (1299, 1000);

      update crmv2.prod_offer_inst_attr b
         set b.status_cd   = '1100',
             b.exp_date    = iexp_date,
             b.status_date = v_date
       where b.prod_offer_inst_attr_id = rec.prod_offer_inst_attr_id;

    end loop;
    --删除销售品关联
    for rec in (select *
                  from crmv2.prod_offer_inst_rel
                 where related_prod_offer_inst_id = v_prod_offer_inst_id
                   and status_cd in (1299, 1000)) loop

      insert into itsc_crmv2.obj_update_bill_bak
        (TABLE_NAME,
         COL_NAME,
         KEY_ID,
         MODI_REASON,
         MODI_STAFF,
         MODI_DATE,
         AREA_ID)
        select 'prod_offer_inst_rel',
               'prod_offer_inst_rel_id',
               prod_offer_inst_rel_id,
               v_remark,
               v_staff,
               sysdate,
               area_id
          from crmv2.prod_offer_inst_rel a
         where related_prod_offer_inst_id = v_prod_offer_inst_id
           and status_cd in (1299, 1000);

      insert into crmv2.prod_offer_inst_rel_his
        (PROD_OFFER_INST_REL_ID,
         RELA_PROD_OFFER_INST_ID,
         RELATED_PROD_OFFER_INST_ID,
         ROLE_CD,
         PROD_OFFER_INST_REL_ROLE_ID,
         RELATION_TYPE_CD,
         STATUS_CD,
         EFF_DATE,
         EXP_DATE,
         CREATE_DATE,
         STATUS_DATE,
         REGION_A,
         REGION_B,
         UPDATE_DATE,
         PROC_SERIAL,
         PROD_OFFER_RELA_ID,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         HIS_ID,
         REC_UPDATE_DATE)
        select PROD_OFFER_INST_REL_ID,
               RELA_PROD_OFFER_INST_ID,
               RELATED_PROD_OFFER_INST_ID,
               ROLE_CD,
               PROD_OFFER_INST_REL_ROLE_ID,
               RELATION_TYPE_CD,
               decode(status_cd, 1299, 1299, 1100),
               EFF_DATE,
               iexp_date,
               CREATE_DATE,
               STATUS_DATE,
               REGION_A,
               REGION_B,
               sysdate + 1 / 24,
               PROC_SERIAL,
               PROD_OFFER_RELA_ID,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               crmv2.seq_prod_offer_inst_rel_his_id.nextval,
               sysdate
          from crmv2.prod_offer_inst_rel
         where prod_offer_inst_rel_id = rec.prod_offer_inst_rel_id
           and status_cd in (1299, 1000);
      delete from crmv2.prod_offer_inst_rel
       where prod_offer_inst_rel_id = rec.prod_offer_inst_rel_id
         and status_cd in (1299, 1000);

    /*new_p_ins_billing_update('prod_offer_inst_rel',
                                                                                                                                                                                                                                                                                             'prod_offer_inst_rel_id',
                                                                                                                                                                                                                                                                                             rec.prod_offer_inst_rel_id,
                                                                                                                                                                                                                                                                                             v_remark,
                                                                                                                                                                                                                                                                                             in_modi_staff);
                                                                                                                                                                                                                                                                  */
    end loop;

    --删除产品销售品关联
    for rec in (select *
                  from crmv2.offer_prod_inst_rel
                 where prod_offer_inst_id = v_prod_offer_inst_id
                   and status_cd in (1299, 1000)) loop

      insert into itsc_crmv2.obj_update_bill_bak
        (TABLE_NAME,
         COL_NAME,
         KEY_ID,
         MODI_REASON,
         MODI_STAFF,
         MODI_DATE,
         AREA_ID)
        select 'offer_prod_inst_rel',
               'offer_prod_inst_rel_id',
               offer_prod_inst_rel_id,
               v_remark,
               v_staff,
               sysdate,
               area_id
          from crmv2.offer_prod_inst_rel a
         where offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           and status_cd in (1299, 1000);

      insert into crmv2.offer_prod_inst_rel_his
        (OFFER_PROD_INST_REL_ID,
         PROD_INST_ID,
         PROD_OFFER_INST_ID,
         ROLE_CD,
         OFFER_PROD_INST_REL_ROLE_ID,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         EFF_DATE,
         EXP_DATE,
         UPDATE_DATE,
         PROC_SERIAL,
         OFFER_PROD_REL_ID,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         HIS_ID,
         REC_UPDATE_DATE,
         EXT_FLAG)
        select OFFER_PROD_INST_REL_ID,
               PROD_INST_ID,
               PROD_OFFER_INST_ID,
               ROLE_CD,
               OFFER_PROD_INST_REL_ROLE_ID,
               decode(status_cd, 1299, 1299, 1100),
               STATUS_DATE,
               CREATE_DATE,
               EFF_DATE,
               iexp_date,
               sysdate + 1 / 24,
               PROC_SERIAL,
               OFFER_PROD_REL_ID,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF,
               crmv2.seq_offer_prod_inst_rel_his_id.nextval,
               sysdate,
               EXT_FLAG
          from crmv2.offer_prod_inst_rel
         where offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
           and status_cd in (1299, 1000);
      delete from crmv2.offer_prod_inst_rel
       where offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
         and status_cd in (1299, 1000);

    /*    new_p_ins_billing_update('offer_prod_inst_rel',
                                                                                                                                                                                                                                                                                             'offer_prod_inst_rel_id',
                                                                                                                                                                                                                                                                                             rec.offer_prod_inst_rel_id,
                                                                                                                                                                                                                                                                                             v_remark,
                                                                                                                                                                                                                                                                                             in_modi_staff);*/

    end loop;

    insert into itsc_crmv2.INTF_INS_BILLING_UPDATE
      (INS_ID,
       TABLE_NAME,
       COLUMN_NAME,
       KEY_ID,
       TOPIC,
       TYPE,
       REASON,
       OPERATOR,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       DEAL_NUM,
       NEXT_DEAL_TIME,
       ERR_MSG,
       REMARK,
       AREA_NBR)
      select itsc_crmv2.seq_intf_ins_billing_update_id.nextval,
             upper(table_name),
             upper(col_name),
             key_id,
             v_remark,
             '1003',
             modi_reason,
             modi_staff,
             '70A',
             null,
             sysdate,
             null,
             0,
             null,
             null,
             null,
             AREA_NBR
        from itsc_crmv2.obj_update_bill_bak a, crmv2.area_code b
       where modi_reason = v_remark
         and a.area_id = b.area_code_id;

    INSERT INTO itsc_crmv2.obj_update_bill_bak_HIS
      select * from itsc_crmv2.obj_update_bill_bak;

    DELETE from itsc_crmv2.obj_update_bill_bak;

    insert into itsc_crmv2.crm_wh_bak
      (TAL_NAME,
       KEY_ID,
       MODI_COLUMN,
       MODI_AREA,
       OLD_VALUE,
       NEW_VALUE,
       MODI_ACTION,
       MODI_SPEC,
       OFFER_SPEC,
       PROCE,
       MODI_STAFF,
       STAFF_AREA,
       MODI_REASON,
       MODI_TIME,
       REASON,
       MODI_TYPE)
      select 'PROD_OFFER_INST',
             v_prod_offer_Inst_id,
             '',
             6,
             '',
             '',
             'DELETE',
             prod_offer_id,
             prod_offer_id,
             'CRMV2.PKG_QZ.DELETE_PRICE',
             V_BSTAFF,
             '6',
             iremark,
             SYSDATE,
             '删除可选包',
             '销售品类'
        from itsc_crmv2.qz_prod_offer_config A
       where A.PROD_OFFER_NAME = replace(in_offername, ' ', '');

    commit;
    --G. 处理成功后，从配置表判断BALANCE=’Y’，
    --则提示：处理成功，请注意余额是否要冻结

    select count(1)
      into v_n
      from itsc_crmv2.qz_prod_offer_config
     where prod_offer_name = replace(in_offername, ' ', '')
       and BALANCE = 'Y';

    if v_n > 0 then
      o_msg := '处理成功，请注意余额是否要冻结!';
    else
      o_msg := '修改成功!';

    end if;

  exception
    when others then
      rollback;
      o_msg := v_prod_offer_inst_id || sqlerrm;
  end;

  procedure change_offer_inst_attr(in_account    in varchar2,
                                   in_offername  in varchar2,
                                   in_attrname   in varchar2,
                                   in_oldvalue   in varchar2,
                                   in_newvalue   in varchar2,
                                   in_remark     in varchar2,
                                   in_modi_staff in varchar2,
                                   o_msg         out varchar2) is

    v_account        varchar2(100) := replace(in_account, ' ', '');
    v_offername      varchar2(100) := replace(in_offername, ' ', '');
    v_attrname       varchar2(100) := replace(in_attrname, ' ', '');
    v_oldvalue       varchar2(100) := replace(in_oldvalue, ' ', '');
    v_newvalue       varchar2(100) := replace(in_newvalue, ' ', '');
    v_remark         varchar2(100) := replace(in_remark, ' ', '');
    v_staff          varchar2(100) := replace(in_modi_staff, ' ', '');
    v_n              number(10);
    v_attrvalueid    number(10);
    v_attrvalue      varchar2(100);
    v_attrinstid     number(10);
    v_newvalueinst   varchar2(100);
    v_newvalueinstid number(10);
    v_attrid number(10);

    ---备份表中需要的字段
    v_bstaff varchar2(100);
  begin
    --------------------------------参数准确性判断----------------------------
    --A.  入参必须都要填，未填的返回报错，说明哪个入参没有填写
    if v_account is null then
      o_msg := '号码未填写';
      return;
    elsif v_offername is null then
      o_msg := '套餐名未填写';
      return;
    elsif v_attrname is null then
      o_msg := '参数名称未填写';
      return;
    elsif v_oldvalue is null then
      o_msg := '参数旧值未填写';
      return;
    elsif v_newvalue is null then
      o_msg := '参数新值未填写';
      return;

    elsif v_remark is null then
      o_msg := '流程ID未填写';
      return;

    elsif v_staff is null then
      o_msg := '修改人员未填写';
      return;
    end if;

    -- B.  判断传入的流程id是否是>3500000的7位数字，否则返回报错信息：流程id有误

    begin
      if to_number(v_remark) <= 3500000 then

        o_msg := '流程ID输入有误，请重新输入';
        return;
      end if;

    exception
      when others then
        o_msg := '流程ID输入有误，请重新输入';
        return;
    end;

    -- C.  判断传入的套餐名是否有在配置表中配置，且flag=2 and state=’A’，
    --查无记录的返回报错信息：套餐名有误或该套餐不允许修改

    select count(1)
      into v_n
      from itsc_crmv2.qz_prod_offer_config
     where prod_offer_name = v_offername
       and flag = '2'
       and state = 'A';

    if v_n = 0 then
      o_msg := '套餐名有误或该套餐不允许修改';
      return;
    end if;

    v_remark := 'flow_id=' || v_remark;

     --备份数据提取

    select SYS_CONTEXT('USERENV', 'SESSION_USER') into v_bstaff from dual;

    if v_bstaff = 'CRMV2' then
      v_bstaff := v_staff;
    end if;
    ----------------------------------------------------------------------------
    --  D.  判断用户档案上是否有需取消的套餐及参数名，
    --如果没有则返回报错信息：
    --号码有误或套餐参数有误或号码上无此套餐

    select count(1)
      into v_n
      from crmv2.prod_inst            partition(p_qz_595) pi,
           crmv2.offer_prod_inst_rel  b,
           crmv2.prod_offer_inst      c,
           crmv2.prod_offer_attr      poa,
           crmv2.attr_spec            ass,
           crmv2.prod_offer_inst_attr poia
     where pi.acc_nbr = v_account
       and pi.prod_inst_id = b.prod_inst_id
       and b.prod_offer_inst_id = c.prod_offer_inst_id
       and c.prod_offer_id = poa.prod_offer_id
       and poa.attr_id = ass.attr_id
       and ass.attr_name = v_attrname
       and ass.attr_id = poia.attr_id
       and poia.prod_offer_inst_id = c.prod_offer_inst_id
       and c.status_cd in ('1299', '1000')
       and poia.status_cd in ('1299', '1000');

    if v_n = 0 then
      o_msg := '号码有误或套餐参数有误或号码上无此套餐';
      return;
    end if;

    --取参数实例ID
    begin
      select poia.prod_offer_inst_attr_id, poa.attr_id
        into v_attrinstid, v_attrid
        from crmv2.prod_inst            partition(p_qz_595) pi,
             crmv2.offer_prod_inst_rel  b,
             crmv2.prod_offer_inst      c,
             crmv2.prod_offer_attr      poa,
             crmv2.attr_spec            ass,
             crmv2.prod_offer_inst_attr poia,
             crmv2.prod_offer           po
       where pi.acc_nbr = v_account
         and pi.prod_inst_id = b.prod_inst_id
         and b.prod_offer_inst_id = c.prod_offer_inst_id
         and c.prod_offer_id = poa.prod_offer_id
         and poa.attr_id = ass.attr_id
         and c.prod_offer_id = po.prod_offer_id
         and po.prod_offer_name = v_offername
         and ass.attr_name = v_attrname
         and ass.attr_id = poia.attr_id
         and poia.prod_offer_inst_id = c.prod_offer_inst_id
         and c.status_cd in ('1299', '1000')
         and poia.status_cd in ('1299', '1000');

    exception
      when no_data_found then
        o_msg := '销售品上的参数档案不存在';
        return;
      when others then
        o_msg := '销售品上的参数个数有误';
        return;

    end;

    --取参数旧值名称与输入的旧值比较

    begin
      select b.attr_value_name, b.attr_value_id
        into v_attrvalue, v_attrvalueid
        from crmv2.prod_offer_inst_attr a, crmv2.attr_value b
       where a.prod_offer_inst_attr_id = v_attrinstid
         and a.attr_value_id = b.attr_value_id;

    exception
      when no_data_found then
        select a.attr_value
          into v_attrvalue
          from crmv2.prod_offer_inst_attr a
         where a.prod_offer_inst_attr_id = v_attrinstid;
      when others then
        o_msg := '销售品上的参数有误';
        return;

    end;

    --- E.  判断用户档案上的套餐参数值与传入的旧值是否相符，
    --不符合的则返回报错信息：号码原参数值有误，请核实
    if v_attrvalue != v_oldvalue then
      o_msg := '号码原参数值有误，请核实';
      return;
    end if;

    --取新值
    begin
      select av.attr_value, av.attr_value_id
        into v_newvalueinst, v_newvalueinstid
        from crmv2.prod_offer            po,
             crmv2.prod_offer_attr       poa,
             crmv2.attr_spec             ass,
             crmv2.attr_value            av,
             crmv2.prod_offer_attr_value poav
       where po.prod_offer_name = v_offername
         and po.prod_offer_id = poa.prod_offer_id
         and poa.attr_id = ass.attr_id
         and ass.attr_name = v_attrname
         and poa.prod_offer_attr_id = poav.prod_offer_attr_id
         and ass.attr_id = av.attr_id
         and av.attr_value_name = v_newvalue
         and poa.status_cd = '1000'
         and poav.status_cd = '1000'
         and poav.attr_value_id = av.attr_value_id;

    exception
      when no_data_found then
        select count(1)
          into v_n
          from crmv2.prod_offer            po,
               crmv2.prod_offer_attr       poa,
               crmv2.prod_offer_attr_value poav,
               crmv2.attr_value            av,
               crmv2.attr_spec             ass
         where po.prod_offer_name = v_offername
           and poa.attr_id = ass.attr_id
           and ass.attr_name = v_attrname
           and po.prod_offer_id = poa.prod_offer_id
           and poa.prod_offer_attr_id = poav.prod_offer_attr_id
           and poav.status_cd = '1000';

        if v_n > 0 then
          o_msg := '号码新参数值不适用于该套餐，请核实';
          return;
        else
          v_newvalueinstid := '';
          v_newvalueinst   := v_newvalue;
        end if;

      when others then
        o_msg := '号码新参数值输入有误，请核实';
        return;

    end;

    --F。修改结果需送往外系统，如ODS。
    update crmv2.prod_offer_Inst_attr a
       set a.attr_value_id = v_newvalueinstid,
           a.attr_value    = v_newvalueinst
     where a.prod_offer_inst_attr_id = v_attrinstid;


      insert into itsc_crmv2.crm_wh_bak
      (TAL_NAME,
       KEY_ID,
       MODI_COLUMN,
       MODI_AREA,
       OLD_VALUE,
       NEW_VALUE,
       MODI_ACTION,
       MODI_SPEC,
       OFFER_SPEC,
       PROCE,
       MODI_STAFF,
       STAFF_AREA,
       MODI_REASON,
       MODI_TIME,
       REASON,
       MODI_TYPE)
      select 'PROD_OFFER_INST_ATTR',
             v_attrinstid,
             'ATTR_VALUE',
             6,
             v_oldvalue,
             v_newvalueinst,
             'MODIFY',
             v_attrid,
             prod_offer_id,
             'CRMV2.PKG_QZ.CHANGE_OFFER_INST_ATTR',
             V_BSTAFF,
             '6',
             v_remark,
             SYSDATE,
             '修改可选包属性',
             '销售品类'
        from itsc_crmv2.qz_prod_offer_config A
       where A.PROD_OFFER_NAME = v_offername;


    itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_attr',
                                        'prod_offer_inst_attr_id',
                                        v_attrinstid,
                                        v_remark,
                                        v_staff);

    o_msg := '修改成功';
  end;

  procedure change_DEV_STAFF_TEAM(in_custnumber in varchar2,
                                  in_staff      in varchar2,
                                  in_team       in varchar2,
                                  in_remark     in varchar2,
                                  in_modi_staff in varchar2,
                                  o_msg         out varchar) is
    v_custnumber varchar2(100) := replace(in_custnumber, ' ', '');
    v_devstaff   varchar2(100) := replace(in_staff, ' ', '');
    v_devteam    varchar2(100) := replace(in_team, ' ', '');
    v_remark     varchar2(100) := replace(in_remark, ' ', '');
    v_staff      varchar2(100) := replace(in_modi_staff, ' ', '');

    v_staffid number(10);
    v_teamid  number(10);
    v_areaid  number(10);
    v_n       number(10);
    v_n2      number(10);
    v_flag    number(10);

    v_oldstaff varchar2(100);
    v_oldteam varchar2(100);
      ---备份表中需要的字段
    v_bstaff varchar2(100);

  begin
    --------------------------------参数准确性判断----------------------------
    --A.  入参必须都要填，未填的返回报错，说明哪个入参没有填写
    if v_custnumber is null then
      o_msg := '订单号未填写';
      return;
    elsif v_devstaff is null then
      o_msg := '发展员工未填写';
      return;
    elsif v_devteam is null then
      o_msg := '发展团队未填写';
      return;
    elsif v_remark is null then
      o_msg := '流程ID未填写';
      return;

    elsif v_staff is null then
      o_msg := '修改人员未填写';
      return;
    end if;

    --备份数据提取

    select SYS_CONTEXT('USERENV', 'SESSION_USER') into v_bstaff from dual;

    if v_bstaff = 'CRMV2' then
      v_bstaff := v_staff;
    end if;

    -- B.  判断传入的流程id是否是>3500000的7位数字，否则返回报错信息：流程id有误

    begin
      if to_number(v_remark) <= 3500000 then

        o_msg := '流程ID输入有误，请重新输入';
        return;
      end if;

    exception
      when others then
        o_msg := '流程ID输入有误，请重新输入';
        return;
    end;

    ----------------------------------------------------------------------------
    -- 地区判断
    begin
      select co.area_id
        into v_areaid
        from crmv2.customer_order co
       where co.cust_so_number = v_custnumber;

    exception
      when no_data_found then
        select co.area_id
          into v_areaid
          from crmv2.customer_order_his co
         where co.cust_so_number = v_custnumber;
      when others then
        o_msg := '订单号输入有误，请重新输入';
        return;
    end;

    if v_areaid != 6 then
      o_msg := '订单号有误或非泉州地区订单';
      return;
    end if;

    --D.  判断订单是否已竣工，未竣工的可以改，已竣工的竣
    --工时间小于当月1日的不允许修改，
    --返回报错信息：非当月订单，不允许修改

    select count(1)
      into v_n
      from crmv2.customer_order co
     where co.cust_so_number = v_custnumber;

    if v_n > 0 then
      v_flag := 1; --在途
    else
      select count(1)
        into v_n2
        from crmv2.customer_order_his coh
       where coh.cust_so_number = v_custnumber
         and coh.status_date >
             to_date(to_char(sysdate, 'yyyymm') || '01', 'yyyymmdd');

      if v_n2 > 0 then
        v_flag := 2; --已竣工
      else
        o_msg := '非当月订单，不允许修改';
        return;
      end if;
    end if;

    --E. 判断发展工号、发展团队是否存在且是泉州地区的工号团队，
    --否的话返回错误信息：发展工号、团队有误
    begin
      select ss.staff_id
        into v_staffid
        from crmv2.system_user ss
       where ss.staff_code = v_devstaff
         and status_cd = '1000'
         and ss.area_id = '6';
    exception
      when others then
        o_msg := '发展工号有误';
        return;
    end;

    begin
      select o.org_id
        into v_teamid
        from crmv2.organization o
       where o.org_name = v_devteam
         and status_cd = '1000'
         and o.area_id = '6';
    exception
      when others then
        o_msg := '发展团队有误';
        return;
    end;

    if v_flag = 1 then
      for rec in (select a.*
                    from crmv2.order_item a, crmv2.customer_order b
                   where b.cust_so_number = trim(in_custnumber)
                     and b.cust_order_id = a.cust_order_id
                     and a.order_item_cd in ('1200', '1300')) loop
        --修改发展员工
        select count(1)
          into v_n
          from crmv2.order_item_proc_attr c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10131;

        if v_n > 0 then
         --备份数据

         begin

          select c.new_value
          into v_oldstaff
          from crmv2.order_item_proc_attr c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10131;

          exception when others then v_oldstaff := '';
         end;

          update crmv2.order_item_proc_attr c
             set new_value = v_staffid, update_date = sysdate + 1 / 24
           where c.order_item_id = rec.order_item_id
             and c.class_id = 6
             and c.obj_attr_id = 10131;


        else
          -- select * from crmv2.order_item_proc_attr
          insert into crmv2.order_item_proc_attr
            (ORDER_ITEM_PROC_ATTR_ID,
             ORDER_ITEM_ID,
             CLASS_ID,
             OBJ_INST_ID,
             OBJ_ATTR,
             OPERATE,
             NEW_VALUE,
             OLD_VALUE,
             STATUS,
             CREATE_DATE,
             STATUS_DATE,
             REMARK,
             OBJ_ATTR_ID,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             UPDATE_DATE,
             DB_INST_ID)
            select crmv2.seq_order_item_proc_attr_id.nextval,
                   rec.order_item_id,
                   6,
                   rec.order_item_obj_id,
                   'devStaff',
                   '10',
                   v_staffid,
                   '',
                   '1000',
                   sysdate,
                   sysdate,
                   '',
                   10131,
                   rec.area_id,
                   rec.region_cd,
                   '',
                   '',
                   sysdate + 1 / 24,
                   1
              from dual;
        end if;

        ---修改发展团队
        select count(1)
          into v_n
          from crmv2.order_item_proc_attr c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10132;

        if v_n > 0 then

         begin

          select c.new_value
          into v_oldteam
          from crmv2.order_item_proc_attr c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10132;

          exception when others then v_oldteam := '';
         end;

          update crmv2.order_item_proc_attr c
             set new_value = v_staffid, update_date = sysdate + 1 / 24
           where c.order_item_id = rec.order_item_id
             and c.class_id = 6
             and c.obj_attr_id = 10132;
        else
          -- select * from crmv2.order_item_proc_attr
          insert into crmv2.order_item_proc_attr
            (ORDER_ITEM_PROC_ATTR_ID,
             ORDER_ITEM_ID,
             CLASS_ID,
             OBJ_INST_ID,
             OBJ_ATTR,
             OPERATE,
             NEW_VALUE,
             OLD_VALUE,
             STATUS,
             CREATE_DATE,
             STATUS_DATE,
             REMARK,
             OBJ_ATTR_ID,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             UPDATE_DATE,
             DB_INST_ID)
            select crmv2.seq_order_item_proc_attr_id.nextval,
                   rec.order_item_id,
                   6,
                   rec.order_item_obj_id,
                   'devTeam',
                   '10',
                   v_teamid,
                   '',
                   '1000',
                   sysdate,
                   sysdate,
                   '',
                   10132,
                   rec.area_id,
                   rec.region_cd,
                   '',
                   '',
                   sysdate + 1 / 24,
                   1
              from dual;
        end if;
      end loop;
      update crmv2.customer_order co
         set co.update_date = sysdate + 1 / 24
       where co.cust_so_number = v_custnumber;

      ---已竣工
    elsif v_flag = 2 then
      for rec in (select a.*
                    from crmv2.order_item_his a, crmv2.customer_order_his b
                   where b.cust_so_number = trim(in_custnumber)
                     and b.cust_order_id = a.cust_order_id
                     and a.order_item_cd in ('1200', '1300')) loop
        --修改发展员工
        select count(1)
          into v_n
          from crmv2.order_item_proc_attr_his c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10131;

        if v_n > 0 then


         begin

          select c.new_value
          into v_oldstaff
          from crmv2.order_item_proc_attr_his c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10131;

          exception when others then v_oldstaff:= '';
         end;



          update crmv2.order_item_proc_attr_his c
             set new_value = v_staffid, update_date = sysdate + 1 / 24
           where c.order_item_id = rec.order_item_id
             and c.class_id = 6
             and c.obj_attr_id = 10131;
        else
          insert into crmv2.order_item_proc_attr_his
            (ORDER_ITEM_PROC_ATTR_ID,
             ORDER_ITEM_ID,
             CLASS_ID,
             OBJ_INST_ID,
             OBJ_ATTR,
             OPERATE,
             NEW_VALUE,
             OLD_VALUE,
             STATUS,
             CREATE_DATE,
             STATUS_DATE,
             REMARK,
             OBJ_ATTR_ID,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             UPDATE_DATE,
             DB_INST_ID,
             his_id)
            select crmv2.seq_order_item_proc_attr_id.nextval,
                   rec.order_item_id,
                   6,
                   rec.order_item_obj_id,
                   'devStaff',
                   '10',
                   v_staffid,
                   '',
                   '1000',
                   sysdate,
                   sysdate,
                   '',
                   10131,
                   rec.area_id,
                   rec.region_cd,
                   '',
                   '',
                   sysdate + 1 / 24,
                   1,
                   CRMV2.SEQ_OR_ITEM_PROC_ATTR_HIS_ID.NEXTVAL
              from dual;
        end if;
        ---修改发展团队

        select count(1)
          into v_n
          from crmv2.order_item_proc_attr_his c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10132;

        if v_n > 0 then

         begin

          select c.new_value
          into v_oldteam
          from crmv2.order_item_proc_attr_his c
         where c.order_item_id = rec.order_item_id
           and c.class_id = 6
           and c.obj_attr_id = 10132;

          exception when others then v_oldteam := '';
         end;


          update crmv2.order_item_proc_attr_his c
             set new_value = v_teamid, update_date = sysdate + 1 / 24
           where c.order_item_id = rec.order_item_id
             and c.class_id = 6
             and c.obj_attr_id = 10132;
        else
          insert into crmv2.order_item_proc_attr_his
            (ORDER_ITEM_PROC_ATTR_ID,
             ORDER_ITEM_ID,
             CLASS_ID,
             OBJ_INST_ID,
             OBJ_ATTR,
             OPERATE,
             NEW_VALUE,
             OLD_VALUE,
             STATUS,
             CREATE_DATE,
             STATUS_DATE,
             REMARK,
             OBJ_ATTR_ID,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             UPDATE_DATE,
             DB_INST_ID,
             HIS_ID)
            select crmv2.seq_order_item_proc_attr_id.nextval,
                   rec.order_item_id,
                   6,
                   rec.order_item_obj_id,
                   'devTeam',
                   '10',
                   v_teamid,
                   '',
                   '1000',
                   sysdate,
                   sysdate,
                   '',
                   10132,
                   rec.area_id,
                   rec.region_cd,
                   '',
                   '',
                   sysdate + 1 / 24,
                   1,
                   CRMV2.SEQ_OR_ITEM_PROC_ATTR_HIS_ID.NEXTVAL
              from dual;
        end if;

      end loop;
      update crmv2.customer_order_his co
         set co.update_date = sysdate + 1 / 24
       where co.cust_so_number = v_custnumber;
    end if;




      insert into itsc_crmv2.crm_wh_bak
      (TAL_NAME,
       KEY_ID,
       MODI_COLUMN,
       MODI_AREA,
       OLD_VALUE,
       NEW_VALUE,
       MODI_ACTION,
       MODI_SPEC,
       OFFER_SPEC,
       PROCE,
       MODI_STAFF,
       STAFF_AREA,
       MODI_REASON,
       MODI_TIME,
       REASON,
       MODI_TYPE)
      select 'ORDER_ITEM',
             '',
             'ORDER_ITEM_PROC_ATTR.NEW_VALUE',
             6,
             V_OLDSTAFF,
             v_staffid,
             'MODIFY',
             10131,
             '',
             'CRMV2.PKG_QZ.CHANGE_DEV_STAFF_TEAM',
             V_BSTAFF,
             '6',
             V_REMARK,
             SYSDATE,
             '修改发展人',
             '订单类'
        from dual;


      insert into itsc_crmv2.crm_wh_bak
      (TAL_NAME,
       KEY_ID,
       MODI_COLUMN,
       MODI_AREA,
       OLD_VALUE,
       NEW_VALUE,
       MODI_ACTION,
       MODI_SPEC,
       OFFER_SPEC,
       PROCE,
       MODI_STAFF,
       STAFF_AREA,
       MODI_REASON,
       MODI_TIME,
       REASON,
       MODI_TYPE)
      select 'ORDER_ITEM',
             '',
             'ORDER_ITEM_PROC_ATTR.NEW_VALUE',
             6,
             V_OLDteam,
             v_teamid,
             'MODIFY',
             10131,
             '',
             'CRMV2.PKG_QZ.CHANGE_DEV_STAFF_TEAM',
             V_BSTAFF,
             '6',
             V_REMARK,
             SYSDATE,
             '修改发展团队',
             '订单类'
        from dual;

    commit;
    o_msg := '修改成功';

  exception
    when others then
      o_msg := '订单号输入有误，请重新输入';
  end;

  procedure release_TermKey(in_key        in varchar2,
                            in_remark     in varchar2,
                            in_modi_staff in varchar2,
                            o_msg         out varchar2) is
    v_key    varchar2(100) := replace(in_key, ' ', '');
    v_remark varchar2(100) := replace(in_remark, ' ', '');
    v_staff  varchar2(100) := replace(in_modi_staff, ' ', '');
    v_n      number(10);
    --   v_n2     number(10);
    v_id     number(10);
    v_occupy number(10);
    v_store  number(10);
    v_spec   number(10);

          ---备份表中需要的字段
    v_bstaff varchar2(100);


  begin
    --------------------------------参数准确性判断----------------------------
    --A.  入参必须都要填，未填的返回报错，说明哪个入参没有填写
    if v_key is null then
      o_msg := '实物串号未填写';
      return;
    elsif v_remark is null then
      o_msg := '流程ID未填写';
      return;
    elsif v_staff is null then
      o_msg := '修改人员未填写';
      return;
    end if;

     --备份数据提取

    select SYS_CONTEXT('USERENV', 'SESSION_USER') into v_bstaff from dual;

    if v_bstaff = 'CRMV2' then
      v_bstaff := v_staff;
    end if;

    -- B.  判断传入的流程id是否是>3500000的7位数字，否则返回报错信息：流程id有误

    begin
      if to_number(v_remark) <= 3500000 then

        o_msg := '流程ID输入有误，请重新输入';
        return;
      end if;

    exception
      when others then
        o_msg := '流程ID输入有误，请重新输入';
        return;
    end;

    ----------------------------------------------------------------------------

    --C．  判断串号是否存在，不存在则返回报错信息：串号有误
    select count(1)
      into v_n
      from crmv1.mkt_resource mr
     where mr.mkt_reso_key = v_key;

    if v_n = 0 then
      o_msg := '串号有误,不存在';
      return;
    end if;

    --D． 必须是已入库的串号且所在仓库为泉州地区下的仓库才允许修改，
    --否则返回报错信息：非泉州地区串号，不允许修改
    select count(1)
      into v_n
      from crmv1.mkt_resource   mr,
           crmv1.mkt_reso_store mrs,
           crmv2.common_region  cr
     where mr.mkt_reso_key = v_key
       and mr.storage_id = mrs.store_id
       and mrs.region_id = cr.common_region_id
       and cr.region_code = '0595'
       and mr.state != '70D';

    if v_n = 0 then
      o_msg := '非泉州地区串号，不允许修改';
      return;
    end if;

    --E． 判断串号是否有关联在用或在途的套餐或用户，
    --有的话需返回报错信息：该串号已被用户XXX使用，
    select mr.mkt_reso_id, mr.storage_id, mr.mkt_reso_spec_id
      into v_id, v_store, v_spec
      from crmv1.mkt_resource mr
     where mr.mkt_reso_key = v_key;

    select count(1)
      into v_n
      from crmv1.mkt_occupy mo, crmv2.prod_inst pi
     where mo.mkt_reso_id = v_id
       and mo.buy_prod_id = pi.prod_inst_id
       and pi.status_cd != '110000';

    if v_n > 0 then
      o_msg := '该串号已被用户使用,请确认串号是否有误';
      return;
    end if;

    select mkt_occupy_id
      into v_occupy
      from crmv1.mkt_occupy
     where mkt_reso_id = v_id;

    -- 释放
    update crmv1.mkt_resource set state = '70A' where mkt_reso_id = v_id;

    insert into crmv1.mkt_occupy_his
      select * from crmv1.mkt_occupy where mkt_reso_id = v_id;

    update crmv1.mkt_occupy_his a
       set a.remark = v_staff || '于' ||
                      to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') || '释放:' ||
                      v_remark
     where mkt_reso_id = v_id;

    begin
      insert into crmv2.prod_res_inst_rel_his
        (prod_res_inst_rel_id,
         prod_inst_id,
         mkt_res_inst_id,
         type_cd,
         property_type,
         create_date,
         status_cd,
         status_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id)
        select prod_res_inst_rel_id,
               prod_inst_id,
               mkt_res_inst_id,
               type_cd,
               property_type,
               create_date,
               status_cd,
               status_date,
               sysdate + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_prod_res_inst_rel_his_id.nextval
          from crmv2.prod_res_inst_rel
         where mkt_res_inst_id = v_occupy;
    exception
      when others then
        o_msg := 'prod_res_inst_rel_his,请联系IT';
        return;

    end;
    begin
      insert into crmv2.offer_res_inst_rel_his
        (offer_res_inst_rel_id,
         mkt_res_inst_id,
         prod_offer_inst_id,
         use_prod_inst_id,
         create_date,
         status_cd,
         status_date,
         update_date,
         proc_serial,
         area_id,
         region_cd,
         update_staff,
         create_staff,
         his_id)
        select offer_res_inst_rel_id,
               mkt_res_inst_id,
               prod_offer_inst_id,
               use_prod_inst_id,
               create_date,
               status_cd,
               status_date,
               sysdate + 1 / 24,
               proc_serial,
               area_id,
               region_cd,
               update_staff,
               create_staff,
               crmv2.seq_offer_res_inst_rel_his_id.nextval
          from crmv2.offer_res_inst_rel
         where mkt_res_inst_id = v_occupy;
    exception
      when others then
        o_msg := 'offer_res_inst_rel_his,请联系IT';
        return;

    end;

    --删除在用记录

    delete crmv1.mkt_occupy where mkt_occupy_id = v_occupy;

    delete crmv2.prod_res_inst_rel where mkt_res_inst_id = v_occupy;

    delete crmv2.offer_res_inst_rel where mkt_res_inst_id = v_occupy;

    --修改库存
    update crmv1.mkt_store_item a
       set a.usage_count = a.usage_count + 1
     where a.store_id = v_store
       and a.mkt_reso_spec_id = v_spec;


      insert into itsc_crmv2.crm_wh_bak
      (TAL_NAME,
       KEY_ID,
       MODI_COLUMN,
       MODI_AREA,
       OLD_VALUE,
       NEW_VALUE,
       MODI_ACTION,
       MODI_SPEC,
       OFFER_SPEC,
       PROCE,
       MODI_STAFF,
       STAFF_AREA,
       MODI_REASON,
       MODI_TIME,
       REASON,
       MODI_TYPE)
      select 'MKT_RESOURCE',
             v_id,
             'STATE',
             6,
             '',
             '70A',
             'MODIFY',
             '',
             '',
             'CRMV2.PKG_QZ.RELEASE_TERMKEY',
             V_BSTAFF,
             '6',
             V_REMARK,
             SYSDATE,
             '释放串号',
             '实物类'
        from dual;

    o_msg := '处理成功';
    commit;

  end;
end PKG_QZ;
/
