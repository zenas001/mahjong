CREATE PACKAGE           PKG_CRM2_SQL_monitor IS
/*
 功能：监控新增的sql语句
 时间：2014-04-13
 作者：郑宗宇
*/
  PROCEDURE P_GET_DAY_SQL;
  function remove_constants( p_query in varchar2 ) return VARCHAR2;
  END;
/
