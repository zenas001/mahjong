CREATE package           PKG_NX_INTF_WEIHU is

  -- Author  : CHENJIANGYUAN
  -- Created : 2013/10/20 11:01:35
  -- Purpose : 宁夏接口数据维护

  procedure proc_intf_resend_data; --集团漏送数据重送集团

end PKG_NX_INTF_WEIHU;
/
