CREATE package           PKG_CRM2_PROD_SYNC_BAK is

  -- Author  : zhengcl
  -- Created : 2012-7-11 10:17:22
  -- Purpose : CRM2.0产品销售品配置同步数据比对
  /*
     根据传入的同步表主键，取出同步脚本。
     根据同步脚本取出本地表的数据，放入名为 SYNC_FROM_201207100945_1
         (该表名自动生成，字段与原表相同，SYNC_FROM+sysdate+表执行顺序)的表内，
     根据同步脚本通过链接取出目标库要被覆盖的数据，放入名为 SYNC_TO_201207100945_1
         (该表名自动生成，字段与原表相同，SYNC_TO+sysdate+表执行顺序) 的表内
     比对两个表，取出要变更的数据放入 SYNC_MINU_201207100945_1 的表中，
       该表字段为“KEY_ID”放置主键，“MINUS_OP”放置操作类型ADD,DEL,UPDATE。
     根据比对表再处理一次数据，通过链接与目标实例表数据做判断，
       针对DEL类型数据增加与实例数据判断，如果已经存在实例，则操作类型更改成DELUP
  */
  PROCEDURE p_createSyncTempTable(i_syncId       in number, --同步表ID
                                  i_id           in number, --销售品规格ID，产品规格ID
                                  i_areaId       in number, --配置区域
                                  i_link         in VARCHAR2, --目标库的链接
                                  o_result       out VARCHAR2, --返回标识
                                  o_tmpTableName out VARCHAR2, --临时表名
                                  o_msg          out VARCHAR2);
  /*
     删除同步的临时表数据，避免数据表冗余
  */
  PROCEDURE p_dropSyncTempTable(i_minuTable in VARCHAR2, --临时差异表
                                o_result    out VARCHAR2, --返回标识
                                o_msg       out VARCHAR2);
end PKG_CRM2_PROD_SYNC;
/
