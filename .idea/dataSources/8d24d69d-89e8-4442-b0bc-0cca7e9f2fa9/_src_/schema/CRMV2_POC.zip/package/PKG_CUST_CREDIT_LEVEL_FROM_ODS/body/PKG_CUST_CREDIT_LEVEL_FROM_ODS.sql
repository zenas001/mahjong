CREATE PACKAGE BODY           PKG_CUST_CREDIT_LEVEL_FROM_ODS IS

  --从ODS获取客户信用等级
  /*
  2.0                     1.0
 有限信用等级   100000    6    C2
 1A	            100100    1    A
 2A	            100200    2    B1
 3A	            100300    3    B2
 4A	            100400    4    B3
 无限信用等级   110000    0    客户级别未定
 5A              110100    5    C1
 1.0对应：          DECODE(A.CUST_CREDIT,
                  NULL,0,    110000
                  'A',1,     100100
                  'B1', 2,   100200
                  'B2',3,    100300
                  'B3',4,    100400
                  'C', 5)    110100
  */
  PROCEDURE PROC_SYNC_CUST_CREDIT_LEVEL IS
      V_COUNT           NUMBER:= 0;
      V_CREDIT_LEVEL    RESULT_CUST_CREDIT.CREDIT_LEVEL%TYPE;
      V_SQL_ERROR       RESULT_CUST_CREDIT.NOTE%TYPE;
      V_FLAG            NUMBER;
  BEGIN
      FOR REC IN
         (   SELECT CUST_ID,
                    DECODE(A.CREDIT_LEVEL,
                            NULL, '110000',
                            'A', '100100',
                            'B1','100200',
                            'B2','100300',
                            'B3','100400',
                            'C', '110100',
                            'ERROR')  CREDIT_LEVEL ,
                     CREATE_DATE
               FROM RESULT_CUST_CREDIT A
              WHERE A.STATE = 'W')  LOOP

          V_SQL_ERROR := '';
          V_COUNT      := V_COUNT + 1;
          V_FLAG := 0;

          BEGIN
           SELECT NVL(CREDIT_LEVEL, '110000') INTO V_CREDIT_LEVEL
            FROM CUST_CREDIT
           WHERE CUST_ID =  REC.CUST_ID
             AND ROWNUM = 1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
               V_FLAG := -1;
            WHEN OTHERS THEN
               V_FLAG:= -2;
               V_SQL_ERROR :='查CUST_CREDIT.CREDIT_LEVEL错：'|| SUBSTR(SQLERRM,400);
          END;

          BEGIN
            IF V_FLAG = -1 THEN
              INSERT INTO CUST_CREDIT
             ( CUST_CREDIT_ID ,  CUST_ID ,  CREDIT_LEVEL ,  CREDIT_VALUE ,  EVALUATE_TIME ,
               EFF_DATE ,  EXP_DATE ,  STATUS_CD ,  STATUS_DATE ,  CREATE_DATE ,
                UPDATE_DATE ,AREA_ID ,  REGION_CD ,  UPDATE_STAFF ,  CREATE_STAFF )
              SELECT
               SEQ_CUST_CREDIT_ID.NEXTVAL,REC.CUST_ID,REC.CREDIT_LEVEL,'',REC.CREATE_DATE,
               REC.CREATE_DATE,NULL,1000,SYSDATE,SYSDATE,SYSDATE,
               C.AREA_ID,C.REGION_CD,NULL,NULL
                FROM CUST C
               WHERE CUST_ID = REC.CUST_ID
                 AND ROWNUM = 1 ;
               UPDATE RESULT_CUST_CREDIT A
                 SET STATE = 'C'
               WHERE CUST_ID = REC.CUST_ID
                 AND STATE = 'W';
            ELSIF V_FLAG = -2 THEN
              UPDATE RESULT_CUST_CREDIT A
                 SET STATE = 'F', NOTE = V_SQL_ERROR
               WHERE CUST_ID = REC.CUST_ID
                 AND STATE = 'W';
              COMMIT;
            ELSIF  REC.CREDIT_LEVEL = V_CREDIT_LEVEL THEN
              UPDATE RESULT_CUST_CREDIT A
                 SET STATE = 'C', NOTE = '值一致,无需更新'
               WHERE CUST_ID = REC.CUST_ID
                 AND STATE = 'W';
            ELSIF  REC.CREDIT_LEVEL = 'ERROR' THEN
              UPDATE RESULT_CUST_CREDIT A
                 SET STATE = 'F', NOTE = '传入值无法转换！'
               WHERE CUST_ID = REC.CUST_ID
                 AND STATE = 'W';
            ELSE
              INSERT INTO CUST_CREDIT_HIS
             ( CUST_CREDIT_ID ,  CUST_ID ,  CREDIT_LEVEL ,  CREDIT_VALUE ,  EVALUATE_TIME ,
               EFF_DATE ,  EXP_DATE ,  STATUS_CD ,  STATUS_DATE ,  CREATE_DATE ,
                UPDATE_DATE ,AREA_ID ,  REGION_CD ,  UPDATE_STAFF ,  CREATE_STAFF,
                HIS_ID )
              SELECT
              CUST_CREDIT_ID ,  CUST_ID ,  CREDIT_LEVEL ,  CREDIT_VALUE ,  EVALUATE_TIME ,
               EFF_DATE ,  EXP_DATE ,  STATUS_CD ,  STATUS_DATE ,  CREATE_DATE ,
                UPDATE_DATE ,AREA_ID ,  REGION_CD ,  UPDATE_STAFF ,  CREATE_STAFF,
                SEQ_CUST_CREDIT_HIS_ID.NEXTVAL
                FROM CUST_CREDIT
               WHERE CUST_ID = REC.CUST_ID;
              UPDATE CUST_CREDIT
                 SET CREDIT_LEVEL = REC.CREDIT_LEVEL,UPDATE_DATE = SYSDATE
               WHERE CUST_ID = REC.CUST_ID;
               UPDATE RESULT_CUST_CREDIT A
                 SET STATE = 'C'
               WHERE CUST_ID = REC.CUST_ID
                 AND STATE = 'W';
            END IF;

            IF (V_COUNT = 1000) THEN
              V_COUNT := 0;
              COMMIT;
            END IF;

          EXCEPTION
            WHEN OTHERS THEN
              V_SQL_ERROR := SUBSTR(SQLERRM,1,500);
              ROLLBACK;
              UPDATE RESULT_CUST_CREDIT A
                 SET STATE = 'F', NOTE = V_SQL_ERROR
               WHERE CUST_ID = REC.CUST_ID
                 AND STATE = 'W';
              COMMIT;
          END;
      END LOOP;
      COMMIT;

      --所有操作做完将接口表转移到 历史表
      INSERT INTO RESULT_CUST_CREDIT_HIS
        SELECT * FROM RESULT_CUST_CREDIT;
      EXECUTE IMMEDIATE 'TRUNCATE TABLE RESULT_CUST_CREDIT';
      COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
  END PROC_SYNC_CUST_CREDIT_LEVEL;


END ;
/
