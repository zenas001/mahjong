CREATE PACKAGE           PKG_CLOB_TO_STR IS

  PROCEDURE CLOB_TO_STR_MAIN1(IN_CLOB        in CLOB,
                              IN_PRIMARY_KEY IN VARCHAR2,
                              IN_PARAM       in VARCHAR2,
                              IN_ID          in number,
                              IN_TABLE_NAME  IN VARCHAR2);
  PROCEDURE CLOB_TO_STR_MAIN(IN_CLOB        in CLOB,
                             IN_PRIMARY_KEY IN VARCHAR2,
                             IN_PARAM       in VARCHAR2,
                             IN_ID          in number,
                             IN_TABLE_NAME  IN VARCHAR2);
  function CLOB_TO_STR_SINGLE1(IN_CLOB   IN CLOB,
                               IN_COLUMN IN VARCHAR2,
                               IN_I      IN NUMBER) RETURN VARCHAR2;
  FUNCTION GET_CHAR_CNT1(IN_CHAR IN CLOB, IN_CONDITION IN VARCHAR2)
    RETURN NUMBER;

END PKG_CLOB_TO_STR;
/
