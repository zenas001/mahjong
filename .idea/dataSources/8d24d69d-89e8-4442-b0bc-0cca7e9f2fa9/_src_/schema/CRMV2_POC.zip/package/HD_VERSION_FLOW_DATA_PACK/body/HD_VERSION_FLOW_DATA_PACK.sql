CREATE PACKAGE BODY           HD_VERSION_FLOW_DATA_PACK IS

  PROCEDURE HD_VERSION_FLOW_DATA IS

    V_OPERATOR_TYPE_10_COUNT   NUMBER;
    V_OPERATOR_TYPE_10_AREA_ID NUMBER;
    V_OPERATOR_TYPE_10_ORG_ID  NUMBER;
    V_OPERATOR_TYPE_BL_COUNT   NUMBER;
    V_PRODUCT_NAME             VARCHAR(200);
    V_PROD_OFFER_NAME          VARCHAR(200);

    B_SAVE_VERSION_FLOW BOOLEAN;

    CURSOR SYS_VIP_VO IS
      SELECT SS.VERSION_NUM, SS.VERSION_SORT
        FROM SYS_VIP SS
       WHERE SS.STATUS_CD = '1000';
  BEGIN

    B_SAVE_VERSION_FLOW := DEL_VERSION_FLOW();
    FOR CUR IN SYS_VIP_VO LOOP
      BEGIN
        SELECT COUNT(1)
          INTO V_OPERATOR_TYPE_10_COUNT
          FROM LOG_INF LI
         WHERE LI.SRC_VERSION = CUR.VERSION_NUM
           AND LI.OPERATOR_TYPE = '10';
        B_SAVE_VERSION_FLOW := SAVE_VERSION_FLOW(CUR.VERSION_NUM,
                                                 '',
                                                 'LOGIN_STAFF',
                                                 '',
                                                 V_OPERATOR_TYPE_10_COUNT);

        SELECT COUNT(1)
          INTO V_OPERATOR_TYPE_10_AREA_ID
          FROM (SELECT AREA_ID
                  FROM (SELECT *
                          FROM LOG_INF LI
                         WHERE LI.SRC_VERSION = CUR.VERSION_NUM
                           AND LI.OPERATOR_TYPE = '10')
                 GROUP BY AREA_ID);
        B_SAVE_VERSION_FLOW := SAVE_VERSION_FLOW(CUR.VERSION_NUM,
                                                 '',
                                                 'LOGIN_AREA',
                                                 '',
                                                 V_OPERATOR_TYPE_10_AREA_ID);

        SELECT COUNT(1)
          INTO V_OPERATOR_TYPE_10_ORG_ID
          FROM (SELECT ORG_ID
                  FROM (SELECT *
                          FROM LOG_INF LI
                         WHERE LI.SRC_VERSION = CUR.VERSION_NUM
                           AND LI.OPERATOR_TYPE = '10')
                 GROUP BY ORG_ID);
        B_SAVE_VERSION_FLOW := SAVE_VERSION_FLOW(CUR.VERSION_NUM,
                                                 '',
                                                 'LOGIN_ORG',
                                                 '',
                                                 V_OPERATOR_TYPE_10_ORG_ID);

        SELECT COUNT(distinct BL.Cust_So_Number)
          INTO V_OPERATOR_TYPE_BL_COUNT
          FROM BUSINESS_LIST BL
         WHERE BL.SRC_VERSION = CUR.VERSION_NUM;
        B_SAVE_VERSION_FLOW := SAVE_VERSION_FLOW(CUR.VERSION_NUM,
                                                 '',
                                                 'SUM',
                                                 '',
                                                 V_OPERATOR_TYPE_BL_COUNT);

        FOR BL_COUNT IN (SELECT ACTION_LIST, PRODUCT_ID, COUNT(1) CNT
                           FROM (SELECT *
                                   FROM BUSINESS_LIST BL
                                  WHERE BL.SRC_VERSION = CUR.VERSION_NUM
                                    AND BL.ACTION_LIST IS NOT NULL
                                    AND BL.PRODUCT_ID IS NOT NULL)
                          GROUP BY ACTION_LIST, PRODUCT_ID) LOOP

          SELECT P.PRODUCT_NAME
            INTO V_PRODUCT_NAME
            FROM PRODUCT P
           WHERE P.PRODUCT_ID = BL_COUNT.PRODUCT_ID;
          B_SAVE_VERSION_FLOW := SAVE_VERSION_FLOW(CUR.VERSION_NUM,
                                                   V_PRODUCT_NAME,
                                                   'PRODUCT',
                                                   BL_COUNT.ACTION_LIST,
                                                   BL_COUNT.CNT);
        END LOOP;

        FOR BL_COUNT IN (SELECT ACTION_LIST, PROD_OFFER_ID, COUNT(1) CNT
                           FROM (SELECT *
                                   FROM BUSINESS_LIST BL
                                  WHERE BL.SRC_VERSION = CUR.VERSION_NUM
                                    AND BL.ACTION_LIST IS NOT NULL
                                    AND BL.PROD_OFFER_ID IS NOT NULL)
                          GROUP BY ACTION_LIST, PROD_OFFER_ID) LOOP

          SELECT PO.PROD_OFFER_NAME
            INTO V_PROD_OFFER_NAME
            FROM PROD_OFFER PO
           WHERE PO.PROD_OFFER_ID = BL_COUNT.PROD_OFFER_ID;
          B_SAVE_VERSION_FLOW := SAVE_VERSION_FLOW(CUR.VERSION_NUM,
                                                   V_PROD_OFFER_NAME,
                                                   'OFFER',
                                                   BL_COUNT.ACTION_LIST,
                                                   BL_COUNT.CNT);
        END LOOP;

      END;
    END LOOP;

    COMMIT;
  END;

  FUNCTION SAVE_VERSION_FLOW(SRC_VERSION IN VARCHAR,
                             OBJECT_NAME IN VARCHAR,
                             OBJECT_TYPE IN VARCHAR,
                             ACTION_LIST IN VARCHAR,
                             CNT         IN NUMBER) RETURN BOOLEAN IS
    V_SRC_VERSION VARCHAR(200);
    V_OBJECT_NAME VARCHAR(200);
    V_OBJECT_TYPE VARCHAR(200);
    V_ACTION_LIST VARCHAR(200);
    V_CNT         VARCHAR(200);

  BEGIN

    V_SRC_VERSION := SRC_VERSION;
    V_OBJECT_NAME := OBJECT_NAME;
    V_OBJECT_TYPE := OBJECT_TYPE;
    V_ACTION_LIST := ACTION_LIST;
    V_CNT         := CNT;

    INSERT INTO VERSION_FLOW
      (VERSION_FLOW_ID,
       SRC_VERSION,
       OBJECT_NAME,
       OBJECT_TYPE,
       ACTION_LIST,
       CNT,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       AREA_ID,
       REGION_CD,
       CREATE_STAFF,
       UPDATE_DATE,
       UPDATE_STAFF)
    VALUES
      (SEQ_VERSION_FLOW_ID.NEXTVAL,
       V_SRC_VERSION,
       V_OBJECT_NAME,
       V_OBJECT_TYPE,
       V_ACTION_LIST,
       V_CNT,
       '1000',
       SYSDATE,
       SYSDATE,
       NULL,
       NULL,
       NULL,
       SYSDATE,
       NULL);

    RETURN TRUE;
  END;
  FUNCTION DEL_VERSION_FLOW RETURN BOOLEAN IS
  BEGIN
    INSERT INTO VERSION_FLOW_HIS
      (HIS_ID,
       VERSION_FLOW_ID,
       SRC_VERSION,
       OBJECT_NAME,
       OBJECT_TYPE,
       ACTION_LIST,
       CNT,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       AREA_ID,
       REGION_CD,
       CREATE_STAFF,
       UPDATE_DATE,
       UPDATE_STAFF)
      (SELECT SEQ_VERSION_FLOW_HIS_ID.NEXTVAL,
              VERSION_FLOW_ID,
              SRC_VERSION,
              OBJECT_NAME,
              OBJECT_TYPE,
              ACTION_LIST,
              CNT,
              STATUS_CD,
              STATUS_DATE,
              CREATE_DATE,
              AREA_ID,
              REGION_CD,
              CREATE_STAFF,
              UPDATE_DATE,
              UPDATE_STAFF
         FROM VERSION_FLOW VF);
    DELETE FROM VERSION_FLOW;
    RETURN TRUE;
  END;
END HD_VERSION_FLOW_DATA_PACK;
/
