CREATE PACKAGE           PKG_PRICINGPLAN_CONV IS

  -- AUTHOR  : TIANSHM
  -- CREATED : 2014/5/12
  -- MODIFY  :
  -- PURPOSE : 转售定价转换省内定价
  /*
    create table mvno_lte_pricing_plan_config(seq number(9),offer_id number(18),offer_comments varchar2(4000),prod_offer_id number(9),prod_offer_name varchar2(4000),pricing_plan_id number(12),stype number(2),stype_desc varchar2(200),vparam varchar2(200),state varchar2(3),comments varchar2(4000));

    create sequence mvno_lte_plan_config_SEQ
    minvalue 1
    maxvalue 999999999
    start with 830080113
    increment by 1
    cache 20;

    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,1,'月租套餐费','600000','00A','模板为策略ID=820087455;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,2,'国内流量赠送','266240','00A','模板为策略ID=820087177;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,3,'国内流量赠送_首月','266240','00A','模板为策略ID=820087179;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,4,'上网超出资费','3','00A','模板为策略ID=820087186;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,5,'赠送短信（新模式）','30','00A','模板为策略ID=820087198;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,6,'赠送短信_首月','30','00A','模板为策略ID=820087199;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,7,'短信超出资费','100','00A','模板为策略ID=820087017;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,8,'赠送通话时长','100','00A','模板为策略ID=820087192;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,9,'赠送通话时长_首月','100','00A','模板为策略ID=820087191;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,10,'语音超出','2000','00A','模板为策略ID=820087194;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,11,'语音被叫','0','00A','模板为策略ID=820088302;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,12,'语音被叫(有费用)','0','00A','模板为策略ID=820088299;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,13,'月租套餐费(非首月)','0','00A','模板为策略ID=820089073;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,14,'国内流量赠送(非首月)','0','00A','模板为策略ID=820089055;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,15,'赠送通话时长(首月折算)','100','00A','模板为策略ID=820089073;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,16,'主叫资费(国内、省内主叫）首月不折算)','1000','00A','模板为策略ID=820088298;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,17,'转售赠送来显','0','00A','模板为策略ID=820089973;');
    insert into mvno_lte_pricing_plan_config values(mvno_lte_plan_config_SEQ.Nextval,134016389,'套餐内容：套餐费：60元；套餐内包括：含国内1X\3G上网流量260M；国内语音拨打100分钟（含呼转；不含IP通话）；含国内点对点短信30条；国内接听免费；',900021224,'极致套餐-C版-60元',54005,18,'主叫资费(本地主叫）首月不折算)','1000','00A','模板为策略ID=820088301;');
  */

  --功    能：获得租费首月套餐参考值
  FUNCTION F_GET_REF_VALUE(SPROD_OFFER_ID   NUMBER,
                           SPROD_OFFER_NAME VARCHAR2) RETURN NUMBER;
  --功    能：获得费率参考值
  FUNCTION F_GET_RATE_REF_VALUE(SVALUE VARCHAR2) RETURN NUMBER;
  --功    能：转售租费
  PROCEDURE P_MVNO_RENT_STRATEGY;
  --功    能：国内流量赠送
  PROCEDURE P_MVNO_GN_RATABLE_STRATEGY;
  --功    能：国内流量赠送_首月
  PROCEDURE P_MVNO_GN_RATABLE_SY_STRATEGY;
  --功    能：上网超出资费
  PROCEDURE P_MVNO_RATABLE_CH_STRATEGY;
  --功    能：赠送短信（新模式）
  PROCEDURE P_MVNO_RATABLE_SMS_STRATEGY;
  --功    能：赠送短信_首月
  PROCEDURE P_MVNO_RATABLE_SMS_SY_STRATEGY;
  --功    能：短信超出资费
  PROCEDURE P_MVNO_SMS_CY_STRATEGY;
  --功    能：赠送通话时长
  PROCEDURE P_MVNO_RATABLE_VOICE_STRATEGY;
  --功    能：赠送通话时长_首月
  PROCEDURE P_MVNO_RATABLE_VOICE_SY_STY;
  --功    能：语音超出资费
  PROCEDURE P_MVNO_VOICE_CH_STRATEGY;
  --功    能：语音被叫(费用为0）
  PROCEDURE P_MVNO_VOICE_BJ_STRATEGY;
  --功    能：语音被叫（费用不为0）
  PROCEDURE P_MVNO_VOICE_BJ2_STRATEGY;
  --功    能：转售租费(非首月)
  PROCEDURE P_MVNO_RENT2_STRATEGY;
  --功    能：国内流量赠送(非首月)
  PROCEDURE P_MVNO_GN_RATABLE2_STRATEGY;
  --功    能：赠送通话时长(首月不折算)
  PROCEDURE P_MVNO_RATABLE_VOICE_BSY_STY;
  --功    能：主叫资费
  PROCEDURE P_MVNO_VOICE_ZJ_STRATEGY;
  --功    能：主叫资费
  PROCEDURE P_MVNO_VOICE_ZJ2_STRATEGY;
  --功    能：转售赠送来显
  PROCEDURE P_MVNO_RATE_ZS_STRATEGY;

  --主过程
  PROCEDURE P_MVNO_PRICING_PLAN_QL;

END PKG_PRICINGPLAN_CONV;
/
