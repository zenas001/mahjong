CREATE PACKAGE BODY           "PKG_CALC_CUST_SUB_TYPE" is
  PROCEDURE FUNC_GET_BATCH_CUST_DATA(in_industry_cd  IN VARCHAR2, --行业类型
                                     in_khgksx       IN VARCHAR2, --管控属性
                                     o_cust_sub_type OUT VARCHAR2) is

    v_industry_cd VARCHAR2(50);
    v_khgksx      VARCHAR2(50);
  BEGIN
    v_industry_cd := in_industry_cd;
    v_khgksx      := in_khgksx;

    o_cust_sub_type := func_calc_cust_sub_type(v_industry_cd, v_khgksx);
  end FUNC_GET_BATCH_CUST_DATA;

end PKG_CALC_CUST_SUB_TYPE;
/
