CREATE package body           PKG_10000QRY is
  /* 客户经理信息查询 */
  PROCEDURE PROC_QUERY_KHJL_INFO(I_AREA_CODE   IN VARCHAR2, --区域，如：福州0591, 可空，为空时表示查询移动语音号码
                                 I_ACC_NBR     IN VARCHAR2, --业务号码
                                 I_EXT_PROD_ID IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                 O_ERR_CODE    OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG     OUT VARCHAR2, --错误信息
                                 O_KHJL_NAME   OUT VARCHAR2, --客户经理名称
                                 O_KHJL_PHONE  OUT VARCHAR2 --客户经理电话
                                 ) is
    V_CUST_ID CUST.CUST_ID%TYPE;
  begin
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    if I_AREA_CODE is null then
      begin
        select pi.owner_cust_id
          into V_CUST_ID
          from prod_inst pi
         where pi.acc_nbr = I_ACC_NBR
           and pi.product_id = 800000002
           and pi.status_cd != '110000';
      exception
        when no_data_found then
          O_ERR_CODE := 1;
          O_ERR_MSG  := '号码不存在';
          return;
      end;
    else
      begin
        select pi.owner_cust_id
          into V_CUST_ID
          from product p, prod_inst pi
         where p.product_id = pi.product_id
           and pi.area_code = I_AREA_CODE
           and pi.acc_nbr = I_ACC_NBR
           and p.ext_prod_id = I_EXT_PROD_ID
           and pi.status_cd != '110000';
      exception
        when no_data_found then
          O_ERR_CODE := 1;
          O_ERR_MSG  := '号码不存在';
          return;
      end;
    end if;

    ---客户经理名称
    begin
      SELECT e.party_name
        into O_KHJL_NAME
        FROM cust_assign_rel b, channel_member c, staff d, party e
       WHERE b.channel_member_id = c.channel_member_id
         AND c.staff_id = d.staff_id
         AND d.party_id = e.party_id
         AND b.cust_id = V_CUST_ID
         and rownum = 1;
    exception
      when no_data_found then
        O_KHJL_NAME := '';
    end;

    --客户经理联系信息
    begin
      select decode(e.mobile_phone,
                    '',
                    decode(e.office_phone, '', e.home_phone, e.office_phone),
                    e.mobile_phone)
        into O_KHJL_PHONE
        from cust_assign_rel    b,
             channel_member     c,
             staff              d,
             party_contact_info e
       where b.channel_member_id = c.channel_member_id
         and c.staff_id = d.staff_id
         and d.party_id = e.party_id
         and b.cust_id = V_CUST_ID
         and rownum = 1;
    exception
      when no_data_found then
        O_KHJL_PHONE := '';
    end;
  end PROC_QUERY_KHJL_INFO;

/************************************************************************
    Function    : 提供10000查询系统查询移动语音的客户信息
    Description ：移动语音客户信息查询
    Author　    ：
    Date        : 2013-05-08
    Parameter   :
                 I_ACC_NBR      -- 业务号码，如：18959190160
                 I_EXT_PROD_ID  -- 接入类产品外部编码，固定：天翼610003886
                 O_ERR_CODE     -- 错误编码（0--成功 1--失败）
                 O_ERR_MSG      -- 错误信息
                 O_CUST_NAME    -- 客户名称
                 O_CUST_TYPE    -- 客户类型
                 O_CREATE_DATE  -- 入网时间
                 O_CUST_LEVEL   -- 客户级别
                 O_VIP_CARD_NO  -- VIP卡号
                 O_CUST_NUMBER  -- 客户编码
                 O_AREA_CODE    -- 产品区域，如：福州0591
                 O_PROD_INST_ID -- 产品实例标识
  ************************************************************************/
  /* 客户信息查询 */
  PROCEDURE PROC_QUERY_CUST_INFO(I_ACC_NBR      IN VARCHAR2, --业务号码，如：18959190160
                                 I_EXT_PROD_ID  IN VARCHAR2, --接入类产品外部编码，如：天翼610003886
                                 O_ERR_CODE     OUT NUMBER, --错误编码（0--成功 1--失败）
                                 O_ERR_MSG      OUT VARCHAR2, --错误信息
                                 O_CUST_NAME    OUT VARCHAR2, --客户名称
                                 O_CUST_TYPE    OUT VARCHAR2, --客户类型
                                 O_CREATE_DATE  OUT VARCHAR2, --入网时间
                                 O_CUST_LEVEL   OUT VARCHAR2, --客户级别
                                 O_VIP_CARD_NO  OUT VARCHAR2, --VIP卡号
                                 O_CUST_NUMBER  OUT VARCHAR2, --客户编码
                                 O_AREA_CODE    OUT VARCHAR2, --产品区域，如：福州0591
                                 O_PROD_INST_ID OUT NUMBER --产品实例标识
                                 ) is

    V_CUST_ID CUST.CUST_ID%TYPE;
  begin
    O_ERR_CODE := 0;
    O_ERR_MSG  := '';

    begin
      select pi.owner_cust_id,pi.area_code,pi.prod_inst_id,to_char(pi.begin_rent_time,'YYYYMMDD')
        into V_CUST_ID,O_AREA_CODE,O_PROD_INST_ID,O_CREATE_DATE
        from product p, prod_inst pi
       where p.product_id = pi.product_id
         and pi.acc_nbr = I_ACC_NBR
         and p.ext_prod_id = I_EXT_PROD_ID
         and pi.status_cd != '110000';
    exception
      when no_data_found then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '号码不存在';
        return;
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查询号码出错:'||SUBSTR(SQLERRM,1,500);
        return;
    end;

    begin
      select party_name,
             av_ct.attr_value_name cust_type,
             av_cm.attr_value_name membership_level,
             vip_card_nbr,
             cust_number
        into O_CUST_NAME,
             O_CUST_TYPE,
             O_CUST_LEVEL,
             O_VIP_CARD_NO,
             O_CUST_NUMBER
        from (select p.party_name,
                     c.cust_type,
                     (select member_id from club_member cm
                       where cm.cust_id = V_CUST_ID
                         and rownum < 2  ) member_id,
                     (select membership_level from club_member cm
                       where cm.cust_id = V_CUST_ID
                         and rownum < 2 ) membership_level,
                     (select cmi.vip_card_nbr from club_member cm,club_member_info cmi
                       where cm.cust_id = V_CUST_ID
                         and cm.member_code = cmi.member_code
                         and rownum < 2) vip_card_nbr,
                     c.cust_number
                from cust c, party p
               where c.party_id = p.party_id
                 and c.cust_id = V_CUST_ID
                 and c.status_cd in ('1000', '1100')) a,
                 attr_value av_cm,
                 attr_value av_ct
        where a.membership_level = av_cm.attr_value(+)
          and av_cm.attr_id(+) = '9014'
          and a.cust_type = av_ct.attr_value(+)
          and av_ct.attr_id(+)= '68'
          and rownum < 2;
    exception
      when no_data_found then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '客户档案不存在';
        return;
      when others then
        O_ERR_CODE := 1;
        O_ERR_MSG  := '查客户档案出错:'||SUBSTR(SQLERRM,1,500);
        return;
    end;

  end PROC_QUERY_CUST_INFO;



end PKG_10000QRY;
/
