CREATE package body           P_CESHI is
  ----ADD SUJ

  procedure PROD_ATTR_CS_CS(I_AREA    in number, ---区域
                            I_ACCOUNT in varchar2, ---号码
                            O_MSG     out varchar2, ---返回
                            O_remark  out varchar2, ---返回错误日志
                            flag      out varchar2 ---失败为0，成功为1
                            ) IS

    V_ACCNBR         PROD_INST.ACC_NBR%TYPE;
    v_prod_inst_a_id prod_inst_rel.prod_inst_a_id%type;
    v_prod_inst_z_id prod_inst_rel.prod_inst_z_id%type;
    V_PRODUCT_NAME   PRODUCT.PRODUCT_NAME%TYPE;
    V_PRODUCT_TYPE   PRODUCT.PRODUCT_TYPE%TYPE;
    i                number;
    F_area           VARCHAR2(50);
  begin
    F_area := 0 || I_AREA;
    O_MSG  := '';
    i      := '0';
    for rec in (select a.acc_nbr,
                       b.product_name,
                       c.prod_inst_a_id,
                       c.prod_inst_z_id
                  from prod_inst a, product b, prod_inst_rel c
                 where a.acc_nbr = i_account
                   and a.area_code = F_area
                   and a.product_id = b.product_id
                   and a.prod_inst_id = c.prod_inst_a_id) LOOP

      i := i + 1;

      if i > 0 then

        for rec1 in (select b.product_name
                       from prod_inst a, product b
                      where a.prod_inst_id = rec.prod_inst_z_id
                        and a.status_cd = '100000'
                        and a.product_id = b.product_id) loop

          O_remark := O_remark || '<product>' || rec1.product_name ||
                      '</product>';

        end loop;

      end if;
      O_remark := O_remark || rec.acc_nbr || rec.product_name;
    end loop;

    /* exception
    when NO_DATA_FOUND then*/
    FLAG     := '1';
    O_remark := o_remark;
    O_MSG    := '无记录';
    return;

  end PROD_ATTR_CS_CS;

  procedure mkt_key_number(store_name in varchar2, ---仓库名称（团队名称）
                           mkt_dalei  in varchar2, ---号码
                           mkt_xilei  in varchar2, ---返回
                           O_remark   out varchar2, ---返回错误日志
                           flag       out varchar2 ---失败为0，成功为1
                           ) is

    v_store_id crmv1.mkt_reso_store.store_id%type;

  begin
    if store_name is null then
      O_remark := '请输入仓库名称（团队名称）';
    elsif mkt_dalei is null then
      O_remark := '请输入实物大类名称';
    elsif mkt_xilei is null then
      O_remark := '请输入实物细类名称';
    end if;

    begin
      v_store_id := '';
      select b.store_id
        into v_store_id
        from crmv1.te a, crmv1.mkt_reso_store b
       where a.chinesename = store_name
         and a.teid = b.team_id;
    exception
      when others then
        select b.store_id
          into v_store_id
          from crmv1.te a, crmv1.mkt_reso_store b
         where a.chinesename like '"%store_name%"'
           and a.teid = b.team_id;
    end;

    for rec1 in (select d.mkt_reso_key,
                        d.state,
                        c.usage_count,
                        b.MKT_RES_NAME,
                        a.MKT_RES_TYPE_ID
                   from crmv1.mkt_resource_type a,
                        crmv1.mkt_resource_spec b,
                        crmv1.mkt_store_item    c,
                        crmv1.mkt_resource      d
                  where a.MKT_RES_TYPE_NAME = mkt_dalei
                    and a.MKT_RES_TYPE_ID = b.MKT_RES_TYPE_ID
                    and b.MKT_RES_NAME = mkt_xilei
                    and b.MKT_RES_ID = c.mkt_reso_Spec_id
                    and c.store_id = d.storage_id
                    and d.storage_id = v_store_id
                    and c.mkt_Reso_spec_Id = d.mkt_reso_spec_id
                    and d.state = '70A'
                    and rownum < 2) loop

      O_remark := rec1.mkt_reso_key;
    end loop;

  end mkt_key_number;

  ---增加工号权限
  procedure GH_ADD_PRI(in_ghdl         in varchar2, ---工号
                       in_org          in varchar2, ---团队
                       in_privilege_id in varchar2, ---权限ID
                       O_remark        out varchar2, ---返回错误日志
                       flag            out varchar2 ---失败为0，成功为1
                       ) is
    i                number;
    v_system_user_id crmv2.system_user.system_user_id%type;
    v_org            crmv2.organization.org_id%type;
  begin
    O_remark := '';
    i        := '0';
    v_org    := '';

    begin
      select system_user_id
        into v_system_user_id
        from system_user
       where staff_code = in_ghdl;
    exception
      when others then
        O_remark := '工号不存在';
        flag     := '0';
        RETURN;
    end;
    if in_org is not null then
      begin
        select b.org_id
          into v_org
          from staff_position a, organization b
         where a.staff_id = v_system_user_id
           and a.org_id = b.org_id
           and (b.org_name = in_org or b.org_id = in_org);
      exception
        when no_data_found then
          begin
        select a.org_id
          into v_org
          from organization a
         where a.org_name = in_org;
         exception
        when no_data_found then
          O_remark := '工号团队不存在,输入正确的团队名称或者ID';
          flag     := '0';
          RETURN;
          end;
      end;
    end if;

    begin
      for rec in (select privilege_id
                    from privilege
                   where /*parent_privilege_id = '0'                                                                                         and*/
                   privilege_id = in_privilege_id
               and privilege_type = '1000'
               and status_cd = '1000') LOOP

        i := i + 1;
        if i > 0 then
          begin
            insert into STAFF_LIMIT
              select seq_staff_limit_id.nextval,
                     p.privilege_id,
                     v_system_user_id,
                     null,
                     null,
                     '1000',
                     sysdate,
                     sysdate,
                     sysdate,
                     null,
                     null,
                     v_system_user_id,
                     v_system_user_id,
                     11,
                     v_org,
                     null
                from privilege p
               start with p.privilege_id = rec.privilege_id
              connect by prior p.privilege_id = p.parent_privilege_id
                     and not exists
               (select *
                            from STAFF_LIMIT a, privilege b
                           where system_user_id = v_system_user_id
                             and a.privilege_id = b.privilege_id
                             and b.parent_privilege_id = rec.privilege_id);

            O_remark := '操作成功';
            flag     := '1';
          exception
            when others then
              O_remark := '数据库操作异常';
              flag     := '0';
              return;
          end;
          commit;
        end if;
      end loop;
      O_remark := '权限不存在';
      flag     := '0';

      for rec1 in (select privilege_id
                     from privilege
                    where privilege_id = in_privilege_id
                      and status_cd = '1000') LOOP

        i := i + 1;
        if i > 0 then
          begin
            insert into STAFF_LIMIT
              select seq_staff_limit_id.nextval,
                     p.privilege_id,
                     v_system_user_id,
                     null,
                     null,
                     '1000',
                     sysdate,
                     sysdate,
                     sysdate,
                     null,
                     null,
                     v_system_user_id,
                     v_system_user_id,
                     11,
                     v_org,
                     null
                from privilege p
               start with p.privilege_id = rec1.privilege_id
              connect by prior p.privilege_id = p.parent_privilege_id
                     and not exists
               (select *
                            from STAFF_LIMIT a, privilege b
                           where system_user_id = v_system_user_id
                             and a.privilege_id = b.privilege_id
                             and b.parent_privilege_id = rec1.privilege_id);

            O_remark := '操作成功';
            flag     := '1';
          exception
            when others then
              O_remark := '数据库操作异常';
              flag     := '0';
              return;
          end;
          commit;
        else
          O_remark := '权限不存在';
          flag     := '0';
        end if;
      end loop;
      return;
    end;
  end;

  ---删除工号权限
  procedure GH_DEL_PRI(in_ghdl         in varchar2, ---工号
                       in_org          in varchar2, ---团队
                       in_privilege_id in varchar2, ---权限ID
                       O_remark        out varchar2, ---返回错误日志
                       flag            out varchar2 ---失败为0，成功为1
                       ) is
  BEGIN
    O_remark := 1;
  END;

  procedure GH_PRIVILEGE(I_STAFF_CODE in varchar2, ---区域
                         I_ORG_NAME   in varchar2, ---号码
                         i_privilege  in varchar2,
                         O_remark     out varchar2, ---返回错误日志
                         flag         out varchar2 ---失败为0，成功为1
                         ) IS

    v_org_id            organization.org_id%type;
    staff_position_id_a STAFF_POSITION.STAFF_POSITION_ID%type;
    v_system_user_id    system_user.system_user_id%type;
    v_privilege_code    privilege.privilege_code%type;
    v_privilege_name    privilege.privilege_name%type;
    i                   number;
    F_area              VARCHAR2(50);
    O_MSG               VARCHAR2(1024);
    O_MSG1              VARCHAR2(1024);
    O_MSG1x             VARCHAR2(1024);
  begin

    i := '0';

    begin
      select c.org_id
        into v_org_id
        from system_user a, staff_POSITION b, organization c
       where a.staff_code = I_STAFF_CODE
         and a.staff_id = b.staff_id
         and b.org_id = c.org_id
         and c.org_id = I_ORG_NAME;
    exception
      when others then
        begin
          select c.org_id
            into v_org_id
            from organization c
           where c.org_ID = I_ORG_NAME;
        exception
          when others then
            O_remark := '团队不存在,请确认团队名称';
            flag     := '0';
            return;

            return;
        end;
    end;
    if v_org_id is not null then
      begin
        select a.system_user_id, b.staff_position_id
          into v_system_user_id, staff_position_id_a
          from system_user a, STAFF_POSITION b
         where a.staff_code = I_STAFF_CODE
           and a.staff_id = b.staff_id
           and b.org_id = v_org_id and rownum<2;
      end;

    end if;

    for rec in (SELECT privilege_name
                  FROM (SELECT DISTINCT C.*
                          FROM CRMV2.STAFF_LIMIT B, CRMV2.PRIVILEGE C
                         WHERE B.PRIVILEGE_ID = C.PRIVILEGE_ID
                           AND C.PRIVILEGE_TYPE = '1000'
                           AND C.PRIVILEGE_SUB_TYPE in ('10100', '10110')
                           AND B.SYSTEM_USER_ID = v_system_user_id ----用户ID
                           AND B.PRI_TYPE IN ('10', '11')
                           AND (B.ORG_ID = v_org_id OR B.ORG_ID IS NULL) --团队ID
                           AND B.STATUS_CD = '1000'
                           AND C.STATUS_CD = '1000'
                           and c.privilege_id = i_privilege)
                 ORDER BY DISP_ORDER) LOOP
      O_MSG    := '';
      O_MSG    := O_MSG || rec.privilege_name;
      O_remark := '工号当前拥有权限：' || O_MSG;
      flag := 1;

    end loop;

    for rec1 in (SELECT privilege_name, Role_name
                   FROM (SELECT DISTINCT D.*, A.*
                           FROM CRMV2.ROLE          A,
                                CRMV2.STAFF_ROLE    B,
                                CRMV2.ROLE_AUTH_REL C,
                                CRMV2.PRIVILEGE     D
                          WHERE B.ROLE_ID = C.ROLE_ID
                            AND C.PRIVILEGE_ID = D.PRIVILEGE_ID
                            AND D.PRIVILEGE_TYPE = '1000'
                            AND D.PRIVILEGE_SUB_TYPE in ('10100', '10110')
                            AND B.SYSTEM_USER_ID = v_system_user_id ----用户ID
                            AND C.PRI_TYPE IN ('10', '11')
                            AND (B.ORG_ID = v_org_id OR B.ORG_ID IS NULL) --团队ID
                            AND B.ROLE_ID = A.ROLE_ID
                            AND B.STATUS_CD = '1000'
                            AND C.STATUS_CD = '1000'
                            AND D.STATUS_CD = '1000'
                            and d.privilege_id = i_privilege)
                  ORDER BY DISP_ORDER) LOOP

      O_MSG1   := O_MSG1 || '"' || rec1.role_name || '",';
      O_MSG1x  := '角色' || O_MSG1 || '拥有' || rec1.privilege_name;
      O_remark := O_remark || O_MSG1x;
      flag := 2;
    end loop;

    for rec2 in (SELECT privilege_name, POSITION_name, role_privilege_id
                   FROM (SELECT /*+ use_nl(d)*/
                         DISTINCT E.*, f.*, d.*
                           FROM CRMV2.SYSTEM_USER           A,
                                CRMV2.STAFF_POSITION        B,
                                CRMV2.POSITION_ROLE_RELA    C,
                                CRMV2.ORG_ROLE_POSITION_REL ORP,
                                CRMV2.STAFF_POSITION        G,
                                CRMV2.ROLE_AUTH_REL         D,
                                CRMV2.PRIVILEGE             E,
                                CRMV2.POSITION              F
                          WHERE A.STAFF_ID = B.STAFF_ID
                            AND C.POSITION_ID = G.POSITION_ID
                            AND C.ROLE_ID = D.ROLE_ID
                            AND D.PRIVILEGE_ID = E.PRIVILEGE_ID
                            AND E.PRIVILEGE_TYPE = '1000'
                            AND E.PRIVILEGE_SUB_TYPE in ('10100', '10110')
                            AND A.SYSTEM_USER_ID = v_system_user_id ----用户ID
                            AND D.PRI_TYPE IN ('10', '11')
                            AND B.ORG_ID = v_org_id --团队ID
                            AND ORP.STAFF_POSITION_A_ID = B.STAFF_POSITION_ID
                            AND ORP.STAFF_POSITION_Z_ID = G.STAFF_POSITION_ID
                            AND ORP.STAFF_POSITION_A_ID = staff_position_id_a ---团队任职岗位ID
                            AND A.STATUS_CD = '1000'
                            AND B.STATUS_CD = '1000'
                            AND C.STATUS_CD = '1000'
                            AND D.STATUS_CD = '1000'
                            AND E.STATUS_CD = '1000'
                            AND G.STATUS_CD = '1000'
                            AND G.POSITION_ID = F.POSITION_ID
                            and e.privilege_id = i_privilege)
                  ORDER BY DISP_ORDER) LOOP

      O_MSG1 := O_MSG1 || '"' || rec2.position_name || '",';
    O_MSG1x  := '工位' || O_MSG1;
    O_remark := O_MSG1x;
    flag :='3';
    end loop;



    if O_remark is null then
      O_remark := '工号无该权限';
      flag :='-999';
      return;
    else
      O_remark := o_remark;

      return;
    end if;

  end GH_PRIVILEGE;
end P_CESHI;
/
