CREATE package body           PKG_UPDATE_COMMUNITY_ID is

  PROCEDURE PROC_MAIN as --返回具体的错误信息

    v_NUM                   number;
    v_count                 number;
    v_counter               number;
    v_area_code             varchar2(20);
    v_area_nbr             varchar2(20);
    num                     number;
    DPTABLE VARCHAR2(200) := 'drop table intf_prod_temp';
    CRTABLE VARCHAR2(200) := 'create table intf_prod_temp  as select * from intf_prod';
  begin

  v_area_code:= '591';
  --2.0上线后 就是全省了。
  if  sysdate > to_date('3-1-2013', 'dd-mm-yyyy') then
     v_area_code:= '590';
  end if;
   /*
 select count(*)

   into v_counter
   from CMS_INTER_STATUS@lk_fj_cms
  where int_name = 'INTF_PROD'
    and is_new = 1
    and area_code = v_area_code;*/
  v_counter := 1;
  -- 更改状态为 -2 CRM抽取增量数据中
  if v_counter = 1 then
    -- 更改状态为 -1 提取数据到临时表
    /* update CMS_INTER_STATUS@lk_fj_cms
     set is_new = '-1', modi_date = sysdate
   where int_name = 'INTF_PROD'
     and area_code = v_area_code
     and is_new = 1;
     commit;*/
    select count(1)
      into num
      from user_tables
     where table_name = upper('intf_prod_temp')
        or table_name = lower('intf_prod_temp');

    if num > 0 then
      EXECUTE IMMEDIATE DPTABLE;
    end if;

    EXECUTE IMMEDIATE CRTABLE;

    -- 更改状态为 -2 CRM抽取增量数据中
    /* update CMS_INTER_STATUS@lk_fj_cms
     set is_new = '-2', modi_date = sysdate
   where int_name = 'INTF_PROD'
     and area_code = v_area_code
     and is_new = '-1';
     commit;*/


    v_NUM := 0;
    for IP  in( select prod_id, place_s_node from  intf_prod_temp where 1=1 )LOOP --@lk_fj_cms

      select count(*) into v_count from   prod_inst where  prod_inst_id = IP.prod_id;
      if  v_count = 1 then

        begin

        --改产品实例
        UPDATE PROD_INST PI
           SET --PI.UPDATE_DATE  = SYSDATE, 2013-01-12 hehf 要求不用更新update_date
               PI.COMMUNITY_ID = IP.place_s_node
         WHERE PI.PROD_INST_ID = IP.prod_id;

        SELECT count(*) into v_count  FROM  PROD_INST PI, area_code a WHERE 1=1
          and PI.PROD_INST_ID = IP.prod_id and PI.Area_Id = a.region_id and rownum < 2;
        v_area_nbr :=  '591';
        if v_count = 1 then
           SELECT a.area_nbr  into v_area_nbr  FROM  PROD_INST PI, area_code a WHERE 1=1
           and PI.PROD_INST_ID = IP.prod_id and PI.Area_Id = a.region_id and rownum < 2;

        end if;

        insert into itsc_crmv2.INTF_INS_BILLING_UPDATE (INS_ID, TABLE_NAME, COLUMN_NAME, KEY_ID, TOPIC, TYPE, REASON, OPERATOR, STATE, STATE_DATE, CREATE_DATE, UPDATE_DATE, DEAL_NUM, NEXT_DEAL_TIME, ERR_MSG, REMARK, AREA_NBR)
        values (itsc_crmv2.seq_intf_ins_billing_update_id.nextval, 'PROD_INST', 'PROD_INST_ID', IP.prod_id, '修改社区标识', '1004', '', '51447', '70T', sysdate, sysdate, sysdate, 0, sysdate, '', '', v_area_nbr);

        v_NUM := v_NUM +1;
        if v_NUM > 100  then
          v_NUM := 0;
          commit;
        end if;

        EXCEPTION
          WHEN OTHERS THEN
            NULL;
          rollback;
          insert into circle_info (CIRCLE_INFO_ID, OBJ_INST_ID, CLASS_ID,  REMARK, CREATE_DATE)
          values (seq_circle_info_id.nextval, IP.prod_id,'1' ,'更新社区ID',sysdate );
          commit;
        end;
      end if;
    end LOOP;
    commit;
     --更新完成回写CMS_INTER_STATUS@lk_fj_cms，is_new更新为“0“，同时更新modi_date字段
     --update   CMS_INTER_STATUS@lk_fj_cms   set  is_new = '2', modi_date = sysdate  where  int_name = 'INTF_PROD'
     --and area_code = v_area_code;

    commit;

  end if;

  end PROC_MAIN;


END PKG_UPDATE_COMMUNITY_ID;
/
