CREATE PACKAGE           PKG_QUEUE IS

  /* VIP会员级别查询 */
  PROCEDURE PROC_QUERY_VIP_LEVEL(I_TYPE             IN NUMBER, --查询类型 1：VIP卡号 2：业务号码 3：身份证号
                                 I_AREA_CODE        IN VARCHAR2, --区号编码 如福州0591
                                 I_ACCOUNT          IN VARCHAR2, --号码  包括VIP卡号，业务号码，身份证号
                                 O_MEMBERSHIP_LEVEL OUT VARCHAR2, --会员级别
                                 O_ERR_CODE         OUT NUMBER, --处理结果（0--成功 1--失败）
                                 O_ERR_MSG          OUT VARCHAR2 --错误信息
                                 );
  /* 排队信息同步 */
  PROCEDURE PROC_QUEUE_INFO_SYNC(I_CALL_SERIAL_NBR  IN VARCHAR2, --呼叫流水号
                                 I_QUEUE_STAFF_CODE IN VARCHAR2, --排队员工号
                                 O_ERR_CODE         OUT NUMBER, --处理结果（0--成功 1--失败）
                                 O_ERR_MSG          OUT VARCHAR2, --错误信息
                                 O_RESULT           OUT VARCHAR2 --处理结果
                                 );

END PKG_QUEUE;
/
