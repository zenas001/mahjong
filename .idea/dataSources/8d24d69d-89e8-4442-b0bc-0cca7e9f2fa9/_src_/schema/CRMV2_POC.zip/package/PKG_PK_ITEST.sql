CREATE PACKAGE           pkg_pk_itest IS

  -- Author  :
  -- Created : 2013/12/30 14:11:14
  -- Purpose : 上海普坤-自动化测试系统-查询数据库中档案盒订单信息-专用

  ----2013-12-30--------------------------------------------------------------------------------
  --2）查询订单子项信息列表
  --       输入：订单流水号
  --       输出：子项ID、子项类型（客户类、销售品等）、实例id（客户、账户、销售品、产品实例id）、
  --              动作类型（订购、变更、成员纳入）、状态、操作时间
  --       测试订单号：FJ2013111442559865
  TYPE order_item_rec IS RECORD(
    order_item_id      NUMBER(12), --子项ID
    order_item_type    VARCHAR2(200), --子项类型
    order_item_obj_id  NUMBER(12), --实例id
    service_offer_name VARCHAR2(200), --动作类型
    status_name        VARCHAR2(200), --状态
    create_date        DATE --创建时间
    ); -- List 中的结构体定义
  TYPE order_item_list IS TABLE OF order_item_rec; -- 返回值是一个List
  PROCEDURE pro_order_item_list(i_cust_so_number  IN VARCHAR2, --输入订单协议号
                                o_order_item_list OUT order_item_list); --返回值是一个List
  ----------------------------------------------------------------------------------------------

  ----2014-01-06--------------------------------------------------------------------------------
  --USIM卡和号码空闲判断
  --存储过程名：getNumberStatus(numType char, numChar varhcar, numStatus out char)
  --例子 getNumberStatus( ‘1’, ‘18902108302’, numStatus)， 输出numStatus = ‘1’ （可用， ‘0’表示占用）
  --输入参数：numType char（‘1’天翼， ‘2’固定电话, ‘3’ USIM卡号），
  ----        numChar varchar（资源号码， 如 ‘18902108992’, ‘059122851925’, ‘8986031090591149575’）
  --输出参数：numStatus char（资源号码占用状态， ‘1’ 表示可用， ‘0’表示已经占用。
  PROCEDURE getnumberstatus(numtype   IN VARCHAR2, -- ‘1’天翼, ‘2’固定电话, ‘3’USIM卡号
                            numchar   IN VARCHAR2, -- 资源， 如 ‘18902108992’, ‘8986031090591149575’, ‘059122851925’
                            numstatus OUT VARCHAR2); --返回值是‘1’ 表示可用， ‘0’表示占用
----------------------------------------------------------------------------------------------

END pkg_pk_itest;
/
