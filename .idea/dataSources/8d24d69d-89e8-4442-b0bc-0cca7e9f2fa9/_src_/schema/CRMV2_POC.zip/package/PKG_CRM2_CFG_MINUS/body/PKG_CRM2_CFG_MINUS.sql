CREATE package body           PKG_CRM2_CFG_MINUS is

  PROCEDURE p_allCfgTableMinus(str_msg out VARCHAR2) is
    v_cnt                number;
    v_batchId            number;
    v_minustablename     varchar2(50);
    v_backminustablename varchar2(50);
    v_msg                varchar2(1000);
    v_sql                varchar2(2000);
    v_worngTable         varchar2(50);
  begin
    select com_sync_log_batch_seq.nextval into v_batchId from dual;

    FOR SyncTable in (SELECT DISTINCT TABLE_NAME, KEY_COLUMN
                        FROM COM_SYNC_CONF
                       WHERE OBJ_TXT LIKE 'Prod%'
                       ORDER BY TABLE_NAME) loop
      v_worngTable := SyncTable.Table_Name;
      --逐表比对
      p_minusTable(SyncTable.Table_Name,
                   SyncTable.Key_Column,
                   v_minustablename,
                   v_backminustablename,
                   v_msg);
      if v_minustablename is null then
        str_msg := 'p_allCfgTableMinus:' || v_worngTable || '没有比较出比对表,请检查';
        return;
      end if;
      v_sql := 'select count(*) from ' || v_minustablename;
      execute immediate v_sql
        into v_cnt;
      if v_cnt = 0 then
        --没比较出差异，可将差异备份表删除
        select count(*)
          into v_cnt
          from user_tab_comments
         where table_name = v_backminustablename;
        if v_cnt > 0 then
          v_sql := 'drop table ' || v_backminustablename;
          execute immediate v_sql;
        end if;
      else
        --逐表加入
        p_minusJoinTable(SyncTable.Table_Name,
                         SyncTable.Key_Column,
                         v_minustablename,
                         v_msg);
        --记录日志
        insert into COM_SYNC_LOG
          (ID,
           CONF_ID,
           SEQ,
           BATCH_ID,
           SYNC_SQL,
           CREATE_DATE,
           MODIFY_DATE,
           OP_STAFF,
           SRC,
           TAR,
           REMARK,
           STATE,
           OBJ_ID,
           AREA_ID,
           TYPE)
        values
          (Seq_Com_Sync_Log_Id.Nextval,
           0,
           0,
           v_batchId,
           v_msg,
           sysdate,
           null,
           'fztest',
           '9005数据库',
           '10061数据库',
           v_backminustablename,
           'EXEU',
           0,
           1,
           'SYNC');
      end if;
      commit;
    end loop;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_allCfgTableMinus:' || sqlerrm || ';错误表' || v_worngTable;
  end p_allCfgTableMinus;

  PROCEDURE p_minusTable(i_tablename         in VARCHAR2, --2.0的表名
                         i_tablekey          in VARCHAR2, --2.0的表对应主键
                         o_minustablename    out VARCHAR2, --2.0比对表
                         o_bakminustablename out VARCHAR2, --2.0比对表备份
                         o_msg               out VARCHAR2) is
    v_cnt                number;
    v_count              number;
    v_tablename          VARCHAR2(100); --要同步的配置本地表 例如 PROD_OFFER_REL
    v_temptablename      VARCHAR2(100); --链接库 对应的同名表
    v_linktablename      VARCHAR2(100); --链接库在本地建的表，方便比较
    v_minustablename     VARCHAR2(100); --差异表 例如 M_PROD_OFFER_REL
    v_backminustablename VARCHAR2(100); --备份本地数据的差异表 例如 M_PROD_OFFER_REL08311002
    v_tablekey           VARCHAR2(100);
    v_sql                VARCHAR2(2000);
    v_clobtable          boolean; --是否是有clob字段的表
  begin
    v_tablekey          := upper(i_tablekey);
    v_tablename         := upper(i_tablename);
    v_minustablename    := 'M_' || v_tablename;
    v_linktablename     := 'L_' || v_tablename;
    v_cnt               := LENGTH(v_tablename);
    o_minustablename    := '';
    o_bakminustablename := '';
    v_clobtable         := false;
    if v_cnt >= 30 then
      v_minustablename := substr(v_minustablename,
                                 0,
                                 LENGTH(v_minustablename) - 2);
      v_linktablename  := substr(v_linktablename,
                                 0,
                                 LENGTH(v_linktablename) - 2);
    end if;
    v_backminustablename := v_minustablename ||
                            to_char(sysdate, 'MMDDHHMI');
    v_cnt                := LENGTH(v_backminustablename);
    if v_cnt >= 30 then
      v_backminustablename := substr(v_backminustablename, 0, 21) ||
                              to_char(sysdate, 'MMDDHHMI');
    end if;
    --v_temptablename := v_tablename || '@LK_PPM_TO_CRM2PZ'; --目前先加用测链接，之后可以改成生产链接
    --v_temptablename := v_tablename || '@LK_CRMV2_PZ';
    v_temptablename :='CRM_PPM.'|| v_tablename ;

    --判断传入的键是否存在表，不存在直接报错
    v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
             v_tablename || ''' and column_name =''' || v_tablekey || '''';
    execute immediate v_sql
      into v_cnt;
    if v_cnt = 0 then
      o_msg := v_tablekey || '不是配置表' || i_tablename || '上的字段,请确认!';
      return;
    end if;

    --判断传入的表是否存在clob类型的字段，有的话后续minus不做判断
    v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
             v_tablename || ''' and DATA_TYPE=''CLOB''';
    execute immediate v_sql
      into v_cnt;
    if v_cnt > 0 then
      v_clobtable := true;
    end if;

    --判断是否存在差异表，如果没用就新建一个，有的话将数据清空掉
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_minustablename;
    if v_cnt = 0 then
      v_sql := 'create table ' || v_minustablename || ' as select * from ' ||
               v_tablename || ' where 1=2';
      execute immediate v_sql;
    else
      v_sql := 'delete from ' || v_minustablename;
      execute immediate v_sql;
      --删除字段MINUS_OP
      v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
               v_minustablename || ''' and column_name =''MINUS_OP''';
      execute immediate v_sql
        into v_cnt;
      if v_cnt = 1 then
        v_sql := 'ALTER TABLE ' || v_minustablename ||
                 ' drop column MINUS_OP';
        execute immediate v_sql;
      end if;
      --删除字段SYNC_OP
      v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
               v_minustablename || ''' and column_name =''SYNC_OP''';
      execute immediate v_sql
        into v_cnt;
      if v_cnt = 1 then
        v_sql := 'ALTER TABLE ' || v_minustablename ||
                 ' drop column SYNC_OP';
        execute immediate v_sql;
      end if;
    end if;
    --有clob的表先跳过，不处理
    if v_clobtable = true then
      o_minustablename    := v_minustablename;
      o_bakminustablename := v_backminustablename;
      return;
    end if;
    --同步链接库的表到本地，方便比较 获取的数据已经加上区域过滤了
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_linktablename;
    if v_cnt = 0 then
      v_sql := 'create table ' || v_linktablename || ' as select * from ' ||
               v_temptablename || ' WHERE 1=1' || addAreaId;
      execute immediate v_sql;
    else
      v_sql := 'delete from ' || v_linktablename;
      execute immediate v_sql;
      v_sql := 'insert into ' || v_linktablename || ' select * from ' ||
               v_temptablename || ' WHERE 1=1' || addAreaId;
      execute immediate v_sql;
    end if;

    --比对最新本地表与链接库表的差异数据
    --1.要新增的数据导入差异表 链接库的表多的
    v_sql := 'INSERT INTO ' || v_minustablename || ' select * from ' ||
             v_linktablename || ' n where not exists (select 1 from ' ||
             v_tablename || ' where ' || v_tablekey || '=n.' || v_tablekey ||
             addAreaId || ')';
    execute immediate v_sql;
    --2.要删除的数据导入差异表 本地的表多的
    v_sql := 'INSERT INTO ' || v_minustablename || ' select * from ' ||
             v_tablename || ' o where not exists (select 1 from ' ||
             v_linktablename || ' where ' || v_tablekey || '=o.' ||
             v_tablekey || ')' || addAreaId;
    execute immediate v_sql;
    --备份比对表 操作与比对表相反，UPDATE数据为本地的原先数据
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_backminustablename;
    if v_cnt > 0 then
      v_sql := 'drop table ' || v_backminustablename;
      execute immediate v_sql;
    end if;
    v_sql := 'create table ' || v_backminustablename ||
             ' as select * from ' || v_minustablename;
    execute immediate v_sql;
    --3.变更的数据导入差异表  以链接库的表为准
    if v_clobtable = false then
      v_sql := 'INSERT INTO ' || v_minustablename || ' select * from ' ||
               v_linktablename || ' n where exists (select 1 from ' ||
               v_tablename || ' where ' || v_tablekey || '=n.' ||
               v_tablekey || ') minus select * from ' || v_tablename ||
               ' minus select * from ' || v_minustablename;
      execute immediate v_sql;
      --备份数据表相反，以本地表为准
      v_sql := 'INSERT INTO ' || v_backminustablename || ' select * from ' ||
               v_tablename || ' n where exists (select 1 from ' ||
               v_linktablename || ' where ' || v_tablekey || '=n.' ||
               v_tablekey || ') minus select * from ' || v_linktablename;
      execute immediate v_sql;
    end if;

    --对差异表增加一个字段来判断操作类型
    v_sql := 'ALTER TABLE ' || v_minustablename ||
             ' ADD MINUS_OP VARCHAR2(6)';
    execute immediate v_sql;
    v_sql := 'ALTER TABLE ' || v_backminustablename ||
             ' ADD MINUS_OP VARCHAR2(6)';
    execute immediate v_sql;

    --对之前导入的数据置操作类型
    --1.新增ADD  链接库的表多的新增
    v_sql := 'update ' || v_minustablename ||
             ' set MINUS_OP=''ADD'' where ' || v_tablekey || ' in( select ' ||
             v_tablekey || ' from ' || v_linktablename ||
             ' n where not exists (select 1 from ' || v_tablename ||
             ' where ' || v_tablekey || '=n.' || v_tablekey || '))';
    execute immediate v_sql;
    --2.删除DEL 本地的表多的删除
    v_sql := 'update ' || v_minustablename ||
             ' set MINUS_OP=''DEL'' where ' || v_tablekey || ' in( select ' ||
             v_tablekey || ' from ' || v_tablename ||
             ' o where not exists (select 1 from ' || v_linktablename ||
             ' where ' || v_tablekey || '=o.' || v_tablekey || '))';
    execute immediate v_sql;
    --3.变更UPDATE 以链接表为准
    if v_clobtable = false then
      v_sql := 'update ' || v_minustablename ||
               ' set MINUS_OP=''UPDATE'' where ' || v_tablekey ||
               ' in( select ' || v_tablekey || '  from (select * from ' ||
               v_linktablename || ' n where exists (select 1 from ' ||
               v_tablename || ' where ' || v_tablekey || '=n.' ||
               v_tablekey || ') minus select * from ' || v_tablename ||
               ') a)';
      execute immediate v_sql;
    end if;
    --备份表处理
    --1.新增数据状态，备份表为DEL
    v_sql := 'update ' || v_backminustablename ||
             ' set MINUS_OP=''DEL'' where ' || v_tablekey || ' in (select ' ||
             v_tablekey || ' from ' || v_minustablename ||
             '  where MINUS_OP=''ADD'' )';
    execute immediate v_sql;
    --2.删除数据状态，备份表为ADD
    v_sql := 'update ' || v_backminustablename ||
             ' set MINUS_OP=''ADD'' where ' || v_tablekey || ' in (select ' ||
             v_tablekey || ' from ' || v_minustablename ||
             '  where MINUS_OP=''DEL'' )';
    execute immediate v_sql;
    --3.修改数据，备份表内存本地原数据
    v_sql := 'update ' || v_backminustablename ||
             ' set MINUS_OP=''UPDATE'' where ' || v_tablekey ||
             ' in (select ' || v_tablekey || ' from ' || v_minustablename ||
             '  where MINUS_OP=''UPDATE'' )';
    execute immediate v_sql;

    --对差异表再增加一个是否同步的字段来判断是否已经将新数据同步给旧数据了
    v_sql := 'ALTER TABLE ' || v_minustablename ||
             ' ADD SYNC_OP VARCHAR2(1)';
    execute immediate v_sql;
    v_sql := 'update ' || v_minustablename || ' set SYNC_OP=''N''';
    execute immediate v_sql;

    v_sql := 'select count(*) from ' || v_minustablename;
    execute immediate v_sql
      into v_count;
    o_minustablename    := v_minustablename;
    o_bakminustablename := v_backminustablename;
    o_msg               := i_tablename || '与本地表相比,有差异' || to_char(v_count) ||
                           '条数据';
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := 'p_minusTable:' || sqlerrm;
  end p_minusTable;

  PROCEDURE p_minusJoinTable(i_tablename      in VARCHAR2, --2.0的表名
                             i_tablekey       in VARCHAR2, --2.0的表对应主键
                             i_minustablename in VARCHAR2, --2.0的比对表
                             o_msg            out VARCHAR2) is
    v_cnt            number;
    v_count          number;
    v_tablename      VARCHAR2(100); --要同步的配置表 例如 PROD_OFFER_REL
    v_minustablename VARCHAR2(100); --比对表
    v_temptablename  VARCHAR2(100); --临时表 例如 T_MDSE_SPEC_RELA
    v_tablekey       VARCHAR2(100);
    v_sql            VARCHAR2(4000);
    v_colums         VARCHAR2(2000);
  begin
    v_tablekey       := upper(i_tablekey);
    v_tablename      := upper(i_tablename);
    v_minustablename := i_minustablename;
    v_temptablename  := 'T_' || substr(v_minustablename,
                                       3,
                                       LENGTH(v_minustablename));
    --判断差异数据表是否存在
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_minustablename;
    if v_cnt = 0 then
      o_msg := '不存在差异表' || v_minustablename || ',请确认!';
      return;
    end if;

    --临时表处理
    select count(*)
      into v_cnt
      from user_tab_comments
     where table_name = v_temptablename;
    if v_cnt > 0 then
      v_sql := 'drop table ' || v_temptablename;
      execute immediate v_sql;
    end if;
    v_sql := 'create table ' || v_temptablename || ' as select * from ' ||
             v_minustablename;
    execute immediate v_sql;

    --删除字段MINUS_OP
    v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
             v_temptablename || ''' and column_name =''MINUS_OP''';
    execute immediate v_sql
      into v_cnt;
    if v_cnt = 1 then
      v_sql := 'ALTER TABLE ' || v_temptablename || ' drop column MINUS_OP';
      execute immediate v_sql;
    end if;
    --删除字段SYNC_OP
    v_sql := 'select count(*) from user_tab_columns where table_name=''' ||
             v_temptablename || ''' and column_name =''SYNC_OP''';
    execute immediate v_sql
      into v_cnt;
    if v_cnt = 1 then
      v_sql := 'ALTER TABLE ' || v_temptablename || ' drop column SYNC_OP';
      execute immediate v_sql;
    end if;

    --根据差异表操作类型处理本地数据
    --1.要新增的数据导入本地数据表
    v_sql := 'INSERT INTO ' || v_tablename || ' select * from ' ||
             v_temptablename || ' t where exists (select 1 from ' ||
             v_minustablename || ' where  minus_op=''ADD'' and ' ||
             v_tablekey || '=t.' || v_tablekey || ')';
    execute immediate v_sql;
    --2.要删除的数据从本地数据表去掉
    v_sql := 'DELETE FROM ' || v_tablename ||
             ' o where exists (select 1 from ' || v_minustablename ||
             ' where  minus_op=''DEL'' and ' || v_tablekey || '=o.' ||
             v_tablekey || ')';
    execute immediate v_sql;
    --3.变更的数据,获取所有字段更新
    v_sql := 'select max(sys_connect_by_path(column_name, '','')) from (select column_name, column_id rn from user_tab_columns
             where table_name = ''' || v_tablename ||
             ''') start with rn = 1 connect by prior rn = rn - 1';
    execute immediate v_sql
      into v_colums;
    v_colums := substr(v_colums, 2, LENGTH(v_colums));
    v_sql    := 'UPDATE ' || v_tablename || ' SET (' || v_colums ||
                ')=(SELECT ' || v_colums || ' FROM ' || v_temptablename ||
                ' WHERE ' || v_tablekey || '=' || v_tablename || '.' ||
                v_tablekey || ' AND ' || v_tablekey || ' IN (SELECT ' ||
                v_tablekey || ' FROM ' || v_minustablename ||
                ' WHERE minus_op=''UPDATE'' )) WHERE EXISTS(SELECT 1 FROM ' ||
                v_minustablename || ' WHERE ' || v_tablekey || '=' ||
                v_tablename || '.' || v_tablekey ||
                ' AND minus_op=''UPDATE'' )';

    execute immediate v_sql;
    --处理完差异数据后，将处理的数据SYNC_OP置为Y
    v_sql := 'update ' || v_minustablename ||
             ' set SYNC_OP=''Y'' where SYNC_OP=''N'' ';
    execute immediate v_sql;
    --删除临时表
    v_sql := 'drop table ' || v_temptablename;
    execute immediate v_sql;

    v_sql := 'select count(*) from ' || v_minustablename;
    execute immediate v_sql
      into v_count;
    o_msg := v_tablename || '已经合并处理了最新的' || to_char(v_count) || '条数据.';
    v_sql := 'select count(*) from ' || v_minustablename ||
             ' where  minus_op=''ADD''';
    execute immediate v_sql
      into v_count;
    o_msg := o_msg || '新增:' || to_char(v_count) || '条数据;';
    v_sql := 'select count(*) from ' || v_minustablename ||
             ' where  minus_op=''DEL''';
    execute immediate v_sql
      into v_count;
    o_msg := o_msg || '删除:' || to_char(v_count) || '条数据;';
    v_sql := 'select count(*) from ' || v_minustablename ||
             ' where minus_op=''UPDATE''';
    execute immediate v_sql
      into v_count;
    o_msg := o_msg || '修改:' || to_char(v_count) || '条数据.';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := 'p_minusJoinTable:' || sqlerrm;
  end p_minusJoinTable;

  --加区域查询
  function addAreaId return VARCHAR2 is
    v_areaSql VARCHAR2(100);
  begin
    --v_areaSql := ' AND AREA_ID>2 AND AREA_ID<11';
    v_areaSql := '';
    return v_areaSql;
  end;
end PKG_CRM2_CFG_MINUS;
/
