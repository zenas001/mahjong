CREATE package body           PKG_CRM2_PROD_SYNC_BAK is

  PROCEDURE p_createSyncTempTable(i_syncid       in number, --同步表ID
                                  i_id           in number, --销售品规格ID，产品规格ID
                                  i_areaid       in number, --配置区域
                                  i_link         in VARCHAR2, --目标库的链接
                                  o_result       out VARCHAR2, --返回标识
                                  o_tmpTableName out VARCHAR2, --临时表名
                    /*
归属模块：产品
关联CQ单：TTP11334 FZBUG_配置系统_1.0支持配置数据同步到其他环境目前2.0不支持
脚本用途：数据同步环境设置
提交人: 郑村铃
提交时间：20120802
发布环境：CRM用测环境
注意事项：
*/
BEGIN
  pkg_isd.p_attr_spec('localDbaUrl', '本地环境数据库', null, 'C', '134.130.3.4:10061', null, null, '0', '0', '1000', sysdate, sysdate, -1, 'T3', 'localDbaUrl', null, null, null, null, 1, 0, 1, null, null, null, '0', null, null, null, 'N', 'N', null, null, null, null, null, 'NCP;', 0, '0', null, '0', null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('CRM生产数据库', '-1','localDbaUrl','1', null, '1', null, null, '134.130.65.5:10066', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);

  pkg_isd.p_attr_spec('comSyncDbaUrl', '数据同步数据库', null, 'C', '134.130.65.5:10066', null, null, '0', '0', '1000', sysdate, sysdate, -1, 'T3', 'comSyncDbaUrl', null, null, null, null, 1, 0, 1, null, null, null, '1', null, null, null, 'Y', 'Y', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('PPM生产数据库', '-1','comSyncDbaUrl','1', null, '1', null, null, '134.130.3.4:10061', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('CRM生产数据库', '-1','comSyncDbaUrl','1', null, '1', null, null, '134.130.65.5:10066', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('9091用测数据库', '-1','comSyncDbaUrl','1', null, '1', null, null, '134.129.126.100:9091', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);

  pkg_isd.p_attr_spec('134.130.3.4:10061', 'PPM生产数据库', null, 'C', null, null, null, '0', '0', '1000', sysdate, sysdate, -1, 'T1', '134.130.3.4:10061', null, null, null, null, 1, 0, 1, null, null, null, '1', null, null, null, 'Y', 'Y', null, null, null, null, null, 'NCP;', 0, '0', null, '0', null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('link', '-1','134.130.3.4:10061','1', null, '1', null, null, 'CRM_PPM.', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('drivername', '-1','134.130.3.4:10061','1', null, '1', null, null, 'oracle.jdbc.driver.OracleDriver', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('url', '-1','134.130.3.4:10061','1', null, '1', null, null, 'jdbc:oracle:thin:@134.128.152.4:2006:crmdb', null, null, sysdate,sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('user', '-1','134.130.3.4:10061','1', null, '1', null, null, '77227d1310227c', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('pwd', '-1','134.130.3.4:10061','1', null, '1', null, null, '57025d1330025c0e0542007a', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);

  pkg_isd.p_attr_spec('134.130.65.5:10066', 'CRM生产数据库', null, 'C', null, null, null, '0', '0', '1000',sysdate, sysdate, -1, 'T1', '134.130.65.5:10066', null, null, null, null, 1, 0, 1, null, null, null, '1', null, null, null, 'Y', 'Y', null, null, null, null, null, 'NCP;', 0, '0', null, '0', null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('link', '-1','134.130.65.5:10066','1', null, '1', null, null, 'CRMV2.', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('drivername', '-1','134.130.65.5:10066','1', null, '1', null, null, 'oracle.jdbc.driver.OracleDriver', null, null, sysdate,sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('url', '-1','134.130.65.5:10066','1', null, '1', null, null, 'jdbc:oracle:thin:@134.128.152.4:2006:crmdb', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('user', '-1','134.130.65.5:10066','1', null, '1', null, null, '77227d1a72', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('pwd', '-1','134.130.65.5:10066','1', null, '1', null, null, '57025d3a725c1f160441027c77', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);

  pkg_isd.p_attr_spec('134.129.126.100:9091', '9091用测数据库', null, 'C', null, null, null, '0', '0', '1000',sysdate, sysdate, -1, 'T1', '134.129.126.100:9091', null, null, null, null, 1, 0, 1, null, null, null, '1', null, null, null, 'Y', 'Y', null, null, null, null, null, 'NCP;', 0, '0', null, '0', null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('link', '-1','134.129.126.100:9091','1', null, '1', null, null, '@LK_PPM_TO_CRM2UT', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('drivername', '-1','134.129.126.100:9091','1', null, '1', null, null, 'oracle.jdbc.driver.OracleDriver', null, null, sysdate,sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('url', '-1','134.129.126.100:9091','1', null, '1', null, null, 'jdbc:oracle:thin:@134.129.126.133:1522:crmtest', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('user', '-1','134.129.126.100:9091','1', null, '1', null, null, '57025d3a72', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);
  pkg_isd.p_attr_value('pwd', '-1','134.129.126.100:9091','1', null, '1', null, null, '57025d3a72430317', null, null, sysdate, sysdate, '1000', null, null, null, null, null, null, null, null, null, null, null);

END;              o_msg          out VARCHAR2) is
    v_cnt           number; --结果变量
    v_syncSql       VARCHAR2(2000); --同步脚本语句
    v_table         VARCHAR2(100); --同步表
    v_seq           number; --同步表顺序
    v_keyColumn     VARCHAR2(100); --同步表的主键字段
    v_mapColumn     VARCHAR2(100); --同步表的主键字段
    v_linkInstTable VARCHAR2(100); --外数据库链接的实例表
    v_syncFromTable VARCHAR2(100); --本地同步数据生成的表名
    v_syncToTable   VARCHAR2(100); --目的同步数据生成的表名
    v_minusTable    VARCHAR2(100); --差异表表名
    v_dateTime      VARCHAR2(20); --当前时间
    v_executeSql    VARCHAR2(2000); --实时执行语句
  begin
    v_dateTime := to_char(sysdate, 'yyyymmddhh24miss');
    o_result   := 'FALSE';
    /*------------------------------------------------------------------------------------------
      步骤一：根据传入的同步表ID，以及主键和区域ID，拼装出要同步的表数据
    ------------------------------------------------------------------------------------------*/
    FOR ComSyncConf in (select * from com_sync_conf where id = i_syncid) LOOP
      v_syncSql       := ComSyncConf.Sync_Sql;
      v_table         := ComSyncConf.Table_Name;
      v_seq           := ComSyncConf.Seq;
      v_keyColumn     := ComSyncConf.Key_Column;
      v_linkInstTable := ComSyncConf.Inst_Table;
    END LOOP;
    if v_syncSql is null or v_table is null or v_keyColumn is null then
      o_msg := '根据ID' || to_char(i_syncid) ||
               '查询com_sync_conf表数据异常,请检查是否Sync_Sql,Table_Name,Key_Column为空';
      return;
    end if;
    --可能对应实例表的字段与配置字段不同
    v_mapColumn := v_keyColumn;
    if v_linkInstTable is not null then
      v_cnt := instr(v_linkInstTable, '-', 1, 1);
      if v_cnt > 0 then
        v_mapColumn     := substr(v_linkInstTable, v_cnt + 1);
        v_linkInstTable := substr(v_linkInstTable, 0, v_cnt - 1);
      end if;
    end if;
    v_syncFromTable := 'SYNC_FROM_' || v_dateTime || '_' || to_char(v_seq);
    v_syncToTable   := 'SYNC_TO_' || v_dateTime || '_' || to_char(v_seq);
    v_minusTable    := 'SYNC_MINU_' || v_dateTime || '_' || to_char(v_seq);
    --替换主键
    v_cnt := instr(v_syncSql, ':id', 1, 1);
    if v_cnt > 0 then
      v_syncSql := REPLACE(v_syncSql, ':id', to_char(i_id));
    end if;
    --替换区域
    v_cnt := instr(v_syncSql, ':cfgAreaId', 1, 1);
    if v_cnt > 0 then
      v_syncSql := REPLACE(v_syncSql, ':cfgAreaId', to_char(i_areaId));
    end if;

    /*------------------------------------------------------------------------------------------
      步骤二： 取出本数据库中要同步表的数据，放入名为 SYNC_FROM_201207100945_1
      (该表名自动生成，字段与原表相同，SYNC_FROM+sysdate+表执行顺序)的表内，
    ------------------------------------------------------------------------------------------*/
    v_executeSql := 'CREATE TABLE ' || v_syncFromTable || ' AS ' ||
                    REPLACE(v_syncSql, '@');
    v_executeSql:=REPLACE(v_executeSql, '#');
    execute immediate v_executeSql;
    /*------------------------------------------------------------------------------------------
     步骤三： 将目标库要被覆盖的数据，放入名为 SYNC_TO_201207100945_1
     (该表名自动生成，字段与原表相同，SYNC_TO+sysdate+表执行顺序) 的表内
     字段排列顺序不同也会造成minu错误，所以先根据同步表建备份表，再导入数据
    ------------------------------------------------------------------------------------------*/
    v_executeSql := 'CREATE TABLE ' || v_syncToTable ||
                    ' AS SELECT * FROM ' || v_syncFromTable || ' WHERE 1=2';
    /*v_executeSql := 'CREATE TABLE ' || v_syncToTable || ' AS ' ||
    REPLACE(v_syncSql, '@', i_link);*/
    execute immediate v_executeSql;
    --同个数据库，不同用户名的情况，传入的链接为crmv2.格式。
    --不同数据库，采用数据库链路，传入的链接为@LK_CRM2DEV3格式。
    v_cnt := instr(i_link, '.', 1, 1);
    if v_cnt > 0 then
      v_syncSql    := REPLACE(v_syncSql, '@');
      v_executeSql := 'INSERT INTO ' || v_syncToTable || '  ' ||
                      REPLACE(v_syncSql, '#', i_link);
    else
      v_syncSql    := REPLACE(v_syncSql, '#');
      v_executeSql := 'INSERT INTO ' || v_syncToTable || '  ' ||
                      REPLACE(v_syncSql, '@', i_link);
    end if;
    execute immediate v_executeSql;
    /*------------------------------------------------------------------------------------------
      步骤四：创建差异表,比对以上两个表，
      取出要变更的数据放入差异表中，该表字段为“KEY_ID”放置主键，“MINUS_OP”放置操作类型ADD,DEL,UPDATE。
    ------------------------------------------------------------------------------------------*/
    v_executeSql := 'create table ' || v_minusTable ||
                    ' (KEY_ID number,MINUS_OP varchar2(6))';
    execute immediate v_executeSql;
    --1.要新增的数据导入差异表
    v_executeSql := 'INSERT INTO ' || v_minusTable || ' select n.' ||
                    v_keyColumn || ',''ADD'' from ' || v_syncFromTable ||
                    ' n where not exists (select 1 from ' || v_syncToTable ||
                    ' where ' || v_keyColumn || '=n.' || v_keyColumn || ')';
    execute immediate v_executeSql;
    --2.要删除的数据导入差异表
    v_executeSql := 'INSERT INTO ' || v_minusTable || ' select o.' ||
                    v_keyColumn || ',''DEL'' from ' || v_syncToTable ||
                    ' o where not exists (select 1 from ' ||
                    v_syncFromTable || ' where ' || v_keyColumn || '=o.' ||
                    v_keyColumn || ')  and o.STATUS_CD != ''1100''';
    execute immediate v_executeSql;
    --3.变更的数据导入差异表
    v_executeSql := 'INSERT INTO ' || v_minusTable || ' select ' ||
                    v_keyColumn || ',''UPDATE'' from (select * from ' ||
                    v_syncFromTable || ' n where exists (select 1 from ' ||
                    v_syncToTable || ' where ' || v_keyColumn || '=n.' ||
                    v_keyColumn || ') minus select * from ' ||
                    v_syncToTable || ')';
    execute immediate v_executeSql;

    /*------------------------------------------------------------------------------------------
     步骤五：针对DEL类型数据增加与目标库的实例数据判断，如果已经存在实例，则操作类型更改成DELUP
    ------------------------------------------------------------------------------------------*/
    if v_linkInstTable is not null then
      v_executeSql := 'select count(*) from ' || v_minusTable ||
                      ' WHERE MINUS_OP = ''DEL''';
      execute immediate v_executeSql
        into v_cnt;
      if v_cnt > 0 then
        v_cnt := instr(i_link, '.', 1, 1);
        if v_cnt > 0 then
          v_linkInstTable := i_link || v_linkInstTable;
        else
          v_linkInstTable := v_linkInstTable || i_link;
        end if;
        v_executeSql := 'UPDATE ' || v_minusTable ||
                        ' SET MINUS_OP=''DELUP'' WHERE MINUS_OP=''DEL'' AND exists (select 1 from ' ||
                        v_linkInstTable || ' where ' || v_mapColumn || '=' ||
                        v_minusTable || '.KEY_ID)';
        execute immediate v_executeSql;
      end if;
    end if;
    commit;
    o_tmpTableName := v_minusTable;
    o_msg          := '获取增量临时表' || v_minusTable || '成功';
    o_result       := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := 'p_createSyncTempTable:' || sqlerrm;
  end;

  PROCEDURE p_dropSyncTempTable(i_minuTable in VARCHAR2, --临时差异表
                                o_result    out VARCHAR2, --返回标识
                                o_msg       out VARCHAR2) is
    v_cnt           number; --结果变量
    v_table         VARCHAR2(100); --表名
    v_syncFromTable VARCHAR2(100); --本地同步数据生成的表名
    v_syncToTable   VARCHAR2(100); --目的同步数据生成的表名
    v_minusTable    VARCHAR2(100); --差异表表名
    v_executeSql    VARCHAR2(2000); --实时执行语句
  begin
    o_result := 'FALSE';
    if i_minuTable is null then
      o_msg := '传入的增量临时表为空,请确认';
      return;
    end if;
    v_cnt := instr(i_minuTable, 'SYNC_', 1, 1);
    if v_cnt > 0 then
      v_table := LTRIM(i_minuTable, 'SYNC_MINU_');
    else
      v_table := i_minuTable;
    end if;
    v_syncFromTable := 'SYNC_FROM_' || v_table;
    v_syncToTable   := 'SYNC_TO_' || v_table;
    v_minusTable    := 'SYNC_MINU_' || v_table;

    --删除临时同步表
    SELECT COUNT(*)
      INTO v_cnt
      FROM USER_TAB_COMMENTS
     WHERE TABLE_NAME = v_syncFromTable;
    if v_cnt > 0 then
      v_executeSql := 'DROP TABLE ' || v_syncFromTable;
      execute immediate v_executeSql;
      o_msg := '删除' || v_syncFromTable || '表成功;';
    end if;

    --删除临时备份表
    SELECT COUNT(*)
      INTO v_cnt
      FROM USER_TAB_COMMENTS
     WHERE TABLE_NAME = v_syncToTable;
    if v_cnt > 0 then
      v_executeSql := 'DROP TABLE ' || v_syncToTable;
      execute immediate v_executeSql;
      o_msg := '删除' || v_syncToTable || '表成功;' || o_msg;
    end if;

    --删除临时增量表
    SELECT COUNT(*)
      INTO v_cnt
      FROM USER_TAB_COMMENTS
     WHERE TABLE_NAME = v_minusTable;
    if v_cnt > 0 then
      v_executeSql := 'DROP TABLE ' || v_minusTable;
      execute immediate v_executeSql;
      o_msg := '删除' || v_minusTable || '表成功;' || o_msg;
    end if;

    o_msg    := '执行过程成功：' || o_msg;
    o_result := 'TRUE';
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := 'p_dropSyncTempTable:' || sqlerrm;
  end;
end PKG_CRM2_PROD_SYNC;
/
