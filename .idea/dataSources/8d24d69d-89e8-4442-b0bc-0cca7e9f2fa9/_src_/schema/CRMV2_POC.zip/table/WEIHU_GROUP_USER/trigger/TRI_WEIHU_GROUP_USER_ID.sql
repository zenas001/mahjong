CREATE TRIGGER TRI_WEIHU_GROUP_USER_ID
BEFORE INSERT
  ON WEIHU_GROUP_USER
FOR EACH ROW
  begin
                 select seq_weihu_group_user_id.nextval into :new.group_user_id from dual;
          end;
/
