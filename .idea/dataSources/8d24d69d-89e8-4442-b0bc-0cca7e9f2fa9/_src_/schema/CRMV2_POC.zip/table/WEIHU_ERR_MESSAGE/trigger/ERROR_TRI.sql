CREATE TRIGGER ERROR_TRI
BEFORE INSERT
  ON WEIHU_ERR_MESSAGE
FOR EACH ROW
  begin
 select sequence_error.nextval into:new.e_id from dual;
end;
/
