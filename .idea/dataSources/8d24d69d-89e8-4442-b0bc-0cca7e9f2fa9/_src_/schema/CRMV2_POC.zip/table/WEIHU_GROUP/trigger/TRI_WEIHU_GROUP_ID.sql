CREATE TRIGGER TRI_WEIHU_GROUP_ID
BEFORE INSERT
  ON WEIHU_GROUP
FOR EACH ROW
  begin
                 select SEQ_WEIHU_GROUP_ID.nextval into :new.g_id from dual;
          end;
/
