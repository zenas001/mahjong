CREATE TRIGGER TG_RLM_RULE
AFTER INSERT OR UPDATE OR DELETE
  ON RLM_RULE
FOR EACH ROW
  DECLARE
  -- local variables here
  v_osuser    VARCHAR2(300);
  v_machine   VARCHAR2(200);
  v_ip_addr   VARCHAR2(200);
  v_program   VARCHAR2(300);
  v_oper_desc VARCHAR2(1000);
  event       VARCHAR2(300);
  obj_name    VARCHAR2(300);
  obj_type    VARCHAR2(300);
  obj_owner   VARCHAR2(300);
  v_object_id VARCHAR2(300);
  v_sql_text  VARCHAR2(3000);
  sql_text    ora_name_list_t;
  stmt        VARCHAR2(4000);
  n           NUMBER;
BEGIN

  SELECT b.osuser,
         b.machine,
         nvl(b.program, 'sqlplus'),
         sys_context('userenv',
                     'ip_address')
    INTO v_osuser,
         v_machine,
         v_program,
         v_ip_addr
    FROM v$sqlarea a, v$session b
   WHERE a.hash_value =
         b.sql_hash_value
     AND b.audsid =
         userenv('sessionid');

  event     := ora_sysevent;
  obj_name  := ora_dict_obj_name;
  obj_type  := ora_dict_obj_type;
  obj_owner := ora_dict_obj_owner;

  IF inserting THEN
    event       := 'INSERT';
    v_object_id := :new.rule_id;
    IF :new.status_cd = '1000' THEN
        --插入到日志表
        v_object_id := :new.rule_id;
    END IF;
  END IF;


    IF updating THEN
      event       := 'UPDATE';
      v_object_id := :new.rule_id;
      v_oper_desc :=  '旧状态:' || :OLD.STATUS_CD || '新状态:' || :NEW.STATUS_CD;
    END IF;

    IF deleting THEN
      event       := 'DELETE';
      v_object_id := :old.rule_id;
    END IF;


  INSERT INTO ddl_event_log
    (TIMESTAMP,
     user_name,
     os_user,
     machine,
     ip_addr,
     program,
     event,
     object_name,
     object_type,
     object_owner,
     STATEMENT,
     object_id,
     remark)
  VALUES
    (SYSDATE,
     USER,
     v_osuser,
     v_machine,
     v_ip_addr,
     v_program,
     event,
     'RLM_RULE',
     obj_type,
     obj_owner,
     NULL,
     v_object_id,
     v_oper_desc);

  ----

END tg_rlm_rule;
/
