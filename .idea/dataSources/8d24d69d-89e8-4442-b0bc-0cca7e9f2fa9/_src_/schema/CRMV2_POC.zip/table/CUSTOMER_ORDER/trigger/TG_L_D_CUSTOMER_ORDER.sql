CREATE TRIGGER TG_L_D_CUSTOMER_ORDER
AFTER INSERT OR UPDATE OR DELETE
  ON CUSTOMER_ORDER
FOR EACH ROW
  declare
  v_action_type           varchar2(50);
  v_src_id                number(15);
  v_area_id               number(15);
  v_before_after          varchar2(50);
begin
  if inserting then
    v_src_id                :=:new.cust_order_id;
    v_action_type           := 'INSERT';
    v_before_after          :='AFTER';
    v_area_id               :=:new.area_id;
  elsif updating then
    v_src_id                :=:new.cust_order_id;
    v_action_type           := 'SQL COMPUPDATE';
    v_before_after          :='AFTER';
    v_area_id               :=:new.area_id;
  elsif deleting then
    v_src_id                :=:old.cust_order_id;
    v_action_type           := 'DELETE';
    v_before_after          :='BEFORE';
    v_area_id               :=:old.area_id;
  end if;

  INSERT INTO l_d_customer_order
    (lid, src_id, action_type, before_after, batch_nbr, state, state_date,
     area_id,comm_time,status_cd,before_status_cd)
  VALUES
    (seq_l_d_lid.nextval, v_src_id, v_action_type, v_before_after, '', '70A', sysdate,
     v_area_id,sysdate,:new.status_cd, :old.status_cd);

end tg_L_D_CUSTOMER_ORDER;
/
