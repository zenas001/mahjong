CREATE TRIGGER LISTEN_TRI
BEFORE INSERT
  ON WEIHU_LISTEN_TYPE
FOR EACH ROW
  begin
 select listen_sequence.nextval into:New.lt_id from dual;
end;
/
