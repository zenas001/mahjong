CREATE TRIGGER TRI_WEIHU_GROUP_THRESHOLDS_ID
BEFORE INSERT
  ON WEIHU_GROUP_THRESHOLDS
FOR EACH ROW
  begin
                 select seq_weihu_group_thresholds_id.nextval into :new.group_id from dual;
          end;
/
