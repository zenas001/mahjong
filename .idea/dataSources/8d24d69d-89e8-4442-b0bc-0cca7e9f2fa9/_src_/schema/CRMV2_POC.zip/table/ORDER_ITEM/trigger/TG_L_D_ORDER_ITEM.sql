CREATE TRIGGER TG_L_D_ORDER_ITEM
AFTER INSERT OR UPDATE OR DELETE
  ON ORDER_ITEM
FOR EACH ROW
  declare
  v_action_type           varchar2(50);
  v_src_id                number(15);
  v_area_id               number(15);
  v_before_after          varchar2(50);
begin
  if inserting then
    v_src_id                :=:new.order_item_id;
    v_action_type           := 'INSERT';
    v_before_after          :='AFTER';
    v_area_id               :=:new.area_id;
  elsif updating then
    v_src_id                :=:new.order_item_id;
    v_action_type           := 'SQL COMPUPDATE';
    v_before_after          :='AFTER';
    v_area_id               :=:new.area_id;
  elsif deleting then
    v_src_id                :=:old.order_item_id;
    v_action_type           := 'DELETE';
    v_before_after          :='BEFORE';
    v_area_id               :=:old.area_id;
  end if;

  INSERT INTO l_d_order_item
    (lid, src_id, action_type, before_after, batch_nbr, state, state_date,
     remark, status_cd, before_status_cd, area_id, comm_time)
  VALUES
    (seq_l_d_lid.nextval, v_src_id, v_action_type, v_before_after, '', '70A', sysdate,
     '', :new.status_cd, :old.status_cd, v_area_id, sysdate);

end tg_l_d_order_item;
/
