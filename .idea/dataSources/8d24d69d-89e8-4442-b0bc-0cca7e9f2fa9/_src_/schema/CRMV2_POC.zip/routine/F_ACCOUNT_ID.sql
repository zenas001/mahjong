CREATE FUNCTION           f_account_id(in_account_id IN NUMBER, in_status_date IN DATE)
    RETURN NUMBER IS
    out_cust_id NUMBER;
  BEGIN
    BEGIN
      SELECT cust_id
        INTO out_cust_id
        FROM account
       WHERE account_id = in_account_id;
    EXCEPTION
      WHEN no_data_found THEN
        BEGIN
          SELECT cust_id
            INTO out_cust_id
            FROM account_his
           WHERE account_id = in_account_id
             AND in_status_date >= status_date
             AND in_status_date < rec_update_date
             AND rownum = 1;
        EXCEPTION
          WHEN no_data_found THEN
            SELECT cust_id
              INTO out_cust_id
              FROM account_his
             WHERE account_id = in_account_id
               AND in_status_date < rec_update_date
               AND rownum = 1;
        END;
    END;
    RETURN out_cust_id;
  END;
/
