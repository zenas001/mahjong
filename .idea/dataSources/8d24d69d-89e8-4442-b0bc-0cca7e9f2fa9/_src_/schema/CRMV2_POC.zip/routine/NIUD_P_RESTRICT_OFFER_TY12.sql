CREATE procedure           niud_p_restrict_offer_ty12(o_msg out varchar2) is
  v_cnt_1        number(3);
  v_cnt_2        number(3);
  v_proc_cnt_1   number(6) := 0;
  v_proc_cnt_2   number(6) := 0;
  v_product_a_id product.product_id%type;
  v_restrict_id  prod_rel_restrict_offer.restrict_id%type;
  v_remark       varchar2(200) := 'configurated via niud_p_restrict_offer_ty12';
  cursor cur_pr is
    select *
      from product_relation pr
     where pr.product_z_id = 800000002 --Z端为移动语音
       and pr.product_a_id in --A端为与移动语音有关系的产品
           (select product_id
              from offer_prod_rel
             where prod_offer_id in --从1.0取出来的与“天翼”销售品有关系的销售品, by lisy
                   (800001144,
                    800001512,
                    800001022,
                    800001773,
                    800001643,
                    800001777,
                    800001524,
                    800001158,
                    800001788,
                    800001618,
                    800001492,
                    800001006,
                    800001007,
                    800001493,
                    800001123,
                    800001253,
                    800001753,
                    800006613,
                    800001900,
                    800001760,
                    800001260,
                    800001383,
                    800001047,
                    800001424,
                    800001061,
                    800001444,
                    800001438,
                    800001921,
                    800001325,
                    800001922,
                    800001065,
                    800001926,
                    800001207,
                    800001343,
                    800001703,
                    800001344,
                    800001344,
                    800001213,
                    800001068,
                    800001443,
                    800001814,
                    800007290,
                    800001071,
                    800001072,
                    800001074,
                    800001447,
                    800001695,
                    800001333,
                    800001450,
                    800001935,
                    800001936,
                    800008013,
                    800008015,
                    800008019,
                    800001098,
                    800001100,
                    800001363,
                    800001971,
                    800001479,
                    800001737,
                    800001480,
                    800575117,
                    800658934,
                    800001775,
                    800299338)
               and rule_type = 12 --强制选择
               and status_cd <> '1100')
       and status_cd <> '1100'
       and exists (select 1
              from prod_rel_restrict_offer prro
             where pr.product_rel_id = prro.product_rel_id
               and status_cd like '10%');
  cursor cur_opr is
    select *
      from offer_prod_rel
     where product_id = v_product_a_id
       and rule_type = 12
       and status_cd like '10%';
  cursor cur_po is
    select *
      from prod_offer po
     where exists (select 1
              from offer_prod_rel opr
             where po.prod_offer_id = opr.prod_offer_id
               and opr.product_id = 800000002
               and rule_type = 12
               and opr.status_cd like '10%')
       and po.offer_type = '11' --套餐销售品
       and po.status_cd like '10%'
       and po.ibs_offer_type = 10010; --单接入类
begin
  for rec_pr in cur_pr loop
    v_product_a_id := rec_pr.product_a_id;
    for rec_po in cur_po loop
      select count(*)
        into v_cnt_1
        from prod_rel_restrict_offer
       where product_rel_id = rec_pr.product_rel_id
         and rela_offer_id = rec_po.prod_offer_id;
      if v_cnt_1 = 0 then
        select seq_prod_rel_restrict_offer_id.nextval
          into v_restrict_id
          from dual;
        insert into prod_rel_restrict_offer
        values
          (v_restrict_id,
           rec_pr.product_rel_id,
           '10',
           rec_po.prod_offer_id,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           rec_po.area_id,
           null,
           -1,
           -1,
           v_remark);
        v_proc_cnt_1 := v_proc_cnt_1 + 1;
      else
        select max(restrict_id)
          into v_restrict_id
          from prod_rel_restrict_offer
         where product_rel_id = rec_pr.product_rel_id
           and rela_offer_id = rec_po.prod_offer_id;
      end if;
      for rec_opr in cur_opr loop
        select count(*)
          into v_cnt_2
          from obj_rel_cfg
         where obj_class_id = 102
           and cfg_class_id = 64855
           and obj_id = rec_opr.offer_prod_rela_id
           and cfg_id = v_restrict_id;
        if v_cnt_2 = 0 then
          insert into obj_rel_cfg
          values
            (seq_obj_rel_cfg_id.nextval,
             102,
             rec_opr.offer_prod_rela_id,
             64855,
             v_restrict_id,
             1,
             null,
             sysdate,
             -1,
             '1000',
             sysdate,
             sysdate,
             -1,
             v_remark);
          v_proc_cnt_2 := v_proc_cnt_2 + 1;
        end if;
      end loop;
    end loop;
  end loop;
  o_msg := to_char(v_proc_cnt_1) || ' + ' || to_char(v_proc_cnt_2);
end;
/
