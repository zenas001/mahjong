CREATE PROCEDURE           PROC_REPAIR_PROD_INST_ATTR(
                                                       I_MOD    IN NUMBER,  --模
                                                       I_LEAVE  IN NUMBER   --余数
                                                       ) IS
  CURSOR CUR IS
    --处理上下行速率和实际速率的attr_value为空的属性
    SELECT *
      FROM PROD_INST_ATTR
     WHERE ATTR_ID IN (800000315, 800000260, 800000283)
       AND STATUS_CD = '1000'
       AND ATTR_VALUE IS NULL
       AND MOD(PROD_INST_ATTR_ID, I_MOD) = I_LEAVE;
  I NUMBER(10) := 10;
  I_AREA_NBR VARCHAR2(6);
BEGIN
  FOR REC IN CUR LOOP
    BEGIN
      I := I + 1;
      I_AREA_NBR := '';
      SELECT NVL(AREA_NBR, '590') INTO I_AREA_NBR FROM AREA_CODE WHERE REGION_ID = REC.AREA_ID;
      IF I_AREA_NBR IS NULL OR I_AREA_NBR = '' THEN
        I_AREA_NBR := '590';
      END IF;
      --填充attr_vlue
      UPDATE PROD_INST_ATTR
         SET ATTR_VALUE =
             (SELECT ATTR_VALUE
                FROM ATTR_VALUE
               WHERE ATTR_VALUE_ID = REC.ATTR_VALUE_ID)
       WHERE PROD_INST_ATTR_ID = REC.PROD_INST_ATTR_ID;
       --送批量增量计费
       BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE(
                                            'PROD_INST_ATTR',
                                            'PROD_INST_ATTR_ID',
                                            REC.PROD_INST_ATTR_ID,
                                            'PROC_REPAIR_PROD_INST_ATTR修复',
                                            '1002',
                                            '修复产品属性attr_value_id有值但attr_value为空',
                                            '',
                                            I_AREA_NBR);
       IF I > 100 THEN
         COMMIT;
         I := 0;
       END IF;
       EXCEPTION WHEN OTHERS THEN
         NULL;
    END;
  END LOOP;
  COMMIT;
END PROC_REPAIR_PROD_INST_ATTR;
/
