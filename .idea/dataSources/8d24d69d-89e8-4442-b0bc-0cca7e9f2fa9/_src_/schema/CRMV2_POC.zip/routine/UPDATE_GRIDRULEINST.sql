CREATE procedure           update_gridruleinst(i_rule_inst_id in number,
                                                i_grid_id      in number,
                                                i_flag         in varchar2,
                                                o_result       out number) is

  /*功能说明
  前台调用存储过程，用于删除网格和设备关联时，
  将参数保存接口表,自动划配根据网格单元下所有产品实例重新划配
  i_flag:
  修改  UPDATE
  新增  INSERT
  删除  DELETE
  */
  i number := 0;
begin
  if i_grid_id is not null and i_rule_inst_id is not null then
    --先判断网格是否存在接口表
    select count(1)
      into i
      from update_grid_rule_inst
     where op_result = '0'
       and grid_id = i_grid_id
       and rule_inst_id = i_rule_inst_id;
    --如果不存在，直接增加记录
    if i <= 0 then
      insert into update_grid_rule_inst
        (id, grid_id, rule_inst_id, op_flag, modify_date, op_result)
        select seq_update_grid_rule_inst_id.nextval, i_grid_id,
               i_rule_inst_id, i_flag, sysdate, '0' op_result
          from dual;
      commit;
    end if;
    o_result := 0; --0成功，其余失败
  else
    o_result := -2; ---2 数据为空
  end if;
exception
  when others then
    o_result := -1;
end;
/
