CREATE procedure           A2 is
begin
  INSERT INTO TEST54(FIELD,CREATE_DATE)
  VALUES
  ('A2',SYSDATE);
  COMMIT;
end A2;
/
