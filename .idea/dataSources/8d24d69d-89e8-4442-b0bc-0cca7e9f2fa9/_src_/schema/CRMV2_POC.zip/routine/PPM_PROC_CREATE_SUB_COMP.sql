CREATE procedure           ppm_proc_create_sub_comp(old_win_id number,vcomp_id number,new_win_id number,parent_win_comp_id number, t_inst_class_id number,v_area_id number) as
	cursor mycur is select * from tmp_ppm_sys_win_componet sc where sc.parent_componet_id = vcomp_id and sc.win_id = old_win_id;
	new_win_comp_id number;
	new_attr_id number;
begin

-- 创建子组件
for r in mycur loop
-- 创建组件
select seq_sys_win_componet_id.nextval into new_win_comp_id from dual;

begin
	select y.attr_id into new_attr_id from attr_spec y where y.java_code = r.componet_code and rownum=1 and y.class_id = t_inst_class_id ;
exception
	when others then
	new_attr_id := -1;
end;

insert into sys_win_componet(componet_id,attr_id ,win_id,parent_componet_id ,componet_code,componet_name,compone_thint,componet_desc,is_display,display_expr ,display_wight,display_height ,display_style,read_only ,display_order,is_newline,positionx ,positiony ,bind_expr ,status_cd ,status_date,create_date,update_date,componet_type,param1,param2,componet_catalog ,area_id ,region_cd ,update_staff ,create_staff ,class_id,proc_default ,remark)
values( new_win_comp_id,new_attr_id ,new_win_id,parent_win_comp_id ,r.componet_code,r.componet_name,r.compone_thint,r.componet_desc,r.is_display,r.display_expr ,r.display_wight,r.display_height ,r.display_style,r.read_only ,r.display_order,r.is_newline,r.positionx ,r.positiony ,r.bind_expr ,r.status_cd ,r.status_date,r.create_date,r.update_date,r.componet_type,r.param1,r.param2,r.componet_catalog ,v_area_id ,v_area_id ,r.update_staff ,r.create_staff ,r.class_id,r.proc_default ,r.remark);
-- 创建子组件
ppm_proc_create_sub_comp(old_win_id,r.componet_id,new_win_id,new_win_comp_id,t_inst_class_id,v_area_id);
end loop;
end;
/
