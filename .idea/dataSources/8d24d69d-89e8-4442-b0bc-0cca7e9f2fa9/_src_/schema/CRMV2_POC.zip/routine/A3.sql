CREATE procedure           A3 is
begin
  INSERT INTO TEST54(FIELD)
  VALUES
  ('A3');
end A1;
/
