CREATE procedure           niud_p_prod_rel_restrict_offer(o_msg out varchar2) is
  cursor cur_po is
    select *
      from prod_offer po
     where exists (select 1
              from offer_prod_rel opr
             where po.prod_offer_id = opr.prod_offer_id
               and opr.product_id = 800000002
               and rule_type = 12
               and opr.status_cd like '10%')
       and po.offer_type = '11'
       and po.status_cd like '10%';
  cursor cur_pr is
    select *
      from product_relation
     where product_z_id = 800000002 ---Z端为移动语音
       and product_a_id in ----A端为与移动语音有关系的产品
           (select product_id
              from offer_prod_rel
             where prod_offer_id in ---从1.0取出来的与“天翼”销售品有关系的销售品
                   (800001144,
                    800001512,
                    800001022,
                    800001773,
                    800001643,
                    800001777,
                    800001524,
                    800001158,
                    800001788,
                    800001618,
                    800001492,
                    800001006,
                    800001007,
                    800001493,
                    800001123,
                    800001253,
                    800001753,
                    800006613,
                    800001900,
                    800001760,
                    800001260,
                    800001383,
                    800001047,
                    800001424,
                    800001061,
                    800001444,
                    800001438,
                    800001921,
                    800001325,
                    800001922,
                    800001065,
                    800001926,
                    800001207,
                    800001343,
                    800001703,
                    800001344,
                    800001344,
                    800001213,
                    800001068,
                    800001443,
                    800001814,
                    800007290,
                    800001071,
                    800001072,
                    800001074,
                    800001447,
                    800001695,
                    800001333,
                    800001450,
                    800001935,
                    800001936,
                    800008013,
                    800008015,
                    800008019,
                    800001098,
                    800001100,
                    800001363,
                    800001971,
                    800001479,
                    800001737,
                    800001480,
                    800575117,
                    800658934,
                    800001775,
                    800299338)
               and status_cd <> '1100')
       and status_cd <> '1100';
  v_tmp number(10);
begin
  for rec_pr in cur_pr loop
    for rec_po in cur_po loop
      null;
    end loop;
  end loop;
end;
/
