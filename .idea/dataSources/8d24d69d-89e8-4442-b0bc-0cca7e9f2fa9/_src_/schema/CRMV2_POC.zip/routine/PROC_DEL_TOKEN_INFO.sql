CREATE procedure           PROC_DEL_TOKEN_INFO is
begin
  insert into token_info_his
    select TOKEN,
           STAFF_ID,
           SYSTEM_USER_CODE,
           ORG_ID,
           LAN_ID,
           IP,
           TOKEN_INFO_ID,
           CREATE_DATE,
           STATUS_DATE,
           UPDATE_DATE,
           STATUS_CD,
           AREA_ID,
           REGION_CD,
           CREATE_STAFF,
           UPDATE_STAFF,
           seq_token_info_his_id.nextval
   from TOKEN_INFO t where t.create_date < sysdate-2;
   delete from TOKEN_INFO t where t.create_date < sysdate-2;
   COMMIT;
end PROC_DEL_TOKEN_INFO;
/
