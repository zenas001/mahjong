CREATE PROCEDURE           "P_SYS_WINDOW" (V_RELATION_A_ID  VARCHAR2, -- A端输入规格id集合
                                                        V_RELATION_B_ID  VARCHAR2, -- B端输入规格id集合
                                                        V_PROCEDURE_CODE VARCHAR2, -- 存储过程编码
                                                        V_RELATION_TYPE  VARCHAR2, -- 指定关联类型
                                                        V_CFG_AREA_ID    VARCHAR2, -- 指定本地标识，非空
                                                        /* V_MESSAGE       OUT VARCHAR2,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              V_MESSAGE_1     OUT VARCHAR2,*/
                                                        v_result_seq_id OUT NUMBER) is

begin


select *
  from sys_class_rel_obj
 where class_id = 800001176
   and status_cd = '1000'; ---产品界面动作

select *
  from sys_window
 where class_id = 800001176
   and win_id in (select obj_id from sys_class_rel_obj where class_id=800001176 and status_cd='1000');----界面窗口（有配置具体设计内容的窗口）

select * from sys_win_componet where win_id=8597;---窗口配置的具体属性

select * from obj_area_rela



end ;
  /
