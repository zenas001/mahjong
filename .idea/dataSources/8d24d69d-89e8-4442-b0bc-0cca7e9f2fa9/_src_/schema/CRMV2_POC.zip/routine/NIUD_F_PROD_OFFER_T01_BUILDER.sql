CREATE function           niud_f_prod_offer_t01_builder(i_prod_offer_name in varchar2,
                                                         i_price_plan_id   in number,
                                                         i_ibs_offer_type  in number,
                                                         i_product_id      in number,
                                                         o_msg             out varchar2)
  return number is

  /****
    功能：
        一个简单的接入类基础销售品的构造器
        建立和产品的强制选择关系及服务
    入参：
        i_prod_offer_name - 销售品名称
        i_product_id - 强制选择的产品的规格ID
    出参：
        o_msg - 提示信息
    返回：
                    by niud, 120518
  ****/

  v_tmp           number(4);
  v_prod_offer_id prod_offer.prod_offer_id%type;
  v_remark        varchar2(200) := 'configurated via niud_f_prod_offer_t01_builder';

  cursor cur is
    select *
      from service_offer
     where service_offer_name in ('订购', '退订', '变更')
       and sort = 'OFFER';

begin
  if i_prod_offer_name is null or i_product_id is null or
     i_ibs_offer_type is null then
    o_msg := '入参不可为空！';
    return(0);
  end if;
  select count(*) into v_tmp from product where product_id = i_product_id;
  if v_tmp <> 1 then
    o_msg := '产品规格ID有误！';
    return(-1);
  end if;
  if i_ibs_offer_type <> 10010 and i_ibs_offer_type <> 10020 then
    o_msg := '单接入类基础销售品请输入10010，多接入类基础销售品请输入10020！';
    return(-3);
  end if;

  begin
    select prod_offer_id
      into v_prod_offer_id
      from prod_offer
     where prod_offer_name = i_prod_offer_name;
  exception
    when no_data_found then
      select seq_prod_offer_id.nextval into v_prod_offer_id from dual;
      insert into prod_offer
      values
        (v_prod_offer_id,
         i_prod_offer_name,
         null,
         '1000',
         sysdate,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         v_remark,
         null,
         null,
         '10',
         sysdate,
         sysdate,
         null,
         null,
         null,
         1,
         null,
         -1,
         -1,
         'T01',
         null,
         null,
         null,
         null,
         'Y',
         null,
         i_price_plan_id,
         null,
         i_ibs_offer_type,
         null,
         null);
  end;

  select count(*)
    into v_tmp
    from offer_prod_rel
   where rule_type = '12' --强制选择
     and prod_offer_id = v_prod_offer_id;
  if v_tmp > 0 then
    o_msg := '已存在和产品的强制关系！';
    return(-2);
  end if;

  insert into offer_prod_rel
  values
    (seq_offer_prod_rel_id.nextval,
     i_product_id,
     v_prod_offer_id,
     null,
     1,
     1,
     '12',
     '1000',
     sysdate,
     sysdate,
     sysdate,
     null,
     1,
     null,
     -1,
     -1,
     'N',
     null,
     null,
     null,
     null,
     null,
     null,
     v_remark,
     null,
     sysdate);
  commit;

  for rec in cur loop
    select count(*)
      into v_tmp
      from offer_service_rel
     where prod_offer_id = v_prod_offer_id
       and service_offer_id = rec.service_offer_id;
    if v_tmp = 0 then
      insert into offer_service_rel
      values
        (seq_offer_service_rel_id.nextval,
         v_prod_offer_id,
         rec.service_offer_id,
         '1000',
         sysdate,
         sysdate,
         sysdate,
         1,
         null,
         -1,
         -1,
         null,
         v_remark);
    end if;
  end loop;

  return(1);
end;
/
