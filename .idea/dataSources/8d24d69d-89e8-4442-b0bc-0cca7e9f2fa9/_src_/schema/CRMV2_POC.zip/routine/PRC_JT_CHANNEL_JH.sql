CREATE procedure           prc_jt_channel_jh is
  v_INTF_FTP_CONTROL_NBR crmv2.INTF_FTP_CONTROL.INTF_FTP_CONTROL_NBR%TYPE;
  V_CNT                  NUMBER(2);
  I                      NUMBER(2) DEFAULT 1;
  v_batch_id             number(5) default 0;
  V_avg_cnt     NUMBER(10);
  --v_common_region_id     varchar2(10);
begin
  select max(batch_id) + 1 into v_batch_id from jt_channel_all_log;

  execute immediate 'delete from channel_up';
  execute immediate 'delete from channel_attr_up';
  execute immediate 'delete from operators_up';
  execute immediate 'delete from operators_attr_up';
  execute immediate 'delete from staff_up';
  execute immediate 'delete from staff_attr_up';
  execute immediate 'delete from channel_rela_up';
  execute immediate 'delete from channel_operators_rela_up';
  execute immediate 'delete from staff_operators_rela_up';
  execute immediate 'delete from staff_channel_rela_up';

    execute immediate 'delete from BIZ_ZONE_UP';
  execute immediate 'delete from BIZ_ZONE_ATTR';
  execute immediate 'delete from CHANNEL_BIZ_ZONE_RELA_UP';
  execute immediate 'delete from STAFF_BIZ_ZONE_RELA_UP';
  execute immediate 'delete from BUSI_STORE_UP';
    execute immediate 'delete from BUSI_STORE_ATTR_UP';
  execute immediate 'delete from CHANNEL_BUSI_STORE_RELA_UP';
  execute immediate 'delete from BUSI_STORE_BIZ_ZONE_RELA';
  commit;

    insert into operators_up
    select TO_CHAR(A.OPERATORS_ID) MSGID,
           A.OPERATORS_NBR,
           replace(replace(A.OPERATORS_NAME, chr(13), ''), chr(10), ''),
           REPLACE(A.CERT_TYPE, '99', '38'),
           A.CERT_NBR,
           replace(replace(A.OPERATORS_SNAME, chr(13), ''), chr(10), ''),
           A.LEGAL_REPR,
           replace(replace(A.address, chr(13), ''), chr(10), ''),
           A.TELEPHONE,
           A.CONTACT,
           A.EMAIL,
           A.OPERATORS_AREA_GRADE,
           (select B.OPERATORS_NBR
              from crmv2.operators b
             where a.PARENT_OPER_ID = b.OPERATORS_ID),
           cr.REGION_CODE,
           a.OPERATORS_TYPE_CD,
           A.STATUS_CD,
           A.STATUS_DATE,
           '',
           TO_CHAR(UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from crmv2.operators a, crmv2.common_region_jt cr
     where a.common_region_id = cr.common_region_id
       and a.status_cd = '1000'
       and operators_nbr not in ('J11000000001', 'J32010000002',
                  'J11000000004', 'J11000000003');
  commit;



  insert into channel_up
    select TO_CHAR(CHANNEL_ID) MSGID,
           CHANNEL_NBR,
           replace(replace(CHANNEL_NAME, chr(13), ''), chr(10), ''),
           CHANNEL_CLASS,
           CHANNEL_TYPE_CD,
           C.chn_type_cd,
           cr.region_code,
           c.STATUS_CD,
           c.STATUS_DATE,
           C.create_date,
           '',
           TO_CHAR(C.UPDATE_DATE,'YYYYMMDDHH24MISS'),
           1
      from crmv2.channel c, crmv2.common_region_jt cr
     where c.channel_class is not null
       and c.status_cd not in
           ( '3000', '1200', '1100','1001') -----------------1297待确认
       and c.common_region_id = cr.common_region_id;
  commit;

/*  for rec in (select channel_nbr
                from channel_up
               where status_cd in ('1201', '1202', '1297', '1298','1299','1400', '1500')) loop
     --     select count(*) into v_cnt from crmv2.channel_his where channel_nbr=rec.channel_nbr and status_cd='1000' ;
          if v_cnt>0 then
    delete from channel_up where channel_nbr = rec.channel_nbr;
    insert into channel_up
      select distinct TO_CHAR(CHANNEL_ID) MSGID,
           CHANNEL_NBR,
           replace(replace(CHANNEL_NAME, chr(13), ''), chr(10), ''),
           CHANNEL_CLASS,
           CHANNEL_TYPE_CD,
           C.chn_type_cd,
           cr.region_code,
           c.STATUS_CD,
           c.STATUS_DATE,
           C.create_date,
           '',
           TO_CHAR(C.UPDATE_DATE,'YYYYMMDDHH24MISS'),
           1
        from crmv2.channel_his c, crmv2.common_region_jt cr
       where c.channel_nbr = rec.channel_nbr
         and c.status_cd = '1000'
         and c.common_region_id = cr.common_region_id
         and c.update_date in
             (select max(update_date)
                from crmv2.channel_his d
               where c.channel_nbr = d.channel_nbr
                 and d.status_cd = '1000');
    else
      update channel_up  set status_cd='1000' where channel_nbr=rec.channel_nbr;
    end if;
    commit;
  end loop;*/


  delete from channel_up
   where MSGID in (select channel_id
                     from crmv2.channel_attr
                    where attr_id = 800057100
                      and attr_value = 'sx' and status_cd='1000')
     and status_cd = '1000';
  commit;

  delete from channel_up where status_cd <> '1000';
  commit;

  update channel_up
     set channel_name = replace(channel_name, '||', '')
   where channel_name like '%||%';
  commit;

  insert into  jt_channel_all_log
    select v_batch_id, 'CHANNEL', '全量数据稽核数据生成', sysdate
      from dual;
  commit;

  --<<<-------------------------此项超过20W
  insert into channel_attr_up
    select TO_CHAR(CA.CHANNEL_ATTR_ID) MSGID,
           c.CHANNEL_NBR,
           TO_NUMBER(ap.group_cd) ext_attr_nbr,
           replace(replace(ca.attr_value, chr(13), ''), chr(10), ''),
           replace(replace(ca.description, chr(13), ''), chr(10), ''),
           TO_CHAR(CA.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           0
      from crmv2.channel_attr ca, crmv2.attr_spec ap, channel_up c
     where ca.attr_id = ap.attr_id
       and ap.class_id = 30
       and ap.group_cd is not null
       and ca.status_cd <> '1100'
       and ca.channel_id = c.msgid and ca.attr_value is not null;
  commit;
  SELECT avg_cnt into V_avg_cnt FROM jt_monitor_upload_sms where  bus_code='BUS37033';
    select CEIL(COUNT(*) / V_avg_cnt) INTO V_CNT from channel_attr_up;
  LOOP

    UPDATE channel_attr_up
       SET SEQ = I
     where ROWNUM <= 200000
       AND SEQ = 0;
    COMMIT;
    I := I + 1;
    EXIT WHEN I > V_CNT;
  END LOOP;

  insert into jt_channel_all_log
    select v_batch_id, 'CHANNEL_ATTR', '全量数据稽核数据生成', sysdate
      from dual;
  commit;
  ------------------------------------>>>

  insert into channel_rela_up
    select TO_CHAR(A.RELA_ID) MSGID,
           b.CHANNEL_NBR,
           c.channel_nbr rela_CHANNEL_NBR,
           a.RELA_TYPE,
           '',
           TO_CHAR(a.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from crmv2.channel_rela a, channel_up b, channel_up c
     where a.status_cd = '1000'
       and a.cha_channel_id = b.msgid
       and a.channel_id = c.msgid;
  commit;

  insert into jt_channel_all_log
    select v_batch_id, 'CHANNEL_RELA', '全量数据稽核数据生成', sysdate
      from dual;
  commit;

  insert into operators_up
    select TO_CHAR(A.OPERATORS_ID) MSGID,
           A.OPERATORS_NBR,
           replace(replace(A.OPERATORS_NAME, chr(13), ''), chr(10), ''),
           REPLACE(A.CERT_TYPE, '99', '38'),
           A.CERT_NBR,
           replace(replace(A.OPERATORS_SNAME, chr(13), ''), chr(10), ''),
           A.LEGAL_REPR,
           replace(replace(A.address, chr(13), ''), chr(10), ''),
           A.TELEPHONE,
           A.CONTACT,
           A.EMAIL,
           A.OPERATORS_AREA_GRADE,
           (select B.OPERATORS_NBR
              from crmv2.operators b
             where a.PARENT_OPER_ID = b.OPERATORS_ID),
           cr.REGION_CODE,
           a.OPERATORS_TYPE_CD,
           A.STATUS_CD,
           A.STATUS_DATE,
           '',
           TO_CHAR(UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from crmv2.operators a, crmv2.common_region_jt cr
     where a.common_region_id = cr.common_region_id
       and a.status_cd = '1000'
       and operators_nbr not in ('J11000000001', 'J32010000002',
                  'J11000000004', 'J11000000003');
  commit;

  /*  for rec in (select *
                from operators_up
               where common_region_id like '59%') loop
    begin
      select c.region_code
        into v_common_region_id
        from crmv2.operators a, common_region b, common_region c
       where a.operators_nbr = rec.operators_nbr
         and a.common_region_id = b.common_region_id
         and b.up_region_id = c.common_region_id;
      update operators_up a
         set common_region_id = v_common_region_id
       where a.operators_nbr = rec.operators_nbr;
      commit;
    exception
      when others then
        null;
    end;
  end loop;*/
  /*
  update operators_up
     set operators_name = replace(operators_name, '||', '')
   where operators_name like '%||%';
  commit;
  update operators_up
     set address = replace(address, '||', '')
   where address like '%||%';
  commit;*/

  insert into jt_channel_all_log
    select v_batch_id, 'OPERATORS', '全量数据稽核数据生成', sysdate
      from dual;
  commit;

  insert into operators_attr_up
    select TO_CHAR(CA.OPERATORS_ATTR_ID) MSGID,
           c.OPERATORS_NBR,
           TO_NUMBER(ap.group_cd) ext_attr_nbr,
           replace(replace(ca.attr_value, chr(13), ''), chr(10), ''),
           replace(replace(ca.description, chr(13), ''), chr(10), ''),
           TO_CHAR(CA.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           0
      FROM crmv2.operators_attr ca,
           crmv2.attr_spec      ap,
           operators_up   c
     where ca.attr_id = ap.attr_id
       and ap.group_cd is not null
       AND EXT_ATTR_NBR LIKE '50000%'
       and ca.status_cd = '1000'
       and ca.operators_id = c.msgid;
  insert into jt_channel_all_log
    select v_batch_id, 'OPERATORS_ATTR', '全量数据稽核数据生成', sysdate
      from dual;
  commit;

  insert into staff_up -----(部分字段还需补充)
    (MSGID,
     SALES_CODE,
     STAFF_CODE,
     STAFF_NAME,
     CERT_TYPE,
     CERT_NUMBER,
     MOBILE_PHONE,
     EMAIL,
     COMMON_REGION_ID,
     STATUS_CD,
     STATUS_DATE,
     VERSION,
     seq)
    select to_char(S.STAFF_ID),
           staff_nbr,
           (select staff_code
              from crmv2.system_user
             where staff_id = s.staff_id
               and rownum = 1),
           nvl(STAFF_NAME, '补空') STAFF_NAME,
           b.CERT_TYPE,
           b.CERT_NUMBER,
           SUBSTR(C.MOBILE_PHONE, 1, 32) MOBILE_PHONE,
           SUBSTR(C.E_MAIL, 1, 30) EMAIL,
            S.REGION_CODE,
           s.STATUS_CD,
           nvl(s.STATUS_DATE, s.create_date),
           TO_CHAR(S.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from (select A.CREATE_DATE,A.PARTY_ID,A.STAFF_ID,A.STAFF_NBR,A.STAFF_NAME,CR.REGION_CODE,A.STATUS_CD,A.STATUS_DATE,A.UPDATE_DATE
              from crmv2.staff A, ORGANIZATION OG, crmv2.common_region_jt CR
             where A.ORG_ID = OG.ORG_ID
               AND OG.COMMON_REGION_ID = CR.COMMON_REGION_ID) S
      LEFT join crmv2.party_certification b
        on s.party_id = b.party_id
      LEFT JOIN crmv2.party_contact_info C
        ON s.party_id = C.party_id
     where s.staff_nbr is not null
       and s.status_cd = '1000'
       and exists (select *
              from crmv2.staff_channel_rela d
             where s.staff_id = d.staff_id
               and d.status_cd = '1000');
  commit;
   /* insert into staff_up -----(部分字段还需补充)
    (MSGID,
     SALES_CODE,
     STAFF_CODE,
     STAFF_NAME,
     CERT_TYPE,
     CERT_NUMBER,
     MOBILE_PHONE,
     EMAIL,
     STATUS_CD,
     STATUS_DATE,
     seq)
    select to_char(S.STAFF_ID),
           staff_nbr,
           (select staff_code
              from crmv2.system_user
             where staff_id = s.staff_id
               and rownum = 1),
           nvl(STAFF_NAME, '补空') STAFF_NAME,
           b.CERT_TYPE,
           b.CERT_NUMBER,
           SUBSTR(C.MOBILE_PHONE, 1, 32) MOBILE_PHONE,
           SUBSTR(C.E_MAIL, 1, 30) EMAIL,
            S.REGION_CODE,
           s.STATUS_CD,
           nvl(s.STATUS_DATE, s.create_date),
           TO_CHAR(S.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from (select A.CREATE_DATE,A.PARTY_ID,A.STAFF_ID,A.STAFF_NBR,A.STAFF_NAME,CR.REGION_CODE,A.STATUS_CD,A.STATUS_DATE,A.UPDATE_DATE
              from crmv2.staff A, ORGANIZATION OG, crmv2.common_region_jt CR
             where A.ORG_ID = OG.ORG_ID
               AND OG.COMMON_REGION_ID = CR.COMMON_REGION_ID) s
      LEFT join crmv2.party_certification b on s.party_id = b.party_id
      LEFT JOIN crmv2.party_contact_info C ON s.party_id = C.party_id
     where s.staff_nbr is not null
       and s.status_cd = '1000' and staff_nbr in (select * from linyx_tmp);*/

  update staff_up
     set STAFF_CODE = '', mobile_phone = ''
   where mobile_phone is null
      or length(mobile_phone) <> 11 or
           SUBSTR(mobile_phone, 1, 2) NOT IN ('13', '15', '18', '17','14');
  COMMIT;

  update staff_up set status_cd='1000' where status_cd='1800';
  commit;

  delete from staff_up a
   where msgid in (select msgid
                     from staff_up
                    group by msgid
                   having count(*) > 1)
     and rowid <>
         (select min(rowid) from staff_up b where a.msgid = b.msgid);
  commit;

  insert into jt_channel_all_log
    select v_batch_id, 'STAFF', '全量数据稽核数据生成', sysdate from dual;
  commit;

  insert into staff_attr_up
    select TO_CHAR(CA.staff_ATTR_ID) MSGID,
           c.sales_code,
           TO_NUMBER(ap.group_cd) ext_attr_nbr,
           replace(replace(ca.attr_value, chr(13), ''), chr(10), ''),
           replace(replace(ca.description, chr(13), ''), chr(10), ''),
           TO_CHAR(CA.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      FROM crmv2.staff_attr ca, crmv2.attr_spec ap, staff_up c
     where ca.attr_id = ap.attr_id
       and ap.group_cd is not null
       and ca.status_cd = '1000'
       and ca.staff_id = c.msgid;
      commit;

     delete from staff_attr_up a
      where a.msgid <> (select max(msgid)
                          from staff_attr_up b
                         where a.sales_code = b.sales_code
                           and a.attr_id = b.attr_id);
  commit;

  insert into jt_channel_all_log
    select v_batch_id, 'STAFF_ATTR', '全量数据稽核数据生成', sysdate
      from dual;
  commit;

  insert into channel_operators_rela_up
    select TO_CHAR(A.RELA_ID) MSGID,
           b.CHANNEL_NBR,
           c.operators_nbr,
           a.rela_type,
           a.description,
           TO_CHAR(a.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from crmv2.channel_operators_rela a,
           channel_up             b,
           operators_up           c
     where a.status_cd <>'1100'
       and a.channel_id = b.msgid
       and a.operators_id = c.msgid
       and b.channel_class is not null;
  commit;

      delete from channel_operators_rela_up a
 where msgid <> (select max(msgid)
                   from channel_operators_rela_up b
                  where a.channel_nbr = b.channel_nbr
                    and a.operators_nbr = b.operators_nbr);
   commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'CHANNEL_OPERATORS_RELA',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;

  insert into staff_operators_rela_up
    select TO_CHAR(A.RELA_ID) MSGID,
           b.sales_code,
           c.operators_nbr,
           a.rela_type,
           a.description,
           TO_CHAR(a.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from crmv2.staff_operators_rela a, staff_up b, operators_up c
     where a.status_cd  <>'1100'
       and a.staff_id = b.msgid
       and a.operators_id = c.msgid;
  commit;
    delete from staff_operators_rela_up a
 where msgid <> (select max(msgid)
                   from staff_operators_rela_up b
                  where a.sales_code = b.sales_code
                    and a.operators_nbr = b.operators_nbr);
   commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'STAFF_OPERATORS_RELA',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;

  insert into staff_channel_rela_up
    select TO_CHAR(A.RELA_ID) MSGID,
           b.sales_code,
           c.channel_nbr,
           a.rela_type,
           a.description,
           TO_CHAR(a.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
           1
      from crmv2.staff_channel_rela a, staff_up b, channel_up c
     where a.status_cd  ='1000'
       and a.staff_id = b.msgid
       and a.channel_id = c.msgid
       and c.channel_class is not null;
  commit;
  delete from staff_channel_rela_up a
 where msgid <> (select max(msgid)
                   from staff_channel_rela_up b
                  where a.sales_code = b.sales_code
                    and a.channel_nbr = b.channel_nbr);
   commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'STAFF_CHANNEL_RELA',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;

  insert into BIZ_ZONE_UP
     select to_char(biz_zone_id) MSGID,
       biz_zone_nbr,
       trim(biz_zone_name),
       biz_zone_lever,
       biz_zone_type_cd,
       common_region_id,
       status_cd,
       TO_CHAR(A.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
       '1' seq
  from crmv2.BIZ_ZONE A where STATUS_CD='1000';
  commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'BIZ_ZONE',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;

  insert into BIZ_ZONE_ATTR_UP
  select TO_CHAR(BIZ_ZONE_ATTR_ID) MSGID,
       B.BIZ_ZONE_NBR,
       TO_NUMBER(c.group_cd) ext_attr_nbr,
      replace(replace(a.attr_value, chr(13), ''), chr(10), ''),
       replace(replace(a.description, chr(13), ''), chr(10), ''),
       TO_CHAR(A.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
       '1' seq
  from crmv2.BIZ_ZONE_ATTR A, BIZ_ZONE_UP B,CRMV2.ATTR_SPEC C
 where A.BIZ_ZONE_ID = B.msgid
   AND A.ATTR_ID=C.ATTR_ID
   AND C.GROUP_CD IS NOT NULL
   AND A.STATUS_CD='1000';

      commit;

     delete from BIZ_ZONE_ATTR_UP a
      where a.msgid <> (select max(msgid)
                          from BIZ_ZONE_ATTR_UP b
                         where a.BIZ_ZONE_NBR = b.BIZ_ZONE_NBR
                           and a.attr_id = b.attr_id);
  commit;

  insert into jt_channel_all_log
    select v_batch_id, 'BIZ_ZONE_ATTR_UP', '全量数据稽核数据生成', sysdate
      from dual;
  commit;



insert into STAFF_BIZ_ZONE_RELA_UP
select to_char(rela_id) MSGID,
       b.SALES_CODE,
       c.biz_zone_nbr,
       a.rela_type,
       a.description,
       TO_CHAR(A.UPDATE_DATE, 'YYYYMMDDHH24MISS') VERSION,
       '1' seq
  from CRMV2.STAFF_BIZ_ZONE_RELA a, STAFF_UP b, crmv2.biz_zone_UP c
 where a.STAFF_ID = b.msgid
   and a.biz_zone_id = c.msgid
   and a.status_cd='1000';


  commit;
  delete from STAFF_BIZ_ZONE_RELA_UP a
 where msgid <> (select max(msgid)
                   from STAFF_BIZ_ZONE_RELA_UP b
                  where a.SALES_CODE = b.SALES_CODE
                    and a.biz_zone_nbr = b.biz_zone_nbr);
   commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'STAFF_BIZ_ZONE_RELA',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;



 insert into BUSI_STORE_UP
   select TO_CHAR(BUSI_STORE_ID) MSGID,
       BUSI_STORE_NBR,
       trim(BUSI_STORE_NAME),
       BUSI_STORE_HOUSE_TYPE,
       ADDRESS,
       COMMON_REGION_ID,
       STATUS_CD,
       STATUS_DATE,
       DESCRIPTION,
       TO_CHAR(UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
       '1' seq
  from CRMV2.BUSI_STORE where status_cd='1000';

  commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'BUSI_STORE',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;

 insert into BUSI_STORE_ATTR_UP
 select to_char(busi_store_attr_id) MSGID,
       b.busi_store_nbr,
       TO_NUMBER(c.group_cd) ext_attr_nbr,
      replace(replace(a.attr_value, chr(13), ''), chr(10), ''),
       replace(replace(a.description, chr(13), ''), chr(10), ''),
       TO_CHAR(A.UPDATE_DATE,'YYYYMMDDHH24MISS') VERSION,
       '1' SEQ
  from crmv2.BUSI_STORE_ATTR a, busi_store_up b,CRMV2.ATTR_SPEC C
 where a.busi_store_id = b.msgid
   and A.ATTR_ID=C.ATTR_ID
   AND C.GROUP_CD IS NOT NULL
   AND A.STATUS_CD='1000';


      commit;

     delete from BUSI_STORE_ATTR_UP a
      where a.msgid <> (select max(msgid)
                          from BUSI_STORE_ATTR_UP b
                         where a.busi_store_nbr = b.busi_store_nbr
                           and a.attr_id = b.attr_id);
  commit;

  insert into jt_channel_all_log
    select v_batch_id, 'BUSI_STORE_ATTR', '全量数据稽核数据生成', sysdate
      from dual;
  commit;



insert into CHANNEL_BIZ_ZONE_RELA_up
select to_char(rela_id) MSGID,
       b.channel_nbr,
       c.biz_zone_nbr,
       a.rela_type,
       a.description,
       TO_CHAR(A.UPDATE_DATE, 'YYYYMMDDHH24MISS') VERSION,
       '1' seq
  from crmv2.CHANNEL_BIZ_ZONE_RELA a, channel_UP b, biz_zone_UP c
 where a.channel_id = b.msgid
   and a.biz_zone_id = c.msgid
   AND A.STATUS_CD='1000'
   AND B.CHANNEL_CLASS IS NOT NULL;

  commit;
  delete from CHANNEL_BIZ_ZONE_RELA_up a
 where msgid <> (select max(msgid)
                   from CHANNEL_BIZ_ZONE_RELA_up b
                  where a.biz_zone_nbr = b.biz_zone_nbr
                    and a.channel_nbr = b.channel_nbr);
   commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'CHANNEL_BIZ_ZONE_RELA',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;

insert into CHANNEL_BUSI_STORE_RELA_up
select TO_CHAR(RELA_ID) MSGID,
       B.CHANNEL_NBR,
       C.BUSI_STORE_NBR,
       A.RELA_TYPE,
       A.DESCRIPTION,
       TO_CHAR(a.UPDATE_DATE, 'YYYYMMDDHH24MISS') VERSION,
       '1' SEQ
  from CRMV2.CHANNEL_BUSI_STORE_RELA A, CHANNEL_up B, busi_store_up C
 where A.CHANNEL_ID = B.MSGID
   AND A.BUSI_STORE_ID = C.MSGID
   and a.status_cd='1000'
   and b.channel_class is not null;



  commit;
  delete from CHANNEL_BUSI_STORE_RELA_up a
 where msgid <> (select max(msgid)
                   from CHANNEL_BUSI_STORE_RELA_up b
                  where a.CHANNEL_NBR = b.CHANNEL_NBR
                    and a.BUSI_STORE_NBR = b.BUSI_STORE_NBR);
   commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'CHANNEL_BUSI_STORE_RELA',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;


insert into BUSI_STORE_BIZ_ZONE_RELA_up
select TO_CHAR(RELA_ID) MSGID,
       C.BUSI_STORE_NBR,
       B.BIZ_ZONE_NBR,
       A.RELA_TYPE,
       A.DESCRIPTION,
       TO_CHAR(a.UPDATE_DATE, 'YYYYMMDDHH24MISS') VERSION,
       '1' SEQ
  from CRMV2.BUSI_STORE_BIZ_ZONE_RELA A,
       BIZ_ZONE_up                 B,
       busi_store_up              C
 where A.BIZ_ZONE_ID = B.MSGID
   AND A.BUSI_STORE_ID = C.MSGID
    and a.status_cd='1000';


  commit;
  delete from BUSI_STORE_BIZ_ZONE_RELA_up a
 where msgid <> (select max(msgid)
                   from BUSI_STORE_BIZ_ZONE_RELA_up b
                  where a.BIZ_ZONE_NBR = b.BIZ_ZONE_NBR
                    and a.BUSI_STORE_NBR = b.BUSI_STORE_NBR);
   commit;

  insert into jt_channel_all_log
    select v_batch_id,
           'BUSI_STORE_BIZ_ZONE_RELA',
           '全量数据稽核数据生成',
           sysdate
      from dual;
  commit;
---------------------异常处理
  delete from jt_channel_jh_err;

  insert into jt_channel_jh_err
    select 'STAFF', MSGID, sales_code, '销售员编码超过12位'
      from staff_up
     where length(sales_code) > 12;
  delete from staff_up where length(sales_code) > 12;
  commit;

  insert into jt_channel_jh_err
    select 'CHANNEL', MSGID, COMMON_REGION_ID, '区域编码异常'
      from channel_up
     where COMMON_REGION_ID NOT LIKE '835%';
  delete from channel_up where COMMON_REGION_ID NOT LIKE '835%';
  commit;

  insert into jt_channel_jh_err
    select 'OPERATORS', MSGID, COMMON_REGION_ID, '区域编码异常'
      from operators_up
     where COMMON_REGION_ID NOT LIKE '835%';
  delete from operators_up where COMMON_REGION_ID NOT LIKE '835%';
  commit;

  insert into jt_channel_jh_err
    select 'OPERATORS', MSGID, parent_oper_id, '操作员编码与上级编码一致'
      from operators_up
     where operators_nbr = parent_oper_id;
  delete from operators_up where operators_nbr = parent_oper_id;
  commit;

  ------------------

  SELECT CRMV2.SEQ_INTF_FTP_CONTROL_NBR.NEXTVAL
    INTO v_INTF_FTP_CONTROL_NBR
    FROM DUAL;

  FOR REC IN (select * from jt_channel_cfg) LOOP
    INSERT INTO INTF_FTP_CONTROL
      (INTF_FTP_CONTROL_ID,
       CONTROL_TYPE,
       STATE,
       EXTRACT_START_TIME,
       EXTRACT_FINISH_TIME,
       SEQ,
       INTF_FTP_CONTROL_NBR,
       remark)
    VALUES
      (CRMV2.SEQ_INTF_FTP_CONTROL_ID.NEXTVAL,
       REC.CONTROL_TYPE,
       '70I',
       sysdate,
       SYSDATE,
       0,
       v_INTF_FTP_CONTROL_NBR,
       'CRM2.0生成数据');

    execute immediate 'SELECT COUNT(*) FROM (SELECT DISTINCT SEQ FROM ' ||
                      REC.TABLE_NAME || ')'
      INTO V_CNT;
    I := 1;
    LOOP
      INSERT INTO INTF_FTP_CONTROL
        (INTF_FTP_CONTROL_ID,
         CONTROL_TYPE,
         STATE,
         EXTRACT_START_TIME,
         EXTRACT_FINISH_TIME,
         SEQ,
         INTF_FTP_CONTROL_NBR,
         remark)
      VALUES
        (CRMV2.SEQ_INTF_FTP_CONTROL_ID.NEXTVAL,
         REC.CONTROL_TYPE,
         '70I',
         sysdate,
         SYSDATE,
         I,
         v_INTF_FTP_CONTROL_NBR,
         'CRM2.0生成数据');
      I := I + 1;
      EXIT WHEN I > V_CNT;
    END LOOP;

    COMMIT;
  END LOOP;
end;
/
