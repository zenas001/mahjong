CREATE PROCEDURE           MOVE_DATA_HIS IS

  /**
  *接口描述：转移query_customer_contact_his表数据
  *执行成功返回1，失败返回0
  **/
BEGIN
  INSERT INTO CRMV1.QUERY_CUSTOMER_CONTACT_HIS3
    SELECT /*+FIRST_ROWS*/
     *
      FROM CRMV1.QUERY_CUSTOMER_CONTACT_HIS A
     WHERE A.CREATE_DATE < TRUNC(ADD_MONTHS(SYSDATE, -8), 'MM')
       AND A.CREATE_DATE >= TRUNC(ADD_MONTHS(SYSDATE, -9), 'MM');
  insert into crmv1.sp_exception_log
    (LOG_ID, OBJ_ID, OBJ_TYPE, CALL_DATE, EXCEPTION_XML, RESULT)
  values
    (crmv1.sp_exception_log_id_seq.nextval,
     '',
     'MOVE_DATA_HIS',
     sysdate,
     'moveintohis3',
     '0');
  COMMIT;
  INSERT INTO CRMV1.QUERY_CUSTOMER_CONTACT_HIS2
    SELECT *
      FROM CRMV1.QUERY_CUSTOMER_CONTACT_HIS A
     WHERE A.CREATE_DATE < TRUNC(ADD_MONTHS(SYSDATE, -9), 'MM');
  insert into crmv1.sp_exception_log
    (LOG_ID, OBJ_ID, OBJ_TYPE, CALL_DATE, EXCEPTION_XML, RESULT)
  values
    (crmv1.sp_exception_log_id_seq.nextval,
     '',
     'MOVE_DATA_HIS',
     sysdate,
     'moveintohis2',
     '0');
  COMMIT;
  INSERT INTO CRMV1.QUERY_CUSTOMER_CONTACT_HIS2
    SELECT *
      FROM CRMV1.QUERY_CUSTOMER_CONTACT_HIS3 A
     WHERE A.CREATE_DATE < TRUNC(ADD_MONTHS(SYSDATE, -9), 'MM');
  insert into crmv1.sp_exception_log
    (LOG_ID, OBJ_ID, OBJ_TYPE, CALL_DATE, EXCEPTION_XML, RESULT)
  values
    (crmv1.sp_exception_log_id_seq.nextval,
     '',
     'MOVE_DATA_HIS',
     sysdate,
     'moveintohis2end',
     '0');
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      insert into crmv1.sp_exception_log
        (LOG_ID, OBJ_ID, OBJ_TYPE, CALL_DATE, EXCEPTION_XML, RESULT)
      values
        (crmv1.sp_exception_log_id_seq.nextval,
         '',
         'MOVE_DATA_HIS',
         sysdate,
         'moveintohis',
         '1');
      ROLLBACK;
      END;
    END MOVE_DATA_HIS;
/
