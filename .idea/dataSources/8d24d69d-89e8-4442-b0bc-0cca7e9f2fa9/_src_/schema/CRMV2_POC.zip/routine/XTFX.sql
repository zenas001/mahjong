CREATE procedure           xtfx as

  v_pagecount        NUMBER(10); --页面访问数
  v_region_cd        number; --地市区县，对应dim_p_area_code的region
  v_menucount        varchar2(4) := 0; --功能访问数
  v_visitstaffcount  number; --访问人数
  v_usedteamcount    number; --有使用团队数
  v_openteamcount    number; --已开通团队数
  v_allstaffcount    number; --总工号数
  v_crmstaffcount    number; --crm工号数
  v_ordercount       number; --受理量
  v_finishordercount number; --竣工量
  v_paycount         number; --充值笔数
  v_paymoney         number; --充值金额
  v_count            number;
begin

  for res in (SELECT B.Region_Cd,
                     COUNT(*) ymcount,
                     COUNT(DISTINCT a.STAFF_ID) staffcount,
                     COUNT(DISTINCT a.AGENT_ACOUNT) agentcount
                FROM TL_ACCESS_URI A, ORGANIZATION B
               WHERE A.AGENT_ACOUNT = B.ORG_CODE
                 AND B.STATUS_CD = '1000'
                 AND TO_CHAR(A.CREATE_DATE, 'YYYYMMDD') =
                     TO_CHAR(sysdate, 'YYYYMMDD')
                 AND A.STAFF_ID IS NOT NULL
                 AND A.AGENT_ACOUNT IS NOT NULL
                 AND A.URI_PATH != '/issuoding.shtml'
               GROUP BY B.Region_Cd
               ORDER BY Region_Cd ASC) loop
    for res1 in (SELECT C.region_cd, COUNT(*) gncount
                   FROM TL_ACCESS_URI A, TS_AGENT_MENU B, ORGANIZATION C
                  WHERE A.URI_PATH = B.MENU_PATH
                    AND A.AGENT_ACOUNT = C.ORG_CODE
                    AND C.STATUS_CD = '1000'
                    AND TO_CHAR(A.CREATE_DATE, 'YYYYMMDD') =
                        TO_CHAR(sysdate, 'YYYYMMDD')
                  GROUP BY C.region_cd
                  ORDER BY C.region_cd ASC) loop
      if res.region_cd = res1.region_cd then
        v_menucount := res1.gncount;
      end if;
      select count(*)
        into v_count
        from tl_sysrun_report
       where region = res.Region_Cd
         and rundate = to_char(sysdate, 'YYYY-MM-DD');
      IF v_count > 0 THEN
        update tl_sysrun_report
           set pagecount       = res.ymcount,
               visitstaffcount = res.staffcount,
               usedteamcount   = res.agentcount,
               menucount       = v_menucount
         WHERE region = res.Region_Cd
           and rundate = to_char(sysdate, 'YYYY-MM-DD');
           commit;
      else
        insert into tl_sysrun_report
          (RUNDATE,
           REGION,
           PAGECOUNT,
           MENUCOUNT,
           VISITSTAFFCOUNT,
           USEDTEAMCOUNT,
           OPENTEAMCOUNT,
           ALLSTAFFCOUNT,
           CRMSTAFFCOUNT,
           ORDERCOUNT,
           FINISHORDERCOUNT,
           PAYCOUNT,
           PAYMONEY)
        values
          (to_char(sysdate, 'YYYY-MM-DD'),
           res.Region_Cd,res.ymcount, v_menucount,res.staffcount,res.agentcount,0,0,0,0,0,0,0);
           commit;
      end if;
    end loop;
  end loop;
  for gh in(SELECT B.Region,
       COUNT(*) zghs,
       SUM(DECODE(A.STAFF_TYPE, '1', 1, 0)) CRMZS
  FROM TS_AGENT_STAFF A, DIM_P_AREA_CODE B
 WHERE A.REGION = B.REGION
   AND A.STATE = 'A'
   AND TO_NUMBER(TO_CHAR(A.CREATE_DATE, 'YYYYMMDD')) = TO_NUMBER(TO_CHAR(sysdate, 'YYYYMMDD'))
 GROUP BY B.Region
 ORDER BY Region ASC) loop
  select count(*)
        into v_count
        from tl_sysrun_report
       where region = gh.Region
         and rundate = to_char(sysdate, 'YYYY-MM-DD');
      IF v_count > 0 THEN
        update tl_sysrun_report
           set allstaffcount  = gh.zghs,
               crmstaffcount  = gh.CRMZS
         WHERE region = gh.Region
           and rundate = to_char(sysdate, 'YYYY-MM-DD');
           commit;
    else
        insert into tl_sysrun_report
          (RUNDATE,
           REGION,
           PAGECOUNT,
           MENUCOUNT,
           VISITSTAFFCOUNT,
           USEDTEAMCOUNT,
           OPENTEAMCOUNT,
           ALLSTAFFCOUNT,
           CRMSTAFFCOUNT,
           ORDERCOUNT,
           FINISHORDERCOUNT,
           PAYCOUNT,
           PAYMONEY)
        values
          (to_char(sysdate, 'YYYY-MM-DD'),gh.Region,0,0,0,0,0,gh.zghs,gh.CRMZS, 0,0,0,0);
          commit;
      end if;
  end loop;

  for wd in( SELECT C.Region_Cd, COUNT(DISTINCT B.AGENT_ACOUNT) yktcount
  FROM TS_AGENT_STAFF A, TS_AGENT_STAFF_AUTH B, ORGANIZATION C
 WHERE A.STAFF_ID = B.STAFF_ID
   AND B.AGENT_ACOUNT = C.ORG_CODE
   AND C.STATUS_CD = '1000'
   AND A.STATE = 'A'
   AND B.AGENT_ACOUNT IS NOT NULL
   AND TO_NUMBER(TO_CHAR(A.CREATE_DATE, 'YYYYMMDD')) = TO_NUMBER(TO_CHAR(sysdate, 'YYYYMMDD'))
 GROUP BY C.Region_Cd) loop
  select count(*)
        into v_count
        from tl_sysrun_report
       where region  = wd.Region_Cd
         and rundate = to_char(sysdate, 'YYYY-MM-DD');
      IF v_count > 0 THEN
        update tl_sysrun_report
           set allstaffcount  = wd.yktcount
          WHERE region = wd.Region_Cd
           and rundate = to_char(sysdate, 'YYYY-MM-DD');
           commit;
    else
        insert into tl_sysrun_report
          (RUNDATE,
           REGION,
           PAGECOUNT,
           MENUCOUNT,
           VISITSTAFFCOUNT,
           USEDTEAMCOUNT,
           OPENTEAMCOUNT,
           ALLSTAFFCOUNT,
           CRMSTAFFCOUNT,
           ORDERCOUNT,
           FINISHORDERCOUNT,
           PAYCOUNT,
           PAYMONEY)
        values
          (to_char(sysdate, 'YYYY-MM-DD'),wd.Region_Cd,0,0,0,0,wd.yktcount,0,0,0,0,0,0);
          commit;
      end if;
 end loop;
 for sl in(
SELECT DISTINCT F.AGENTACCOUNT, F.SLL, F.JGL, D.REGION
  FROM (SELECT T.AGENTACCOUNT,
               COUNT(*) SLL,
               NVL(SUM(DECODE(B.ORDERSTATE, '300000', 1, 0)), 0) JGL
          FROM TF_ORDERBASIC T, TF_OTHERORDERINFO B
         WHERE T.WEBORDER = B.WEBORDER(+)
           AND T.UPORDERID = 0
           AND TO_NUMBER(TO_CHAR(T.ACCEPTTIME, 'YYYYMMDD')) = TO_NUMBER(TO_CHAR(sysdate, 'YYYYMMDD'))
         GROUP BY T.AGENTACCOUNT
         ORDER BY AGENTACCOUNT ASC) F,
       TS_AGENT_STAFF_TEAM C,
       TS_AGENT_STAFF D
 WHERE C.STAFF_ID = D.STAFF_ID
   AND F.AGENTACCOUNT = C.AGENT_ACOUNT) loop
   select count(*)
        into v_count
        from tl_sysrun_report
       where region  = sl.REGION
         and rundate = to_char(sysdate, 'YYYY-MM-DD');
      IF v_count > 0 THEN
        update tl_sysrun_report
           set ordercount   = sl.sll,finishordercount =sl.jgl
          WHERE region = sl.REGION
           and rundate = to_char(sysdate, 'YYYY-MM-DD');
           commit;
    else
        insert into tl_sysrun_report
          (RUNDATE,
           REGION,
           PAGECOUNT,
           MENUCOUNT,
           VISITSTAFFCOUNT,
           USEDTEAMCOUNT,
           OPENTEAMCOUNT,
           ALLSTAFFCOUNT,
           CRMSTAFFCOUNT,
           ORDERCOUNT,
           FINISHORDERCOUNT,
           PAYCOUNT,
           PAYMONEY)
        values
          (to_char(sysdate, 'YYYY-MM-DD'),sl.REGION,0,0,0,0,0,0,0,sl.sll,sl.jgl,0,0);
          commit;
      end if;
    end loop;
 for je in(SELECT DISTINCT T1.AGENT_ACOUNT, T.CZCS, T.CZJE, T2.REGION
  FROM TS_AGENT_STAFF_TEAM T1,
       TS_AGENT_STAFF T2,
       (SELECT T.AGENTACCOUNT, COUNT(*) CZCS, SUM(AMOUNT) / 100 CZJE
          FROM TF_PAYMENT T
         WHERE TO_CHAR(OIDTIME, 'YYYYMMDD') = to_char(sysdate,'YYYYMMDD')
         GROUP BY AGENTACCOUNT) T
 WHERE T.AGENTACCOUNT = T1.AGENT_ACOUNT
   AND T1.STAFF_ID = T2.STAFF_ID
) loop
  select count(*)
        into v_count
        from tl_sysrun_report
       where region   = je.REGION
        and rundate = to_char(sysdate, 'YYYY-MM-DD');
      IF v_count > 0 THEN
        update tl_sysrun_report
           set  paycount=je.czcs,
                paymoney =je.czje
          WHERE region = je.region
           and rundate = to_char(sysdate, 'YYYY-MM-DD');
           commit;
    else
        insert into tl_sysrun_report
          (RUNDATE,
           REGION,
           PAGECOUNT,
           MENUCOUNT,
           VISITSTAFFCOUNT,
           USEDTEAMCOUNT,
           OPENTEAMCOUNT,
           ALLSTAFFCOUNT,
           CRMSTAFFCOUNT,
           ORDERCOUNT,
           FINISHORDERCOUNT,
           PAYCOUNT,
           PAYMONEY)
        values
          (to_char(sysdate, 'YYYY-MM-DD'),je.region,0,0,0,0,0,0,0,0,0,je.czcs,je.czje);
          commit;
      end if;
  end loop;
for sll1 in(select (select bss_areaid from td_area b where b.areacode = d.Areacode ) region,
       d.PRE001_DAY,d.PRE002_DAY,d.PRE101_DAY,d.UIM001_DAY,d.UIM002_DAY,d.UIM003_DAY
  from (SELECT A.Areacode,
               SUM(DECODE(A.SERVICETYPE, 'pre001', 1, 0)) PRE001_DAY,
               SUM(DECODE(A.SERVICETYPE, 'pre002', 1, 0)) PRE002_DAY,
               SUM(DECODE(A.SERVICETYPE, 'pre101', 1, 0)) PRE101_DAY,
               SUM(DECODE(A.SERVICETYPE, 'uim001', 1, 0)) UIM001_DAY,
               SUM(DECODE(A.SERVICETYPE, 'uim002', 1, 0)) UIM002_DAY,
               SUM(DECODE(A.SERVICETYPE, 'uim003', 1, 0)) UIM003_DAY
          FROM TF_ORDERBASIC A
         WHERE TO_CHAR(A.ACCEPTTIME, 'YYYYMMDD') =to_char(sysdate,'YYYYMMDD')
           AND A.UPORDERID = 0
         GROUP BY A.Areacode) d) loop
   if sll1.region!=null then
    insert into tl_sysorder_report
          (rundate,
           region,
           pre001_count,
           pre101_count,
           uim001_count,
           uim002_count,
           uim003_count,
           paycount,
           paymoney)
        values
          (to_char(sysdate, 'YYYY-MM-DD'),
           sll1.region,
           sll1.PRE001_DAY,
           sll1.PRE002_DAY,
           sll1.PRE101_DAY,
           sll1.UIM001_DAY,
           sll1.UIM002_DAY,
           sll1.UIM003_DAY,
           0,
           0);
           commit;
         end if ;
   end loop;
 /*  for tjje in() loop

   end loop; */


end;
/
