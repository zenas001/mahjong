CREATE procedure           automatic_carryover_points(ruletype in varchar2) is
  /*功能说明
     积分自动结转
  */
  --查找积分账本失效的积分帐户
  cursor pointaccountlist is
    select *
      from point_account t3
     where t3.status_cd = '10'
       and (t3.point_account_id in
           (select t4.pay_point_acct_id
               from point_acct_bala t4
              where t4.expire_date <= sysdate));
begin
  for pointaccount in pointaccountlist loop
    declare
      --过期年数
      vyearcount number(12);
      --统计帐户下的积分帐本结转余额
      v_carryover_point        number(9);
      v_point_acct_chng_rec_id number(9);
      --积分账本失效的总积分余额
      vsumpointbalance number(9);
      --帐本数量
      vpointacctbalacount number(9);
      --查找积分帐户下的积分账本
      cursor pointacctbalalist is
        select *
          from point_acct_bala t4
         where (t4.pay_point_acct_id = pointaccount.point_account_id)
           and t4.status_cd = '10'
           and t4.expire_date <= sysdate;
    begin
      select sum(t4.point_balance)
        into vsumpointbalance
        from point_acct_bala t4
       where (t4.pay_point_acct_id = pointaccount.point_account_id)
         and t4.status_cd = '10'
         and t4.expire_date <= sysdate;
      vpointacctbalacount      := 0;
      v_carryover_point        := 0;
      v_point_acct_chng_rec_id := 0;
      for pointacctbala in pointacctbalalist loop
        select floor(ceil((sysdate - pointacctbala.expire_date)) / 365)
          into vyearcount
          from dual;
        if vyearcount > 0 then
          declare
            --积分规则明细的记录数
            vpointruledetailcount number(12);
            --周转比例
            vpercentage number(12, 2);
            --积分帐户变更记录的记录数
            vpointacctchngreccount  number(12);
            field_name              varchar2(2000);
            field_value             varchar2(2000);
            temp_sql                varchar2(2000);
            vpoint_acct_chng_rec_id number(12);
            cursor pointruleconditionlist is
              select t6.*, t8.attr_name, t8.attr_cd, t8.is_dany_attr
                from point_rule t, point_rule_conditon t6, attr_spec t8
               where t.rule_id = t6.rule_id
                 and t.rule_type = ruletype
                 and t.status_cd = '10'
                 and t6.status_cd = '10'
                 and t6.attr_id = t8.attr_id;
          begin
            for pointrulecondition in pointruleconditionlist loop
              if pointrulecondition.is_dany_attr = 0 then
                temp_sql    := '';
                field_name  := '';
                field_value := '';
                temp_sql    := 'SELECT ' || pointrulecondition.attr_cd ||
                               ' FROM CUST WHERE CUST_ID =' ||
                               pointaccount.cust_id;
                field_name  := pointrulecondition.attr_cd;
                execute immediate temp_sql
                  into field_value;
                dbms_output.put_line('field_value=' || field_value ||
                                     ';field_name=' || field_name);
                --2011-07-01 判断"积分规则适用条件"属性取值是否与动态sql一致
                if pointrulecondition.attr_value = field_value then
                  --根据过期年数及规则类型查找积分规则明细的记录数
                  select count(t2.param_a)
                    into vpointruledetailcount
                    from point_rule_detail t2
                   where t2.rule_id in
                         (select t.rule_id
                            from point_rule t, point_rule_conditon t6
                           where t.rule_type = ruletype
                             and t.rule_id = t6.rule_id
                             and t6.attr_value in (field_value))
                     and t2.detail_item = vyearcount;
                  if vpointruledetailcount > 0 then
                    select t2.param_a / 100
                      into vpercentage
                      from point_rule_detail t2
                     where t2.rule_id in
                           (select t.rule_id
                              from point_rule t, point_rule_conditon t6
                             where t.rule_type = ruletype
                               and t.rule_id = t6.rule_id
                               and t6.attr_value in (field_value))
                       and t2.detail_item = vyearcount;

                    if vpointacctbalacount <= 0 then
                      select seq_point_acct_chng_rec_id.nextval
                        into v_point_acct_chng_rec_id
                        from dual;
                      insert into point_acct_chng_rec
                        (point_acct_chng_rec_id,
                         point_account_id,
                         point_service_rec_id,
                         service_date,
                         status_cd,
                         status_date,
                         change_action,
                         create_date,
                         update_date,
                         ext_serial_nbr,
                         area_id,
                         region_cd,
                         update_staff,
                         create_staff)
                      values
                        (v_point_acct_chng_rec_id,
                         pointaccount.point_account_id,
                         null,
                         sysdate,
                         '10',
                         sysdate,
                         '18',
                         sysdate,
                         sysdate,
                         '自动结转',
                         pointaccount.area_id,
                         pointaccount.region_cd,
                         pointaccount.update_staff,
                         pointaccount.create_staff);
                    end if;
                    select point_acct_chng_rec_id
                      into vpoint_acct_chng_rec_id
                      from point_acct_chng_rec t5
                     where t5.change_action = '18'
                       and t5.status_cd = '10'
                       and t5.point_account_id =
                           pointaccount.point_account_id
                       and rownum < 2;
                    insert into point_acct_bala_chng_rec
                      (point_acct_bala_chng_rec_id,
                       point_acct_bala_id,
                       point_acct_chng_rec_id,
                       point_change,
                       oper_date,
                       point_change_action,
                       create_date,
                       status_cd,
                       status_date,
                       update_date,
                       area_id,
                       region_cd,
                       update_staff,
                       create_staff)
                    values
                      (seq_point_acct_bala_rec_id.nextval,
                       pointacctbala.point_acct_bala_id,
                       vpoint_acct_chng_rec_id,
                       pointacctbala.point_balance * vpercentage,
                       sysdate,
                       '18',
                       sysdate,
                       '10',
                       sysdate,
                       sysdate,
                       pointaccount.area_id,
                       pointaccount.region_cd,
                       pointaccount.update_staff,
                       pointaccount.create_staff);
                    --根据周转比例调整积分账本的积分余额
                    update point_acct_bala t4
                       set t4.point_balance = t4.point_balance *
                                              (1 - vpercentage),
                           t4.expire_date   = sysdate
                     where t4.point_acct_bala_id =
                           pointacctbala.point_acct_bala_id;
                    v_carryover_point := v_carryover_point + pointacctbala.point_balance *
                                         vpercentage;
                    commit;
                  end if;
                end if;
              end if;
            end loop;
          end;
        end if;
        vpointacctbalacount := vpointacctbalacount + 1;
      end loop;
      if v_point_acct_chng_rec_id > 0 then
        update point_acct_chng_rec
           set change_value = v_carryover_point
         where point_acct_chng_rec_id = v_point_acct_chng_rec_id;
        commit;
      end if;
    end;
  end loop;
end automatic_carryover_points;
/
