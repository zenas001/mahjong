CREATE PROCEDURE           PROC_CREATE_ORDER(I_PROD_INST         IN NUMBER, --产品实例ID
                                              I_PROC_NAME         IN VARCHAR2, --存储过程名称
                                              I_PROC_DEAL_CONTENT IN VARCHAR2, --调用过程的作用
                                              I_REMARK            IN VARCHAR2, --备注，调用这个存储过程的原因
                                              I_STAFFF_CODE       IN VARCHAR2 --存储过程操作的工号
                                              ) IS
  V_CUST_SO_NUMBER     CUSTOMER_ORDER.CUST_SO_NUMBER%TYPE; --订单流水号
  V_CUST_ORDER_ID      CUSTOMER_ORDER.CUST_ORDER_ID%TYPE; --订单id
  V_PROD_ORDER_ITEM_ID ORDER_ITEM.ORDER_ITEM_ID%TYPE; --产品订单项id
  V_AREA_ID            PROD_INST.AREA_ID%TYPE;
  V_REGION_ID          PROD_INST.COMMON_REGION_ID%TYPE;
  V_OWNER_CUST_ID      PROD_INST.OWNER_CUST_ID%TYPE; --产品实例对象
  V_STAFF_ID           SYSTEM_USER.STAFF_ID%TYPE;
BEGIN
  --获取staff
  SELECT SU.STAFF_ID
    INTO V_STAFF_ID
    FROM SYSTEM_USER SU
   WHERE SU.STAFF_CODE = I_STAFFF_CODE
     AND SU.STATUS_CD = '1000'
     AND ROWNUM < 2;
  --获取产品实例
  select PI.OWNER_CUST_ID, PI.AREA_ID, PI.COMMON_REGION_ID
    INTO V_OWNER_CUST_ID, V_AREA_ID, V_REGION_ID
    from PROD_INST PI
   where PI.PROD_INST_ID = I_PROD_INST;
  --生成新的订单流水号
  SELECT 'FJ' || TO_CHAR(SYSDATE, 'YYYYMMDD') ||
         LPAD(TO_CHAR(SEQ_CUSTOMER_ORDER_SO_NUMBER.NEXTVAL), 8, '0')
    INTO V_CUST_SO_NUMBER
    FROM DUAL;
  --订单id
  SELECT SEQ_CUSTOMER_ORDER_ID.NEXTVAL INTO V_CUST_ORDER_ID FROM DUAL;
  --插订单
  INSERT INTO CUSTOMER_ORDER_HIS
    (CUST_ORDER_ID,
     CUSTOMER_INTERACTION_EVENT_ID,
     CHANNEL_ID,
     CUST_ID,
     STAFF_ID,
     CUST_SO_NUMBER,
     CUST_ORDER_TYPE,
     STATUS_CD,
     STATUS_DATE,
     PRE_HANDLE_FLAG,
     HANDLE_PEOPLE_NAME,
     PRIORITY,
     REASON,
     CREATE_DATE,
     UPDATE_DATE,
     ACCEPT_TIME,
     EXT_CUST_ORDER_ID,
     LAN_ID,
     REMARK,
     BOOK_TIME,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     HIS_ID,
     ORDER_FROM,
     DB_INST_ID,
     PROC_PRIORITY)
    SELECT V_CUST_ORDER_ID, --CUST_ORDER_ID,
           NULL, --CUSTOMER_INTERACTION_EVENT_ID,
           (SELECT C.CHANNEL_ID
              FROM CHANNEL C
             WHERE C.CHANNEL_NBR = '24939'
               AND ROWNUM = 1), --CHANNEL_ID,
           V_OWNER_CUST_ID, --CUST_ID,
           V_STAFF_ID, --STAFF_ID,
           V_CUST_SO_NUMBER, --CUST_SO_NUMBER,
           '101', --CUST_ORDER_TYPE,???
           '300000', --STATUS_CD,(300000: 竣工)
           SYSDATE, --STATUS_DATE,
           NULL, --PRE_HANDLE_FLAG,
           NULL, --HANDLE_PEOPLE_NAME,
           '100', --PRIORITY,
           NULL, --REASON,
           SYSDATE, --CREATE_DATE,
           SYSDATE, --UPDATE_DATE,
           SYSDATE, --ACCEPT_TIME,
           NULL, --EXT_CUST_ORDER_ID,
           NULL, --LAN_ID,
           '工号[' || I_STAFFF_CODE || ']在' || sysdate || '因' || I_REMARK ||
           '原因调用存储过程' || I_PROC_NAME || '.执行' || I_PROC_DEAL_CONTENT || '操作', --REMARK,
           NULL, --BOOK_TIME,
           V_AREA_ID, --AREA_ID,
           V_REGION_ID, --REGION_CD,
           V_STAFF_ID, --UPDATE_STAFF,
           V_STAFF_ID, --CREATE_STAFF,
           SEQ_CUSTOMER_ORDER_HIS_ID.NEXTVAL, --HIS_ID,
           '24939', --ORDER_FROM,
           NULL, --DB_INST_ID,
           NULL --PROC_PRIORITY,
      FROM DUAL;

  --插产品订单项
  SELECT SEQ_ORDER_ITEM_ID.NEXTVAL INTO V_PROD_ORDER_ITEM_ID FROM DUAL;
  INSERT INTO ORDER_ITEM_HIS
    (ORDER_ITEM_ID,
     CUST_ORDER_ID,
     ORDER_ITEM_CD,
     CUST_WORKSHEET_ID,
     STATUS_CD,
     STATUS_DATE,
     STATUS_CHANGE_REASON,
     PRIORITY,
     PRE_HANDLE_FLAG,
     HANDLE_TIME,
     ARCHIVE_DATE,
     FINISH_TIME,
     ORDER_ITEM_OBJ_ID,
     INSTALL_TIME_SEGMENT_ID,
     BEGIN_TIME_SEGMENT_ID,
     SERVICE_OFFER_ID,
     CREATE_DATE,
     UPDATE_DATE,
     REASON,
     EXT_ORDER_ITEM_ID,
     LAN_ID,
     CLASS_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     HIS_ID,
     ORDER_CLASS_ID,
     DB_INST_ID,
     PF_PROCESS_FLAG,
     PROC_PRIORITY)
    SELECT V_PROD_ORDER_ITEM_ID, --ORDER_ITEM_ID,
           V_CUST_ORDER_ID, --CUST_ORDER_ID,
           '1300', --ORDER_ITEM_CD,(1300: 产品订单项)
           NULL, --CUST_WORKSHEET_ID,
           '300000', --STATUS_CD,(300000: 竣工)
           SYSDATE, --STATUS_DATE,
           NULL, --STATUS_CHANGE_REASON,
           NULL, --PRIORITY,
           NULL, --PRE_HANDLE_FLAG,
           NULL, --HANDLE_TIME,
           SYSDATE, --ARCHIVE_DATE,
           SYSDATE, --FINISH_TIME,
           I_PROD_INST, --ORDER_ITEM_OBJ_ID,
           NULL, --INSTALL_TIME_SEGMENT_ID,
           NULL, --BEGIN_TIME_SEGMENT_ID,
           24, --SERVICE_OFFER_ID,
           SYSDATE, --CREATE_DATE,
           SYSDATE, --UPDATE_DATE,
           NULL, --REASON,
           NULL, --EXT_ORDER_ITEM_ID,
           NULL, --LAN_ID,
           4, --CLASS_ID,
           V_AREA_ID, --AREA_ID,
           V_REGION_ID, --REGION_CD,
           V_STAFF_ID, --UPDATE_STAFF,
           V_STAFF_ID, --CREATE_STAFF,
           SEQ_ORDER_ITEM_HIS_ID.NEXTVAL, --HIS_ID,
           NULL, --ORDER_CLASS_ID,
           NULL, --DB_INST_ID,
           NULL, --PF_PROCESS_FLAG,
           NULL --PROC_PRIORITY,
      FROM DUAL;


  insert into crmv2.Order_Item_Proc_Attr_His
    (ORDER_ITEM_PROC_ATTR_ID,
     ORDER_ITEM_ID,
     CLASS_ID,
     OBJ_INST_ID,
     OBJ_ATTR,
     OPERATE,
     NEW_VALUE,
     OLD_VALUE,
     STATUS,
     CREATE_DATE,
     STATUS_DATE,
     REMARK,
     OBJ_ATTR_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     HIS_ID,
     UPDATE_DATE,
     DB_INST_ID,
     VERSION)
    select crmv2.seq_order_item_proc_attr_id.nextval,
           V_PROD_ORDER_ITEM_ID,
           4,
           I_PROD_INST,
           'remark',
           10,
           '工号[' || I_STAFFF_CODE || ']在' || sysdate || '因' || I_REMARK ||
           '原因调用存储过程' || I_PROC_NAME || '.执行' || I_PROC_DEAL_CONTENT || '操作',
           null,
           1000,
           sysdate,
           sysdate,
           null,
           800015094,
           V_AREA_ID,
           V_REGION_ID,
           V_STAFF_ID,
           V_STAFF_ID,
           crmv2.seq_or_item_proc_attr_his_id.nextval,
           sysdate,
           null,
           null
       from dual;
END;
/
