CREATE PROCEDURE           PROC_UPDATE_CUST_ASSIGN_REL IS
  /**
  *陈明乾 2012-06-01
  用于同步客户经理
  **/
  V_CNT               NUMERIC(12) := 0;
  V_IS_NEW            VARCHAR2(10) := '0';
  V_END_DATE          VARCHAR2(20) := '';
  V_I                 NUMBER(10) := 0;
  V_STAFF_ID          NUMERIC(12) := 0;
  V_PARTY_NAME        VARCHAR2(250) := '';
  V_CHANNEL_MEMBER_ID NUMERIC(12) := 0;
  V_ROW_TYPE          CHANNEL_MEMBER%ROWTYPE;
  V_ERROR_INFO        CLOB;
  V_NOW               DATE := SYSDATE;
  I_CHANNEL_MEMBER_ID NUMBER(12) :=0;
  I_CUST_ASSIGN_REL_ID NUMBER(12) :=0;
  I_CHANNEL_MEMBER_HIS_ID NUMBER(12) :=0;
  /**
  **添加条件约束 AREA_CODE
  **AUTHOR: WANGY
  **DESC :只获取福州地区的相关数据 福州：951
  **DATE :2012-06-14
  **/
  --20121114  FANGJ改造，过滤STATE为1的数据，
  --  0   CRM未取走
  --  1   CRM提取成功
  --  -1  CRM提取失败

BEGIN
  BEGIN
    SELECT COUNT(1), NVL(IS_NEW, '0'), NVL(END_DATE, '0')
      INTO V_CNT, V_IS_NEW, V_END_DATE
     /*20160518 测试需要先注释
      FROM CMS_INTER_STATUS@LK_FJ_CMS*/
     FROM CMS_INTER_STATUS
     WHERE INT_NAME = 'INTF_ZQYK_CUST'
       AND AREA_CODE = '590'
     GROUP BY IS_NEW, END_DATE; --开关590表示取全省的数据
    INSERT INTO PROC_LOG
      (TABLE_NAME, COLUMN_NAME, V_SESSION, INSERT_DATE, OBJ_ID)
    VALUES
      ('政企客户经理信息同步开始', V_END_DATE, '开关状态:' || V_IS_NEW || '周期:' ||
        V_END_DATE || '同步开始', SYSDATE, 'CUST_ASSIGN_INFO_TEMP');
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  IF V_IS_NEW = '1' THEN
    --将临时表记录移至2表
    INSERT INTO CUST_ASSIGN_INFO_TEMP2
      (CUST_ID, CRM_STAFF_ID, STAFF_ID, MODIFY_TYPE, END_DATE)
      (SELECT CUST_ID, CRM_STAFF_ID, STAFF_ID, MODIFY_TYPE, V_END_DATE
         FROM CUST_ASSIGN_INFO_TEMP);
    EXECUTE IMMEDIATE 'TRUNCATE TABLE CUST_ASSIGN_INFO_TEMP';
    BEGIN
      --将远程数据先取到临时表中
      INSERT INTO CUST_ASSIGN_INFO_TEMP
        (CUST_ID, CRM_STAFF_ID, STAFF_ID, MODIFY_TYPE)
        SELECT CUST_ID, B.CRM_STAFF_ID, A.STAFF_ID, MODIFY_TYPE
        /*20160518 测试需要 先注释
          FROM INTF_ZQYK_CUST@LK_FJ_CMS        A,
               INTF_CMS_STAFF_EXTEND@LK_FJ_CMS B */
         FROM INTF_ZQYK_CUST       A,
               INTF_CMS_STAFF_EXTEND B
         WHERE A.STAFF_ID = B.STAFF_ID(+)
           AND A.STATE <> '1';
      --MOD 20121114  将客经平台接口表记录状态更新为已取走
       /*20160518 测试需要 先注释
      UPDATE INTF_ZQYK_CUST@LK_FJ_CMS AA
         SET AA.STATE = 1, AA.MODIFY_DATE = SYSDATE
       WHERE AA.CUST_ID IN (SELECT CUST_ID
                              FROM INTF_ZQYK_CUST@LK_FJ_CMS        A,
                                   INTF_CMS_STAFF_EXTEND@LK_FJ_CMS B
                             WHERE A.STAFF_ID = B.STAFF_ID(+)
                              AND A.STATE <> '1'); */
       UPDATE INTF_ZQYK_CUST AA
         SET AA.STATE = 1, AA.MODIFY_DATE = SYSDATE
       WHERE AA.CUST_ID IN (SELECT CUST_ID
                              FROM INTF_ZQYK_CUST       A,
                                   INTF_CMS_STAFF_EXTEND B
                             WHERE A.STAFF_ID = B.STAFF_ID(+)
                              AND A.STATE <> '1');

      INSERT INTO PROC_LOG
        (TABLE_NAME, COLUMN_NAME, V_SESSION, INSERT_DATE, OBJ_ID)
      VALUES
        ('CUST_ASSIGN_INFO_TEMP', 'CRM获取更新记录成功', V_ERROR_INFO, SYSDATE, 'CUST_ASSIGN_INFO_TEMP');
    EXCEPTION
      WHEN OTHERS THEN
        V_ERROR_INFO := SQLERRM;
        INSERT INTO PROC_LOG
          (TABLE_NAME, COLUMN_NAME, V_SESSION, INSERT_DATE, OBJ_ID)
        VALUES
          ('CUST_ASSIGN_INFO_TEMP', 'CUST_ASSIGN_INFO_TEMP', V_ERROR_INFO, SYSDATE, 'CUST_ASSIGN_INFO_TEMP');
        COMMIT;
        ROLLBACK;
    END;
    FOR REC IN (SELECT CUST_ID, CRM_STAFF_ID, STAFF_ID, MODIFY_TYPE
                  FROM CUST_ASSIGN_INFO_TEMP) LOOP
      V_I := V_I + 1;
      BEGIN
        V_CNT := 0;
        IF REC.CRM_STAFF_ID IS NOT NULL THEN
          SELECT COUNT(1)
            INTO V_CNT
            FROM SYSTEM_USER A
           WHERE A.STAFF_CODE = REC.CRM_STAFF_ID;
          IF V_CNT > 0 THEN
            SELECT A.STAFF_ID, C.PARTY_NAME
              INTO V_STAFF_ID, V_PARTY_NAME
              FROM SYSTEM_USER A, STAFF B, PARTY C
             WHERE A.STAFF_CODE = REC.CRM_STAFF_ID
               AND B.STAFF_ID = A.STAFF_ID
               AND B.PARTY_ID = C.PARTY_ID
               /*edit by liumq for crm00079259 过滤失效的工号*/
               AND A.STATUS_CD != '1100'
               AND B.STATUS_CD != '1100'
               AND C.STATUS_CD = '1000'
               AND ROWNUM < 2;
          ELSE
            /**刘壮飞确认 CRM根据STAFF_CODE找不到对应的则就直接保存CRM_STAFF_ID**/
            V_STAFF_ID   := 0;
            V_PARTY_NAME := REC.CRM_STAFF_ID;
          END IF;
        ELSE
          /**刘壮飞确认 如果找不到CRM对应的STAFF_CODE则就保存VIP的STAFF_ID**/
          V_STAFF_ID   := 0;
          V_PARTY_NAME := REC.STAFF_ID;
        END IF;
        /**
        新增
        **/
        /**
        **AUTHOR: suqj
        **DESC :单号:crm00062351
        **不管客经送什么动作，CRM判断是否已经有客户经理数据，如果存在则更新，不存在则新增。
        **DATE :2015-05-25
        **/
        /*IF REC.MODIFY_TYPE = 'A' THEN
          INSERT INTO CHANNEL_MEMBER
            (CHANNEL_MEMBER_ID, STAFF_ID, CHANNEL_MEMBER_NAME, MEMBER_TYPE_CD, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
          VALUES
            (SEQ_CHANNEL_MEMBER_ID.NEXTVAL, V_STAFF_ID, V_PARTY_NAME, 99, NULL, NULL, 1000, V_NOW, V_NOW, 0, V_NOW, 0);
          INSERT INTO CUST_ASSIGN_REL
            (CUST_ASSIGN_REL_ID, CHN_ORG_UNIT_ID, CUST_ID, CHANNEL_MEMBER_ID, RELATIONSHIP_TYPE_CD, RESPONSIBILITY_TYPE_CD, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
          VALUES
            (SEQ_CUST_ASSIGN_REL_ID.NEXTVAL, -100, REC.CUST_ID, SEQ_CHANNEL_MEMBER_ID.CURRVAL, 10, 12, NULL, NULL, 1000, V_NOW, V_NOW, 0, V_NOW, 0);
        END IF;*/
        /**
        修改
        **/
        /*IF REC.MODIFY_TYPE = 'U' THEN*/
          V_CNT := 0;
          SELECT COUNT(1)
            INTO V_CNT
            FROM CUST_ASSIGN_REL A
           WHERE A.CUST_ID = REC.CUST_ID;
          /**
          如果找不到记录也认为是新增
          **/
          IF V_CNT < 1 THEN
            SELECT SEQ_CHANNEL_MEMBER_ID.NEXTVAL INTO I_CHANNEL_MEMBER_ID FROM DUAL;
            SELECT SEQ_CUST_ASSIGN_REL_ID.NEXTVAL INTO I_CUST_ASSIGN_REL_ID FROM DUAL;
            INSERT INTO CHANNEL_MEMBER
              (CHANNEL_MEMBER_ID, STAFF_ID, CHANNEL_MEMBER_NAME, MEMBER_TYPE_CD, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
            VALUES
              (I_CHANNEL_MEMBER_ID, V_STAFF_ID, V_PARTY_NAME, 99, NULL, NULL, 1000, V_NOW, V_NOW, 0, V_NOW, 0);
            V_CHANNEL_MEMBER_ID := SEQ_CHANNEL_MEMBER_ID.CURRVAL;
            INSERT INTO CUST_ASSIGN_REL
              (CUST_ASSIGN_REL_ID, CHN_ORG_UNIT_ID, CUST_ID, CHANNEL_MEMBER_ID, RELATIONSHIP_TYPE_CD, RESPONSIBILITY_TYPE_CD, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
            VALUES
              (I_CUST_ASSIGN_REL_ID, -100, REC.CUST_ID, I_CHANNEL_MEMBER_ID, 10, 12, NULL, NULL, 1000, V_NOW, V_NOW, 0, V_NOW, 0);
       /* BASEJ.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CHANNEL_MEMBER',
                                                                         'CHANNEL_MEMBER_ID',
                                                                         I_CHANNEL_MEMBER_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '51447',
                                                                         '590');
        BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CUST_ASSIGN_REL',
                                                                         'CUST_ASSIGN_REL_ID',
                                                                         I_CUST_ASSIGN_REL_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '51447',
                                                                         '590');  */
        PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CHANNEL_MEMBER',
                                                                         'CHANNEL_MEMBER_ID',
                                                                         I_CHANNEL_MEMBER_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '51447',
                                                                         '590');
        PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CUST_ASSIGN_REL',
                                                                         'CUST_ASSIGN_REL_ID',
                                                                         I_CUST_ASSIGN_REL_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入',
                                                                         '51447',
                                                                         '590');
         ELSE
            SELECT A.CHANNEL_MEMBER_ID
              INTO V_CHANNEL_MEMBER_ID
              FROM CUST_ASSIGN_REL A
             WHERE A.CUST_ID = REC.CUST_ID
               AND ROWNUM < 2;
            /**修改   先把记录保存到历史表**/
            SELECT A.*
              INTO V_ROW_TYPE
              FROM CHANNEL_MEMBER A
             WHERE A.CHANNEL_MEMBER_ID = V_CHANNEL_MEMBER_ID
               AND ROWNUM < 2;
               SELECT SEQ_CHANNEL_MEMBER_HIS_ID.NEXTVAL INTO I_CHANNEL_MEMBER_HIS_ID FROM DUAL ;
            INSERT INTO CHANNEL_MEMBER_HIS
              (CHANNEL_MEMBER_ID, STAFF_ID, CHANNEL_MEMBER_NAME, MEMBER_TYPE_CD, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF, HIS_ID)
            VALUES
              (V_ROW_TYPE.CHANNEL_MEMBER_ID, V_ROW_TYPE.STAFF_ID, V_ROW_TYPE.CHANNEL_MEMBER_NAME, V_ROW_TYPE.MEMBER_TYPE_CD, V_ROW_TYPE.AREA_ID, V_ROW_TYPE.REGION_CD, V_ROW_TYPE.STATUS_CD, V_ROW_TYPE.STATUS_DATE, V_ROW_TYPE.CREATE_DATE, V_ROW_TYPE.CREATE_STAFF, SYSDATE, V_ROW_TYPE.UPDATE_STAFF, I_CHANNEL_MEMBER_HIS_ID);
            UPDATE CHANNEL_MEMBER A
               SET A.STAFF_ID            = V_STAFF_ID,
                   A.CHANNEL_MEMBER_NAME = V_PARTY_NAME,
                   A.UPDATE_DATE         = V_NOW
             WHERE A.CHANNEL_MEMBER_ID = V_CHANNEL_MEMBER_ID;
       /*       BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CHANNEL_MEMBER',
                                                                         'CHANNEL_MEMBER_ID',
                                                                         V_CHANNEL_MEMBER_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 更新',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 更新',
                                                                         '51447',
                                                                         '590');
             BASEJK.PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE@LK_CRM2INTF('CHANNEL_MEMBER_HIS',
                                                                         'HIS_ID',
                                                                         I_CHANNEL_MEMBER_HIS_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入历史',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入历史',
                                                                         '51447',
                                                                         '590'); */
           PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CHANNEL_MEMBER',
                                                                         'CHANNEL_MEMBER_ID',
                                                                         V_CHANNEL_MEMBER_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 更新',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 更新',
                                                                         '51447',
                                                                         '590');
           /*PKG_COMMON.PROC_INTF_INS_BILLING_UPDATE('CHANNEL_MEMBER_HIS',
                                                                         'HIS_ID',
                                                                         I_CHANNEL_MEMBER_HIS_ID,
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入历史',
                                                                         '1002',
                                                                         'PROC_UPDATE_CUST_ASSIGN_REL 插入历史',
                                                                         '51447',
                                                                         '590');    */
  ds_ins_intf_ins_ds_update_wh('CHANNEL_MEMBER_HIS','HIS_ID',I_CHANNEL_MEMBER_HIS_ID,
      'PROC_UPDATE_CUST_ASSIGN_REL 插入历史','51447','CREATE','');
          END IF;
        /*END IF;*/
      EXCEPTION
        WHEN OTHERS THEN
          V_ERROR_INFO := SQLERRM;
          INSERT INTO PROC_LOG
            (TABLE_NAME, COLUMN_NAME, V_SESSION, INSERT_DATE, OBJ_ID)
          VALUES
            ('CUST_ASSIGN_REL', 'CUST_ID', V_ERROR_INFO, SYSDATE, REC.CUST_ID);
          COMMIT;
          ROLLBACK;
      END;
      IF V_I > 100 THEN
        V_I := 0;
        COMMIT;
      END IF;
    END LOOP;
    /*20160518 测试需要先注释
    UPDATE CMS_INTER_STATUS@LK_FJ_CMS*/
    UPDATE CMS_INTER_STATUS
       SET IS_NEW = 0, MODI_DATE = SYSDATE
     WHERE INT_NAME = 'INTF_ZQYK_CUST'
       AND IS_NEW = 1
       AND AREA_CODE = '590'; --区域约束
    COMMIT;
  END IF;
  INSERT INTO PROC_LOG
    (TABLE_NAME, COLUMN_NAME, V_SESSION, INSERT_DATE, OBJ_ID)
  VALUES
    ('政企客户经理信息同步结束', V_END_DATE, '开关状态:' || V_IS_NEW || '周期:' || V_END_DATE ||
      '同步结束', SYSDATE, 'CUST_ASSIGN_INFO_TEMP');
  COMMIT;
END PROC_UPDATE_CUST_ASSIGN_REL;
/
