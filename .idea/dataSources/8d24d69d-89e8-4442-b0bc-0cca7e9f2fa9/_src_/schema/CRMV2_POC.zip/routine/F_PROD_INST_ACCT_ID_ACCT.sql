CREATE FUNCTION           f_prod_inst_acct_id_acct(in_prod_inst_acct_id IN NUMBER,
                                                    in_status_date       IN DATE)
  RETURN NUMBER IS
  out_account_id NUMBER;
BEGIN
  BEGIN
    SELECT account_id
      INTO out_account_id
      FROM prod_inst_acct a
     WHERE prod_inst_acct_id = in_prod_inst_acct_id;
  EXCEPTION
    WHEN no_data_found THEN
      BEGIN
        SELECT account_id
          INTO out_account_id
          FROM prod_inst_acct_his a
         WHERE prod_inst_acct_id = in_prod_inst_acct_id
           AND in_status_date >= status_date
           AND in_status_date < rec_update_date
           AND rownum = 1;
      EXCEPTION
        WHEN no_data_found THEN
          SELECT account_id
            INTO out_account_id
            FROM prod_inst_acct_his a
           WHERE prod_inst_acct_id = in_prod_inst_acct_id
             AND in_status_date < rec_update_date
             AND rownum = 1;
      END;
  END;
  RETURN out_account_id;
END;
/
