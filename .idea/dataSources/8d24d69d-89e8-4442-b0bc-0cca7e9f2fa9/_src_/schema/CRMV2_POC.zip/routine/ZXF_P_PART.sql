CREATE PROCEDURE           zxf_p_part(str_msg out VARCHAR2) is
--可选群组类角色上适用销售品
    v_cnt                     number; --查询数
    v_remark                  varchar2(2000); --备注
    v_oldofferprodrelaid      number; --旧的销售品产品关联ID
    v_oprrocount              number; --插入产品实例关联销售品约束数
    v_alloprrocount           number; --插入产品实例关联销售品约束总数据
    v_oprcount                number; --插入销售品关联约束数
    v_alloprcount             number; --插入销售品关联约束总数据
    v_prodofferrelaid         number; --可选关系关联Id
    v_oldkxbofferprodrelaid   number; --旧的可选群组类销售品与产品的关联关系Id
    v_oldkxbofferprodrelaname varchar2(200); --旧的可选群组类销售品与产品的关联名称
    v_porcount                number; --插入的可选包销售品约束数
    v_allporcount             number; --插入的可选包销售品约束总数
    v_infoname                varchar2(200); --名称
  begin
    v_alloprrocount         := 0;
    v_alloprcount           := 0;
    v_allporcount           := 0;
    v_oldofferprodrelaid    := 0;
    v_prodofferrelaid       := 0;
    v_oldkxbofferprodrelaid := 0;
    /*查询1.0组合类在2.0落地为可选群组类销售品.
      1.角色包上的套餐落地为套餐销售品的数据。根据角色查询
      2.合并上原组合类角色包上适用销售品在1.0落为基础销售品的数据。也根据角色查询
    */
    FOR PreferOfferRelaOffer IN (select po.prod_offer_id        prod_offer_id,
                                        po.prod_offer_name      prod_offer_name,
                                        opr.offer_prod_rela_id  offer_prod_rela_id,
                                        p.product_id            product_id,
                                        p.product_name          product_name,
                                        b.rela_id               rela_id,
                                        b.name                  name,
                                        oprr.role_cd            role_cd,
                                        oprr.role_name          role_name,
                                        f.prod_offer_id         rela_prod_offer_id,
                                        f.prod_offer_name       rela_prod_offer_name,
                                        opr2.offer_prod_rela_id rela_offer_prod_rela_id
                                   from prefer_price_spec@lk_crmv1           pps,
                                        mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                                        prod_offer                           po,
                                        offer_prod_rel                       opr,
                                        Offer_Prod_Rel_Role                  oprr,
                                        product                              p,
                                        prod_map_zhengcl                     pmz,
                                        PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 a,
                                        PREFER_MDSE_SPEC_RELA@lk_crmv1       b,
                                        PM_SPECIAL_MDSE_SPEC@lk_crmv1        c,
                                        mdse_spec@lk_crmv1                   d,
                                        mdse_ys_lisy_new                     e, ---取新的规格映射表（modify by lisy）
                                        prod_offer                           f,
                                        offer_prod_rel                       opr2
                                  where pps.prefer_spec_id = myx.id_v1
                                    and myx.id_v2 = po.prod_offer_id
                                    and po.offer_type = '12'
                                    and po.offer_sub_type = 'T05'
                                    and opr.prod_offer_id = po.prod_offer_id
                                    and opr.rule_type != '13'
                                    and opr.product_id = p.product_id
                                    and oprr.prod_offer_id =
                                        po.prod_offer_id
                                    and oprr.role_cd = opr.role_cd
                                    and oprr.role_name = b.name --增加1.0与2.0的角色包一致
                                    and b.prefer_spec_id =
                                        pps.Prefer_Spec_Id
                                    and a.CFG_AREA_ID in (1, 2)
                                    AND a.RELA_MDSE_ID = b.rela_id
                                    and b.rela_id = c.role_id
                                    and c.mdse_spec_id = d.mdse_spec_id
                                    and pmz.product_id = p.product_id
                                    and d.prod_spec_id = pmz.prod_spec_id --1.0产品规格
                                    and a.price_id = e.id_v1
                                    and e.id_v2 = f.prod_offer_id
                                    and f.offer_type = '11'
                                    and f.status_cd<>'1100'
                                    and opr2.prod_offer_id = f.prod_offer_id
                                    and opr2.product_id = p.product_id
                                    and opr2.rule_type != '13'
                                 union
                                 select po.prod_offer_id        prod_offer_id,
                                        po.prod_offer_name      prod_offer_name,
                                        opr.offer_prod_rela_id  offer_prod_rela_id,
                                        p.product_id            product_id,
                                        p.product_name          product_name,
                                        b.rela_id               rela_id,
                                        b.name                  name,
                                        oprr.role_cd            role_cd,
                                        oprr.role_name          role_name,
                                        f.prod_offer_id         rela_prod_offer_id,
                                        f.prod_offer_name       rela_prod_offer_name,
                                        opr2.offer_prod_rela_id rela_offer_prod_rela_id
                                   from prefer_price_spec@lk_crmv1     pps,
                                        mdse_ys_lisy_new               myx, ---取新的规格映射表（modify by lisy）
                                        prod_offer                     po,
                                        offer_prod_rel                 opr,
                                        Offer_Prod_Rel_Role            oprr,
                                        product                        p,
                                        prod_map_zhengcl               pmz,
                                        PREFER_MDSE_SPEC_RELA@lk_crmv1 b,
                                        PM_SPECIAL_MDSE_SPEC@lk_crmv1  c,
                                        mdse_spec@lk_crmv1             d,
                                        mdse_ys_lisy_new               e, ---取新的规格映射表（modify by lisy）
                                        prod_offer                     f,
                                        offer_prod_rel                 opr2
                                  where pps.prefer_spec_id = myx.id_v1
                                    and myx.id_v2 = po.prod_offer_id
                                    and po.offer_type = '12'
                                    and po.offer_sub_type = 'T05'
                                    and opr.prod_offer_id = po.prod_offer_id
                                    and opr.rule_type != '13'
                                    and opr.product_id = p.product_id
                                    and oprr.prod_offer_id =
                                        po.prod_offer_id
                                    and oprr.role_cd = opr.role_cd
                                    and oprr.role_name = b.name --增加1.0与2.0的角色包一致
                                    and b.prefer_spec_id =
                                        pps.Prefer_Spec_Id
                                    and b.rela_id = c.role_id
                                    and c.mdse_spec_id = d.mdse_spec_id
                                    and pmz.product_id = p.product_id
                                    and d.prod_spec_id = pmz.prod_spec_id --1.0产品规格
                                    and d.mdse_spec_id = e.id_v1
                                    and e.id_v2 = f.prod_offer_id
                                    and f.offer_type = '10'
                                    and f.offer_sub_type = 'T01'
                                    and f.status_cd<>'1100'
                                    and opr2.prod_offer_id = f.prod_offer_id
                                    and opr2.product_id = p.product_id
                                    and opr2.rule_type != '13'
                                  order by prod_offer_id,
                                           product_id,
                                           offer_prod_rela_id,
                                           rela_prod_offer_id) LOOP
      /*
      --导入数据日志记录
      if v_oldofferprodrelaid = 0 or
         (v_oldofferprodrelaid > 0 and
         v_oldofferprodrelaid != PreferOfferRelaOffer.offer_prod_rela_id) then
        if v_oldofferprodrelaid > 0 and v_oprrocount > 0 then
          select o.prod_offer_name || ',' || p.product_name
            into v_infoname
            from offer_prod_rel r, prod_offer o, product p
           where r.offer_prod_rela_id = v_oldofferprodrelaid
             and r.prod_offer_id = o.prod_offer_id
             and r.product_id = p.product_id;
          v_remark := '1.0角色上适用套餐,导入' || v_infoname || '产品实例关联的销售品约束表';
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'OFFER_PROD_RESTRICT_RELA_OFFER',
             v_oldofferprodrelaid,
             'OFFER_PROD_RELA_ID',
             'p_roleInOfferProdRestRelaOffer',
             SYSDATE,
             v_oprrocount,
             v_remark);
        end if;
        v_oldofferprodrelaid := PreferOfferRelaOffer.offer_prod_rela_id;
        v_oprrocount         := 0;
      end if;
      --是否2.0已经有配置销售品产品关系上产品实例关联销售品约束.没配才插入数据
      select count(*)
        into v_cnt
        from Offer_Prod_Restrict_Rela_Offer
       WHERE OFFER_PROD_RELA_ID = PreferOfferRelaOffer.offer_prod_rela_id
         and rela_offer_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id;
      if v_cnt = 0 then
        insert into OFFER_PROD_RESTRICT_RELA_OFFER
          (RESTRICT_ID,
           OFFER_PROD_RELA_ID,
           RESTRICT_TYPE,
           RELA_OFFER_ID,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF)
        values
          (SEQ_OPR_RELA_OFFER_ID.Nextval,
           PreferOfferRelaOffer.offer_prod_rela_id,
           '10',
           PreferOfferRelaOffer.Rela_Prod_Offer_Id,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           1,
           1,
           49822,
           49822);
        v_alloprrocount := v_alloprrocount + 1;
        v_oprrocount    := v_oprrocount + 1;
      end if;
      */
      /*查询角色包上的适用套餐，落地为可选包的数据。要跟以上2.0套餐销售品以及基础销售品都要建立可选关系
        如果在1.0中该适用套餐只适用于该角色包，要另外再加上“可选包销售品约束”
      */
      v_oprcount := 0;
      FOR KxbProdOffer IN (select pmrsr.rela_mdse_id,
                                  pmrsr.price_id,
                                  po.prod_offer_id,
                                  po.prod_offer_name
                             from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pmrsr,
                                  mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                                  prod_offer                           po
                            where pmrsr.CFG_AREA_ID in (1, 2)
                              and pmrsr.rela_mdse_id =
                                  PreferOfferRelaOffer.Rela_Id --1.0的角色包
                              and pmrsr.price_id = myx.id_v1
                              and myx.id_v2 = po.prod_offer_id
                              and po.offer_type = '12'
                              and po.offer_sub_type = 'T04') LOOP
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
           and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          select SEQ_PROD_OFFER_REL_ID.nextval
            into v_prodofferrelaid
            from dual;
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (v_prodofferrelaid,
             PreferOfferRelaOffer.Rela_Prod_Offer_Id,
             KxbProdOffer.Prod_Offer_Id,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             1,
             1,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_oprcount    := v_oprcount + 1;
          v_alloprcount := v_alloprcount + 1;
        elsif v_cnt = 1 then
          select por.prod_offer_rela_id
            into v_prodofferrelaid
            from prod_offer_rel por
           where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
             and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
             and por.relation_type_cd = '100000';
        else
          v_prodofferrelaid := 0;
        end if;
        if v_prodofferrelaid > 0 then
          --判断可选包是否只能在角色上受理
          select count(*)
            into v_cnt
            from prefer_mdse_price_spec_rela@lk_crmv1
           where price_id = KxbProdOffer.Prod_Offer_Id
             and mdse_spec_id > 0
             and rela_mdse_id = -1
             and state = '70A'
             and cfg_area_id in (1, 2);
          if v_cnt = 0 then
            --角色可选包与产品关联关系 作为可选包销售品约束的日志记录
            if v_oldkxbofferprodrelaid = 0 or
               (v_oldkxbofferprodrelaid > 0 and
               v_oldkxbofferprodrelaid !=
               PreferOfferRelaOffer.Offer_Prod_Rela_Id) then
              if v_oldkxbofferprodrelaid > 0 and v_porcount > 0 then
                v_remark := '1.0角色上适用套餐,导入作为Z端"' ||
                            v_oldkxbofferprodrelaname || '"的可选包销售品约束';
                insert into CRM1_CFG_SYNC
                  (ID,
                   TABLE_NAME,
                   OBJ_ID,
                   OBJ_TYPE,
                   SYNC_METHO,
                   SYNC_DATE,
                   SYNC_COUNT,
                   REMARK)
                values
                  (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                   'PROD_OFFER_REL_RESTRICT',
                   v_oldkxbofferprodrelaid,
                   'OFFER_PROD_REL_ID_Z',
                   'p_roleInOfferProdRestRelaOffer',
                   SYSDATE,
                   v_porcount,
                   v_remark);
              end if;
              v_oldkxbofferprodrelaid   := PreferOfferRelaOffer.Offer_Prod_Rela_Id;
              v_oldkxbofferprodrelaname := PreferOfferRelaOffer.prod_offer_name || '关联' ||
                                           PreferOfferRelaOffer.Product_Name;
              v_porcount                := 0;
            end if;
            select count(*)
              into v_cnt
              from PROD_OFFER_REL_RESTRICT porr
             where porr.prod_offer_rel_id = v_prodofferrelaid
               and porr.offer_prod_rel_id_a =
                   PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id
               and porr.offer_prod_rel_id_z =
                   PreferOfferRelaOffer.Offer_Prod_Rela_Id
               and porr.rule_type = '10';
            if v_cnt = 0 then
              insert into PROD_OFFER_REL_RESTRICT
                (PROD_OFFER_REL_RESTRICT_ID,
                 PROD_OFFER_REL_ID,
                 OFFER_PROD_REL_ID_A,
                 OFFER_PROD_REL_ID_Z,
                 CREATE_DATE,
                 AREA_ID,
                 REGION_CD,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_STAFF,
                 UPDATE_DATE,
                 UPDATE_STAFF,
                 RULE_TYPE)
              values
                (SEQ_PROD_OFFER_REL_RESTRICT_ID.Nextval,
                 v_prodofferrelaid,
                 PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id,
                 PreferOfferRelaOffer.Offer_Prod_Rela_Id,
                 sysdate,
                 2,
                 11,
                 '1000',
                 sysdate,
                 49822,
                 sysdate,
                 49822,
                 '10');
              v_porcount    := v_porcount + 1;
              v_allporcount := v_allporcount + 1;
            end if;
          end if;
        end if;
      END LOOP;
      --记录可选包可选关系日志
      if v_oprcount > 0 then
        v_remark := '1.0角色上适用套餐,导入' ||
                    PreferOfferRelaOffer.Rela_Prod_Offer_Name ||
                    '建立与原角色包上适用套餐的可选包的可选关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           PreferOfferRelaOffer.Rela_Prod_Offer_Id,
           'OFFER_A_ID',
           'p_roleInOfferProdRestRelaOffer',
           SYSDATE,
           v_oprcount,
           v_remark);
      end if;
    END LOOP;
    if v_oldofferprodrelaid > 0 and v_oprrocount > 0 then
      select o.prod_offer_name || ',' || p.product_name
        into v_infoname
        from offer_prod_rel r, prod_offer o, product p
       where r.offer_prod_rela_id = v_oldofferprodrelaid
         and r.prod_offer_id = o.prod_offer_id
         and r.product_id = p.product_id;
      v_remark := '1.0角色上适用套餐,导入' || v_infoname || '产品实例关联的销售品约束表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'OFFER_PROD_RESTRICT_RELA_OFFER',
         v_oldofferprodrelaid,
         'OFFER_PROD_RELA_ID',
         'p_roleInOfferProdRestRelaOffer',
         SYSDATE,
         v_oprrocount,
         v_remark);
    end if;
    if v_oldkxbofferprodrelaid > 0 and v_porcount > 0 then
      v_remark := '1.0角色上适用套餐,导入作为Z端"' || v_oldkxbofferprodrelaname ||
                  '"的可选包销售品约束';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL_RESTRICT',
         v_oldkxbofferprodrelaid,
         'OFFER_PROD_REL_ID_Z',
         'p_roleInOfferProdRestRelaOffer',
         SYSDATE,
         v_porcount,
         v_remark);
    end if;
    str_msg := '导入OFFER_PROD_RESTRICT_RELA_OFFER表"' ||
               to_char(v_alloprrocount) || '"条数据;导入PROD_OFFER_REL表"' ||
               to_char(v_alloprcount) || '"条数据;导入PROD_OFFER_REL_RESTRICT表"' ||
               to_char(v_allporcount) || '"条数据;';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_roleInOfferProdRestRelaOffer:' || sqlerrm;
  end;
/
