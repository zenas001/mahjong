CREATE PROCEDURE           p_cancel_order_70E(v_package_group in varchar2,
                                         IN_MODI_STAFF  IN VARCHAR2,
                                         O_RESULT       OUT VARCHAR2)
                                         is
v_ext_cust_order_id varchar2(100);
v_order_package_rel_id varchar2(100);
v_count1 number(10);
begin
  select c.ext_cust_order_id,t.intf_dep_order_package_rel_id into v_ext_cust_order_id , v_order_package_rel_id
    from crmv2.intf_dep_order c,crmv2.intf_dep_order_package_rel t where t.intf_dep_order_id=c.intf_dep_order_id
   and c.package_group = v_package_group;
   ------判断是否已有异常记录
  Select Count(1)
    into v_count1
    From (select v.intf_dep_finish_id
            from crmv2.intf_dep_finish v
           where v.ext_cust_order_id = v_ext_cust_order_id
          union all
          select intf_dep_finish_id
            from crmv2.intf_dep_finish_his v
           where v.ext_cust_order_id = v_ext_cust_order_id)  ;

     select count(1)
       into v_count1
       from crmv2.intf_dep_finish v
      where v.ext_cust_order_id = v_ext_cust_order_id and v.status_cd='400000';
     ----已有异常记录，则重写
    if v_count1=0  then
                begin
                ----------解析报文，获取订单组id
                    delete from ffpany.购物车流水号_3;
                    insert into ffpany.购物车流水号_3
                    select  1 num1,crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',1) ORDER_ITEM_GROUP from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id
                    union all
                    select 2 num1, crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',2) ORDER_ITEM_GROUP from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id
                    union all
                    select 3 num1, crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',3) ORDER_ITEM_GROUP from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id
                    union all
                    select 4 num1, crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',4) from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id
                    union all
                    select 5 num1, crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',5) from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id
                    union all
                    select 6 num1, crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',6) from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id
                    union all
                    select 7 num1, crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',7) from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id
                    union all
                    select 8 num1, crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(c.data_info, 'ORDER_ITEM_GROUP',8) from crmv2.intf_dep_data_info c where c.intf_dep_order_package_rel_id =v_order_package_rel_id;

                    begin
                    delete from ffpany.购物车流水号_4;
                    for M_ in(
                      select  * from ffpany.购物车流水号_3  where ORDER_ITEM_GROUP is not null
                    )loop
                      insert into ffpany.购物车流水号_4
                      select crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(ORDER_ITEM_GROUP,
                                                                       'ORDER_ITEM_GROUP_ID',
                                                                       1) ORDER_ITEM_GROUP_ID,
                             crmv2.pkg_clob_to_str.CLOB_TO_STR_SINGLE1(ORDER_ITEM_GROUP,
                                                                       'GROUP_TYPE',
                                                                       1) GROUP_TYPE
                        from ffpany.购物车流水号_3
                       where num1 = M_.num1;
                    end loop;
                    end;
                exception when others then null;
                end;

        insert into crmv2.intf_dep_finish
        select crmv2.seq_intf_dep_finish_id.nextval,a.package_group,a.ext_cust_order_id,'','',b.order_item_group_id ,b.group_type  ,'',a.channel_nbr,sysdate,'70B','',sysdate,sysdate,'1',sysdate,'',IN_MODI_STAFF||'-撤销过程-pany','400000'
        from crmv2.intf_dep_order a,ffpany.购物车流水号_4 b where b.group_type in ('4000','5000','6000') and a.ext_cust_order_id=v_ext_cust_order_id;

        else
          update crmv2.intf_dep_finish v set v.state='70B',v.status_cd='400000' where v.ext_cust_order_id = v_ext_cust_order_id and v.state='70A' ;

        end if;

      exception
        when others then
          o_result := '处理异常！';
          RETURN;
end;
/
