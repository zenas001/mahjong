CREATE function           ppm_fnc_create_window(vwin_id number,vclass_id number,vsub_class_id number, vtemp_name varchar2,v_area_id number,t_inst_class_id number) return number
as
	old_win tmp_ppm_sys_window%rowtype;
	new_win_id number;
	new_win_comp_id number;
	new_attr_id number;
	old_attr_id number;
	cursor mycur is  select * from tmp_ppm_sys_win_componet sc where sc.win_id = vwin_id and sc.parent_componet_id is null;
begin
-- 获取新窗体ID
select seq_sys_window_id.nextval into new_win_id from dual;
-- 获取旧模板数据
select * into old_win from tmp_ppm_sys_window t where t.win_id = vwin_id;
-- 创建窗体
insert into sys_window(WIN_ID ,WIN_CODE,WIN_NAME,WIN_HINT,WIN_DESC,WIN_EXPR,WIN_ARGS,CLASS_ID,STATUS_CD ,STATUS_DATE ,CREATE_DATE ,UPDATE_DATE ,WIN_ZUL ,ROOT_COMPONET ,WIN_URL ,AREA_ID ,REGION_CD ,UPDATE_STAFF,CREATE_STAFF,REMARK)
values(new_win_id,vclass_id||'-'||vsub_class_id||'-100WIN',vclass_id||'-'||vsub_class_id||'-新装',vtemp_name,vtemp_name,old_win.WIN_EXPR,old_win.WIN_ARGS,old_win.CLASS_ID,old_win.STATUS_CD ,old_win.STATUS_DATE ,old_win.CREATE_DATE ,old_win.UPDATE_DATE ,old_win.WIN_ZUL ,old_win.ROOT_COMPONET ,old_win.WIN_URL ,v_area_id ,v_area_id ,old_win.UPDATE_STAFF,old_win.CREATE_STAFF,old_win.REMARK);

-- 创建组件
for r in mycur loop
-- 创建组件
select seq_sys_win_componet_id.nextval into new_win_comp_id from dual;
begin
 select y.attr_id into new_attr_id from attr_spec y where y.class_id = t_inst_class_id and y.java_code = r.componet_code and rownum=1 ;
exception
	when others then
	new_attr_id := -1;
end;

insert into sys_win_componet(componet_id,attr_id ,win_id,parent_componet_id ,componet_code,componet_name,compone_thint,componet_desc,is_display,display_expr ,display_wight,display_height ,display_style,read_only ,display_order,is_newline,positionx ,positiony ,bind_expr ,status_cd ,status_date,create_date,update_date,componet_type,param1,param2,componet_catalog ,area_id ,region_cd ,update_staff ,create_staff ,class_id,proc_default ,remark)
values( new_win_comp_id,new_attr_id ,new_win_id,null ,r.componet_code,r.componet_name,r.compone_thint,r.componet_desc,r.is_display,r.display_expr ,r.display_wight,r.display_height ,r.display_style,r.read_only ,r.display_order,r.is_newline,r.positionx ,r.positiony ,r.bind_expr ,r.status_cd ,r.status_date,r.create_date,r.update_date,r.componet_type,r.param1,r.param2,r.componet_catalog ,v_area_id ,v_area_id ,r.update_staff ,r.create_staff ,r.class_id,r.proc_default ,r.remark);
-- 创建子组件
ppm_proc_create_sub_comp(vwin_id,r.componet_id,new_win_id,new_win_comp_id,t_inst_class_id,v_area_id);
end loop;
return new_win_id;
end;
/
