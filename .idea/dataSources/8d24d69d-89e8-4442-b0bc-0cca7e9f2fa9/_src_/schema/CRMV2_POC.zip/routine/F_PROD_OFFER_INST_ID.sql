CREATE FUNCTION           f_prod_offer_inst_id(in_prod_offer_inst_id IN NUMBER,
                                in_status_date        IN DATE) RETURN NUMBER IS
    out_cust_id NUMBER;
  BEGIN
    BEGIN
      SELECT cust_id
        INTO out_cust_id
        FROM prod_offer_inst
       WHERE prod_offer_inst_id = in_prod_offer_inst_id;
    EXCEPTION
      WHEN no_data_found THEN
        BEGIN
          SELECT cust_id
            INTO out_cust_id
            FROM prod_offer_inst_his
           WHERE prod_offer_inst_id = in_prod_offer_inst_id
             AND in_status_date >= status_date
             AND in_status_date < rec_update_date
             AND rownum = 1;
        EXCEPTION
          WHEN no_data_found THEN
            SELECT cust_id
              INTO out_cust_id
              FROM prod_offer_inst_his
             WHERE prod_offer_inst_id = in_prod_offer_inst_id
               AND in_status_date < rec_update_date
               AND rownum = 1;
        END;
    END;
    RETURN out_cust_id;
  END;
/
