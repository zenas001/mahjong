CREATE function           fnc_has_region_right(i_prod_offer_id in number, --销售品ID
                                                i_my_area_id    in number, --登录工号AREA_ID
                                                i_my_region_cd  in number --登录工号REGION_CD
                                                ) return integer is
  --1：有权，0：无权
  v_cnt integer;
begin
  select count(1)
    into v_cnt
    from prod_offer_region a
   where a.prod_offer_id = i_prod_offer_id
     and a.status_cd = '1000';
  if v_cnt = 0 then
    return 1;
  end if;
  select count(1)
    into v_cnt
    from prod_offer_region a
   where a.prod_offer_id = i_prod_offer_id
     and a.status_cd = '1000'
     and (a.common_region_id = i_my_area_id or
         a.common_region_id = i_my_region_cd);
  if v_cnt > 0 then
    return 1;
  end if;
  return 0;
end fnc_has_region_right;
/
