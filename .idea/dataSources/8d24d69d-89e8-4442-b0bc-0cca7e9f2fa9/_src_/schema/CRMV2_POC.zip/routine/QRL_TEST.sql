CREATE procedure           QRL_TEST  is
  v_prod_offer_inst_attr_id number(12);
  v_attr_value_id number(12);
  v_attr_value varchar2(4000);
  cursor c is
  select * from itsc_crmv2.INC_201208156107
   WHERE ROWNUM < 3;
begin
  for rec in c loop
    v_prod_offer_inst_attr_id := 0;
    v_attr_value_id := 0;
    v_attr_value := ' ';
    select nvl(prod_offer_inst_attr_id,0) into v_prod_offer_inst_attr_id
      from crmv2.prod_offer_inst_attr
     where prod_offer_inst_id = rec.prod_offer_inst_id
       and attr_id = 800011258;

    if v_prod_offer_inst_attr_id = 0 then
      select nvl(prod_offer_inst_attr_id,0) into v_prod_offer_inst_attr_id
        from crmv2.prod_offer_inst_attr_his
       where prod_offer_inst_id = rec.prod_offer_inst_id
         and attr_id = 800011258
         and rownum = 1;
    end if;

    select c.attr_value_id,c.attr_value
      into v_attr_value_id,v_attr_value
      from crmv2.prod_offer_inst a,crmv2.prod_offer_attr b,crmv2.attr_value c
     where a.prod_offer_id = b.prod_offer_id
       and a.prod_offer_inst_id =rec.prod_offer_inst_id
       and b.attr_id = c.attr_id
       and b.attr_id =  800011258
       and b.status_cd = 1000
       and b.default_value = c.attr_value;

    insert into crmv2.prod_offer_inst_attr_his
    (PROD_OFFER_INST_ATTR_ID,PROD_OFFER_INST_ID,ATTR_ID,ATTR_VALUE_ID,ATTR_VALUE,
     CREATE_DATE,EXP_DATE,EFF_DATE,STATUS_DATE,STATUS_CD,
     UPDATE_DATE,PROC_SERIAL,AREA_ID,REGION_CD,UPDATE_STAFF,
     CREATE_STAFF,HIS_ID,REC_UPDATE_DATE,VERSION)
    select v_prod_offer_inst_attr_id,rec.prod_offer_inst_id,800011258,v_attr_value_id,v_attr_value,
           CREATE_DATE,EXP_DATE,EFF_DATE,STATUS_DATE,STATUS_CD,
           UPDATE_DATE,PROC_SERIAL,AREA_ID,REGION_CD,UPDATE_STAFF,
           CREATE_STAFF,CRMV2.SEQ_PROD_OFFER_INST_ATTR_2_ID.NEXTVAL,REC_UPDATE_DATE,VERSION
      from CRMV2.PROD_OFFER_INST_ATTR_HIS
     where prod_offer_inst_id = rec.prod_offer_inst_id
       and status_date =  rec.status_date;

     INSERT INTO ITSC_CRMV2.INTF_INS_BILLING_UPDATE
      (INS_ID, TABLE_NAME, COLUMN_NAME, KEY_ID, TOPIC,
       TYPE, REASON, OPERATOR,STATE, CREATE_DATE,
       DEAL_NUM, AREA_NBR)
      VALUES( ITSC_CRMV2.SEQ_INTF_INS_BILLING_UPDATE_ID.NEXTVAL,
              'PROD_OFFER_INST_ATTR', 'PROD_OFFER_INST_ATTR_ID', v_prod_offer_inst_attr_id,'异常数据修复',
              '1003','INC_201208156107', 'FFQRL', '70A', SYSDATE,  0, '591') ;

  end loop;

end QRL_TEST;
/
