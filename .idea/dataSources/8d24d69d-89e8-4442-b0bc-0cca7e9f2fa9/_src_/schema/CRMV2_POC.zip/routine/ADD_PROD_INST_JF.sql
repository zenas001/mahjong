CREATE PROCEdure           add_prod_inst_jf(in_prodinst    in number,
                                             in_modi_reason in varchar2,
                                             in_modi_staff  in varchar2,
                                             o_id           out number,
                                             o_msg          out varchar2) IS
  v_fprodinst      number(10);
  v_fprodofferinst number(10);
  v_offerprodrela  number(10);
  v_prodinstrel    number(10);
BEGIN

  --建立产品表
  select crmv2.seq_prod_inst_id.nextval into v_fprodinst from dual;

  insert into crmv2.prod_inst
    (PROD_INST_ID,
     PRODUCT_ID,
     ACC_PROD_INST_ID,
     ADDRESS_ID,
     OWNER_CUST_ID,
     PAYMENT_MODE_CD,
     PRODUCT_PASSWORD,
     IMPORTANT_LEVEL,
     AREA_CODE,
     ACC_NBR,
     EXCH_ID,
     COMMON_REGION_ID,
     REMARK,
     PAY_CYCLE,
     BEGIN_RENT_TIME,
     STOP_RENT_TIME,
     FINISH_TIME,
     STOP_STATUS,
     STATUS_CD,
     CREATE_DATE,
     STATUS_DATE,
     UPDATE_DATE,
     PROC_SERIAL,
     USE_CUST_ID,
     EXT_PROD_INST_ID,
     ADDRESS_DESC,
     AREA_ID,
     UPDATE_STAFF,
     CREATE_STAFF,
     REC_UPDATE_DATE)
    select v_fprodinst,
           '901212221',
           prod_inst_id,
           '',
           owner_cust_id,
           '',
           '',
           '',
           area_code,
           '',
           '',
           common_region_id,
           in_modi_reason,
           PAY_CYCLE,
           sysdate,
           date '2199-01-01',
           sysdate,
           '',
           '100000',
           sysdate,
           sysdate,
           sysdate,
           '',
           use_cust_id,
           v_fprodinst,
           '',
           area_id,
           '',
           '',
           ''
      from crmv2.prod_inst pi
     where pi.prod_inst_id = in_prodinst;

  -- 新增产品和产品关系
  select crmv2.Seq_Prod_Inst_Rel_Id.nextval into v_prodinstrel from dual;

  insert into prod_inst_rel
    (PROD_INST_REL_ID,
     PROD_INST_A_ID,
     PROD_INST_Z_ID,
     RELATION_TYPE_CD,
     PROD_INST_REL_ROLE_ID,
     ROLE_CD,
     EFF_DATE,
     EXP_DATE,
     CREATE_DATE,
     STATUS_CD,
     STATUS_DATE,
     UPDATE_DATE,
     PROC_SERIAL,
     PRODUCT_REL_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     REC_UPDATE_DATE)
    select v_prodinstrel,
           in_prodinst,
           v_fprodinst,
           '100600',
           '',
           '',
           sysdate,
           date '2199-01-01',
           sysdate,
           '1000',
           sysdate,
           sysdate,
           '',
           '22535',
           pi.area_id,
           pi.common_region_id,
           '',
           '',
           ''
      from crmv2.prod_inst pi
     where pi.prod_inst_id = in_prodinst;

  select crmv2.seq_prod_offer_inst_id.nextval
    into v_fprodofferinst
    from dual;

  insert into crmv2.prod_offer_Inst poi
    (PROD_OFFER_INST_ID,
     PROD_OFFER_ID,
     CUST_ID,
     CHANNEL_ID,
     CREATE_DATE,
     STATUS_CD,
     STATUS_DATE,
     EFF_DATE,
     EXP_DATE,
     REGION,
     UPDATE_DATE,
     PROC_SERIAL,
     EXT_PROD_OFFER_INST_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     TRIAL_EFF_DATE,
     TRIAL_EXP_DATE,
     REC_UPDATE_DATE,
     SERVICE_NBR,
     END_AUTO,
     REMARK,
     WH_REMARK)
    select v_fprodofferinst,
           '901251563',
           pi.owner_cust_id,
           '',
           sysdate,
           '1000',
           sysdate,
           sysdate,
           date '2199-01-01',
           pi.common_region_id,
           sysdate,
           '',
           '',
           pi.area_id,
           pi.common_region_id,
           '',
           '',
           '',
           '',
           '',
           '',
           '',
           in_modi_reason,
           in_modi_reason
      from crmv2.prod_inst pi
     where pi.prod_inst_id = in_prodinst;

  --销售品产品关联
  select crmv2.seq_offer_prod_inst_rel_id.nextval
    into v_offerprodrela
    from dual;

  insert into crmv2.offer_prod_inst_rel
    (OFFER_PROD_INST_REL_ID,
     PROD_INST_ID,
     PROD_OFFER_INST_ID,
     ROLE_CD,
     OFFER_PROD_INST_REL_ROLE_ID,
     STATUS_CD,
     STATUS_DATE,
     CREATE_DATE,
     EFF_DATE,
     EXP_DATE,
     UPDATE_DATE,
     PROC_SERIAL,
     OFFER_PROD_REL_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     REC_UPDATE_DATE,
     EXT_FLAG)
    select v_offerprodrela,
           v_fprodinst,
           v_fprodofferinst,
           '',
           '',
           '1000',
           sysdate,
           sysdate,
           sysdate,
           date '2199-01-01',
           sysdate,
           '',
           '901251567',
           b.area_id,
           b.common_region_id,
           '',
           '',
           '',
           ''
      from crmv2.prod_Inst b
     where b.prod_inst_id = v_fprodinst;

  insert into crmv2.prod_inst_attr
  (PROD_INST_ATTR_ID,
PROD_INST_ID,
ATTR_ID,
ATTR_VALUE_ID,
ATTR_VALUE,
STATUS_CD,
STATUS_DATE,
EFF_DATE,
EXP_DATE,
CREATE_DATE,
UPDATE_DATE,
PROC_SERIAL,
AREA_ID,
REGION_CD,
UPDATE_STAFF,
CREATE_STAFF,
REC_UPDATE_DATE,
VERSION
)
select CRMV2.SEQ_PROD_INST_ATTR_ID.NEXTVAL,
       A.PROD_INST_ID,
       B.ATTR_ID,
       C.ATTR_VALUE_ID,
       C.ATTR_VALUE,
       '1000',
       SYSDATE,
       SYSDATE,
       date '2199-01-01',
       SYSDATE,
       SYSDATE,
       '',
       A.AREA_ID,
       A.COMMON_REGION_ID,
       '',
       '',
       '',
       '0'
  from CRMV2.prod_inst A, CRMV2.PRODUCT_ATTR B, ATTR_VALUE C
 where A.PRODUCT_ID = B.PRODUCT_ID
   AND B.ATTR_ID = C.ATTR_ID
   AND B.DEFAULT_VALUE = C.ATTR_VALUE
   AND prod_inst_id = v_fprodinst;
   COMMIT;
o_id := v_fprodinst;

  --上载计费
/*  itsc_crmv2.new_p_ins_billing_update('prod_Inst',
                                      'prod_inst_id',
                                      v_fprodinst,
                                      in_modi_reason,
                                      in_modi_staff);
  itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
                                      'prod_offer_inst_id',
                                      v_fprodofferinst,
                                      in_modi_reason,
                                      in_modi_staff);
  itsc_crmv2.new_p_ins_billing_update('prod_inst_rel',
                                      'prod_inst_rel_id',
                                      v_prodinstrel,
                                      in_modi_reason,
                                      in_modi_staff);
  itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
                                      'offer_prod_inst_rel_id',
                                      v_offerprodrela,
                                      in_modi_reason,
                                      in_modi_staff);*/

  o_msg := '添加成功';

END;
/
