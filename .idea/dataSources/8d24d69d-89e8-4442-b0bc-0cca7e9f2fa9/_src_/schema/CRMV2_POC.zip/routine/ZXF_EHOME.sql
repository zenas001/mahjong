CREATE PROCEDURE           zxf_EHOME(i_preferspecid in number)--1.0 e家销售品规格
is
  vcount number;
begin
 --添加e家小灵通基础包的可选包上关联的接入类产品
 for voffer in (select a.prod_offer_rela_id prod_offer_rela_id,
        c.offer_prod_rela_id offer_prod_rela_id
   from prod_offer_rel a,
        (select distinct po1.prod_offer_id e_prod_offer_id,
                         po1.prod_offer_name e_prod_offer_name,
                         po.prod_offer_id kxb_prod_offer_id,
                         po.prod_offer_name kxb_prod_offer_name,
                         800000003 product_id,
                          '小灵通' product_name
           from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                prefer_mdse_spec_rela@lk_crmv1       pmsr,
                mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                prod_offer                           po,
                mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                prod_offer                           po1
          where pmpsr.rela_mdse_id = pmsr.rela_id
            and pmsr.prefer_spec_id = i_preferspecid --1.0e家销售品id
            and pmsr.name in ('小灵通可选包','超无包')
            and pmpsr.cfg_area_id in (1, 2)
            and pmpsr.state = '70A'
            and myx.id_v1 = pmpsr.price_id
            and myx.id_v2 = po.prod_offer_id
            and po.offer_type = '12'
            and po.offer_sub_type = 'T04'
            and myx1.id_v1 = i_preferspecid --1.0e家销售品id
            and myx1.id_v2 = po1.prod_offer_id
            and po1.offer_type = '11'
            and po1.offer_sub_type = 'T01'
            and po.prod_offer_id not in (
             select distinct
                             po.prod_offer_id    KXB_PROD_OFFER_ID
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid
                         and pmsr.role_type = '001' --基础包
                         and pmpsr.cfg_area_id in (1, 2)
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type in ('12','13') --落地为可选包和促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                         and not exists
                       (select obj_id
                                from pm_extend_restrict@lk_crmv1 per
                               where per.restrict_type = '174'
                                 and per.obj_type = 'TCSPGL'
                                 and per.obj_id = pmpsr.rela_id))
          order by e_prod_offer_id, kxb_prod_offer_id) b,
        offer_prod_rel c
  where a.offer_a_id = b.e_prod_offer_id
    and a.offer_z_id = b.kxb_prod_offer_id
    and a.status_cd = '1000'
    and b.product_id = c.product_id
    and b.e_prod_offer_id = c.prod_offer_id
    and c.role_cd in (2943,2944)
    and c.status_cd = '1000') loop

    select count(*) into vcount from offer_rel_restrict_prod where offer_prod_rela_id=voffer.offer_prod_rela_id and prod_offer_rela_id=voffer.prod_offer_rela_id;
  if vcount=0 then
 insert into offer_rel_restrict_prod
 values
   (SEQ_OFFER_REL_RESTRICT_PROD_ID.NEXTVAL,
    voffer.offer_prod_rela_id,
    voffer.prod_offer_rela_id,
    null,
    16,
    sysdate,
    2,
    11,
    '1000',
    sysdate,
    49822,
    sysdate,
    49822,
    '12');
   end if;
    end loop;
    commit;
end zxf_EHOME;
/
