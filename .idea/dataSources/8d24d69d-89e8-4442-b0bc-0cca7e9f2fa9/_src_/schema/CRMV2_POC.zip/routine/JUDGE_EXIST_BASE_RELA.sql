CREATE PROCEDURE           JUDGE_EXIST_BASE_RELA(IN_PROD_INST_ID NUMBER,
                                                  IN_PRODUCT_ID NUMBER,
                                                  OUT_RET OUT NUMBER) IS
  I         NUMBER := 0;
  J         NUMBER := 0;
  P_PROD_ID NUMBER := 0;
  P_RELA_ID NUMBER := 0;
  P_SPEC_ID NUMBER := 0;
BEGIN
  /*
  判断传入的功能销售品，与同客户下，是否与E家存在构成关系,如果存在，返回基础销售品实例ID
  created by zhengzhh 2011-10-19
  */
  --1.判断规格层面是否构成关系(PARENT_RELA_ID不能为空)
  SELECT COUNT(1)
    INTO I
    FROM ZZH_BASE_OFFER_PROD_RELA ZE
   WHERE ZE.PRODUCT_ID = IN_PRODUCT_ID;
  IF I > 0 THEN
    --获取对应主产品实例ID
    SELECT PROD_INST_A_ID
      INTO P_PROD_ID
      FROM PROD_INST_REL
     WHERE STATUS_CD = '10'
       AND PROD_INST_Z_ID = IN_PROD_INST_ID;
    --2.判断对应的主产品实例，是否在基础销售品构成关系里
    SELECT COUNT(1)
      INTO J
      FROM ZZH_OFFER_PROD_INST_BASE
     WHERE PROD_INST_ID = P_PROD_ID;
    IF J > 0 THEN
      --存在关系，返回E家销售品ID,不存在返回0
      SELECT PROD_OFFER_INST_ID
        INTO OUT_RET
        FROM ZZH_OFFER_PROD_INST_BASE
       WHERE PROD_INST_ID = P_PROD_ID;
    ELSE
      OUT_RET := 0;
    END IF;
  ELSE
    OUT_RET := 0;
  END IF;
  --如果发生异常错误，返回-1
EXCEPTION
  WHEN OTHERS THEN
    NULL;
    OUT_RET := -1;
END JUDGE_EXIST_BASE_RELA;
/
