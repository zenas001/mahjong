CREATE PROCEDURE           roleInProdRelRestrictOffer_1(str_msg out VARCHAR2) is
  v_cnt             number; --查询数
  v_oldprodrelaId   number; --旧的群组类产品与原子产品的关联关系
  v_oldprodrelaId2  number; --旧的群组类产品与原子产品的关联关系
  v_restrictId      number; --产品关联销售品ID
  v_count           number; --插入数
  v_pallcount       number; --总数据
  v_oallcount       number; --总数据
  v_oldprodofferid  number; --旧的2.0销售品规格
  v_porcount        number; --插入prod_offer_rel数 帽子上的适用套餐
  v_porcount2       number; --插入prod_offer_rel数 其它角色包上的适用套餐
  v_allporcount     number; --插入prod_offer_rel总数
  v_orrpcount       number; --插入offer_Rel_Restrict_Prod数
  v_allorrpcount    number; --插入offer_Rel_Restrict_Prod总数
  v_prodofferrelaid number; --prod_offer_rel.rela_id
  v_infoname        varchar2(1000); --信息说明
  v_remark          varchar2(2000); --备注
  v_seqid           number; --seq取值
begin
  v_pallcount       := 0;
  v_oallcount       := 0;
  v_oldprodrelaId   := 0;
  v_oldprodofferid  := 0;
  v_allporcount     := 0;
  v_allorrpcount    := 0;
  v_prodofferrelaid := 0;
  v_porcount        := 0;
  v_oldprodrelaId2  := 0;
  v_orrpcount       := 0;
  /*查询1.0组合类在2.0落地为基础接入类销售品的数据
    1.角色包上的套餐落地为套餐销售品的数据。根据角色查询
    2.合并上原组合类角色包上适用销售品在1.0落为基础销售品的数据。也根据角色查询
  */
  FOR PreferOfferRelaOffer IN (select a.prefer_spec_id        prefer_spec_id,
                                      pmsr.rela_id            prefer_role_id,
                                      c.prod_offer_id         prod_offer_id,
                                      c.prod_offer_name       prod_offer_name,
                                      r.product_rel_id        product_rel_id,
                                      prr.role_name           role_name,
                                      p.product_id            product_a_id,
                                      p.product_name          product_a_name,
                                      pz.product_id           product_z_id,
                                      pz.product_name         product_z_name,
                                      po.prod_offer_id        rela_prod_offer_id,
                                      po.prod_offer_name      rela_prod_offer_name,
                                      opr2.offer_prod_rela_id rela_offer_prod_rela_id
                                 from prefer_price_spec@lk_crmv1           a,
                                      mdse_ys_lisy_new                     b, ---取新的规格隐射表（modify by lisy）
                                      prod_offer                           c,
                                      offer_prod_rel                       opr,
                                      product                              p,
                                      product_relation                     r,
                                      product_rel_role                     prr,
                                      product                              pz,
                                      prod_map_zhengcl                     pm,
                                      prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                                      PREFER_MDSE_SPEC_RELA@lk_crmv1       pmsr,
                                      PM_SPECIAL_MDSE_SPEC@lk_crmv1        psms,
                                      mdse_spec@lk_crmv1                   ms,
                                      mdse_ys_lisy_new                     myx, ---取新的规格隐射表（modify by lisy）
                                      prod_offer                           po,
                                      offer_prod_rel                       opr2
                                where a.prefer_spec_id = b.id_v1
                                  and b.id_v2 = c.prod_offer_id
                                  and c.offer_type = '10'
                                  and c.offer_sub_type = 'T01'
                                  and opr.prod_offer_id = c.Prod_Offer_Id
                                  and opr.rule_type != '13'
                                  and p.product_id = opr.product_id
                                  and p.product_type = '13'
                                  and opr.status_cd = '1000'
                                  and p.product_id = r.product_a_id
                                  and r.product_z_id = pz.product_id --2.0产品规格
                                  and r.relation_type_cd = '100300' --构成关系
                                  and prr.product_id = p.product_id
                                  and pmsr.name = prr.role_name
                                  and prr.role_cd = r.role_cd
                                  and pmsr.prefer_spec_id = a.prefer_spec_id
                                  and pmpsr.CFG_AREA_ID in (1, 2)
                                  AND pmpsr.RELA_MDSE_ID = pmsr.rela_id
                                  and pmsr.rela_id = psms.role_id
                                  and psms.mdse_spec_id = ms.mdse_spec_id
                                  and pm.product_id = pz.product_id
                                  and ms.prod_spec_id = pm.prod_spec_id --1.0产品规格
                                  and pmpsr.price_id = myx.id_v1
                                  and myx.id_v2 = po.prod_offer_id
                                  and po.offer_type = '11'
                                  and opr2.product_id = pz.product_id
                                  and opr2.prod_offer_id = po.prod_offer_id
                               union
                               select a.prefer_spec_id        prefer_spec_id,
                                      pmsr.rela_id            prefer_role_id,
                                      c.prod_offer_id         prod_offer_id,
                                      c.prod_offer_name       prod_offer_name,
                                      r.product_rel_id        product_rel_id,
                                      prr.role_name           role_name,
                                      p.product_id            product_a_id,
                                      p.product_name          product_a_name,
                                      pz.product_id           product_z_id,
                                      pz.product_name         product_z_name,
                                      po.prod_offer_id        rela_prod_offer_id,
                                      po.prod_offer_name      rela_prod_offer_name,
                                      opr2.offer_prod_rela_id rela_offer_prod_rela_id
                                 from prefer_price_spec@lk_crmv1     a,
                                      mdse_ys_lisy_new               b, ---取新的规格隐射表（modify by lisy）
                                      prod_offer                     c,
                                      offer_prod_rel                 opr,
                                      product                        p,
                                      product_relation               r,
                                      product_rel_role               prr,
                                      product                        pz,
                                      prod_map_zhengcl               pm,
                                      PREFER_MDSE_SPEC_RELA@lk_crmv1 pmsr,
                                      PM_SPECIAL_MDSE_SPEC@lk_crmv1  psms,
                                      mdse_spec@lk_crmv1             ms,
                                      mdse_ys_lisy_new               myx, ---取新的规格隐射表（modify by lisy）
                                      prod_offer                     po,
                                      offer_prod_rel                 opr2
                                where a.prefer_spec_id = b.id_v1
                                  and b.id_v2 = c.prod_offer_id
                                  and c.offer_type = '10'
                                  and c.offer_sub_type = 'T01'
                                  and opr.prod_offer_id = c.Prod_Offer_Id
                                  and opr.rule_type != '13'
                                  and p.product_id = opr.product_id
                                  and p.product_type = '13'
                                  and opr.status_cd = '1000'
                                  and p.product_id = r.product_a_id
                                  and r.product_z_id = pz.product_id --2.0产品规格
                                  and r.relation_type_cd = '100300' --构成关系
                                  and prr.product_id = p.product_id
                                  and pmsr.name = prr.role_name
                                  and prr.role_cd = r.role_cd
                                  and pmsr.prefer_spec_id = a.prefer_spec_id
                                  and pmsr.rela_id = psms.role_id
                                  and psms.mdse_spec_id = ms.mdse_spec_id
                                  and pm.product_id = pz.product_id
                                  and ms.prod_spec_id = pm.prod_spec_id --1.0产品规格
                                  and psms.mdse_spec_id = myx.id_v1
                                  and myx.id_v2 = po.prod_offer_id
                                  and po.offer_type = '10'
                                  and opr2.product_id = pz.product_id
                                  and opr2.prod_offer_id = po.prod_offer_id
                                order by prod_offer_id, product_z_id) LOOP
    --产品关联导入数据日志记录
    if v_oldprodrelaId = 0 or
       (v_oldprodrelaId > 0 and
       v_oldprodrelaId != PreferOfferRelaOffer.product_rel_id) then
      if v_oldprodrelaId > 0 and v_count > 0 then
        select p1.product_name || '与' || p2.product_name || '的' ||
               v.attr_value_name
          into v_infoname
          from product_relation r, product p1, product p2, attr_value v
         where v.attr_id = 7691
           and v.attr_value = r.relation_type_cd
           and r.product_rel_id = v_oldprodrelaId
           and r.product_a_id = p1.product_id
           and r.product_z_id = p2.product_id;
        v_remark := '1.0角色上适用套餐,导入"' || v_infoname || '"的产品关联销售品约束表';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_REL_RESTRICT_OFFER',
           v_oldprodrelaId,
           'PRODUCT_REL_ID',
           'p_roleInProdRelRestrictOffer',
           SYSDATE,
           v_count,
           v_remark);
      end if;
      v_oldprodrelaId := PreferOfferRelaOffer.product_rel_id;
      v_count         := 0;
    end if;
    --是否2.0已经有配置产品关系上限制销售品约束.没配才插入数据
    select count(*)
      into v_cnt
      from Prod_Rel_Restrict_Offer
     where product_rel_id = PreferOfferRelaOffer.product_rel_id
       and rela_offer_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id;
    if v_cnt = 0 then
      --插入PROD_REL_RESTRICT_OFFER
      select SEQ_PROD_REL_RESTRICT_OFFER_ID.nextval into v_seqid from dual;
      insert into PROD_REL_RESTRICT_OFFER
        (RESTRICT_ID,
         PRODUCT_REL_ID,
         RESTRICT_TYPE,
         RELA_OFFER_ID,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF)
      values
        (v_seqid,
         PreferOfferRelaOffer.product_rel_id,
         '10',
         PreferOfferRelaOffer.Rela_Prod_Offer_Id,
         '1000',
         sysdate,
         sysdate,
         sysdate,
         1,
         11,
         49822,
         49822);
      v_restrictId := v_seqid;
      v_pallcount  := v_pallcount + 1;
      v_count      := v_count + 1;
    elsif v_cnt = 1 then
      select RESTRICT_ID
        into v_restrictId
        from Prod_Rel_Restrict_Offer
       where product_rel_id = PreferOfferRelaOffer.product_rel_id
         and rela_offer_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id;
    end if;
    select count(*)
      into v_cnt
      from OBJ_REL_CFG
     where (OBJ_CLASS_ID = 0 or OBJ_CLASS_ID is null)
       and (OBJ_ID = 0 or OBJ_ID is null)
       and CFG_CLASS_ID = 64855
       and CFG_ID = v_restrictId;
    if v_cnt = 0 then
      --关联表OBJ_REL_CFG也要插入
      insert into OBJ_REL_CFG
        (OBJ_REL_CFG_ID,
         OBJ_CLASS_ID,
         OBJ_ID,
         CFG_CLASS_ID,
         CFG_ID,
         AREA_ID,
         REGION_CD,
         CREATE_DATE,
         CREATE_STAFF,
         STATUS_CD,
         STATUS_DATE,
         UPDATE_DATE,
         UPDATE_STAFF)
      values
        (seq_obj_rel_cfg_id.nextval,
         null,
         0,
         64855,
         v_seqid,
         1,
         11,
         sysdate,
         49822,
         '1000',
         sysdate,
         sysdate,
         49822);
      v_oallcount := v_oallcount + 1;
    end if;
    --查询帽子上的适用套餐,落地2.0为可选包的情况。之间建立可选关系
    if v_oldprodofferid = 0 or
       (v_oldprodofferid > 0 and
       v_oldprodofferid != PreferOfferRelaOffer.Prod_Offer_Id) then
      FOR MOFFER IN (SELECT distinct PO.PROD_OFFER_ID, PO.PROD_OFFER_NAME
                       FROM PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 PMPSR,
                            PREFER_MDSE_SPEC_RELA@lk_crmv1       PMSR,
                            MDSE_YS_LISY_NEW                     MYX, ---取新的规格隐射表（modify by lisy）
                            PROD_OFFER                           PO
                      WHERE PMPSR.rela_mdse_id = PMSR.RELA_ID
                        AND PMSR.ID_TYPE = '1'
                        AND PMPSR.CFG_AREA_ID IN (1, 2)
                        AND PMPSR.PRICE_ID = MYX.ID_V1
                        AND MYX.ID_V2 = PO.PROD_OFFER_ID
                        AND PO.OFFER_TYPE = '12'
                        AND PO.OFFER_SUB_TYPE = 'T04'
                        AND PMSR.prefer_spec_id =
                            PreferOfferRelaOffer.Prefer_Spec_Id) LOOP
        select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = PreferOfferRelaOffer.Prod_Offer_Id
           and por.offer_z_id = MOFFER.PROD_OFFER_ID
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_ID.nextval,
             PreferOfferRelaOffer.Prod_Offer_Id,
             MOFFER.PROD_OFFER_ID,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             1,
             1,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
          v_porcount    := v_porcount + 1;
          v_allporcount := v_allporcount + 1;
        end if;
      END LOOP;
      if v_porcount > 0 then
        v_remark := '1.0角色上适用套餐,导入"' ||
                    PreferOfferRelaOffer.Prod_offer_name || '"与可选包的可选关系';
        insert into CRM1_CFG_SYNC
          (ID,
           TABLE_NAME,
           OBJ_ID,
           OBJ_TYPE,
           SYNC_METHO,
           SYNC_DATE,
           SYNC_COUNT,
           REMARK)
        values
          (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
           'PROD_OFFER_REL',
           PreferOfferRelaOffer.Prod_Offer_Id,
           'OFFER_A_ID',
           'p_roleInProdRelRestrictOffer',
           SYSDATE,
           v_porcount,
           v_remark);
      end if;
      v_porcount       := 0;
      v_oldprodofferid := PreferOfferRelaOffer.Prod_Offer_Id;
    end if;
    /*其它角色包上的适用套餐 要与同角色的产品关系上的套餐销售品（基础销售品）配置可选关系
    如果这个可选包只能角色上受理，则要增加“可选包组合产品约束”*/
    v_porcount2 := 0;
    FOR KxbProdOffer IN (select pmrsr.rela_mdse_id,
                                pmrsr.price_id,
                                po.prod_offer_id,
                                po.prod_offer_name
                           from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pmrsr,
                                mdse_ys_lisy_new                     myx, ---取新的规格隐射表（modify by lisy）
                                prod_offer                           po
                          where pmrsr.CFG_AREA_ID in (1, 2)
                            and pmrsr.rela_mdse_id =
                                PreferOfferRelaOffer.Prefer_Role_Id --1.0的角色包
                            and pmrsr.price_id = myx.id_v1
                            and myx.id_v2 = po.prod_offer_id
                            and po.offer_type = '12'
                            and po.offer_sub_type = 'T04') LOOP
      select count(*)
        into v_cnt
        from prod_offer_rel por
       where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
         and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
         and por.relation_type_cd = '100000';
      if v_cnt = 0 then
        select SEQ_PROD_OFFER_REL_ID.nextval
          into v_prodofferrelaid
          from dual;
        insert into PROD_OFFER_REL
          (PROD_OFFER_RELA_ID,
           OFFER_A_ID,
           OFFER_Z_ID,
           ROLE_CD,
           RELATION_TYPE_CD,
           EFF_DATE,
           EXP_DATE,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           HOT_SPOT_NO,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           SYNC_CUST,
           EFFECTIVE_TYPE,
           DEFAULT_TIME_PERIOD,
           EXPIRE_TYPE,
           RULE_TYPE)
        values
          (v_prodofferrelaid,
           PreferOfferRelaOffer.Rela_Prod_Offer_Id,
           KxbProdOffer.Prod_Offer_Id,
           null,
           '100000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           null,
           null,
           1,
           1,
           49822,
           49822,
           null,
           null,
           null,
           null,
           null);
        v_porcount2   := v_porcount2 + 1;
        v_allporcount := v_allporcount + 1;
      elsif v_cnt = 1 then
        select por.prod_offer_rela_id
          into v_prodofferrelaid
          from prod_offer_rel por
         where por.offer_a_id = PreferOfferRelaOffer.Rela_Prod_Offer_Id
           and por.offer_z_id = KxbProdOffer.Prod_Offer_Id
           and por.relation_type_cd = '100000';
      else
        v_prodofferrelaid := 0;
      end if;
      if v_prodofferrelaid > 0 then
        --判断可选包是否只能在角色上受理
        select count(*)
          into v_cnt
          from prefer_mdse_price_spec_rela@lk_crmv1
         where price_id = KxbProdOffer.Prod_Offer_Id
           and mdse_spec_id > 0
           and rela_mdse_id = -1
           and state = '70A'
           and cfg_area_id in (1, 2);
        if v_cnt = 0 then
          --帽子与产品关联关系 作为可选包组合产品约束的日志记录
          if v_oldprodrelaId2 = 0 or
             (v_oldprodrelaId2 > 0 and
             v_oldprodrelaId2 != PreferOfferRelaOffer.product_rel_id) then
            if v_oldprodrelaId2 > 0 and v_orrpcount > 0 then
              select p1.product_name || '与' || p2.product_name || '的' ||
                     v.attr_value_name
                into v_infoname
                from product_relation r,
                     product          p1,
                     product          p2,
                     attr_value       v
               where v.attr_id = 7691
                 and v.attr_value = r.relation_type_cd
                 and r.product_rel_id = v_oldprodrelaId
                 and r.product_a_id = p1.product_id
                 and r.product_z_id = p2.product_id;
              v_remark := '1.0角色上适用套餐,导入"' || v_infoname || '"的可选包组合产品约束表';
              insert into CRM1_CFG_SYNC
                (ID,
                 TABLE_NAME,
                 OBJ_ID,
                 OBJ_TYPE,
                 SYNC_METHO,
                 SYNC_DATE,
                 SYNC_COUNT,
                 REMARK)
              values
                (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                 'OFFER_REL_RESTRICT_PROD',
                 v_oldprodrelaId2,
                 'PRODUCT_REL_ID',
                 'p_roleInProdRelRestrictOffer',
                 SYSDATE,
                 v_orrpcount,
                 v_remark);
            end if;
            v_oldprodrelaId2 := PreferOfferRelaOffer.product_rel_id;
            v_orrpcount      := 0;
          end if;
          select count(*)
            into v_cnt
            from OFFER_REL_RESTRICT_PROD orrp
           where orrp.prod_offer_rela_id = v_prodofferrelaid
             and orrp.product_rel_id = PreferOfferRelaOffer.Product_Rel_Id
             and orrp.offer_prod_rela_id =
                 PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id
             and orrp.conf_type = '10';
          if v_cnt = 0 then
            insert into OFFER_REL_RESTRICT_PROD
              (OFFER_REL_RESTRICT_PROD_ID,
               OFFER_PROD_RELA_ID,
               PROD_OFFER_RELA_ID,
               PRODUCT_REL_ID,
               RULE_TYPE,
               CREATE_DATE,
               AREA_ID,
               REGION_CD,
               STATUS_CD,
               STATUS_DATE,
               CREATE_STAFF,
               UPDATE_DATE,
               UPDATE_STAFF,
               CONF_TYPE)
            values
              (SEQ_OFFER_REL_RESTRICT_PROD_ID.Nextval,
               PreferOfferRelaOffer.Rela_Offer_Prod_Rela_Id,
               v_prodofferrelaid,
               PreferOfferRelaOffer.Product_Rel_Id,
               '10',
               sysdate,
               2,
               11,
               '1000',
               sysdate,
               49822,
               sysdate,
               49822,
               '10');
            v_orrpcount    := v_orrpcount + 1;
            v_allorrpcount := v_allorrpcount + 1;
          end if;
        end if;
      end if;
    END LOOP;
    --记录其它角色上的可选包可选关系日志
    if v_porcount2 > 0 then
      v_remark := '1.0角色上适用套餐,导入' ||
                  PreferOfferRelaOffer.Rela_Prod_Offer_Name ||
                  '建立与原角色包上适用套餐的可选包的可选关系';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_OFFER_REL',
         PreferOfferRelaOffer.Rela_Prod_Offer_Id,
         'OFFER_A_ID',
         'p_roleInProdRelRestrictOffer',
         SYSDATE,
         v_porcount2,
         v_remark);
    end if;
  END LOOP;
  if v_oldprodrelaId > 0 and v_count > 0 then
    select p1.product_name || '与' || p2.product_name || '的' ||
           v.attr_value_name
      into v_infoname
      from product_relation r, product p1, product p2, attr_value v
     where v.attr_id = 7691
       and v.attr_value = r.relation_type_cd
       and r.product_rel_id = v_oldprodrelaId
       and r.product_a_id = p1.product_id
       and r.product_z_id = p2.product_id;
    v_remark := '1.0角色上适用套餐,导入"' || v_infoname || '"的产品关联销售品约束表';
    insert into CRM1_CFG_SYNC
      (ID,
       TABLE_NAME,
       OBJ_ID,
       OBJ_TYPE,
       SYNC_METHO,
       SYNC_DATE,
       SYNC_COUNT,
       REMARK)
    values
      (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
       'PROD_REL_RESTRICT_OFFER',
       v_oldprodrelaId,
       'PRODUCT_REL_ID',
       'p_roleInProdRelRestrictOffer',
       SYSDATE,
       v_count,
       v_remark);
  end if;
  if v_oallcount > 0 then
    v_remark := '1.0角色上适用套餐,导入关联OBJ_REL_CFG数据OBJ_ID=0 AND CFG_CLASS_ID=64855';
    insert into CRM1_CFG_SYNC
      (ID,
       TABLE_NAME,
       OBJ_ID,
       OBJ_TYPE,
       SYNC_METHO,
       SYNC_DATE,
       SYNC_COUNT,
       REMARK)
    values
      (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
       'OBJ_REL_CFG',
       64855,
       'CFG_CLASS_ID',
       'p_roleInProdRelRestrictOffer',
       SYSDATE,
       v_oallcount,
       v_remark);
  end if;
  if v_oldprodrelaId2 > 0 and v_orrpcount > 0 then
    select p1.product_name || '与' || p2.product_name || '的' ||
           v.attr_value_name
      into v_infoname
      from product_relation r, product p1, product p2, attr_value v
     where v.attr_id = 7691
       and v.attr_value = r.relation_type_cd
       and r.product_rel_id = v_oldprodrelaId
       and r.product_a_id = p1.product_id
       and r.product_z_id = p2.product_id;
    v_remark := '1.0角色上适用套餐,导入"' || v_infoname || '"的可选包组合产品约束表';
    insert into CRM1_CFG_SYNC
      (ID,
       TABLE_NAME,
       OBJ_ID,
       OBJ_TYPE,
       SYNC_METHO,
       SYNC_DATE,
       SYNC_COUNT,
       REMARK)
    values
      (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
       'OFFER_REL_RESTRICT_PROD',
       v_oldprodrelaId2,
       'PRODUCT_REL_ID',
       'p_roleInProdRelRestrictOffer',
       SYSDATE,
       v_orrpcount,
       v_remark);
  end if;
  str_msg := '导入PROD_REL_RESTRICT_OFFER"' || to_char(v_pallcount) ||
             '"条数据;导入OBJ_REL_CFG"' || to_char(v_oallcount) ||
             '"条数据;导入PROD_OFFER_REL"' || to_char(v_allporcount) ||
             '"条数据;导入OFFER_REL_RESTRICT_PROD"' || to_char(v_allorrpcount) ||
             '"条数据';
EXCEPTION
  WHEN OTHERS THEN
    str_msg := 'p_roleInProdRelRestrictOffer:' || sqlerrm;
end;
/
