CREATE function           niud_f_ehome_tel_importer(i_prefer_spec_id in number,
                                                     o_msg            out varchar2)
  return number is

  /****
      功能：
          1.0组合套餐某些适用了e家电话的角色
          在2.0里的销售品产品关联约束上配置
          e家套餐销售品
      入参：
          i_prefer_spec_id - 1.0的规格ID
      出参：
          o_msg - 提示信息
      返回：
          处理的记录总数
                      by niud, 120524
  ****/

  v_remark varchar2(100) := 'imported via niud_f_ehome_tel_importer';
  v_tmp    number(6);
  v_cnt    number(6) := 0;

  cursor cur is
    select y.id_v2, opr.area_id, opr.offer_prod_rela_id
      from crm.prefer_price_spec@lk_crmv1     a1,
           crm.prefer_mdse_spec_rela@lk_crmv1 a2,
           crm.pm_special_mdse_spec@lk_crmv1  a3,
           crm.mdse_spec@lk_crmv1             a4,
           mdse_ys_lisy_new                   y,
           offer_prod_rel_role                o,
           offer_prod_rel                     opr
     where a1.prefer_spec_id = a2.prefer_spec_id
       and a2.rela_id = a3.role_id
       and a3.mdse_spec_id = a4.mdse_spec_id
       and a3.mdse_spec_id in (600261489) --e家“电话”
       and a1.state <> '70X'
       and a2.state = '70A'
       and a3.state = '70A'
       and a1.name not like '%e%'
       and a1.type = '105'
       and a1.prefer_spec_id = y.id_v1
       and o.prod_offer_id = y.id_v2
       and o.role_name = a2.name
       and opr.prod_offer_id = y.id_v2
       and opr.product_id = 800000000 --普通电话
       and opr.rule_type = 10 --可选关系
       and opr.role_cd = o.role_cd
       and a1.prefer_spec_id = i_prefer_spec_id
       and exists
     (select 1
              from offer_prod_restrict_rela_offer rro
             where opr.offer_prod_rela_id = rro.offer_prod_rela_id
               and rro.restrict_type = '10');

  cursor cur_e is
    select po.*
      from prefer_price_spec@lk_crmv1 pps,
           mdse_ys_lisy_new           y,
           prod_offer                 po
     where pps.prefer_spec_id = y.id_v1
       and y.id_v2 = po.prod_offer_id
       and po.offer_type = '11'
       and po.status_cd not like '11%'
       and exists
     (select 1
              from PREFER_MDSE_SPEC_RELA@lk_crmv1 pmsr
             where pps.prefer_spec_id = pmsr.prefer_spec_id
               and exists (select 1
                      from PM_SPECIAL_MDSE_SPEC@lk_crmv1 psms
                     where pmsr.rela_id = psms.role_id
                       and psms.mdse_spec_id = 600261489))
       and state = '70A'
       and type = '106';

begin
  for rec in cur loop
    for rec_e in cur_e loop
      select count(*)
        into v_tmp
        from offer_prod_restrict_rela_offer
       where offer_prod_rela_id = rec.offer_prod_rela_id
         and rela_offer_id = rec_e.prod_offer_id
         and restrict_type = '10';
      if v_tmp = 0 then
        insert into offer_prod_restrict_rela_offer
        values
          (seq_opr_rela_offer_id.nextval,
           rec.offer_prod_rela_id,
           '10',
           rec_e.prod_offer_id,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           rec.area_id,
           null,
           -1,
           -1,
           v_remark);
        v_cnt := v_cnt + 1;
      end if;
    end loop;
  end loop;
  o_msg := '加入' || v_cnt || '条记录。';
  return(v_cnt);
end;
/
