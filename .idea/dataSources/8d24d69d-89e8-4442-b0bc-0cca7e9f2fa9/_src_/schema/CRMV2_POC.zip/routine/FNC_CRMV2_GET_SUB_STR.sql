CREATE FUNCTION           fnc_crmv2_get_sub_str(str       in varchar2, --待分割的字符串
                                                 splitchar in varchar2 --分割标志
                                                 ) return t_varchar_table IS
  restStr  varchar2(2000) default str; --剩余的字符串
  thisStr  varchar2(18); --取得的当前字符串
  indexStr int; --临时存放分隔符在字符串中的位置
  v        t_varchar_table := t_varchar_table(); --返回结果
begin
  dbms_output.put_line(restStr);
  while length(restStr) != 0 LOOP
    <<top>>
    indexStr := instr(restStr, splitchar); --从子串中取分隔符的第一个位置
    if indexStr = 0 and length(restStr) != 0 then
      --在剩余的串中找不到分隔符
      begin
        v.extend;
        v(v.count) := Reststr;
        return v;
      end;
    end if;
    if indexStr = 1 then
      ---第一个字符便为分隔符,此时去掉分隔符
      begin
        restStr := substr(restStr, 2);
        goto top;
      end;
    end if;
    if length(restStr) = 0 or restStr is null then
      return v;
    end if;
    v.extend;
    thisStr := substr(restStr, 1, indexStr - 1); --取得当前的字符串
    restStr := substr(restStr, indexStr + 1); ---取剩余的字符串
    v(v.count) := thisStr;
  END LOOP;
  return v;
end;
/
