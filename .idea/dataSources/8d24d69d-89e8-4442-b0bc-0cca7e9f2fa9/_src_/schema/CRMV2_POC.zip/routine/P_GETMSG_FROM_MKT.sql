CREATE PROCEDURE           p_getmsg_from_mkt(i_mkt_campaign_id in number,
                                              i_mkt_work_sheet_id in number,
                                              o_result          OUT VARCHAR2) IS
BEGIN

  INSERT INTO intf_sms
    SELECT seq_intf_sms_id.NEXTVAL,
           c.event_cd,
           a.req_content,
           a.obj_id,
           '10000',
           '10000',
           a.area_id,
           a.region_cd,
           a.create_date,
           a.status_cd,
           a.status_date,
           a.create_staff,
           a.update_date,
           a.update_staff
      FROM mkt_intf_log_info a, mkt_work_sheet b, mkt_campaign c
     WHERE a.mkt_work_order_id = b.mkt_work_sheet_id
       AND b.mkt_campaign_id = c.mkt_campaign_id
       and b.mkt_campaign_id = i_mkt_campaign_id
       AND B.mkt_work_sheet_id =i_mkt_work_sheet_id
       AND a.status_cd = '10';

  UPDATE mkt_intf_log_info a
     SET a.status_cd = '12'
   WHERE a.status_cd = '10'
     and a.mkt_work_order_id=i_mkt_work_sheet_id;

  COMMIT;
END p_getmsg_from_mkt;
/
