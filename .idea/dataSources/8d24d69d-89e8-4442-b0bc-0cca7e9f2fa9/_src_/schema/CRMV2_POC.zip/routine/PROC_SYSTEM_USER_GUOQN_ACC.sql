CREATE procedure           proc_system_user_guoqn_acc is

  cursor i_q is
    select * from SYSTEM_USER where ROWNUM=0;
  /**
   功能说明：修改员工的失效时间到了就自动将状态变成1100
   author：guoqn
   创建时间：2013-7-11
  **/
begin
  declare
 cursor aa is
select distinct C.*
  from  staff a, system_user c,party p,party_certification pc
 where a.staff_id=c.staff_id
   and p.party_id=a.party_id
   and p.party_id=pc.party_id
   and c.status_cd='1000'
   and a.status_cd='1000'
   and c.user_exp_date<sysdate+1;

begin
  for rec in aa loop
INSERT INTO GUO_SYSTEM_USER_USER_STATUSCD
select * from system_user where system_user_id=rec.system_user_id;
update system_user s set s.status_cd='1100',s.update_date=sysdate where s.system_user_id =rec.system_user_id;
update staff a set a.status_cd='1100',a.update_date=sysdate where a.staff_id =(select c.staff_id from system_user c where c.system_user_id =rec.system_user_id);
update party p set p.status_cd='1100',p.update_date=sysdate where p.party_id = (select s.party_id from staff s where s.staff_id=(select c.staff_id from system_user c where c.system_user_id =rec.system_user_id));
update party_certification pc set pc.status_cd = '1100',pc.update_date=sysdate where pc.party_id = (select s.party_id from staff s where s.staff_id=(select c.staff_id from system_user c where c.system_user_id =rec.system_user_id));
commit;
  end loop;
  COMMIT;
end;
end;
/
