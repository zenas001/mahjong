CREATE PROCEDURE           Q_ACCOUNT_A_TRANS(i_order_item_id IN NUMBER,
                                              I_ACTION_TYPE   IN VARCHAR) IS
  V_ACCOUNT_SEQ        NUMBER;
  V_CUST_ORDER_ID      NUMBER;
  V_PROD_INST_ACCT_SEQ NUMBER;
  C_ACTION_ADD CONSTANT VARCHAR2(5) := 'ADD';
  C_ACTION_MOD CONSTANT VARCHAR2(5) := 'MOD';
  C_ACTION_DEL CONSTANT VARCHAR2(5) := 'DEL';
  C_ACTION_KIP CONSTANT VARCHAR2(5) := 'KIP';
BEGIN
  V_ACCOUNT_SEQ        := SEQ_AUTOTEST_ACCOUNT_ID.NEXTVAL;
  V_PROD_INST_ACCT_SEQ := SEQ_AUTOTEST_PROD_INST_ACCT_ID.NEXTVAL;
  select cust_order_id
    INTO V_CUST_ORDER_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  IF I_ACTION_TYPE = C_ACTION_ADD THEN
    --ADD
    INSERT INTO AUTOTEST_ACCOUNT
      (AUTOTEST_ACCOUNT_ID,
       CUST_ORDER_ID,
       CUST_ID,
       LAN_ID,
       ACCOUNT_NAME,
       VIRTUAL_ACCOUNT_ID,
       ACCOUNT_AREA_GRADE,
       ACCOUNT_NUMBER,
       PAYMENT_METHOD_CD,
       PAYMENT_ACCOUNT,
       PAYMENT_ACCOUNT_NAME,
       PAYMENT_ACCOUNT_TYPE,
       PAYMENT_BANK_ID,
       BILL_POST_TYPE,
       BILL_POST_CONTENT,
       POST_ADDRESS,
       POST_CODE,
       EMAIL,
       ACTION,
       CREATE_DATE)
      SELECT V_ACCOUNT_SEQ,
             V_CUST_ORDER_ID,
             NULL CUST_ID,
             (SELECT AC.AREA_CODE
                FROM CRMV2.AREA_CODE AC
               WHERE AC.AREA_CODE_ID = A.AREA_ID) LAN_ID,
             A.ACCOUNT_NAME,
             NULL VIRTUAL_ACCOUNT_ID,
             A.ACCOUNT_AREA_GRADE,
             A.ACCOUNT_NUMBER,
             B.PAYMENT_METHOD_ID PAYMENT_METHOD_CD,
             B.PAYMENT_ACCOUNT,
             B.PAYMENT_ACCOUNT_NAME,
             B.PAYMENT_ACCOUNT_TYPE,
             B.PAYMENT_BANK_ID,
             (SELECT BILL_POST_TYPE
                FROM CRMV2.BILL_FORMAT_CUSTOMIZE C
               WHERE C.ACCOUNT_ID = A.ACCOUNT_ID) BILL_POST_TYPE,
             (SELECT BILL_POST_CONTENT
                FROM CRMV2.BILL_FORMAT_CUSTOMIZE C1
               WHERE C1.ACCOUNT_ID = A.ACCOUNT_ID) BILL_POST_CONTENT,
             (SELECT POST_ADDRESS
                FROM CRMV2.BILL_FORMAT_CUSTOMIZE C2
               WHERE C2.ACCOUNT_ID = A.ACCOUNT_ID) POST_ADDRESS,
             (SELECT POST_CODE
                FROM CRMV2.BILL_FORMAT_CUSTOMIZE C3
               WHERE C3.ACCOUNT_ID = A.ACCOUNT_ID) POST_CODE,
             (SELECT EMAIL
                FROM CRMV2.BILL_FORMAT_CUSTOMIZE C4
               WHERE C4.ACCOUNT_ID = A.ACCOUNT_ID) EMAIL,
             C_ACTION_ADD ACTION,
             SYSDATE CREATE_DATE
        FROM ACCOUNT A, PAYMENT_PLAN B
       WHERE A.ACCOUNT_ID = B.ACCOUNT_ID
         AND A.ACCOUNT_ID =
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'ACCOUNT_ID',
                                i_order_item_id);
    INSERT INTO AUTOTEST_ACCOUNT_ATTR
      (AUTOTEST_ACCOUNT_ATTR_ID,
       AUTOTEST_ACCOUNT_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      SELECT SEQ_AUTOTEST_ACCOUNT_ATTR_ID.NEXTVAL,
             V_ACCOUNT_SEQ,
             AC.EXT_ATTR_NBR,
             NULL,
             A.NEW_VALUE,
             SYSDATE
        FROM CRMV2.ORDER_ITEM_PROC_ATTR_HIS A, CRMV2.ATTR_SPEC AC
       WHERE A.OBJ_ATTR_ID = AC.ATTR_ID
         AND A.CLASS_ID = 137
         AND A.ORDER_ITEM_ID = i_order_item_id;

    insert into autotest_prod_inst_acct
      (AUTOTEST_PROD_INST_ACCT_ID,
       CUST_ORDER_ID,
       ACCOUNT_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       CHARGE_TYPE,
       ACTION,
       CREATE_DATE)
      select V_PROD_INST_ACCT_SEQ,
             V_CUST_ORDER_ID,
             ACCOUNT_ID,
             PROD_INST_ID,
             PAYMENT_LIMIT_TYPE,
             PAYMENT_LIMIT,
             CHARGE_TYPE,
             C_ACTION_ADD         ACTION,
             SYSDATE              CREATE_DATE
        from CRMV2.PROD_INST_ACCT A
       where A.ACCOUNT_ID =
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'ACCOUNT_ID',
                                i_order_item_id);

  ELSIF I_ACTION_TYPE = C_ACTION_MOD THEN
    --MOD
    INSERT INTO AUTOTEST_ACCOUNT
      (AUTOTEST_ACCOUNT_ID,
       CUST_ORDER_ID,
       CUST_ID,
       LAN_ID,
       ACCOUNT_NAME,
       VIRTUAL_ACCOUNT_ID,
       ACCOUNT_AREA_GRADE,
       ACCOUNT_NUMBER,
       PAYMENT_METHOD_CD,
       PAYMENT_ACCOUNT,
       PAYMENT_ACCOUNT_NAME,
       PAYMENT_ACCOUNT_TYPE,
       PAYMENT_BANK_ID,
       BILL_POST_TYPE,
       BILL_POST_CONTENT,
       POST_ADDRESS,
       POST_CODE,
       EMAIL,
       ACTION,
       CREATE_DATE)
      SELECT V_ACCOUNT_SEQ,
             V_CUST_ORDER_ID,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'CUST_ID',
                                i_order_item_id) CUST_ID,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'LAN_ID',
                                i_order_item_id) LAN_ID,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'ACCOUNT_NAME',
                                i_order_item_id) ACCOUNT_NAME,
             '' VIRTUAL_ACCOUNT_ID,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'ACCOUNT_AREA_GRADE',
                                i_order_item_id) ACCOUNT_AREA_GRADE,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'ACCOUNT_NUMBER',
                                i_order_item_id) ACCOUNT_NUMBER,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'PAYMENT_METHOD_CD',
                                i_order_item_id) PAYMENT_METHOD_CD,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'PAYMENT_ACCOUNT',
                                i_order_item_id) PAYMENT_ACCOUNT,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'PAYMENT_ACCOUNT_NAME',
                                i_order_item_id) PAYMENT_ACCOUNT_NAME,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'PAYMENT_ACCOUNT_TYPE',
                                i_order_item_id) PAYMENT_ACCOUNT_TYPE,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'BILL_POST_CONTENT',
                                i_order_item_id) BILL_POST_CONTENT,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'PAYMENT_BANK_ID',
                                i_order_item_id) PAYMENT_BANK_ID,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'BILL_POST_TYPE',
                                i_order_item_id) BILL_POST_TYPE,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'POST_ADDRESS',
                                i_order_item_id) POST_ADDRESS,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'POST_CODE',
                                i_order_item_id) POST_CODE,
             qianty_f_get_value('AUTOTEST_ACCOUNT',
                                'EMAIL',
                                i_order_item_id) EMAIL,
             C_ACTION_MOD ACTION,
             SYSDATE CREATE_DATE

        FROM DUAL;

    INSERT INTO AUTOTEST_ACCOUNT_ATTR
      (AUTOTEST_ACCOUNT_ATTR_ID,
       AUTOTEST_ACCOUNT_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      SELECT SEQ_AUTOTEST_ACCOUNT_ATTR_ID.NEXTVAL,
             V_ACCOUNT_SEQ,
             AC.EXT_ATTR_NBR,
             NULL,
             A.NEW_VALUE,
             SYSDATE
        FROM CRMV2.ORDER_ITEM_PROC_ATTR_HIS A, CRMV2.ATTR_SPEC AC
       WHERE A.OBJ_ATTR_ID = AC.ATTR_ID
         AND A.CLASS_ID = 137
         AND A.ORDER_ITEM_ID = i_order_item_id;

    insert into autotest_prod_inst_acct
      (AUTOTEST_PROD_INST_ACCT_ID,
       CUST_ORDER_ID,
       ACCOUNT_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       CHARGE_TYPE,
       ACTION,
       CREATE_DATE)
      select V_PROD_INST_ACCT_SEQ,
             V_CUST_ORDER_ID,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'ACCOUNT_ID',
                                i_order_item_id) ACCOUNT_ID,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'PROD_INST_ID',
                                i_order_item_id) PROD_INST_ID,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'PAYMENT_LIMIT_TYPE',
                                i_order_item_id) PAYMENT_LIMIT_TYPE,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'PAYMENT_LIMIT',
                                i_order_item_id) PAYMENT_LIMIT,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'CHARGE_TYPE',
                                i_order_item_id) CHARGE_TYPE,
             C_ACTION_MOD ACTION,
             SYSDATE CREATE_DATE
        from dual;

  ELSE
    --DEL
    INSERT INTO AUTOTEST_ACCOUNT
      (AUTOTEST_ACCOUNT_ID, CUST_ORDER_ID, CUST_ID, ACTION, CREATE_DATE)
      SELECT V_ACCOUNT_SEQ,
             V_CUST_ORDER_ID,
             NULL CUST_ID,
             C_ACTION_DEL,
             SYSDATE
        FROM DUAL;

    INSERT INTO autotest_prod_inst_acct
      (AUTOTEST_PROD_INST_ACCT_ID,
       CUST_ORDER_ID,
       ACCOUNT_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       CHARGE_TYPE,
       ACTION,
       CREATE_DATE)
      SELECT V_PROD_INST_ACCT_SEQ,
             V_CUST_ORDER_ID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             C_ACTION_DEL,
             SYSDATE
        FROM DUAL;
  END IF;
END Q_ACCOUNT_A_TRANS;
/
