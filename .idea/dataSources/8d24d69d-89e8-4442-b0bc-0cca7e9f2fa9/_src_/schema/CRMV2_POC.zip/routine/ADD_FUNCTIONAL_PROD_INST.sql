CREATE PROCEdure           add_functional_prod_inst(in_prodinst    in number,
                                                     in_fproductid  in number,
                                                     in_modi_reason in varchar2,
                                                     in_modi_staff  in varchar2,
                                                     o_id           out number,
                                                     o_msg          out varchar2) IS
  v_n              number(10);
  v_fprodinst      number(10);
  v_fprodofferinst number(10);
  v_offerprodrela  number(10);
  v_prodinstrel    number(10);
  v_prodoffer      number(10);
BEGIN
  --是否有配置
  select count(1)
    into v_n
    from crmv2.prod_Inst pi, crmv2.product_relation b
   where pi.prod_inst_id = in_prodinst
     and pi.product_id = b.product_a_id
     and b.product_z_id = in_fproductid
     and b.status_cd = '1000';

  if v_n = 0 then
    o_id  := 0;
    o_msg := '该功能产品没有配置与接入类产品的关联';
    return;
  end if;

  --产品是否存在

  select count(1)
    into v_n
    from crmv2.prod_Inst pi
   where pi.prod_inst_id = in_prodinst
     and pi.status_cd not in ('110000', '130000');

  if v_n = 0 then
    o_id  := 0;
    o_msg := '输入的产品ID有误';
    return;
  end if;

  --判断是否已经存在

  select count(1)
    into v_n
    from crmv2.prod_inst_rel a, crmv2.prod_inst b
   where a.prod_inst_a_id = in_prodinst
     and a.prod_inst_z_id = b.prod_inst_id
     and b.product_id = in_fproductid
     and b.status_cd != '110000';

  if v_n > 0 then
    o_id  := 0;
    o_msg := '功能性产品已存在';
    return;
  end if;

  --建立产品表
  select crmv2.seq_prod_inst_id.nextval into v_fprodinst from dual;

  insert into crmv2.prod_inst
    (PROD_INST_ID,
     PRODUCT_ID,
     ACC_PROD_INST_ID,
     ADDRESS_ID,
     OWNER_CUST_ID,
     PAYMENT_MODE_CD,
     PRODUCT_PASSWORD,
     IMPORTANT_LEVEL,
     AREA_CODE,
     ACC_NBR,
     EXCH_ID,
     COMMON_REGION_ID,
     REMARK,
     PAY_CYCLE,
     BEGIN_RENT_TIME,
     STOP_RENT_TIME,
     FINISH_TIME,
     STOP_STATUS,
     STATUS_CD,
     CREATE_DATE,
     STATUS_DATE,
     UPDATE_DATE,
     PROC_SERIAL,
     USE_CUST_ID,
     EXT_PROD_INST_ID,
     ADDRESS_DESC,
     AREA_ID,
     UPDATE_STAFF,
     CREATE_STAFF,
     REC_UPDATE_DATE)
    select v_fprodinst,
           in_fproductid,
           prod_inst_id,
           '',
           owner_cust_id,
           '',
           '',
           '',
           area_code,
           '',
           '',
           common_region_id,
           in_modi_reason,
           '',
           sysdate,
           date '2199-01-01',
           sysdate,
           '0',
           '100000',
           sysdate,
           sysdate,
           sysdate,
           '',
           use_cust_id,
           v_fprodinst,
           '',
           area_id,
           '',
           '',
           ''
      from crmv2.prod_inst pi
     where pi.prod_inst_id = in_prodinst;

  -- 新增产品和产品关系
  select crmv2.Seq_Prod_Inst_Rel_Id.nextval into v_prodinstrel from dual;

  insert into prod_inst_rel
    (PROD_INST_REL_ID,
     PROD_INST_A_ID,
     PROD_INST_Z_ID,
     RELATION_TYPE_CD,
     PROD_INST_REL_ROLE_ID,
     ROLE_CD,
     EFF_DATE,
     EXP_DATE,
     CREATE_DATE,
     STATUS_CD,
     STATUS_DATE,
     UPDATE_DATE,
     PROC_SERIAL,
     PRODUCT_REL_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     REC_UPDATE_DATE)
    select v_prodinstrel,
           in_prodinst,
           v_fprodinst,
           pr.relation_type_cd,
           '',
           pr.role_cd,
           sysdate,
           date '2199-01-01',
           sysdate,
           '1000',
           sysdate,
           sysdate,
           '',
           pr.product_rel_id,
           pi.area_id,
           pi.common_region_id,
           '',
           '',
           ''
      from crmv2.prod_inst pi, crmv2.product_relation pr
     where pi.prod_inst_id = in_prodinst
       and pi.product_id = pr.product_a_id
       and pr.product_z_id = in_fproductid
       and pr.status_cd = '1000';

  --销售品
  begin
    select b.prod_offer_id
      into v_prodoffer
      from crmv2.offer_prod_rel a, crmv2.prod_offer b
     where a.product_id = in_fproductid
       and a.prod_offer_id = b.prod_offer_id
       and b.offer_sub_type = 'T02'
       and a.status_cd = '1000'
       and a.rule_type = '10'
       and b.prod_offer_id='900587950';

  exception
    when others then
      o_msg := '附属产品的销售品不存在';
      rollback;
      return;
  end;

  select crmv2.seq_prod_offer_inst_id.nextval
    into v_fprodofferinst
    from dual;

  insert into crmv2.prod_offer_Inst poi
    (PROD_OFFER_INST_ID,
     PROD_OFFER_ID,
     CUST_ID,
     CHANNEL_ID,
     CREATE_DATE,
     STATUS_CD,
     STATUS_DATE,
     EFF_DATE,
     EXP_DATE,
     REGION,
     UPDATE_DATE,
     PROC_SERIAL,
     EXT_PROD_OFFER_INST_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     TRIAL_EFF_DATE,
     TRIAL_EXP_DATE,
     REC_UPDATE_DATE,
     SERVICE_NBR,
     END_AUTO,
     REMARK,
     WH_REMARK)
    select v_fprodofferinst,
           v_prodoffer,
           pi.owner_cust_id,
           '',
           sysdate,
           '1000',
           sysdate,
           sysdate,
           date '2199-01-01',
           pi.common_region_id,
           sysdate,
           '',
           v_fprodinst,
           pi.area_id,
           pi.common_region_id,
           '',
           '',
           '',
           '',
           '',
           '',
           '',
           in_modi_reason,
           in_modi_reason
      from crmv2.prod_inst pi
     where pi.prod_inst_id = in_prodinst;

  --销售品产品关联
  select crmv2.seq_offer_prod_inst_rel_id.nextval
    into v_offerprodrela
    from dual;

  insert into crmv2.offer_prod_inst_rel
    (OFFER_PROD_INST_REL_ID,
     PROD_INST_ID,
     PROD_OFFER_INST_ID,
     ROLE_CD,
     OFFER_PROD_INST_REL_ROLE_ID,
     STATUS_CD,
     STATUS_DATE,
     CREATE_DATE,
     EFF_DATE,
     EXP_DATE,
     UPDATE_DATE,
     PROC_SERIAL,
     OFFER_PROD_REL_ID,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     REC_UPDATE_DATE,
     EXT_FLAG)
    select v_offerprodrela,
           v_fprodinst,
           v_fprodofferinst,
           a.role_cd,
           '',
           '1000',
           sysdate,
           sysdate,
           sysdate,
           date '2199-01-01',
           sysdate,
           '',
           a.offer_prod_rela_id,
           b.area_id,
           b.common_region_id,
           '',
           '',
           '',
           ''
      from crmv2.offer_prod_rel a, crmv2.prod_Inst b
     where b.prod_inst_id = v_fprodinst
       and b.product_id = a.product_id
       and a.prod_offer_id = v_prodoffer
       and a.status_cd = '1000';

  o_id := v_fprodinst;



  o_msg := '添加成功';

END;
/
