CREATE procedure           update_proc_mode_bycode( v_area_id varchar2,v_proc_mode_code varchar2) as
	v_prod_mode_id number;
	t_class_id number;
	new_win_id number;
	t_inst_class_id number;
	obj tmp_ppm_sys_class_rel_obj%rowtype;
	v_prod_mode_id0 number;
  v_proc proc_mode%rowtype;
begin

    select p.proc_mode_id into v_prod_mode_id0 from tmp_proc_mode p where p.proc_mode_code = v_proc_mode_code;
    select p.proc_mode_id into v_prod_mode_id from proc_mode p where p.proc_mode_code = v_proc_mode_code;
    select p.* into v_proc from proc_mode p where p.proc_mode_code = v_proc_mode_code;


	select sc.class_id into t_class_id from sys_class sc where sc.java_code = 'ProcMode';


	delete FROM sys_window sw where sw.win_id = (select t.obj_id from sys_class_rel_obj t where t.class_id = t_class_id and t.sub_class_id = v_prod_mode_id and t.event_id = '100');

	delete FROM sys_win_componet sp where sp.win_id = (select t.obj_id from sys_class_rel_obj t where t.class_id = t_class_id and t.sub_class_id = v_prod_mode_id and t.event_id = '100');

	delete from sys_class_rel_obj t where t.class_id = t_class_id and t.sub_class_id = v_prod_mode_id and t.event_id = '100';

begin
		t_inst_class_id:=-300;
			-- 获取旧窗体id
		select * into obj from tmp_ppm_sys_class_rel_obj t where t.class_id = t_class_id and t.sub_class_id = v_prod_mode_id0 and t.event_id = '100' ;

		-- 创建窗体
		new_win_id := ppm_fnc_create_window(obj.obj_id,t_class_id,v_prod_mode_id,v_proc.proc_mode_name,v_area_id,t_inst_class_id);
		--创建关联关系
		insert into sys_class_rel_obj(class_obj_rela_id ,class_id,event_id,obj_type,obj_id,rela_region ,status_cd ,status_date ,create_date ,update_date ,sub_class_id,area_id ,region_cd ,update_staff,create_staff,remark)
	 	 values(seq_sys_class_rel_obj_id.nextval,t_class_id,obj.event_id,obj.obj_type,new_win_id,obj.rela_region ,obj.status_cd ,sysdate ,sysdate ,sysdate ,v_prod_mode_id ,v_area_id ,v_area_id,null,null,obj.remark);
exception
	when others then
	dbms_output.PUT_LINE(v_proc_mode_code||'未配置界面');
end;

end;
/
