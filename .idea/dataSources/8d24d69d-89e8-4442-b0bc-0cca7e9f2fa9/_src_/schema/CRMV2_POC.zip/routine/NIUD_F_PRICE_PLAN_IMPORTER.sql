CREATE function           niud_f_price_plan_importer(i_price_id in number,
                                                      o_msg      out varchar2)
  return number is

  /****
    功能：
        一，将1.0可选/促销包基本套餐的销售品适用导入2.0的销售品产品引用关系；
        二，将1.0可选/促销包基本套餐间的依赖/互斥关系导入2.0，其中
          a) 如果互斥的另一端是2.0的套餐销售品，则屏蔽销售品之间的依赖关系即可；
          b) 如果互斥的另一端是2.0的可选/促销包，则配置销售品之间的互斥关系。
        三，将1.0可选/促销包基本套餐的实物关联关系导入2.0
        四，建立服务提供
    使用注意事项：
        先要在2.0创建可选包规格，并在映射表里做好和1.0的映射关系
        销售品的目录、属性、页面要另外配置
        对于1.0销售品关联和套餐关联为空、而套餐销售品配置非空的数据，需另行处理
        参考《销售品关联脚本导入说明.docx》
    入参：
        i_price_id - 1.0基本套餐规格ID（对应为2.0的可选/促销包）
    出参：
        o_msg - 提示信息
    返回：
        0或正数 - 正常执行后处理的数据总数
        -1 - 入参有误
        -2 - 2.0存在多个映射规格

                       by niud, 120510
  ****/

  v_cre_area_id        number(2);
  v_prod_offer_id      prod_offer.prod_offer_id%type;
  v_prod_offer_rela_id prod_offer_rel.prod_offer_rela_id%type;
  v_res_rel_id         prod_offer_res_rel.prod_offer_res_rel_id%type;
  v_area_id            number(2);
  v_remark             varchar2(100) := 'imported via niud_f_price_plan_importer';
  v_main_flag          boolean := false; --标记如果插入了任何的主套餐依赖，就不必依赖于天翼
  v_tmp_1              number(4);
  v_tmp_2              number(4);
  v_tmp_3              number(4);
  v_tmp_4              number(4);
  v_tmp_5              number(4);
  v_cnt_bk             number(4) := 0;
  v_cnt_1              number(4) := 0;
  v_cnt_2              number(4) := 0;
  v_cnt_3              number(4) := 0;
  v_cnt_4              number(4) := 0;
  v_cnt_5              number(4) := 0;

  /****
      产品引用关系的导入，每个产品只需要导入一条。
      根据price_plan.cre_area_id，
      省级的直接导为省级，本地直接导为本地。
  ****/
  cursor cur_prod is
    select distinct p.prod_id_2
      from prefer_mdse_price_spec_rela@lk_crmv1 r,
           mdse_spec@lk_crmv1                   ms,
           mdse_ys_product                      p
     where r.mdse_spec_id = ms.mdse_spec_id
       and ms.prod_spec_id = p.prod_id_1
       and r.rela_mdse_id = -1
       and r.rela_type = '101'
       and r.state = '70A'
       and p.state_cd like '在售'
       and r.mdse_spec_id <> 610317985 --排除无线宽带数据卡
       and r.rela_type <> '130' --排除实物关联
       and r.price_id = i_price_id
    union all
    select distinct 800000007
      from prefer_mdse_price_spec_rela@lk_crmv1 r
     where r.mdse_spec_id = 610317985 --无线宽带数据卡在2.0转换为无线宽带产品
       and r.rela_mdse_id = -1
       and r.rela_type = '101'
       and r.state = '70A'
       and r.rela_type <> '130' --排除实物关联
       and r.price_id = i_price_id;

  /****
      全部主套餐导入，依据产品引用关系配置
      只有移动语音和无线宽带才要取主套餐
      执行此段游标的前提是该可选包不存在
        任何和其他套餐销售品的依赖关系
  ****/
  cursor cur_main is
    select y.id_v1, y.id_v2
      from prod_offer po, mdse_ys_lisy_new y
     where po.prod_offer_id = y.id_v2
       and po.status_cd like '10%'
       and po.offer_sub_type = 'T01' --接入类
       and (po.area_id = 1 or po.area_id = v_cre_area_id)
       and exists
     (select 1
              from offer_prod_rel r
             where r.prod_offer_id = po.prod_offer_id
               and r.rule_type = '12' --强制选择
               and r.status_cd like '10%'
               and r.role_cd is null --排除角色上的强制选择
               and r.product_id in (800000002, 800000007) --只有移动语音和无线宽带才要取主套餐
               and exists (select 2
                      from offer_prod_rel r1
                     where r.product_id = r1.product_id
                       and r1.prod_offer_id = v_prod_offer_id
                       and r1.rule_type = '14' --引用关系
                       and r1.status_cd = '1000'
                       and r1.area_id = v_cre_area_id));

  cursor cur_main_101 is
    select distinct y.id_v1, y.id_v2
      from mdse_spec_rela@lk_crmv1 r, mdse_ys_lisy_new y, prod_offer po
     where r.mdse_spec_ida = y.id_v1
       and r.mdse_spec_idb = i_price_id
       and y.id_v2 = po.prod_offer_id
       and r.rela_type in ('101', '127') --强制依赖，选择依赖
       and po.offer_type = '11' --套餐销售品
       and r.state = '70A';

  /****
      和可选包之间的依赖关系
  ****/
  cursor cur_rela_kxb_101 is
    select distinct y.id_v1, y.id_v2, n.rela_type_v1, n.rela_type_v2
      from mdse_spec_rela@lk_crmv1  r,
           mdse_ys_lisy_new         y,
           prod_offer               po,
           niud_t_rela_type_mapping n
     where r.mdse_spec_ida = y.id_v1
       and y.id_v2 = po.prod_offer_id
       and r.rela_type = n.rela_type_v1
       and r.rela_type in ('101', '127') --强制依赖、选择依赖
       and po.offer_type in ('12', '13') --可选包、促销包
       and r.state = '70A'
       and r.mdse_spec_idb = i_price_id;

  /****
      和可选包之间的互斥关系
  ****/
  cursor cur_rela_kxb_102 is
    select distinct y.id_v1, y.id_v2
      from mdse_spec_rela@lk_crmv1 r, mdse_ys_lisy_new y, prod_offer po
     where ((r.mdse_spec_idb = y.id_v1 and r.mdse_spec_ida = i_price_id) or
           (r.mdse_spec_ida = y.id_v1 and r.mdse_spec_idb = i_price_id))
       and y.id_v2 = po.prod_offer_id
       and r.rela_type = '102' --互斥
       and po.offer_type in ('12', '13') --可选包、促销包
       and r.state = '70A';

  /****
      销售品适用关系
      除101外还有其他关系，请根据需要另行扩充。
  ****/
  cursor cur_pm_101 is
    select distinct ys.id_v1, ys.id_v2
      from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1 pm, mdse_ys_lisy_new ys
     where pm.mdse_spec_id = ys.id_v1
       and ys.id_v2 is not null
       and pm.price_id = i_price_id
       and pm.rela_type = '101'
       and pm.state = '70A';

  /****
      实物关联关系
      未关联套餐档次，请根据需要扩充此功能。
  ****/
  cursor cur_pm_130 is
    select distinct mdse_spec_id s_id, 0 res_type
      from prefer_mdse_price_spec_rela@lk_crmv1 r
     where r.rela_type = '130' --实物关联
       and r.state = '70A'
       and r.mdse_spec_id <> -1 --实物细类
       and r.price_id = i_price_id
    union
    select distinct prod_spec_id s_id, 1 res_type
      from prefer_mdse_price_spec_rela@lk_crmv1 r
     where r.rela_type = '130' --实物关联
       and r.state = '70A'
       and r.mdse_spec_id = -1 --实物大类
       and r.price_id = i_price_id;

  /****
      服务提供
      未提供页面配置，请另行处理
  ****/
  cursor cur_so is
    select *
      from service_offer
     where sort = 'OFFER'
       and service_offer_name in ('订购', '变更', '退订');

begin

  begin
    select id_v2
      into v_prod_offer_id
      from mdse_ys_lisy_new y, prod_offer po
     where y.id_v2 = po.prod_offer_id
       and po.offer_type in ('12', '13')
       and y.id_v1 = i_price_id;
  exception
    when no_data_found then
      o_msg := '1.0规格ID输入有误！';
      return(-1);
    when too_many_rows then
      o_msg := '1.0规格ID在2.0存在多个映射！';
      return(-2);
  end;

  select cre_area_id
    into v_cre_area_id
    from price_plan@lk_crmv1
   where price_id = i_price_id;

  for rec_prod in cur_prod loop
    --删除多余/错误的构成记录
    delete from offer_prod_rel
     where prod_offer_id = v_prod_offer_id
       and product_id = rec_prod.prod_id_2
       and rule_type = '14'
       and area_id <> v_cre_area_id;
    select count(*)
      into v_tmp_1
      from offer_prod_rel
     where prod_offer_id = v_prod_offer_id
       and product_id = rec_prod.prod_id_2
       and rule_type = '14'
       and area_id = v_cre_area_id;
    if v_tmp_1 = 0 then
      insert into offer_prod_rel
      values
        (seq_offer_prod_rel_id.nextval,
         rec_prod.prod_id_2,
         v_prod_offer_id,
         null,
         null,
         null,
         '14', --引用关系
         '1000',
         sysdate,
         sysdate,
         sysdate,
         null,
         v_cre_area_id,
         null,
         null,
         null,
         'N',
         '2',
         null,
         null,
         null,
         null,
         null,
         v_remark,
         null,
         sysdate);
      v_cnt_1 := v_cnt_1 + 1;
    end if;

    /****
        判断该可选包有没有依赖于其他套餐销售品
        若有，则根据1.0配置依赖于相关套餐销售品
        若无，则根据移动语音/无线宽带引用关系
              配置相关的所有套餐销售品
    ****/
    select count(*)
      into v_tmp_1
      from mdse_spec_rela@lk_crmv1 r, mdse_ys_lisy_new y, prod_offer po
     where r.mdse_spec_ida = y.id_v1
       and r.mdse_spec_idb = i_price_id
       and y.id_v2 = po.prod_offer_id
       and r.rela_type in ('101', '127') --强制依赖、选择依赖
       and po.offer_type = '11' --套餐销售品
       and r.state = '70A';
    if v_tmp_1 = 0 then
      for rec_main in cur_main loop
        select count(*)
          into v_tmp_2
          from prod_offer_rel
         where offer_a_id = rec_main.id_v2
           and offer_z_id = v_prod_offer_id
           and relation_type_cd = '100000'
           and area_id = v_cre_area_id;
        select count(*)
          into v_tmp_3
          from mdse_spec_rela@lk_crmv1
         where ((mdse_spec_ida = rec_main.id_v2 and
               mdse_spec_idb = v_prod_offer_id) or
               (mdse_spec_idb = rec_main.id_v2 and
               mdse_spec_ida = v_prod_offer_id))
           and rela_type = '102'
           and cfg_area_id = v_cre_area_id
           and state = '70A';
        --配入之前先要确认1.0里存不存在互斥关系
        if v_tmp_2 = 0 and v_tmp_3 = 0 then
          insert into prod_offer_rel
          values
            (seq_prod_offer_rel_id.nextval,
             rec_main.id_v2,
             v_prod_offer_id,
             null,
             '100000', --依赖关系
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             sysdate,
             null,
             v_cre_area_id,
             null,
             -1,
             -1,
             null,
             null,
             null,
             null,
             null,
             v_remark);
          v_cnt_2     := v_cnt_2 + 1;
          v_main_flag := true;
        end if;
      end loop;
    else
      for rec_main_101 in cur_main_101 loop
        if v_cre_area_id > 1 then
          select count(*)
            into v_tmp_2
            from prod_offer_rel
           where offer_a_id = rec_main_101.id_v2
             and offer_z_id = v_prod_offer_id
             and relation_type_cd = '100000'
             and area_id = v_cre_area_id;
          if v_tmp_2 = 0 then
            insert into prod_offer_rel
            values
              (seq_prod_offer_rel_id.nextval,
               rec_main_101.id_v2,
               v_prod_offer_id,
               null,
               '100000', --依赖关系
               sysdate,
               null,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               v_cre_area_id,
               null,
               -1,
               -1,
               null,
               null,
               null,
               null,
               null,
               v_remark);
            v_cnt_2 := v_cnt_2 + 1;
            v_main_flag := true;
          end if;
        else
          --参考：省级可选包的关联关系从1.0导入2.0的逻辑关系图.vsd
          select count(*)
            into v_tmp_2
            from prod_offer_rel
           where offer_a_id = rec_main_101.id_v2
             and offer_z_id = v_prod_offer_id
             and relation_type_cd = '100000'
             and status_cd = '1000'
             and role_cd is null
             and area_id = 1;
          if v_tmp_2 = 0 then
            select seq_prod_offer_rel_id.nextval
              into v_prod_offer_rela_id
              from dual;
            insert into prod_offer_rel
            values
              (v_prod_offer_rela_id,
               rec_main_101.id_v2,
               v_prod_offer_id,
               null,
               '100000', --依赖关系
               sysdate,
               null,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               v_cre_area_id,
               null,
               -1,
               -1,
               null,
               null,
               null,
               null,
               null,
               v_remark);
            v_cnt_2 := v_cnt_2 + 1;
            v_main_flag := true;
          else
            select max(prod_offer_rela_id)
              into v_prod_offer_rela_id
              from prod_offer_rel
             where offer_a_id = rec_main_101.id_v2
               and offer_z_id = v_prod_offer_id
               and relation_type_cd = '100000'
               and role_cd is null
               and status_cd = '1000'
               and area_id = 1;
          end if;

          v_cnt_bk := v_cnt_4;
          for v_area_id in 2 .. 10 loop
            select count(*)
              into v_tmp_2
              from mdse_spec_rela@lk_crmv1
             where mdse_spec_ida = rec_main_101.id_v1
               and mdse_spec_idb = i_price_id
               and rela_type in ('101', '127')
               and state = '70A'
               and cfg_area_id = v_area_id;
            if v_tmp_2 > 0 then
              select count(*)
                into v_tmp_3
                from obj_area_rela
               where obj_class_id = 51
                 and obj_id = v_prod_offer_rela_id
                 and rela_area_id = v_area_id;
              if v_tmp_3 = 0 then
                insert into obj_area_rela
                values
                  (seq_obj_area_rela_id.nextval,
                   51,
                   v_prod_offer_rela_id,
                   v_area_id,
                   10,
                   1,
                   1,
                   '1000',
                   sysdate,
                   sysdate,
                   -1,
                   sysdate,
                   -1,
                   v_remark);
                v_cnt_4 := v_cnt_4 + 1;
              end if;
            else
              select count(*)
                into v_tmp_3
                from mdse_spec_rela@lk_crmv1
               where (mdse_spec_ida = i_price_id or
                     mdse_spec_idb = i_price_id)
                 and cfg_area_id = v_area_id;
              if v_tmp_3 = 0 then
                select count(*)
                  into v_tmp_4
                  from mdse_spec_rela@lk_crmv1
                 where mdse_spec_ida = rec_main_101.id_v1
                   and mdse_spec_idb = i_price_id
                   and rela_type in ('101', '127')
                   and state = '70A'
                   and cfg_area_id = 1;
                if v_tmp_4 > 0 then
                  select count(*)
                    into v_tmp_5
                    from obj_area_rela
                   where obj_class_id = 51
                     and obj_id = v_prod_offer_rela_id
                     and rela_area_id = v_area_id;
                  if v_tmp_5 = 0 then
                    insert into obj_area_rela
                    values
                      (seq_obj_area_rela_id.nextval,
                       51,
                       v_prod_offer_rela_id,
                       v_area_id,
                       10,
                       1,
                       1,
                       '1000',
                       sysdate,
                       sysdate,
                       -1,
                       sysdate,
                       -1,
                       v_remark);
                    v_cnt_4 := v_cnt_4 + 1;
                  end if;
                end if;
              end if;
            end if;
          end loop;
          select count(*)
            into v_tmp_1
            from obj_area_rela
           where obj_class_id = 51
             and obj_id = v_prod_offer_rela_id
             and status_cd = '1000';
          if v_tmp_1 >= 9 then
            delete from obj_area_rela
             where obj_class_id = 51
               and obj_id = v_prod_offer_rela_id;
            v_cnt_4 := v_cnt_bk;
          end if;
        end if;
      end loop;
    end if;
  end loop;

  for rec_rela_kxb_101 in cur_rela_kxb_101 loop
    if v_cre_area_id > 1 then
      select count(*)
        into v_tmp_1
        from prod_offer_rel
       where offer_a_id = rec_rela_kxb_101.id_v2
         and offer_z_id = v_prod_offer_id
         and relation_type_cd = rec_rela_kxb_101.rela_type_v2
         and role_cd is null
         and area_id = v_cre_area_id;
      if v_tmp_1 = 0 then
        insert into prod_offer_rel
        values
          (seq_prod_offer_rel_id.nextval,
           rec_rela_kxb_101.id_v2,
           v_prod_offer_id,
           null,
           rec_rela_kxb_101.rela_type_v2,
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           v_cre_area_id,
           null,
           -1,
           -1,
           null,
           null,
           null,
           null,
           null,
           v_remark);
        v_cnt_2 := v_cnt_2 + 1;
      end if;
    else
      --参考：省级可选包的关联关系从1.0导入2.0的逻辑关系图.vsd
      select count(*)
        into v_tmp_2
        from prod_offer_rel
       where offer_a_id = rec_rela_kxb_101.id_v2
         and offer_z_id = v_prod_offer_id
         and relation_type_cd = rec_rela_kxb_101.rela_type_v2
         and role_cd is null
         and area_id = 1
         and status_cd = '1000';
      if v_tmp_2 = 0 then
        select seq_prod_offer_rel_id.nextval
          into v_prod_offer_rela_id
          from dual;
        insert into prod_offer_rel
        values
          (v_prod_offer_rela_id,
           rec_rela_kxb_101.id_v2,
           v_prod_offer_id,
           null,
           rec_rela_kxb_101.rela_type_v2,
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           1,
           1,
           -1,
           -1,
           null,
           null,
           null,
           null,
           null,
           v_remark);
        v_cnt_2 := v_cnt_2 + 1;
      else
        select max(prod_offer_rela_id)
          into v_prod_offer_rela_id
          from prod_offer_rel
         where offer_a_id = rec_rela_kxb_101.id_v2
           and offer_z_id = v_prod_offer_id
           and relation_type_cd = rec_rela_kxb_101.rela_type_v2
           and role_cd is null
           and area_id = 1
           and status_cd = '1000';
      end if;

      v_cnt_bk := v_cnt_4;
      for v_area_id in 2 .. 10 loop
        select count(*)
          into v_tmp_2
          from mdse_spec_rela@lk_crmv1
         where mdse_spec_ida = rec_rela_kxb_101.id_v1
           and mdse_spec_idb = i_price_id
           and rela_type = rec_rela_kxb_101.rela_type_v1
           and state = '70A'
           and cfg_area_id = v_area_id;
        if v_tmp_2 > 0 then
          select count(*)
            into v_tmp_3
            from obj_area_rela
           where obj_class_id = 51
             and obj_id = v_prod_offer_rela_id
             and rela_area_id = v_area_id;
          if v_tmp_3 = 0 then
            insert into obj_area_rela
            values
              (seq_obj_area_rela_id.nextval,
               51,
               v_prod_offer_rela_id,
               v_area_id,
               10,
               1,
               1,
               '1000',
               sysdate,
               sysdate,
               -1,
               sysdate,
               -1,
               v_remark);
            v_cnt_4 := v_cnt_4 + 1;
          end if;
        else
          select count(*)
            into v_tmp_3
            from mdse_spec_rela@lk_crmv1
           where (mdse_spec_ida = i_price_id or mdse_spec_idb = i_price_id)
             and cfg_area_id = v_area_id;
          if v_tmp_3 = 0 then
            select count(*)
              into v_tmp_4
              from mdse_spec_rela@lk_crmv1
             where mdse_spec_ida = rec_rela_kxb_101.id_v1
               and mdse_spec_idb = i_price_id
               and rela_type = rec_rela_kxb_101.rela_type_v1
               and state = '70A'
               and cfg_area_id = 1;
            if v_tmp_4 > 0 then
              select count(*)
                into v_tmp_5
                from obj_area_rela
               where obj_class_id = 51
                 and obj_id = v_prod_offer_rela_id
                 and rela_area_id = v_area_id;
              if v_tmp_5 = 0 then
                insert into obj_area_rela
                values
                  (seq_obj_area_rela_id.nextval,
                   51,
                   v_prod_offer_rela_id,
                   v_area_id,
                   10,
                   1,
                   1,
                   '1000',
                   sysdate,
                   sysdate,
                   -1,
                   sysdate,
                   -1,
                   v_remark);
                v_cnt_4 := v_cnt_4 + 1;
              end if;
            end if;
          end if;
        end if;
      end loop;
      select count(*)
        into v_tmp_1
        from obj_area_rela
       where obj_class_id = 51
         and obj_id = v_prod_offer_rela_id
         and status_cd = '1000';
      if v_tmp_1 >= 9 then
        delete from obj_area_rela
         where obj_class_id = 51
           and obj_id = v_prod_offer_rela_id;
        v_cnt_4 := v_cnt_bk;
      end if;
    end if;
  end loop;

  for rec_rela_kxb_102 in cur_rela_kxb_102 loop
    if v_cre_area_id > 1 then
      select count(*)
        into v_tmp_1
        from prod_offer_rel
       where ((offer_a_id = rec_rela_kxb_102.id_v2 and
             offer_z_id = v_prod_offer_id) or
             (offer_z_id = rec_rela_kxb_102.id_v2 and
             offer_a_id = v_prod_offer_id))
         and relation_type_cd = '200000'
         and role_cd is null;
      if v_tmp_1 = 0 then
        insert into prod_offer_rel
        values
          (seq_prod_offer_rel_id.nextval,
           v_prod_offer_id,
           rec_rela_kxb_102.id_v2,
           null,
           '200000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           null,
           null,
           v_cre_area_id,
           null,
           -1,
           -1,
           null,
           null,
           null,
           null,
           null,
           v_remark);
        v_cnt_2 := v_cnt_2 + 1;
      end if;
    else
      --参考：省级可选包的关联关系从1.0导入2.0的逻辑关系图.vsd
      select count(*)
        into v_tmp_1
        from prod_offer_rel
       where ((offer_a_id = rec_rela_kxb_102.id_v2 and
             offer_z_id = v_prod_offer_id) or
             (offer_z_id = rec_rela_kxb_102.id_v2 and
             offer_a_id = v_prod_offer_id))
         and relation_type_cd = '200000'
         and status_cd = '1000'
         and role_cd is null
         and area_id = 1;
      if v_tmp_1 = 0 then
        select seq_prod_offer_rel_id.nextval
          into v_prod_offer_rela_id
          from dual;
        insert into prod_offer_rel
        values
          (v_prod_offer_rela_id,
           v_prod_offer_id,
           rec_rela_kxb_102.id_v2,
           null,
           '200000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           null,
           null,
           1,
           1,
           -1,
           -1,
           null,
           null,
           null,
           null,
           null,
           v_remark);
        v_cnt_2 := v_cnt_2 + 1;
      else
        select max(prod_offer_rela_id)
          into v_prod_offer_rela_id
          from prod_offer_rel
         where ((offer_a_id = rec_rela_kxb_102.id_v2 and
               offer_z_id = v_prod_offer_id) or
               (offer_z_id = rec_rela_kxb_102.id_v2 and
               offer_a_id = v_prod_offer_id))
           and relation_type_cd = '200000'
           and role_cd is null
           and status_cd = '1000'
           and area_id = 1;
      end if;

      v_cnt_bk := v_cnt_4;
      for v_area_id in 2 .. 10 loop
        select count(*)
          into v_tmp_2
          from mdse_spec_rela@lk_crmv1
         where ((mdse_spec_ida = rec_rela_kxb_102.id_v1 and
               mdse_spec_idb = i_price_id) or
               (mdse_spec_idb = rec_rela_kxb_102.id_v1 and
               mdse_spec_ida = i_price_id))
           and rela_type = '102'
           and state = '70A'
           and cfg_area_id = v_area_id;
        if v_tmp_2 > 0 then
          select count(*)
            into v_tmp_3
            from obj_area_rela
           where obj_class_id = 51
             and obj_id = v_prod_offer_rela_id
             and rela_area_id = v_area_id
             and status_cd = '1000';
          if v_tmp_3 = 0 then
            insert into obj_area_rela
            values
              (seq_obj_area_rela_id.nextval,
               51,
               v_prod_offer_rela_id,
               v_area_id,
               '10',
               1,
               1,
               '1000',
               sysdate,
               sysdate,
               -1,
               sysdate,
               -1,
               v_remark);
            v_cnt_4 := v_cnt_4 + 1;
          end if;
        else
          select count(*)
            into v_tmp_3
            from mdse_spec_rela@lk_crmv1
           where (mdse_spec_ida = i_price_id or mdse_spec_idb = i_price_id)
             and cfg_area_id = v_area_id;
          if v_tmp_3 = 0 then
            select count(*)
              into v_tmp_4
              from mdse_spec_rela@lk_crmv1
             where ((mdse_spec_ida = rec_rela_kxb_102.id_v1 and
                   mdse_spec_idb = i_price_id) or
                   (mdse_spec_idb = rec_rela_kxb_102.id_v1 and
                   mdse_spec_ida = i_price_id))
               and rela_type = '102'
               and state = '70A'
               and cfg_area_id = 1;
            if v_tmp_4 > 0 then
              select count(*)
                into v_tmp_5
                from obj_area_rela
               where obj_class_id = 51
                 and obj_id = v_prod_offer_rela_id
                 and rela_area_id = v_area_id
                 and status_cd = '1000';
              if v_tmp_5 = 0 then
                insert into obj_area_rela
                values
                  (seq_obj_area_rela_id.nextval,
                   51,
                   v_prod_offer_rela_id,
                   v_area_id,
                   '10',
                   1,
                   1,
                   '1000',
                   sysdate,
                   sysdate,
                   -1,
                   sysdate,
                   -1,
                   v_remark);
                v_cnt_4 := v_cnt_4 + 1;
              end if;
            end if;
          end if;
        end if;
      end loop;
      select count(*)
        into v_tmp_1
        from obj_area_rela
       where obj_class_id = 51
         and obj_id = v_prod_offer_rela_id
         and status_cd = '1000';
      if v_tmp_1 >= 9 then
        delete from obj_area_rela
         where obj_class_id = 51
           and obj_id = v_prod_offer_rela_id;
        v_cnt_4 := v_cnt_bk;
      end if;
    end if;
  end loop;

  for rec_pm_101 in cur_pm_101 loop
    if v_cre_area_id > 1 then
      select count(*)
        into v_tmp_1
        from prod_offer_rel
       where offer_a_id = rec_pm_101.id_v2
         and offer_z_id = v_prod_offer_id
         and relation_type_cd = '100000'
         and role_cd is null
         and area_id = v_area_id;
      if v_tmp_1 = 0 then
        insert into prod_offer_rel
        values
          (seq_prod_offer_rel_id.nextval,
           rec_pm_101.id_v2,
           v_prod_offer_id,
           null,
           '100000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           v_cre_area_id,
           null,
           -1,
           -1,
           null,
           null,
           null,
           null,
           null,
           v_remark);
        v_cnt_2 := v_cnt_2 + 1;
      end if;
    else
      --参考：省级可选包的关联关系从1.0导入2.0的逻辑关系图.vsd
      select count(*)
        into v_tmp_1
        from prod_offer_rel
       where offer_a_id = rec_pm_101.id_v2
         and offer_z_id = v_prod_offer_id
         and relation_type_cd = '100000'
         and role_cd is null
         and area_id = 1;
      if v_tmp_1 = 0 then
        select seq_prod_offer_rel_id.nextval
          into v_prod_offer_rela_id
          from dual;
        insert into prod_offer_rel
        values
          (v_prod_offer_rela_id,
           rec_pm_101.id_v2,
           v_prod_offer_id,
           null,
           '100000',
           sysdate,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           1,
           null,
           -1,
           -1,
           null,
           null,
           null,
           null,
           null,
           v_remark);
        v_cnt_2 := v_cnt_2 + 1;
      else
        select max(prod_offer_rela_id)
          into v_prod_offer_rela_id
          from prod_offer_rel
         where offer_a_id = rec_pm_101.id_v2
           and offer_z_id = v_prod_offer_id
           and relation_type_cd = '100000'
           and role_cd is null
           and area_id = 1;
      end if;

      v_cnt_bk := v_cnt_4;
      for v_area_id in 2 .. 10 loop
        select count(*)
          into v_tmp_2
          from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
         where mdse_spec_id = rec_pm_101.id_v1
           and price_id = i_price_id
           and rela_type = '101'
           and state = '70A'
           and cfg_area_id = v_area_id;
        if v_tmp_2 > 0 then
          select count(*)
            into v_tmp_3
            from obj_area_rela
           where obj_class_id = 51
             and obj_id = v_prod_offer_rela_id
             and rela_area_id = v_area_id
             and status_cd = '1000';
          if v_tmp_3 = 0 then
            insert into obj_area_rela
            values
              (seq_obj_area_rela_id.nextval,
               51,
               v_prod_offer_rela_id,
               v_area_id,
               '10',
               1,
               1,
               '1000',
               sysdate,
               sysdate,
               -1,
               sysdate,
               -1,
               v_remark);
            v_cnt_4 := v_cnt_4 + 1;
          end if;
        else
          select count(*)
            into v_tmp_3
            from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
           where mdse_spec_id = rec_pm_101.id_v1
             and cfg_area_id = v_area_id;
          if v_tmp_3 = 0 then
            select count(*)
              into v_tmp_4
              from PREFER_MDSE_PRICE_SPEC_RELA@lk_crmv1
             where mdse_spec_id = rec_pm_101.id_v1
               and price_id = i_price_id
               and rela_type = '101'
               and state = '70A'
               and cfg_area_id = 1;
            if v_tmp_4 > 0 then
              select count(*)
                into v_tmp_5
                from obj_area_rela
               where obj_class_id = 51
                 and obj_id = v_prod_offer_rela_id
                 and rela_area_id = v_area_id
                 and status_cd = '1000';
              if v_tmp_5 = 0 then
                insert into obj_area_rela
                values
                  (seq_obj_area_rela_id.nextval,
                   51,
                   v_prod_offer_rela_id,
                   v_area_id,
                   '10',
                   1,
                   1,
                   '1000',
                   sysdate,
                   sysdate,
                   -1,
                   sysdate,
                   -1,
                   v_remark);
                v_cnt_4 := v_cnt_4 + 1;
              end if;
            end if;
          end if;
        end if;
      end loop;
      select count(*)
        into v_tmp_1
        from obj_area_rela
       where obj_class_id = 51
         and obj_id = v_prod_offer_rela_id
         and status_cd = '1000';
      if v_tmp_1 >= 9 then
        delete from obj_area_rela
         where obj_class_id = 51
           and obj_id = v_prod_offer_rela_id;
        v_cnt_4 := v_cnt_bk;
      end if;
    end if;
  end loop;

  if v_main_flag = true then
    select count(*)
      into v_tmp_1
      from prod_offer_rel
     where offer_z_id = v_prod_offer_id
       and offer_a_id = 800001837 --天翼
       and relation_type_cd = '100000'
       and remark like '%' || v_remark || '%';
    if v_tmp_1 > 0 then
      delete from prod_offer_rel
       where offer_z_id = v_prod_offer_id
         and offer_a_id = 800001837
         and relation_type_cd = '100000'
         and remark like '%' || v_remark || '%';
      v_cnt_2 := v_cnt_2 - v_cnt_1;
    end if;
  end if;

  for rec_pm_130 in cur_pm_130 loop
    if v_cre_area_id > 1 then
      select count(*)
        into v_tmp_1
        from prod_offer_res_rel
       where prod_offer_id = v_prod_offer_id
         and mkt_res_id = rec_pm_130.s_id
         and area_id = v_cre_area_id;
      if v_tmp_1 = 0 then
        insert into prod_offer_res_rel
        values
          (seq_prod_offer_res_rel_id.nextval,
           v_prod_offer_id,
           rec_pm_130.s_id,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           v_area_id,
           null,
           null,
           null,
           null,
           rec_pm_130.res_type,
           v_remark);
        v_cnt_3 := v_cnt_3 + 1;
      end if;
    else
      --参考：省级可选包的关联关系从1.0导入2.0的逻辑关系图.vsd
      select count(*)
        into v_tmp_1
        from prod_offer_res_rel
       where prod_offer_id = v_prod_offer_id
         and mkt_res_id = rec_pm_130.s_id
         and status_cd = '1000'
         and area_id = 1;
      if v_tmp_1 = 0 then
        select seq_prod_offer_res_rel_id.nextval
          into v_res_rel_id
          from dual;
        insert into prod_offer_res_rel
        values
          (v_res_rel_id,
           v_prod_offer_id,
           rec_pm_130.s_id,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           1,
           null,
           null,
           null,
           null,
           rec_pm_130.res_type,
           v_remark);
        v_cnt_3 := v_cnt_3 + 1;
      else
        select max(prod_offer_res_rel_id)
          into v_res_rel_id
          from prod_offer_res_rel
         where prod_offer_id = v_prod_offer_id
           and mkt_res_id = rec_pm_130.s_id
           and status_cd = '1000'
           and area_id = 1;
      end if;

      v_cnt_bk := v_cnt_4;
      for v_area_id in 2 .. 10 loop
        select count(*)
          into v_tmp_2
          from prefer_mdse_price_spec_rela@lk_crmv1
         where rela_type = '130'
           and price_id = i_price_id
           and (mdse_spec_id = rec_pm_130.s_id or
               (mdse_spec_id = -1 and prod_spec_id = rec_pm_130.s_id))
           and state = '70A'
           and cfg_area_id = v_area_id;
        if v_tmp_2 > 0 then
          select count(*)
            into v_tmp_3
            from obj_area_rela
           where obj_id = v_res_rel_id
             and obj_class_id = 14
             and rela_area_id = v_area_id
             and status_cd = '1000';
          if v_tmp_3 = 0 then
            insert into obj_area_rela
            values
              (seq_obj_area_rela_id.nextval,
               14,
               v_res_rel_id,
               v_area_id,
               '10',
               1,
               1,
               '1000',
               sysdate,
               sysdate,
               -1,
               sysdate,
               -1,
               v_remark);
            v_cnt_4 := v_cnt_4 + 1;
          end if;
        else
          select count(*)
            into v_tmp_3
            from prefer_mdse_price_spec_rela@lk_crmv1
           where rela_type = '130'
             and (mdse_spec_id = rec_pm_130.s_id or
                 (mdse_spec_id = -1 and prod_spec_id = rec_pm_130.s_id))
             and state = '70A'
             and cfg_area_id = v_area_id;
          if v_tmp_3 = 0 then
            select count(*)
              into v_tmp_4
              from prefer_mdse_price_spec_rela@lk_crmv1
             where rela_type = '130'
               and price_id = i_price_id
               and (mdse_spec_id = rec_pm_130.s_id or
                   (mdse_spec_id = -1 and prod_spec_id = rec_pm_130.s_id))
               and state = '70A'
               and cfg_area_id = 1;
            if v_tmp_4 > 0 then
              select count(*)
                into v_tmp_5
                from obj_area_rela
               where obj_id = v_res_rel_id
                 and obj_class_id = 14
                 and rela_area_id = v_area_id
                 and status_cd = '1000';
              if v_tmp_5 = 0 then
                insert into obj_area_rela
                values
                  (seq_obj_area_rela_id.nextval,
                   14,
                   v_res_rel_id,
                   v_area_id,
                   '10',
                   1,
                   1,
                   '1000',
                   sysdate,
                   sysdate,
                   -1,
                   sysdate,
                   -1,
                   v_remark);
                v_cnt_4 := v_cnt_4 + 1;
              end if;
            end if;
          end if;
        end if;
      end loop;
      select count(*)
        into v_tmp_1
        from obj_area_rela
       where obj_class_id = 14
         and obj_id = v_res_rel_id
         and status_cd = '1000';
      if v_tmp_1 >= 9 then
        delete from obj_area_rela
         where obj_class_id = 14
           and obj_id = v_res_rel_id;
        v_cnt_4 := v_cnt_bk;
      end if;
    end if;
  end loop;

  for rec_so in cur_so loop
    select count(*)
      into v_tmp_1
      from offer_service_rel
     where prod_offer_id = v_prod_offer_id
       and service_offer_id = rec_so.service_offer_id
       and area_id = v_cre_area_id;
    if v_tmp_1 = 0 then
      insert into offer_service_rel
      values
        (seq_offer_service_rel_id.nextval,
         v_prod_offer_id,
         rec_so.service_offer_id,
         '1000',
         sysdate,
         sysdate,
         sysdate,
         v_cre_area_id,
         null,
         -1,
         -1,
         0,
         v_remark);
      v_cnt_5 := v_cnt_5 + 1;
    end if;
  end loop;

  o_msg := 'offer_prod_rel表插入了' || to_char(v_cnt_1) ||
           '条记录；prod_offer_rel表插入了' || to_char(v_cnt_2) ||
           '条记录；prod_offer_res_rel表插入了' || to_char(v_cnt_3) ||
           '条记录；obj_area_rela表插入了' || to_char(v_cnt_4) ||
           '条记录；offer_service_rel表插入了' || to_char(v_cnt_5) || '条记录。';
  return(v_cnt_1 + v_cnt_2 + v_cnt_3 + v_cnt_4 + v_cnt_5);

end;
/
