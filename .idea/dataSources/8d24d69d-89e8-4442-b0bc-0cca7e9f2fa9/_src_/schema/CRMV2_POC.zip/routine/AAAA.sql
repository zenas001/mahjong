CREATE procedure           aaaa as
  v_new_value varchar2(2000) := '';
  CURSOR c IS
    select * from attr_spec c
     where Upper(c.default_value) like '%HTTP%';
begin
  FOR rec IN c LOOP
  -- dbms_output.put_line(rec.java_code);
  v_new_value:='';
    select nvl(a.default_value,'')
      into v_new_value
      from attr_spec@ycold a
     where a.java_code = rec.java_code;
    if v_new_value != ''   then
      dbms_output.put_line(v_new_value);
    end if;
  END LOOP;

end;
/
