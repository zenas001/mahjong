CREATE PROCEDURE           CONTRACT_WARN IS
  cursor cur_yes is
    select contract_id
      from crmv1.contract a
     where a.exp_date < sysdate + 1
       and is_auto_continue = '1'
       and cust_type = 'partner'; --自动延续
  cursor cur_no is
    select contract_id, cust_id
      from crmv1.contract a
     where a.exp_date < sysdate + 1
       and is_auto_continue <> '1'
       and cust_type = 'partner'; --自动归档
begin
  for rec in cur_yes loop
    --更新合同失效时间增加2个月
    update crmv1.contract
       set exp_date = Add_months(exp_date, +2)
     where contract_id = rec.contract_id;
  end loop;
  commit;
  for rec1 in cur_no loop
    --更新合同状态为失效，流程状态为终止
    update crmv1.contract
       set state = '70X', flow_state = 'S800999'
     where contract_id = rec1.contract_id;
    --更新渠道资质信息未终止状态
    update crmv2.channel
       set status_cd = '12', status_date = sysdate
     where channel_id = rec1.cust_id;
    --更新社会渠道资质信息未终止状态
    update crmv2.third_party_chn_info
       set status_cd = '12', status_date = sysdate
     where channel_id = rec1.cust_id;
    --更新渠道资质信息未终止状态
    update crmv2.channel_applications
       set status_cd = '12', status_date = sysdate
     where channel_id = rec1.cust_id;
    --更新渠道信息
    insert into crmv2.channel_chg_info
      (qualification_chg_info_id,
       channel_id,
       channel_application_id,
       qualification_chg_type_cd,
       relationship_type_cd,
       apply_date,
       approved_date,
       approved_result,
       approved_result_cd,
       approved_by,
       area_id,
       region_cd,
       status_cd,
       status_date,
       create_date,
       create_staff,
       update_date,
       update_staff)
      select crmv2.seq_channel_chg_info_id.nextval,
             a.channel_id,
             b.channel_application_id,
             'ZZ',
             'DQ',
             sysdate,
             '',
             '',
             '',
             '',
             a.area_id,
             a.region_cd,
             '10',
             sysdate,
             sysdate,
             '3745', --默认 合同维护工号区别于接口自动终止
             sysdate,
             '3745' --默认 合同维护工号区别于接口自动终止
        from crmv2.channel a, crmv2.channel_applications b
       where a.channel_id = b.channel_id
         and a.channel_id = rec1.cust_id;
  end loop;
  commit;
end;
/
