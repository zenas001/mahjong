CREATE FUNCTION           FNC_REBUILD_FLOW(IN_PROCESS_DEF_NAME IN VARCHAR2,
                                            IN_PROCESS_DEF_KEY  IN VARCHAR2,
                                            IN_PRIVILEGE_ID     IN NUMBER,
                                            IN_ACTION_CD        IN VARCHAR2,
                                            IN_ACTION_NAME      IN VARCHAR2,
                                            IN_CLASS_ID         IN NUMBER,
                                            IN_WIN_CODE         IN VARCHAR2,
                                            IN_WIN_NAME         IN VARCHAR2)
  RETURN BOOLEAN IS
  V_RESULT         BOOLEAN := TRUE;
  V_PROCESS_DEF_ID INT;
  V_WIN_ID         INT;
  V_CNT            INT;
BEGIN
  --流程定义处理
  SELECT COUNT(*)
    INTO V_CNT
    FROM SYS_PROCESS_DEF
   WHERE PROCESS_DEF_KEY = IN_PROCESS_DEF_KEY;
  IF V_CNT = 0 THEN
    --获取流程定义ID
    SELECT SEQ_SYS_PROCESS_DEF_ID.NEXTVAL INTO V_PROCESS_DEF_ID FROM DUAL;
    --添加流程定义
    INSERT INTO SYS_PROCESS_DEF
      (PROCESS_DEF_ID,
       PROCESS_DEF_NAME,
       PROCESS_DEF_KEY,
       PRIVILEGE_ID,
       SHOW_LEVEL)
    VALUES
      (V_PROCESS_DEF_ID,
       IN_PROCESS_DEF_NAME,
       IN_PROCESS_DEF_KEY,
       IN_PRIVILEGE_ID,
       '1');
  ELSE
    UPDATE SYS_PROCESS_DEF
       SET PROCESS_DEF_NAME = IN_PROCESS_DEF_NAME,
           PRIVILEGE_ID     = IN_PRIVILEGE_ID
     WHERE PROCESS_DEF_KEY = IN_PROCESS_DEF_KEY;
    V_PROCESS_DEF_ID := IN_PROCESS_DEF_KEY;
  END IF;

  --流程事件处理
  SELECT COUNT(*)
    INTO V_CNT
    FROM SERVICE_OFFER
   WHERE SERVICE_OFFER_ID = IN_ACTION_CD;
  IF V_CNT = 0 THEN
    --添加流程事件
    INSERT INTO SERVICE_OFFER
      (SERVICE_OFFER_ID,
       ACTION_CD,
       STANDARD_CD,
       STATUS_CD,
       SERVICE_OFFER_NAME,
       OP_TYPE)
    VALUES
      (IN_ACTION_CD,
       IN_ACTION_CD,
       IN_ACTION_CD,
       '10',
       IN_ACTION_NAME,
       '10');
  ELSE
    UPDATE SERVICE_OFFER
       SET --ACTION_CD          = IN_ACTION_CD,(Unique故值修改时要唯一)
           STANDARD_CD        = IN_ACTION_CD,
           SERVICE_OFFER_NAME = IN_ACTION_NAME
     WHERE SERVICE_OFFER_ID = IN_ACTION_CD;
  END IF;

  --流程与领域对象关系处理
  SELECT COUNT(*)
    INTO V_CNT
    FROM SYS_CLASS_REL_OBJ
   WHERE CLASS_ID = IN_CLASS_ID
     AND EVENT_ID = IN_ACTION_CD
     AND OBJ_ID = V_PROCESS_DEF_ID
     AND OBJ_TYPE = 'FLW';
  IF V_CNT = 0 THEN
    --添加流程与领域对象的关系
    INSERT INTO SYS_CLASS_REL_OBJ
      (CLASS_OBJ_RELA_ID, CLASS_ID, EVENT_ID, OBJ_TYPE, OBJ_ID, STATUS_CD)
    VALUES
      (SEQ_SYS_CLASS_REL_OBJ_ID.NEXTVAL,
       IN_CLASS_ID,
       IN_ACTION_CD,
       'FLW',
       V_PROCESS_DEF_ID,
       '10');
  END IF;

  --流程窗体处理
  IF IN_WIN_CODE IS NOT NULL THEN
    SELECT COUNT(*)
      INTO V_CNT
      FROM SYS_WINDOW
     WHERE WIN_CODE = IN_WIN_CODE;
    IF V_CNT = 0 THEN
      --添加窗体
      SELECT SEQ_SYS_WINDOW_ID.NEXTVAL INTO V_WIN_ID FROM DUAL;
      INSERT INTO SYS_WINDOW
        (WIN_ID, WIN_CODE, WIN_NAME)
      VALUES
        (V_WIN_ID, IN_WIN_CODE, IN_WIN_NAME);
    ELSE
      SELECT WIN_ID
        INTO V_WIN_ID
        FROM SYS_WINDOW
       WHERE WIN_CODE = IN_WIN_CODE;
    END IF;

    --流程与窗体关系处理
    SELECT COUNT(*)
      INTO V_CNT
      FROM SYS_CLASS_REL_OBJ
     WHERE CLASS_ID = '67785'
       AND EVENT_ID = '101'
       AND OBJ_TYPE = 'WIN'
       AND OBJ_ID = V_WIN_ID
       AND SUB_CLASS_ID = V_PROCESS_DEF_ID;
    IF V_CNT = 0 THEN
      --添加流程与窗体的关系
      INSERT INTO SYS_CLASS_REL_OBJ
        (CLASS_OBJ_RELA_ID,
         CLASS_ID,
         EVENT_ID,
         OBJ_TYPE,
         OBJ_ID,
         STATUS_CD,
         SUB_CLASS_ID)
      VALUES
        (SEQ_SYS_CLASS_REL_OBJ_ID.NEXTVAL,
         '67785',
         '101',
         'WIN',
         V_WIN_ID,
         '10',
         V_PROCESS_DEF_ID);
    END IF;
  END IF;

  COMMIT;
  RETURN(V_RESULT);
EXCEPTION
  WHEN OTHERS THEN
    V_RESULT := FALSE;
    RETURN(V_RESULT);
END FNC_REBUILD_FLOW;
/
