CREATE function           chk_lan_nbr_exists(in_product_id   integer,
                                              in_acc_nbr      string,
                                              in_prod_inst_id long)
  return integer is
  i_count           integer;
  rule_result_pass  varchar2(10) := '1';
  rule_result_error varchar2(10) := '0';
begin
  if in_acc_nbr is null or in_acc_nbr = '' then
    return rule_result_pass;
  end if;

  select count(*)
    into i_count
    from prod_inst a
   where a.acc_nbr = in_acc_nbr
     and prod_inst_id <> in_prod_inst_id
     and a.product_id = in_product_id;

  if (i_count > 0) then
    return rule_result_error;
  end if;
  return rule_result_pass;
end;
/
