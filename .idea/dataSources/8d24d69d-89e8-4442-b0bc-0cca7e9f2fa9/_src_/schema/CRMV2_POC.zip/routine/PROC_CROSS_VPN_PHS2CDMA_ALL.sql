CREATE procedure           proc_cross_vpn_phs2cdma_all
is
  /**
   功能说明：核对互拨免费套餐数据信息
   author：luxb
   创建时间：2012-7-19
  **/
  i_area_code varchar2(10);
  i_mdse_count  number;
  i_mdse_id     number;
  i_acc_nbr     varchar2(100);
  i_prod_type   varchar2(10);
  i_vpn_count   number;
  v_truncateString varchar2(100);
  v_prod_count number;
  cursor i_prod_offer_inst  is
  select poi.region_cd, poi.prod_offer_inst_id, poi.service_nbr
  from prod_offer_inst poi, attr_value av
 where poi.prod_offer_id = av.attr_value
   and exists (select 1
          from sys_class t, attr_spec a
         where t.java_code = 'AssiAttrSpecConfig'
           and t.class_id = a.class_id
           and a.java_code = 'vpnHPoId'
           and av.attr_id = a.attr_id)
    and poi.service_nbr is not null;
   cursor i_vpn_tmp is
   select vpn_id, vpn_type, area_code, service_code from vpn_psh2cdma_tmp;
begin
   v_truncateString :='truncate table vpn_psh2cdma_tmp';
   --循环遍历获取关联关系
   for poir in i_prod_offer_inst loop
      --vpn临时表数据清空
      execute immediate v_truncateString;
      select area_code into i_area_code from area_code where region_id = poir.region_cd;
      select count(1) into i_mdse_count
        from crm.mdse@lk_tocrm1_cross c
       where c.mdse_serv_number is not null
         and c.mdse_serv_number = poir.service_nbr
         and c.mdse_type = '105';
       if i_mdse_count > 0 then
      select mdse_id into i_mdse_id
        from crm.mdse@lk_tocrm1_cross c
       where c.mdse_serv_number is not null
         and c.mdse_serv_number = poir.service_nbr
         and c.mdse_type = '105';
       --获取群组套餐下的成员
      DECLARE
       cursor i_offer_prod_inst_rel is
       select r.prod_inst_id
         from offer_prod_inst_rel r
        where r.prod_offer_inst_id = poir.prod_offer_inst_id;
       begin
       for opir in i_offer_prod_inst_rel loop
       select count(1) into v_prod_count from prod_inst where prod_inst_id = opir.prod_inst_id;
       if v_prod_count > 0 then
       select pi.acc_nbr,product_type
         into i_acc_nbr,i_prod_type
         from prod_inst pi, product p
        where pi.prod_inst_id = opir.prod_inst_id
          and p.product_id = pi.product_id;
       --群组产品
       if i_prod_type = '13' then
       DECLARE
          cursor i_prod_inst_rel is
          select r.prod_inst_z_id,pi.acc_nbr
          from prod_inst_rel r,prod_inst pi,product p
           where r.prod_inst_a_id = opir.prod_inst_id
            and r.prod_inst_z_id = pi.prod_inst_id
            and pi.product_id = p.product_id
            and p.product_type = '10'
            and r.relation_type_cd='100300';
            begin
          for pir in i_prod_inst_rel loop
            insert into vpn_psh2cdma_tmp
            (vpn_id,
             vpn_type,
             area_code,
             service_code)
             values
             (i_mdse_id,
             '-99',
             '0591',
             pir.acc_nbr);
          end loop;
          end;
       else
        insert into vpn_psh2cdma_tmp
        (vpn_id,
         vpn_type,
         area_code,
         service_code)
         values
         (i_mdse_id,
         '-99',
         '0591',
         i_acc_nbr);
       end if;
       end if;
       end loop;
       end;
       end if;
   for v in i_vpn_tmp loop
     select count(1) into i_vpn_count
       from crm.vpn_phs2cdma@lk_tocrm1_cross
      where vpn_id = i_mdse_id
        and service_code = v.service_code;
     if i_vpn_count = 0 then
     insert into crm.vpn_phs2cdma@lk_tocrm1_cross
     (member_id,
      vpn_id,
      vpn_type,
      area_code,
      service_code,
      mdse_id,
      eff_date,
      exp_date,
      create_date,
      real_modify_date)
     values(
      crm.vpn_phs2cdma_id_seq.nextval@lk_tocrm1_cross,
      i_mdse_id,
      -99,
      '0591',
      v.service_code,
      null,
      sysdate,
      to_date('2199/1/1','yyyy-MM-dd'),
      sysdate,
      sysdate
     );
     end if;
   end loop;
   DECLARE
     cursor i_vpn is
     select vpn_id,service_code
       from crm.vpn_phs2cdma@lk_tocrm1_cross where vpn_id = i_mdse_id;
   begin
     for vpn in i_vpn loop
      select count(1) into i_vpn_count
       from vpn_psh2cdma_tmp
       where vpn_id = i_mdse_id
         and service_code = vpn.service_code;
      if i_vpn_count = 0 then
        insert into crm.vpn_phs2cdma_his@lk_tocrm1_cross
      (his_id,
       member_id,
       vpn_id,
       area_code,
       service_code,
       mdse_id,
       eff_date,
       exp_date,
       create_dat,
       real_modify_date,
       vpn_type)
  select crm.vpn_phs2cdma_his_id_seq.nextval@lk_tocrm1_cross,
         member_id,
         vpn_id,
         area_code,
         service_code,
         decode(mdse_id,'',0,mdse_id),
         eff_date,
         exp_date,
         create_date,
         real_modify_date,
         vpn_type
    from crm.vpn_phs2cdma@lk_tocrm1_cross
   where vpn_id = i_mdse_id
     and service_code = vpn.service_code
     and vpn_type = '-99';
   delete from crm.vpn_phs2cdma@lk_tocrm1_cross
    where vpn_id = i_mdse_id
      and service_code = vpn.service_code
      and area_code = '0591'
      and vpn_type = '-99';
      end if;
     end loop;
   end;
   end loop;
   commit;
end;
/
