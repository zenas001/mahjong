CREATE procedure           proc_add_attr_value_2(i_java_code      varchar2,
                                                i_attr_java_code         varchar2,
                                                i_attr_value      varchar2,
                                                i_attr_value_name varchar2) is

  v_class_id      number;
  v_attr_id       number;
  v_attr_value_id number;
begin
  select a.class_id
    into v_class_id
    from sys_class a
   where a.java_code = i_java_code;

  select b.attr_id
    into v_attr_id
    from attr_spec b
   where b.class_id = v_class_id
     and b.java_code = i_attr_java_code;

  insert into attr_value
    (attr_value_id,
     attr_value,
     attr_value_name,
     attr_id,
     create_date,
     status_cd,
     status_date)
  values
    (seq_attr_value_id.nextval,
     i_attr_value,
     i_attr_value_name,
     v_attr_id,
     sysdate,
     '1000',
     sysdate);

  commit;
end proc_add_attr_value_2;



begin
  -- Call the procedure
  proc_add_attr_value_2('AttrSpec',
                      'attrValueCode',
                      'M',
                      '整型(金额)');
end;
/
