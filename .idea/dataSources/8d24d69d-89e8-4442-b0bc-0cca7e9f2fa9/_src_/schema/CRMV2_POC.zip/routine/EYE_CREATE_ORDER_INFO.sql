CREATE procedure           eye_create_order_info is
  v_sum_time        number(12) := 0;
  v_sum_bus_time        number(12) := 0;
  v_order_id        number(12) := 0;
  v_product_id      number(12) := 0;
  v_proc_code       varchar2(30) := '';
  v_proc_name       varchar2(30) := '';
  v_prod_offer_id   varchar2(30) := '';
  v_product_name    varchar2(256) := '';
  v_prod_offer_name varchar2(256) := '';
  v_package_group   varchar2(128) := '';
  v_cust_so_number  varchar2(128) := '';
  v_count           number(12) := 0;
  v_is_zh           number(12) := 0;
  v_is_other           number(12) := 0;
  v_channel_name varchar2(128) := '';

begin
  for cur in (select distinct CUST_SO_NUMBER, EXT_CUST_SO_NUMBER, channel_id
                from eye_order_node a where
               -- a.cust_so_number='FJ2015092255453855'
                a.CUST_SO_NUMBER is null or
                not exists
               (select 1
                        from eye_order_info b
                       where b.CUST_SO_NUMBER = a.CUST_SO_NUMBER)) loop
    v_channel_name:='营业前台';
    /**********接口*************************/
     if cur.channel_id = 'sale002' then
        continue;
     end if;
    if cur.channel_id = 'intf001' then
      v_channel_name:='接口';
      select count(1)
        into v_count
        from (select i.package_group
                from crmv2.intf_dep_order i
               where i.ext_cust_so_number = cur.EXT_CUST_SO_NUMBER
              union
              select i.package_group
                from crmv2.intf_dep_order_his i
               where i.ext_cust_so_number = cur.EXT_CUST_SO_NUMBER) a;
      if v_count >= 1 then
        select package_group
          into v_package_group
          from (select i.package_group
                  from crmv2.intf_dep_order i
                 where i.ext_cust_so_number = cur.EXT_CUST_SO_NUMBER
                union
                select i.package_group
                  from crmv2.intf_dep_order_his i
                 where i.ext_cust_so_number = cur.EXT_CUST_SO_NUMBER) a
         where rownum = 1;
      else
        continue;
      end if;
      select count(1)
        into v_count
        from (select i.cust_so_number
                from crmv2.intf_dep_finish i
               where i.package_group = v_package_group
              union
              select i.cust_so_number
                from crmv2.intf_dep_finish i
               where i.package_group = v_package_group) a;
      if v_count >= 1 then
        select cust_so_number
          into v_cust_so_number
          from (select i.cust_so_number
                  from crmv2.intf_dep_finish i
                 where i.package_group = v_package_group
                union
                select i.cust_so_number
                  from crmv2.intf_dep_finish i
                 where i.package_group = v_package_group) a where rownum=1;
      else
        continue;
      end if;
      update  eye_order_node set cust_so_number=v_cust_so_number where EXT_CUST_SO_NUMBER=cur.cust_so_number;
    else
      v_cust_so_number := cur.cust_so_number;
    end if;
    /****************************************/

    select sum(ELAPSED_TIME)
      into v_sum_time
      from eye_order_node a
     where a.CUST_SO_NUMBER = v_cust_so_number and a.channel_id in('intf001','sale001') ;
     select (max(a.start_time)-min(a.start_time))*24*3600*1000
      into v_sum_bus_time
      from eye_order_node a
     where a.CUST_SO_NUMBER = v_cust_so_number and a.channel_id in('intf001','sale001') ;

    select count(1)
      into v_count
      from business_list
     where cust_so_number = v_cust_so_number
       --and product_id is null
       ;
    if v_count >= 1 then

      select cust_order_id,
             prod_offer_id,
             service_offer_name,
             service_offer_id
        into v_order_id, v_prod_offer_id, v_proc_name, v_proc_code
        from business_list
       where cust_so_number = v_cust_so_number
         --and product_id is null
         and rownum = 1;
      select count(1)
        into v_is_zh
        from eye_busi_conf a
       where a.spec_id = v_prod_offer_id
         and a.busi_code = 'FUSION';

      /*非融合销售品*/
      if v_is_zh=0 then
     select count(1)
       into v_is_other
       from business_list
      where cust_so_number = v_cust_so_number
        and product_id is not null;

        if v_is_other=1 then
          select count(1)
            into v_count
            from business_list
           where cust_so_number = cur.cust_so_number
             and product_id is not null;
          if v_count >= 1 then
            select product_id
              into v_product_id
              from business_list
             where cust_so_number = v_cust_so_number
               and product_id is not null
               and rownum = 1;
          end if;

          select count(1)
            into v_count
            from product
           where product_id = v_product_id;
          if v_count >= 1  then
            select product_name
              into v_product_name
              from product
             where product_id = v_product_id
               and rownum = 1;
          end if;
        else
         v_product_id:=100000000;
         v_product_name:='其他';
        end if;/*if v_is_other=1 then*/
    end if;


    /*end 非融合销售品 */

      select count(1)
        into v_count
        from prod_offer
       where prod_offer_id = v_prod_offer_id;
      if v_count >= 1 then
        select prod_offer_name
          into v_prod_offer_name
          from prod_offer
         where prod_offer_id = v_prod_offer_id
           and rownum = 1;
      end if;

      insert into eye_order_info
        (cust_so_number,
         ext_cust_so_number,
         order_id,
         product_id,
         proc_code,
         sum_elapsed_time,
         bus_elapsed_time,
         create_order_time,
         create_time,
         track_host,
         requester,
         CHANNEL_ID,
         PROD_OFFER_ID,
         OFFER_NAME,
         PRODUCT_NAME,
         PROC_NAME,
         CHANNEL_NAME,P_STATE)
        select cust_so_number,
               ext_cust_so_number,
               v_order_id,
               v_product_id,
               v_proc_code,
               v_sum_time,
               v_sum_bus_time,
               start_time,
               sysdate,
               track_host,
               requester,
               channel_id,
               v_prod_offer_id,
               v_prod_offer_name,
               v_product_name,
               v_proc_name,
               v_channel_name,'001'
          from eye_order_node a
         where a.CUST_SO_NUMBER = v_cust_so_number
           and rownum = 1
         order by start_time desc;
    end if;
  end loop;

end eye_create_order_info;
/
