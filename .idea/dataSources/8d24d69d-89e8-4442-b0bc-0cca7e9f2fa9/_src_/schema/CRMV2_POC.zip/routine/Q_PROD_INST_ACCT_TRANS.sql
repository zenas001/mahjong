CREATE PROCEDURE           Q_PROD_INST_ACCT_TRANS(i_order_item_id IN NUMBER,
                                 I_ACTION_TYPE   IN VARCHAR) IS
  V_PROD_INST_ACCT_SEQ NUMBER;
  V_CUST_ORDER_ID NUMBER;
  C_ACTION_ADD CONSTANT VARCHAR2(5) := 'ADD';
  C_ACTION_MOD CONSTANT VARCHAR2(5) := 'MOD';
  C_ACTION_DEL CONSTANT VARCHAR2(5) := 'DEL';
  C_ACTION_KIP CONSTANT VARCHAR2(5) := 'KIP';
BEGIN
  V_PROD_INST_ACCT_SEQ := SEQ_AUTOTEST_PROD_INST_ACCT_ID.NEXTVAL;
  select cust_order_id INTO V_CUST_ORDER_ID from crmv2.order_item_his where order_item_id = i_order_item_id and rownum<2 ;
  IF I_ACTION_TYPE = C_ACTION_ADD THEN
    --add
    insert into autotest_prod_inst_acct
      (AUTOTEST_PROD_INST_ACCT_ID,
       CUST_ORDER_ID,
       ACCOUNT_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       CHARGE_TYPE,
       ACTION,
       CREATE_DATE)
      select V_PROD_INST_ACCT_SEQ,
             V_CUST_ORDER_ID,
             ACCOUNT_ID,
             PROD_INST_ID,
             PAYMENT_LIMIT_TYPE,
             PAYMENT_LIMIT,
             CHARGE_TYPE,
             C_ACTION_ADD         ACTION,
             SYSDATE              CREATE_DATE
        from CRMV2.PROD_INST_ACCT A
       where A.ACCOUNT_ID =
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'ACCOUNT_ID',
                                i_order_item_id);

  ELSIF I_ACTION_TYPE = C_ACTION_MOD THEN
    --mod
    insert into autotest_prod_inst_acct
      (AUTOTEST_PROD_INST_ACCT_ID,
       CUST_ORDER_ID,
       ACCOUNT_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       CHARGE_TYPE,
       ACTION,
       CREATE_DATE)
      select V_PROD_INST_ACCT_SEQ,
             V_CUST_ORDER_ID,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'ACCOUNT_ID',
                                i_order_item_id) ACCOUNT_ID,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'PROD_INST_ID',
                                i_order_item_id) PROD_INST_ID,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'PAYMENT_LIMIT_TYPE',
                                i_order_item_id) PAYMENT_LIMIT_TYPE,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'PAYMENT_LIMIT',
                                i_order_item_id) PAYMENT_LIMIT,
             qianty_f_get_value('AUTOTEST_PROD_INST_ACCT',
                                'CHARGE_TYPE',
                                i_order_item_id) CHARGE_TYPE,
             C_ACTION_MOD ACTION,
             SYSDATE CREATE_DATE
        from dual;
  ELSE
    --del
    INSERT INTO autotest_prod_inst_acct
      (AUTOTEST_PROD_INST_ACCT_ID,
       CUST_ORDER_ID,
       ACCOUNT_ID,
       PROD_INST_ID,
       PAYMENT_LIMIT_TYPE,
       PAYMENT_LIMIT,
       CHARGE_TYPE,
       ACTION,
       CREATE_DATE)
      SELECT V_PROD_INST_ACCT_SEQ,
             V_CUST_ORDER_ID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             C_ACTION_DEL,
             SYSDATE
        FROM DUAL;

  END IF;

END Q_PROD_INST_ACCT_TRANS;
/
