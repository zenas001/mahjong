CREATE function           qianty_t
  return varchar2 is
  Result varchar2(800);
    Result2 varchar2(800);
  t      varchar2(80);
  v_sql  varchar2(2000);
  a  varchar2(80);
 -- v_sql2 varchar2(2000);
BEGIN
    execute immediate 'select party_name from party where party_id = 2137427'
INTO Result2  ;
DBMS_OUTPUT.put_line(Result2);
    return(Result2);

exception
  when NO_DATA_FOUND then
    Result := '';
    return(Result);

end qianty_t;

  --select qianty_f_get_value('AUTOTEST_CUST','CONTACT_NAME',149388433) from dual
/
