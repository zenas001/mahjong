CREATE procedure           p_clear_attr_value_offer(i_old_value in varchar2,
                                                     i_new_value in varchar2) is
begin
  update prod_offer_attr_value a
     set a.attr_value_id = i_new_value
   where a.attr_value_id = i_old_value;

  update prod_offer_inst_attr a
     set a.attr_value_id = i_new_value
   where a.attr_value_id = i_old_value;

  delete from attr_value a where a.attr_value_id = i_old_value;

  update crmgc.archive_gj_code_conv a
     set new_code = i_new_value
   where a.field_name = 'MDSE_PARAM_ID'
     and a.type_id = 'ATTR_VALUE_ID'
     and a.new_code = i_old_value;
  commit;
end p_clear_attr_value_offer;
/
