CREATE procedure           update_order_item_no_bill(cust_so_num in varchar2,
                                                      o_result    out varchar2,
                                                      o_msg       out varchar2) is
  i_num_count number := 0;
  l_sql varchar2(255);
begin
  select count(1)
    into i_num_count
    from customer_order t
   where t.cust_so_number = cust_so_num;
  if i_num_count > 0 then
    update order_item oi
       set oi.pre_handle_flag = 'Y01'
     where exists (select 1
              from customer_order co
             where co.cust_so_number = cust_so_num
               and co.cust_order_id = oi.cust_order_id);
    o_result := '1';
    o_msg := '订单' || cust_so_num || '的订单项的不增量计费修改成功！';
  else
    o_result := '0';
    o_msg := '订单' || cust_so_num || '不存在！';
  end if;
exception
  when others then
    o_result := '0';
     l_sql:=sqlerrm;
    o_msg := '异常'||l_sql;
end;
/
