CREATE PROCEDURE           Q_CUST_TRANS(i_order_item_id IN NUMBER,
                                         I_ACTION_TYPE   IN VARCHAR) IS
  V_CUST_SEQ NUMBER;
  V_CUST_ORDER_ID NUMBER;
  C_ACTION_ADD CONSTANT VARCHAR2(5) := 'ADD';
  C_ACTION_MOD CONSTANT VARCHAR2(5) := 'MOD';
  C_ACTION_DEL CONSTANT VARCHAR2(5) := 'DEL';
  C_ACTION_KIP CONSTANT VARCHAR2(5) := 'KIP';

BEGIN
  V_CUST_SEQ := SEQ_AUTOTEST_CUST_ID.NEXTVAL;
  select cust_order_id INTO V_CUST_ORDER_ID from crmv2.order_item_his where order_item_id = i_order_item_id and rownum<2;
  IF I_ACTION_TYPE = C_ACTION_ADD THEN
    --1.add
    INSERT INTO CRMV2.AUTOTEST_CUST
      (AUTOTEST_CUST_ID,
       CUST_ORDER_ID,
       CUST_ID,
       CUST_NAME,
       CUST_TYPE,
       CUST_ADDRESS,
       CERT_TYPE,
       CERT_NUMBER,
       CERT_ADDRESS,
       CUST_AREA_GRADE,
       CONTACT_NAME,
       CONTACT_PHONE,
       LAN_ID,
       IS_CARD_READER,
       PARTY_PHOTO,
       ESALE_PHOTO,
       ACTION,
       VIRTUAL_CUST_ID,
       CREATE_DATE)
      SELECT V_CUST_SEQ,
             V_CUST_ORDER_ID CUST_ORDER_ID,
             A.CUST_ID,
             B.PARTY_NAME CUST_NAME,
             A.CUST_TYPE,
             A.CUST_ADDRESS,
             (SELECT C.CERT_TYPE
                FROM CRMV2.PARTY_CERTIFICATION C
               WHERE C.PARTY_ID = B.PARTY_ID) CERT_TYPE,
             (SELECT C1.CERT_NUMBER
                FROM CRMV2.PARTY_CERTIFICATION C1
               WHERE C1.PARTY_ID = B.PARTY_ID) CERT_NUMBER,
             (SELECT C2.CERT_ADDRESS
                FROM CRMV2.PARTY_CERTIFICATION C2
               WHERE C2.PARTY_ID = B.PARTY_ID) CERT_ADDRESS,
             A.CUST_AREA_GRADE,
             (SELECT PCI.CONTACT_NAME
                FROM CRMV2.PARTY_CONTACT_INFO PCI
               WHERE PCI.PARTY_ID = B.PARTY_ID
                 AND ROWNUM < 2) CONTACT_NAME,
             (SELECT NVL(NVL(PCI1.MOBILE_PHONE, PCI1.HOME_PHONE),
                         PCI1.OFFICE_PHONE)
                FROM CRMV2.PARTY_CONTACT_INFO PCI1
               WHERE PCI1.PARTY_ID = B.PARTY_ID
                 AND ROWNUM < 2) CONTACT_PHONE,
             (SELECT AC.AREA_CODE
                FROM CRMV2.AREA_CODE AC
               WHERE AC.AREA_CODE_ID = B.AREA_ID) LAN_ID,
             (SELECT COUNT(1)
                FROM CRMV2.CUST_EXTERNAL_ATTR D
               WHERE D.ATTR_ID = 950006547
                 AND D.CUST_ID = A.CUST_ID) IS_CARD_READER,
             NULL PARTY_PHOTO,
             NULL ESALE_PHOTO,
             C_ACTION_ADD ACTION,
             NULL VIRTUAL_CUST_ID,
             SYSDATE CREATE_DATE
        FROM CRMV2.CUST A, CRMV2.PARTY B
       WHERE A.PARTY_ID = B.PARTY_ID
         AND A.CUST_ID =
             (select cust_id
                from crmv2.CUSTOMER_ORDER_his
               where cust_order_id = V_CUST_ORDER_ID);
    --客户属性
    INSERT INTO AUTOTEST_CUST_ATTR
      (AUTOTEST_CUST_ATTR_ID,
       AUTOTEST_CUST_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE,
       CREATE_DATE)
      SELECT SEQ_AUTOTEST_CUST_ATTR_ID.NEXTVAL,
             V_CUST_SEQ,
             AC.EXT_ATTR_NBR,
             CEA.ATTR_VALUE,
             SYSDATE
        FROM CUST_EXTERNAL_ATTR CEA, ATTR_SPEC AC
       WHERE CEA.ATTR_ID = AC.ATTR_ID
         AND CEA.CUST_ID =
             (select cust_id
                from crmv2.CUSTOMER_ORDER_his
               where cust_order_id = V_CUST_ORDER_ID);

  ELSIF I_ACTION_TYPE = C_ACTION_MOD THEN
    --2.mod
    INSERT INTO CRMV2.AUTOTEST_CUST
      (AUTOTEST_CUST_ID,
       CUST_ORDER_ID,
       CUST_ID,
       CUST_NAME,
       CUST_TYPE,
       CUST_ADDRESS,
       CERT_TYPE,
       CERT_NUMBER,
       CERT_ADDRESS,
       CUST_AREA_GRADE,
       CONTACT_NAME,
       CONTACT_PHONE,
       LAN_ID,
       IS_CARD_READER,
       PARTY_PHOTO,
       ESALE_PHOTO,
       ACTION,
       VIRTUAL_CUST_ID,
       CREATE_DATE)
      select V_CUST_SEQ,
             CUST_ORDER_ID,
             CUST_ID,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CUST_NAEM',
                                i_order_item_id) CUST_NAEM,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CUST_TYPE',
                                i_order_item_id) CUST_TYPE,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CUST_ADDRESS',
                                i_order_item_id) CUST_ADDRESS,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CERT_TYPE',
                                i_order_item_id) CERT_TYPE,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CERT_NUMBER',
                                i_order_item_id) CERT_NUMBER,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CERT_ADDRESS',
                                i_order_item_id) CERT_ADDRESS,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CUST_AREA_GRADE',
                                i_order_item_id) CUST_AREA_GRADE,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CONTACT_NAME',
                                i_order_item_id) CONTACT_NAME,
             qianty_f_get_value('AUTOTEST_CUST',
                                'CONTACT_PHONE',
                                i_order_item_id) CONTACT_PHONE,
             qianty_f_get_value('AUTOTEST_CUST', 'LAN_ID', i_order_item_id) LAN_ID,
             qianty_f_get_value('AUTOTEST_CUST',
                                'IS_CARD_READER',
                                i_order_item_id) IS_CARD_READER,
             '' PARTY_PHOTO,
             '' ESALE_PHOTO,
             C_ACTION_MOD ACTION,
             '' VIRTUAL_CUST_ID,
             sysdate CREATE_DATE
        from crmv2.CUSTOMER_ORDER_his
       where cust_order_id = V_CUST_ORDER_ID;
    --客户属性(只处理客户扩展属性信息)

    INSERT INTO AUTOTEST_CUST_ATTR
      (AUTOTEST_CUST_ATTR_ID,
       AUTOTEST_CUST_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE,
       CREATE_DATE)
      select SEQ_AUTOTEST_CUST_ATTR_ID.NEXTVAL,
             V_CUST_SEQ,
             b.ext_attr_nbr,
             a.new_value,
             SYSDATE
        from order_item_proc_attr_his a, ATTR_SPEC b
       where a.order_item_id = i_order_item_id
         and a.class_id = 1
         and a.obj_attr_id = b.attr_id;

  ELSE
    --不变
    INSERT INTO CRMV2.AUTOTEST_CUST
      (AUTOTEST_CUST_ID,
       CUST_ORDER_ID,
       CUST_ID,
       CUST_NAME,
       CUST_TYPE,
       CUST_ADDRESS,
       CERT_TYPE,
       CERT_NUMBER,
       CERT_ADDRESS,
       CUST_AREA_GRADE,
       CONTACT_NAME,
       CONTACT_PHONE,
       LAN_ID,
       IS_CARD_READER,
       PARTY_PHOTO,
       ESALE_PHOTO,
       ACTION,
       VIRTUAL_CUST_ID,
       CREATE_DATE)
      select V_CUST_SEQ,
             CUST_ORDER_ID,
             cust_id,
             '' CUST_NAME,
             '' CUST_TYPE,
             '' CUST_ADDRESS,
             '' CERT_TYPE,
             '' CERT_NUMBER,
             '' CERT_ADDRESS,
             '' CUST_AREA_GRADE,
             '' CONTACT_NAME,
             '' CONTACT_PHONE,
             '' LAN_ID,
             '' IS_CARD_READER,
             '' PARTY_PHOTO,
             '' ESALE_PHOTO,
             C_ACTION_KIP ACTION,
             '' VIRTUAL_CUST_ID,
             sysdate CREATE_DATE
        from crmv2.CUSTOMER_ORDER_his
       where cust_order_id =V_CUST_ORDER_ID;

  END IF;

  DBMS_OUTPUT.PUT_LINE('exec CUST_TRANS i_order_item_id->' ||
                       i_order_item_id);
END Q_CUST_TRANS;
/
