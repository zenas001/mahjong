CREATE procedure           proc_ppm_sync_offer_rel_to_it(v_prod_offer_id  in varchar2, v_area_id in varchar2,v_request_inst_id in varchar2,v_cust_order_id in varchar2,o_result out varchar2)

as
v_offer_order_item_id number;
v_attr_value_id number;
v_offer_type varchar2(10);
v_timestamp number;
begin
SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 +
       TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) into v_timestamp
  FROM DUAL;

-- 导入原始的数据 (A端)
 insert into sync_prod_offer_rel( REQUEST_TIMESTAMP, SYNC_PROD_OFFER_REL_ID , REQUEST_INST_ID , PROD_OFFER_RELA_ID,PROD_OFFER_RELA_ID_OLD ,RELATION_TYPE_CD, BUSINESS_OFFER_A_ID , BUSINESS_OFFER_Z_ID , CATALOG_ITEM_ID, REL_DIRECTION,status_cd)
 SELECT v_timestamp, seq_sync_prod_offer_rel_id.nextval , v_request_inst_id , rel.prod_offer_rela_id, rel.prod_offer_rela_id ,rel.relation_type_cd, rel.offer_a_id , rel.offer_z_id , rel.catalog_item_id, 'AZ',rel.status_cd
 FROM ppm_prod_offer_rel rel WHERE rel.offer_a_id = v_prod_offer_id;
 -- 导入原始数据（Z端）
 insert into sync_prod_offer_rel( REQUEST_TIMESTAMP, SYNC_PROD_OFFER_REL_ID , REQUEST_INST_ID , PROD_OFFER_RELA_ID, PROD_OFFER_RELA_ID_OLD  ,RELATION_TYPE_CD, BUSINESS_OFFER_A_ID , BUSINESS_OFFER_Z_ID , CATALOG_ITEM_ID, REL_DIRECTION,status_cd )
 SELECT v_timestamp, seq_sync_prod_offer_rel_id.nextval , v_request_inst_id , rel.prod_offer_rela_id, rel.prod_offer_rela_id,rel.relation_type_cd , rel.offer_a_id , rel.offer_z_id , rel.catalog_item_id, 'ZA',rel.status_cd
 FROM ppm_prod_offer_rel rel WHERE rel.offer_z_id = v_prod_offer_id;

 if v_cust_order_id is not null then
    -- 获取失效的关联关系
    update sync_prod_offer_rel rel set rel.status_cd = '1100'
    WHERE rel.prod_offer_rela_id IN (
      SELECT p.obj_inst_id FROM order_item_proc_attr p,order_item t
      WHERE t.cust_order_id = v_cust_order_id
      and   t.class_id = (SELECT sc.class_id FROM sys_class sc WHERE sc.java_code = 'PpmProdOffer')
      and   t.order_item_id = p.order_item_id
      and   p.obj_attr IN ( 'prodOfferARels','prodOfferZRels' )
      and   p.operate = '12'
     ) and rel.request_inst_id = v_request_inst_id and rel.request_timestamp = v_timestamp ;
 end if;

 -- 所有创建状态的关联关系置成失效
 update sync_prod_offer_rel rel
    set rel.status_cd = '1000'
  WHERE rel.status_cd = '1299'
    and rel.request_timestamp = v_timestamp;

 -- 获取目录下所有的关联关系数据
 for r1 IN (  SELECT rel.* FROM ppm_prod_offer_rel rel WHERE rel.offer_a_id = v_prod_offer_id and rel.catalog_item_id is not null ) loop
     insert into sync_prod_offer_rel( REQUEST_TIMESTAMP,SYNC_PROD_OFFER_REL_ID , REQUEST_INST_ID , PROD_OFFER_RELA_ID, PROD_OFFER_RELA_ID_OLD,RELATION_TYPE_CD , BUSINESS_OFFER_A_ID , BUSINESS_OFFER_Z_ID , CATALOG_ITEM_ID, REL_DIRECTION,status_cd)
     SELECT v_timestamp,  seq_sync_prod_offer_rel_id.nextval , v_request_inst_id , seq_prod_offer_rel_id.nextval,r1.prod_offer_rela_id,r1.relation_type_cd , r1.offer_a_id , p.prod_offer_id , r1.catalog_item_id, 'AZZ',r1.status_cd
     FROM (
            SELECT r1.catalog_item_id main_caltalog_item_id,t.catalog_item_id sub_catalog_item_id FROM catalog_item t start with t.catalog_item_id = r1.catalog_item_id connect by prior t.catalog_item_id = t.up_catalog_item_id
           ) sub_catalog_item, ppm_catalog_item_element pe, ppm_prod_offer p
     where sub_catalog_item.sub_catalog_item_id = pe.catalog_item_id
     and   pe.prod_offer_id = p.prod_offer_id
     and   p.status_cd != '1100'
    ;
 end loop;
-- 更新关联目录下的销售品状态
 update sync_prod_offer_rel rel set rel.status_cd = (
 SELECT rel2.status_cd FROM sync_prod_offer_rel rel2
 WHERE rel2.catalog_item_id = rel.catalog_item_id
  and rel2.business_offer_z_id is null and rownum=1
  and rel2.request_inst_id = v_request_inst_id
  and rel2.prod_offer_rela_id_old = rel.prod_offer_rela_id_old
  and rel2.status_cd !='1300'
  and rel2.request_timestamp = v_timestamp
 )
 WHERE rel.catalog_item_id is not null
 and rel.business_offer_z_id is not null
 and rel.request_inst_id = v_request_inst_id
 and rel.request_timestamp = v_timestamp
 ;

 --更新A端,通过映射表
update sync_prod_offer_rel rel
   set rel.it_offer_z_id = rel.business_offer_z_id,
       rel.it_offer_a_id = (SELECT rel2.it_id
                              FROM it_business_rel rel2
                             WHERE rel2.business_id = rel.business_offer_a_id
                               and rel2.rel_type = 'offer'
                               and rownum = 1)
 WHERE rel.business_offer_z_id = v_prod_offer_id
   and rel.business_offer_a_id IN
       (SELECT rel2.business_id
          FROM it_business_rel rel2
         WHERE rel2.business_id = rel.business_offer_a_id
           and rel2.rel_type = 'offer')
   and rel.request_inst_id = v_request_inst_id
   and rel.request_timestamp = v_timestamp
   ;

 --更新Z端,通过映射表
update sync_prod_offer_rel rel
   set rel.it_offer_a_id = rel.business_offer_a_id,
       rel.it_offer_z_id = (SELECT rel2.it_id
                              FROM it_business_rel rel2
                             WHERE rel2.business_id = rel.business_offer_z_id
                               and rel2.rel_type = 'offer'
                               and rownum = 1)
 WHERE rel.business_offer_a_id = v_prod_offer_id
   and rel.business_offer_z_id IN
       (SELECT rel2.business_id
          FROM it_business_rel rel2
         WHERE rel2.business_id = rel.business_offer_z_id
           and rel2.rel_type = 'offer')
   and rel.request_inst_id = v_request_inst_id
   and rel.request_timestamp = v_timestamp
   ;

-- 更新A端数据
update sync_prod_offer_rel rel set rel.it_offer_a_id = rel.business_offer_a_id,rel.it_offer_z_id = rel.business_offer_z_id
WHERE rel.business_offer_z_id = v_prod_offer_id
and   rel.business_offer_a_id IN (
SELECT p.prod_offer_id FROM prod_offer p WHERE p.object_source != 'GT' or p.object_source is null
 ) and rel.it_offer_z_id is null
 and rel.request_inst_id = v_request_inst_id
 and rel.request_timestamp = v_timestamp
 ;

 -- 更新Z端数据
update sync_prod_offer_rel rel set rel.it_offer_a_id = rel.business_offer_a_id,rel.it_offer_z_id = rel.business_offer_z_id
WHERE rel.business_offer_a_id = v_prod_offer_id
and   rel.business_offer_z_id IN (
SELECT p.prod_offer_id FROM prod_offer p WHERE p.object_source != 'GT' or p.object_source is null
 ) and rel.it_offer_a_id is null
  and rel.request_inst_id = v_request_inst_id
  and rel.request_timestamp = v_timestamp
  ;


 -- 目录同步的需要更新 A端Z端顺序
 SELECT p.offer_type into v_offer_type FROM ppm_prod_offer p WHERE p.prod_offer_id = v_prod_offer_id;

 if v_offer_type ='10' or v_offer_type = '11' then
  -- 套餐、基础销售品
  update sync_prod_offer_rel rel
     set rel.rel_direction = rel.rel_direction || '-AZ'
   WHERE rel.rel_direction = 'AZZ'
     and rel.request_inst_id = v_request_inst_id
     and rel.request_timestamp = v_timestamp
     ;
 elsif v_offer_type ='12' then
 -- 可选包
 -- 关联另一端为可选，促销目录，则本销售品放A端。
 update sync_prod_offer_rel rel set rel.rel_direction = rel.rel_direction||'-AZ'
  WHERE rel.request_inst_id = v_request_inst_id
  and rel.rel_direction = 'AZZ'
  and exists (
      SELECT * FROM catalog_item t
      WHERE  t.catalog_item_id = rel.catalog_item_id
      and( t.catalog_item_cd like '7%' or t.catalog_item_cd like '8%'  )
    )
  and rel.request_timestamp = v_timestamp
    ;
  -- 其他，本销售品放Z端
  update sync_prod_offer_rel rel
     set rel.rel_direction = rel.rel_direction || '-ZA'
   WHERE rel.rel_direction = 'AZZ'
     and rel.request_inst_id = v_request_inst_id
     and rel.request_timestamp = v_timestamp
     ;

  update sync_prod_offer_rel rel
     set rel.rel_direction = rel.rel_direction || '-ZA'
   WHERE rel.rel_direction = 'AZZ'
     and rel.request_inst_id = v_request_inst_id
     and rel.request_timestamp = v_timestamp
     ;

 else
 -- 促销
 -- 关联另一端为可选，促销目录，则本销售品放A端。
  update sync_prod_offer_rel rel set rel.rel_direction = rel.rel_direction||'-AZ'
  WHERE rel.request_inst_id = v_request_inst_id
  and rel.rel_direction = 'AZZ'
  and exists (
      SELECT * FROM catalog_item t
      WHERE  t.catalog_item_id = rel.catalog_item_id
      and t.catalog_item_cd like '8%'
    )
    and rel.request_timestamp = v_timestamp
    ;
  -- 其他，本销售品放Z端
  update sync_prod_offer_rel rel
     set rel.rel_direction = rel.rel_direction || '-ZA'
   WHERE rel.rel_direction = 'AZZ'
     and rel.request_inst_id = v_request_inst_id
     and rel.request_timestamp = v_timestamp
     ;

 end if;

-- 同步的时候，无关联的数据不同步，不同步1300的数据
update sync_prod_offer_rel rel set rel.status_cd = '1300',rel.region_cd = '11'
WHERE rel.it_offer_a_id is null or rel.it_offer_z_id is null
and   rel.request_inst_id = v_request_inst_id
and   rel.request_timestamp = v_timestamp
;
-- 标识无需关联的数据，也不做同步
update sync_prod_offer_rel rel set rel.status_cd = '1300',rel.region_cd = '12'
WHERE rel.it_offer_a_id =-1 or rel.it_offer_z_id =-1
and   rel.request_inst_id = v_request_inst_id
and   rel.request_timestamp = v_timestamp
;

-- 重复的数据，不做同步
update sync_prod_offer_rel rel1
   set rel1.status_cd = '1300', rel1.region_cd = '13'
 WHERE rel1.status_cd != '1300' and exists(
SELECT * FROM  sync_prod_offer_rel rel2
WHERE rel1.request_inst_id = v_request_inst_id
and   rel2.request_inst_id = v_request_inst_id
and   rel1.it_offer_a_id = rel2.it_offer_a_id
and   rel1.it_offer_z_id = rel2.it_offer_z_id
and   rel1.relation_type_cd = rel2.relation_type_cd
and   rel1.prod_offer_rela_id > rel2.prod_offer_rela_id and rel2.status_cd != '1300'
and   rel2.request_timestamp = v_timestamp
)
and   rel1.request_timestamp = v_timestamp
;


--crm00060717_FJPPM2.8_REQ_集团任务单销售品视图需求
--在映射表数据构造完毕后，针对‘默认依赖’(120000)进行统一处理为‘可选依赖’(100000),然后再同步到销售品关系prod_offer_rel中
update sync_prod_offer_rel rel set rel.relation_type_cd='100000' where rel.request_inst_id = v_request_inst_id and rel.relation_type_cd='120000';

--AZ,ZA, AZZ-AZ关联数据
insert into prod_offer_rel(  PROD_OFFER_RELA_ID  ,
  OFFER_A_ID          ,
  OFFER_Z_ID          ,
  ROLE_CD             ,
  RELATION_TYPE_CD    ,
  STATUS_CD           ,
  STATUS_DATE         ,
  CREATE_DATE         ,
  UPDATE_DATE         ,
  AREA_ID             ,
  REGION_CD)
SELECT rel2.prod_offer_rela_id,rel2.it_offer_a_id,rel2.it_offer_z_id,
(SELECT r2.role_cd FROM prod_offer_rela_role r2 WHERE r2.role_cd = rel1.role_cd),
rel2.relation_type_cd,rel2.status_cd,sysdate,sysdate,sysdate,v_area_id,v_area_id
FROM ppm_prod_offer_rel rel1, sync_prod_offer_rel rel2
WHERE rel1.prod_offer_rela_id = rel2.prod_offer_rela_id_old
and   rel2.request_inst_id = v_request_inst_id -- 限定本次配置的数据
and   rel2.rel_direction IN ( 'AZ','ZA','AZZ-AZ' )
and   rel2.request_timestamp = v_timestamp
and   not exists (
-- 过滤ID重复的数据
SELECT * FROM prod_offer_rel rel3 WHERE rel2.prod_offer_rela_id = rel3.prod_offer_rela_id
 )
 and not exists (
-- 配置重复配置的数据
SELECT * FROM prod_offer_rel rel3 WHERE rel3.offer_a_id = rel2.it_offer_a_id and rel3.offer_z_id = rel2.it_offer_z_id and rel3.relation_type_cd = rel2.relation_type_cd
 )
 and rel2.status_cd ='1000'
 ;

 --AZZ-Za关联数据
insert into prod_offer_rel(  PROD_OFFER_RELA_ID  ,
  OFFER_Z_ID          ,
  OFFER_A_ID          ,
  ROLE_CD             ,
  RELATION_TYPE_CD    ,
  STATUS_CD           ,
  STATUS_DATE         ,
  CREATE_DATE         ,
  UPDATE_DATE         ,
  AREA_ID             ,
  REGION_CD)
SELECT rel2.prod_offer_rela_id,rel2.it_offer_a_id,rel2.it_offer_z_id,
(SELECT r2.role_cd FROM prod_offer_rela_role r2 WHERE r2.role_cd = rel1.role_cd),
rel2.relation_type_cd,rel2.status_cd,sysdate,sysdate,sysdate,v_area_id,v_area_id
FROM ppm_prod_offer_rel rel1, sync_prod_offer_rel rel2
WHERE rel1.prod_offer_rela_id = rel2.prod_offer_rela_id_old
and   rel2.request_inst_id = v_request_inst_id -- 限定本次配置的数据
and   rel2.rel_direction IN ('AZZ-ZA' )
and   rel2.request_timestamp = v_timestamp
and   not exists (
-- 过滤ID重复的数据
SELECT * FROM prod_offer_rel rel3 WHERE rel2.prod_offer_rela_id = rel3.prod_offer_rela_id
 )
 and not exists (
-- 配置重复配置的数据
SELECT * FROM prod_offer_rel rel3 WHERE rel3.offer_a_id = rel2.it_offer_a_id and rel3.offer_z_id = rel2.it_offer_z_id and rel3.relation_type_cd = rel2.relation_type_cd
 )
 and rel2.status_cd ='1000'
 ;

 -- 数据失效
 update prod_offer_rel rel set rel.status_cd = '1100' WHERE exists (
 SELECT * FROM sync_prod_offer_rel rel2 WHERE rel2.request_inst_id = v_request_inst_id
 and rel2.prod_offer_rela_id = rel.prod_offer_rela_id
 and rel2.status_cd = '1100'
 and rel2.request_timestamp = v_timestamp
  );

   -- 数据失效
 update prod_offer_rel rel set rel.status_cd = '1100' WHERE exists (
 SELECT * FROM sync_prod_offer_rel rel2 WHERE rel2.request_inst_id = v_request_inst_id
 and rel2.it_offer_a_id = rel.offer_a_id
 and rel2.it_offer_z_id = rel.offer_z_id
 and rel2.relation_type_cd = rel.relation_type_cd
 and rel2.rel_direction IN ('AZ','ZA','AZZ-AZ'   )
 and rel2.status_cd = '1100'
 and rel2.request_timestamp = v_timestamp
  );

     -- 数据失效
 update prod_offer_rel rel set rel.status_cd = '1100' WHERE exists (
 SELECT * FROM sync_prod_offer_rel rel2 WHERE rel2.request_inst_id = v_request_inst_id
 and rel2.it_offer_z_id = rel.offer_a_id
 and rel2.it_offer_a_id = rel.offer_z_id
 and rel2.relation_type_cd = rel.relation_type_cd
 and rel2.rel_direction IN ('AZZ-ZA'   )
 and rel2.status_cd = '1100'
 and rel2.request_timestamp = v_timestamp
  );
o_result:='TRUE';
end;
/
