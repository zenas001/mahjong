CREATE function           f_insert_billing_update(i_table_name in varchar2,
                                                              i_key_id     in number,
                                                              i_remark     in varchar2,
                                                              i_modify_man in varchar2)
  return boolean is
  v_i_table_name itsc_crmv2.INTF_INS_BILLING_UPDATE.table_name%type;
  v_column_name  itsc_crmv2.INTF_INS_BILLING_UPDATE.column_name%type;
  v_i_key_id     itsc_crmv2.INTF_INS_BILLING_UPDATE.key_id%type;
  v_ins_id       itsc_crmv2.INTF_INS_BILLING_UPDATE.ins_id%type;
  v_sql          varchar2(1000);
  v_area_id      number(10) := 0;
  i              number(10) := 0;
  v_AREA_NBR     varchar2(10) := '591';
begin
  --去掉空格，并转化为大写
  v_i_table_name := upper(trim(i_table_name));
  v_i_key_id     := upper(trim(i_key_id));
  --表的判断
  begin
    case v_i_table_name
      when 'PROD_INST' then
        v_i_table_name := 'PROD_INST';
        v_column_name  := 'PROD_INST_ID';
      when 'PROD_INST_REL' then
        v_i_table_name := 'PROD_INST_REL';
        v_column_name  := 'PROD_INST_REL_ID';
      when 'PROD_INST_ATTR' then
        v_i_table_name := 'PROD_INST_ATTR';
        v_column_name  := 'PROD_INST_ATTR_ID';
      when 'OFFER_PROD_INST_REL' then
        v_i_table_name := 'OFFER_PROD_INST_REL';
        v_column_name  := 'OFFER_PROD_INST_REL_ID';
      when 'PROD_OFFER_INST' then
        v_i_table_name := 'PROD_OFFER_INST';
        v_column_name  := 'PROD_OFFER_INST_ID';
      when 'PROD_OFFER_INST_REL' then
        v_i_table_name := 'PROD_OFFER_INST_REL';
        v_column_name  := 'PROD_OFFER_INST_REL_ID';
      when 'PROD_OFFER_INST_ATTR' then
        v_i_table_name := 'PROD_OFFER_INST_ATTR';
        v_column_name  := 'PROD_OFFER_INST_ATTR_ID';
      when 'PROD_OFFER_MEMBER_INST' then
        v_i_table_name := 'PROD_OFFER_MEMBER_INST';
        v_column_name  := 'MEMBER_INST_ID';
      when 'ACCOUNT' then
        v_i_table_name := 'ACCOUNT';
        v_column_name  := 'ACCOUNT_ID';
      when 'PROD_INST_ACCT' then
        v_i_table_name := 'PROD_INST_ACCT';
        v_column_name  := 'PROD_INST_ACCT_ID';
      when 'PAYMENT_PLAN' then
        v_i_table_name := 'PAYMENT_PLAN';
        v_column_name  := 'PAYMENT_PLAN';
      when 'CUST' then
        v_i_table_name := 'CUST';
        v_column_name  := 'CUST_ID';
      when 'PARTY' then
        v_i_table_name := 'PARTY';
        v_column_name  := 'PARTY_ID';
      when 'IVPN_NBR' then
        v_i_table_name := 'IVPN_NBR';
        v_column_name  := 'REC_ID';
      when 'VPN_PHS2CDMA' then
        v_i_table_name := 'VPN_PHS2CDMA';
        v_column_name  := 'MEMBER_ID';
      when 'CREDIT_LIMIT' then
        v_i_table_name := 'CREDIT_LIMIT';
        v_column_name  := 'CREDIT_LIMIT_ID';
      when 'CLUB_MEMBER' then
        v_i_table_name := 'CLUB_MEMBER';
        v_column_name  := 'MEMBER_ID';
      else
        --写日志表
        --add by fflingy 20091125检查是否批量接口是否已有数据，有则不送
        /*        select \*+index(a,INX_O_INS_BILLING_UPDATE_01)*\
         count(1)
          into i
          from ins_billing_update a
         where column_name = v_column_name
           and table_name = v_i_table_name
           and key_id = v_i_key_id
           and state = '10A';
        if i > 0 then
          return true;
        end if;*/

        return false;
    end case;
  end;

  select count(1)
    into i
    from ITSC_CRMV2.INTF_INS_BILLING_UPDATE a
   where column_name = v_column_name
     and table_name = v_i_table_name
     and key_id = i_key_id
     and topic=i_remark
     and reason=i_remark
     and OPERATOR=i_modify_man
     and state in ('70A', '70G','70T');
  if i > 0 then
    return true;
  end if;

  --取流水

  begin
    v_sql := ' select area_id from CRMV2.' || v_i_table_name || ' where ' ||
             v_column_name || ' = ''' || i_key_id || '''';

    execute immediate v_sql
      into v_area_id;
  exception
    when no_data_found then
      begin
        v_sql := ' select area_id from CRMV2.' || v_i_table_name ||
                 '_his where ' || v_column_name || ' = ''' || i_key_id || '''';

        execute immediate v_sql
          into v_area_id;
      exception
        when others then
          null;
      end;
    when others then
      null;
  end;

  --和王建均确认，非福建的数据以及异常的数据，area_nbr改成590
  BEGIN
    SELECT area_nbr
      INTO v_area_nbr
      FROM crmv2.area_code
     WHERE area_code_id = v_area_id
       AND area_code BETWEEN '0591' AND '0599';

  EXCEPTION
    WHEN OTHERS THEN
      v_area_nbr := '590';
  END;

  select itsc_crmv2.seq_intf_ins_billing_update_id.nextval
    into v_ins_id
    from dual;

  --写计费接口表
  insert into itsc_crmv2.INTF_INS_BILLING_UPDATE
    (INS_ID,
     TABLE_NAME,
     COLUMN_NAME,
     KEY_ID,
     TOPIC,
     TYPE,
     REASON,
     OPERATOR,
     STATE,
     STATE_DATE,
     CREATE_DATE,
     UPDATE_DATE,
     DEAL_NUM,
     NEXT_DEAL_TIME,
     ERR_MSG,
     REMARK,
     AREA_NBR)
  values
    (v_ins_id,
     v_i_table_name,
     v_column_name,
     v_i_key_id,
     i_remark,
     '1003',
     i_remark,
     i_modify_man,
     '70T',
     null,
     sysdate,
     null,
     0,
     null,
     null,
     null,
     v_AREA_NBR);
  --返回
  commit;
  return true;
end f_insert_billing_update;
/
