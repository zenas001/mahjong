CREATE PROCEDURE           INSERT_TFJ_TEST4(res        in VARCHAR2) IS
   o_result       customer_order.remark%TYPE; --订单流水号
   o_msg          customer_order.remark%TYPE; --订单流水号
   o_cust_order_id customer_order.cust_order_id%TYPE;
  begin
  FOR  REC IN  (
       select o.queue_id QUEUE_ID from o_auto_proc_queue o where to_char(create_date,'YYYY-MM-DD HH24:MM:SS') > '2016-03-10 00:00:00'
      ) LOOP
   PKG_PROC_AUTO_H.procOptionOfferNotOrder(REC.QUEUE_ID,o_result,o_msg,o_cust_order_id);
   END LOOP;
END INSERT_TFJ_TEST4;
/
