CREATE PROCEDURE           PRC_groupOfferInst IS
  v_accNbr    varchar2(32) := '';
  v_offer_nbr varchar2(50) := '';
  v_flag      number := 1;
  v_insertDate date;
  CURSOR CUR IS
    select *
      from (SELECT *
              FROM group_offer_inst A
             WHERE NOT EXISTS (SELECT 1
                      FROM INTF_group_offer_inst B
                     WHERE A.INTF_GROUP_OFFER_INST_ID =
                           B.INTF_GROUP_OFFER_INST_ID)
               and a.state is null
             order by insert_date desc)
     where rownum < 5000;
begin
  FOR REC IN CUR LOOP
    v_flag := 1;
    if REC.ACC_NBR is null then
      begin
        select aaa.acc_nbr
          into v_accNbr
          from (select nvl(d.acc_nbr, d.account) acc_nbr
                  from prod_offer_inst     a,
                       offer_prod_inst_rel b,
                       prod_inst           c,
                       prod_inst           d
                 where a.prod_offer_inst_id = b.prod_offer_inst_id
                   and b.prod_inst_id = c.prod_inst_id
                   and c.acc_prod_inst_id = d.prod_inst_id
                   and a.prod_offer_inst_id = rec.prod_offer_inst_id
                   and c.acc_prod_inst_id is not null
                   and rownum = 1
                union
                select nvl(c.acc_nbr, c.account) acc_nbr
                  from prod_offer_inst a, offer_prod_inst_rel b, prod_inst c
                 where a.prod_offer_inst_id = b.prod_offer_inst_id
                   and b.prod_inst_id = c.prod_inst_id
                   and a.prod_offer_inst_id = rec.prod_offer_inst_id
                   and c.acc_prod_inst_id is null
                   and rownum = 1) AAA;
      exception
        when others then
          begin
            select aaa.acc_nbr
              into v_accNbr
              from (select nvl(d.acc_nbr, d.account) acc_nbr
                      from prod_offer_inst         a,
                           offer_prod_inst_rel_his b,
                           prod_inst               c,
                           prod_inst               d
                     where a.prod_offer_inst_id = b.prod_offer_inst_id
                       and b.prod_inst_id = c.prod_inst_id
                       and c.acc_prod_inst_id = d.prod_inst_id
                       and a.prod_offer_inst_id = rec.prod_offer_inst_id
                       and c.acc_prod_inst_id is not null
                       and rownum = 1
                    union
                    select nvl(c.acc_nbr, c.account) acc_nbr
                      from prod_offer_inst         a,
                           offer_prod_inst_rel_his b,
                           prod_inst               c
                     where a.prod_offer_inst_id = b.prod_offer_inst_id
                       and b.prod_inst_id = c.prod_inst_id
                       and a.prod_offer_inst_id = rec.prod_offer_inst_id
                       and c.acc_prod_inst_id is null
                       and rownum = 1) AAA;
          exception
            when others then
              /*加一层异常处理，*/
              begin
                select aaa.acc_nbr
                  into v_accNbr
                  from (select nvl(d.acc_nbr, d.account) acc_nbr
                          from prod_offer_inst_his     a,
                               offer_prod_inst_rel_his b,
                               prod_inst_his           c,
                               prod_inst_his           d
                         where a.prod_offer_inst_id = b.prod_offer_inst_id
                           and b.prod_inst_id = c.prod_inst_id
                           and c.acc_prod_inst_id = d.prod_inst_id
                           and a.prod_offer_inst_id = rec.prod_offer_inst_id
                           and c.acc_prod_inst_id is not null
                           and rownum = 1
                        union
                        select nvl(c.acc_nbr, c.account) acc_nbr
                          from prod_offer_inst_his     a,
                               offer_prod_inst_rel_his b,
                               prod_inst_his           c
                         where a.prod_offer_inst_id = b.prod_offer_inst_id
                           and b.prod_inst_id = c.prod_inst_id
                           and a.prod_offer_inst_id = rec.prod_offer_inst_id
                           and c.acc_prod_inst_id is null
                           and rownum = 1) AAA;
              exception
                when others then
                  /*加一层异常处理，*/
                  begin
                    update group_offer_inst a
                       set a.state = '70E'
                     where a.intf_group_offer_inst_id =
                           rec.intf_group_offer_inst_id;
                    v_flag := 0;
                  end;
              end;
          end;
      end;
      /*取同一transaction_id最大时间
       *crm00058809FJCRMV2.0_BUG_福建省_集团佣金用户报错
       */
      begin
        select max(insert_date)
          into v_insertDate
          from group_offer_inst AA
         where AA.transaction_id = REC.TRANSACTION_ID;
      end;
      if v_flag = 1 then
        insert into intf_group_offer_inst
          (INTF_GROUP_OFFER_INST_ID,
           TRANSACTION_ID,
           EXT_CUST_ORDER_ID,
           OP_TYPE,
           CHANNEL_NBR,
           ACC_NBR,
           PROD_OFFER_INST_ID,
           OFFER_NBR,
           EXT_PROD_OFFER_ID,
           INSERT_DATE,
           REMARK)
          select INTF_GROUP_OFFER_INST_ID,
                 TRANSACTION_ID,
                 EXT_CUST_ORDER_ID,
                 OP_TYPE,
                 CHANNEL_NBR,
                 v_accNbr,
                 PROD_OFFER_INST_ID,
                 /*国漫的编码不知道为啥设置不进去，先进行这样修复吧，后面再跟踪下程序*/
                 decode(EXT_PROD_OFFER_ID,
                        '135011300',
                        '6220101001100003',
                        '135011299',
                        '6220101001100002',
                        '135011298',
                        '6210200201100003',
                        '135011297',
                        '6210200201100002',
                        '135010933',
                        '6210200201100001',
                        '135010931',
                        '6220101001100001',
                        OFFER_NBR),
                 EXT_PROD_OFFER_ID,
                 v_insertDate,
                 REMARK
            from group_offer_inst
           where intf_group_offer_inst_id = REC.INTF_GROUP_offer_inst_id
             and acc_nbr is null;
      end if;
    else
      insert into intf_group_offer_inst
        (INTF_GROUP_OFFER_INST_ID,
         TRANSACTION_ID,
         EXT_CUST_ORDER_ID,
         OP_TYPE,
         CHANNEL_NBR,
         ACC_NBR,
         PROD_OFFER_INST_ID,
         OFFER_NBR,
         EXT_PROD_OFFER_ID,
         INSERT_DATE,
         REMARK)
        select INTF_GROUP_OFFER_INST_ID,
               TRANSACTION_ID,
               EXT_CUST_ORDER_ID,
               OP_TYPE,
               CHANNEL_NBR,
               acc_nbr,
               PROD_OFFER_INST_ID,
               /*国漫的编码不知道为啥设置不进去，先进行这样修复吧，后面再跟踪下程序*/
               decode(EXT_PROD_OFFER_ID,
                      '135011300',
                      '6220101001100003',
                      '135011299',
                      '6220101001100002',
                      '135011298',
                      '6210200201100003',
                      '135011297',
                      '6210200201100002',
                      '135010933',
                      '6210200201100001',
                      '135010931',
                      '6220101001100001',
                      OFFER_NBR),
               EXT_PROD_OFFER_ID,
               v_insertDate,
               REMARK
          from group_offer_inst
         where intf_group_offer_inst_id = REC.INTF_GROUP_offer_inst_id
           and acc_nbr is not null;
    end if;
    if v_flag = 1 then
      update group_offer_inst a
         set a.state = '70C'
       where a.intf_group_offer_inst_id = rec.intf_group_offer_inst_id;
    end if;
  END LOOP;
  COMMIT;
end;
/
