CREATE FUNCTION           FUNC_CHECK_ORDER_ITEM_INFO(IN_ORDER_ITEM_ID IN NUMBER,
                                      OUT_ERR_MSG      OUT VARCHAR2)
    RETURN NUMBER IS
    V_CONFIG_COUNT  NUMBER := 0; --可选包产品是否有配置关系
    V_PROD_OFFER_ID NUMBER := 0;
    V_OFFER_SUB_TYPE varchar2(30):='';
    V_PROD_OFFER_EXPIRE_TYPE varchar2(30):='';
    V_COUNT                  NUMBER(10);
    AN_FLAG                  NUMBER := 0;
    V_PROD_OFFER_INST_ID     NUMBER(12);
    V_REL_PROD_INST_ID       NUMBER(12);
    V_REL_PROD_OFFER_INST_ID NUMBER(12);
    NEW_FLAG                 NUMBER := 0;
    XD_FLAG                  NUMBER := 0;

    V_OFFER_EXP_DATE DATE; --套餐失效时间

    V_ORDER_ITEM_STATUS_CD varchar2(30) := ''; --订单项状态

    V_SERVICE_OFFER_ID varchar2(30) := ''; --订单项动作
    V_CNT              NUMBER(10) := 0;
  BEGIN
    --续订单
    SELECT DECODE(COUNT(*), 1, 1, 0)
      INTO XD_FLAG
      FROM ORDER_ITEM OI, CUSTOMER_ORDER CO
     WHERE OI.CUST_ORDER_ID = CO.CUST_ORDER_ID
       AND OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
       AND CO.STATUS_CD = '101300'
       AND OI.SERVICE_OFFER_ID = '502';
    --订购单
    SELECT DECODE(COUNT(*), 1, 1, 0)
      INTO NEW_FLAG
      FROM ORDER_ITEM_HIS OI
     WHERE OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
       AND (OI.SERVICE_OFFER_ID = '500' OR OI.SERVICE_OFFER_ID = '502');

    IF (XD_FLAG = 0 AND NEW_FLAG = 0) THEN
      select DECODE(COUNT(*), 1, 1, 0)
        INTO V_CNT
        from ORDER_ITEM A
       WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;

      IF V_CNT > 0 THEN
        select A.STATUS_CD, A.SERVICE_OFFER_ID
          INTO V_ORDER_ITEM_STATUS_CD, V_SERVICE_OFFER_ID
          from ORDER_ITEM A
         WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 续订单订单项状态要求为101300，订单动作要求为502；' ||
                       '而目前订单项的状态为' || V_ORDER_ITEM_STATUS_CD || ',订单项的动作为' ||
                       V_SERVICE_OFFER_ID;
      ELSE
        select DECODE(COUNT(*), 1, 1, 0)
          INTO V_CNT
          from ORDER_ITEM_HIS A
         WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
        IF V_CNT > 0 THEN
          select A.STATUS_CD, A.SERVICE_OFFER_ID
            INTO V_ORDER_ITEM_STATUS_CD, V_SERVICE_OFFER_ID
            from ORDER_ITEM_HIS A
           WHERE A.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
          OUT_ERR_MSG := IN_ORDER_ITEM_ID ||
                         ' 订购单订单项状态要求为300000，订单动作要求为500；' || '而目前订单项的状态为' ||
                         V_ORDER_ITEM_STATUS_CD || ',订单项的动作为' ||
                         V_SERVICE_OFFER_ID;

        END IF;
      END IF;
      IF  V_CNT=0 THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 订单项ID有误,不存在该订单项';
      END IF;
      insert into proc_log
      values
        ('ORDER_ITEM',
         'ORDER_ITEM_ID',
         OUT_ERR_MSG,
         sysdate,
         IN_ORDER_ITEM_ID);
      commit;
      RETURN 1;
    END IF;

    IF (XD_FLAG = 1) THEN
      --续订单
      --找订单关联的可选包销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID, POI.EXP_DATE, poi.prod_offer_id
          INTO V_PROD_OFFER_INST_ID, V_OFFER_EXP_DATE, V_PROD_OFFER_ID
          FROM ORDER_ITEM O, PROD_OFFER_INST POI
         WHERE O.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
           AND O.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到订单项关联的可选包实例，不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;

          RETURN 1;
      END;
      --找可选包关联的销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID
          INTO V_REL_PROD_OFFER_INST_ID
          FROM PROD_OFFER_INST_REL POIR, PROD_OFFER_INST POI, PROD_OFFER PO
         WHERE POIR.RELA_PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
           AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
           AND POIR.RELATED_PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
           AND PO.OFFER_SUB_TYPE IN ('T01', 'T05');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到可选包关联的销售品实例，不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
      END;

      select count(*)
        into V_CONFIG_COUNT
        from  offer_prod_rel a
       where a.prod_offer_id = V_PROD_OFFER_ID
         and a.status_cd = 1000;
      --找可选包关联的产品实例
    if V_CONFIG_COUNT>0 then
     BEGIN
        SELECT PI.PROD_INST_ID
          INTO V_REL_PROD_INST_ID
          FROM OFFER_PROD_INST_REL OPIR, PROD_INST PI, PRODUCT P
         WHERE OPIR.PROD_INST_ID = PI.PROD_INST_ID
           AND PI.PRODUCT_ID = P.PRODUCT_ID
           AND P.PROD_FUNC_TYPE = '101'
           AND OPIR.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID;
      EXCEPTION
        WHEN OTHERS THEN
          OUT_ERR_MSG := SUBSTR(SQLERRM,1,1000) || '';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
           RETURN 1;
      END;
    end if;
      --判断订单项是可选包，且是充值开通
      SELECT DECODE(COUNT(*), 0, 0, 1)
        INTO AN_FLAG
        FROM ORDER_ITEM      OI,
             ACCT_ITEM       AI,
             PROD_OFFER_INST POI,
             PROD_OFFER      PO
       WHERE OI.ORDER_ITEM_ID = AI.ORDER_ITEM_ID
         AND OI.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
         AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
         AND AI.CHARGE_METHOD = '140101'
         AND PO.OFFER_SUB_TYPE = 'T04'
         AND OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包不是充值开通的付款方式';
        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);
        commit;
        RETURN 1;
      END IF;
      --判断套餐是否已经过了失效期
      --查询输入的年缴套餐是否包含“到期处理方式”（ 属性ID=800002919），
      --如果有，在失效时间再延迟1个月的时间内，计费发起的查询都返回可以划拨
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_OFFER_INST_ATTR A
       WHERE A.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
         AND A.ATTR_ID = 800002919;--800002919: xm_宽带续约标识专用
      IF V_COUNT > 0 THEN
        --失效时间再延迟1个月
        V_OFFER_EXP_DATE := ADD_MONTHS(V_OFFER_EXP_DATE, 1);
      END IF;

      IF V_OFFER_EXP_DATE < SYSDATE THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 套餐已经过了失效期';

        insert into proc_log
        values
          ('PROD_OFFER_INST',
           'PROD_OFFER_INST_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);
        commit;
        RETURN 1;
      END IF;

      --可选包有关联的产品实例需要判断关联产品实例的状态
      IF V_REL_PROD_INST_ID IS NOT NULL THEN
        --关联产品处于停机不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '120000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于停机不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
        --关联产品处于未激活(预开通)不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '140000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于未激活(预开通)不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
        --关联产品的订单处于撤销中不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.STATUS_CD = '401399';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品订单撤销中不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
        --关联产品存在拆机单不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.SERVICE_OFFER_ID = '101';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品存在拆机单不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
      END IF;
      --可选包关联的销售品处于退订中不能发起
      SELECT DECODE(COUNT(*), 0, 1, 0)
        INTO AN_FLAG
        FROM PROD_OFFER_INST POI, ORDER_ITEM OI
       WHERE POI.PROD_OFFER_INST_ID = OI.ORDER_ITEM_OBJ_ID
         AND PROD_OFFER_INST_ID = V_REL_PROD_OFFER_INST_ID
         AND OI.SERVICE_OFFER_ID = '501';
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联的销售品处于退订中不能发起';
        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);
        commit;
        RETURN 1;
      END IF;

      RETURN 0;
    END IF;
    IF (NEW_FLAG = 1) THEN
      --订购单
      --找订单关联的可选包销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID, POI.EXP_DATE, poi.prod_offer_id,po.offer_sub_type,po.expire_type
          INTO V_PROD_OFFER_INST_ID, V_OFFER_EXP_DATE, V_PROD_OFFER_ID,V_OFFER_SUB_TYPE,V_PROD_OFFER_EXPIRE_TYPE
          FROM ORDER_ITEM_HIS O, PROD_OFFER_INST POI,prod_offer po
         WHERE O.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
           AND O.ORDER_ITEM_ID = IN_ORDER_ITEM_ID
           and po.prod_offer_id=poi.prod_offer_id;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到订单项关联的可选包实例，不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
      END;
      /*如果是竣工后立即失效的可选包，直接返回成功*/
      IF V_PROD_OFFER_EXPIRE_TYPE ='3' THEN
         RETURN 0;
      END IF;

        /*如果是T01，是充值开通 直接返回成功*/
      IF V_OFFER_SUB_TYPE ='T01' THEN

       --判断订单项是可选包，且是充值开通
      SELECT DECODE(COUNT(*), 0, 0, 1)
        INTO AN_FLAG
        FROM
             PROD_OFFER_INST POI
       WHERE POI.PROD_OFFER_INST_ID =V_PROD_OFFER_INST_ID
       AND POI.EFF_DATE=POI.EXP_DATE
       AND POI.EFF_DATE IS NOT NULL ;
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 销售品不是充值开通的付款方式';
        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);
        commit;
        RETURN 1;
      END IF;
      RETURN 0;

      END IF;


      --找可选包关联的销售品实例
      BEGIN
        SELECT POI.PROD_OFFER_INST_ID
          INTO V_REL_PROD_OFFER_INST_ID
          FROM PROD_OFFER_INST_REL POIR, PROD_OFFER_INST POI, PROD_OFFER PO
         WHERE POIR.RELA_PROD_OFFER_INST_ID = POI.PROD_OFFER_INST_ID
           AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
           AND POIR.RELATED_PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
           AND PO.OFFER_SUB_TYPE IN ('T01', 'T05');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 没有找到可选包关联的销售品实例，不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
      END;
            select count(*)
        into V_CONFIG_COUNT
        from offer_prod_rel a
       where a.prod_offer_id = V_PROD_OFFER_ID
         and a.status_cd = 1000;
      --找可选包关联的产品实例
    if V_CONFIG_COUNT>0 then

      --找可选包关联的产品实例
      BEGIN
        SELECT PI.PROD_INST_ID
          INTO V_REL_PROD_INST_ID
          FROM OFFER_PROD_INST_REL OPIR, PROD_INST PI, PRODUCT P
         WHERE OPIR.PROD_INST_ID = PI.PROD_INST_ID
           AND PI.PRODUCT_ID = P.PRODUCT_ID
           AND P.PROD_FUNC_TYPE = '101'
           AND OPIR.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID;
      EXCEPTION
        WHEN OTHERS THEN
          OUT_ERR_MSG := SUBSTR(SQLERRM,1,1000) || '';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
    RETURN 1;
       END;
      end if;
      --判断订单项是可选包，且是充值开通
      SELECT DECODE(COUNT(*), 0, 0, 1)
        INTO AN_FLAG
        FROM ORDER_ITEM_HIS OI, ACCT_ITEM_HIS AI, PROD_OFFER_INST POI, PROD_OFFER PO
       WHERE OI.ORDER_ITEM_ID = AI.ORDER_ITEM_ID
         AND OI.ORDER_ITEM_OBJ_ID = POI.PROD_OFFER_INST_ID
         AND POI.PROD_OFFER_ID = PO.PROD_OFFER_ID
         AND AI.CHARGE_METHOD = '140101'
         AND PO.OFFER_SUB_TYPE = 'T04'
         AND POI.EFF_DATE = POI.EXP_DATE
         AND OI.ORDER_ITEM_ID = IN_ORDER_ITEM_ID;
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包不是充值开通的付款方式';
        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);
        commit;
        RETURN 1;
      END IF;
      --判断套餐是否已经过了失效期
      --查询输入的年缴套餐是否包含“到期处理方式”（ 属性ID=800002919），
      --如果有，在失效时间再延迟1个月的时间内，计费发起的查询都返回可以划拨
      SELECT COUNT(*)
        INTO V_COUNT
        FROM PROD_OFFER_INST_ATTR A
       WHERE A.PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID
         AND A.ATTR_ID = 800002919;--800002919: xm_宽带续约标识专用
      IF V_COUNT > 0 THEN
        --失效时间再延迟1个月
        V_OFFER_EXP_DATE := ADD_MONTHS(V_OFFER_EXP_DATE, 1);
      END IF;

      IF V_OFFER_EXP_DATE < SYSDATE THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 套餐已经过了失效期';
        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);
        commit;
        RETURN 1;
      END IF;

      --可选包有关联的产品实例需要判断关联产品实例的状态
      IF V_REL_PROD_INST_ID IS NOT NULL THEN
        --关联产品处于停机不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '120000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于停机不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
        --关联产品处于未激活(预开通)不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST
         WHERE PROD_INST_ID = V_REL_PROD_INST_ID
           AND STATUS_CD = '140000';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品处于未激活(预开通)不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
        --关联产品的订单处于撤销中不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.STATUS_CD = '401399';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品订单撤销中不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
        --关联产品存在拆机单不能发起
        SELECT DECODE(COUNT(*), 0, 1, 0)
          INTO AN_FLAG
          FROM PROD_INST PI, ORDER_ITEM OI
         WHERE PI.PROD_INST_ID = OI.ORDER_ITEM_OBJ_ID
           AND PI.PROD_INST_ID = V_REL_PROD_INST_ID
           AND OI.SERVICE_OFFER_ID = '101';
        IF (AN_FLAG = 0) THEN
          OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联产品存在拆机单不能发起';
          insert into proc_log
          values
            ('ORDER_ITEM',
             'ORDER_ITEM_ID',
             OUT_ERR_MSG,
             sysdate,
             IN_ORDER_ITEM_ID);
          commit;
          RETURN 1;
        END IF;
      END IF;
      --可选包关联的销售品处于退订中不能发起
      SELECT DECODE(COUNT(*), 0, 1, 0)
        INTO AN_FLAG
        FROM PROD_OFFER_INST POI, ORDER_ITEM OI
       WHERE POI.PROD_OFFER_INST_ID = OI.ORDER_ITEM_OBJ_ID
         AND PROD_OFFER_INST_ID = V_REL_PROD_OFFER_INST_ID
         AND OI.SERVICE_OFFER_ID = '501';
      IF (AN_FLAG = 0) THEN
        OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 可选包关联的销售品处于退订中不能发起';
        insert into proc_log
        values
          ('ORDER_ITEM',
           'ORDER_ITEM_ID',
           OUT_ERR_MSG,
           sysdate,
           IN_ORDER_ITEM_ID);
        commit;
        RETURN 1;
      END IF;

      RETURN 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      OUT_ERR_MSG := IN_ORDER_ITEM_ID || ' 其它未知错误' || SUBSTR(SQLERRM,1,1000);
      insert into proc_log
      values
        ('ORDER_ITEM',
         'ORDER_ITEM_ID',
         OUT_ERR_MSG,
         sysdate,
         IN_ORDER_ITEM_ID);
      commit;
      RETURN 1;
  END;
/
