CREATE FUNCTION           FNC_GET_MKT_FLOW_ACNAME(IN_procinID IN NUMBER)
  RETURN VARCHAR2 IS
  V_RESULT VARCHAR2(500);
BEGIN
  IF IN_procinID IS NULL THEN
    RETURN(NULL);
  END IF;

 SELECT substr(MAX(sys_connect_by_path(name_, ',')), 2)  paramcode  INTO V_RESULT
  FROM (SELECT a.*, row_number() over(ORDER BY a.name_) rn
          FROM jbpm4_task a WHERE a.procinst_= IN_procinID)
 START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;


RETURN(V_RESULT);
END FNC_GET_MKT_FLOW_ACNAME;
/
