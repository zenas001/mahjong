CREATE PROCEDURE           p_material_spec_sync_intf(i_MATERIAL_SPEC_ID IN NUMBER,
                                                      i_MATERIAL_CODE    IN VARCHAR2,
                                                      i_MATERIAL_KIND    IN VARCHAR2,
                                                      i_MATERIAL_MODEL   IN VARCHAR2,
                                                      i_MATERIAL_TYPE    IN VARCHAR2,
                                                      i_OPERATE          IN VARCHAR2,
                                                      i_TERM_MODEL       IN VARCHAR2,
                                                      i_NET_TYPE         IN VARCHAR2,
                                                      i_NET_MODE         IN VARCHAR2,
                                                      i_TERM_FUNC        IN VARCHAR2,
                                                      o_ret              OUT NUMBER,
                                                      o_message          OUT VARCHAR2) Is


  v_count               Number(10) := 0;
  v_mkt_res_type        varchar2(30);
  v_mkt_res_attrId      varchar2(30);


Begin
  o_ret     := 1;
  o_message := '实物规格同步成功！';

  begin
    select mkt_res_type_id
      into v_mkt_res_type
      from mkt_resource_type
     where ext_type_code = i_MATERIAL_KIND and rownum =1;
  exception
    when others then
      o_ret     := 0;
      o_message := '不存在此实物大类：' || i_MATERIAL_KIND || '，请先同步目录！';
      return;
  end;

  begin
    Select count(*)
      into v_count
      From mkt_resource
     Where mkt_res_id = i_MATERIAL_SPEC_ID;
    if i_OPERATE = 'ADD' then
      if v_count > 0 then
        o_ret     := 0;
        o_message := '此实物规格已经存在，不能进行新增操作，规格ID：' || i_MATERIAL_SPEC_ID;
        return;
      end if;
      ---新增mkt_resource
      insert into mkt_resource
        (MKT_RES_ID,
         MKT_RES_TYPE_ID,
         MKT_RES_NAME,
         MKT_RES_DESC,
         INSTANCE_FLAG,
         STANDARD_CD,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         UPDATE_DATE,
         AREA_ID,
         REGION_CD,
         UPDATE_STAFF,
         CREATE_STAFF,
         EFF_FLAG,
         EXP_DATE,
         SINGLE_PRICE)
      values
        (i_MATERIAL_SPEC_ID,
         v_mkt_res_type,
         i_MATERIAL_MODEL,
         'LGS到CRM终端规格同步', --标注来源，可以删除
         '1',
         i_TERM_MODEL,
         '1000',
         sysdate,
         sysdate,
         sysdate,
         46,
         460,
         null,
         null,
         '1',
         To_Date('2900-01-01', 'YYYY-MM-DD'),
         null);
      --新增mkt_res_attr
      if i_NET_TYPE is not null then
        select SEQ_MKT_RES_ATTR_ID.nextval into v_mkt_res_attrId from dual;
        insert into mkt_res_attr
          (MKT_RES_ATTR_ID,
           MKT_RES_ID,
           ATTR_ID,
           ATTR_VALUE,
           ATTR_VALUE_ID,
           STATUS_CD,
           STATUS_DATE,
           EFF_DATE,
           EXP_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           PROC_SERIAL,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           REC_UPDATE_DATE)
        values
          (v_mkt_res_attrId,
           i_MATERIAL_SPEC_ID,
           910001318,
           i_NET_TYPE,
           decode(i_NET_TYPE,
                  '2',
                  '920002414',
                  '3',
                  '920002414',
                  '920002414'),
           '1000',
           sysdate,
           sysdate,
           null,
           sysdate,
           sysdate,
           '',
           460,
           46,
           null,
           null,
           sysdate);
      end if;
      if i_TERM_FUNC is not null then
        select SEQ_MKT_RES_ATTR_ID.nextval into v_mkt_res_attrId from dual;
        insert into mkt_res_attr
          (MKT_RES_ATTR_ID,
           MKT_RES_ID,
           ATTR_ID,
           ATTR_VALUE,
           ATTR_VALUE_ID,
           STATUS_CD,
           STATUS_DATE,
           EFF_DATE,
           EXP_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           PROC_SERIAL,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           REC_UPDATE_DATE)
        values
          (v_mkt_res_attrId,
           i_MATERIAL_SPEC_ID,
           910001324,
           i_TERM_FUNC,
           decode(i_TERM_FUNC,
                  '1',
                  '920002416',
                  '0',
                  '920002417',
                  '920002416'),
           '1000',
           sysdate,
           sysdate,
           null,
           sysdate,
           sysdate,
           '',
           460,
           46,
           null,
           null,
           sysdate);
      end if;
      if i_NET_MODE is not null then
        select SEQ_MKT_RES_ATTR_ID.nextval into v_mkt_res_attrId from dual;
        insert into mkt_res_attr
          (MKT_RES_ATTR_ID,
           MKT_RES_ID,
           ATTR_ID,
           ATTR_VALUE,
           ATTR_VALUE_ID,
           STATUS_CD,
           STATUS_DATE,
           EFF_DATE,
           EXP_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           PROC_SERIAL,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           REC_UPDATE_DATE)
        values
          (v_mkt_res_attrId,
           i_MATERIAL_SPEC_ID,
           910001325,
           i_NET_MODE,
           decode(i_NET_MODE,
                  '1',
                  '920002418',
                  '0',
                  '920002419',
                  '920002419'),
           '1000',
           sysdate,
           sysdate,
           null,
           sysdate,
           sysdate,
           '',
           460,
           46,
           null,
           null,
           sysdate);
      end if;
      if i_TERM_MODEL is not null then
        select SEQ_MKT_RES_ATTR_ID.nextval into v_mkt_res_attrId from dual;
        insert into mkt_res_attr
          (MKT_RES_ATTR_ID,
           MKT_RES_ID,
           ATTR_ID,
           ATTR_VALUE,
           ATTR_VALUE_ID,
           STATUS_CD,
           STATUS_DATE,
           EFF_DATE,
           EXP_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           PROC_SERIAL,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           REC_UPDATE_DATE)
        values
          (v_mkt_res_attrId,
           i_MATERIAL_SPEC_ID,
           910001323,
           i_TERM_MODEL,
           '',
           '1000',
           sysdate,
           sysdate,
           null,
           sysdate,
           sysdate,
           '',
           460,
           46,
           null,
           null,
           sysdate);
      end if;
    end if;
  exception
    when others then
      rollback;
      o_ret     := 0;
      o_message := sqlerrm;
  end;
  --Commit;
End;
/
