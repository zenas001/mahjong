CREATE procedure           eye_create_order_elapsed_time is
  V_QUERY_CUST float(10):=0.0;
  V_QUERY_OFFER float(10):=0.0;
  V_QUERY_PROC float(10):=0.0;
  V_SELECT_ADR float(10):=0.0;
  V_SELECT_NUM float(10):=0.0;
  V_SELECT_OFFER_OPT float(10):=0.0;
  V_SELECT_PROD_OPT float(10):=0.0;
  V_SUBMIT_ORDER float(10):=0.0;
  V_PRINT_AGREEMENT float(10):=0.0;
  V_PAY1 float(10):=0.0;
  V_PAY2 float(10):=0.0;
  V_ORDER_CONFIRM float(10):=0.0;
  v_count     number:=0;
begin
  for cur in (select *
                from eye_order_info a where
                a.p_state='001' and a.channel_id = 'sale001' ) loop
  select count(1) into v_count
             from eye_order_node t
            where channel_id = 'sale001';
   if v_count>0 then
   select elapsed_time
     into V_QUERY_PROC
     from (select elapsed_time
             from eye_order_node t
            where channel_id = 'sale001'
            order by t.start_time)
    where rownum = 1;
   end if;
   --选可选包
    select sum(b.elapsed_time) into V_SELECT_OFFER_OPT from eye_order_node  a, eye_order_node  b where
    a.service_name='com.ffcs.crm2.order.ui.sale.optionoffer.OptionalOfferInstExt.refreshOptionOfferWithCallOuter'
    and a.cust_so_number=cur.cust_so_number
    and a.track_id=b.track_id and substr(b.service_name,0,1)='/';
    --选可选功能
    select sum(b.elapsed_time) into V_SELECT_PROD_OPT from eye_order_node  a, eye_order_node  b where
    a.service_name='com.ffcs.crm2.order.ui.sale.optionprod.OptionProdExt.refreshAppendWithCallOuter'
    and a.cust_so_number=cur.cust_so_number
    and a.track_id=b.track_id and substr(b.service_name,0,1)='/';
    --订单提交
    select sum(b.elapsed_time) into V_SUBMIT_ORDER from eye_order_node  a, eye_order_node  b where
    a.service_name='com.ffcs.crm2.order.context.OrderCtx.buildCustOrder'
    and a.cust_so_number=cur.cust_so_number
    and a.track_id=b.track_id and substr(b.service_name,0,1)='/';

    --协议打印
    select sum(b.elapsed_time) into V_PRINT_AGREEMENT from eye_order_node  a, eye_order_node  b where
    a.service_name='com.ffcs.crm2.order.manager.impl.OrderPrintManagerNewImpl.printOrder'
    and a.cust_so_number=cur.cust_so_number
    and a.track_id=b.track_id and substr(b.service_name,0,1)='/';

     --算费
    select sum(b.elapsed_time) into V_PAY1 from eye_order_node  a, eye_order_node  b where
    a.service_name='com.ffcs.crm2.order.context.OrderCtx.calculateOrder'
    and a.cust_so_number=cur.cust_so_number
    and a.track_id=b.track_id and substr(b.service_name,0,1)='/';
      --订单确认
    select sum(b.elapsed_time) into V_ORDER_CONFIRM from eye_order_node  a, eye_order_node  b where
    a.service_name='com.ffcs.crm2.order.manager.impl.OrderCreatorManagerImpl.submitCustomerOrder'
    and a.cust_so_number=cur.cust_so_number
    and a.track_id=b.track_id and substr(b.service_name,0,1)='/';
    insert into EYE_ORDER_ELAPSED_TIME
      (id,
       cust_so_number,
       prod_offer_id,
       offer_name,
       product_name,
       proc_name,
       query_cust,
       query_offer,
       query_proc,
       select_adr,
       select_num,
       select_offer_opt,
       select_prod_opt,
       submit_order,
       print_agreement,
       pay1,
       pay2,
       order_confirm,
       CREATE_ORDER_DATE,
       CREATE_TIME)
    values
      (EYE_ORDER_ELAPSED_TIME_ID_SEQ.NEXTVAL,
       cur.cust_so_number,
       cur.prod_offer_id,
       cur.offer_name,
       cur.product_name,
       cur.proc_name,
       V_QUERY_CUST,
       V_QUERY_OFFER,
       V_QUERY_PROC,
       V_SELECT_ADR,
       V_SELECT_NUM,
       V_SELECT_OFFER_OPT,
       V_SELECT_PROD_OPT,
       V_SUBMIT_ORDER,
       V_PRINT_AGREEMENT,
       V_PAY1,
       V_PAY2,
       V_ORDER_CONFIRM,
       cur.create_order_time,
       sysdate());
  update eye_order_info set p_state='002' where cust_so_number=cur.cust_so_number;

  end loop;

end eye_create_order_elapsed_time;
/
