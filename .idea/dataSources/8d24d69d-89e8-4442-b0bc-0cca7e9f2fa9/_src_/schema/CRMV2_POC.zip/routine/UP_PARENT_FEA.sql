CREATE procedure           up_parent_fea is
  cursor prod_fea is
    select * from temp_hmm_prod_fea_spec WHERE UP_FEA_SPEC_ID = 0;
  v_count  number(12);
  v_parent number(12);
begin
  for rec in prod_fea loop
    SELECT COUNT(*)
      into v_count
      FROM temp_hmm_prod_fea_spec_rela b
     where b.fea_id_b = rec.fea_spec_id;
    if v_count = 1 then
      v_parent := 0;
      SELECT b.fea_id_a
        into v_parent
        FROM temp_hmm_prod_fea_spec_rela b
       where b.fea_id_b = rec.fea_spec_id;
      update temp_hmm_prod_fea_spec mm
         set mm.up_fea_spec_id = v_parent
       where mm.fea_spec_id = rec.fea_spec_id;
    end if;
    commit;
  end loop;
end up_parent_fea;
/
