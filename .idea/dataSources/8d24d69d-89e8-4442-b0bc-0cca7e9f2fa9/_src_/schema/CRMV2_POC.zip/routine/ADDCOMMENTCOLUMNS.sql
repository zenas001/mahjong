CREATE procedure           addCommentColumns is
  cursor table_sql is
    SELECT * FROM ADD_TABLE;
  CURSOR comment_columns is
    SELECT * FROM COMMON_COLUMNS;
  V_SEQ         VARCHAR2(1000);
  v_seq_comment VARCHAR2(1000);
begin
  FOR REC IN table_sql LOOP
    FOR REC1 IN comment_columns LOOP
      V_SEQ         := '';
      v_seq_comment := '';
      SELECT 'alter table ' || REC.TABLE_NAME || ' add ' || REC1.COLUMNS_ID || ' ' ||
             REC1.COLUMNS_TYPE
        INTO V_SEQ
        from DUAL;
      EXECUTE IMMEDIATE V_SEQ;
      select 'comment on column ' || REC.TABLE_NAME || '.' ||
             REC1.COLUMNS_ID || ' is ' || REC1.COLUMNS_COMMENT
        INTO v_seq_comment
        from DUAL;
        EXECUTE IMMEDIATE v_seq_comment;
    END LOOP;
  END LOOP;
end addCommentColumns;
/
