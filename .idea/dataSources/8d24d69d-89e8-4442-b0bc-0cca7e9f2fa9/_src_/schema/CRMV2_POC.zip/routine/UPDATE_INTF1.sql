CREATE Procedure           update_intf1 Is

  i     number(10) := 0;
  v_err Varchar2(1000);
Begin

  begin
    for rec in (select distinct substr(a.remark,
                                       instr(a.remark, ')') + 2,
                                       instr(substr(a.remark,
                                                    instr(a.remark, ')')),
                                             '增量包旧记录') - 4) t_name,
                                substr(a.remark,
                                       instr(a.remark, '旧记录关键字段为:') + 9,
                                       instr(substr(a.remark,
                                                    instr(a.remark,
                                                          '旧记录关键字段为:') + 9),
                                             '=') - 1) col_name,
                                substr(a.remark,
                                       instr(a.remark, '=') + 1,
                                       instr(substr(a.remark,
                                                    instr(a.remark, '=')),
                                             ',') - 2) value
                  from crmv2.circle_info a, crmv2.customer_order b
                 where a.obj_inst_id = b.cust_order_id
                   and a.class_id = 24
                   and b.status_cd in ('400000', '2000098', '400099')
                   and a.remark like '%送计费系统失败%') LOOP
      begin

/*        if length(rec.t_name) > 0 then
          itsc_crmv2.new_p_ins_billing_update(rec.t_name,
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if (rec.col_name = 'CUST_ID') then
          itsc_crmv2.new_p_ins_billing_update('CUST',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if (rec.col_name = 'PARTY_ID') then
          itsc_crmv2.new_p_ins_billing_update('PARTY',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if (rec.col_name = 'PAYMENT_PLAN') then
          itsc_crmv2.new_p_ins_billing_update('PAYMENT_PLAN',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if (rec.col_name = 'PROD_OFFER_INST_ID') then
          itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
      */
       i  := 0;
      exception
        when others then
          v_err := Sqlerrm;
       /*   INSERT INTO zzy_intf_order_err_log
          VALUES
            (rec.t_name, rec.col_name, rec.Value, v_err, SYSDATE);
          COMMIT;
          Dbms_Output.put_line(rec.t_name||'-'||rec.col_name||'-'||rec.Value);
          RETURN;*/
      end;
    end loop;
  end;

  begin
    for rec in (select substr(remark,
                              instr(remark, ')') + 2,
                              instr(substr(remark, instr(remark, ')')),
                                    '增量包旧记录') - 4) t_name,
                       substr(remark,
                              instr(remark, '旧记录关键字段为:') + 9,
                              instr(substr(remark,
                                           instr(remark, '旧记录关键字段为:') + 9),
                                    '=') - 1) col_name,
                       substr(remark,
                              instr(remark, '=') + 1,
                              instr(substr(remark, instr(remark, '=')), ',') - 2) value,
                       a.*
                  from crmv2.circle_info a, crmv2.ORDER_ITEM b
                 where a.obj_inst_id = b.order_item_id
                   and a.class_id = 110
                   and b.status_cd in
                       ('400097', '200098', '400096', '400095', '400094')
                   and a.remark like '%送计费系统失败%') loop
      begin

  /*        if length(rec.t_name) > 0 and rec.value <> 2507896619 then
            itsc_crmv2.new_p_ins_billing_update(rec.t_name,
                                                rec.col_name,
                                                rec.value,
                                                'upload',
                                                'zengx');
          end if;*/
          i  := 0;
      exception
        when others then
          v_err := Sqlerrm;
/*          INSERT INTO zzy_intf_order_err_log
          VALUES
            (rec.t_name, rec.col_name, rec.Value, v_err, SYSDATE);
          COMMIT;*/
      end;
    end loop;
  end;

  begin
    for rec in (select distinct substr(remark,
                                       instr(remark, ')') + 2,
                                       instr(substr(remark,
                                                    instr(remark, ')')),
                                             '计费内存') - 4) t_name,
                                substr(remark,
                                       instr(remark, '旧记录关键字段为:') + 9,
                                       instr(substr(remark,
                                                    instr(remark,
                                                          '旧记录关键字段为:') + 9),
                                             '=') - 1) col_name,
                                substr(remark,
                                       instr(remark, '=') + 1,
                                       instr(substr(remark,
                                                    instr(remark, '=')),
                                             ',') - 2) value
                  from crmv2.circle_info a, crmv2.ORDER_ITEM b
                 where a.obj_inst_id = b.order_item_id
                   and a.class_id = 110
                   and b.status_cd in
                       ('400097', '200098', '400096', '400095', '400094')
                   and a.remark like '%送计费系统失败%') loop
      begin
/*        if (rec.col_name = 'PROD_INST_ATTR_ID') then
          itsc_crmv2.new_p_ins_billing_update('PROD_INST_ATTR',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if (rec.col_name = 'OFFER_PROD_INST_REL_ID') then
          itsc_crmv2.new_p_ins_billing_update('OFFER_PROD_INST_REL',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if (rec.col_name = 'PROD_OFFER_INST_ID') then
          itsc_crmv2.new_p_ins_billing_update('PROD_OFFER_INST',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if (rec.col_name = 'PROD_INST_REL_ID') then
          itsc_crmv2.new_p_ins_billing_update('PROD_INST_REL',
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;
        if length(rec.t_name) > 0 and rec.value <> 2507896619 then
          itsc_crmv2.new_p_ins_billing_update(rec.t_name,
                                              rec.col_name,
                                              rec.value,
                                              'upload',
                                              'zengx');
        end if;*/
        i  := 0;
      exception
        when others then
          v_err := Sqlerrm;
/*          INSERT INTO zzy_intf_order_err_log
          VALUES
            (rec.t_name, rec.col_name, rec.Value, v_err, SYSDATE);
          COMMIT;*/
      end;
    end loop;
  end;


  update crmv2.customer_order

     set status_cd = '200098', PROC_PRIORITY = '200'
   where status_cd = '400000'
     and CUST_ORDER_ID in
         (select b.CUST_ORDER_ID
            from crmv2.circle_info a, crmv2.customer_order b
           where a.obj_inst_id = b.cust_order_id
             and a.class_id = 24
             and b.status_cd = '400000'
             and a.call_times < 100);
  update crmv2.customer_order
     set status_cd = '101201', PROC_PRIORITY = '200'
   where status_cd = '400001'
     and CUST_ORDER_ID in
         (select b.CUST_ORDER_ID
            from crmv2.circle_info a, crmv2.customer_order b
           where a.obj_inst_id = b.cust_order_id
             and a.class_id = 24
             and b.status_cd = '400001'
             and a.call_times < 100);
  update crmv2.order_item
     set status_cd = '200098', PROC_PRIORITY = '200'
   where status_cd = '400097'
     and ORDER_ITEM_ID in (select b.ORDER_ITEM_ID
                             from crmv2.circle_info a, crmv2.ORDER_ITEM b
                            where a.obj_inst_id = b.ORDER_ITEM_ID
                              and a.class_id = 110
                              and b.status_cd = '400097'
                              and a.call_times < 100);
  update crmv2.customer_order
     set status_cd = '200000'
   where status_cd = '400099';
  update crmv2.order_item
     set status_cd = '400099'
   where status_cd = '200096'
     and STATUS_DATE < sysdate - 1 / 24;
/*  select count(1)
    into i
    from ITSC_CRMV2.INTF_INS_BILLING_UPDATE a
   where state in ('70G');
  if i < 50000 then
    update ITSC_CRMV2.INTF_INS_BILLING_UPDATE
       set state = '70G'
     where state = '70T'
       and rownum < 50000;
  end if;*/

  commit;
End;
/
