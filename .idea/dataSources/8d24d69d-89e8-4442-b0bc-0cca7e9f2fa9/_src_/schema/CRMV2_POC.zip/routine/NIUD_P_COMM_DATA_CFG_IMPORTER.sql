CREATE procedure           niud_p_comm_data_cfg_importer(o_cnt out number) is
  /****
    功能：将1.0的o_data_cfg表
          导入2.0的comm_data_cfg表
    出参：o_cnt - 导入的记录个数
             by niud, 120612
  ****/
  v_type           number(2);
  v_rela_prod_spec number(10);
  v_seq_name       varchar2(30);
  v_cnt            number(10) := 0;
  v_tmp            number(2);
  v_remark         varchar2(200) := 'imported via niud_p_comm_data_cfg_importer-2';
  cursor cur is
    select y.prod_id_2, o.*
      from o_data_cfg@lk_crmv1 o, mdse_ys_product y
     where o.prod_spec_id = y.prod_id_1
       and not exists
     (select 1
              from comm_data_cfg c
             where o.seq_name = c.seq_name
               and y.prod_id_2 = c.prod_spec_id
               and nvl(o.prefix, ' ') = nvl(c.prefix, ' ')
               and o.num_len = c.num_len
               and nvl(o.backfix, ' ') = nvl(c.backfix, ' '))
       and y.prod_id_2 is not null;
  /****
    1.0的组合套餐在2.0是可选群组
    不再有对应的产品
    因此号码生成规则要配置在销售品级别
    先前lisy已手工导入福州的可选群组
    在此基础上进行全省配置
            by niud, 120627
  ****/
  cursor cur_m is
    select *
      from comm_data_cfg c
     where prod_spec_id = 0
       and area_id = 2;
  cursor cur_o is
    select *
      from o_data_cfg@lk_crmv1
     where prod_spec_id = (select prod_spec_id
                             from o_data_cfg@lk_crmv1
                            where seq_name = v_seq_name)
       and area_id <> 2;
begin
  for rec in cur loop
    if rec.postfix_value is null then
      v_type := 0;
    else
      v_type := 1;
    end if;
    if rec.rela_prod_spec > 0 then
      begin
        select y.prod_id_2
          into v_rela_prod_spec
          from mdse_ys_product y
         where y.prod_id_1 = rec.rela_prod_spec;
      exception
        when no_data_found then
          begin
            select distinct y.prod_id_2
              into v_rela_prod_spec
              from mdse_ys_product                          y,
                   crm.niud_broadband_fea_unifying@lk_crmv1 n
             where n.prod_spec_id_new = y.prod_id_1
               and n.prod_spec_id_old = rec.rela_prod_spec;
          exception
            when no_data_found then
              v_rela_prod_spec := rec.rela_prod_spec;
          end;
      end;
    else
      v_rela_prod_spec := rec.rela_prod_spec;
    end if;
    insert into comm_data_cfg
    values
      (comm_data_cfg_seq.nextval,
       rec.area_id,
       rec.prod_id_2,
       rec.fee_type,
       rec.prefix,
       rec.seq_name,
       rec.num_len,
       rec.postfix_value,
       v_rela_prod_spec,
       rec.backfix,
       rec.mdse_spec_id,
       null, --prefix_value
       v_type,
       null,
       v_remark,
       null);
    v_cnt := v_cnt + 1;
  end loop;
  for rec_m in cur_m loop
    v_seq_name := rec_m.seq_name;
    for rec_o in cur_o loop
      select count(*)
        into v_tmp
        from comm_data_cfg
       where seq_name = rec_o.seq_name
         and area_id = rec_o.area_id
         and prefix = rec_o.prefix
         and num_len = rec_o.num_len
         and mdse_spec_id = rec_m.mdse_spec_id;
      if v_tmp = 0 then
        insert into comm_data_cfg
        values
          (comm_data_cfg_seq.nextval,
           rec_o.area_id,
           0,
           rec_o.fee_type,
           rec_o.prefix,
           rec_o.seq_name,
           rec_o.num_len,
           rec_o.postfix_value,
           rec_m.rela_prod_spec,
           rec_o.backfix,
           rec_m.mdse_spec_id,
           rec_m.prefix_value,
           rec_m.cfg_type,
           rec_m.regex,
           v_remark,
           rec_m.attr_java_code);
        v_cnt := v_cnt + 1;
      end if;
    end loop;
  end loop;
  o_cnt := v_cnt;
end;
/
