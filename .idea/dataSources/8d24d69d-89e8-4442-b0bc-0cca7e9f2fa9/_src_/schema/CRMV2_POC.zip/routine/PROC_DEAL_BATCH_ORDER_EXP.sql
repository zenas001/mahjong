CREATE procedure           proc_deal_batch_order_exp
is
  /**
   功能说明：批量异常订单处理
   author：luxb
   创建时间：2012-12-28
  **/
  i_cust_order_id number;
  i_count         number;
  cursor i_order  is
  select distinct co.cust_order_id,co.cust_so_number
  from batch_order_data t,batch_order_rel r,customer_order co
 where t.create_date>to_date('2013-2-6','yyyy-MM-dd')
   and t.batch_order_id = r.batch_order_id
   and r.cust_order_id = co.cust_order_id
   and co.status_cd = '200099'
   and (t.remark like 'SimpleThreadPool.java%' or t.remark like 'java.lang.NullPointerException%')
   and (ROUND(co.reason) < 10 or ROUND(co.reason) is null);
  cursor i_data is
  select od.order_data_id
   from crmv2.batch_order_rel r, crmv2.batch_order_data od
  where r.cust_order_id = i_cust_order_id
    and r.batch_order_id = od.batch_order_id
    and r.data_type = '50'
    and (od.remark like 'SimpleThreadPool.java%' or
          od.remark like '规则执行:错误提示:Could not open Hibernate Session for transaction;%'
          or od.remark like 'java.lang.NullPointerException%');
begin
   --
   for ia in i_order loop
   i_cust_order_id := ia.cust_order_id;
   for ic in i_data loop
   update crmv2.batch_order_data
   set remark = '', status = '401700'
   where order_data_id = ic.order_data_id;
   end loop;
   update order_item set status_cd = '200000' where cust_order_id = ia.cust_order_id;
   select ROUND(co.reason) into i_count from customer_order co where co.cust_order_id = ia.cust_order_id;
   if i_count is null then
      i_count := 0;
   end if;
   update customer_order set status_cd = '200098',reason=''|| (i_count+1) where cust_order_id = ia.cust_order_id;
   end loop;
   commit;
end;
/
