CREATE function           niud_f_offer_prod_rel_role(i_prefer_spec_id in number,
                                                      o_msg            out varchar2)
  return number is

  /****
    功能：
        将1.0组合套餐的角色适用销售品
        导入2.0群组类可选包的产品关联角色
        需要事先将2.0的角色配置好
    入参：
        i_prefer_spec_id - 1.0组合套餐规格ID
    出参：
        o_msg - 提示信息
    返回：
        1 - 正常插入数据
        0 - 插入0条数据
        -1 - 2.0未配置角色
        -2 - 2.0存在多个角色
        -3 - 1.0规格ID有误

                           by niud, 120509

    增加offer_prod_rel.area_id配置
                           by niud, 120528
  ****/

  v_role_cd offer_prod_rel_role.role_cd%type;
  v_rela_id number(10);
  v_rel_id  offer_prod_rel.offer_prod_rela_id%type;
  v_area_id offer_prod_rel.area_id%type;
  v_tmp     number(4);
  v_cnt     number(4);
  v_remark  varchar2(200) := 'imported via niud_f_offer_prod_rel_role';

  cursor cur_p is
    select * from mdse_ys_lisy_new where id_v1 = i_prefer_spec_id;

  cursor cur_r is
    select *
      from prefer_mdse_spec_rela@lk_crmv1
     where state = '70A'
       and prefer_spec_id = i_prefer_spec_id;

  cursor cur_m is
    select distinct y.prod_id_2
      from pm_special_mdse_spec@lk_crmv1 m,
           mdse_spec@lk_crmv1            ms,
           mdse_ys_product               y
     where m.mdse_spec_id = ms.mdse_spec_id
       and ms.prod_spec_id = y.prod_id_1
       and y.state_cd = '在售'
       and m.state = '70A'
       and m.role_id = v_rela_id;

begin
  select count(*)
    into v_tmp
    from mdse_ys_lisy_new
   where id_v1 = i_prefer_spec_id;
  if v_tmp = 0 then
    o_msg := '1.0规格ID有误或不存在匹配记录！';
    return(-3);
  end if;

  v_cnt := 0;
  o_msg := 'select * from offer_prod_rel where offer_prod_rela_id in (';
  for rec_p in cur_p loop
    select area_id
      into v_area_id
      from prod_offer
     where prod_offer_id = rec_p.id_v2;
    for rec_r in cur_r loop
      begin
        select role_cd
          into v_role_cd
          from offer_prod_rel_role
         where prod_offer_id = rec_p.id_v2
           and lower(role_name) = lower(rec_r.name);
      exception
        when no_data_found then
          o_msg := '2.0未找到角色“' || rec_r.name || '”！';
          return(-1);
        when too_many_rows then
          o_msg := '2.0找到多个角色“' || rec_r.name || '”！';
          return(-2);
      end;

      v_rela_id := rec_r.rela_id;
      for rec_m in cur_m loop
        select count(*)
          into v_tmp
          from offer_prod_rel
         where product_id = rec_m.prod_id_2
           and prod_offer_id = rec_p.id_v2
           and role_cd = v_role_cd
           and rule_type = '10';
        if v_tmp = 0 then
          select seq_offer_prod_rel_id.nextval into v_rel_id from dual;
          insert into offer_prod_rel
          values
            (v_rel_id,
             rec_m.prod_id_2,
             rec_p.id_v2,
             v_role_cd,
             null,
             null,
             '10', --可选关系
             '1000',
             sysdate,
             sysdate,
             sysdate,
             null,
             v_area_id,
             null,
             -1,
             -1,
             'N',
             null,
             null,
             null,
             null,
             null,
             null,
             v_remark,
             null,
             sysdate);
          v_cnt := v_cnt + 1;
          o_msg := o_msg || to_char(v_rel_id) || ', ';
        end if;
      end loop;
    end loop;
  end loop;

  if v_cnt = 0 then
    o_msg := '没有插入任何记录。';
    return(0);
  else
    o_msg := substr(o_msg, 1, length(o_msg) - 2) || '); --插入' ||
             to_char(v_cnt) || '条记录。';
    return(v_cnt);
  end if;

end;
/
