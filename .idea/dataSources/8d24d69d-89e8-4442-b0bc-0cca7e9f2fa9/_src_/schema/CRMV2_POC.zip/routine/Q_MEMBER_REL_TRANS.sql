CREATE PROCEDURE           Q_MEMBER_REL_TRANS(i_order_item_id IN NUMBER) IS
  V_MEMBER_REL_SEQ NUMBER;
  V_CUST_ORDER_ID  NUMBER;
  V_REL_ID         NUMBER;

BEGIN
  V_MEMBER_REL_SEQ := SEQ_AUTOTEST_MEMBER_REL_ID.NEXTVAL;
  select cust_order_id
    INTO V_CUST_ORDER_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  select order_item_obj_id
    INTO V_REL_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;

  insert into autotest_member_rel
    (AUTOTEST_MEMBER_REL_ID,
     CUST_ORDER_ID,
     RELATION_TYPE_CD,
     PROD_INST_A_ID,
     PROD_INST_Z_ID,
     ROLE_CD,
     CREATE_DATE)
    select V_MEMBER_REL_SEQ   AUTOTEST_MEMBER_REL_ID,
           V_CUST_ORDER_ID    CUST_ORDER_ID,
           D.RELATION_TYPE_CD,
           D.PROD_INST_A_ID,
           D.PROD_INST_Z_ID,
           D.ROLE_CD,
           SYSDATE            CREATE_DATE
      from crmv2.prod_inst_REL D
     where d.prod_inst_REL_id = V_REL_ID;

END Q_MEMBER_REL_TRANS;
/
