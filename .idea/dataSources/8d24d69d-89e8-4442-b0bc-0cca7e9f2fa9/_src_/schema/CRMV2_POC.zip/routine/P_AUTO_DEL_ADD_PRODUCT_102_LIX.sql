CREATE PROCEDURE           p_auto_del_add_product_102_lix
/***************************************************************
   FUN NAME: 自动拆除需要送施工的功能类产品
   VERSION: V1.0.0
   AUTHOR: ZHENGZY
   CREATE_DATE: 20130628
   功能说明：自动拆除需要送施工的功能类产品
   使用范例：
   declare
   o_msg varchar2(100)；
   begin
     ffzhengzy.p_auto_del_product_102(94810750,   -- 功能类产品实例ID
                           'fftest',    --修改人
                           'xxxxxxx',   --修改备注
                           o_msg);
   end ;
  ****************************************************************/
(i_prod_inst_id_102 IN NUMBER, --  功能类产品实例ID
 in_product_id      in number,
 in_modi_staff      IN VARCHAR2, -- 修改人
 i_remark           IN VARCHAR2, --修改备注
 o_queue_id         OUT VARCHAR2) IS
  v_id  NUMBER(10);
  v_id2 NUMBER(10);
  v_id3 NUMBER(10);
  v_id4 NUMBER(10);
BEGIN
  o_queue_id := 0;
  --取出功能类产品实例id，接入类产品实例id，接入类T01主销售品
  FOR rec IN (SELECT b.prod_offer_inst_id, a.prod_inst_id, d.prod_inst_z_id
                FROM crmv2.offer_prod_inst_rel a,
                     crmv2.prod_offer_inst     b,
                     crmv2.prod_offer          c,
                     crmv2.prod_inst_rel       d,
                     crmv2.prod_inst           e,
                     crmv2.product             f
               WHERE 1 = 1
                 AND d.prod_inst_z_id = i_prod_inst_id_102
                 AND d.prod_inst_a_id = a.prod_inst_id
                 AND a.prod_offer_inst_id = b.prod_offer_inst_id
                 AND b.prod_offer_id = c.prod_offer_id
                 AND c.offer_sub_type = 'T01'
                 AND b.status_cd = '1000'
                 AND d.prod_inst_a_id = e.prod_inst_id
                 AND e.product_id = f.product_id
                 AND f.prod_func_type = '101'
                 AND d.relation_type_cd = '100600') LOOP
    BEGIN
      SELECT crmv2.seq_o_auto_proc_queue_id.nextval INTO v_id FROM dual;
      SELECT crmv2.seq_o_auto_proc_queue_id.nextval INTO v_id2 FROM dual;
      SELECT crmv2.seq_o_auto_proc_queue_id.nextval INTO v_id3 FROM dual;
      SELECT crmv2.seq_o_auto_proc_queue_id.nextval INTO v_id4 FROM dual;

      INSERT INTO crmv2.o_auto_proc_queue
        SELECT v_id,
               0,
               '',
               'ProdOfferInst',
               prod_offer_inst_id,
               '3020500000',
               'MOD',
               '',
               '',
               in_modi_staff || i_remark,
               in_modi_staff || i_remark,
               '',
               '',
               area_id,
               region_cd,
               '',
               SYSDATE,
               '200099',
               SYSDATE,
               '',
               SYSDATE,
               poi.cust_id,
               ''
          FROM crmv2.prod_offer_inst poi
         WHERE poi.prod_offer_inst_id = rec.prod_offer_inst_id;

      INSERT INTO crmv2.o_auto_proc_queue
        SELECT v_id2,
               v_id,
               '',
               'ProdInst',
               rec.prod_inst_id,
               '4040800000',
               'MOD',
               '',
               '',
               in_modi_staff || i_remark,
               in_modi_staff || i_remark,
               '',
               '',
               area_id,
               region_cd,
               '',
               SYSDATE,
               '200099',
               SYSDATE,
               '',
               SYSDATE,
               '',
               ''
          FROM crmv2.prod_offer_inst poi
         WHERE poi.prod_offer_inst_id = rec.prod_offer_inst_id;

      INSERT INTO crmv2.o_auto_proc_queue
        SELECT v_id3,
               v_id2,
               '',
               'ProdInst',
               rec.prod_inst_z_id,
               '4020100000',
               'MOD',
               '',
               '',
               in_modi_staff || i_remark,
               in_modi_staff || i_remark,
               '',
               '',
               area_id,
               region_cd,
               '',
               SYSDATE,
               '200099',
               SYSDATE,
               '',
               SYSDATE,
               '',
               ''
          FROM crmv2.prod_offer_inst poi
         WHERE poi.prod_offer_inst_id = rec.prod_offer_inst_id;

      INSERT INTO crmv2.o_auto_proc_queue
        (queue_id,
         super_queue_id,
         priority,
         src_type,
         src_inst_id,
         src_action,
         proc_type,
         cust_order_id,
         order_item_id,
         remark,
         queue_desc,
         EXTEND,
         eff_date,
         area_id,
         region_cd,
         create_staff,
         create_date,
         status_cd,
         status_date,
         update_staff,
         update_date,
         cust_id,
         begin_date)
        SELECT v_id4,
               v_id2,
               '',
               'Product',
               in_product_id,
               '3010100000' src_action,
               'ADD' proc_type,
               '' cust_order_id,
               '' order_item_id,
               '' remark,
               i_remark queue_desc,
               '' EXTEND,
               '' eff_date,
                area_id,
                region_cd,
               '' create_staff,
               SYSDATE create_date,
               '200098' status_cd,
               SYSDATE status_date,
               '' update_staff,
               '' update_date,
               '' cust_id,
               '' begin_date
          FROM crmv2.prod_offer_inst poi
         WHERE poi.prod_offer_inst_id = rec.prod_offer_inst_id;

      --插入拆除的渠道属性
      INSERT INTO crmv2.proc_queue_attr
        SELECT crmv2.seq_proc_queue_attr_id.nextval,
               v_id,
               0,
               'CHNCD',
               0,
               0,
               'INSERT',
               in_modi_staff || i_remark,
               area_id,
               region_cd,
               '51447',
               SYSDATE,
               '',
               SYSDATE,
               '51447',
               SYSDATE,
               '600105B021',
               '',
               '',
               ''
          FROM crmv2.prod_offer_inst poi
         WHERE poi.prod_offer_inst_id = rec.prod_offer_inst_id;
      -- //增加插入销售品备注。
      INSERT INTO crmv2.proc_queue_attr
        SELECT crmv2.seq_proc_queue_attr_id.nextval,
               v_id,
               0,
               'EA',
               800015094,
               0,
               'INSERT',
               in_modi_staff || i_remark,
               area_id,
               region_cd,
               '51447',
               SYSDATE,
               '',
               SYSDATE,
               '51447',
               SYSDATE,
               '【' || in_modi_staff || '】因【 ' || i_remark || ' 】修改',
               '',
               '',
               ''
          FROM crmv2.prod_offer_inst poi
         WHERE poi.prod_offer_inst_id = rec.prod_offer_inst_id;

      INSERT INTO crmv2.proc_queue_attr
        SELECT crmv2.seq_proc_queue_attr_id.nextval,
               v_id,
               0,
               'CHECK',
               0,
               0,
               '',
               in_modi_staff || i_remark,
               area_id,
               region_cd,
               '51447',
               SYSDATE,
               '',
               SYSDATE,
               '51447',
               SYSDATE,
               '',
               '',
               '',
               ''
          FROM crmv2.prod_offer_inst poi
         WHERE poi.prod_offer_inst_id = rec.prod_offer_inst_id;
      o_queue_id := '拆除队列的主键id= ' || v_id;
    EXCEPTION
      WHEN OTHERS THEN
        o_queue_id := 0;
    END;
  END LOOP;
  COMMIT;
END;
/
