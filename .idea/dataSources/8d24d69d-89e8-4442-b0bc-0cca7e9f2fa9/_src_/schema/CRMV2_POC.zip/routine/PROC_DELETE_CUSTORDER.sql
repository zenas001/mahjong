CREATE procedure           PROC_DELETE_CUSTORDER(cust_so_number in char) is
begin
  --查询订单项对应的所有的产品
  for rec in (select *
                from prod_inst pi
               where exists (select 1
                        from customer_order co, order_item oi
                       where co.cust_so_number = cust_so_number
                         and co.cust_order_id = oi.order_item_id
                         and oi.entt_spec_type = 'AP')) loop
    --删除账户定制关系属性
    delete from prod_inst_acct_attr piaa
     where exists (select 1
              from prod_inst_acct pia
             where piaa.prod_inst_acct_id = pia.prod_inst_acct_id
               and pia.prod_inst_id = rec.prod_inst_id);
    --删除产品实例
    delete from prod_inst where prod_inst_id = rec.prod_inst_id;
    --删除账户定制关系
    delete from prod_inst_acct where prod_inst_id = rec.prod_inst_id;
    --删除产品属性
    delete from prod_inst_attr where prod_inst_id = rec.prod_inst_id;
    --  删除产品关联
    delete from prod_inst_rel
     where prod_inst_a_id = rec.prod_inst_id
        or prod_inst_z_id = rec.prod_inst_id;
    --删除销售品实例
    delete from prod_offer_inst poi
     where exists (select 1
              from offer_prod_inst_rel opie
             where poi.prod_offer_inst_id = opie.prod_offer_inst_id
               and opie.prod_inst_id = rec.prod_inst_id);
    --删除销售品关联
    delete from prod_offer_inst_rel poi
     where exists
     (select 1
              from offer_prod_inst_rel opie
             where (poi.rela_prod_offer_inst_id = opie.prod_offer_inst_id or
                   poi.related_prod_offer_inst_id = opie.prod_offer_inst_id)
               and opie.prod_inst_id = rec.prod_inst_id);

    --删除产品销售品关联
    delete from offer_prod_inst_rel where prod_inst_id = rec.prod_inst_id;
  end loop;

  ---删除订单信息
  delete from order_item_act_rela oiar
   where exists (select 1
            from order_item oi, customer_order co
           where oiar.order_item_id = oi.order_item_id
             and oi.cust_order_id = co.cust_order_id
             and co.cust_so_number = cust_so_number);
  --删除订单处理属性
  delete from order_item_proc_attr oipa
   where exists (select 1
            from order_item oi, customer_order co
           where oipa.order_item_id = oi.order_item_id
             and oi.cust_order_id = co.cust_order_id
             and co.cust_so_number = cust_so_number);
  --删除订单项
  delete from order_item
   where exists
   (select 1 from customer_order where cust_so_number = cust_so_number);
  --删除订单
  delete from customer_order where cust_so_number = cust_so_number;
  commit;
end PROC_DELETE_CUSTORDER;
/
