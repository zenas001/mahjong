CREATE procedure           ds_ins_intf_ins_ds_update_wh(v_table_name        in varchar2, -- 表名
                                                         v_primary_key       in varchar2, -- 主键字段名
                                                         v_primary_key_value in number, -- 主键值
                                                         v_name              in varchar2, -- 表名说明
                                                         v_from              in varchar2, -- 来源说明
                                                         v_op_type           in varchar2, -- 数据库操作类型：CREATE、UPDATE、DELETE
                                                         v_sharding_id       in varchar2 -- 分片键值，DELETE动作且为分片库表时，需要填值，其它情况为空值
                                                         ) is
  v_flag varchar2(6);
begin
  v_flag := '';
  -- 判断表是否需要双写
  begin
    select 'x'
      into v_flag
      from sys_class
     where (table_name = upper(v_table_name) or his_table_name = upper(v_table_name))
       and is_ds is not null
       and rownum <= 1;
  exception
    when no_data_found then
      return;
  end;
  if v_flag = 'x' then
  null;
  /***
    -- 将表信息插入intf_ins_ds_update表中
    insert into intf_ins_ds_update
      (INS_ID,
       TABLE_NAME,
       COLUMN_NAME,
       KEY_ID,
       TOPIC,
       TYPE,
       REASON,
       OPERATOR,
       STATE,
       STATE_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       DEAL_NUM,
       NEXT_DEAL_TIME,
       ERR_MSG,
       REMARK,
       AREA_NBR,
       OP_TYPE,
       SHARDING_ID)
    values
      (seq_intf_ins_ds_update_id.nextval,
       upper(v_table_name),
       upper(v_primary_key),
       v_primary_key_value,
       v_name,
       '1001',
       v_from,
       null,
       '70A',
       sysdate,
       sysdate,
       sysdate,
       0,
       null,
       null,
       null,
       null,
       v_op_type,
       v_sharding_id);
       **/
  end if;
end ds_ins_intf_ins_ds_update_wh;
/
