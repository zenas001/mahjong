CREATE FUNCTION           fnc_add_system_user(i_staff_code     IN VARCHAR2,
                                               i_position_id    IN NUMBER,
                                               i_sys_type       IN VARCHAR2,
                                               i_p_privilege_id IN NUMBER)
  RETURN BOOLEAN IS
  RESULT           BOOLEAN;
  i_party_id       INTEGER;
  i_staff_id       INTEGER;
  i_system_user_id INTEGER;
  /**
  //2012-4-18 linzhiqiang
  增加登陆员工
  入参：
  i_staff_code     登录名
  i_position_id    初始岗位
  i_sys_type       所属系统
  i_p_privilege_id 根节点权限
  **/
BEGIN
  SELECT seq_party_id.nextval INTO i_party_id FROM dual;
  SELECT seq_staff_id.nextval INTO i_staff_id FROM dual;
  SELECT seq_system_user_id.nextval INTO i_system_user_id FROM dual;

  --插入参与人信息
  INSERT INTO party
    (party_id, party_name, party_type, status_cd, area_id, region_cd)
  VALUES
    (i_party_id, i_staff_code, '0', '1000', 1, 1);

  --插入参与人证件信息
  INSERT INTO party_certification
    (party_certi_id, party_id, cert_type, cert_number, status_cd, area_id, region_cd)
  VALUES
    (seq_party_certification_id.nextval, i_party_id, '1', 'test', '1000', 1, 1);

  --插入sataff记录
  INSERT INTO staff
    (staff_id, staff_code, party_id, org_id, status_cd, area_id, region_cd)
  VALUES
    (i_staff_id, i_staff_code, i_party_id, '14388', '1000', 1, 1);

  --插入系统用户
  INSERT INTO system_user
    (system_user_id, staff_id, staff_code, password, password_eff_date, password_exp_date, status_cd, area_id, region_cd)
  VALUES
    (i_system_user_id, i_staff_id, i_staff_code, '202CB962AC59075B964B07152D234B70', SYSDATE, add_months(to_date(to_char(SYSDATE,
                                 'YYYY-MM-DD'),
                         'YYYY-MM-DD'),
                 6), '1000', 1, 1);

  --插入参与人角色
  INSERT INTO party_role
    (party_role_id, party_id, role_type, status_cd, area_id, region_cd)
  VALUES
    (seq_party_role_id.nextval, i_party_id, '1200', '1000', 1, 1);

  --插入任职岗位
  INSERT INTO staff_position
    (staff_position_id, org_id, position_id, staff_id, status_cd, area_id, region_cd)
  VALUES
    (seq_staff_position_id.nextval, 1000152, i_position_id, i_staff_id, '1000', 1, 1);

  --COMMIT;
  RESULT := TRUE;
  RETURN(RESULT);
EXCEPTION
  WHEN OTHERS THEN
    RESULT := FALSE;
    RETURN(RESULT);
END fnc_add_system_user;
/
