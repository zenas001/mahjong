CREATE PROCEDURE           proc_invoice(startnum      IN NUMBER,
                                         endnum        IN NUMBER,
                                         invoicecode   IN VARCHAR2,
                                         storeid       IN NUMBER,
                                         mktresospecid IN NUMBER) IS
  i          NUMBER;
  cont       NUMBER;
  mktresokey VARCHAR2(50);
BEGIN
  i          := startnum;
  cont       := 0;
  mktresokey := '';
  LOOP
    --如果出现已存在的串码则不处理
    mktresokey := invoicecode || ';' || lpad(i, 8, '0');
    --select count(*) into cont from mkt_resource a where a.MKT_RESO_KEY=mktresokey and a.MKT_RESO_SPEC_TYPE=610007666 and rownum<2;
    EXECUTE IMMEDIATE 'select count(1) from mkt_resource a where a.MKT_RESO_KEY=:mktresokey and a.MKT_RESO_SPEC_TYPE=610007666 and rownum<2'
      INTO cont
      USING mktresokey;
    IF cont = 0 THEN
      INSERT INTO mkt_resource
        (mkt_reso_id, storage_id, mkt_reso_spec_id, mkt_reso_key, batch_id,
         state, modi_time, crea_time, mkt_reso_spec_type)
      VALUES
        (mkt_reso_id_seq.NEXTVAL, storeid, mktresospecid, mktresokey, '',
         '70A', SYSDATE, SYSDATE, 610007666);
      INSERT INTO tax_invoice_temp
        (invoice_id, mkt_reso_key, storage_id, invoice_code, invoice_num)
      VALUES
        (tax_invoice_temp_seq.NEXTVAL,
         invoicecode || ';' || lpad(i, 8, '0'), storeid, invoicecode, i);
    END IF;
    --
    i := i + 1;
    IF i > endnum THEN
      EXIT;
    END IF;
  END LOOP;
END proc_invoice;
/
