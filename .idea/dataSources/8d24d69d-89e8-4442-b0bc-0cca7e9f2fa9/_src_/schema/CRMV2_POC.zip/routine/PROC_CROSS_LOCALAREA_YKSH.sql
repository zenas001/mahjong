CREATE procedure           proc_cross_localarea_yksh(i_pi_id       in varchar2, --虚号码产品实例ID
                                                      i_po_id       in varchar2, --虚号码主销售品ID
                                                      i_main_accnbr in varchar2, --主号的业务号码
                                                      i_main_region  in varchar2, --区域
                                                      op_flag       in varchar2, --操作标识 0--新增
                                                      o_result      out varchar2) is
  i_prod_count       number := 0;
  v_acc_nbr          varchar(20);
  v_region_cd        varchar(10);
  v_cust_id          number;
  v_prod_id          number;
  v_mdse_id          number;
  v_acct_count       number := 0;
  v_tel_acct_id_seq  number;
  v_zgid_seq         number;
  v_mdse_rela_seq    number;
  v_mdse_rela_seq2   number;
  v_payment_plan_seq number;
  v_payment_plan_id  number;
  v_zh_seq           number;
  v_mdse_idb         number;
  v_batch_num        number;
  v_custId           number;
  v_xh_count         number;
  v_prod_idb         number;
  v_mdse_rela_id     number;
  v_mdse_rela_count  number;
  v_main_area_code   varchar2(20);
  v_prod_offer_id    number;
  v_prod_offer_count number;
  v_price_rela_count number;
  v_price_rela_id    number;
  v_mdse_rela_count2  number;
  v_area_code_count  number;
  v_cust_price_plan_count number;
  v_cust_price_plan_id number;
  v_main_mdse_id     number;
  v_main_region      varchar2(20);
  v_main_prod_spec_id number;
  cursor i_acct is
    select a.account_number, a.account_id,pia.prod_inst_acct_id
      from prod_inst_acct pia, account a
     where pia.prod_inst_id = i_pi_id
       and pia.account_id = a.account_id;
  cursor i_rela is
  select pp.cust_price_plan_param_id
  from BILL.cust_price_plan_param@lk_tocrm1_cross pp
 where pp.mdse_id in
       (select mpr.rela_id
          from crm.mdse_price_rela@lk_tocrm1_cross mpr, crm.prod_common@lk_tocrm1_cross pm
         where mpr.mdse_id  = v_main_mdse_id
           and pm.sort = 'T7_PRICE_YKSH'
           and pm.code = mpr.price_id)
   and pp.pricing_param_id = 11084016
   and pp.state = '00D';
  /**
   功能说明：一卡双号虚号码同步到1.0
   author：luxb
   创建时间：2012-5-23
  **/
begin
  --同步批次号
  select seq_cross_localarea_batch_id.nextval into v_batch_num from dual;

  if op_flag is not null then
    --新装
    select t.owner_cust_id, t.acc_nbr, t.common_region_id
      into v_cust_id, v_acc_nbr, v_region_cd
      from prod_inst t
     where t.prod_inst_id = i_pi_id;

    select k.khid
      into v_custId
      from cust c, crm.kh@lk_tocrm1_cross k
     where c.cust_id = v_cust_id
       and c.cust_number = k.khbm;

    if op_flag = '0' then
     /*update prod_inst
       set area_code = '0591', common_region_id = '11', area_id = 2
     where prod_inst_id = i_pi_id;

    update prod_offer_inst
    set area_id =2,region='11',region_cd = '11'
    where prod_offer_inst_id = i_po_id;

    v_region_cd := '11';*/
    select common_region_id into v_region_cd from prod_inst where prod_inst_id = i_pi_id;
    --197关系已经存在了就不在同步
    select count(r.rela_id)
      into v_mdse_rela_count2
      from crm.prod@lk_tocrm1_cross p, crm.mdse@lk_tocrm1_cross m,crm.mdse_rela@lk_tocrm1_cross r
     where p.prod_id = m.prod_id
       and m.mdse_type = '101'
       and p.account = i_main_accnbr
       and m.mdse_id = r.mdse_ida
       and r.rela_type = '197';

     if v_mdse_rela_count2 = 0 then
     /*--多次同步删除前次同步的销售品
      insert into crm.ins_billing_update@lk_tocrm1_cross
      (INS_ID, TABLE_NAME, KEY_ID, STATE, COLUMN_NAME, MODI_DATE, DEAL_NUM)
      select crm.ins_billing_update_id_seq.nextval@lk_tocrm1_cross,
             'MDSE',
             m.mdse_id,
             '10A',
             'MDSE_ID',
             sysdate,
             0
        from crm.mdse@lk_tocrm1_cross m
      where m.prod_id in
            (select p.prod_id
               from crm.prod@LK_TOCRM1_CROSS p
              where p.region = (select c.up_region_id
                                  from common_region c
                                 where c.common_region_id = v_region_cd)
                and account = v_acc_nbr);

      delete from crm.mdse@lk_tocrm1_cross m
      where m.prod_id in
            (select p.prod_id
               from crm.prod@LK_TOCRM1_CROSS p
              where p.region = (select c.up_region_id
                                  from common_region c
                                 where c.common_region_id = v_region_cd)
                and account = v_acc_nbr);
      --多次同步删除前次同步的产品
      insert into crm.ins_billing_update@lk_tocrm1_cross
      (INS_ID, TABLE_NAME, KEY_ID, STATE, COLUMN_NAME, MODI_DATE, DEAL_NUM)
      select crm.ins_billing_update_id_seq.nextval@lk_tocrm1_cross,
             'V_PROD',
             P.PROD_ID,
             '10A',
             'PROD_ID',
             sysdate,
             0
        from crm.prod@LK_TOCRM1_CROSS p
     where p.region = (select c.up_region_id
                       from common_region c
                      where c.common_region_id = v_region_cd)
       and account = v_acc_nbr;

      delete from crm.prod@LK_TOCRM1_CROSS p
     where p.region = (select c.up_region_id
                       from common_region c
                      where c.common_region_id = v_region_cd)
       and account = v_acc_nbr;*/

      select count(1)
        into i_prod_count
        from crm.prod@LK_TOCRM1_CROSS
       where region in (v_region_cd,'2')
         and account = v_acc_nbr;

      select count(1) into v_area_code_count from prod_inst
     where acc_nbr = i_main_accnbr
       and area_code <> '0591';
       --获取主号区域
        /*select area_code
        into v_main_area_code
        from prod_inst
       where acc_nbr = i_main_accnbr
         and area_code <> '0591';*/
         /*and v_area_code_count > 0*/
      if i_prod_count = 0 and v_area_code_count > 0 then
        select area_code
        into v_main_area_code
        from prod_inst
       where acc_nbr = i_main_accnbr
         and area_code <> '0591';
        --插入数据prod
        o_result := '添加产品信息错误';
        select crm.prod_id_seq.nextval@LK_TOCRM1_CROSS
          into v_prod_id
          from dual;
        insert into crm.prod@LK_TOCRM1_CROSS
          (prod_id, --id
           property_custid, --产权客户标识
           cust_id, --使用客户标识
           prod_spec_id, --产品规格标识
           create_date, --生成时间
           modify_date, --修改时间
           staff, --操作员工号
           state, --状态
           prod_spec_type, --产品规格类型
           service_code, --业务号码
           address_id, --地址id
           stop_status, --停机状态
           exch_id, --局向
           region, --区域
           area_code, --区号
           acct_cycle, --帐务周期类型
           pay_type, --付费方式
           rent_date, --起租日
           remark, --备注
           account, --业务号码
           address_name, --地址名称
           real_modify_date,
           ext_flag1)
          select v_prod_id,
                 v_custId,
                 v_custId,
                 p.ext_prod_id,
                 pi.create_date,
                 pi.status_date,
                 pi.create_staff,
                 '70A',
                 p.prod_func_type,
                 pi.acc_nbr,
                 pi.address_id,
                 pi.stop_status,
                 pi.exch_id,
                 cr.up_region_id,
                 pi.area_code,
                 pi.pay_cycle,
                 pi.payment_mode_cd,
                 pi.begin_rent_time,
                 pi.remark,
                 pi.acc_nbr,
                 pi.address_desc,
                 pi.update_date,
                 'Y'
            from prod_inst pi, product p,common_region cr
           where pi.prod_inst_id = i_pi_id
             and pi.product_id = p.product_id
             and pi.common_region_id = cr.common_region_id;
        --计费增量表
        proc_cross_ins_billing_update('V_PROD', v_prod_id, 'PROD_ID');
        --同步日志表
        proc_cross_localarea_log('PROD', v_prod_id, i_pi_id,v_batch_num,'同步产品实例表');

        --销售品添加
        o_result := '添加销售品信息错误';
        select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS into v_mdse_id from dual;

        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           ext_flag1)
          select v_mdse_id,
                 decode(pz.default_value, '', '610290109', pz.default_value),
                 v_custId,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 v_prod_id,
                 decode(pz.attr_desc,'','101',pz.attr_desc),
                 poi.status_date,
                 cr.up_region_id,
                 poi.eff_date,
                 poi.update_date,
                 'Y'
            from prod_offer_inst poi,
                 prod_offer po,
                 (select a.java_code,a.attr_desc,a.default_value
                    from sys_class sc, attr_spec a
                   where sc.java_code = 'ProdOfferIdRel'
                     and sc.class_id = a.class_id) pz, common_region cr
           where poi.prod_offer_inst_id = i_po_id
             and poi.prod_offer_id = po.prod_offer_id
             and po.prod_offer_id = pz.java_code(+)
             and po.offer_sub_type = 'T01'
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE', v_mdse_id, 'MDSE_ID');
        --同步日志表
        proc_cross_localarea_log('MDSE', v_mdse_id, i_po_id,v_batch_num,'同步销售品实例表');
        o_result :='主号销售品信息处理';
        select p.ext_prod_id into v_main_prod_spec_id from prod_inst pi,product p
        where pi.product_id = p.product_id
          and pi.acc_nbr = i_main_accnbr;

        select mr.mdse_id,mr.region
          into v_main_mdse_id,v_main_region
          from crm.prod@lk_tocrm1_cross pr, crm.mdse@lk_tocrm1_cross mr
         where pr.account = i_main_accnbr
           and pr.area_code = v_main_area_code
           and pr.prod_id = mr.prod_id
           and pr.prod_spec_id = v_main_prod_spec_id
           and mr.mdse_type = '101';

        o_result := '添加销售品关联信息错误';
        select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross
          into v_mdse_rela_seq
          from dual;
        insert into crm.mdse_rela@lk_tocrm1_cross
          (RELA_ID,
           MDSE_IDB,
           RELA_TYPE,
           STATE,
           MDSE_IDA,
           CREATE_DATE,
           MODIFY_DATE,
           a_region,
           b_region,
           ext_flag1,
           eff_date,
           exp_date)
           select v_mdse_rela_seq,
                  v_mdse_id,
                  '197',
                  '70A',
                  v_main_mdse_id,
                  sysdate,
                  sysdate,
                  v_region_cd,
                  v_main_region,
                  'Y',
                  poi.eff_date,
                  poi.exp_date
             from crmv2.prod_offer_inst poi
            where poi.prod_offer_inst_id = i_po_id;
          /*select v_mdse_rela_seq,
                 v_mdse_id,
                 '197',
                 '70A',
                 mr.mdse_id,
                 sysdate,
                 sysdate,
                 v_region_cd,
                 mr.region,
                 'Y'
            from crm.prod@lk_tocrm1_cross pr, crm.mdse@lk_tocrm1_cross mr
           where pr.account = i_main_accnbr
             and pr.area_code = v_main_area_code
             and pr.prod_id = mr.prod_id
             and mr.mdse_type = '101';*/

        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela_seq,'RELA_ID');
        proc_cross_localarea_log('MDSE_RELA', v_mdse_rela_seq, null,v_batch_num,'同步销售品关联表');

        o_result := '添加虚号与校园vpn的关联关系';
        select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross
          into v_mdse_rela_seq2
          from dual;

        insert into mdse_rela@lk_tocrm1_cross
        (RELA_ID,
         MDSE_IDB,
         RELA_TYPE,
         STATE,
         MDSE_IDA,
         EFF_DATE,
         EXP_DATE,
         CREATE_DATE,
         MODIFY_DATE,
         REMARK,
         MDSEB_ROLE,
         PREFER_ID,
         A_REGION,
         B_REGION,
         REAL_MODIFY_DATE,
         EXT_FLAG1)
        select v_mdse_rela_seq2,
               bb.mdse_idb,
               '150',
               '70A',
               aa.mdse_ida,
               aa.EFF_DATE,
               aa.EXP_DATE,
               sysdate,
               sysdate,
               '',
               600349207,
               0,
               aa.A_REGION,
               2,
               sysdate,
               'Y'
          from (select *
                  from mdse_rela@lk_tocrm1_cross
                 where mdse_idb in
                       (select mdse_id
                          from mdse@lk_tocrm1_cross
                         where mdse_id != 696658814
                           and prod_id in
                               (select pr.prod_id
                                  from prod@lk_tocrm1_cross pr
                                 where pr.account = i_main_accnbr
                                 and pr.area_code = v_main_area_code)
                           and mdse_type = '101')
                   and rela_type = '150'
                   and exists (select 'X'
                          from mdse@lk_tocrm1_cross
                         where mdse_id = mdse_ida
                           and mdse_spec_id = 610745453)) aa,
               (select *
                  from mdse_rela@lk_tocrm1_cross
                 where mdse_idb in
                       (select mdse_id
                          from mdse@lk_tocrm1_cross
                         where mdse_id in
                               (select mdse_idb
                                  from mdse_rela@lk_tocrm1_cross
                                 where mdse_ida in
                                       (select mdse_id
                                          from mdse@lk_tocrm1_cross
                                         where prod_id in
                                               (select pr.prod_id
                                                  from prod@lk_tocrm1_cross pr
                                                 where pr.account = i_main_accnbr
                                                   and pr.area_code = v_main_area_code)
                                           and mdse_type = '101')
                                   and rela_type = '197'))) bb
         where aa.mdse_idb = bb.mdse_ida;

        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela_seq2,'RELA_ID');

        proc_cross_localarea_log('MDSE_RELA', v_mdse_rela_seq2, null,v_batch_num,'同步销售品关联表');
        o_result := '修改套餐虚号码区域信息错误';
        for rela in i_rela loop
        update BILL.CUST_PRICE_PLAN_PARAM@lk_tocrm1_cross aa set info_val = '0591'
        where AA.cust_price_plan_param_id = rela.cust_price_plan_param_id;

        proc_cross_ins_billing_update('CUST_PRICE_PLAN_PARAM', rela.cust_price_plan_param_id, 'CUST_PRICE_PLAN_PARAM_ID');

        end loop;
       /* select count(1) into v_prod_offer_count
         from prod_inst pi, offer_prod_inst_rel r, prod_offer_inst poi,prod_offer po
        where pi.acc_nbr = i_main_accnbr
          and pi.prod_inst_id = r.prod_inst_id
          and r.prod_offer_inst_id = poi.prod_offer_inst_id
          and poi.prod_offer_id = po.prod_offer_id
          and po.offer_sub_type = 'T01';
       if v_prod_offer_count > 0 then
        select poi.prod_offer_id
          into v_prod_offer_id
         from prod_inst pi, offer_prod_inst_rel r, prod_offer_inst poi,prod_offer po
        where pi.acc_nbr = i_main_accnbr
          and pi.prod_inst_id = r.prod_inst_id
          and r.prod_offer_inst_id = poi.prod_offer_inst_id
          and poi.prod_offer_id = po.prod_offer_id
          and po.offer_sub_type = 'T01';

       select count(1) into v_price_rela_count
         from prod@lk_tocrm1_cross            p,
              mdse@lk_tocrm1_cross            m,
              mdse_price_rela@lk_tocrm1_cross mp,
              crmv2.mdse_ys_lisy_new          m
        where p.account = i_main_accnbr
          and p.area_code = v_main_area_code
          and m.mdse_type = '101'
          and p.prod_id = m.prod_id
          and m.mdse_id = mp.mdse_id
          and mp.price_id = m.id_v1
          and m.id_v2 = v_prod_offer_id;

       if v_price_rela_count > 0 then
       select mp.rela_id into v_price_rela_id
         from prod@lk_tocrm1_cross            p,
              mdse@lk_tocrm1_cross            m,
              mdse_price_rela@lk_tocrm1_cross mp,
              crmv2.mdse_ys_lisy_new          m
        where p.account = i_main_accnbr
          and p.area_code = v_main_area_code
          and m.mdse_type = '101'
          and p.prod_id = m.prod_id
          and m.mdse_id = mp.mdse_id
          and mp.price_id = m.id_v1
          and m.id_v2 = v_prod_offer_id;

    select count(1) into v_cust_price_plan_count from BILL.CUST_PRICE_PLAN_PARAM@lk_tocrm1_cross aa where AA.MDSE_ID = v_price_rela_id
      and aa.pricing_param_id = 11084016
      and state = '00D';
    if v_cust_price_plan_count > 0 then
    select aa.cust_price_plan_param_id into v_cust_price_plan_id from BILL.CUST_PRICE_PLAN_PARAM@lk_tocrm1_cross aa where AA.MDSE_ID = v_price_rela_id
      and aa.pricing_param_id = 11084016
      and state = '00D';

    update BILL.CUST_PRICE_PLAN_PARAM@lk_tocrm1_cross aa set info_val = '0591'
    where AA.MDSE_ID = v_price_rela_id
      and aa.pricing_param_id = 11084016
      and state = '00D';

      proc_cross_ins_billing_update('CUST_PRICE_PLAN_PARAM', v_cust_price_plan_id, 'CUST_PRICE_PLAN_PARAM_ID');

      end if;
       end if;
       end if;*/

        o_result := '添加电信账户信息错误';
        --同步账户信息
        for ac in i_acct loop
          select count(1)
            into v_acct_count
            from crm.telecom_account@LK_TOCRM1_CROSS
           where agreement_code = ac.account_number;
          if v_acct_count = 0 then
            select crm.tel_acct_id_seq.nextval@LK_TOCRM1_CROSS
              into v_tel_acct_id_seq
              from dual;
            insert into crm.telecom_account@LK_TOCRM1_CROSS
              (tel_acct_id, --电信账户标识
               agreement_code, --合同号
               customer_id, --客户标识
               tel_acct_code, --电信账户编码
               tel_acct_name, --电信账户名称
               state, --状态
               create_date, --创建时间
               deduct_charge, --扣款金额
               deduct_limit, --扣款阀值
               modify_date,
               REAL_MODIFY_DATE,
               region,
               ext_flag1)
              select v_tel_acct_id_seq,
                     a.account_number,
                     v_custId,
                     a.account_number,
                     a.account_name,
                     '10A',
                     a.create_date,
                     a.deduct_charge,
                     a.deduct_limit,
                     a.status_date,
                     a.update_date,
                     a.region_cd,
                     'Y'
                from account a
               where a.account_id = ac.account_id;
            proc_cross_ins_billing_update('TELECOM_ACCOUNT', v_tel_acct_id_seq,'TEL_ACCT_ID');

            proc_cross_localarea_log('TELECOM_ACCOUNT', v_tel_acct_id_seq, ac.account_id,v_batch_num,'同步电信账户表');
          else
            select tel_acct_id
              into v_tel_acct_id_seq
              from crm.telecom_account@LK_TOCRM1_CROSS
             where agreement_code = ac.account_number;
          end if;
          --
          o_result := '添加账户信息错误';
          select crm.zgid_seq.nextval@LK_TOCRM1_CROSS into v_zgid_seq from dual;
          insert into crm.zg@LK_TOCRM1_CROSS
            (zgid, --账户id
             zgzr, --产品id
             zgzh, --电信账户标识
             zgzl,
             zgff,
             zgxe,
             zgxs,
             zgrq,
             zggr,
             zgzt,
             zgfg,
             zgtl,
             zgfp,
             zgqy,
             zgfl,
             real_modify_date,
             ext_flag1)
            select v_zgid_seq,
                   v_prod_id,
                   v_tel_acct_id_seq,
                   pia.acct_item_type_group_id,
                   pia.payment_limit_type,
                   pia.payment_limit,
                   pia.priority,
                   pia.create_date,
                   pia.status_date,
                   '70A',
                   pia.charge_type,
                   decode(pia.def_acct_flag,'T','true','false'),
                   pia.invoice_formart_flag,
                   cr.up_region_id,
                   0,
                   pia.update_date,
                   'Y'
              from prod_inst_acct pia,common_region cr
             where pia.prod_inst_acct_id =ac.prod_inst_acct_id
               and pia.region_cd = cr.common_region_id;

          proc_cross_localarea_log('ZG', v_zgid_seq, ac.prod_inst_acct_id,v_batch_num,'同步账户表');

          o_result := '添加账户信息错误';
          select crm.zhid_seq.nextval@LK_TOCRM1_CROSS into v_zh_seq from dual;
          insert into crm.zh@LK_TOCRM1_CROSS
            (zhid,
             zhyh,
             zhmc,
             zhzh,
             zhlx,
             zhkh,
             zhrq,
             zhgr,
             zhzt,
             region,
             real_modify_date,
             acc_agreement_code,
             send_method_type,
             entrust_type,
             ext_flag1)
            select v_zh_seq,
                   pp.payment_bank_id,
                   pp.payment_account_name,
                   pp.payment_account,
                   pp.payment_method_id,
                   v_custId,
                   pp.create_date,
                   pp.status_date,
                   '70A',
                   pp.region_cd,
                   pp.update_date,
                   pp.acc_agreement_code,
                   pp.send_entrust_method,
                   pp.entrust_type,
                   'Y'
              from payment_plan pp, prod_inst_acct pia
             where pia.account_id = pp.account_id
               and pia.prod_inst_acct_id = ac.prod_inst_acct_id
               and rownum <2;
            proc_cross_localarea_log('ZH', v_zh_seq, null,v_batch_num,'同步ZH表');

          select crm.payment_plan_id_seq.nextval@LK_TOCRM1_CROSS into v_payment_plan_seq from dual;

          select pp.payment_plan
            into v_payment_plan_id
            from payment_plan pp, prod_inst_acct pia
           where pia.account_id = pp.account_id
             and pia.prod_inst_acct_id = ac.prod_inst_acct_id
             and rownum < 2;

          o_result := '添加支付方案信息错误';
          insert into crm.payment_plan@LK_TOCRM1_CROSS
            (payment_plan_id,
             proportion,
             limitation,
             cust_acct_id,
             tel_acct_id,
             priority,
             create_date,
             modify_date,
             state,
             region,
             real_modify_date,
             ext_flag1)
            select v_payment_plan_seq,
                   pia.payment_limit,
                   pia.payment_limit,
                   v_zh_seq,
                   v_tel_acct_id_seq,
                   pp.priority,
                   pp.create_date,
                   pp.status_date,
                   '10A',
                   pp.region_cd,
                   pp.update_date,
                   'Y'
              from payment_plan pp, prod_inst_acct pia
             where pia.account_id = pp.account_id
               and pia.prod_inst_acct_id = ac.prod_inst_acct_id
               and pp.payment_plan = v_payment_plan_id;

          proc_cross_ins_billing_update('PAYMENT_PLAN', v_payment_plan_seq, 'PAYMENT_PLAN_ID');

          proc_cross_localarea_log('PAYMENT_PLAN', v_payment_plan_seq, v_payment_plan_id,v_batch_num,'同步支付方案表');
        end loop;
      end if;
      end if;
    else
         select count(1)
         into v_xh_count
         from crm.prod@LK_TOCRM1_CROSS p, crm.mdse@lk_tocrm1_cross m
        where p.region in (v_region_cd,'2')
          and p.account = v_acc_nbr
          and p.prod_id = m.prod_id
          and m.mdse_type = '101';
        if v_xh_count <> 0 then
         select m.mdse_id,p.prod_id
         into v_mdse_idb,v_prod_idb
         from crm.prod@LK_TOCRM1_CROSS p, crm.mdse@lk_tocrm1_cross m
        where p.region in (v_region_cd,'2')
          and p.account = v_acc_nbr
          and p.prod_id = m.prod_id
          and m.mdse_type = '101';
         if op_flag = '3' then
              insert into crm.mdse_his@lk_tocrm1_cross
              (his_id,
               mdse_id,
               mdse_spec_id,
               property_custid,
               create_date,
               exp_date,
               state,
               prod_id,
               fea_id,
               mdse_type,
               modify_date,
               region,
               mdse_serv_number,
               eff_date,
               attr_sort,
               trial_eff_date,
               trial_exp_date,
               real_modify_date,
               ver_date,
               jt_mdse_spec
               )
              select crm.mdse_his_id_seq.nextval@lk_tocrm1_cross,
                     mdse_id,
                     mdse_spec_id,
                     property_custid,
                     create_date,
                     exp_date,
                     state,
                     prod_id,
                     prod_fea_id,
                     mdse_type,
                     modify_date,
                     region,
                     mdse_serv_number,
                     eff_date,
                     attr_sort,
                     trial_eff_date,
                     trial_exp_date,
                     real_modify_date,
                     ver_date,
                     jt_mdse_spec
               from crm.mdse@lk_tocrm1_cross where mdse_id = v_mdse_idb;
              delete from crm.mdse@lk_tocrm1_cross where mdse_id = v_mdse_idb;
              proc_cross_ins_billing_update('MDSE', v_mdse_idb, 'MDSE_ID');
              insert into crm.prod_his@lk_tocrm1_cross
              (his_id,
               prod_id,
               property_custid,
               cust_id,
               prod_spec_id,
               contract,
               create_date,
               modify_date,
               modify_cause,
               staff,
               state,
               prod_spec_type,
               service_type,
               service_code,
               address_id,
               stop_status,
               exch_id,
               role_id,
               zipcode,
               region,
               area_code,
               acct_cycle,
               pay_type,
               term_type,
               rent_date,
               remark,
               account,
               attr_sort,
               linkman,
               rent_type,
               address_name,
               real_modify_date,
               community_id
               )
              select crm.prod_his_id_seq.nextval@lk_tocrm1_cross,
               prod_id,
               property_custid,
               cust_id,
               prod_spec_id,
               contract,
               create_date,
               modify_date,
               modify_cause,
               staff,
               state,
               prod_spec_type,
               service_type,
               service_code,
               address_id,
               stop_status,
               exch_id,
               role_id,
               zipcode,
               region,
               area_code,
               acct_cycle,
               pay_type,
               term_type,
               rent_date,
               remark,
               account,
               attr_sort,
               linkman,
               rent_type,
               address_name,
               real_modify_date,
               community_id
          from crm.prod@lk_tocrm1_cross
          where prod_id = v_prod_idb;
          delete from crm.prod@lk_tocrm1_cross
          where prod_id = v_prod_idb;
          proc_cross_ins_billing_update('V_PROD', v_prod_idb, 'PROD_ID');

          select count(1) into v_mdse_rela_count from crm.mdse_rela@lk_tocrm1_cross where mdse_idb = v_mdse_idb and rela_type = '197';
          if v_mdse_rela_count <> 0 then
          insert into crm.mdse_rela_his@lk_tocrm1_cross
          (his_id,
          rela_id,
          mdse_idb,
          rela_type,
          state,
          mdse_ida,
          eff_date,
          exp_date,
          create_date,
          modify_date,
          remark,
          mdseb_role,
          prefer_id,
          a_region,
          b_region,
          real_modify_date )
          select crm.mdse_rela_his_id_seq.nextval@lk_tocrm1_cross,
          rela_id,
          mdse_idb,
          rela_type,
          state,
          mdse_ida,
          eff_date,
          exp_date,
          create_date,
          modify_date,
          remark,
          mdseb_role,
          prefer_id,
          a_region,
          b_region,
          real_modify_date
        from crm.mdse_rela@lk_tocrm1_cross
        where mdse_idb = v_mdse_idb
        and rela_type = '197';
        select rela_id into v_mdse_rela_id from crm.mdse_rela@lk_tocrm1_cross where mdse_idb = v_mdse_idb and rela_type = '197';
        delete from crm.mdse_rela@lk_tocrm1_cross where mdse_idb = v_mdse_idb and rela_type = '197';
        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela_id,'RELA_ID');
        end if;
        end if;
       end if;
    end if;
  end if;
  o_result := 'TRUE';
  commit;
exception
  when others then
    o_result := o_result;
end;
/
