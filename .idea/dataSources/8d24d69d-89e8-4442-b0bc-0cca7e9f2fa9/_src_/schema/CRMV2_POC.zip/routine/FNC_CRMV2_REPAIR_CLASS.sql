CREATE function           FNC_CRMV2_REPAIR_CLASS(in_tab_name in string)
  return boolean is
  Result     boolean;
  i_class_id int := 0;
begin
  /*
  --删除实体原有配置数据
  delete attr_value where attr_id in(select attr_id from attr_spec a, sys_class b where a.class_id=b.class_id and b.table_name=in_tab_name);
  delete attr_spec where class_id in (select class_id from sys_class where table_name=in_tab_name );
  delete sys_class where table_name=in_tab_name;
  */
  --select max(class_id)+1 into i_class_id from sys_class;
  select class_id
    into i_class_id
    from sys_class
   where table_name = in_tab_name;
  /*
  --插入类配置数据
  insert into sys_class(class_id,super_class_id,class_name,java_code,table_name, is_entity,class_desc ,class_hint,is_change_log,is_dany_class)
  select i_class_id,-2,substr(comments,0,11),in_tab_name,in_tab_name,1,comments,comments,1,0
  from user_tab_comments where table_name =in_tab_name;
    commit;

  --根据表名更新实体名字
  update sys_class set java_code= initcap(substr(java_code,0,instr(java_code,'_')-1))||initcap(substr(java_code,instr(java_code,'_')+1))
         where class_id=i_class_id;
  for i in 1 .. 7 loop
      update sys_class set java_code= substr(java_code,0,instr(java_code,'_')-1)||initcap(substr(java_code,instr(java_code,'_')+1))
        where class_id = i_class_id and java_code like '%\_%' escape '\';
   end loop;
    commit;
  */
  --插入属性配置数据
  delete wzy_attr_spec_repair;

  insert into wzy_attr_spec_repair
    (attr_id,
     attr_cd,
     attr_name,
     attr_desc,
     attr_value_type,
     class_id,
     attr_type,
     attr_seq,
     IS_DANY_ATTR,
     IS_MULTI_VALUE,
     java_code)
    select ATTR_ID_seq.Nextval,
           b.column_name,
           substr(comments, 1, 30),
           substr(comments, 1, 50),
           decode(data_type,
                  'TIMESTAMP(6)',
                  'T',
                  'FLOAT',
                  'F',
                  'NUMBER',
                  'N',
                  'CHAR',
                  'C',
                  'CLOB',
                  'B',
                  'DATE',
                  'D',
                  'VARCHAR2',
                  'C',
                  'BLOB',
                  'B',
                  'C'),
           i_class_id,
           'T1',
           rownum,
           0,
           0,
          a.COLUMN_NAME
      from user_col_comments a,
           user_tab_columns b,
           (select attr_cd from attr_spec where class_id = i_class_id) c
     where a.table_name(+) = b.TABLE_NAME
       and A.COLUMN_NAME(+) = B.column_name
       and B.TABLE_NAME = in_tab_name
       and b.COLUMN_NAME = c.attr_cd(+)
       and c.attr_cd is null
       and b.COLUMN_NAME not in ('STATUS_CD',
                                 'STATUS_DATE',
                                 'CREATE_DATE',
                                 'UPDATE_DATE',
                                 'AREA_ID',
                                 'REGION_CD',
                                 'UPDATE_STAFF',
                                 'CREATE_STAFF', 'COMMON_REGION_ID');
  commit;
  --根据数据库列名，更新java_code
  update wzy_attr_spec_repair
     set java_code = lower(substr(attr_cd, 0, instr(attr_cd, '_') - 1)) ||
                     initcap(substr(attr_cd, instr(attr_cd, '_') + 1))
   where class_id = i_class_id;

  for i in 1 .. 7 loop
    update wzy_attr_spec_repair
       set java_code = substr(java_code, 0, instr(java_code, '_') - 1) ||
                       initcap(substr(java_code, instr(java_code, '_') + 1))
     where class_id = i_class_id
       and java_code like '%\_%' escape '\';
  end loop;

  insert into attr_spec
    (ATTR_ID,
     ATTR_CD,
     ATTR_NAME,
     ATTR_DESC,
     ATTR_VALUE_TYPE,
     DEFAULT_VALUE,
     VALUE_FROM,
     VALUE_TO,
     IS_UNIQUE,
     IS_NULLABLE,
     STATUS_CD,
     STATUS_DATE,
     CREATE_DATE,
     CLASS_ID,
     ATTR_TYPE,
     JAVA_CODE,
     ATTR_SEQ,
     CNS_TYPE,
     REF_CLASS_ID,
     ATTR_LEVEL,
     IS_DANY_ATTR,
     IS_MULTI_VALUE,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF)
    select ATTR_ID,
           ATTR_CD,
           ATTR_NAME,
           ATTR_DESC,
           ATTR_VALUE_type,
           DEFAULT_VALUE,
           VALUE_FROM,
           VALUE_TO,
           IS_UNIQUE,
           IS_NULLABLE,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           CLASS_ID,
           ATTR_TYPE,
           JAVA_CODE,
           ATTR_SEQ,
           CNS_TYPE,
           REF_CLASS_ID,
           ATTR_LEVEL,
           IS_DANY_ATTR,
           IS_MULTI_VALUE,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF
      from wzy_attr_spec_repair;
  commit;
  return(Result);

end FNC_CRMV2_REPAIR_CLASS;
/
