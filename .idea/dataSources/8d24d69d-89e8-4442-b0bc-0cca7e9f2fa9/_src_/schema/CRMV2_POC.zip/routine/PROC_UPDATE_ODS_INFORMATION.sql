CREATE procedure           proc_update_ods_information is
  /**
  ODS报表信息权 同步到ODS
  **/
  rl          boolean;
  staffId     varchar2(15) := '';
  privilegeId varchar2(15) := '';
  classId     varchar2(15) := '';
  attrValue   varchar2(250) := '';
  rightType   varchar2(250) := '';
  V_i         number(10) := 0;
  cursor cur is
    select *
      from ods_update_temp a
     where a.flag = 1
     order by a.ods_update_temp_id asc;
  type curtype is ref cursor;
  priCur curtype;
begin
  for rec in cur loop
    begin
      if rec.op_type = 'ADD' then
        open priCur for rec.str_sql;
        loop
          v_i := v_i + 1;
          fetch priCur --循环和给其他参数赋值赋值
            into staffId, attrValue, classId, privilegeId;
          exit when priCur%notfound; --退出条件
          rl := fnc_insert_ods_tab(staffId, privilegeId, attrValue, classId);
          if v_i > 100 then
            v_i := 0;
            commit;
          end if;
        end loop;
        close priCur;
        update ods_update_temp a
           set a.flag = 0
         where a.ods_update_temp_id = rec.ods_update_temp_id;
        commit;
      end if;

      if rec.op_type = 'DEL' then

        open priCur for rec.str_sql;
        loop
          v_i := v_i + 1;
          fetch priCur --循环和给其他参数赋值赋值
            into staffId, privilegeId, attrValue, classId;
          exit when priCur%notfound; --退出条件

          if classId = -88 then
            rightType := 'team';
          end if;
          if classId = 121 then
            rightType := 'area';
          end if;
          if classId = 36 then
            rightType := 'organ';
          end if;
          if classId = 950000230 then
            rightType := 'sensitivity';
          end if;

          delete from crm_user_obj a
           where a.user_id = staffId
             and obj_id = privilegeId
             and map_system = 'CRM2';
          delete from crm_user_right a
           where a.user_id = staffId
             and right_value = attrValue
             and right_type = rightType
             and map_system = 'CRM2';
          if v_i > 100 then
            v_i := 0;
            commit;
          end if;
        end loop;
        close priCur;
        update ods_update_temp a
           set a.flag = 0
         where a.ods_update_temp_id = rec.ods_update_temp_id;
        commit;
      end if;
      if rec.op_type = 'DELVALUE' then

        open priCur for rec.str_sql;
        loop
          v_i := v_i + 1;
          fetch priCur --循环和给其他参数赋值赋值
            into staffId, privilegeId, attrValue, classId;
          exit when priCur%notfound; --退出条件
          if classId = -88 then
            rightType := 'team';
          end if;
          if classId = 121 then
            rightType := 'area';
          end if;
          if classId = 36 then
            rightType := 'organ';
          end if;
          if classId = 950000230 then
            rightType := 'sensitivity';
          end if;
          delete from crm_user_right a
           where a.user_id = staffId
             and right_value = attrValue
             and right_type = rightType
             and map_system = 'CRM2';
          if v_i > 100 then
            v_i := 0;
            commit;
          end if;
        end loop;
        close priCur;
        update ods_update_temp a
           set a.flag = 0
         where a.ods_update_temp_id = rec.ods_update_temp_id;
        commit;
      end if;
      EXCEPTION
        WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('异常数据'||'---'||rec.ods_update_temp_id);
    end;
  end loop;
  commit;
end proc_update_ods_information;
/
