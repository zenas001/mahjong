CREATE PROCEDURE           PROC_DEL_CT_AUTO_TEST IS

  V_CNT NUMERIC(12) := 0;

BEGIN

  FOR REC IN (SELECT A.AUTO_TEST_COMPLAINT_ID, A.BX_DATA_ID
                FROM CRMV2.AUTO_TEST_COMPLAINT A
               WHERE 1 = 1
                 AND (NOT EXISTS
                      (SELECT 1
                         FROM PROD_INST@LK_CRM_9090 B
                        WHERE A.OBSTACLE_SERVNBR = B.ACC_NBR
                          AND B.STATUS_CD = '100000'
                          and a.area_code = b.area_code) OR NOT EXISTS
                      (SELECT 1
                         FROM CRMCIA.ZB@LK_CRM_9090 B
                        WHERE A.SOURCE_TYPE = B.ZBZS
                          AND B.ZBFL = 'CT_SOURCE'
                          AND B.SPBM IS NULL))) LOOP
    V_CNT := V_CNT + 1;
    BEGIN
      DELETE FROM AUTO_TEST_COMPLAINT
       WHERE AUTO_TEST_COMPLAINT_ID = REC.AUTO_TEST_COMPLAINT_ID;

      DELETE FROM AUTO_TEST_BX_DATA C
       WHERE C.AUTO_TEST_BX_DATA_ID = REC.BX_DATA_ID;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    IF V_CNT > 100 THEN
      V_CNT := 0;
      COMMIT;
    END IF;
  END LOOP;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    NULL;

END PROC_DEL_CT_AUTO_TEST;
/
