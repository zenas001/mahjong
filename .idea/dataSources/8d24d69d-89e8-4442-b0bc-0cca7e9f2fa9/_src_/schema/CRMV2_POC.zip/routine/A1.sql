CREATE procedure           A1 is
  i number(12):=0;
begin
  dbms_output.put_line('A1 BEGIN');
  INSERT INTO TEST54(FIELD,CREATE_DATE)
  VALUES
  ('A1',SYSDATE);

  loop
    i := i+1;
    exit when ( i >= 29999999);
  end loop;

    COMMIT;

  dbms_output.put_line('A1 END');
end A1;
/
