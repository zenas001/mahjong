CREATE PROCEDURE           proc_repair_group_order IS
  /*生效时间属性*/
  v_eff_date_attr VARCHAR2(20) := '40020005';
  /*失效时间属性*/
  v_exp_date_attr VARCHAR2(20) := '40020006';
  v_eff_date      VARCHAR2(40);
  v_exp_date      VARCHAR2(40);
  v_finish_time   DATE;
  v_online_cnt    NUMBER(12) := 0;
  v_his_cnt       NUMBER(12) := 0;
  v_cnt           NUMBER(12) := 0;
/*  v_id_str        clob;
  v_his_id_str    clob;
  v_mkt_str       clob;*/

BEGIN
  /*处理订单项竣工，还在一表的数据*/
  FOR rec IN (SELECT *
                FROM intf_dep_finish a
               WHERE a.finish_time IS NULL
                 AND a.crm_order_item_id IS NOT NULL
                 AND a.state = '70A'
                 AND EXISTS
               (SELECT 1
                        FROM order_item oi
                       WHERE oi.status_cd = '300000'
                         AND oi.order_item_id = a.crm_order_item_id))
  LOOP
    SELECT oi.finish_time
      INTO v_finish_time
      FROM order_item oi
     WHERE oi.order_item_id = rec.crm_order_item_id;

    UPDATE intf_dep_finish a
       SET a.finish_time = v_finish_time
      /* ,
           a.state       = '70B'*/
     WHERE a.crm_order_item_id = rec.crm_order_item_id
       AND a.package_group = rec.package_group;

/*    v_id_str := v_id_str || to_char(rec.intf_dep_finish_id);*/

    SELECT COUNT(1)
      INTO v_cnt
      FROM order_item a
     WHERE a.order_item_id = rec.crm_order_item_id
       AND a.entt_spec_type = 'BO';
    IF v_cnt > 0
    THEN
      SELECT to_char(a.eff_date, 'yyyymmddhhmiss'), to_char(a.exp_date, 'yyyymmddhhmiss')
        INTO v_eff_date, v_exp_date
        FROM prod_offer_inst a
       WHERE a.prod_offer_inst_id =
             (SELECT b.order_item_obj_id
                FROM order_item b
               WHERE b.order_item_id = rec.crm_order_item_id);

      FOR rec2 IN (SELECT b.*
                     FROM intf_dep_order_item_rel a, intf_dep_order_item_attr b
                    WHERE a.intf_dep_finish_id = rec.intf_dep_finish_id
                      AND a.intf_dep_order_item_rel_id =
                          b.intf_dep_order_item_rel_id)

      LOOP
       /* v_id_str := v_id_str || ',';*/
        IF v_eff_date_attr = rec2.attr_nbr
        THEN
          UPDATE intf_dep_order_item_attr a
             SET a.attr_value = v_eff_date
           WHERE a.intf_dep_order_item_attr_id =
                 rec2.intf_dep_order_item_attr_id;
          /*v_id_str := v_id_str || to_char(rec2.intf_dep_order_item_attr_id);*/

        ELSIF v_exp_date_attr = rec2.attr_nbr
        THEN
          UPDATE intf_dep_order_item_attr a
             SET a.attr_value = v_eff_date
           WHERE a.intf_dep_order_item_attr_id =
                 rec2.intf_dep_order_item_attr_id;
          /*v_id_str := v_id_str || to_char(rec2.intf_dep_order_item_attr_id);*/

        END IF;
      END LOOP;

    END IF;
    /*v_id_str     := v_id_str || ';';*/
    v_online_cnt := v_online_cnt + 1;
  END LOOP;
  /*dbms_output.put_line(v_id_str);*/
  dbms_output.put_line(v_online_cnt);

  /*处理订单项竣工，在二表的数据*/
  FOR rec IN (SELECT *
                FROM intf_dep_finish a
               WHERE a.finish_time IS NULL
                 AND a.crm_order_item_id IS NOT NULL
                 AND a.state = '70A'
                 AND EXISTS
               (SELECT 1
                        FROM order_item_his oi
                       WHERE oi.status_cd = '300000'
                         AND oi.order_item_id = a.crm_order_item_id))
  LOOP
    SELECT oi.finish_time
      INTO v_finish_time
      FROM order_item_his oi
     WHERE oi.order_item_id = rec.crm_order_item_id;

    UPDATE intf_dep_finish a
       SET a.finish_time = v_finish_time
      /* ,
           a.state       = '70B'*/
     WHERE a.crm_order_item_id = rec.crm_order_item_id
       AND a.package_group = rec.package_group;
/*    v_his_id_str := v_his_id_str || to_char(rec.intf_dep_finish_id);
*/
    SELECT COUNT(1)
      INTO v_cnt
      FROM order_item_his a
     WHERE a.order_item_id = rec.crm_order_item_id
       AND a.entt_spec_type = 'BO';
    IF v_cnt > 0
    THEN
      SELECT to_char(a.eff_date, 'yyyymmddhhmiss'), to_char(a.exp_date, 'yyyymmddhhmiss')
        INTO v_eff_date, v_exp_date
        FROM prod_offer_inst a
       WHERE a.prod_offer_inst_id =
             (SELECT b.order_item_obj_id
                FROM order_item_his b
               WHERE b.order_item_id = rec.crm_order_item_id);
      FOR rec2 IN (SELECT b.*
                     FROM intf_dep_order_item_rel a, intf_dep_order_item_attr b
                    WHERE a.intf_dep_finish_id = rec.intf_dep_finish_id
                      AND a.intf_dep_order_item_rel_id =
                          b.intf_dep_order_item_rel_id)

      LOOP
/*        v_his_id_str := v_his_id_str || ',';
*/
        IF v_eff_date_attr = rec2.attr_nbr
        THEN
          UPDATE intf_dep_order_item_attr a
             SET a.attr_value = v_eff_date
           WHERE a.intf_dep_order_item_attr_id =
                 rec2.intf_dep_order_item_attr_id;
         /* v_his_id_str := v_his_id_str ||
                          to_char(rec2.intf_dep_order_item_attr_id);*/

        ELSIF v_exp_date_attr = rec2.attr_nbr
        THEN
          UPDATE intf_dep_order_item_attr a
             SET a.attr_value = v_eff_date
           WHERE a.intf_dep_order_item_attr_id =
                 rec2.intf_dep_order_item_attr_id;
          /*v_his_id_str := v_his_id_str ||
                          to_char(rec2.intf_dep_order_item_attr_id);*/

        END IF;
      END LOOP;
    END IF;

/*    v_his_id_str := v_his_id_str || ';';
*/
    v_his_cnt := v_his_cnt + 1;
  END LOOP;
/*  dbms_output.put_line(v_his_id_str);
*/  dbms_output.put_line(v_his_cnt);

  FOR rec IN (SELECT *
                FROM intf_dep_finish a
               WHERE a.finish_time IS NULL
                 AND a.state = '70A'
                 AND a.crm_order_item_id IS NULL
                 AND EXISTS
               (SELECT 1
                        FROM intf_dep_finish b
                       WHERE b.group_type = '5000'
                         /*AND b.state = '70B'*/
                         AND b.state = '70A'
                         and b.finish_time is not null
                         AND b.package_group = a.package_group))
  LOOP
    SELECT a.finish_time
      INTO v_finish_time
      FROM intf_dep_finish a
     WHERE a.package_group = rec.package_group
       AND a.finish_time IS NOT NULL
       /*AND a.state = '70B'*/
       and a.state='70A'
       AND a.group_type = '5000'
       AND rownum = 1;

    UPDATE intf_dep_finish a
       SET a.finish_time = v_finish_time
       /*,
           a.state       = '70B'*/
     WHERE a.intf_dep_finish_id = rec.intf_dep_finish_id;
/*    v_mkt_str := v_mkt_str || to_char(rec.intf_dep_finish_id) || ',';
*/
  END LOOP;
/*  dbms_output.put_line(v_mkt_str);
*/
END proc_repair_group_order;
/
