CREATE PROCEDURE           PROC_SYNC_CT_AUTO_TEST IS

  V_AUTO_TEST_BX_DATA_ID NUMERIC(12) := 0;
  V_CNT                  NUMERIC(12) := 0;

BEGIN

  FOR REC IN (SELECT DECODE(A.PROC_MODE, '2', '提交复核', '3', '提交复核', '10', '提交复核', '提交') AS 动作,
                     A.CONT_ID,
                     A.AGREE_ID AS 定单号,
                     A.CREATE_DATE AS 受理时间,
                     (SELECT GHDL FROM CRMV1.GH WHERE GHGH = A.STAFF_ID) AS 受理工号,
                     (SELECT CHINESENAME
                        FROM CRMV1.TE
                       WHERE TEID = A.DISPOSE_DEPT) AS 受理团队,
                     A.OBSTACLE_SERVNBR AS 障碍号码,
                     (SELECT SUBSTR(SYS_CONNECT_BY_PATH(NODE_NAME, ':'), INSTR(SYS_CONNECT_BY_PATH(NODE_NAME, ':'), ':', 2) + 1) FULLNODENAME
                        FROM CRMV1.CT_COMM_TYPE_CFG CCTC
                       WHERE NODE_ID = A.PROC_TYPE
                      CONNECT BY CCTC.PARENT_NODE_ID = PRIOR CCTC.NODE_ID
                       START WITH CCTC.NODE_ID = '03') AS 定单类型,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_SOURCE'
                         AND ZBBM = A.SOURCE) AS 受理来源,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_PROC_MODE'
                         AND ZBBM = A.PROC_MODE) AS 处理方式,
                     (SELECT '(' || DECODE(BB.ID, 1, '0590', BB.STANDARDCODE) || ')' ||
                             AA.CHINESENAME
                        FROM CRMV1.TE AA, CRMV1.P_AREA BB
                       WHERE AA.AREA_ID = BB.ID
                         AND AA.TEID = A.CHECK_DEPT) AS 复核部门,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_LEVEL'
                         AND ZBBM = A.CONT_LEVEL) AS 重要程度,
                     A.CALL_SERVNBR AS 主叫号码,
                     A.AREA_CODE AS 当前所在地,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_PROD_ATTR'
                         AND ZBBM = A.PROD_ATTR) AS 产品属性,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_PRODUCT_BASE'
                         AND ZBBM = A.PRODUCT_BASE) AS 产品基地,
                     A.OVERTIME AS 定单要求时限,
                     A.TOPIC AS 主题,
                     A.CONTENT AS 详细内容,
                     A.PROC_ADVISE AS 处理建议,
                     A.LINK_NAME AS 联系人,
                     A.LINK_CONTENT AS 联系电话,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_REPLY_MODE'
                         AND ZBBM = A.REPLY_MODE) AS 回复方式,
                     A.REPLY_DATE AS 回复时间,
                     (SELECT SC.FAXMAIL
                        FROM CRMV1.SP_CUSTOMER_CONTACT SC
                       WHERE CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 邮件,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'IS_RESPONSES'
                         AND ZBBM = A.IS_RESPONSES) AS 是否首回,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'SHLX'
                         AND ZBBM = A.RESPONSES_TYP) AS 首回类型,
                     A.RESPONSES_CODE AS 首回区号,
                     A.RESPONSES_PHONE AS 首回号码,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 535
                         AND ROWNUM < 2) AS 障碍联系人,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 536
                         AND ROWNUM < 2) AS 障碍联系电话,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 534
                         AND ROWNUM < 2) AS 障碍主叫号码,
                     (SELECT PARAM2
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 531
                         AND ROWNUM < 2) AS 障碍现象编码,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 537
                         AND ROWNUM < 2) AS 障碍预约时间,
                     (SELECT CR.FULLREGIONNAME
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF,
                             (SELECT SUBSTR(SYS_CONNECT_BY_PATH(REGION_NAME, ':'), 2) FULLREGIONNAME,
                                     COMMON_REGION_ID
                                FROM CRMV2.COMMON_REGION
                              CONNECT BY UP_REGION_ID = PRIOR COMMON_REGION_ID
                               START WITH UP_REGION_ID IS NULL) CR
                       WHERE CCF.FEA_SPEC_ID = 741
                         AND CR.COMMON_REGION_ID = TO_NUMBER(CCF.PARAM1)
                         AND CCF.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 投障区域,
                     (SELECT PARAM2
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 620014306
                         AND ROWNUM < 2) AS 销障原因,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 532
                         AND ROWNUM < 2) AS 障碍现象描述,
                     (SELECT PS.NAME
                        FROM CRMV1.SP_CUSTOMER_CONTACT SCC,
                             CRMV1.SP_PROD_SPEC        PS
                       WHERE PS.SP_PROD_SPEC_ID = SCC.SP_PROD_SPEC_ID
                         AND SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 业务名称,
                     (SELECT SSI.SP_CODE
                        FROM CRMV1.SP_CUSTOMER_CONTACT SCC, CRMV1.SP_INFO SSI
                       WHERE SSI.SP_INFO_ID = SCC.SP_INFO_ID
                         AND SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS SP代码,
                     (SELECT '(' || DECODE(BB.ID, 1, '0590', BB.STANDARDCODE) || ')' ||
                             AA.CHINESENAME
                        FROM CRMV1.TE AA, CRMV1.P_AREA BB
                       WHERE AA.AREA_ID = BB.ID
                         AND AA.TEID = A.PROC_DEPT) AS 第一责任部门,
                     (SELECT PS.NAME
                        FROM CRMV1.SP_CUSTOMER_CONTACT SCC,
                             CRMV1.PROD_SPEC           PS
                       WHERE PS.PROD_SPEC_ID = SCC.PROD_SPEC_ID
                         AND SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 业务平台,
                     (SELECT SCC.SERVICE_CODE
                        FROM CRMV1.SP_CUSTOMER_CONTACT SCC
                       WHERE SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 服务代码,
                     A.OBSTACLE_AREA_CODE AS 障碍号码区域
                FROM CRMV1.CUSTOMER_CONTACT A
               WHERE A.CONT_TYPE = '3'
                 AND A.PROD_ATTR IS NOT NULL
                 AND A.STATE = '70A'
                 AND A.CREATE_DATE > TRUNC(SYSDATE) - 1
                 AND A.CREATE_DATE <= TRUNC(SYSDATE)
              UNION ALL
              SELECT DECODE(A.PROC_MODE, '2', '提交复核', '3', '提交复核', '10', '提交复核', '提交'),
                     A.CONT_ID,
                     A.AGREE_ID AS 定单号,
                     A.CREATE_DATE AS 受理时间,
                     (SELECT GHDL FROM CRMV1.GH WHERE GHGH = A.STAFF_ID) AS 受理工号,
                     (SELECT CHINESENAME
                        FROM CRMV1.TE
                       WHERE TEID = A.DISPOSE_DEPT) AS 受理团队,
                     A.OBSTACLE_SERVNBR AS 障碍号码,
                     (SELECT SUBSTR(SYS_CONNECT_BY_PATH(NODE_NAME, ':'), INSTR(SYS_CONNECT_BY_PATH(NODE_NAME, ':'), ':', 2) + 1) FULLNODENAME
                        FROM CRMV1.CT_COMM_TYPE_CFG CCTC
                       WHERE NODE_ID = A.PROC_TYPE
                      CONNECT BY CCTC.PARENT_NODE_ID = PRIOR CCTC.NODE_ID
                       START WITH CCTC.NODE_ID = '03') AS 定单类型,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_SOURCE'
                         AND ZBBM = A.SOURCE) AS 受理来源,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_PROC_MODE'
                         AND ZBBM = A.PROC_MODE) AS 处理方式,
                     (SELECT '(' || DECODE(BB.ID, 1, '0590', BB.STANDARDCODE) || ')' ||
                             AA.CHINESENAME
                        FROM CRMV1.TE AA, CRMV1.P_AREA BB
                       WHERE AA.AREA_ID = BB.ID
                         AND AA.TEID = A.CHECK_DEPT) AS 复核部门,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_LEVEL'
                         AND ZBBM = A.CONT_LEVEL) AS 重要程度,
                     A.CALL_SERVNBR AS 主叫号码,
                     A.AREA_CODE AS 当前所在地,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_PROD_ATTR'
                         AND ZBBM = A.PROD_ATTR) AS 产品属性,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_PRODUCT_BASE'
                         AND ZBBM = A.PRODUCT_BASE) AS 产品基地,
                     A.OVERTIME AS 定单要求时限,
                     A.TOPIC AS 主题,
                     A.CONTENT AS 详细内容,
                     A.PROC_ADVISE AS 处理建议,
                     A.LINK_NAME AS 联系人,
                     A.LINK_CONTENT AS 联系电话,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'CT_REPLY_MODE'
                         AND ZBBM = A.REPLY_MODE) AS 回复方式,
                     A.REPLY_DATE AS 回复时间,
                     (SELECT SC.FAXMAIL
                        FROM CRMV1.SP_CUSTOMER_CONTACT_HIS SC
                       WHERE CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 邮件,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'IS_RESPONSES'
                         AND ZBBM = A.IS_RESPONSES) AS 是否首回,
                     (SELECT ZBZS
                        FROM CRMV1.ZB
                       WHERE ZBFL = 'SHLX'
                         AND ZBBM = A.RESPONSES_TYP) AS 首回类型,
                     A.RESPONSES_CODE AS 首回区号,
                     A.RESPONSES_PHONE AS 首回号码,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 535
                         AND ROWNUM < 2) AS 障碍联系人,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 536
                         AND ROWNUM < 2) AS 障碍联系电话,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 534
                         AND ROWNUM < 2) AS 障碍主叫号码,
                     (SELECT PARAM2
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 531
                         AND ROWNUM < 2) AS 障碍现象编码,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 537
                         AND ROWNUM < 2) AS 障碍预约时间,
                     (SELECT CR.FULLREGIONNAME
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF,
                             (SELECT SUBSTR(SYS_CONNECT_BY_PATH(REGION_NAME, ':'), 2) FULLREGIONNAME,
                                     COMMON_REGION_ID
                                FROM CRMV2.COMMON_REGION
                              CONNECT BY UP_REGION_ID = PRIOR COMMON_REGION_ID
                               START WITH UP_REGION_ID IS NULL) CR
                       WHERE CCF.FEA_SPEC_ID = 741
                         AND CR.COMMON_REGION_ID = TO_NUMBER(CCF.PARAM1)
                         AND CCF.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 投障区域,
                     (SELECT PARAM2
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 620014306
                         AND ROWNUM < 2) AS 销障原因,
                     (SELECT PARAM1
                        FROM CRMV1.CUSTOMER_CONTACT_FEA_HIS CCF
                       WHERE CCF.CONT_ID = A.CONT_ID
                         AND CCF.FEA_SPEC_ID = 532
                         AND ROWNUM < 2) AS 障碍现象描述,
                     (SELECT PS.NAME
                        FROM CRMV1.SP_CUSTOMER_CONTACT_HIS SCC,
                             CRMV1.SP_PROD_SPEC            PS
                       WHERE PS.SP_PROD_SPEC_ID = SCC.SP_PROD_SPEC_ID
                         AND SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 业务名称,
                     (SELECT SSI.SP_CODE
                        FROM CRMV1.SP_CUSTOMER_CONTACT_HIS SCC,
                             CRMV1.SP_INFO                 SSI
                       WHERE SSI.SP_INFO_ID = SCC.SP_INFO_ID
                         AND SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS SP代码,
                     (SELECT '(' || DECODE(BB.ID, 1, '0590', BB.STANDARDCODE) || ')' ||
                             AA.CHINESENAME
                        FROM CRMV1.TE AA, CRMV1.P_AREA BB
                       WHERE AA.AREA_ID = BB.ID
                         AND AA.TEID = A.PROC_DEPT) AS 第一责任部门,
                     (SELECT PS.NAME
                        FROM CRMV1.SP_CUSTOMER_CONTACT_HIS SCC,
                             CRMV1.PROD_SPEC               PS
                       WHERE PS.PROD_SPEC_ID = SCC.PROD_SPEC_ID
                         AND SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 业务平台,
                     (SELECT SCC.SERVICE_CODE
                        FROM CRMV1.SP_CUSTOMER_CONTACT_HIS SCC
                       WHERE SCC.CONT_ID = A.CONT_ID
                         AND ROWNUM < 2) AS 服务代码,
                     A.OBSTACLE_AREA_CODE AS 障碍号码区域
                FROM CRMV1.CUSTOMER_CONTACT_HIS A
               WHERE A.CONT_TYPE = '3'
                 AND A.PROD_ATTR IS NOT NULL
                 AND A.STATE = '70X'
                 AND A.CREATE_DATE > TRUNC(SYSDATE) - 1
                 AND A.CREATE_DATE <= TRUNC(SYSDATE)) LOOP
    V_CNT := V_CNT + 1;

    SELECT SEQ_AUTO_TEST_BX_DATA_ID.NEXTVAL
      INTO V_AUTO_TEST_BX_DATA_ID
      FROM DUAL;
    INSERT INTO AUTO_TEST_BX_DATA
      (AUTO_TEST_BX_DATA_ID, MENU_NAME, PROCESS_MODE, ACTION, ACCEPT_TIME, AGREE_NBR, ORDER_NBR, AUTO_STATUS, MANUAL_STATUS, DEALER, ORDER_TYPE, NEW_AGREE_NBR, REMOTE_URL)
    VALUES
      (V_AUTO_TEST_BX_DATA_ID, '投诉单受理', REC.处理方式, REC.动作, REC.受理时间, REC.定单号, REC.CONT_ID, 'FREE', '', '', '', '', '');

    INSERT INTO AUTO_TEST_COMPLAINT
      (AUTO_TEST_COMPLAINT_ID, BX_DATA_ID, LOGIN_USER, LOGIN_PWD, LOGIN_TEAM, OBSTACLE_SERVNBR, PROC_TYPE, SOURCE_TYPE, PROC_MODE, CHECK_DEPT, IMPORTANCE, CALL_SERVNBR, CURRENT_LOCATION, PRODUCT_ATTR, PRODUCT_BASE, OVERTIME, TOPIC, CONTENT, PROC_ADVISE, LINK_NAME, LINK_CONTENT, REPLY_MODE, REPLY_DATE, LINK_EMAIL, IS_RESPONSES, RESPONSES_TYPE, RESPONSES_CODE, RESPONSES_PHONE, OBSTACLE_CONTACT, OBSTACLE_CONT_PHONE, OBSTACLE_CALL_NBR, OBSTACLE_PHEN_CODE, OBSTACLE_APPOINT_TIME, OBSTACLE_AREA, OFFOBSTACLE_REASON, SP_PRODNAME, SP_CODE, FIRST_ASSIGN_TE, PROD_SPEC_PLATFORM, SERVICE_CODE, AREA_CODE)
    VALUES
      (SEQ_AUTO_TEST_BX_DATA_ID.NEXTVAL, V_AUTO_TEST_BX_DATA_ID, REC.受理工号, 'fZ123123', REC.受理团队, REC.障碍号码, REC.定单类型, REC.受理来源, REC.处理方式, REC.复核部门, REC.重要程度, REC.主叫号码, REC.当前所在地, REC.产品属性, REC.产品基地, REC.定单要求时限, REC.主题, REC.详细内容, REC.处理建议, REC.联系人, REC.联系电话, REC.回复方式, REC.回复时间, REC.邮件, REC.是否首回, REC.首回类型, REC.首回区号, REC.首回号码, REC.障碍联系人, REC.障碍联系电话, REC.障碍主叫号码, REC.障碍现象编码, REC.障碍预约时间, REC.投障区域, REC.销障原因, REC.业务名称, REC.SP代码, REC.第一责任部门, REC.业务平台, REC.服务代码, REC.障碍号码区域);
    IF V_CNT > 100 THEN
      V_CNT := 0;
      COMMIT;
    END IF;
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    NULL;

END PROC_SYNC_CT_AUTO_TEST;
/
