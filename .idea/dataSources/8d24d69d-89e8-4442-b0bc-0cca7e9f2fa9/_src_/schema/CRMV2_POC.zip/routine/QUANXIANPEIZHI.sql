CREATE procedure           quanxianpeizhi (user_name_ in varchar2,user_id_ in int,menuName_ in varchar2,result out varchar2) is

--获取菜单树，并给其子菜单赋权
cursor menu_tree is
      select a.privilege_id, a.privilege_name, a.parent_privilege_id
        from privilege a
       where a.privilege_sub_type in ( 10110, 10100 )
       and status_cd = '10'
       start with a.privilege_name like '%'|| menuName_   || '%'
      connect by prior a.privilege_id = a.parent_privilege_id;
  v_data  menu_tree%ROWTYPE;
  v_count number(5);
  system_user_id_tmp number(12);

begin
  --1工号和id进行判断---------------------------------------------------------
  if user_id_ is null then
     dbms_output.put_line('验证用户id是否为空，否则根据帐户查询') ;
     select system_user_id into system_user_id_tmp from system_user where staff_code like user_name_ ;
     dbms_output.put_line(user_name_||'的system_user_id ='||system_user_id_tmp) ;
  else
    system_user_id_tmp:=user_id_;
    end if ;
   --2工号id不为空，执行权限配置----------------------------------------------------
   if system_user_id_tmp is not null then

          --2.1打开游标----------------------------------------
            OPEN menu_tree;
         LOOP
          --2.1遍历所有记录------------------------------------
         FETCH menu_tree INTO v_data;
          --2.3判断是否已经赋权权限id+userId 进行判断----------------------------
          v_count:=0;
          Exit when menu_tree%NOTFOUND;

          select count(*) into v_count from staff_limit a
           where a.privilege_id = v_data.privilege_id and a.system_user_id= system_user_id_tmp and a.status_cd= '10';
          if v_count >0 then
           dbms_output.put_line('已配置权限,用户id='||system_user_id_tmp||',权限名称='||v_data.privilege_name||',权限id='||v_data.privilege_id) ;
          else
           dbms_output.put_line('未配置权限,用户id='||system_user_id_tmp||',权限名称='||v_data.privilege_name||',权限id='||v_data.privilege_id) ;
             insert into staff_limit (SYSTEM_USER_PRIVILEGE_ID, PRIVILEGE_ID, SYSTEM_USER_ID, EFFECT_DATE, EXPIRE_DATE, STATUS_CD, STATUS_DATE, CREATE_DATE, UPDATE_DATE, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, PRI_TYPE)
             values (seq_staff_limit_id.nextval, v_data.privilege_id, system_user_id_tmp, sysdate,sysdate, '10', sysdate, sysdate, null, null, null, 49822, 49822, '11');
             commit;
          end if;

        END LOOP;
        result:='执行成功!!!';
        CLOSE menu_tree;
    else
         dbms_output.put_line('id为空');
         result:='id为空,未进行配置!!!';
    end if ;
exception
  when NO_DATA_FOUND then
   dbms_output.put_line('执行异常');
        result:='执行异常:未找到数据!!!';
end  quanxianpeizhi;
/
