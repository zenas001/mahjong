CREATE procedure           meta_data_backup is
  V_EXECUTESQL    VARCHAR2(7000); --实时执行语句
  V_AttrValueCode VARCHAR2(50);
  V_AttrValueName VARCHAR2(200);
  V_AttrValueDesc VARCHAR2(1000);
  V_ParentAttrValueId VARCHAR2(50);
  V_AttrSpecCode      VARCHAR2(50);
  V_AttrSpecId        VARCHAR2(50);
  V_AttrValueId       VARCHAR2(50);
begin
  --生成主数据报批清单
  FOR COMSYNCCONF IN (select attr_id,
       attr_cd,
       attr_value,
       attr_value_name,
       attr_desc,
       eff_date,
       exp_date,
       parent_value_id,
       manage_grade,
       attr_value_id,
       group_cd,
       status_cd,
       cns_type
  from (select a.attr_value_id,
               a.attr_value,
               a.attr_value_name,
               a.attr_desc,
               a.eff_date,
               a.exp_date,
               a.parent_value_id,
               b.attr_id,
               b.attr_cd,
               a.manage_grade,
               b.group_cd,
               a.status_cd,
               b.cns_type
          from crmv2.attr_value  a,
               crmv2.attr_spec   b,
               crmv2.sys_class   c,
               crmv2.sys_package d
         where a.attr_id = b.attr_id
           and b.class_id = c.class_id
           and c.package_id = d.package_id
           and a.status_cd = '1000'
           and b.status_cd = '1000'
           and a.attr_id in
               (select aa.attr_id
                  from (select d.table_name, c.attr_cd, c.group_cd, c.attr_id
                          from crmv2.attr_spec c, crmv2.sys_class d
                         where c.class_id = d.class_id) aa,
                       (select b.entity_code,
                               a.table_column_name,
                               a.attr_spec_code
                          from sys_attr_spec a, sys_entity b
                         where a.entity_id = b.entity_id
                           and a.Attr_Spec_Code in
                               (select attr_spec_code
                                  from sys_attr_spec
                                 where attr_spec_rule_bb = 'T1'
                                   and attr_spec_code like '___-00__')
                         order by a.attr_spec_code) bb
                 where aa.table_name = bb.entity_code
                   and aa.attr_cd = bb.table_column_name)) cc
 where not exists
 (select b.attr_value_code, b.attr_value_name, a.attr_spec_code
          from sys_attr_spec a, sys_attr_value b
         where a.attr_spec_id = b.attr_spec_id
           and a.attr_spec_code in
               (select attr_spec_code
                  from sys_attr_spec
                 where attr_spec_rule_bb = 'T1'
                   and attr_spec_code like '___-00__')
           and a.attr_spec_code = cc.group_cd
           and b.attr_value_code = cc.attr_value)) LOOP

    V_AttrValueCode := COMSYNCCONF.ATTR_VALUE;
    V_AttrValueName := COMSYNCCONF.ATTR_VALUE_NAME;
    V_AttrValueDesc := COMSYNCCONF.ATTR_DESC;
    V_ParentAttrValueId := COMSYNCCONF.PARENT_VALUE_ID;
    V_AttrSpecCode      := COMSYNCCONF.GROUP_CD;
    V_AttrValueId       := COMSYNCCONF.ATTR_VALUE_ID;

    V_EXECUTESQL := 'select attr_spec_id from sys_attr_spec where attr_spec_code='''||V_AttrSpecCode||'''';
    EXECUTE IMMEDIATE V_EXECUTESQL INTO V_AttrSpecId;

    --写入主数据表，标识为1400
    if V_AttrValueDesc is null then
      V_AttrValueDesc := 'null';
    else
      V_AttrValueDesc := ''''||V_AttrValueDesc||'''';
    end if;

    if V_ParentAttrValueId is null then
      V_ParentAttrValueId := 'null';
    else
      V_EXECUTESQL := 'select a.attr_value_id from sys_attr_value a where a.attr_spec_id='||V_AttrSpecId||' and a.attr_value_code=(select b.attr_value from attr_value b where b.attr_value_id='||V_ParentAttrValueId||')';
      EXECUTE IMMEDIATE V_EXECUTESQL into V_ParentAttrValueId;
    end if;

    V_EXECUTESQL := 'insert into sys_attr_value (attr_value_id,attr_spec_id,attr_value_code,attr_value_name,attr_value_desc,eff_date,exp_date,
                     parent_attr_value_id,manage_grade,create_date,status_cd) values ('||V_AttrValueId||','
                     ||V_AttrSpecId||','''||V_AttrValueCode||''','''||V_AttrValueName||''','||V_AttrValueDesc||',null,null,'
                     ||V_ParentAttrValueId||',''11'',sysdate,''1400'')';
    EXECUTE IMMEDIATE V_EXECUTESQL;

    --记录日志
    V_EXECUTESQL := 'insert into oper_record (op_log_id,class_id,op_desc,op_date,op_type,status_cd,obj_inst_id) values
    (seq_oper_record_id.nextval,(select class_id from sys_class where table_name=''SYS_ATTR_VALUE'' and status_cd=''1000''),''自动发起新增主数据审批申请,主数据：'||V_AttrValueName||''',sysdate,''省内审批'',''1000'','||V_AttrValueId||')';
    EXECUTE IMMEDIATE V_EXECUTESQL;
  END LOOP;

  --主数据报备:增加主数据
  V_EXECUTESQL := 'insert into meta_data_group_bb
  select attr_id,
         attr_cd,
         attr_value,
         attr_value_name,
         attr_desc,
         eff_date,
         exp_date,
         parent_value_id,
         manage_grade,
         attr_value_id,
         group_cd,
         status_cd,
         null,
         ''add''
    from (select a.attr_value_id,
                 a.attr_value,
                 a.attr_value_name,
                 a.attr_desc,
                 a.eff_date,
                 a.exp_date,
                 a.parent_value_id,
                 b.attr_id,
                 b.attr_cd,
                 a.manage_grade,
                 b.group_cd,
                 a.status_cd
            from crmv2.attr_value  a,
                 crmv2.attr_spec   b,
                 crmv2.sys_class   c,
                 crmv2.sys_package d
           where a.attr_id = b.attr_id
             and b.class_id = c.class_id
             and c.package_id = d.package_id
             and a.status_cd = ''1000''
             and a.attr_id in
                 (select aa.attr_id
                    from (select d.table_name, c.attr_cd, c.group_cd, c.attr_id
                            from crmv2.attr_spec c, crmv2.sys_class d
                           where c.class_id = d.class_id) aa,
                         (select b.entity_code,
                                 a.table_column_name,
                                 a.attr_spec_code
                            from sys_attr_spec a, sys_entity b
                           where a.entity_id = b.entity_id
                             and a.Attr_Spec_Code in
                                 (select attr_spec_code
                                    from sys_attr_spec
                                   where attr_spec_rule_bb = ''T2''
                                     and attr_spec_code like ''___-00__'')
                           order by a.attr_spec_code) bb
                   where aa.table_name = bb.entity_code
                     and aa.attr_cd = bb.table_column_name)) cc
   where not exists
   (select b.attr_value_code, b.attr_value_name, a.attr_spec_code
            from sys_attr_spec a, sys_attr_value b
           where a.attr_spec_id = b.attr_spec_id
             and b.status_cd = ''1000''
             and a.attr_spec_code in
                 (select attr_spec_code
                    from sys_attr_spec
                   where attr_spec_rule_bb = ''T2''
                     and attr_spec_code like ''___-00__'')
             and a.attr_spec_code = cc.group_cd
             and b.attr_value_code = cc.attr_value)';

    EXECUTE IMMEDIATE V_EXECUTESQL;

    --主数据报备:停用主数据
    V_EXECUTESQL := 'insert into meta_data_group_bb
    select attr_id,
           attr_cd,
           attr_value,
           attr_value_name,
           attr_desc,
           eff_date,
           exp_date,
           parent_value_id,
           manage_grade,
           attr_value_id,
           group_cd,
           status_cd,
           null,
           ''disable''
      from (select a.attr_value_id,
                   a.attr_value,
                   a.attr_value_name,
                   a.attr_desc,
                   a.eff_date,
                   a.exp_date,
                   a.parent_value_id,
                   b.attr_id,
                   b.attr_cd,
                   a.manage_grade,
                   b.group_cd,
                   a.status_cd
              from crmv2.attr_value  a,
                   crmv2.attr_spec   b,
                   crmv2.sys_class   c,
                   crmv2.sys_package d
             where a.attr_id = b.attr_id
               and b.class_id = c.class_id
               and c.package_id = d.package_id
               and a.status_cd = ''1100''
               and a.attr_id in
                   (select aa.attr_id
                      from (select d.table_name, c.attr_cd, c.group_cd, c.attr_id
                              from crmv2.attr_spec c, crmv2.sys_class d
                             where c.class_id = d.class_id) aa,
                           (select b.entity_code,
                                   a.table_column_name,
                                   a.attr_spec_code
                              from sys_attr_spec a, sys_entity b
                             where a.entity_id = b.entity_id
                               and a.Attr_Spec_Code in
                                   (select attr_spec_code
                                      from sys_attr_spec
                                     where attr_spec_rule_bb = ''T2''
                                       and attr_spec_code like ''___-00__'')
                             order by a.attr_spec_code) bb
                     where aa.table_name = bb.entity_code
                       and aa.attr_cd = bb.table_column_name)) cc
     where exists (select b.attr_value_code, b.attr_value_name, a.attr_spec_code
              from sys_attr_spec a, sys_attr_value b
             where a.attr_spec_id = b.attr_spec_id
               and b.status_cd = ''1000''
               and a.attr_spec_code in
                   (select attr_spec_code
                      from sys_attr_spec
                     where attr_spec_rule_bb = ''T2''
                       and attr_spec_code like ''___-00__'')
               and a.attr_spec_code = cc.group_cd
               and b.attr_value_code = cc.attr_value)';

     EXECUTE IMMEDIATE V_EXECUTESQL;

     COMMIT;

end meta_data_backup;
/
