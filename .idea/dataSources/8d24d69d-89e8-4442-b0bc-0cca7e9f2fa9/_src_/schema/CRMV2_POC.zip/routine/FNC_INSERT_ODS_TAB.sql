CREATE FUNCTION           fnc_insert_ods_tab(v_staffId     in string,
                                              v_privilegeId in string,
                                              v_attrValue   in string,
                                              v_classId     in string)
  RETURN BOOLEAN IS
  v_temp_type varchar2(20) := '';
  v_cnt       number(12) := 0;
begin
  select count(1)
    into v_cnt
    from crm_user_obj a
   where a.user_id = v_staffId
     and obj_id = v_privilegeId
     and map_system = 'CRM2';
  if v_cnt < 1 then
    insert into crm_user_obj values (v_staffId, v_privilegeId, 'CRM2',sysdate);
  end if;

  if v_classId = -88 then
    v_temp_type := 'team';
  end if;
  if v_classId = 121 then
    v_temp_type := 'area';
  end if;
  if v_classId = 36 then
    v_temp_type := 'organ';
  end if;
  if v_classId = 950000230 then
    v_temp_type := 'sensitivity';
  end if;
  select count(1)
    into v_cnt
    from crm_user_right a
   where a.user_id = v_staffId
     and right_value = v_attrValue
     and right_type = v_temp_type
     and sys_type='CRM'
     and map_system = 'CRM2';
  if v_cnt < 1 then
    insert into crm_user_right
    values
      (v_staffId, v_temp_type, v_attrValue, 'CRM', 'CRM2',sysdate);
  end if;
  return true;
END fnc_insert_ods_tab;
/
