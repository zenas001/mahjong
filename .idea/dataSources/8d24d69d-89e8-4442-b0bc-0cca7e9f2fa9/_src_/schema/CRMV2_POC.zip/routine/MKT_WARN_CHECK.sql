CREATE PROCEDURE           MKT_WARN_CHECK IS
  n_check          number;--是否校验
  n_warn_con_id    number;--预警配置id
  n_warn_cycle     number;--预警周期
begin
     for rec in (select * from Mkt_Store_Item  where low_limit>0 or up_limit>0 ) loop
         n_check:=0;
         begin
              select  a.warn_conf_id,a.cycle  into n_warn_con_id ,n_warn_cycle from Mkt_Warn_Conf a
              where a.item_id =rec.store_item_id and a.state='70A';
              if rec.usage_count<rec.low_limit or rec.usage_count>rec.up_limit then
                 n_check:=1;
              end if;
              exception
              when NO_DATA_FOUND then
                   begin
                        select  a.warn_conf_id ,a.cycle into n_warn_con_id ,  n_warn_cycle from Mkt_Warn_Conf a
                        where a.stroe_id =rec.store_id and a.state='70A';
                        if rec.usage_count<rec.low_limit or rec.usage_count>rec.up_limit then
                           n_check:=1;
                        end if;
                   end;
         end;
	 --首次监控或达到监控周期
         if rec.old_send_date is null or trunc(sysdate-rec.old_send_date)>= n_warn_cycle then
            begin
                if n_check = 1 then
                   begin
                             ---插入库存监控信息表
                          insert into mkt_warn_info
                            (warn_conf_id, item_id, usage_count, obj_id, create_date,modify_date,state,real_modify_date)
                          values
                            (MKT_WARN_INFO_ID_SEQ.nextval,--seq
                             rec.store_item_id,
                             rec.usage_count,
                             n_warn_con_id,
                             sysdate,
                             sysdate,
                             '70A',
                             sysdate);

                    end;
                 end if;
		 --更新最近一次监控时间
                 update Mkt_Store_Item
                        set   old_send_date = sysdate
                        where store_item_id = rec.store_item_id;
                 commit;
             end;
          end if;
     end loop;
end;
/
