CREATE PROCEDURE           proc_update_yzf_temp_state IS
  CURSOR c IS
    SELECT *
      FROM prod_inst_yzf a
     WHERE a.status_cd = '1099'

BEGIN

  BEGIN
    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '翼支付轮询处理之前状态', '', SYSDATE);
    COMMIT;
    FOR cur IN c
    LOOP
      BEGIN
        ----数据插入历史表
        INSERT INTO prod_inst_yzf_temp_his
          (PROD_INST_YZF_temp_ID, ORDER_ITEM_ID, PROD_INST_ID, TYPE, REMARK, STATUS_CD, STATUS_DATE, HIS_ID, AREA_ID, REGION_CD, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
          (SELECT PROD_INST_YZF_temp_ID, ORDER_ITEM_ID, PROD_INST_ID, TYPE, REMARK, STATUS_CD, STATUS_DATE,seq_prod_inst_yzf_temp_his_id.nextval, AREA_ID, REGION_CD, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF
             FROM prod_inst_yzf_temp oa
            WHERE oa.PROD_INST_YZF_temp_ID = cur.PROD_INST_YZF_temp_ID);

        UPDATE prod_inst_yzf_temp a
           SET a.status_cd    = '1000',
               a.update_date  = SYSDATE,
               a.status_date  = SYSDATE,
               a.update_staff = -1
         WHERE a.PROD_INST_YZF_temp_ID = cur.PROD_INST_YZF_temp_ID;

        i     := i + 1;
        v_cnt := v_cnt + 1;

        IF i > 50
        THEN
          COMMIT;
          i := 0;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval, '翼支付轮询处理后状态更新异常,队列ID:' ||
              cur.queue_id, str_msg, SYSDATE);
          COMMIT;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval, '翼支付轮询处理后状态更新异常', str_msg, SYSDATE);
      COMMIT;
  END;

  BEGIN
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval, '翼支付轮询处理最后提交队列状态失败', str_msg, SYSDATE);
      COMMIT;
  END;

  INSERT INTO vip_info_log
    (log_id, msg, err, op_date)
  VALUES
    (seq_vip_info_log_id.nextval, '翼支付轮询处理共计更新队列状态次数', to_char(v_cnt), SYSDATE);
  INSERT INTO vip_info_log
    (log_id, msg, err, op_date)
  VALUES
    (seq_vip_info_log_id.nextval, '翼支付轮询处理结束更新队列状态', '', SYSDATE);
  COMMIT;
END proc_update_auto_queue_state;
/
