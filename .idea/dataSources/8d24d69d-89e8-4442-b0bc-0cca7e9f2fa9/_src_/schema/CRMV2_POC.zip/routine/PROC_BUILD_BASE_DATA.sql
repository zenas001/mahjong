CREATE procedure           proc_build_base_data(table_name in string) is
v_count int;
begin
  select count(1)
    into v_count
    from sys_class a
   where a.table_name = table_name;
  if v_count > 0 then
    if FNC_CRMV2_REPAIR_CLASS(table_name) then
      null;
    end if;
  else
    if fnc_crmv2_build_class(table_name) then
      null;
    end if;
  end if;
end proc_build_base_data;
/
