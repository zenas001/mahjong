CREATE PROCEDURE           Q_T02_PROD_TRANS(i_order_item_id IN NUMBER,
                                             I_ACTION_TYPE   IN VARCHAR2) IS
  V_PROD_SEQ            NUMBER;
  V_CUST_ORDER_ID       NUMBER;
  V_PROD_INST_ID        NUMBER;
  I_AUTOTEST_MEMBER_SEQ NUMBER;
  C_ACTION_ADD CONSTANT VARCHAR2(5) := 'ADD';
  C_ACTION_MOD CONSTANT VARCHAR2(5) := 'MOD';
  C_ACTION_DEL CONSTANT VARCHAR2(5) := 'DEL';
BEGIN
  V_PROD_SEQ := SEQ_AUTOTEST_PROD_ID.NEXTVAL;
  select cust_order_id
    INTO V_CUST_ORDER_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  select order_item_obj_id
    INTO V_PROD_INST_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  select a_order_item_id
    into I_AUTOTEST_MEMBER_SEQ
    from order_item_rel_his
   where z_order_item_id = i_order_item_id
     and rownum < 2;

  IF I_ACTION_TYPE = C_ACTION_ADD THEN
    --ADD
    --附属产品
    insert into AUTOTEST_PROD
      (AUTOTEST_PROD_ID,
       CUST_ORDER_ID,
       AUTOTEST_MEMBER_ID,
       EXT_PROD_ID,
       ACTION,
       CREATE_DATE)
      select V_PROD_SEQ            AUTOTEST_PROD_ID,
             V_CUST_ORDER_ID       CUST_ORDER_ID,
             I_AUTOTEST_MEMBER_SEQ AUTOTEST_MEMBER_ID,
             p.EXT_PROD_ID,
             C_ACTION_ADD          ACTION,
             SYSDATE               CREATE_DATE
        from crmv2.prod_inst D, crmv2.product p
       where d.prod_inst_id = V_PROD_INST_ID
         and d.product_id = p.product_id;
    --附属产品属性
    insert into AUTOTEST_PROD_ATTR
      (AUTOTEST_PROD_ATTR_ID,
       AUTOTEST_PROD_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      select SEQ_AUTOTEST_PROD_ATTR_ID.NEXTVAL AUTOTEST_PROD_ATTR_ID,
             V_PROD_SEQ                        AUTOTEST_PROD_ID,
             c.EXT_ATTR_NBR,
             a.ATTR_VALUE_ID,
             a.attr_value,
             sysdate                           CREATE_DATE
        from crmv2.PROD_INST_ATTR a, CRMV2.ATTR_SPEC c
       where a.prod_inst_id = V_PROD_INST_ID
         and a.ATTR_ID = c.ATTR_ID;
    ---MEMBER_REL
    insert into autotest_member_rel
      (AUTOTEST_MEMBER_REL_ID,
       CUST_ORDER_ID,
       RELATION_TYPE_CD,
       PROD_INST_A_ID,
       PROD_INST_Z_ID,
       ROLE_CD,
       CREATE_DATE)
      select SEQ_AUTOTEST_MEMBER_REL_ID.NEXTVAL AUTOTEST_MEMBER_REL_ID,
             V_CUST_ORDER_ID                    CUST_ORDER_ID,
             D.RELATION_TYPE_CD,
             D.PROD_INST_A_ID,
             D.PROD_INST_Z_ID,
             D.ROLE_CD,
             SYSDATE                            CREATE_DATE
        from crmv2.prod_inst_REL D
       where D.PROD_INST_Z_ID = V_PROD_INST_ID;

  ELSIF I_ACTION_TYPE = C_ACTION_MOD THEN
    --MOD

    --附属产品
    insert into AUTOTEST_PROD
      (AUTOTEST_PROD_ID,
       CUST_ORDER_ID,
       AUTOTEST_MEMBER_ID,
       EXT_PROD_ID,
       ACTION,
       CREATE_DATE)
      select V_PROD_SEQ            AUTOTEST_PROD_ID,
             V_CUST_ORDER_ID       CUST_ORDER_ID,
             I_AUTOTEST_MEMBER_SEQ AUTOTEST_MEMBER_ID,
             p.EXT_PROD_ID,
             C_ACTION_MOD          ACTION,
             SYSDATE               CREATE_DATE
        from crmv2.prod_inst a, crmv2.order_item_his b, crmv2.product p
       where b.order_item_id = i_order_item_id
         and a.prod_inst_id = b.order_item_obj_id
         and p.product_id = a.product_id;

    --附属产品属性
    insert into AUTOTEST_PROD_ATTR
      (AUTOTEST_PROD_ATTR_ID,
       AUTOTEST_PROD_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      select SEQ_AUTOTEST_PROD_ATTR_ID.NEXTVAL AUTOTEST_PROD_ATTR_ID,
             V_PROD_SEQ                        AUTOTEST_PROD_ID,
             c.ext_attr_nbr,
             null,
             a.new_value,
             sysdate
        from crmv2.order_item_proc_attr_his a, CRMV2.ATTR_SPEC c
       where a.order_item_id = i_order_item_id
         and a.class_id = -4
         and a.OBJ_ATTR_ID = c.ATTR_ID;
  --MEMBER_REL
    insert into autotest_member_rel
      (AUTOTEST_MEMBER_REL_ID,
       CUST_ORDER_ID,
       RELATION_TYPE_CD,
       PROD_INST_A_ID,
       PROD_INST_Z_ID,
       ROLE_CD,
       CREATE_DATE)
      select SEQ_AUTOTEST_MEMBER_REL_ID.NEXTVAL AUTOTEST_MEMBER_REL_ID,
             V_CUST_ORDER_ID                    CUST_ORDER_ID,
             D.RELATION_TYPE_CD,
             D.PROD_INST_A_ID,
             D.PROD_INST_Z_ID,
             D.ROLE_CD,
             SYSDATE                            CREATE_DATE
        from crmv2.prod_inst_REL D, order_item_proc_attr_his A
       where A.NEW_VALUE = D.PROD_INST_REL_ID
         AND A.CLASS_ID = 136
         AND A.ORDER_ITEM_ID = i_order_item_id;

  ELSE
    --del
    insert into AUTOTEST_PROD
      (AUTOTEST_PROD_ID,
       CUST_ORDER_ID,
       AUTOTEST_MEMBER_ID,
       EXT_PROD_ID,
       ACTION,
       CREATE_DATE)
      select V_PROD_SEQ            AUTOTEST_PROD_ID,
             V_CUST_ORDER_ID       CUST_ORDER_ID,
             I_AUTOTEST_MEMBER_SEQ AUTOTEST_MEMBER_ID,
             p.EXT_PROD_ID,
             C_ACTION_DEL          ACTION,
             SYSDATE               CREATE_DATE
        from crmv2.prod_inst a, crmv2.order_item_his b, crmv2.product p
       where b.order_item_id = i_order_item_id
         and a.prod_inst_id = b.order_item_obj_id
         and p.product_id = a.product_id;

  END IF;

END Q_T02_PROD_TRANS;
/
