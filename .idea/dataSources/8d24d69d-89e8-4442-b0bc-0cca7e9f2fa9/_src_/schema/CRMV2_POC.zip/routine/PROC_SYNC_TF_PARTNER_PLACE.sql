CREATE procedure           PROC_SYNC_TF_PARTNER_PLACE is
  varAttrIdWGBS     NUMBER(9);
  varAttrIdWGMC     NUMBER(9);
  varAttrIdSTQDGS   NUMBER(9);
  varAttrValueId    NUMBER(9);
  varAttrValue      VARCHAR2(4000);
  varHasWGBSCount   NUMBER(9);
  varHasWGMCCount   NUMBER(9);
  varHasSTQDGSCount NUMBER(9);
  --查找还没同步过来的做新增
  CURSOR addCUR is
    select PARTNER_ID, PLACE_NODE, PLACE_NAME
      from TF_PARTNER_PLACE_CRM pext
     where not exists (select *
              from TF_PARTNER_PLACE ploc
             where ploc.partner_id = pext.partner_id)
       and exists (select *
              from channel cl
             where cl.channel_id = pext.partner_id
               and cl.channel_class is not null)
       and pext.PLACE_NODE is not null;
begin
  select ap.attr_id
    into varAttrIdWGBS
    from attr_spec ap
   where ap.attr_name = '网格标识'
     and ap.class_id = 30
     and ap.status_cd = '1000'
     and rownum < 2;
  select ap.attr_id
    into varAttrIdWGMC
    from attr_spec ap
   where ap.attr_name = '网格名称'
     and ap.class_id = 30
     and ap.status_cd = '1000'
     and rownum < 2;

  select ap.attr_id
    into varAttrIdSTQDGS
    from attr_spec ap
   where ap.attr_name = '实体渠道归属'
     and ap.class_id = 30
     and ap.status_cd = '1000'
     and rownum < 2;

  select av.attr_value_id
    into varAttrValueId
    from attr_value av
   where av.attr_id = varAttrIdSTQDGS
     and av.attr_value_name = '物理网格'
     and av.status_cd = '1000'
     and rownum < 2;

  select av.attr_value
    into varAttrValue
    from attr_value av
   where av.attr_id = varAttrIdSTQDGS
     and av.attr_value_name = '物理网格'
     and av.status_cd = '1000'
     and rownum < 2;

  FOR addREC IN addCUR LOOP
    varHasWGBSCount   := 0;
    varHasWGMCCount   := 0;
    varHasSTQDGSCount := 0;
    select count(car.attr_id)
      into varHasWGBSCount
      from channel_attr car
     where car.channel_id = addREC.PARTNER_ID
       and car.attr_id = varAttrIdWGBS;
    select count(car.attr_id)
      into varHasWGMCCount
      from channel_attr car
     where car.channel_id = addREC.PARTNER_ID
       and car.attr_id = varAttrIdWGMC;
    select count(car.attr_id)
      into varHasSTQDGSCount
      from channel_attr car
     where car.channel_id = addREC.PARTNER_ID
       and car.attr_id = varAttrIdSTQDGS;
    insert into TF_PARTNER_PLACE
      (PARTNER_ID, PLACE_NODE, PLACE_NAME)
    Values
      (addREC.PARTNER_ID, addREC.place_node, addREC.place_name);
    if varHasWGBSCount <= 0 then
      insert into channel_attr
        (CHANNEL_ATTR_ID,
         ATTR_ID,
         CHANNEL_ID,
         ATTR_VALUE,
         ATTR_VALUE_ID,
         DESCRIPTION,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         AREA_ID,
         REGION_CD,
         CREATE_STAFF,
         UPDATE_DATE,
         UPDATE_STAFF)
      values
        (seq_channel_attr_id.nextval,
         varAttrIdWGBS,
         addREC.PARTNER_ID,
         addREC.place_node,
         null,
         '',
         '1000',
         sysdate,
         sysdate,
         2,
         2,
         49822,
         sysdate,
         49822);
    end if;
    if varHasWGMCCount <= 0 then
      insert into channel_attr
        (CHANNEL_ATTR_ID,
         ATTR_ID,
         CHANNEL_ID,
         ATTR_VALUE,
         ATTR_VALUE_ID,
         DESCRIPTION,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         AREA_ID,
         REGION_CD,
         CREATE_STAFF,
         UPDATE_DATE,
         UPDATE_STAFF)
      values
        (seq_channel_attr_id.nextval,
         varAttrIdWGMC,
         addREC.PARTNER_ID,
         addREC.place_name,
         null,
         '',
         '1000',
         sysdate,
         sysdate,
         2,
         2,
         49822,
         sysdate,
         49822);
    end if;
    if varHasSTQDGSCount <= 0 then
      insert into channel_attr
        (CHANNEL_ATTR_ID,
         ATTR_ID,
         CHANNEL_ID,
         ATTR_VALUE,
         ATTR_VALUE_ID,
         DESCRIPTION,
         STATUS_CD,
         STATUS_DATE,
         CREATE_DATE,
         AREA_ID,
         REGION_CD,
         CREATE_STAFF,
         UPDATE_DATE,
         UPDATE_STAFF)
      values
        (seq_channel_attr_id.nextval,
         varAttrIdSTQDGS,
         addREC.PARTNER_ID,
         varAttrValue,
         varAttrValueId,
         '',
         '1000',
         sysdate,
         sysdate,
         2,
         2,
         49822,
         sysdate,
         49822);
    end if;
  END LOOP;

  COMMIT;
end PROC_SYNC_TF_PARTNER_PLACE;
/
