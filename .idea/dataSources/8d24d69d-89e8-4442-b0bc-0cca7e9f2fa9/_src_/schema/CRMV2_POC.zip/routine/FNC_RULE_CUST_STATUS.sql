CREATE function           FNC_RULE_CUST_STATUS(in_cust_id in string,out_result out string) return boolean is
  Result boolean;
  i_count integer;
begin

  select count(*) into i_count from prod_inst a where a.owner_cust_id = in_cust_id;

  if i_count>0 then
     out_result :='13';
     result := true;
  else
     out_result :='10';
     result := false;
  end if;

  return(Result);
end FNC_RULE_CUST_STATUS;
/
