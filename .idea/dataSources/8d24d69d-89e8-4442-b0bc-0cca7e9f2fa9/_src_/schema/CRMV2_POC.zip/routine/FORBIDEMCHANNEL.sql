CREATE procedure           forbidemChannel(forbidem_id channel.channel_id%TYPE,
                                            v_rule_id   rlm_rule.rule_id%TYPE) is
begin

  for channels in (select a.channel_id
                     from channel a
                    where a.channel_id <> forbidem_id) loop
    insert into rlm_rule_obj_rel
      (rlm_rule_obj_rel_id,
       rule_id,
       obj_type,
       obj_id,
       area_id,
       region_cd,
       status_cd,
       status_date,
       create_date,
       update_date)
    values
      (seq_rlm_rule_obj_rel_id.nextval,
       v_rule_id,
       'CHANNEL',
       channels.channel_id,
       2,
       11,
       '1000',
       sysdate,
       sysdate,
       sysdate);
    commit;
  end loop;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('BUX');
end forbidemChannel;
/
