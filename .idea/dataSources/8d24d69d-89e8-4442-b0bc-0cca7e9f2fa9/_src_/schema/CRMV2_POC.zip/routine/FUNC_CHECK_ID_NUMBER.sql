CREATE function           func_check_id_number(p_number varchar2)
  return varchar2 is
  type tbl_t is table of number;
  my_tbl            tbl_t := tbl_t(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2); --初始化
  i                 number := 0;
  sum_result        number := 0;
  sub_str           number;
  rule_result_pass  varchar2(10) := '1';
  rule_result_error varchar2(10) := '0';
begin
  for i in 1 .. length(p_number) - 1 loop
    sub_str    := substr(p_number, i, 1);
    sum_result := sum_result + sub_str * my_tbl(i);
  end loop;
  sub_str := mod(sum_result, 11);
  select decode(sub_str, 0, 1, 1, 0, 2, 'X', 3, 9, 4, 8, 5, 7, 6, 6, 7, 5, 8, 4, 9, 3, 10, 2)
    into sum_result
    from dual;
  if substr(p_number, length(p_number), 1) <> sum_result then
    return rule_result_error;
  else
    return rule_result_pass;
  end if;
exception
  when others then
    return rule_result_error;
end;
/
