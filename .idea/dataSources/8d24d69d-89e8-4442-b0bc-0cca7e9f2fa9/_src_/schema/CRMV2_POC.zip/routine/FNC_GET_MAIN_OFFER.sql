CREATE function           fnc_get_main_offer(i_prod_inst_id in number)
  return varchar2 is
  v_result varchar2(500);
begin
  select c.prod_offer_name
    into v_result
    from offer_prod_inst_rel a, prod_offer_inst b, prod_offer c
   where a.prod_offer_inst_id = b.prod_offer_inst_id
     and b.prod_offer_id = c.prod_offer_id
     and c.offer_sub_type = 'T01'
     and a.prod_inst_id = i_prod_inst_id
     and rownum = 1;
  return(v_result);
exception
  when others then
    return(v_result);
end fnc_get_main_offer;
/
