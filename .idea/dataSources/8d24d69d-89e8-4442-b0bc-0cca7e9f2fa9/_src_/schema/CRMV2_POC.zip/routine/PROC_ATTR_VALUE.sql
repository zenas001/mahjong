CREATE procedure           proc_attr_value as
  v_new_value varchar2(2000) := '';
  v_cnt       int := 0;
  CURSOR c IS
    select * from  attr_value a
     where Upper(a.attr_value_name) like '%HTTP%';
begin
  FOR rec IN c LOOP
    -- dbms_output.put_line(rec.java_code);
    v_new_value := '';
    v_cnt       := 0;
    select count(1)
      into v_cnt
      from  attr_value@ycold  a
     where a.attr_value =rec.attr_value
     and  Upper(a.attr_value_name) like '%HTTP%';
    if v_cnt = 1 then
      select a.attr_value_name
        into v_new_value
        from attr_value@ycold a
       where a.attr_value = rec.attr_value
       and  Upper(a.attr_value_name) like '%HTTP%';
      update attr_value a
         set a.attr_value_name = v_new_value
       where a.attr_value = rec.attr_value
       and  Upper(a.attr_value_name) like '%HTTP%';

    end if;
  END LOOP;
  commit;
end;
/
