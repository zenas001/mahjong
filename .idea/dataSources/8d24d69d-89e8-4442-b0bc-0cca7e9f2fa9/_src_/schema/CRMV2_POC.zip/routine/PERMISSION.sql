CREATE procedure           permission(username_in   varchar,
                                       table_owner   varchar,
                                       table_name_in varchar,
                                       perm          number) is
  sql_text   varchar(1000);
  action     varchar(500);
  error_msg  varchar(1000);
  username   varchar(100);
  table_name varchar(100);
begin
  if perm in (1, 2, 3, 4, 5, 6, 7) then
    if perm = 1 then
      action := 'select,insert,update,delete';
    elsif perm = 2 then
      action := 'delete,insert,update';
    elsif perm = 3 then
      action := 'insert,update';
    elsif perm = 4 then
      action := 'update';
    elsif perm = 5 then
      action := 'delete';
    elsif perm = 6 then
      action := 'insert';
    elsif perm = 7 then
      action := 'select';
    end if;
    username   := lower(username_in);
    table_name := lower(table_name_in);
    insert into crmv2.PERMISSION_FOR_WH
      select username,
             action,
             table_owner,
             table_name,
             sysdate,
             sysdate,
             'n',
             null
        from dual;
     commit;
  end if;
exception
  when others then
    error_msg := to_char(sqlerrm);
    dbms_output.put_line(error_msg);
end;
/
