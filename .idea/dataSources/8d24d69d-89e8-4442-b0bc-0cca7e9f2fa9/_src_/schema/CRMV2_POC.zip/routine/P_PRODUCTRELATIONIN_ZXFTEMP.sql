CREATE PROCEDURE           p_productRelationIn_zxfTemp(str_msg out VARCHAR2) is
    v_cnt           number; --查询数
    v_pcount        number; --插入产品关联数
    v_ocount        number; --插入销售品约束数
    v_ccount        number; --插入关联约束数
    v_remark        varchar2(2000); --备注
    v_seqid         number;
    v_oldproductId  number; --旧的产品ID
    v_infoname      varchar2(200); --备注名称
    v_prodrelaId    number; --产品关联ID
    v_oldprodrelaId number; --旧的产品关联ID
    v_restrictId    number; --产品关联销售品约束Id
    v_oldrestrictId number; --旧的产品关联销售品约束Id
    v_allPcount     number; --产品关联总数据
    v_allOcount     number; --产品关联销售品约束总数据
    v_allCcount     number; --obj_rela_cfg总数据
  begin
    v_allPcount     := 0;
    v_allOcount     := 0;
    v_allCcount     := 0;
    v_oldprodrelaId := 0;
    v_oldproductId  := 0;
    v_oldrestrictId := 0;
    --查1.0销售品关联，落地到2.0后的产品应该有的关联数据,无线宽带数据卡的，对应到2.0的产品不是移动语音，而是无线宽带数据卡
    FOR ProdRela IN (select p1.prod_spec_id      cmr1_y_prod_spec_id,
                            p1.name              cmr1_y_prod_name,
                            m1.mdse_spec_id      crm1_y_mdse_spec_id,
                            m1.name              crm1_y_mdse_name,
                            p2.prod_spec_id      crm1_m_prod_spec_id,
                            p2.name              crm1_m_prod_name,
                            m2.mdse_spec_id      crm1_m_mdse_spec_id,
                            m2.name              crm1_m_mdse_name,
                            a.rela_type          crm1_rela_type,
                            m.old_rela_type_name crm1_rela_type_name,
                            --2.0源跟目标与1.0的源目标是相反的
                            pm2.product_id          crm2_y_product_id,
                            pm2.product_name        crm2_y_product_name,
                            mp2.id_v2               crm2_y_mdse_id,
                            mp2.name_v2             crm2_y_mdse_name,
                            opr2.offer_prod_rela_id crm2_y_offer_prod_rela_id,
                            pm1.product_id          crm2_m_product_id,
                            pm1.product_name        crm2_m_product_name,
                            mp1.id_v2               crm2_m_mdse_id,
                            mp1.name_v2             crm2_m_mdse_name,
                            opr1.offer_prod_rela_id crm2_m_offer_prod_rela_id,
                            m.new_rela_type         crm2_rela_type,
                            m.new_rela_type_name    crm2_rela_type_name,
                            a.cfg_area_id           crm1_cfg_area_id
                       from mdse_spec_rela@lk_crmv1 a,
                            mdse_spec@lk_crmv1      m1,
                            mdse_spec@lk_crmv1      m2,
                            crm2_mdse_rela_type_map m,
                            prod_spec@lk_crmv1      p1,
                            prod_spec@lk_crmv1      p2,
                            prod_map_zhengcl        pm1,
                            prod_map_zhengcl        pm2,
                            mdse_ys_lisy_new        mp1, ---取新的规格映射表（modify by lisy）
                            mdse_ys_lisy_new        mp2, ---取新的规格映射表（modify by lisy）
                            prod_offer              o1,
                            prod_offer              o2,
                            offer_prod_rel          opr1,
                            offer_prod_rel          opr2
                      where a.mdse_spec_ida = m1.mdse_spec_id
                        and a.mdse_spec_idb = m2.mdse_spec_id
                        and m1.prod_spec_id = p1.prod_spec_id
                        and m2.prod_spec_id = p2.prod_spec_id
                        and opr2.offer_prod_rela_id=800299341  --实名查询
                        and m1.type != '102'
                        and m2.type != '102'
                        and m1.state != '70X'
                        and m2.state != '70X'
                        and m1.mdse_spec_id not in
                            (select mdse_spec_id
                               from mdse_node@lk_crmv1
                              where catalog_id = 1)
                        and a.rela_type = m.old_rela_type
                        and m.new_rela_type != '无'
                        and m.sync != 'N'
                        and m.new_rela_type <> '109920' ----主副关系的不处理（特殊配置，以目前系统配置为准）add by lisy
                        and a.cfg_area_id in (1, 2) ---lisy说明：取省级跟福州本地的并集，个人认为有误，若2有配置数据，应只取2,2无数据才取1
                        and a.state = '70A'
                        and pm1.prod_spec_id = p1.prod_spec_id
                        and pm2.prod_spec_id = p2.prod_spec_id
                        and mp1.id_v1 = m1.mdse_spec_id
                        and mp1.id_v2 = o1.prod_offer_id
                        and mp2.id_v1 = m2.mdse_spec_id
                        and mp2.id_v2 = o2.prod_offer_id
                        and o1.offer_type in ('10', '11')
                        and o1.status_cd = '1000'
                        and o2.offer_type in ('10', '11')
                        and o2.status_cd = '1000'
                        and opr1.product_id = pm1.product_id
                        and opr1.prod_offer_id = o1.prod_offer_id
                        and opr1.status_cd = '1000'
                        and opr2.product_id = pm2.product_id
                        and opr2.prod_offer_id = o2.prod_offer_id
                        and opr2.status_cd = '1000'
                        and opr1.rule_type in ('10', '11', '12')
                        and opr2.rule_type in ('10', '11', '12')) LOOP
      ------------------------步骤1 插入产品关联数据。------------------------------------------------
      --产品关联导入数据日志记录
      if v_oldproductId = 0 or
         (v_oldproductId > 0 and
         v_oldproductId != ProdRela.Crm2_y_Product_Id) then
        if v_oldproductId > 0 and v_pcount > 0 then
          select p.product_name
            into v_infoname
            from product p
           where p.product_id = v_oldproductId;
          v_remark := '1.0销售品关联,导入源产品为"' || v_infoname || '"的产品关联表';
          dbms_output.put_line(v_remark);
          insert into CRM1_CFG_SYNC
            (ID,
             TABLE_NAME,
             OBJ_ID,
             OBJ_TYPE,
             SYNC_METHO,
             SYNC_DATE,
             SYNC_COUNT,
             REMARK)
          values
            (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
             'PRODUCT_RELATION',
             v_oldproductId,
             'PRODUCT_A_ID',
             'p_productRelationIn',
             SYSDATE,
             v_pcount,
             v_remark);
        end if;
        v_oldproductId := ProdRela.Crm2_y_Product_Id;
        v_pcount       := 0;
      end if;
      --判断是否有产品关系数据
      select count(*)
        into v_cnt
        from product_relation r
       where r.product_a_id = ProdRela.Crm2_y_Product_Id
         and r.product_z_id = ProdRela.Crm2_m_Product_Id
         and r.relation_type_cd = ProdRela.Crm2_Rela_Type
         and r.status_cd = '1000';
      if v_cnt = 0 then
        select SEQ_PRODUCT_REL_ID.nextval into v_seqid from dual;
        v_prodrelaId := v_seqid;
        --插入产品关联数据
        insert into PRODUCT_RELATION
          (PRODUCT_REL_ID,
           RELATION_TYPE_CD,
           PRODUCT_A_ID,
           PRODUCT_Z_ID,
           ROLE_CD,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           HOT_SPOT_NO,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           MIN_COUNT,
           MAX_COUNT,
           SYNC_CUST,
           EXIST_TYPE,
           REL_GROUP_ALIAS)
        values
          (v_prodrelaId,
           ProdRela.Crm2_Rela_Type,
           ProdRela.Crm2_y_Product_Id,
           ProdRela.Crm2_m_Product_Id,
           null,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           null,
           1,
           1,
           49822,
           49822,
           null,
           null,
           null,
           null,
           null);
        v_pcount    := v_pcount + 1;
        v_allPcount := v_allPcount + 1;
      elsif v_cnt = 1 then
      -- dbms_output.put_line('-------------------已存在产品关系-----------------------------');
        select r.product_rel_id
          into v_prodrelaId
          from product_relation r
         where r.product_a_id = ProdRela.Crm2_y_Product_Id
           and r.product_z_id = ProdRela.Crm2_m_Product_Id
           and r.relation_type_cd = ProdRela.Crm2_Rela_Type
           and r.status_cd = '1000';
      else
        v_prodrelaId := 0;
      end if;
      ------------------------步骤2 插入产品关联销售品数据。------------------------------------------------

      if v_prodrelaId != 0 then
        --产品关联销售品导入数据日志记录
       -- if v_oldprodrelaId = 0 or
          -- (v_oldprodrelaId > 0 and v_oldprodrelaId != v_prodrelaId) then
          if v_oldprodrelaId > 0 and v_ocount > 0 then
            select p1.product_name || ',' || p2.product_name || ',' ||
                   v.attr_value_name
              into v_infoname
              from product_relation r, product p1, product p2, attr_value v
             where v.attr_id = 7691
               and v.attr_value = r.relation_type_cd
               and r.product_rel_id = v_oldprodrelaId
               and r.product_a_id = p1.product_id
               and r.product_z_id = p2.product_id;
            v_remark := '1.0销售品关联,导入"' || v_infoname || '"产品关联销售品约束表';
            insert into CRM1_CFG_SYNC
              (ID,
               TABLE_NAME,
               OBJ_ID,
               OBJ_TYPE,
               SYNC_METHO,
               SYNC_DATE,
               SYNC_COUNT,
               REMARK)
            values
              (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
               'PROD_REL_RESTRICT_OFFER',
               v_oldprodrelaId,
               'PRODUCT_REL_ID',
               'p_productRelationIn',
               SYSDATE,
               v_ocount,
               v_remark);
          end if;
          v_oldprodrelaId := v_prodrelaId;
          v_ocount        := 0;
          --是否2.0已经有配置产品关系上限制销售品约束.没配才插入数据
          select count(*)
            into v_cnt
            from Prod_Rel_Restrict_Offer
           where product_rel_id = v_prodrelaId
             and rela_offer_id = ProdRela.crm2_m_mdse_id;
          if v_cnt = 0 then
            --插入PROD_REL_RESTRICT_OFFER
            select SEQ_PROD_REL_RESTRICT_OFFER_ID.nextval
              into v_seqid
              from dual;
            insert into PROD_REL_RESTRICT_OFFER
              (RESTRICT_ID,
               PRODUCT_REL_ID,
               RESTRICT_TYPE,
               RELA_OFFER_ID,
               STATUS_CD,
               STATUS_DATE,
               CREATE_DATE,
               UPDATE_DATE,
               AREA_ID,
               REGION_CD,
               UPDATE_STAFF,
               CREATE_STAFF)
            values
              (v_seqid,
               v_prodrelaId,
               '10',
               ProdRela.crm2_m_mdse_id,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               1,
               11,
               49822,
               49822);
            v_restrictId := v_seqid;
            v_allOcount  := v_allOcount + 1;
            v_ocount     := v_ocount + 1;
          elsif v_cnt = 1 then
            select RESTRICT_ID
              into v_restrictId
              from Prod_Rel_Restrict_Offer
             where product_rel_id = v_prodrelaId
               and rela_offer_id = ProdRela.crm2_m_mdse_id;
          else
            v_restrictId := 0;
          end if;
          ------------------------步骤3 插入关联表OBJ_REL_CFG数据。------------------------------------------------
          if v_restrictId > 0 then
            --关联表OBJ_REL_CFG导入数据日志记录
            if v_oldrestrictId = 0 or
               (v_oldrestrictId > 0 and v_oldrestrictId != v_restrictId) then
              if v_oldrestrictId > 0 and v_ccount > 0 then
                select p1.product_name || '"与"' || p2.product_name || '"的' ||
                       v.attr_value_name || '上,关联销售品"' ||
                       po.prod_offer_name
                  into v_infoname
                  from PROD_REL_RESTRICT_OFFER prro,
                       product_relation        pr,
                       product                 p1,
                       product                 p2,
                       prod_offer              po,
                       attr_value              v
                 where v.attr_id = 7691
                   and v.attr_value = pr.relation_type_cd
                   and prro.product_rel_id = pr.product_rel_id
                   and prro.rela_offer_id = po.prod_offer_id
                   and pr.product_a_id = p1.product_id
                   and pr.product_z_id = p2.product_id
                   and prro.restrict_id = v_oldrestrictId;
                v_remark := '1.0销售品关联,导入"' || v_infoname ||
                            '"关联表OBJ_REL_CFG.OBJ_CLASS_ID=102 AND CFG_CLASS_ID=64855';
                insert into CRM1_CFG_SYNC
                  (ID,
                   TABLE_NAME,
                   OBJ_ID,
                   OBJ_TYPE,
                   SYNC_METHO,
                   SYNC_DATE,
                   SYNC_COUNT,
                   REMARK)
                values
                  (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                   'OBJ_REL_CFG',
                   v_oldrestrictId,
                   'CFG_ID',
                   'p_productRelationIn',
                   SYSDATE,
                   v_ccount,
                   v_remark);
              end if;
              v_oldrestrictId := v_restrictId;
              v_ccount        := 0;
              --关联表OBJ_REL_CFG也要插入
              --先查询是否有直接配置在产品关系上的obj_rel_Cfg,有的话，以下可以都不用导入了
              select count(*)
                into v_cnt
                from OBJ_REL_CFG
               where (OBJ_CLASS_ID is null or OBJ_CLASS_ID = 0)
                 and OBJ_ID = 0
                 and CFG_CLASS_ID = 64855
                 and CFG_ID = v_restrictId;
              if v_cnt = 0 then
                select count(*)
                  into v_cnt
                  from OBJ_REL_CFG
                 where OBJ_CLASS_ID = '102'
                   and OBJ_ID = ProdRela.crm2_y_offer_prod_rela_id
                   and CFG_CLASS_ID = 64855
                   and CFG_ID = v_restrictId;
                --插入与2.0销售品直接关联的数据
                if v_cnt = 0 then
                  insert into OBJ_REL_CFG
                    (OBJ_REL_CFG_ID,
                     OBJ_CLASS_ID,
                     OBJ_ID,
                     CFG_CLASS_ID,
                     CFG_ID,
                     AREA_ID,
                     REGION_CD,
                     CREATE_DATE,
                     CREATE_STAFF,
                     STATUS_CD,
                     STATUS_DATE,
                     UPDATE_DATE,
                     UPDATE_STAFF)
                  values
                    (seq_obj_rel_cfg_id.nextval,
                     102,
                     ProdRela.crm2_y_offer_prod_rela_id,
                     64855,
                     v_restrictId,
                     1,
                     11,
                     sysdate,
                     49822,
                     '1000',
                     sysdate,
                     sysdate,
                     49822);
                  v_allCcount := v_allCcount + 1;
                  v_ccount    := v_ccount + 1;
                end if;
                --关联插入2.0A端销售品对应套餐销售品 与 产品关联销售品的obj_rel_cfg关系
                FOR AMdsePriceRela IN (select opr.offer_prod_rela_id,
                                              o.prod_offer_id,
                                              o.prod_offer_name
                                         from mdse_spec@lk_crmv1                   s,
                                              prefer_mdse_price_spec_rela@lk_crmv1 r,
                                              price_plan@lk_crmv1                  p,
                                              mdse_ys_lisy_new                     m, ---取新的规格映射表（modify by lisy）
                                              prod_offer                           o,
                                              offer_prod_rel                       opr
                                        where s.type = '101'
                                          and s.mdse_spec_id =
                                              r.mdse_spec_id
                                          and r.price_id = p.price_id
                                          and r.state = '70A'
                                          and r.cfg_area_id in (1, 2)
                                          and s.mdse_spec_id =
                                              ProdRela.Crm1_m_Mdse_Spec_Id
                                          and m.id_v1 = p.price_id
                                          and m.id_v2 = o.prod_offer_id
                                          and o.offer_type = '11'
                                          and opr.prod_offer_id =
                                              o.prod_offer_id
                                          and opr.product_id =
                                              ProdRela.Crm2_y_Product_Id
                                          and opr.status_cd = '1000'
                                          and opr.rule_type in
                                              ('10', '11', '12')
                                       union
                                       select opr.offer_prod_rela_id,
                                              o.prod_offer_id,
                                              o.prod_offer_name
                                         from prod_offer     o,
                                              offer_prod_rel opr
                                        where o.offer_busi_type = '1'
                                          and offer_sub_type='T01'
                                         -- and 610290109 =
                                              --ProdRela.Crm1_m_Mdse_Spec_Id
                                          and opr.prod_offer_id =
                                              o.prod_offer_id
                                          and opr.product_id =
                                              ProdRela.Crm2_y_Product_Id
                                          and opr.status_cd = '1000'
                                          and opr.rule_type in
                                              ('10', '11', '12') --如果是天翼销售品还要加e家和商务领航关联
                                       ) LOOP
                  select count(*)
                    into v_cnt
                    from OBJ_REL_CFG
                   where OBJ_CLASS_ID = '102'
                     and OBJ_ID = AMdsePriceRela.offer_prod_rela_id
                     and CFG_CLASS_ID = 64855
                     and CFG_ID = v_restrictId;
                  if v_cnt = 0 then
                    insert into OBJ_REL_CFG
                      (OBJ_REL_CFG_ID,
                       OBJ_CLASS_ID,
                       OBJ_ID,
                       CFG_CLASS_ID,
                       CFG_ID,
                       AREA_ID,
                       REGION_CD,
                       CREATE_DATE,
                       CREATE_STAFF,
                       STATUS_CD,
                       STATUS_DATE,
                       UPDATE_DATE,
                       UPDATE_STAFF)
                    values
                      (seq_obj_rel_cfg_id.nextval,
                       102,
                       AMdsePriceRela.offer_prod_rela_id,
                       64855,
                       v_restrictId,
                       1,
                       11,
                       sysdate,
                       49822,
                       '1000',
                       sysdate,
                       sysdate,
                       49822);
                    v_allCcount := v_allCcount + 1;
                    v_ccount    := v_ccount + 1;
                  end if;
                END LOOP;
              end if;
            end if;
          end if;
          ------------------------步骤4 插入产品关联套餐销售品数据。------------------------------------------------
          --除了直接对应的销售品要导入外,销售品对应的套餐销售品也要导入
          FOR MdsePriceRela IN (select o.prod_offer_id, o.prod_offer_name
                                /* s.mdse_spec_id,
                                                                                                     s.name mdse_name,
                                                                                                     p.price_id,
                                                                                                     p.name price_name*/
                                  from mdse_spec@lk_crmv1                   s,
                                       prefer_mdse_price_spec_rela@lk_crmv1 r,
                                       price_plan@lk_crmv1                  p,
                                       mdse_ys_lisy_new                     m, ----取新的规格映射表（modify by lisy）
                                       prod_offer                           o,
                                       offer_prod_rel                       opr
                                 where s.type = '101'
                                   and s.mdse_spec_id = r.mdse_spec_id
                                   and r.price_id = p.price_id
                                   and r.state = '70A'
                                   and r.cfg_area_id in (1, 2)
                                   and s.mdse_spec_id =
                                       ProdRela.Crm1_y_Mdse_Spec_Id
                                   and m.id_v1 = p.price_id
                                   and m.id_v2 = o.prod_offer_id
                                   and o.offer_type = '11'
                                   and opr.prod_offer_id = o.prod_offer_id
                                   and opr.product_id =
                                       ProdRela.Crm2_m_Product_Id
                                   and opr.status_cd = '1000'
                                   and opr.rule_type in ('10', '11', '12')
                                union
                                select o.prod_offer_id, o.prod_offer_name
                                  from prod_offer o
                                 where o.offer_busi_type = '1'
                                   and offer_sub_type='T01'
                                  -- and 610290109 =
                                    --   ProdRela.Crm1_y_Mdse_Spec_Id --如果是天翼销售品还要加e家和商务领航关联
                                ) LOOP
            --是否2.0已经有配置产品关系上限制销售品约束.没配才插入数据
            select count(*)
              into v_cnt
              from Prod_Rel_Restrict_Offer
             where product_rel_id = v_prodrelaId
               and rela_offer_id = MdsePriceRela.Prod_Offer_Id;
            if v_cnt = 0 then
              --插入PROD_REL_RESTRICT_OFFER
              select SEQ_PROD_REL_RESTRICT_OFFER_ID.nextval
                into v_seqid
                from dual;
              insert into PROD_REL_RESTRICT_OFFER
                (RESTRICT_ID,
                 PRODUCT_REL_ID,
                 RESTRICT_TYPE,
                 RELA_OFFER_ID,
                 STATUS_CD,
                 STATUS_DATE,
                 CREATE_DATE,
                 UPDATE_DATE,
                 AREA_ID,
                 REGION_CD,
                 UPDATE_STAFF,
                 CREATE_STAFF)
              values
                (v_seqid,
                 v_prodrelaId,
                 '10',
                 MdsePriceRela.Prod_Offer_Id,
                 '1000',
                 sysdate,
                 sysdate,
                 sysdate,
                 1,
                 11,
                 49822,
                 49822);
              v_restrictId := v_seqid;
              v_allOcount  := v_allOcount + 1;
              v_ocount     := v_ocount + 1;
            elsif v_cnt = 1 then
              select RESTRICT_ID
                into v_restrictId
                from Prod_Rel_Restrict_Offer
               where product_rel_id = v_prodrelaId
                 and rela_offer_id = MdsePriceRela.Prod_Offer_Id;
            else
              v_restrictId := 0;
            end if;
            ------------------------步骤5 插入关联表OBJ_REL_CFG数据。------------------------------------------------
            if v_restrictId > 0 then
              --关联表OBJ_REL_CFG导入数据日志记录
              if v_oldrestrictId = 0 or
                 (v_oldrestrictId > 0 and v_oldrestrictId != v_restrictId) then
                if v_oldrestrictId > 0 and v_ccount > 0 then
                  select p1.product_name || '"与"' || p2.product_name || '"的' ||
                         v.attr_value_name || '上,关联销售品"' ||
                         po.prod_offer_name
                    into v_infoname
                    from PROD_REL_RESTRICT_OFFER prro,
                         product_relation        pr,
                         product                 p1,
                         product                 p2,
                         prod_offer              po,
                         attr_value              v
                   where v.attr_id = 7691
                     and v.attr_value = pr.relation_type_cd
                     and prro.product_rel_id = pr.product_rel_id
                     and prro.rela_offer_id = po.prod_offer_id
                     and pr.product_a_id = p1.product_id
                     and pr.product_z_id = p2.product_id
                     and prro.restrict_id = v_oldrestrictId;
                  v_remark := '1.0销售品关联,导入"' || v_infoname ||
                              '"关联表OBJ_REL_CFG.OBJ_CLASS_ID=102 AND CFG_CLASS_ID=64855';
                  insert into CRM1_CFG_SYNC
                    (ID,
                     TABLE_NAME,
                     OBJ_ID,
                     OBJ_TYPE,
                     SYNC_METHO,
                     SYNC_DATE,
                     SYNC_COUNT,
                     REMARK)
                  values
                    (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
                     'OBJ_REL_CFG',
                     v_oldrestrictId,
                     'CFG_ID',
                     'p_productRelationIn',
                     SYSDATE,
                     v_ccount,
                     v_remark);
                end if;
                v_oldrestrictId := v_restrictId;
                v_ccount        := 0;

                --关联表OBJ_REL_CFG也要插入
                --先查询是否有直接配置在产品关系上的obj_rel_Cfg,有的话，以下可以都不用导入了
                select count(*)
                  into v_cnt
                  from OBJ_REL_CFG
                 where (OBJ_CLASS_ID is null or OBJ_CLASS_ID = 0)
                   and OBJ_ID = 0
                   and CFG_CLASS_ID = 64855
                   and CFG_ID = v_restrictId;
                if v_cnt = 0 then
                  select count(*)
                    into v_cnt
                    from OBJ_REL_CFG
                   where OBJ_CLASS_ID = '102'
                     and OBJ_ID = ProdRela.crm2_y_offer_prod_rela_id
                     and CFG_CLASS_ID = 64855
                     and CFG_ID = v_restrictId;
                  --插入与2.0套餐销售品关联的数据
                  if v_cnt = 0 then
                    insert into OBJ_REL_CFG
                      (OBJ_REL_CFG_ID,
                       OBJ_CLASS_ID,
                       OBJ_ID,
                       CFG_CLASS_ID,
                       CFG_ID,
                       AREA_ID,
                       REGION_CD,
                       CREATE_DATE,
                       CREATE_STAFF,
                       STATUS_CD,
                       STATUS_DATE,
                       UPDATE_DATE,
                       UPDATE_STAFF)
                    values
                      (seq_obj_rel_cfg_id.nextval,
                       102,
                       ProdRela.crm2_y_offer_prod_rela_id,
                       64855,
                       v_restrictId,
                       1,
                       11,
                       sysdate,
                       49822,
                       '1000',
                       sysdate,
                       sysdate,
                       49822);
                    v_allCcount := v_allCcount + 1;
                    v_ccount    := v_ccount + 1;
                  end if;
                  --关联插入2.0A端销售品对应套餐销售品 与 产品关联销售品的obj_rel_cfg关系
                  FOR AMdsePriceRela IN (select opr.offer_prod_rela_id,
                                                o.prod_offer_id,
                                                o.prod_offer_name
                                           from mdse_spec@lk_crmv1                   s,
                                                prefer_mdse_price_spec_rela@lk_crmv1 r,
                                                price_plan@lk_crmv1                  p,
                                                mdse_ys_lisy_new                     m, ----取新的规格映射表（modify by lisy）
                                                prod_offer                           o,
                                                offer_prod_rel                       opr
                                          where s.type = '101'
                                            and s.mdse_spec_id =
                                                r.mdse_spec_id
                                            and r.price_id = p.price_id
                                            and r.state = '70A'
                                            and r.cfg_area_id in (1, 2)
                                            and s.mdse_spec_id =
                                                ProdRela.Crm1_m_Mdse_Spec_Id
                                            and m.id_v1 = p.price_id
                                            and m.id_v2 = o.prod_offer_id
                                            and o.offer_type = '11'
                                            and opr.prod_offer_id =
                                                o.prod_offer_id
                                            and opr.product_id =
                                                ProdRela.Crm2_y_Product_Id
                                            and opr.status_cd = '1000'
                                            and opr.rule_type in
                                                ('10', '11', '12')
                                         union
                                         select opr.offer_prod_rela_id,
                                                o.prod_offer_id,
                                                o.prod_offer_name
                                           from prod_offer     o,
                                                offer_prod_rel opr
                                          where o.offer_busi_type = '1'
                                            and offer_sub_type='T01'
                                           -- and 610290109 =
                                               -- ProdRela.Crm1_m_Mdse_Spec_Id
                                            and opr.prod_offer_id =
                                                o.prod_offer_id
                                            and opr.product_id =
                                                ProdRela.Crm2_y_Product_Id
                                            and opr.status_cd = '1000'
                                            and opr.rule_type in
                                                ('10', '11', '12') --如果是天翼销售品还要加e家和商务领航关联
                                         ) LOOP
                    select count(*)
                      into v_cnt
                      from OBJ_REL_CFG
                     where OBJ_CLASS_ID = '102'
                       and OBJ_ID = AMdsePriceRela.offer_prod_rela_id
                       and CFG_CLASS_ID = 64855
                       and CFG_ID = v_restrictId;
                    --插入与2.0销售品直接关联的数据
                    if v_cnt = 0 then
                      insert into OBJ_REL_CFG
                        (OBJ_REL_CFG_ID,
                         OBJ_CLASS_ID,
                         OBJ_ID,
                         CFG_CLASS_ID,
                         CFG_ID,
                         AREA_ID,
                         REGION_CD,
                         CREATE_DATE,
                         CREATE_STAFF,
                         STATUS_CD,
                         STATUS_DATE,
                         UPDATE_DATE,
                         UPDATE_STAFF)
                      values
                        (seq_obj_rel_cfg_id.nextval,
                         102,
                         AMdsePriceRela.offer_prod_rela_id,
                         64855,
                         v_restrictId,
                         1,
                         11,
                         sysdate,
                         49822,
                         '1000',
                         sysdate,
                         sysdate,
                         49822);
                      v_allCcount := v_allCcount + 1;
                      v_ccount    := v_ccount + 1;
                    end if;
                  END LOOP;
                end if;
              end if;
            end if;
          END LOOP;
        end if;
      --end if;
    END LOOP;
    --补充日志，以上写法会造成最后一条日志没记录
    if v_oldproductId > 0 and v_pcount > 0 then
      select p.product_name
        into v_infoname
        from product p
       where p.product_id = v_oldproductId;
      v_remark := '1.0销售品关联,导入源产品为"' || v_infoname || '"的产品关联表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PRODUCT_RELATION',
         v_oldproductId,
         'PRODUCT_A_ID',
         'p_productRelationIn',
         SYSDATE,
         v_pcount,
         v_remark);
    end if;

    if v_oldprodrelaId > 0 and v_ocount > 0 then
      select p1.product_name || ',' || p2.product_name || ',' ||
             v.attr_value_name
        into v_infoname
        from product_relation r, product p1, product p2, attr_value v
       where v.attr_id = 7691
         and v.attr_value = r.relation_type_cd
         and r.product_rel_id = v_oldprodrelaId
         and r.product_a_id = p1.product_id
         and r.product_z_id = p2.product_id;
      v_remark := '1.0销售品关联,导入"' || v_infoname || '"产品关联销售品约束表';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'PROD_REL_RESTRICT_OFFER',
         v_oldprodrelaId,
         'PRODUCT_REL_ID',
         'p_productRelationIn',
         SYSDATE,
         v_ocount,
         v_remark);
    end if;

    if v_oldrestrictId > 0 and v_ccount > 0 then
      select p1.product_name || '"与"' || p2.product_name || '"的' ||
             v.attr_value_name || '上,关联销售品"' || po.prod_offer_name
        into v_infoname
        from PROD_REL_RESTRICT_OFFER prro,
             product_relation        pr,
             product                 p1,
             product                 p2,
             prod_offer              po,
             attr_value              v
       where v.attr_id = 7691
         and v.attr_value = pr.relation_type_cd
         and prro.product_rel_id = pr.product_rel_id
         and prro.rela_offer_id = po.prod_offer_id
         and pr.product_a_id = p1.product_id
         and pr.product_z_id = p2.product_id
         and prro.restrict_id = v_oldrestrictId;
      v_remark := '1.0销售品关联,导入"' || v_infoname ||
                  '"关联表OBJ_REL_CFG.OBJ_CLASS_ID=102 AND CFG_CLASS_ID=64855';
      insert into CRM1_CFG_SYNC
        (ID,
         TABLE_NAME,
         OBJ_ID,
         OBJ_TYPE,
         SYNC_METHO,
         SYNC_DATE,
         SYNC_COUNT,
         REMARK)
      values
        (SEQ_CRM1_CFG_SYNC_ID.NEXTVAL,
         'OBJ_REL_CFG',
         v_oldrestrictId,
         'CFG_ID',
         'p_productRelationIn',
         SYSDATE,
         v_ccount,
         v_remark);
    end if;
    str_msg := '导入PRODUCT_RELATION"' || to_char(v_allPcount) ||
               '"条数据;导入PROD_REL_RESTRICT_OFFER"' || to_char(v_allOcount) ||
               '"条数据;导入OBJ_REL_CFG"' || to_char(v_allCcount) || '"条数据';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := 'p_productRelationIn:' || sqlerrm;
  end;
/
