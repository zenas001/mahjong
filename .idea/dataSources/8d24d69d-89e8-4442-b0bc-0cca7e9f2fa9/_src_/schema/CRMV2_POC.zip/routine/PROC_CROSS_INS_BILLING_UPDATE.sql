CREATE procedure           proc_cross_ins_billing_update(table_name      in varchar2, --客户编码
                                                          primary_key     in number, --实例对象ID
                                                          pri_column_name in varchar2 --字段名称
                                                          ) is
  /**
   功能说明：crm2.0跨本地网业务，计费批量接口信息
   author：luxb
   创建时间：2012-4-14
  **/
begin
  insert into crm.ins_billing_update@lk_tocrm1_cross
    (INS_ID, TABLE_NAME, KEY_ID, STATE, COLUMN_NAME, MODI_DATE, DEAL_NUM)
  values
    (crm.ins_billing_update_id_seq.nextval@lk_tocrm1_cross,
     table_name,
     primary_key,
     '10A',
     pri_column_name,
     sysdate,
     0);
end;
/
