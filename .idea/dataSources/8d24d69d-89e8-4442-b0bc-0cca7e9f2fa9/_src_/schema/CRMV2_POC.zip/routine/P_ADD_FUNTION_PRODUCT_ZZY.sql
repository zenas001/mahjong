CREATE PROCEDURE           p_add_funtion_product_zzy(i_prod_inst_id IN NUMBER,--接入类产品实例id
                                                  i_product_id   IN NUMBER, --功能类产品规格
                                                  i_remark       IN VARCHAR2,
                                                  i_mod_man      IN VARCHAR2,
                                                  o_prod_inst_id OUT NUMBER,
                                                  o_msg          OUT VARCHAR2) IS
  CURSOR cur IS
    SELECT a.*,
           d.product_rel_id,
           d.product_z_id,
           c.offer_prod_rela_id,
           c.prod_offer_id
      FROM crmv2.prod_inst        a,
           crmv2.prod_offer       b,
           crmv2.offer_prod_rel   c,
           crmv2.product_relation d
     WHERE a.product_id = d.product_a_id
       AND d.product_z_id = c.product_id
       AND b.prod_offer_id = c.prod_offer_id
       AND b.offer_sub_type = 'T02'
       AND c.product_id = i_product_id --'800000576'
       AND a.prod_inst_id = i_prod_inst_id; --'13395006435';
  v_prod_inst_id           NUMBER(12);
  v_prod_inst_rel_id       NUMBER(12);
  v_prod_offer_inst_id     NUMBER(12);
  v_offer_prod_inst_rel_id NUMBER(12);
  v_cnt                    NUMBER(5);
BEGIN
  FOR rec IN cur LOOP
    BEGIN
      SELECT COUNT(1)
        INTO v_cnt
        FROM crmv2.prod_inst a, crmv2.prod_inst_rel b, crmv2.prod_inst c
       WHERE a.prod_inst_id = i_prod_inst_id
         AND a.prod_inst_id = b.prod_inst_a_id
         AND b.prod_inst_z_id = c.prod_inst_id
         AND c.product_id = i_product_id;

      IF v_cnt = 0 THEN

        SELECT crmv2.seq_prod_inst_id.nextval
          INTO v_prod_inst_id
          FROM dual;
        INSERT INTO crmv2.prod_inst
          SELECT v_prod_inst_id prod_inst_id,
                 i_product_id product_id,
                 prod_inst_id acc_prod_inst_id,
                 '' address_id,
                 owner_cust_id,
                 '' payment_mode_cd,
                 '' product_password,
                 '' important_level,
                 area_code,
                 '' acc_nbr,
                 '' exch_id,
                 common_region_id,
                 i_remark remark,
                 '' pay_cycle,
                 a.status_date begin_rent_time,
                 stop_rent_time,
                 finish_time,
                 stop_status,
                 '100000' status_cd,
                 create_date,
                 status_date,
                 update_date,
                 '' proc_serial,
                 use_cust_id,
                 '' ext_prod_inst_id,
                 '' address_desc,
                 area_id,
                 '' update_staff,
                 '' create_staff,
                 '' rec_update_date,
                 '' account,
                 version,
                 '' community_id,'','',''
            FROM crmv2.prod_inst a
           WHERE a.prod_inst_id = rec.prod_inst_id;

        SELECT crmv2.seq_prod_inst_rel_id.nextval
          INTO v_prod_inst_rel_id
          FROM dual;
        INSERT INTO crmv2.prod_inst_rel
          SELECT v_prod_inst_rel_id prod_inst_rel_id,
                 prod_inst_id prod_inst_a_id,
                 v_prod_inst_id prod_inst_z_id,
                 '100600' relation_type_cd,
                 '' prod_inst_rel_role_id,
                 '' role_cd,
                 '' eff_date,
                 to_date('2199-1-1', 'yyyy-mm-dd') vexp_date,
                 create_date,
                 '1000' status_cd,
                 status_date,
                 update_date,
                 '' proc_serial,
                 rec.product_rel_id product_rel_id,
                 area_id,
                 a.common_region_id region_cd,
                 '' update_staff,
                 '' create_staff,
                 '' rec_update_date
            FROM crmv2.prod_inst a
           WHERE a.prod_inst_id = rec.prod_inst_id;

        SELECT crmv2.seq_prod_offer_inst_id.nextval
          INTO v_prod_offer_inst_id
          FROM dual;
        INSERT INTO crmv2.prod_offer_inst
          (prod_offer_inst_id,
           prod_offer_id,
           cust_id,
           channel_id,
           create_date,
           status_cd,
           status_date,
           eff_date,
           exp_date,
           region,
           update_date,
           proc_serial,
           ext_prod_offer_inst_id,
           area_id,
           region_cd,
           update_staff,
           create_staff,
           trial_eff_date,
           trial_exp_date,
           rec_update_date,
           service_nbr,
           version,
           end_auto)
          SELECT v_prod_offer_inst_id prod_offer_inst_id,
                 rec.prod_offer_id prod_offer_id,
                 a.owner_cust_id cust_id,
                 '' channel_id,
                 create_date,
                 '1000' status_cd,
                 status_date,
                 a.create_date eff_date,
                 to_date('2199-1-1', 'yyyy-mm-dd') exp_date,
                 a.common_region_id region,
                 update_date,
                 '' proc_serial,
                 '' ext_prod_offer_inst_id,
                 area_id,
                 a.common_region_id region_cd,
                 '' update_staff,
                 '' create_staff,
                 '' trial_eff_date,
                 '' trial_exp_date,
                 '' rec_update_date,
                 '' service_nbr,
                 version,
                 '' end_auto
            FROM crmv2.prod_inst a
           WHERE a.prod_inst_id = rec.prod_inst_id;

        SELECT crmv2.seq_offer_prod_inst_rel_id.nextval
          INTO v_offer_prod_inst_rel_id
          FROM dual;
        INSERT INTO crmv2.offer_prod_inst_rel
          SELECT v_offer_prod_inst_rel_id offer_prod_inst_rel_id,
                 v_prod_inst_id prod_inst_id,
                 v_prod_offer_inst_id prod_offer_inst_id,
                 '' role_cd,
                 '' offer_prod_inst_rel_role_id,
                 '1000' status_cd,
                 status_date,
                 create_date,
                 a.create_date eff_date,
                 to_date('2199-1-1', 'yyyy-mm-dd') exp_date,
                 update_date,
                 '' proc_serial,
                 rec.offer_prod_rela_id offer_prod_rel_id,
                 area_id,
                 a.common_region_id region_cd,
                 '' update_staff,
                 '' create_staff,
                 '' rec_update_date,
                 '' ext_flag
            FROM crmv2.prod_inst a
           WHERE a.prod_inst_id = rec.prod_inst_id;
        o_msg := 'OK';

      END IF;
      o_prod_inst_id:= v_prod_inst_id;
    EXCEPTION

      WHEN OTHERS THEN
        o_msg := SQLERRM;

    END;

  END LOOP;
END ;
/
