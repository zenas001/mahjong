CREATE procedure           NEW_INS_ODS_UPDATE(i_table_name  in varchar2,
                                               i_column_name in varchar2,
                                               i_key_id      in number,
                                               i_modi_man    in varchar2) is
  --o_result        varchar2(200);
  v_boolean       boolean := true;
  v_i_table_name  itsc_crmv2.INTF_INS_BILLING_UPDATE.table_name%type;
  v_i_column_name itsc_crmv2.INTF_INS_BILLING_UPDATE.column_name%type;
  v_num           number(10) := 0;
  v_num2          number(10) := 0;
  v_int3          number(10) := 0;
  v_sql           varchar2(1000);
begin
  ------去空格转大写
  v_i_table_name  := upper(trim(i_table_name));
  v_i_column_name := upper(trim(i_column_name));

  -----判断表名和主键名是否在CRM表
  select count(*)
    into v_num
    from all_tables
   where owner = 'CRMV2'
     and table_name = v_i_table_name;
  select count(*)
    into v_num2
    from all_cons_columns
   where owner = 'CRMV2'
     and (constraint_name like 'PK_%' or constraint_name like 'SYS_%')
     and table_name = v_i_table_name;

  -------------------------
  if (v_num <> 0 and v_num2 <> 0)  then

    v_sql := ' select count(1) from CRMV2.' || v_i_table_name || ' where ' ||
             i_column_name || ' = ''' || i_key_id || '''';

    execute immediate v_sql
      into v_int3;

    if v_int3 > 0 then
      v_boolean := false;
    end if;
  else
    v_boolean := false;
    if v_num = 0 then
      raise_application_error(-20203,
                              '送的表名  "' || i_table_name || '"出错,请检查');
    elsif v_num2 = 0 then
      raise_application_error(-20203,
                              '送的主键名  "' || i_column_name || '"出错,请检查');
    else
      raise_application_error(-20203,
                              'CRM表中可能还有数据,请确认后再物理删除送ODS');
    end if;

  end if;
  if v_boolean then

    insert into crmv2.ins_ods_update
    values
      (itsc_crmv2.ins_ods_update_id_seq.nextval,
       v_i_table_name,
       v_i_column_name,
       i_key_id,
       'DELETE',
       sysdate,
       i_modi_man);
    commit;
  else
    /*    o_result := '错误请检查';
    dbms_output.put_line(o_result);*/
    null;
  end if;

end NEW_INS_ODS_UPDATE;
/
