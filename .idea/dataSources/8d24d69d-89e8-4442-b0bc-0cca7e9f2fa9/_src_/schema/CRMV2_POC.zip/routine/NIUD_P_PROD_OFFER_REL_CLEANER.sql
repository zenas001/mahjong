CREATE procedure           niud_p_prod_offer_rel_cleaner(o_msg out varchar2) is

  /****
    功能：
        确认、清理prod_offer_rel的重复记录
                by niud, 120717
  ****/

  v_tmp    number(3);

  cursor cur is
    select r.offer_a_id,
           po.area_id,
           r.offer_z_id,
           r.relation_type_cd,
           count(*)
      from prod_offer_rel r, prod_offer po
     where r.offer_a_id = po.prod_offer_id
       and r.status_cd like '10%'
       and role_cd is null
     group by offer_a_id, po.area_id, offer_z_id, relation_type_cd
    having count(*) > 1;

begin

  for rec in cur loop

    select count(*)
      into v_tmp
      from prod_offer_rel
     where offer_a_id = rec.offer_a_id
       and offer_z_id = rec.offer_z_id
       and relation_type_cd = rec.relation_type_cd
       and status_cd like '10%'
       and role_cd is null
       and area_id = 1;

    if v_tmp > 0 then
      update prod_offer_rel
         set status_cd = '1100',
             remark    = '存在省级记录，又存在本地记录，删除本地记录, by niud_p_prod_offer_rel_cleaner; ' ||
                         remark
       where offer_a_id = rec.offer_a_id
         and offer_z_id = rec.offer_z_id
         and relation_type_cd = rec.relation_type_cd
         and status_cd like '10%'
         and role_cd is null
         and area_id <> 1;
      if v_tmp > 1 then
        update prod_offer_rel
           set remark    = '存在重复省级记录, 需确认，by niud_p_prod_offer_rel_cleaner; ' ||
                           remark
         where offer_a_id = rec.offer_a_id
           and offer_z_id = rec.offer_z_id
           and relation_type_cd = rec.relation_type_cd
           and status_cd like '10%'
           and role_cd is null
           and area_id = 1;
      end if;
    else
      update prod_offer_rel
         set remark    = '无省级记录，存在多条本地记录，需确认, by niud_p_prod_offer_rel_cleaner; ' ||
                         remark
       where offer_a_id = rec.offer_a_id
         and offer_z_id = rec.offer_z_id
         and relation_type_cd = rec.relation_type_cd
         and status_cd like '10%'
         and role_cd is null;
    end if;
  end loop;

  o_msg := '执行成功！';

end;
/
