CREATE procedure           PROC_GROUP_OFFER_BACKUP(I_PRODOFFER_CODE IN VARCHAR2,
                                              O_MSG           OUT VARCHAR2,
                                              O_RESULT           OUT VARCHAR2) as

cursor tempsor is
       select * from prod_offer p where p.prod_offer_id IN(I_PRODOFFER_CODE); -- 修改查询条件即可
v_request_form_id number(20);
v_request_template_id number(20);
v_area_id number(20);
v_form_type_cd request_form.type_cd%type;
--v_staff_code varchar(20);
v_request_form_title request_form.request_form_topic%type;
begin
--需要更改的内容
--v_staff_code := 'fjniud'; -- 创建人账号
--v_request_form_title := '海南省内销售品报备配置申请单2222'; -- 需求单标题
v_area_id := '1'; -- 区域ID 46海南，95宁夏，1福建
v_form_type_cd := '001_OFFER';-- 需求单类型：001_OFFER 福建销售品需求单， HN_OFFER 海南销售品需求单,NX_OFFER 宁夏销售品需求单
O_RESULT   := 'FALSE';

--select su.staff_id into v_staff_id from system_user su where su.staff_code = v_staff_code and su.status_cd = '1000';


for r in tempsor loop
  v_request_form_title:= r.prod_offer_name;
  select seq_request_form_id.nextval into v_request_form_id from dual;
      insert into request_form (REQUEST_FORM_ID, REQUEST_FORM_TOPIC, REQUEST_FORM_DESC, STATUS_CD, CREATE_DATE, TYPE_CD, REQUEST_DEPARTMENT, DUTY_UNIT, PHONE, E_MAIL, STATUS_DATE, UPDATE_DATE, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, CUST_ORDER_ID, PRIORITY, IMPORTANCE, FINISH_DATE, ITSM_CODE, RELEASE_DATE, JOB_FLAG, SORT_CD, CUST_ORDER_ID_HIS, BATCH_NO, ACTION_TYPE, GROUP_INST_ID, CONT_NAME, CONT_TELE, FLOW_VERSION, ORDER_VERSION, DEAL_STAFF)
values (v_request_form_id, v_request_form_title, v_request_form_title, '12', sysdate, v_form_type_cd, '100', '', '', '', sysdate, sysdate, v_area_id, v_area_id, r.CREATE_STAFF, r.CREATE_STAFF, null, '', '', null, '', null, '', '', null, '', '', null, '', '', 'flow1', 'order2', r.CREATE_STAFF);
    --delete ppm_prod_offer_attr p WHERE p.prod_offer_id = r.prod_offer_id;
    --delete ppm_catalog_item_element p WHERE p.prod_offer_id = r.prod_offer_id;
    --delete ppm_prod_offer p WHERE p.prod_offer_id = r.prod_offer_id;
    -- 复制基本信息等。
      copy_offer_from_it(r.prod_offer_id,v_area_id);
      insert into request_inst (REQUEST_TEMPLATE_INST_ID, PRODUCT_ID, PROD_OFFER_ID, PARENT_TEMPLATE_INST_ID, REQUEST_TEMPLATE_ID, REQUEST_FORM_ID, REQUEST_TEMPLATE_INST_NAME, MANAGE_GRADE, STATUS_CD, VERSION_NO, REQUEST_TEMPLATE_INST_DESC, CREATE_DATE, TYPE_CD, CONTENT_IDENTIFY_ID, STATUS_DATE, UPDATE_DATE, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, SORT_CD, DATA_FULL_FLAG, GROUP_INST_ID, ORDER_ID, OBJECT_ID, RESULT_FLAG, OBJECT_CD, CUST_ORDER_ID, CUST_ORDER_ID_HIS, OBJECT_NAME, RESULT_CD)
values (seq_request_inst_id.nextval, null, r.prod_offer_id, null, 84, v_request_form_id, '', '', '1000', '', '', sysdate, '001_KX', null, sysdate, sysdate, v_area_id, v_area_id, r.CREATE_STAFF, r.CREATE_STAFF, 'OFFER_ADD', 'true', null, '', null, '', '', null, null, '', '1');
end loop;

-- 基础销售品
SELECT  t.request_template_id into v_request_template_id FROM request_template t where t.template_sort_cd = '001' and t.is_default = 'Y' and t.template_type_cd = '1002_JC';
update request_inst r
   set r.request_template_id = v_request_template_id,r.type_cd = '001_XSP'
 where exists (SELECT *
          FROM ppm_prod_offer p
         where p.prod_offer_id = r.prod_offer_id
           and p.offer_type = '10');

-- 套餐销售品
SELECT  t.request_template_id into v_request_template_id FROM request_template t where t.template_sort_cd = '001' and t.is_default = 'Y' and t.template_type_cd = '1002';
update request_inst r
   set r.request_template_id = v_request_template_id,r.type_cd = '001_XSP'
 where exists (SELECT *
          FROM ppm_prod_offer p
         where p.prod_offer_id = r.prod_offer_id
           and p.offer_type = '11');


-- 可选包
SELECT  t.request_template_id into v_request_template_id FROM request_template t where t.template_sort_cd = '001' and t.is_default = 'Y' and t.template_type_cd = '1003';
update request_inst r
   set r.request_template_id = v_request_template_id,r.type_cd = '001_KX'
 where exists (SELECT *
          FROM ppm_prod_offer p
         where p.prod_offer_id = r.prod_offer_id
           and p.offer_type = '12');

-- 促销
SELECT  t.request_template_id into v_request_template_id FROM request_template t where t.template_sort_cd = '001' and t.is_default = 'Y' and t.template_type_cd = '1004';
update request_inst r
   set r.request_template_id = v_request_template_id,r.type_cd = '001_CX'
 where exists (SELECT *
          FROM ppm_prod_offer p
         where p.prod_offer_id = r.prod_offer_id
           and p.offer_type = '13');
    O_MSG:= '执行过程成功!';
    O_RESULT := 'TRUE';
    COMMIT;
    exception
    when others then
      O_RESULT := 'FALSE';
      O_MSG := sqlerrm;
      rollback;
end PROC_GROUP_OFFER_BACKUP;
/
