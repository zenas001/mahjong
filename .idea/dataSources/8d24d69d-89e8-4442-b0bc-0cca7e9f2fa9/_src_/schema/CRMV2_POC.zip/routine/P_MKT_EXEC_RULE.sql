CREATE PROCEDURE           p_mkt_exec_rule(i_cust_id IN NUMBER, channel_id IN NUMBER, o_result OUT NUMBER) IS
  i NUMBER := 0;

BEGIN
  IF i_cust_id IS NOT NULL THEN
    -- 1. 判断是否VIP客户
    SELECT COUNT(1)
    INTO   i
    FROM   cust a,club_member b
    WHERE  a.party_id=b.party_id and a.cust_id = i_cust_id ;

    --2. 表示客户为非VIP客户
    IF i <= 0 THEN
      SELECT COUNT(1) INTO i FROM dual;
    END IF;
    o_result := 0; --0成功，其余失败

    -- 2. 获取渠道定义


    --如果不存在,表示客户为非VIP客户
    IF i <= 0 THEN
      SELECT COUNT(1) INTO i FROM dual;
    END IF;
    o_result := 0; --0成功，其余失败
  ELSE
    o_result := -2; ---2 数据为空
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    o_result := -1;
END p_mkt_exec_rule;
/
