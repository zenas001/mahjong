CREATE PROCEDURE           Q_T01_PROD_TRANS(i_order_item_id       IN NUMBER,
                                             I_ACTION_TYPE         in VARCHAR2) IS
 -- i_order_item_id NUMBER;
  V_CUST_ORDER_ID       NUMBER;
  V_PROD_INST_ID        NUMBER;
  C_ACTION_ADD CONSTANT VARCHAR2(5) := 'ADD';
  C_ACTION_MOD CONSTANT VARCHAR2(5) := 'MOD';
  C_ACTION_DEL CONSTANT VARCHAR2(5) := 'DEL';
BEGIN

  -- T01  SELECT * FROM ORDER_ITEM_HIS WHERE CLASS_ID=4 AND ENTT_SPEC_TYPE='AP';
  -- T02  SELECT * FROM ORDER_ITEM_HIS WHERE CLASS_ID=4 AND ENTT_SPEC_TYPE is NULL;

 -- i_order_item_id := SEQ_AUTOTEST_MEMBER_ID.NEXTVAL;
 -- O_AUTOTEST_MEMBER_SEQ := i_order_item_id;
  select cust_order_id
    INTO V_CUST_ORDER_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  select order_item_obj_id
    INTO V_PROD_INST_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  IF I_ACTION_TYPE = C_ACTION_ADD THEN
    --ADD
    INSERT INTO AUTOTEST_MEMBER
      (AUTOTEST_MEMBER_ID,
       CUST_ORDER_ID,
       EXT_PROD_ID,
       PROD_INST_ID,
       ACC_NBR,
       ROLE_CD,
       LAN_ID,
       VIRTUAL_PROD_INST_ID,
       ADDRESS_ID,
       ADDRESS_DESC,
       EXCH_ID,
       PAYMENT_MODE_CD,
       OWNER_CUST_ID,
       NEW_PRODUCT_ID,
       IS_EXIST,
       ACTION,
       CREATE_DATE)
      SELECT i_order_item_id AUTOTEST_MEMBER_ID,
             V_CUST_ORDER_ID CUST_ORDER_ID,
             (SELECT EXT_PROD_ID
                FROM PRODUCT P
               WHERE P.PRODUCT_ID = A.PRODUCT_ID) EXT_PROD_ID,
             A.PROD_INST_ID,
             A.ACC_NBR,
             NULL ROLE_CD,
             (SELECT AC.AREA_CODE
                FROM CRMV2.AREA_CODE AC
               WHERE AC.AREA_CODE_ID = A.AREA_ID) LAN_ID,
             NULL VIRTUAL_PROD_INST_ID,
             A.ADDRESS_ID,
             A.ADDRESS_DESC,
             A.EXCH_ID,
             A.PAYMENT_MODE_CD,
             A.OWNER_CUST_ID,
             NULL NEW_PRODUCT_ID,
             'N' IS_EXIST,
             'IN' ACTION,
             SYSDATE CREATE_DATE
        FROM CRMV2.PROD_INST A
       WHERE PROD_INST_ID = V_PROD_INST_ID;
    --产品属性
    INSERT INTO AUTOTEST_MEMBER_ATTR
      (AUTOTEST_MEMBER_ATTR_ID,
       AUTOTEST_MEMBER_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      SELECT SEQ_AUTOTEST_MEMBER_ATTR_ID.NEXTVAL,
             i_order_item_id               AUTOTEST_MEMBER_ID,
             AC.EXT_ATTR_NBR,
             PIA.ATTR_VALUE_ID,
             PIA.ATTR_VALUE,
             SYSDATE                             CREATE_DATE
        FROM CRMV2.PROD_INST_ATTR PIA, CRMV2.ATTR_SPEC AC
       WHERE AC.ATTR_ID = PIA.ATTR_ID
         AND PIA.PROD_INST_ID = V_PROD_INST_ID;

          ---MEMBER_REL
    insert into autotest_member_rel
      (AUTOTEST_MEMBER_REL_ID,
       CUST_ORDER_ID,
       RELATION_TYPE_CD,
       PROD_INST_A_ID,
       PROD_INST_Z_ID,
       ROLE_CD,
       CREATE_DATE)
      select SEQ_AUTOTEST_MEMBER_REL_ID.NEXTVAL AUTOTEST_MEMBER_REL_ID,
             V_CUST_ORDER_ID                    CUST_ORDER_ID,
             D.RELATION_TYPE_CD,
             D.PROD_INST_A_ID,
             D.PROD_INST_Z_ID,
             D.ROLE_CD,
             SYSDATE                            CREATE_DATE
        from crmv2.prod_inst_REL D
       where D.PROD_INST_A_ID = V_PROD_INST_ID;

  ELSIF I_ACTION_TYPE = C_ACTION_MOD THEN
    --MOD
    INSERT INTO AUTOTEST_MEMBER
      (AUTOTEST_MEMBER_ID,
       CUST_ORDER_ID,
       EXT_PROD_ID,
       PROD_INST_ID,
       ACC_NBR,
       ROLE_CD,
       LAN_ID,
       VIRTUAL_PROD_INST_ID,
       ADDRESS_ID,
       ADDRESS_DESC,
       EXCH_ID,
       PAYMENT_MODE_CD,
       OWNER_CUST_ID,
       NEW_PRODUCT_ID,
       IS_EXIST,
       ACTION,
       CREATE_DATE)
      SELECT i_order_item_id AUTOTEST_MEMBER_ID,
             V_CUST_ORDER_ID,
             qianty_f_get_value('AUTOTEST_CUST',
                                'EXT_PROD_ID',
                                i_order_item_id) EXT_PROD_ID,
             V_PROD_INST_ID PROD_INST_ID,
             qianty_f_get_value('AUTOTEST_CUST', 'ACC_NBR', i_order_item_id) ACC_NBR,
             qianty_f_get_value('AUTOTEST_CUST', 'ROLE_CD', i_order_item_id) ROLE_CD,
             qianty_f_get_value('AUTOTEST_CUST', 'LAN_ID', i_order_item_id) LAN_ID,
             '' VIRTUAL_PROD_INST_ID,
             qianty_f_get_value('AUTOTEST_CUST',
                                'ADDRESS_ID',
                                i_order_item_id) ADDRESS_ID,
             qianty_f_get_value('AUTOTEST_CUST',
                                'ADDRESS_DESC',
                                i_order_item_id) ADDRESS_DESC,
             qianty_f_get_value('AUTOTEST_CUST', 'EXCH_ID', i_order_item_id) EXCH_ID,
             qianty_f_get_value('AUTOTEST_CUST',
                                'PAYMENT_MODE_CD',
                                i_order_item_id) PAYMENT_MODE_CD,
             qianty_f_get_value('AUTOTEST_CUST',
                                'OWNER_CUST_ID',
                                i_order_item_id) OWNER_CUST_ID,
             '' NEW_PRODUCT_ID,
             'Y' IS_EXIST,
             '' ACTION,
             SYSDATE CREATE_DATE
        FROM DUAL;
    --产品属性 --class_id=-4 表示产品属性
    INSERT INTO AUTOTEST_MEMBER_ATTR
      (AUTOTEST_MEMBER_ATTR_ID,
       AUTOTEST_MEMBER_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      SELECT SEQ_AUTOTEST_MEMBER_ATTR_ID.NEXTVAL,
             i_order_item_id               AUTOTEST_MEMBER_ID,
             AC.EXT_ATTR_NBR,
             NULL                                ATTR_VALUE_ID,
             PIA.NEW_VALUE,
             SYSDATE                             CREATE_DATE
        FROM CRMV2.ORDER_ITEM_PROC_ATTR_HIS PIA, CRMV2.ATTR_SPEC AC
       WHERE AC.ATTR_ID = PIA.OBJ_ATTR_ID
         AND PIA.CLASS_ID = -4
         AND ORDER_ITEM_ID = i_order_item_id;

         --MEMBER_REL
    insert into autotest_member_rel
      (AUTOTEST_MEMBER_REL_ID,
       CUST_ORDER_ID,
       RELATION_TYPE_CD,
       PROD_INST_A_ID,
       PROD_INST_Z_ID,
       ROLE_CD,
       CREATE_DATE)
      select SEQ_AUTOTEST_MEMBER_REL_ID.NEXTVAL AUTOTEST_MEMBER_REL_ID,
             V_CUST_ORDER_ID                    CUST_ORDER_ID,
             D.RELATION_TYPE_CD,
             D.PROD_INST_A_ID,
             D.PROD_INST_Z_ID,
             D.ROLE_CD,
             SYSDATE                            CREATE_DATE
        from crmv2.prod_inst_REL D, order_item_proc_attr_his A
       where A.NEW_VALUE = D.PROD_INST_REL_ID
         AND A.CLASS_ID = 136
         AND A.ORDER_ITEM_ID = i_order_item_id;


  ELSE
    INSERT INTO AUTOTEST_MEMBER
      (AUTOTEST_MEMBER_ID,
       CUST_ORDER_ID,
       EXT_PROD_ID,
       PROD_INST_ID,
       ACC_NBR,
       ROLE_CD,
       LAN_ID,
       VIRTUAL_PROD_INST_ID,
       ADDRESS_ID,
       ADDRESS_DESC,
       EXCH_ID,
       PAYMENT_MODE_CD,
       OWNER_CUST_ID,
       NEW_PRODUCT_ID,
       IS_EXIST,
       ACTION,
       CREATE_DATE)
      SELECT i_order_item_id AUTOTEST_MEMBER_ID,
             V_CUST_ORDER_ID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             'Y' IS_EXIST,
             'OUT' ACTION,
             SYSDATE CREATE_DATE
        FROM DUAL;
  END IF;

END Q_T01_PROD_TRANS;
/
