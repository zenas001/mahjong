CREATE PROCEDURE           CRM_DATA_REPAIR2016(I_TABLE_NAME IN VARCHAR2,
                                                I_KEY_ID     IN NUMBER,
                                                O_MSG        OUT VARCHAR2,
                                                code_msg OUT NUMBER) IS
cn1 number;
cn2 number;
v_i_table_name  itsc_crmv2.intf_ins_billing_update.table_name%TYPE;
V_DATE DATE;
V_DATE2 DATE;
V_DATE3 DATE;
HIS_ID_MAX VARCHAR2(30);
BEGIN
/*liufzh(刘凤珍) 09:17:35
code=0 成功，1表示失败  */
  V_I_TABLE_NAME := UPPER(TRIM(I_TABLE_NAME));

  IF I_KEY_ID IS NULL THEN
    RAISE_APPLICATION_ERROR(-20203, 'I_KEY_ID 不能为空');
    code_msg := '1';
  END IF;

IF V_I_TABLE_NAME NOT IN
('CUST','PARTY','PAYMENT_PLAN','ACCOUNT','PROD_INST_ACCT','PROD_INST','PROD_INST_ATTR','PROD_INST_REL','OFFER_PROD_INST_REL',/*'PROD_OFFER_INST',*/'PROD_OFFER_INST_REL','PROD_OFFER_INST_ATTR','PROD_OFFER_MEMBER_INST') THEN
 O_MSG := '不存在此表修复';
      code_msg := '1';
  RETURN;
end if;


IF V_I_TABLE_NAME = 'CUST' THEN
  select count(1) into cn1  from  CUST_HIS where CUST_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       cust_id order by  status_date asc ) idx
  from   cust_his a where cust_id =i_key_id AND STATUS_CD<>'1299') ) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id,rec_update_date INTO HIS_ID_MAX, V_DATE2 from
(select  a.*,
       row_number() over(partition by
       CUST_ID order by  REC_UPDATE_DATE desc ) idx1
  from   CUST_HIS a where CUST_ID =I_KEY_ID and status_cd<>'1299' )
where idx1=1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update CUST_his
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update CUST_his
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;

    select count(1) into cn2 from CUST where  cust_id =I_KEY_ID;

    if cn2>0 then
  select STATUS_DATE INTO V_DATE3 from CUST where
                cust_id =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update cust
                  set status_date = V_DATE
         where cust_id = I_KEY_ID;
        COMMIT;
      end if;
end if;



 NEW_P_INS_BILLING_UPDATE_70S('CUST',
                                        'CUST_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  O_MSG := '已处理';
code_msg := '0';
  end loop;
  commit;

   end if;

ELSIF V_I_TABLE_NAME = 'PARTY' THEN
  select count(1) into cn1  from  PARTY_HIS where PARTY_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       party_id order by  status_date asc ) idx
  from   party_his a where party_id =i_key_id  AND STATUS_CD<>'1299')) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id,rec_update_date INTO HIS_ID_MAX, V_DATE2 from
(select  a.*,
       row_number() over(partition by
       PARTY_ID order by  REC_UPDATE_DATE desc ) idx1
  from   PARTY_HIS a where PARTY_ID =I_KEY_ID and status_cd<>'1299' )
where idx1=1;

    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PARTY_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PARTY_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;

     select count(1) into cn2 from PARTY where   PARTY_id =I_KEY_ID;

    if cn2>0 then
    select STATUS_DATE INTO V_DATE3 from PARTY where
                PARTY_id =I_KEY_ID;

  if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PARTY
                  set status_date = V_DATE
         where PARTY_id = I_KEY_ID;
        COMMIT;
      end if;
end if;
 NEW_P_INS_BILLING_UPDATE_70S('PARTY',
                                        'PARTY_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
  O_MSG := '已处理';
code_msg := '0';
   end if;
ELSIF V_I_TABLE_NAME = 'PAYMENT_PLAN' THEN
  select count(1) into cn1  from  PAYMENT_PLAN_HIS where PAYMENT_PLAN =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       PAYMENT_PLAN order by  status_date asc ) idx
  from   PAYMENT_PLAN_his a where PAYMENT_PLAN =i_key_id AND STATUS_CD<>'1299' )) loop

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id,rec_update_date INTO HIS_ID_MAX, V_DATE2 from
(select  a.*,
       row_number() over(partition by
       PAYMENT_PLAN order by  REC_UPDATE_DATE desc ) idx1
  from   PAYMENT_PLAN_HIS a where PAYMENT_PLAN =I_KEY_ID and status_cd<>'1299' )
where idx1=1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PAYMENT_PLAN_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PAYMENT_PLAN_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;

        select count(1) into cn2 from PAYMENT_PLAN where  PAYMENT_PLAN =I_KEY_ID;

    if cn2>0 then
 select STATUS_DATE INTO V_DATE3 from PAYMENT_PLAN where
                PAYMENT_PLAN =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PAYMENT_PLAN
                  set status_date = V_DATE
         where PAYMENT_PLAN = I_KEY_ID;
        COMMIT;
      end if;

end if;


 NEW_P_INS_BILLING_UPDATE_70S('PAYMENT_PLAN',
                                        'PAYMENT_PLAN',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
    O_MSG := '已处理';
code_msg := '0';
  commit;

   end if;


ELSIF V_I_TABLE_NAME = 'ACCOUNT' THEN
  select count(1) into cn1  from  ACCOUNT_HIS where ACCOUNT_id =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       ACCOUNT_ID order by  status_date asc ) idx
  from   ACCOUNT_his a where ACCOUNT_ID =i_key_id AND STATUS_CD<>'1299')) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id,rec_update_date INTO HIS_ID_MAX, V_DATE2 from
(select  a.*,
       row_number() over(partition by
       ACCOUNT_ID order by  REC_UPDATE_DATE desc ) idx1
  from   ACCOUNT_HIS a where ACCOUNT_ID =I_KEY_ID and status_cd<>'1299' )
where idx1=1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update ACCOUNT_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update ACCOUNT_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;

      select count(1) into cn2 from ACCOUNT where  ACCOUNT_ID =I_KEY_ID;

    if cn2>0 then
    select STATUS_DATE INTO V_DATE3 from ACCOUNT where
                ACCOUNT_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update ACCOUNT
                  set status_date = V_DATE
         where ACCOUNT_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;



 NEW_P_INS_BILLING_UPDATE_70S('ACCOUNT',
                                        'ACCOUNT_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
  O_MSG := '已处理';
code_msg := '0';
   end if;
ELSIF V_I_TABLE_NAME = 'PROD_INST_ACCT' THEN
  select count(1) into cn1  from  PROD_INST_ACCT_HIS where PROD_INST_ACCT_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       PROD_INST_ACCT_ID order by  status_date asc ) idx
  from   PROD_INST_ACCT_his a where PROD_INST_ACCT_ID =i_key_id AND STATUS_CD<>'1299')) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by PROD_INST_ACCT_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_INST_ACCT_HIS a
         where PROD_INST_ACCT_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_INST_ACCT_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_INST_ACCT_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;

     select count(1) into cn2 from PROD_INST_ACCT where  PROD_INST_ACCT_ID =I_KEY_ID;

    if cn2>0 then
    select STATUS_DATE INTO V_DATE3 from PROD_INST_ACCT where
                PROD_INST_ACCT_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_INST_ACCT
                  set status_date = V_DATE
         where PROD_INST_ACCT_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;


 NEW_P_INS_BILLING_UPDATE_70S('PROD_INST_ACCT',
                                        'PROD_INST_ACCT_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
  O_MSG := '已处理';
code_msg := '0';
   end if;
ELSIF V_I_TABLE_NAME = 'PROD_INST' THEN
  select count(1) into cn1  from  PROD_INST_HIS where PROD_INST_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       prod_inst_id order by  status_date asc ) idx
  from   PROD_INST_HIS a where PROD_INST_ID =i_key_id AND STATUS_CD<>'1299')) loop

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;



select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by PROD_INST_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_INST_HIS a
         where PROD_INST_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;

    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_INST_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_INST_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;


     select count(1) into cn2 from PROD_INST where  PROD_INST_ID =I_KEY_ID;

    if cn2>0 then
   select STATUS_DATE INTO V_DATE3 from PROD_INST where
                PROD_INST_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then
        insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_INST
                  set status_date = V_DATE
         where PROD_INST_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;


O_MSG := '已处理';
 NEW_P_INS_BILLING_UPDATE_70S('PROD_INST',
                                        'PROD_INST_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  COMMIT;
    O_MSG := '已处理';
code_msg := '0';
   end if;



ELSIF V_I_TABLE_NAME = 'PROD_INST_ATTR' THEN
  select count(1) into cn1  from  PROD_INST_ATTR_HIS where PROD_INST_ATTR_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       PROD_INST_ATTR_ID order by  status_date asc ) idx
  from   PROD_INST_ATTR_his a where PROD_INST_ATTR_ID =i_key_id AND STATUS_CD<>'1299')) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by PROD_INST_ATTR_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_INST_ATTR_HIS a
         where PROD_INST_ATTR_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;



    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_INST_ATTR_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_INST_ATTR_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;


     select count(1) into cn2 from PROD_INST_ATTR where  PROD_INST_ATTR_ID =I_KEY_ID;

    if cn2>0 then
       select STATUS_DATE INTO V_DATE3 from PROD_INST_ATTR where
                PROD_INST_ATTR_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_INST_ATTR
                  set status_date = V_DATE
         where PROD_INST_ATTR_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;

     NEW_P_INS_BILLING_UPDATE_70S('PROD_INST_ATTR',
                                        'PROD_INST_ATTR_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
  O_MSG := '已处理';
code_msg := '0';
   end if;
ELSIF V_I_TABLE_NAME = 'PROD_INST_REL' THEN
  select count(1) into cn1  from  PROD_INST_REL_HIS where PROD_INST_REL_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       PROD_INST_REL_id order by  status_date asc ) idx
  from   PROD_INST_REL_HIS a where PROD_INST_REL_ID =i_key_id AND STATUS_CD<>'1299')) loop

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;


select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by PROD_INST_REL_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_INST_REL_HIS a
         where PROD_INST_REL_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_INST_REL_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_INST_REL_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;


     select count(1) into cn2 from PROD_INST_REL where  PROD_INST_REL_ID =I_KEY_ID;

    if cn2>0 then
          select STATUS_DATE INTO V_DATE3 from PROD_INST_REL where
                PROD_INST_REL_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_INST_REL
                  set status_date = V_DATE
         where PROD_INST_REL_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;


 NEW_P_INS_BILLING_UPDATE_70S('PROD_INST_REL',
                                        'PROD_INST_REL_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
    O_MSG := '已处理';
code_msg := '0';
   end if;
ELSIF V_I_TABLE_NAME = 'OFFER_PROD_INST_REL' THEN
  select count(1) into cn1  from  OFFER_PROD_INST_REL_HIS where OFFER_PROD_INST_REL_ID =I_KEY_ID;
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       OFFER_PROD_INST_REL_id order by  status_date asc ) idx
  from   OFFER_PROD_INST_REL_HIS a where OFFER_PROD_INST_REL_ID =i_key_id )) loop

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;


select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by OFFER_PROD_INST_REL_ID order by REC_UPDATE_DATE desc) idx1
          from OFFER_PROD_INST_REL_HIS a
         where OFFER_PROD_INST_REL_ID = I_KEY_ID)
 where idx1 = 1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update OFFER_PROD_INST_REL_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update OFFER_PROD_INST_REL_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;


     select count(1) into cn2 from OFFER_PROD_INST_REL where  OFFER_PROD_INST_REL_ID =I_KEY_ID;

    if cn2>0 then
           select STATUS_DATE INTO V_DATE3 from OFFER_PROD_INST_REL where
                OFFER_PROD_INST_REL_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then


insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update OFFER_PROD_INST_REL
                  set status_date = V_DATE
         where OFFER_PROD_INST_REL_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;


 NEW_P_INS_BILLING_UPDATE_70S('OFFER_PROD_INST_REL',
                                        'OFFER_PROD_INST_REL_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
    O_MSG := '已处理';
code_msg := '0';
   end if;
/*ELSIF V_I_TABLE_NAME = 'PROD_OFFER_INST' THEN
  select count(1) into cn1  from  PROD_OFFER_INST_HIS where PROD_OFFER_INST_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       PROD_OFFER_INST_id order by  status_date asc ) idx
  from   PROD_OFFER_INST_HIS a where PROD_OFFER_INST_id =i_key_id AND STATUS_CD<>'1299')) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by PROD_OFFER_INST_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_OFFER_INST_HIS a
         where PROD_OFFER_INST_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_OFFER_INST_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_OFFER_INST_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;


     select count(1) into cn2 from PROD_OFFER_INST where  PROD_OFFER_INST_ID =I_KEY_ID;

    if cn2>0 then
         select STATUS_DATE INTO V_DATE3 from PROD_OFFER_INST where
                PROD_OFFER_INST_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_OFFER_INST
                  set status_date = V_DATE
         where PROD_OFFER_INST_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;


 NEW_P_INS_BILLING_UPDATE_70S('PROD_OFFER_INST',
                                        'PROD_OFFER_INST_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
    O_MSG := '已处理';
code_msg := '0';
   end if;*/
ELSIF V_I_TABLE_NAME = 'PROD_OFFER_INST_REL' THEN
  select count(1) into cn1  from  PROD_OFFER_INST_REL_HIS where PROD_OFFER_INST_REL_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       PROD_OFFER_INST_REL_id order by  status_date asc ) idx
  from   PROD_OFFER_INST_REL_HIS a where PROD_OFFER_INST_REL_id =i_key_id AND STATUS_CD<>'1299')) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by PROD_OFFER_INST_REL_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_OFFER_INST_REL_HIS a
         where PROD_OFFER_INST_REL_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;

    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_OFFER_INST_REL_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_OFFER_INST_REL_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;

       select count(1) into cn2 from PROD_OFFER_INST_REL where  PROD_OFFER_INST_REL_ID =I_KEY_ID;

    if cn2>0 then
      select STATUS_DATE INTO V_DATE3 from PROD_OFFER_INST_REL where
                PROD_OFFER_INST_REL_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_OFFER_INST_REL
                  set status_date = V_DATE
         where PROD_OFFER_INST_REL_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;


 NEW_P_INS_BILLING_UPDATE_70S('PROD_OFFER_INST_REL',
                                        'PROD_OFFER_INST_REL_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
    O_MSG := '已处理';
code_msg := '0';
   end if;
ELSIF V_I_TABLE_NAME = 'PROD_OFFER_INST_ATTR' THEN
  select count(1) into cn1  from  PROD_OFFER_INST_ATTR_HIS where PROD_OFFER_INST_ATTR_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       PROD_OFFER_INST_ATTR_id order by  status_date asc ) idx
  from   PROD_OFFER_INST_ATTR_HIS a where PROD_OFFER_INST_ATTR_id =i_key_id AND STATUS_CD<>'1299')) loop
insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;

select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by PROD_OFFER_INST_ATTR_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_OFFER_INST_ATTR_HIS a
         where PROD_OFFER_INST_ATTR_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_OFFER_INST_ATTR_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_OFFER_INST_ATTR_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;

     select count(1) into cn2 from PROD_OFFER_INST_ATTR where  PROD_OFFER_INST_ATTR_ID =I_KEY_ID;

    if cn2>0 then
       select STATUS_DATE INTO V_DATE3 from PROD_OFFER_INST_ATTR where
                PROD_OFFER_INST_ATTR_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_OFFER_INST_ATTR
                  set status_date = V_DATE
         where PROD_OFFER_INST_ATTR_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;


 NEW_P_INS_BILLING_UPDATE_70S('PROD_OFFER_INST_ATTR',
                                        'PROD_OFFER_INST_ATTR_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
    O_MSG := '已处理';
code_msg := '0';
   end if;
ELSIF V_I_TABLE_NAME = 'PROD_OFFER_MEMBER_INST' THEN
  select count(1) into cn1  from  PROD_OFFER_MEMBER_INST_HIS where MEMBER_INST_ID =I_KEY_ID and status_cd<>'1299';
  if cn1=0 then
      O_MSG := '没有历史记录';
      code_msg := '1';
      RETURN;
  elsif cn1>0 then
  for rec2 in (select idx, his_id, status_date, rec_update_date from
(select  a.*,
       row_number() over(partition by
       MEMBER_INST_id order by  status_date asc ) idx
  from   PROD_OFFER_MEMBER_INST_HIS a where MEMBER_INST_id =i_key_id AND STATUS_CD<>'1299')) loop

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,rec2.his_id,rec2.status_date,rec2.rec_update_date,sysdate from dual;
commit;


select his_id, rec_update_date
  INTO HIS_ID_MAX, V_DATE2
  from (select a.*,
               row_number() over(partition by MEMBER_INST_ID order by REC_UPDATE_DATE desc) idx1
          from PROD_OFFER_MEMBER_INST_HIS a
         where MEMBER_INST_ID = I_KEY_ID
           and status_cd <> '1299')
 where idx1 = 1;


    if rec2.idx = 1 then
      V_DATE := REC2.rec_update_date;
    end if;
    if rec2.idx > 1 then
      if rec2.rec_update_date > v_date then
        update PROD_OFFER_MEMBER_INST_HIS
           set status_date = v_date
         where his_id = rec2.his_id;
        v_date := rec2.rec_update_date;
      else
        update PROD_OFFER_MEMBER_INST_HIS
           set status_date = v_date, rec_update_date = v_date + 1 / 3600
         where his_id = rec2.his_id;
        v_date := v_date + 1 / 3600;
      end if;
    end if;


 select count(1) into cn2 from PROD_OFFER_MEMBER_INST where  MEMBER_INST_ID =I_KEY_ID;

    if cn2>0 then
         select STATUS_DATE INTO V_DATE3 from PROD_OFFER_MEMBER_INST where
                MEMBER_INST_ID =I_KEY_ID;


      if HIS_ID_MAX = REC2.HIS_ID AND V_DATE3 <> V_DATE then

insert into CRM_DATA_REPAIR2016_bak
select v_i_table_name,i_key_id,'',V_DATE3,'',sysdate from dual;
commit;
        update PROD_OFFER_MEMBER_INST
                  set status_date = V_DATE
         where MEMBER_INST_ID = I_KEY_ID;
        COMMIT;
      end if;
      end if;



 NEW_P_INS_BILLING_UPDATE_70S('PROD_OFFER_MEMBER_INST',
                                        'MEMBER_INST_ID',
                                        I_key_id,
                                        'DEM0_201605313153-01',
                                        'FZTEST');

  end loop;
  commit;
    O_MSG := '已处理';
code_msg := '0';
   end if;

END IF;


     exception  when others then
          O_MSG := SQLERRM;
        code_msg := '1';

end;
/
