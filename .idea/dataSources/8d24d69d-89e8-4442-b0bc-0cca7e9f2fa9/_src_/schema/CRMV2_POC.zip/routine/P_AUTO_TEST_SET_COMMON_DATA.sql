CREATE PROCEDURE           P_AUTO_TEST_SET_COMMON_DATA IS

    --过程主体
BEGIN
--枢纽营业厅
   --删除已使用数据
   DELETE FROM AUTO_TEST_COMMON_DATA CD WHERE CD.CLASS = 'USIM卡' AND CD.TYPE = '4G卡-翼支付' AND CD.STORAGE = '341';
   COMMIT;
   --插入4G卡-翼支付卡数据
   for rec in (select a.mkt_reso_key
	   from crmv1.mkt_resource a where A.STORAGE_ID = '341' and a.mkt_reso_spec_type = '610003985'
      AND A.STATE = '70A' AND a.mkt_reso_spec_id = '611190410'   --4G卡-翼支付
      AND ROWNUM < 100)	loop
   	insert into auto_test_common_data (COMMON_DATA_ID, DATA, CLASS, TYPE, DATA_DESC, STORAGE, AREA, REGION, USE_FLAG, UPDATE_DATE)
	  values (SEQ_AUTO_TEST_COMMON_DATA_ID.NEXTVAL, rec.mkt_reso_key, 'USIM卡', '4G卡-翼支付', 'USIM卡号', '341', '', '', '0', SYSDATE);
	  COMMIT;
   end loop;

--东街营业厅 STORAGE_ID = '463'
    --删除已使用数据
    DELETE FROM AUTO_TEST_COMMON_DATA CD WHERE CD.CLASS = 'USIM卡' AND CD.TYPE = '4G卡-翼支付' AND CD.STORAGE = '463';
    COMMIT;
    --插入4G卡-翼支付卡数据





  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;

END P_AUTO_TEST_SET_COMMON_DATA;
/
