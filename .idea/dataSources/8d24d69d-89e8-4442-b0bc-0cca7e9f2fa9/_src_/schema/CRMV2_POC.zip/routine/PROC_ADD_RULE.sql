CREATE procedure           proc_add_rule(i_class_id            number, --类ID
                                          i_oper_id             number, --方法ID
                                          i_rule_name           varchar2, --规则名称
                                          i_comments            varchar2, --规则备注
                                          i_rule_excecute_class varchar2, --规则执行类
                                          i_rule_excecute_meth  varchar2, --规则执行方法
                                          i_service_offer_id    number --service_offer
                                          ) is

  v_rule_id number;
begin
  select seq_rlm_rule_id.nextval into v_rule_id from dual;
  insert into rlm_rule
    (rule_id,
     rule_name,
     comments,
     rule_type,
     manage_level,
     rule_excecute_class,
     rule_excecute_meth,
     cfg_url,
     status_cd,
     status_date,
     create_person,
     create_date,
     update_date,
     area_id,
     region_cd,
     update_staff,
     create_staff,
     bak_data,
     data,
     rule_seq)
  values
    (v_rule_id,
     i_rule_name,
     i_comments,
     'JVA',
     'GRP',
     i_rule_excecute_class,
     i_rule_excecute_meth,
     '',
     '1000',
     sysdate,
     '',
     sysdate,
     sysdate,
     1,
     1,
     49822,
     49822,
     '',
     null,
     null);

  insert into rlm_rule_class_rel
    (rule_class_rel_id,
     rule_id,
     class_id,
     oper_id,
     service_offer_id,
     region_id,
     status_cd,
     status_date,
     create_date,
     update_date,

     area_id,
     region_cd,
     update_staff,
     create_staff,
     attr_id)
  values
    (seq_rlm_rule_class_rel_id.nextval,
     v_rule_id,
     i_class_id,
     i_oper_id,
     i_service_offer_id,
     null,
     '1000',
     sysdate,
     sysdate,
     sysdate,
     2,
     11,
     49822,
     49822,
     null);

  commit;
end proc_add_rule;
/
