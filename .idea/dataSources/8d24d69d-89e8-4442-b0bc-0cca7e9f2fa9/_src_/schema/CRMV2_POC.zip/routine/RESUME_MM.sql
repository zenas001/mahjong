CREATE PROCEDURE           RESUME_MM(IN_CUST_SO_NUMBER IN VARCHAR2 ,OUT_RESULT OUT VARCHAR2) IS
  V_new_value  VARCHAR2(60);
  V_attr_value VARCHAR2(60);
  v_pw         varchar2(30);
  v_code       varchar2(30);
  v_msg        varchar2(1200);
BEGIN
  begin
    ----提取密码数据
    select a.new_value, pi.attr_value
      INTO V_new_value, V_attr_value
      from crmv2.customer_order_his       co,
           crmv2.Order_Item_his           po,
           crmv2.Order_item_proc_attr_his a,
           crmv2.prod_inst_attr           pi
     where co.cust_so_number = IN_cust_so_number--'FJ2014060385100050'
       and co.cust_order_id = po.cust_order_id
       and a.order_item_id = po.order_item_id
       and a.obj_attr = 'ONE_MM'
       and pi.prod_inst_id = po.order_item_obj_id
       and pi.attr_id = a.obj_attr_id;
    ----解密
    decry(V_attr_value, v_pw, v_code, v_msg);
    if V_new_value = v_pw then
      OUT_RESULT := '订单修改密码同档案一致';
    else
      OUT_RESULT := '订单修改密码同档案不一致';
    end if;
  exception
    when others then
      OUT_RESULT := '检查异常';
  end;
end;
/
