CREATE PROCEDURE           PROC_ADD_STAFF_PRIVILEGE(I_SRC_STAFF_POSITION_ID    IN NUMBER,
                                                     I_DEST_STAFF_POSITION_ID   IN NUMBER,
                                                     I_HANDLE_STAFF_ID          IN NUMBER,
                                                     I_HANDLE_STAFF_POSITION_ID IN NUMBER,
                                                     O_RESULT                   OUT VARCHAR2,
                                                     O_MSG                      OUT VARCHAR2) IS

  V_SRC_STAFF_ID           NUMBER;
  V_HANDLE_STAFF_ID        NUMBER;
  V_DEST_STAFF_ID          NUMBER;
  V_SRC_SYSTEM_USER_ID     NUMBER;
  V_HANDLE_SYSTEM_USER_ID  NUMBER;
  V_DEST_SYSTEM_USER_ID    NUMBER;
  V_SRC_ORG_ID             NUMBER;
  V_HANDLE_ORG_ID          NUMBER;
  V_SRC_POSITION_ID        NUMBER;
  V_DEST_STAFF_POSITION_ID NUMBER;
  V_DEST_ORG_ID            NUMBER;
  V_COUNT                  NUMBER;

  --定义一个游标,用来查询所有的员工权限
  CURSOR CUR IS
    SELECT A.SYSTEM_USER_PRIVILEGE_ID,
           PRIVILEGE_ID,
           V_DEST_SYSTEM_USER_ID SYSTEM_USER_ID,
           EFFECT_DATE,
           EXPIRE_DATE,
           STATUS_CD,
           STATUS_DATE,
           CREATE_DATE,
           UPDATE_DATE,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           CREATE_STAFF,
           PRI_TYPE,
           V_DEST_ORG_ID ORG_ID --V_DEST_ORG_ID替换ORG_ID modify by g.huangwch ORG_ID
      FROM STAFF_LIMIT A
     WHERE A.SYSTEM_USER_ID = V_SRC_SYSTEM_USER_ID
       AND A.STATUS_CD = '1000'
          --20131219 crm00049529
       and exists (SELECT PRIVILEGE_ID
              FROM STAFF_LIMIT AL
             WHERE AL.SYSTEM_USER_ID = V_HANDLE_SYSTEM_USER_ID
               AND AL.STATUS_CD = '1000'
               AND AL.ORG_ID = V_HANDLE_ORG_ID
               AND AL.PRIVILEGE_ID = a.PRIVILEGE_ID
               AND (AL.PRI_TYPE = '11') --只有管理类型为管理才允许拷贝 modify by g.huangwch
            )
       AND A.ORG_ID = V_SRC_ORG_ID
       AND NOT EXISTS --员工本身拥有的权限过滤,避免重复插入
     (SELECT 1
              FROM STAFF_LIMIT B
             WHERE A.PRIVILEGE_ID = B.PRIVILEGE_ID
               AND B.SYSTEM_USER_ID = V_DEST_SYSTEM_USER_ID
               AND B.ORG_ID = V_DEST_ORG_ID)
       AND NOT EXISTS (SELECT 1 --敏感权限过滤  84 为PRIVILEGE的CLASS_ID
              FROM PRIVILEGE_COPY_BLOCK C
             WHERE A.PRIVILEGE_ID = C.OBJ_INST_ID
               AND C.CLASS_ID = 84
               AND C.STATUS_CD = '1000');

  CURSOR CUR_STAFF_POSITION IS

    SELECT E.*, d.rela_privilege_id
      FROM STAFF_POSITION        A,
           POSITION              C,
           ORG_ROLE_POSITION_REL D,
           STAFF_POSITION        E
     WHERE A.STAFF_POSITION_ID = I_SRC_STAFF_POSITION_ID
       AND A.STATUS_CD = '1000'
       AND A.STAFF_POSITION_ID = D.STAFF_POSITION_A_ID
       AND D.STAFF_POSITION_Z_ID = E.STAFF_POSITION_ID
       AND E.POSITION_ID = C.POSITION_ID
       AND C.POSITION_SORT = '10'
          --20131219 crm00049529
       AND EXISTS
     (SELECT EL.POSITION_ID
              FROM STAFF_POSITION        AL,
                   POSITION              CL,
                   ORG_ROLE_POSITION_REL DL,
                   STAFF_POSITION        EL
             WHERE AL.STAFF_POSITION_ID = I_HANDLE_STAFF_POSITION_ID
               AND AL.STATUS_CD = '1000'
               AND AL.STAFF_POSITION_ID = DL.STAFF_POSITION_A_ID
               AND DL.STAFF_POSITION_Z_ID = EL.STAFF_POSITION_ID
               AND EL.POSITION_ID = CL.POSITION_ID
               AND CL.POSITION_SORT = '10'
               AND EL.POSITION_ID = E.POSITION_ID
               AND (EL.PRI_TYPE = '11') --只有管理类型为管理才允许拷贝 modify by g.huangwch
            )
       AND NOT EXISTS --员工本身拥有的权限过滤,避免重复插入
     (SELECT 1
              FROM ORG_ROLE_POSITION_REL B, STAFF_POSITION F
             WHERE E.POSITION_ID = F.POSITION_ID
               AND B.STAFF_POSITION_Z_ID = F.STAFF_POSITION_ID
               AND B.STAFF_POSITION_A_ID = I_DEST_STAFF_POSITION_ID)
       AND NOT EXISTS (SELECT 1 --敏感工位过滤  10 为POSITION的CLASS_ID
              FROM PRIVILEGE_COPY_BLOCK C
             WHERE E.POSITION_ID = C.OBJ_INST_ID
               AND C.CLASS_ID = 10
               AND C.STATUS_CD = '1000');

BEGIN
  --查询权限来源员工id,组织id,岗位id
  SELECT A.STAFF_ID, A.POSITION_ID, A.ORG_ID
    INTO V_SRC_STAFF_ID, V_SRC_POSITION_ID, V_SRC_ORG_ID
    FROM STAFF_POSITION A
   WHERE A.STAFF_POSITION_ID = I_SRC_STAFF_POSITION_ID;

  --查询登陆任职团队的权限来源员工id,组织id 20131219 crm00049529
  SELECT A.STAFF_ID, A.ORG_ID
    INTO V_HANDLE_STAFF_ID, V_HANDLE_ORG_ID
    FROM STAFF_POSITION A
   WHERE A.STAFF_POSITION_ID = I_HANDLE_STAFF_POSITION_ID;

  --查询目标员工系统用户标识
  SELECT B.SYSTEM_USER_ID, A.STAFF_ID, A.ORG_ID
    INTO V_DEST_SYSTEM_USER_ID, V_DEST_STAFF_ID, V_DEST_ORG_ID
    FROM STAFF_POSITION A, SYSTEM_USER B
   WHERE A.STAFF_ID = B.STAFF_ID
     AND A.STAFF_POSITION_ID = I_DEST_STAFF_POSITION_ID;

  --查询权限来源系统用户id
  SELECT B.SYSTEM_USER_ID
    INTO V_SRC_SYSTEM_USER_ID
    FROM SYSTEM_USER B
   WHERE B.STAFF_ID = V_SRC_STAFF_ID
     AND B.STATUS_CD = '1000'
     AND ROWNUM < 2;

  --查询登陆任职团队来源系统用户id 20131219 crm00049529
  SELECT B.SYSTEM_USER_ID
    INTO V_HANDLE_SYSTEM_USER_ID
    FROM SYSTEM_USER B
   WHERE B.STAFF_ID = V_HANDLE_STAFF_ID
     AND B.STATUS_CD = '1000'
     AND ROWNUM < 2;

  --1. 根据输入的员工id,查询该员工拥有的STAFF_LIMIT信息

  FOR REC IN CUR LOOP

    INSERT INTO STAFF_LIMIT
      (SYSTEM_USER_PRIVILEGE_ID,
       PRIVILEGE_ID,
       SYSTEM_USER_ID,
       EFFECT_DATE,
       EXPIRE_DATE,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       PRI_TYPE,
       ORG_ID)
    VALUES
      (SEQ_STAFF_LIMIT_ID.NEXTVAL,
       REC.PRIVILEGE_ID,
       REC.SYSTEM_USER_ID,
       REC.EFFECT_DATE,
       REC.EXPIRE_DATE,
       REC.STATUS_CD,
       SYSDATE,
       SYSDATE,
       SYSDATE,
       REC.AREA_ID,
       REC.REGION_CD,
       REC.UPDATE_STAFF,
       I_HANDLE_STAFF_ID, --I_HANDLE_STAFF_ID 替换REC.CREATE_STAFF  2013-11-18crm00046377
       REC.PRI_TYPE,
       REC.ORG_ID);

    V_COUNT := V_COUNT + 1;
    IF V_COUNT > 100 THEN
      COMMIT;
      V_COUNT := 0;
    END IF;

  END LOOP;

  --2. 根据输入的员工id,查询该员工拥有的STAFF_ROLE信息
  INSERT INTO STAFF_ROLE
    (RELATION_ID,
     ROLE_ID,
     SYSTEM_USER_ID,
     EFFECT_DATE,
     EXPIRE_DATE,
     STATUS_CD,
     STATUS_DATE,
     CREATE_DATE,
     UPDATE_DATE,
     AREA_ID,
     REGION_CD,
     UPDATE_STAFF,
     CREATE_STAFF,
     PRI_TYPE,
     ORG_ID)
    SELECT SEQ_STAFF_ROLE_ID.NEXTVAL,
           ROLE_ID,
           V_DEST_SYSTEM_USER_ID,
           EFFECT_DATE,
           EXPIRE_DATE,
           STATUS_CD,
           SYSDATE,
           SYSDATE,
           SYSDATE,
           AREA_ID,
           REGION_CD,
           UPDATE_STAFF,
           I_HANDLE_STAFF_ID, --I_HANDLE_STAFF_ID 替换CREATE_STAFF  2013-11-18crm00046377
           PRI_TYPE,
           V_DEST_ORG_ID --V_DEST_ORG_ID替换ORG_ID modify by g.huangwch
      FROM STAFF_ROLE A
     WHERE A.SYSTEM_USER_ID = V_SRC_SYSTEM_USER_ID
       AND A.STATUS_CD = '1000'
       AND A.ORG_ID = V_SRC_ORG_ID
          --20131219 crm00049529
       and exists (SELECT AL.ROLE_ID
              FROM STAFF_ROLE AL
             WHERE AL.SYSTEM_USER_ID = V_HANDLE_SYSTEM_USER_ID
               AND AL.STATUS_CD = '1000'
               AND AL.ORG_ID = V_HANDLE_ORG_ID
               AND AL.ROLE_ID = a.role_id
               AND (AL.PRI_TYPE = '11') --只有管理类型为管理才允许拷贝 modify by g.huangwch
            )
       AND NOT EXISTS --员工本身拥有的权限过滤,避免重复插入
     (SELECT 1
              FROM STAFF_ROLE B
             WHERE A.ROLE_ID = B.ROLE_ID
               AND B.SYSTEM_USER_ID = V_DEST_SYSTEM_USER_ID
               AND B.ORG_ID = V_DEST_ORG_ID)
       AND NOT EXISTS (SELECT 1 --敏感角色过滤  159 为ROLE的CLASS_ID
              FROM PRIVILEGE_COPY_BLOCK C
             WHERE A.ROLE_ID = C.OBJ_INST_ID
               AND C.CLASS_ID = 159
               AND C.STATUS_CD = '1000');

  --3. 根据输入的员工ID,查询该员工拥有的STAFF_POSITION信息
  --3.1 复制员工的拥有的工位信息
  FOR REC_STAFF_POSITION IN CUR_STAFF_POSITION LOOP

    SELECT SEQ_STAFF_POSITION_ID.NEXTVAL
      INTO V_DEST_STAFF_POSITION_ID
      FROM DUAL;

    --插入任职岗位
    INSERT INTO STAFF_POSITION
      (STAFF_POSITION_ID,
       ORG_ID,
       POSITION_ID,
       STAFF_ID,
       EFFECT_DATE,
       EXPIRE_DATE,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       UPDATE_DATE,
       OLD_POSITION_ID,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       ORG_REL_CD,
       PRI_TYPE)
    VALUES
      (V_DEST_STAFF_POSITION_ID,
       REC_STAFF_POSITION.ORG_ID,
       REC_STAFF_POSITION.POSITION_ID,
       V_DEST_STAFF_ID,
       REC_STAFF_POSITION.EFFECT_DATE,
       REC_STAFF_POSITION.EXPIRE_DATE,
       REC_STAFF_POSITION.STATUS_CD,
       SYSDATE,
       SYSDATE,
       SYSDATE,
       V_DEST_STAFF_POSITION_ID,
       REC_STAFF_POSITION.AREA_ID,
       REC_STAFF_POSITION.REGION_CD,
       REC_STAFF_POSITION.UPDATE_STAFF,
       I_HANDLE_STAFF_ID, --I_HANDLE_STAFF_ID 替换 REC_STAFF_POSITION.CREATE_STAFF 2013-11-18crm00046377
       REC_STAFF_POSITION.ORG_REL_CD,
       REC_STAFF_POSITION.PRI_TYPE);

    --插入任职组织拥有的工位信息
    INSERT INTO ORG_ROLE_POSITION_REL
      (ORG_ROLE_POSITION_REL_ID,
       STAFF_POSITION_A_ID,
       STAFF_POSITION_Z_ID,
       STATUS_CD,
       STATUS_DATE,
       CREATE_STAFF,
       CREATE_DATE,
       UPDATE_STAFF,
       UPDATE_DATE,
       AREA_ID,
       REGION_CD,
       rela_privilege_id)
    VALUES
      (SEQ_ORG_ROLE_POSI_REL_ID.NEXTVAL,
       I_DEST_STAFF_POSITION_ID,
       V_DEST_STAFF_POSITION_ID,
       '1000',
       SYSDATE,
       '0',
       SYSDATE,
       '0',
       SYSDATE,
       2,
       11,
       REC_STAFF_POSITION.rela_privilege_id);

  END LOOP;

  COMMIT;

  O_RESULT := 'TRUE';
EXCEPTION
  WHEN OTHERS THEN
    O_RESULT := 'FALSE';
    O_MSG    := '失败:' || SQLERRM;
    ROLLBACK;
END PROC_ADD_STAFF_PRIVILEGE;
/
