CREATE PROCEDURE           proc_update_businessList_state(i_mod   in number,
                                                             i_leave in number) IS
  CURSOR cur IS
    SELECT *
      FROM business_list_state
     WHERE MOD(business_list_state_id, i_mod) = i_leave
       and rownum < 1000;
  i NUMBER(10) := 0;
BEGIN
  for rec in cur loop
    begin
      i := i + 1;
      update business_list bl
         set bl.ord_state   = rec.ord_state,
             bl.state       = rec.state,
             bl.finish_date = rec.finish_date,
             bl.update_date = sysdate,
             bl.status_date = sysdate
       where bl.order_item_id = rec.order_item_id;
      insert into business_list_state_his
        (his_id,
         business_list_state_id,
         business_list_id,
         state,
         ord_state,
         order_item_id,
         finish_date,
         area_id,
         region_cd,
         status_cd,
         status_date,
         create_date,
         create_staff,
         update_date,
         update_staff)
      values
        (seq_business_list_state_his_id.nextval,
         rec.business_list_state_id,
         rec.business_list_id,
         rec.state,
         rec.ord_state,
         rec.order_item_id,
         rec.finish_date,
         rec.area_id,
         rec.region_cd,
         rec.status_cd,
         rec.status_date,
         rec.create_date,
         rec.create_staff,
         sysdate,
         rec.update_staff);
      delete from business_list_state
       where business_list_state_id = rec.business_list_state_id;
      IF i > 100 THEN
        COMMIT;
        i := 0;
      END IF;
      EXCEPTION WHEN OTHERS THEN
        NULL;
    end;
  end loop;
  commit;
END proc_update_businessList_state;
/
