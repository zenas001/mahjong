CREATE FUNCTION           get_reward_summary_list(v_channel_id     number,
                                                   v_reward_type_cd varchar2)
  return varchar2 is
  o_reward_info_id_list varchar(3000) := '';
  v_code                varchar2(1) := '';
begin
  for rec in (select reward_info_id
                from reward_info
               where channel_id = v_channel_id
                 and reward_type_cd = v_reward_type_cd) loop
    o_reward_info_id_list := o_reward_info_id_list || v_code ||
                             rec.reward_info_id;

    v_code := ',';
  end loop;
  return o_reward_info_id_list;
end;
/
