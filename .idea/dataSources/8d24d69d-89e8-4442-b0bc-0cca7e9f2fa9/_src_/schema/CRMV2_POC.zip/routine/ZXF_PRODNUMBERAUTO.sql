CREATE procedure           zxf_prodNumberAUTO is
  vseq number(10);
  vCreateseq varchar2(300);
begin
for i in (select a.prefix prefix,
                 a.seq_name seq_name,
                 a.num_len num_len,
                 a.postfix_value postfix_value,
                 a.rela_prod_spec,
                 a.backfix backfix,
                 a.mdse_spec_id mdse_spec_id,
                 b.product_id product_id,
                 b.product_name product_name
            from o_data_cfg@lk_crmv1 a, prod_map_zhengcl b, comm_data_cfg c
           where a.prod_spec_id = b.prod_spec_id
             and a.area_id = 2
             and a.prefix is not null
             and b.product_id = c.prod_spec_id(+)
             and c.prod_spec_id is null) loop
    select count(*) into vseq from user_sequences  where  sequence_name=i.seq_name;
    --如果序列不存在，新建序列
    vCreateseq := '';
    if (vseq=0) then
     vCreateseq := 'create sequence  crmv2.' || i.seq_name || ' minvalue 1 maxvalue 99999999999999999 start with 1 increment by 1 cache 20' ;
     dbms_output.put_line(vCreateseq);
     EXECUTE IMMEDIATE vCreateseq;
    end if;
    insert into comm_data_cfg(id,area_id,prod_spec_id,prefix,seq_name,num_len,rela_prod_spec,mdse_spec_id)
          values (COMM_DATA_CFG_SEQ.NEXTVAL,2,i.product_id,i.prefix,i.seq_name,i.num_len,0,0);
end loop;

end;
/
