CREATE PROCEDURE           zxf_EHOME_CXB(i_preferspecid in number)--1.0 e家销售品规格
is
 v_cnt number;
begin

 for KXOFFER  in (select po1.prod_offer_id   E_PROD_OFFER_ID,
                             po1.prod_offer_name E_PROD_OFFER_NAME,
                             po.prod_offer_id    KXB_PROD_OFFER_ID,
                             po.prod_offer_name  KXB_PROD_OFFER_NAME
                        from prefer_mdse_price_spec_rela@lk_crmv1 pmpsr,
                             prefer_mdse_spec_rela@lk_crmv1       pmsr,
                             mdse_ys_lisy_new                     myx, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po,
                             mdse_ys_lisy_new                     myx1, ---取新的规格映射表（modify by lisy）
                             prod_offer                           po1
                       where pmpsr.rela_mdse_id = pmsr.rela_id
                         and pmsr.prefer_spec_id = i_preferspecid --1.0规格
                         and pmsr.role_type = '001' --基础包
                         and pmpsr.cfg_area_id in (1, 2)
                         and pmpsr.state = '70A'
                         and myx.id_v1 = pmpsr.price_id
                         and myx.id_v2 = po.prod_offer_id
                         and po.offer_type = '13'  --促销包
                         and po.offer_sub_type = 'T04'
                         and myx1.id_v1 = i_preferspecid --1.0规格
                         and myx1.id_v2 = po1.prod_offer_id
                         and po1.offer_type = '11'
                         and po1.offer_sub_type = 'T01'
                       order by E_PROD_OFFER_ID, KXB_PROD_OFFER_ID) loop
    select count(*)
          into v_cnt
          from prod_offer_rel por
         where por.offer_a_id = KXOFFER.e_Prod_Offer_Id
           and por.offer_z_id = KXOFFER.KXB_PROD_OFFER_ID
           and por.relation_type_cd = '100000';
        if v_cnt = 0 then
          insert into PROD_OFFER_REL
            (PROD_OFFER_RELA_ID,
             OFFER_A_ID,
             OFFER_Z_ID,
             ROLE_CD,
             RELATION_TYPE_CD,
             EFF_DATE,
             EXP_DATE,
             STATUS_CD,
             STATUS_DATE,
             CREATE_DATE,
             UPDATE_DATE,
             HOT_SPOT_NO,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             SYNC_CUST,
             EFFECTIVE_TYPE,
             DEFAULT_TIME_PERIOD,
             EXPIRE_TYPE,
             RULE_TYPE)
          values
            (SEQ_PROD_OFFER_REL_ID.Nextval,
             KXOFFER.e_Prod_Offer_Id,
             KXOFFER.Kxb_Prod_Offer_Id,
             null,
             '100000',
             sysdate,
             null,
             '1000',
             sysdate,
             sysdate,
             null,
             null,
             1,
             1,
             49822,
             49822,
             null,
             null,
             null,
             null,
             null);
       end if;
    end loop;
  end;
/
