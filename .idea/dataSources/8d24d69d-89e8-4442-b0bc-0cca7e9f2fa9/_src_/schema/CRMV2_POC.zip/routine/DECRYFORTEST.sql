CREATE procedure           decryfortest(srcstr in varchar2, desstr out varchar2, errcode out integer,errmsg out varchar2) is
       i number;
       j integer;
       m integer;
       n integer;
       keystr varchar2(32);
       tmpstr varchar2(2);

      FUNCTION hex_to_dec (hexin IN VARCHAR2) RETURN NUMBER IS
        v_charpos NUMBER;
        v_charval CHAR(1);
        v_return NUMBER DEFAULT 0;
        v_power NUMBER DEFAULT 0;
        v_string VARCHAR2(2000);
      BEGIN
        v_string := UPPER(hexin);
        v_charpos := LENGTH(v_string);
        WHILE v_charpos > 0 LOOP
          v_charval := SUBSTR(v_string,v_charpos,1);
          IF v_charval BETWEEN '0' AND '9' THEN
            v_return := v_return + TO_NUMBER(v_charval) * POWER(16,v_power);
          ELSE
            IF v_charval = 'A' THEN
              v_return := v_return + 10 * POWER(16,v_power);
            ELSIF v_charval = 'B' THEN
              v_return := v_return + 11 * POWER(16,v_power);
            ELSIF v_charval = 'C' THEN
              v_return := v_return + 12 * POWER(16,v_power);
            ELSIF v_charval = 'D' THEN
              v_return := v_return + 13 * POWER(16,v_power);
            ELSIF v_charval = 'E' THEN
              v_return := v_return + 14 * POWER(16,v_power);
            ELSIF v_charval = 'F' THEN
              v_return := v_return + 15 * POWER(16,v_power);
            ELSE
              raise_application_error(-20621,'Invalid input');
            END IF;
          END IF;
          v_charpos := v_charpos - 1;
          v_power := v_power + 1;
        END LOOP;
        RETURN v_return;
      END hex_to_dec;
begin
     errcode := 0;
     errmsg  := '';

     j:= 1;
     i:= 1;
     keystr := '*bv_.azqadec;d7efbikop,01-fre382';

     if(length(srcstr)>500) or (mod(length(srcstr),2) =1) or (srcstr is null) then
        errcode := 1;
        errmsg := 'length of source string is error!';
        return;
     end if;

     while(i<length(srcstr)) loop
     begin
          tmpstr := substr(srcstr,i,2);

          m := ascii(substr(keystr,j,1));
          n := hex_to_dec(tmpstr);

          desstr := desstr || chr(m+n-bitand(m,n)*2) ;

          j:=j+1;
          i:=i+2;
     Exception
        When Others Then
          errcode :=2;
          errmsg := 'content of source string is error!';
          return;
     end;
     end loop;

end decryfortest;
/
