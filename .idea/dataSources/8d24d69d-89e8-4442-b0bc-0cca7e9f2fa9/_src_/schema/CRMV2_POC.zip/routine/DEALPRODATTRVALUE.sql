CREATE procedure           dealProdAttrValue is
  cursor prod_attr_value is
    select * from temp_hmm_prod_spec_value;
begin
  for rec in prod_attr_value loop
    --检查属性值是否已经写入到公用属性中
    declare
      v_value_count       number(12);
      v_parent_attr_id    number(12);
      v_value_id          number(12);
      v_parent_attr_count number(12);
    BEGIN
      --查询属性值是否已经在共有属性中
      --查询属性值上级对应的属性ID
      SELECT count(*)
        into v_parent_attr_count
        from temp_hmm_prod_fea_spec b, temp_hmm_attr_spec c
       where b.fea_spec_id in (select a.fea_id_a
                                 from temp_hmm_prod_fea_spec_rela a
                                where a.fea_id_b = rec.fea_spec_id
                                  AND RELA_TYPE = '0'
                                  and rownum < 2)
         and c.attr_cd = b.code
         and c.attr_name = b.name;
      if v_parent_attr_count > 0 then
        SELECT c.attr_id
          into v_parent_attr_id
          from temp_hmm_prod_fea_spec b, temp_hmm_attr_spec c
         where b.fea_spec_id in (select a.fea_id_a
                                   from temp_hmm_prod_fea_spec_rela a
                                  where a.fea_id_b = rec.fea_spec_id
                                    AND RELA_TYPE = '0'
                                    and rownum < 2)
           and c.attr_cd = b.code
           and c.attr_name = b.name;
      end if;
      --判断属性值是否存在公有属性中
      SELECT COUNT(*)
        INTO v_value_count
        FROM TEMP_HMM_ATTR_VALUE M
       WHERE M.ATTR_VALUE = rec.code
         and m.attr_value_name = rec.name;
      if v_value_count = 0 then
        select SEQ_ATTR_VALUE.NEXTVAL into v_value_id from dual;
        --插入属性值
        INSERT INTO TEMP_HMM_ATTR_VALUE
          (ATTR_VALUE_ID, ATTR_VALUE_NAME, ATTR_ID, ATTR_VALUE)
          SELECT v_value_id, REC.NAME, v_parent_attr_id, rec.code
            from dual;
      else
        --查询属性值
        SELECT ATTR_VALUE_ID, ATTR_ID
          INTO v_value_id, v_parent_attr_id
          FROM TEMP_HMM_ATTR_VALUE M
         WHERE M.ATTR_VALUE = rec.code
           and m.attr_value_name = rec.name;
      end if;
      --插入产品的选择属性
      INSERT INTO TEMP_HMM_PROD_ATTR_VALUE
        (PROD_ATTR_VALUE_ID,
         PRODUCT_ATTR_ID,
         ATTR_VALUE_ID,
         OLD_FEA_SPEC_ID)
        SELECT SEQ_PROD_ATTR_VALUE.NEXTVAL,
               v_parent_attr_id,
               v_value_id,
               rec.fea_spec_id
          from dual;
    END;
    commit;
  end loop;
end dealProdAttrValue;
/
