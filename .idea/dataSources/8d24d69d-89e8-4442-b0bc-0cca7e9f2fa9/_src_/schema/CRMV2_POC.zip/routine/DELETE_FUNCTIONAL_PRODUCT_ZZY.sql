CREATE PROCEDURE           delete_functional_product_zzy
/***************************************************************
    FUN NAME: 只删除功能类产品档案，不送外围施工
    VERSION: V1.0.0
    AUTHOR: zengx
    CREATE_DATE: 20130101
    功能说明：只删除功能类产品档案，不送外围施工
  ****************************************************************/
(v_prod_inst_id IN NUMBER, -- 功能类产品实例id
 iremark        IN VARCHAR2, --修改备注
 modi_man       IN VARCHAR2, --修改人
 o_msg          OUT VARCHAR2) IS
  --执行过程返回信息
  v_prod_func_type     crmv2.product.prod_func_type%TYPE;
  v_prod_offer_inst_id crmv2.prod_offer_inst.prod_offer_inst_id%TYPE;
  v_offer_type         crmv2.prod_offer.offer_type%TYPE;
  v_offer_sub_type     crmv2.prod_offer.offer_sub_type%TYPE;
BEGIN

  BEGIN
    SELECT c.prod_func_type
      INTO v_prod_func_type
      FROM crmv2.prod_inst b, crmv2.product c
     WHERE b.prod_inst_id = v_prod_inst_id
       AND b.status_cd = 100000
       AND b.product_id = c.product_id;
  EXCEPTION
    WHEN OTHERS THEN
      o_msg := v_prod_inst_id || '产品ID不存在!!';
      RETURN;
  END;

  BEGIN
    SELECT b.prod_offer_inst_id, c.offer_type, c.offer_sub_type
      INTO v_prod_offer_inst_id, v_offer_type, v_offer_sub_type
      FROM crmv2.offer_prod_inst_rel a,
           crmv2.prod_offer_inst     b,
           crmv2.prod_offer          c
     WHERE a.prod_inst_id = v_prod_inst_id
       AND a.status_cd = 1000
       AND a.prod_offer_inst_id = b.prod_offer_inst_id
       AND b.prod_offer_id = c.prod_offer_id;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  IF v_prod_func_type NOT IN ('102') THEN
    o_msg := '只能删除功能类产品，不删除其他类型产品！';
    RETURN;
  END IF;

  --删除产品
  INSERT INTO crmv2.prod_inst_his
    SELECT prod_inst_id,
           product_id,
           acc_prod_inst_id,
           address_id,
           owner_cust_id,
           payment_mode_cd,
           product_password,
           important_level,
           area_code,
           acc_nbr,
           exch_id,
           common_region_id,
           remark,
           pay_cycle,
           begin_rent_time,
           stop_rent_time,
           finish_time,
           stop_status,
           110000,
           create_date,
           status_date,
           update_date,
           proc_serial,
           use_cust_id,
           ext_prod_inst_id,
           address_desc,
           area_id,
           update_staff,
           create_staff,
           crmv2.seq_prod_inst_his_id.nextval,
           SYSDATE,
           account,
           community_id,
           version,
           '','',''
      FROM crmv2.prod_inst
     WHERE prod_inst_id = v_prod_inst_id
       AND status_cd = 100000;
 /* INSERT INTO itsc_crmv2.del_t02_prod_bak_zzy
    (table_name, col_name, key_id, insert_date,AREA_ID)
    SELECT 'prod_inst', 'prod_inst_id', prod_inst_id, SYSDATE,area_id
      FROM crmv2.prod_inst
     WHERE prod_inst_id = v_prod_inst_id
       AND status_cd = 100000;*/

  DELETE FROM crmv2.prod_inst
   WHERE prod_inst_id = v_prod_inst_id
     AND status_cd = 100000;
  COMMIT;
  /*    itsc_crmv2.new_p_ins_billing_update('prod_inst',
  'prod_inst_id',
  v_prod_inst_id,
  iremark,
  modi_man);*/
  --删除产品属性
  FOR rec IN (SELECT *
                FROM crmv2.prod_inst_attr
               WHERE prod_inst_id = v_prod_inst_id
                 AND status_cd = 1000) LOOP

    INSERT INTO crmv2.prod_inst_attr_his
      SELECT prod_inst_attr_id,
             prod_inst_id,
             attr_id,
             attr_value_id,
             attr_value,
             1100,
             status_date,
             eff_date,
             SYSDATE,
             create_date,
             update_date,
             proc_serial,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             crmv2.seq_prod_inst_attr_his_id.nextval,
             SYSDATE,
             version
        FROM crmv2.prod_inst_attr
       WHERE prod_inst_id = v_prod_inst_id
         AND status_cd = 1000;
  /*  INSERT INTO itsc_crmv2.del_t02_prod_bak_zzy
      (table_name, col_name, key_id, insert_date,AREA_ID)
      SELECT 'PROD_INST_ATTR',
             'PROD_INST_ATTR_ID',
             prod_inst_attr_id,
             SYSDATE,AREA_ID
        FROM crmv2.prod_inst_attr
       WHERE prod_inst_id = v_prod_inst_id
         AND status_cd = 1000;*/

    DELETE FROM crmv2.prod_inst_attr
     WHERE prod_inst_id = v_prod_inst_id
       AND status_cd = 1000;
    COMMIT;
    /* itsc_crmv2.new_p_ins_billing_update('prod_inst_attr',
    'prod_inst_attr_id',
    rec.prod_inst_attr_id,
    iremark,
    modi_man);*/

  END LOOP;

  IF v_offer_type IN (10, 11) AND v_offer_sub_type IN ('T02') THEN
    --删除销售品
    INSERT INTO crmv2.prod_offer_inst_his
      SELECT prod_offer_inst_id,
             prod_offer_id,
             cust_id,
             channel_id,
             create_date,
             1100,
             status_date,
             eff_date,
             SYSDATE,
             region,
             update_date,
             proc_serial,
             ext_prod_offer_inst_id,
             NULL,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             crmv2.seq_prod_offer_inst_his_id.nextval,
             SYSDATE,
             trial_eff_date,
             trial_exp_date,
             service_nbr,
             version,
             remark,
             ext_flag2,
             wh_remark,
             ext_flag1
        FROM crmv2.prod_offer_inst
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd = 1000;
   /* INSERT INTO itsc_crmv2.del_t02_prod_bak_zzy
      (table_name, col_name, key_id, insert_date,AREA_ID)
      SELECT 'PROD_OFFER_INST',
             'PROD_OFFER_INST_ID',
             prod_offer_inst_id,
             SYSDATE,AREA_ID
        FROM crmv2.prod_offer_inst
       WHERE prod_offer_inst_id = v_prod_offer_inst_id
         AND status_cd = 1000;*/

    DELETE FROM crmv2.prod_offer_inst
     WHERE prod_offer_inst_id = v_prod_offer_inst_id
       AND status_cd = 1000;
    COMMIT;
    /* itsc_crmv2.new_p_ins_billing_update('prod_offer_inst',
    'prod_offer_inst_id',
    v_prod_offer_inst_id,
    iremark,
    modi_man);*/
  END IF;
  --删除产品销售品关联
  FOR rec IN (SELECT *
                FROM crmv2.offer_prod_inst_rel
               WHERE prod_inst_id = v_prod_inst_id
                 AND status_cd = 1000) LOOP

    INSERT INTO crmv2.offer_prod_inst_rel_his
      SELECT offer_prod_inst_rel_id,
             prod_inst_id,
             prod_offer_inst_id,
             role_cd,
             offer_prod_inst_rel_role_id,
             1100,
             status_date,
             create_date,
             eff_date,
             SYSDATE,
             update_date,
             proc_serial,
             offer_prod_rel_id,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             crmv2.seq_offer_prod_inst_rel_his_id.nextval,
             SYSDATE,
             ext_flag
        FROM crmv2.offer_prod_inst_rel
       WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
         AND status_cd = 1000;
   /* INSERT INTO itsc_crmv2.del_t02_prod_bak_zzy
      (table_name, col_name, key_id, insert_date,AREA_ID)
      SELECT 'OFFER_PROD_INST_REL',
             'OFFER_PROD_INST_REL_ID',
             offer_prod_inst_rel_id,
             SYSDATE,AREA_ID
        FROM crmv2.offer_prod_inst_rel
       WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
         AND status_cd = 1000;*/

    DELETE FROM crmv2.offer_prod_inst_rel
     WHERE offer_prod_inst_rel_id = rec.offer_prod_inst_rel_id
       AND status_cd = 1000;
    COMMIT;
    /*  itsc_crmv2.new_p_ins_billing_update('offer_prod_inst_rel',
    'offer_prod_inst_rel_id',
    rec.offer_prod_inst_rel_id,
    iremark,
    modi_man);*/

  END LOOP;
  --删除产品关联
  FOR rec IN (SELECT *
                FROM crmv2.prod_inst_rel
               WHERE prod_inst_z_id = v_prod_inst_id
                 AND status_cd = 1000
                 AND relation_type_cd = '100600') LOOP

    INSERT INTO crmv2.prod_inst_rel_his
      SELECT prod_inst_rel_id,
             prod_inst_a_id,
             prod_inst_z_id,
             relation_type_cd,
             prod_inst_rel_role_id,
             role_cd,
             eff_date,
             SYSDATE,
             create_date,
             1100,
             status_date,
             update_date,
             proc_serial,
             product_rel_id,
             area_id,
             region_cd,
             update_staff,
             create_staff,
             crmv2.seq_prod_inst_rel_his_id.nextval,
             SYSDATE
        FROM crmv2.prod_inst_rel
       WHERE prod_inst_z_id = v_prod_inst_id
         AND status_cd = 1000
         AND relation_type_cd = '100600';
   /* INSERT INTO itsc_crmv2.del_t02_prod_bak_zzy
      (table_name, col_name, key_id, insert_date,AREA_ID)
      SELECT 'PROD_INST_REL', 'PROD_INST_REL_ID', prod_inst_rel_id, SYSDATE,AREA_ID
        FROM crmv2.prod_inst_rel
       WHERE prod_inst_z_id = v_prod_inst_id
         AND status_cd = 1000
         AND relation_type_cd = '100600';*/

    DELETE FROM crmv2.prod_inst_rel
     WHERE prod_inst_z_id = v_prod_inst_id
       AND status_cd = 1000
       AND relation_type_cd = '100600';
    COMMIT;
    /* itsc_crmv2.new_p_ins_billing_update('prod_inst_rel',
    'prod_inst_rel_id',
    rec.prod_inst_rel_id,
    iremark,
    modi_man);*/

  END LOOP;
    --单独送计费接口
/*  FOR rec IN (SELECT * FROM itsc_crmv2.del_t02_prod_bak_zzy) LOOP
    itsc_crmv2.new_p_ins_billing_update(rec.table_name, rec.col_name,
                                        rec.key_id, iremark, modi_man);
  END LOOP;
*/

  COMMIT;
  o_msg := '修改成功！';
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    o_msg := v_prod_inst_id || SQLERRM;
END;
/
