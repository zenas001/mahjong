CREATE PROCEDURE           Q_OFFER_TRANS(i_order_item_id IN NUMBER,
                                          I_ACTION_TYPE   IN VARCHAR2) IS
  V_OFFER_SEQ           NUMBER;
  V_CUST_ORDER_ID       NUMBER;
  V_PROD_OFFER_INST_ID  NUMBER;
  I_AUTOTEST_MEMBER_SEQ NUMBER;
  C_ACTION_ADD CONSTANT VARCHAR2(5) := 'ADD';
  C_ACTION_MOD CONSTANT VARCHAR2(5) := 'MOD';
  C_ACTION_DEL CONSTANT VARCHAR2(5) := 'DEL';
BEGIN
  -- SELECT * FROM ORDER_ITEM_HIS WHERE CLASS_ID=6 AND ENTT_SPEC_TYPE='BO';

  V_OFFER_SEQ := SEQ_AUTOTEST_OFFER_ID.NEXTVAL;
  select cust_order_id
    INTO V_CUST_ORDER_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  select order_item_obj_id
    INTO V_PROD_OFFER_INST_ID
    from crmv2.order_item_his
   where order_item_id = i_order_item_id
     and rownum < 2;
  select a_order_item_id
    into I_AUTOTEST_MEMBER_SEQ
    from order_item_rel_his
   where z_order_item_id = i_order_item_id
     and rownum < 2;

  IF I_ACTION_TYPE = C_ACTION_ADD THEN
    --ADD
    insert into autotest_offer
      (AUTOTEST_OFFER_ID,
       CUST_ORDER_ID,
       AUTOTEST_MEMBER_ID,
       EXT_OFFER_NBR,
       ROLE_CD,
       ROLE_CODE,
       VIRTUAL_OFFER_INST_ID,
       RELA_OFFERVIRTUALID,
       ACTION,
       CREATE_DATE)
      select V_OFFER_SEQ AUTOTEST_OFFER_ID,
             V_CUST_ORDER_ID CUST_ORDER_ID,
             I_AUTOTEST_MEMBER_SEQ AUTOTEST_MEMBER_ID,
             b.EXT_OFFER_NBR,
             (select c.role_cd
                from crmv2.prod_offer_inst_rel c
               where c.related_prod_offer_inst_id = V_PROD_OFFER_INST_ID
                 and rownum < 2) role_cd,
             (select role_code
                from crmv2.prod_offer_inst_rel  c,
                     crmv2.prod_offer_rela_role d
               where c.related_prod_offer_inst_id = V_PROD_OFFER_INST_ID
                 and d.role_cd = c.role_cd
                 and rownum < 2) role_code,
             null VIRTUAL_OFFER_INST_ID,
             (select c.rela_prod_offer_inst_id
                from crmv2.prod_offer_inst_rel c
               where c.related_prod_offer_inst_id = V_PROD_OFFER_INST_ID
                 and rownum < 2) RELA_OFFERVIRTUALID,
             C_ACTION_ADD ACTION,
             sysdate CREATE_DATE
        from crmv2.prod_offer_inst a, crmv2.prod_offer b
       where a.prod_offer_id = b.prod_offer_id
         and a.prod_offer_inst_id = V_PROD_OFFER_INST_ID;

    ---销售品属性
    insert into autotest_offer_attr
      (AUTOTEST_OFFER_ATTR_ID,
       AUTOTEST_OFFER_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      select SEQ_AUTOTEST_OFFER_ATTR_ID.NEXTVAL AUTOTEST_OFFER_ATTR_ID,
             V_OFFER_SEQ                        AUTOTEST_PROD_ID,
             c.ext_attr_nbr,
             a.ATTR_VALUE_ID,
             a.ATTR_VALUE,
             sysdate
        from crmv2.prod_offer_inst_attr a, CRMV2.ATTR_SPEC c
       where a.prod_offer_inst_id = V_PROD_OFFER_INST_ID
         and a.ATTR_ID = c.ATTR_ID;

  ELSIF I_ACTION_TYPE = C_ACTION_MOD THEN
    --mod
    insert into autotest_offer
      (AUTOTEST_OFFER_ID,
       CUST_ORDER_ID,
       AUTOTEST_MEMBER_ID,
       EXT_OFFER_NBR,
       ROLE_CD,
       ROLE_CODE,
       VIRTUAL_OFFER_INST_ID,
       RELA_OFFERVIRTUALID,
       ACTION,
       CREATE_DATE)
      select V_OFFER_SEQ           AUTOTEST_OFFER_ID,
             V_CUST_ORDER_ID       CUST_ORDER_ID,
             I_AUTOTEST_MEMBER_SEQ AUTOTEST_MEMBER_ID,
             b.EXT_OFFER_NBR,
             null,
             null,
             null,
             null,
             C_ACTION_MOD,
             sysdate
        from crmv2.prod_offer_inst a, crmv2.prod_offer b
       where a.prod_offer_id = b.prod_offer_id
         and a.prod_offer_inst_id = V_PROD_OFFER_INST_ID;
    ---销售品属性
    insert into autotest_offer_attr
      (AUTOTEST_OFFER_ATTR_ID,
       AUTOTEST_OFFER_ID,
       EXT_ATTR_NBR,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE)
      select SEQ_AUTOTEST_OFFER_ATTR_ID.NEXTVAL AUTOTEST_OFFER_ATTR_ID,
             V_OFFER_SEQ                        AUTOTEST_PROD_ID,
             c.ext_attr_nbr,
             null,
             a.new_value,
             sysdate
        from crmv2.order_item_proc_attr_his a, CRMV2.ATTR_SPEC c
       where a.order_item_id = i_order_item_id
         and a.class_id = -6
         and a.OBJ_ATTR_ID = c.ATTR_ID;

  ELSE
    insert into autotest_offer
      (AUTOTEST_OFFER_ID,
       CUST_ORDER_ID,
       AUTOTEST_MEMBER_ID,
       EXT_OFFER_NBR,
       ROLE_CD,
       ROLE_CODE,
       VIRTUAL_OFFER_INST_ID,
       RELA_OFFERVIRTUALID,
       ACTION,
       CREATE_DATE)
      select V_OFFER_SEQ           AUTOTEST_OFFER_ID,
             V_CUST_ORDER_ID       CUST_ORDER_ID,
             I_AUTOTEST_MEMBER_SEQ AUTOTEST_MEMBER_ID,
             b.EXT_OFFER_NBR,
             null,
             null,
             null,
             null,
             C_ACTION_DEL,
             sysdate
        from crmv2.prod_offer_inst a, crmv2.prod_offer b
       where a.prod_offer_id = b.prod_offer_id
         and a.prod_offer_inst_id = V_PROD_OFFER_INST_ID;

  END IF;
END Q_OFFER_TRANS;
/
