CREATE procedure           rela_obj_so_restrict_contrast is

begin
  null;
end;
/
