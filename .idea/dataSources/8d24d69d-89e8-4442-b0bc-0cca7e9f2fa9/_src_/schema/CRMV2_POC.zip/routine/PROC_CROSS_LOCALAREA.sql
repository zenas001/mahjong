CREATE procedure           proc_cross_localarea(cust_num       in varchar2, --客户编码
                                                 accnbrs_regins in varchar2, --业务号码、区域
                                                 main_accnbr_regin in varchar2,--主号的业务号码与区域
                                                 op_flag        in varchar2,--操作标识
                                                 o_result       out varchar2) is
  i_cust_count number := 0;
  i_prod_count number := 0;
  i_cy_seq     number;
  i_kh_seq     number;
  i_cust_id    number;
  i_party_id   number;
  i_batch_id   number;
  cursor i_acc_nbr is
    select * from table(fnc_crmv2_get_sub_str(accnbrs_regins, ','));
  /**
   功能说明：crm2.0跨本地网业务，crm2.0的客户、产品、账户同步到1.0中
   author：luxb
   创建时间：2012-4-14
  **/
begin
  /**先通过客户编码查询crm1.0中这个客户是否存在，不存在则添加**/
  select count(khid) into i_cust_count
    from crm.kh@LK_TOCRM1_CROSS
   where khbm = cust_num;
  --获取客户ID
  select cust_id,party_id into i_cust_id,i_party_id from cust where cust_number = cust_num;
  --获取同步批次号
  select seq_cross_localarea_batch_id.nextval into i_batch_id from dual;
  if i_cust_count = 0 then
    --插入数据到客户
    o_result := '添加参与人信息错误';
    select crm.cyid_seq.nextval@LK_TOCRM1_CROSS into i_cy_seq from dual;
    --参与人信息添加
    insert into crm.cy@LK_TOCRM1_CROSS
      (cyid, --参与人id
       cymc, --参与人名称
       cyzl, --常用证件类型
       cymk, --常用证件号码
       cyrq, --生成日期
       cyzt, --参与人状态
       cyjp, --名称简拼
       cypm, --英文名称
       cylx, --参与人类型
       cygr, --修改日期
       identify_addr, --证件地址
       region, --区域
       ext_flag1 --虚拟档案标识‘Y’代表虚档案
       )
      select i_cy_seq,
             p.party_name,
             pc.cert_type,
             pc.cert_number,
             sysdate,
             '10A',
             p.party_abbrname,
             p.english_name,
             p.party_type,
             sysdate,
             pc.cert_address,
             p.region_cd,
             'Y'
        from party p,party_certification pc
       where p.party_id = i_party_id
         and p.party_id = pc.party_id;

    proc_cross_ins_billing_update('V_PARTY',i_cy_seq,'PARTY_ID');
    --同步日志
    proc_cross_localarea_log('PARTY',i_cy_seq,i_party_id,i_batch_id,'同步参与人表');
    --客户信息添加
    o_result := '添加客户信息错误';
    select crm.khid_seq.nextval@LK_TOCRM1_CROSS into i_kh_seq from dual;
    insert into crm.kh@LK_TOCRM1_CROSS
      (khid, --客户id
       khcy, --参与人id
       khzy, --客户重要标识
       khxz, --客户类型
       khzt, --客户状态
       khbm, --客户编码
       khlx, --客户行业
       khrq, --生成日期
       khgr, --修改日期
       khxd, --客户级别
       khqy, --客户区域
       main_group_id, --战略群标识
       correspondent,
       cust_year_type,
       ext_flag1)
      select i_kh_seq,
             i_cy_seq,
             decode(c.important_level,'','3',c.important_level),
             decode(c.cust_type,'1000','1','3'),
             '10A',
             c.cust_number,
             substr(c.industry_cd,0,5),
             sysdate,
             sysdate,
             c.cust_area_grade,
             c.region_cd,
             decode(c.cust_type,'1000','1','3'),
             c.cust_address,
             c.cur_year_type,
             'Y'
        from cust c
       where c.cust_number = cust_num;
       proc_cross_ins_billing_update('V_CUST',i_kh_seq,'CUST_ID');
       --同步日志
       proc_cross_localarea_log('CUST',i_kh_seq,i_cust_id,i_batch_id,'同步客户表');
  else
    select khid
      into i_kh_seq
      from crm.kh@LK_TOCRM1_CROSS
     where khbm = cust_num;
  end if;
  --同步产品信息
  o_result := '产品信息同步';
  for rec2 in i_acc_nbr loop
    declare
      v_acc_nbr         varchar(20);
      v_region_cd       varchar(10);
      v_num             number := 0;
      v_prod_id         number;
      v_fprod_id        number;
      v_mdse_id         number;
      v_vmdse_id        number;
      v_fmdse_id        number;
      v_acct_count      number := 0;
      v_prod_inst_id    number;
      v_prod_offer_inst_id number;
      v_tel_acct_id_seq number;
      v_zgid_seq        number;
      v_mdse_rela_seq   number;
      v_payment_plan_seq number;
      v_prod_inst_acct_id number;
      v_payment_plan_id number;
      v_mdse_idb        number;
      v_mdse_ida        number;
      v_attr_num        number;
      v_prod_fea_id1    number;
      v_prod_fea_id2    number;
      v_prod_fea_id3    number;
      v_prod_fea_id4    number;
      v_prod_fea_id5    number;
      v_prod_fea_id6    number;
      v_prod_fea_id7    number;
      v_prod_fea_id8    number;
      v_prod_fea_id     number;
      v_prod_offer_id   number;
      v_mdse_price_rela_id number;
      v_tycy_pid        number;
      v_tycy_count      number := 0;
      v_zfk_id          number;
      v_fk_id           number;
      v_vpn_prod_id     number;
      v_vpn_offer_id    number;
      v_xprod_id        number;
      v_xmdse_id        number;
      v_zh_id           number;
      v_product_id      number;
      v_ext_prod_id     number;
      v_fea_rela_id1    number;
      v_fea_rela_id2    number;
      v_fea_rela_id3    number;
      v_is_count        number;
      v_is_count2       number;
      v_attr_count      number;
      v_acc_nbr2         varchar2(50);
      v_mdse_rela1      number;
      v_mdse_rela2      number;
      v_group_count     number;
      v_group_cust      number;
      V_exist_count     number;
      v_vpn_count       number;
      cursor t_acc_nbr is
        select * from table(fnc_crmv2_get_sub_str(rec2.column_value, '|'));
      cursor mc_acc_nbr is
        select * from table(fnc_crmv2_get_sub_str(main_accnbr_regin, '|'));
      cursor i_acct is
        select a.account_number,a.account_id
          from prod_inst_acct pia, account a
         where pia.prod_inst_id = v_prod_inst_id
           and pia.account_id = a.account_id;
      cursor i_prod_rel is
        select pi.prod_inst_id
          from prod_inst_rel r, prod_inst pi
         where r.prod_inst_a_id = pi.prod_inst_id
           and pi.product_id in (800000251,800299131) --ivpn 集团IVPN--军翼网
           and r.prod_inst_z_id = v_prod_inst_id;

      cursor i_prod_offer_rel is
        select poi.prod_offer_id
          from prod_offer_inst_rel r,prod_offer_inst poi
         where r.rela_prod_offer_inst_id = v_prod_offer_inst_id
           and r.related_prod_offer_inst_id = poi.prod_offer_inst_id
           and poi.prod_offer_id in ('800008424','800625509','800624316','800776106','800618435','800615003');
      --产品关联的销售品
      cursor i_prod_offer_inst_rel is
      select poi.prod_offer_inst_id,poi.prod_offer_id,po.offer_sub_type
       from offer_prod_inst_rel r,prod_offer_inst poi,prod_offer po
      where r.prod_inst_id = v_prod_inst_id
        and r.prod_offer_inst_id = poi.prod_offer_inst_id
        and poi.prod_offer_id = po.prod_offer_id
        and po.offer_sub_type not in ('T04','T01');
      --产品关联信息
      cursor i_prod_inst_rel is
      select r.prod_inst_z_id,pi.acc_nbr,pi.area_code
        from prod_inst_rel r, prod_inst pi, product p
      where r.prod_inst_a_id = v_prod_inst_id
        and r.prod_inst_z_id = pi.prod_inst_id
        and pi.product_id = p.product_id
        and p.prod_func_type = '101';
    begin
      for tt in t_acc_nbr loop
        if v_num = 0 then
          v_acc_nbr := tt.column_value;
          v_num     := v_num + 1;
        else
          if v_num = 1 then
            v_region_cd := tt.column_value;
          end if;
        end if;
      end loop;
      if op_flag = '0' then --2.0群组销售品同步
       select count(1) into v_vpn_count from prod@lk_tocrm1_cross where account = v_acc_nbr and region in ('2') and area_code = '0591' and ext_flag1='Y';
       --delete mdse@lk_tocrm1_cross where mdse_serv_number = v_acc_nbr and region in ('2') and ext_flag1='Y';

       --delete prod@lk_tocrm1_cross where account = v_acc_nbr and region in ('2') and area_code = '0591' and ext_flag1='Y';
       if v_vpn_count = 0 then
        --获取2.0销售品ID
         select prod_offer_inst_id,prod_offer_id
           into v_prod_offer_inst_id,v_prod_offer_id
           from prod_offer_inst poi
          where poi.service_nbr = v_acc_nbr
            and region_cd = v_region_cd;
         o_result := '添加VPN群产品信息错误';
         --校园vpn ttp16878
         if v_prod_offer_id =800001394 then
          select COUNT(1) INTO V_exist_count from crm.prod@lk_tocrm1_cross where account = 'FZGJ'||v_acc_nbr;
          if V_exist_count = 1 then
            select p.property_custid into i_kh_seq from crm.prod@lk_tocrm1_cross p
            where p.account = 'FZGJ'||v_acc_nbr;
          else
              i_kh_seq := 33250689;
          end if;
         end if;
         select crm.prod_id_seq.nextval@LK_TOCRM1_CROSS into v_xprod_id from dual;
        insert into crm.prod@LK_TOCRM1_CROSS
          (prod_id, --id
           property_custid, --产权客户标识
           cust_id, --使用客户标识
           prod_spec_id, --产品规格标识
           create_date, --生成时间
           modify_date, --修改时间
           staff, --操作员工号
           state, --状态
           prod_spec_type, --产品规格类型
           service_code, --业务号码
           address_id, --地址id
           stop_status, --停机状态
           exch_id, --局向
           region, --区域
           area_code, --区号
           acct_cycle, --帐务周期类型
           pay_type, --付费方式
           rent_date, --起租日
           remark, --备注
           account, --业务号码
           address_name, --地址名称
           real_modify_date,
           ext_flag1)
          select v_xprod_id,
                 i_kh_seq,
                 i_kh_seq,
                 594001183,
                 sysdate,
                 sysdate,
                 pi.create_staff,
                 '70A',
                 '103',
                 v_acc_nbr,
                 '',
                 '0',
                 '',
                 cr.up_region_id,
                 '0591',
                 '003',
                 '1',
                 pi.status_date,
                 '',
                 v_acc_nbr,
                 '',
                 sysdate,
                 'Y'
            from prod_offer_inst pi, common_region cr
           where pi.prod_offer_inst_id = v_prod_offer_inst_id
             and pi.region_cd = cr.common_region_id;

         proc_cross_ins_billing_update('V_PROD',v_xprod_id,'PROD_ID');
         --同步日志
         proc_cross_localarea_log('PROD',v_xprod_id,'0',i_batch_id,'同步产品表');
         o_result := '添加VPN群销售品信息错误';
         select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS
          into v_xmdse_id
          from dual;
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_xmdse_id,
                 600013680,
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 v_xprod_id,
                 '108',
                 sysdate,
                 cr.up_region_id,
                 sysdate,
                 sysdate,
                 v_acc_nbr2,
                 'Y'
            from prod_offer_inst poi,common_region cr
           where poi.prod_offer_inst_id = v_prod_offer_inst_id
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_xmdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_xmdse_id,'0',i_batch_id,'同步销售品表');

        o_result := '添加群组销售品信息错误';
        select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS
          into v_mdse_id
          from dual;
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_mdse_id,
                 decode(pz.default_value, '', '610290109', pz.default_value),
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 0,
                 decode(pz.attr_desc,'','101',pz.attr_desc),
                 poi.status_date,
                 cr.up_region_id,
                 poi.eff_date,
                 poi.update_date,
                 poi.service_nbr,
                 'Y'
            from prod_offer_inst poi,
                 (select a.java_code,a.attr_desc,a.default_value
                    from sys_class sc, attr_spec a
                   where sc.java_code = 'ProdOfferIdRel'
                     and sc.class_id = a.class_id) pz, common_region cr
           where poi.prod_offer_inst_id = v_prod_offer_inst_id
             and poi.prod_offer_id = pz.java_code(+)
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_mdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_mdse_id,v_prod_offer_inst_id,i_batch_id,'同步销售品表');

        o_result := '添加总机服务与vpn群商品信息错误';
        select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross
          into v_mdse_rela2
          from dual;
        insert into crm.mdse_rela@lk_tocrm1_cross
          (RELA_ID,
           MDSE_IDB,
           RELA_TYPE,
           STATE,
           MDSE_IDA,
           CREATE_DATE,
           MODIFY_DATE,
           a_region,
           b_region,
           ext_flag1)
          select v_mdse_rela2,
                 v_xmdse_id,
                 '151',
                 '70A',
                 v_mdse_id,
                 sysdate,
                 sysdate,
                 2,
                 2,
                 'Y'
            from dual;

        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela2,'RELA_ID');
        proc_cross_localarea_log('MDSE_RELA', v_mdse_rela2, null,i_batch_id,'同步群组套餐跟vpn套餐的关联关系');

        select crm.zgid_seq.nextval@LK_TOCRM1_CROSS
            into v_zgid_seq
            from dual;
        insert into crm.zg@lk_tocrm1_cross (ZGID, ZGZR, ZGZH, ZGZL, ZGFF, ZGXE, ZGXS, ZGRQ, ZGGR, ZGZT, ZGFG, ZGTL, ZGFP, ZGQY, ZGFL, REAL_MODIFY_DATE, EXT_FLAG1)
        values (v_zgid_seq, v_xprod_id, 152776023, 0, '1', 100, 1, sysdate, sysdate, '70A', '4', 'true', 0, 11, '0', sysdate, '');

        proc_cross_localarea_log('ZG',v_zgid_seq,0,i_batch_id,'同步zg表');

        /*select count(1) into v_group_count from crm.pm_group@lk_tocrm1_cross where group_id = i_kh_seq;

        if v_group_count = 0 then
        insert into crm.pm_group@lk_tocrm1_cross
        (group_id,
         descript,
         type,
         state,
         owner_cust_id,
         create_date,
         modify_date,
         region,
         real_modify_date)
        select i_kh_seq,
               p.party_name|| '-群客户',
               '4',
               '70A',
               i_kh_seq,
               sysdate,
               sysdate,
               c.region_cd,
               sysdate
          from cust c, party p
         where c.party_id = p.party_id
           and c.cust_id = i_kh_seq;
        end if;

      select count(1) into v_group_cust from crm.kh@lk_tocrm1_cross where khid = i_kh_seq and ext_flag1='Y';
      if v_group_cust =1 then
         update crm.kh@lk_tocrm1_cross set khxz='9' where khid = i_kh_seq and ext_flag1='Y';
      end if;*/
      end if;
      else
      --多次同步删除前次同步的销售品
      insert into crm.ins_billing_update@lk_tocrm1_cross
      (INS_ID, TABLE_NAME, KEY_ID, STATE, COLUMN_NAME, MODI_DATE, DEAL_NUM)
      select crm.ins_billing_update_id_seq.nextval@lk_tocrm1_cross,
             'MDSE',
             m.mdse_id,
             '10A',
             'MDSE_ID',
             sysdate,
             0
        from crm.mdse@lk_tocrm1_cross m
      where m.prod_id in
            (select p.prod_id
               from crm.prod@LK_TOCRM1_CROSS p
              where p.region = (select c.up_region_id
                                  from common_region c
                                 where c.common_region_id = v_region_cd)
                and p.account = v_acc_nbr
                and p.ext_flag1='Y')
        and m.ext_flag1='Y';

      delete from crm.mdse@lk_tocrm1_cross m
      where m.prod_id in
            (select p.prod_id
               from crm.prod@LK_TOCRM1_CROSS p
              where p.region = (select c.up_region_id
                                  from common_region c
                                 where c.common_region_id = v_region_cd)
                and p.account = v_acc_nbr
             and p.ext_flag1='Y')
       and m.ext_flag1='Y';
      --多次同步删除前次同步的产品
      insert into crm.ins_billing_update@lk_tocrm1_cross
      (INS_ID, TABLE_NAME, KEY_ID, STATE, COLUMN_NAME, MODI_DATE, DEAL_NUM)
      select crm.ins_billing_update_id_seq.nextval@lk_tocrm1_cross,
             'V_PROD',
             p.prod_id,
             '10A',
             'PROD_ID',
             sysdate,
             0
        from crm.prod@LK_TOCRM1_CROSS p
     where p.region = (select c.up_region_id
                       from common_region c
                      where c.common_region_id = v_region_cd)
       and account = v_acc_nbr
       and p.ext_flag1='Y';

      delete from crm.prod@LK_TOCRM1_CROSS p
     where p.region = (select c.up_region_id
                       from common_region c
                      where c.common_region_id = v_region_cd)
       and p.account = v_acc_nbr
       and p.ext_flag1='Y';

      select count(1)
        into i_prod_count
        from crm.prod@LK_TOCRM1_CROSS
       where region = (select c.up_region_id from common_region c where c.common_region_id =v_region_cd )
         and account = v_acc_nbr;

      select t.prod_inst_id,t.product_id,p.ext_prod_id
        into v_prod_inst_id,v_product_id,v_ext_prod_id
        from prod_inst t,product p
       where t.acc_nbr = v_acc_nbr
         and t.common_region_id = v_region_cd
         and t.product_id = p.product_id
         and t.product_id = '800000002';
      if i_prod_count = 0 then
        --插入数据prod
        o_result := '添加产品信息错误1';
        select crm.prod_id_seq.nextval@LK_TOCRM1_CROSS
          into v_prod_id
          from dual;
        insert into crm.prod@LK_TOCRM1_CROSS
          (prod_id, --id
           property_custid, --产权客户标识
           cust_id, --使用客户标识
           prod_spec_id, --产品规格标识
           create_date, --生成时间
           modify_date, --修改时间
           staff, --操作员工号
           state, --状态
           prod_spec_type, --产品规格类型
           service_code, --业务号码
           address_id, --地址id
           stop_status, --停机状态
           exch_id, --局向
           region, --区域
           area_code, --区号
           acct_cycle, --帐务周期类型
           pay_type, --付费方式
           rent_date, --起租日
           remark, --备注
           account, --业务号码
           address_name, --地址名称
           real_modify_date,
           ext_flag1)
          select v_prod_id,
                 i_kh_seq,
                 i_kh_seq,
                 p.ext_prod_id,
                 pi.create_date,
                 pi.status_date,
                 pi.create_staff,
                 '70A',
                 p.prod_func_type,
                 pi.account,
                 pi.address_id,
                 pi.stop_status,
                 pi.exch_id,
                 cr.up_region_id,
                 pi.area_code,
                 pi.pay_cycle,
                 decode(pi.payment_mode_cd,'1200','2','2100','3','1201','1'),
                 pi.begin_rent_time,
                 pi.remark,
                 pi.acc_nbr,
                 pi.address_desc,
                 pi.update_date,
                 'Y'
            from prod_inst pi, product p,common_region cr
           where pi.prod_inst_id = v_prod_inst_id
             and pi.product_id = p.product_id
             and pi.common_region_id = cr.common_region_id;

         proc_cross_ins_billing_update('V_PROD',v_prod_id,'PROD_ID');
         --同步日志
         proc_cross_localarea_log('PROD',v_prod_id,v_prod_inst_id,i_batch_id,'同步产品表');
        --销售品添加
        --IVPN或集团IVPN--军翼网时同步3个属性
        if v_product_id = 800000251
        or v_product_id = 800299131 then
        o_result := '添加网内短号长度';
        select count(*)
          into v_attr_count
          from prod_inst_attr
         where prod_inst_id = v_prod_inst_id
           and attr_id = 800000563;

        if v_attr_count = 1 then
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id1 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date)
         select v_prod_fea_id1,
                v_prod_id,
                '620024174', --网内短号长度
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate
           from dual;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id1,'PROD_FEA_ID');
        --同步日志
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id1,0,i_batch_id,'同步产品属性表');
        o_result := '添加网内短号长度值';
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id4 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date)
         select v_prod_fea_id4,
                v_prod_id,
                pf.fea_spec_id, --网内短号值
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate
           from prod_inst_attr pa,crm.prod_fea_spec@lk_tocrm1_cross pf
          where pa.prod_inst_id = v_prod_inst_id
            and pa.attr_id = 800000563
            and pa.attr_value = pf.code
            and pf.prod_spec_id = v_ext_prod_id;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id4,'PROD_FEA_ID');
        --同步日志
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id4,0,i_batch_id,'同步产品属性表');
        o_result := '添加网内短号长度上下级关系';
        select crm.fea_rela_seq.nextval@lk_tocrm1_cross into v_fea_rela_id1 from dual;
        insert into crm.fea_rela@lk_tocrm1_cross
        (rela_id,
         fea_id_a,
         fea_id_b,
         rela_type,
         create_date,
         modify_date,
         region,
         real_modify_date)
         values(
         v_fea_rela_id1,
         v_prod_fea_id1,
         v_prod_fea_id4,
         '0',
         sysdate,
         sysdate,
         v_region_cd,
         sysdate
         );
        proc_cross_localarea_log('FEA_RELA',v_fea_rela_id1,0,i_batch_id,'属性关联表');
        end if;

        select count(*)
          into v_attr_count
          from prod_inst_attr
         where prod_inst_id = v_prod_inst_id
           and attr_id = 800000554;

        if v_attr_count = 1 then
        o_result := '添加集团付费属性';
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id2 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date)
         select v_prod_fea_id2,
                v_prod_id,
                '620024768',--集团付费属性
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate
           from dual;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id2,'PROD_FEA_ID');
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id2,0,i_batch_id,'同步产品属性表');

        o_result := '添加集团付费属性值';
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id5 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date)
         select v_prod_fea_id5,
                v_prod_id,
                pf.fea_spec_id,
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate
           from prod_inst_attr pa,crm.prod_fea_spec@lk_tocrm1_cross pf
          where pa.prod_inst_id = v_prod_inst_id
            and pa.attr_id = 800000554
            and pa.attr_value = pf.code
            and pf.prod_spec_id = v_ext_prod_id;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id5,'PROD_FEA_ID');
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id5,0,i_batch_id,'同步产品属性表');

        o_result := '添加集团付费属性值上下级关系';
        select crm.fea_rela_seq.nextval@lk_tocrm1_cross into v_fea_rela_id2 from dual;
        insert into crm.fea_rela@lk_tocrm1_cross
        (rela_id,
         fea_id_a,
         fea_id_b,
         rela_type,
         create_date,
         modify_date,
         region,
         real_modify_date)
         values(
         v_fea_rela_id2,
         v_prod_fea_id2,
         v_prod_fea_id5,
         '0',
         sysdate,
         sysdate,
         v_region_cd,
         sysdate
         );
        proc_cross_localarea_log('FEA_RELA',v_fea_rela_id2,0,i_batch_id,'属性关联表');

        end if;
        --同步日志

        select count(*)
          into v_attr_count
          from prod_inst_attr
         where prod_inst_id = v_prod_inst_id
           and attr_id = 800000558;
        if v_attr_count =1 then
        o_result := '添加集团状态';
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id3 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date)
         select v_prod_fea_id3,
                v_prod_id,
                '620032058',
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate
           from dual;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id3,'PROD_FEA_ID');
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id3,0,i_batch_id,'同步产品属性表');
        o_result := '添加集团状态值';
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id6 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date)
         select v_prod_fea_id6,
                v_prod_id,
                pf.fea_spec_id,
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate
           from prod_inst_attr pa,crm.prod_fea_spec@lk_tocrm1_cross pf
          where pa.prod_inst_id = v_prod_inst_id
            and pa.attr_id = 800000558
            and pa.attr_value = pf.code
            and pf.prod_spec_id = v_ext_prod_id;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id6,'PROD_FEA_ID');
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id6,0,i_batch_id,'同步产品属性表');
        o_result := '添加集团状态上下级关系';
        select crm.fea_rela_seq.nextval@lk_tocrm1_cross into v_fea_rela_id3 from dual;
        insert into crm.fea_rela@lk_tocrm1_cross
        (rela_id,
         fea_id_a,
         fea_id_b,
         rela_type,
         create_date,
         modify_date,
         region,
         real_modify_date)
         values(
         v_fea_rela_id3,
         v_prod_fea_id3,
         v_prod_fea_id6,
         '0',
         sysdate,
         sysdate,
         v_region_cd,
         sysdate
         );
        proc_cross_localarea_log('FEA_RELA',v_fea_rela_id3,0,i_batch_id,'属性关联表');
        --同步日志
        end if;

        select count(*)
          into v_attr_count
          from prod_inst_attr
         where prod_inst_id = v_prod_inst_id
           and attr_id = 800000564;
        if v_attr_count = 1 then
        o_result := '添加企业总机号码';
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id7 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date,
         param1,
         param2)
         select v_prod_fea_id7,
                v_prod_id,
                pf.fea_spec_id,
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate,
                pa.attr_value,
                pa.attr_value
           from prod_inst_attr pa,attr_spec a,crm.prod_fea_spec@lk_tocrm1_cross pf
          where pa.prod_inst_id = v_prod_inst_id
            and pa.attr_id = 800000564
            and pa.attr_id = a.attr_id
            and a.java_code = pf.code
            and pf.prod_spec_id = v_ext_prod_id;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id7,'PROD_FEA_ID');
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id7,0,i_batch_id,'同步产品属性表');
        end if;

        select count(*)
          into v_attr_count
          from prod_inst_attr
         where prod_inst_id = v_prod_inst_id
           and attr_id = 800000555;
        if v_attr_count = 1 then
        o_result := '添加外线拨号错误';
        select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id8 from dual;
        insert into crm.prod_fea@lk_tocrm1_cross
        (prod_fea_id,
         prod_id,
         fea_spec_id,
         op_mode,
         state,
         create_date,
         modify_date,
         region,
         real_modify_date,
         param1)
         select v_prod_fea_id8,
                v_prod_id,
                pf.fea_spec_id,
                '',
                '70A',
                sysdate,
                sysdate,
                v_region_cd,
                sysdate,
                pa.attr_value
           from prod_inst_attr pa,attr_spec a,crm.prod_fea_spec@lk_tocrm1_cross pf
          where pa.prod_inst_id = v_prod_inst_id
            and pa.attr_id = 800000555
            and pa.attr_id = a.attr_id
            and a.java_code = pf.code
            and pf.prod_spec_id = v_ext_prod_id;
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id8,'PROD_FEA_ID');
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id8,0,i_batch_id,'同步产品属性表');
        end if;
        end if;
        o_result := '添加产品关联信息错误1';
        select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS
          into v_mdse_id
          from dual;

        --获取2.0销售品ID
        select poi.prod_offer_inst_id,po.prod_offer_id into v_prod_offer_inst_id,v_prod_offer_id
          from offer_prod_inst_rel r, prod_offer_inst poi, prod_offer po
         where r.prod_inst_id = v_prod_inst_id
           and r.prod_offer_inst_id = poi.prod_offer_inst_id
           and poi.prod_offer_id = po.prod_offer_id
           and po.offer_sub_type = 'T01';

        --针对一卡双号的主号的限制的一些属性的同步
        select count(*) into v_attr_num
          from prod_inst_attr p
         where p.prod_inst_id = v_prod_inst_id
           and p.attr_id =(select attr_id from attr_spec where java_code = 'YKSH');

        if v_attr_num <> 0 then
        --同步一卡双号可受理属性
           o_result := '添加产品属性信息错误';
           select crm.F_GET_PROD_FEA_ID@lk_tocrm1_cross into v_prod_fea_id from dual;

           insert into crm.prod_fea@lk_tocrm1_cross
            (prod_fea_id,
             prod_id,
             fea_spec_id,
             op_mode,
             state,
             create_date,
             modify_date,
             region,
             real_modify_date)
             select v_prod_fea_id,
                    v_prod_id,
                    fea_spec_id,
                    '',
                    '70A',
                    sysdate,
                    sysdate,
                    v_region_cd,
                    sysdate
               from crm.prod_fea_spec@lk_tocrm1_cross where code = 'YKSH';
        proc_cross_ins_billing_update('PROD_FEA',v_prod_fea_id,'PROD_FEA_ID');
        --同步日志
        proc_cross_localarea_log('PROD_FEA',v_prod_fea_id,0,i_batch_id,'同步产品属性表');

        o_result := '添加销售品信息错误2';
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_mdse_id,
                 610290109,
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 v_prod_id,
                 '101',
                 poi.status_date,
                 cr.up_region_id,
                 poi.eff_date,
                 poi.update_date,
                 poi.service_nbr,
                 'Y'
            from prod_offer_inst poi,common_region cr
           where poi.prod_offer_inst_id = v_prod_offer_inst_id
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_mdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_mdse_id,v_prod_offer_inst_id,i_batch_id,'同步销售品表');

        for prodOfferR in i_prod_offer_rel loop
        o_result := '添加套餐信息错误';
        select crm.MDSE_ID_SEQ.Nextval@lk_tocrm1_cross into v_mdse_price_rela_id from dual;
        insert into crm.mdse_price_rela@lk_tocrm1_cross
        (rela_id,
         price_id,
         mdse_id,
         price_type,
         eff_date,
         exp_date,
         create_date,
         modify_date,
         state,
         region,
         real_modify_date)
        select v_mdse_price_rela_id,
               n.id_v1,
               v_mdse_id,
               '104', --程控类型
               sysdate,
               to_date('2199-2-1','yyyy-MM-dd'),
               sysdate,
               sysdate,
               '70A',
               v_region_cd,
               sysdate
          from mdse_ys_lisy_new n
         where n.id_v2 = prodOfferR.prod_offer_id;

        proc_cross_ins_billing_update('MDSE_PRICE_RELA',v_mdse_price_rela_id,'RELA_ID');
        --同步日志
        proc_cross_localarea_log('MDSE_PRICE_RELA',v_mdse_price_rela_id,'0',i_batch_id,'1.0套餐表');

        end loop;
        --销售品是天翼，有受理T7套餐
        if v_prod_offer_id <> 800001837 then
        o_result := '添加套餐信息错误';
        select crm.MDSE_ID_SEQ.Nextval@lk_tocrm1_cross into v_mdse_price_rela_id from dual;
        insert into crm.mdse_price_rela@lk_tocrm1_cross
        (rela_id,
         price_id,
         mdse_id,
         price_type,
         eff_date,
         exp_date,
         create_date,
         modify_date,
         state,
         region,
         real_modify_date)
        select v_mdse_price_rela_id,
               n.id_v1,
               v_mdse_id,
               '104', --程控类型
               sysdate,
               to_date('2199-2-1','yyyy-MM-dd'),
               sysdate,
               sysdate,
               '70A',
               v_region_cd,
               sysdate
          from mdse_ys_lisy_new n
         where n.id_v2 = v_prod_offer_id;

        proc_cross_ins_billing_update('MDSE_PRICE_RELA',v_mdse_price_rela_id,'RELA_ID');
        --同步日志
        proc_cross_localarea_log('MDSE_PRICE_RELA',v_mdse_price_rela_id,'0',i_batch_id,'1.0套餐表');
        end if;

        --如果有受理天翼超无则同步天翼超无
        select count(*)
          into v_tycy_count
          from prod_inst_rel r, prod_inst pi
         where pi.product_id = 800000048
           and r.prod_inst_z_id = pi.prod_inst_id
           and r.prod_inst_a_id = v_prod_inst_id;

        if v_tycy_count <> 0 then
        select pi.prod_inst_id
          into v_tycy_pid
          from prod_inst_rel r, prod_inst pi
         where pi.product_id = 800000048
           and r.prod_inst_z_id = pi.prod_inst_id
           and r.prod_inst_a_id = v_prod_inst_id;

        --当前天翼超无中的另外一个产品
          select r.prod_inst_a_id
            into v_fk_id
            from prod_inst_rel r
           where r.prod_inst_z_id = v_tycy_pid
             and r.prod_inst_a_id <> v_prod_inst_id;
         --插入数据prod
        o_result := '添加产品关联信息错误2';
        select crm.prod_id_seq.nextval@LK_TOCRM1_CROSS
          into v_fprod_id
          from dual;
        insert into crm.prod@LK_TOCRM1_CROSS
          (prod_id, --id
           property_custid, --产权客户标识
           cust_id, --使用客户标识
           prod_spec_id, --产品规格标识
           create_date, --生成时间
           modify_date, --修改时间
           staff, --操作员工号
           state, --状态
           prod_spec_type, --产品规格类型
           service_code, --业务号码
           address_id, --地址id
           stop_status, --停机状态
           exch_id, --局向
           region, --区域
           area_code, --区号
           acct_cycle, --帐务周期类型
           pay_type, --付费方式
           rent_date, --起租日
           remark, --备注
           account, --业务号码
           address_name, --地址名称
           real_modify_date,
           ext_flag1)
          select v_fprod_id,
                 i_kh_seq,
                 i_kh_seq,
                 p.ext_prod_id,
                 pi.create_date,
                 pi.status_date,
                 pi.create_staff,
                 '70A',
                 p.prod_func_type,
                 pi.account,
                 pi.address_id,
                 pi.stop_status,
                 pi.exch_id,
                 cr.up_region_id,
                 pi.area_code,
                 pi.pay_cycle,
                 decode(pi.payment_mode_cd,'1200','2','2100','3','1201','1'),
                 pi.begin_rent_time,
                 pi.remark,
                 pi.acc_nbr,
                 pi.address_desc,
                 pi.update_date,
                 'Y'
            from prod_inst pi, product p,common_region cr
           where pi.prod_inst_id = v_fk_id
             and pi.product_id = p.product_id
             and pi.common_region_id = cr.common_region_id;
         proc_cross_ins_billing_update('V_PROD',v_fprod_id,'PROD_ID');
         --同步日志
         proc_cross_localarea_log('PROD',v_fprod_id,v_fk_id,i_batch_id,'同步天翼超无关联的产品表');

         o_result := '添加销售品信息错误2';
          select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS
          into v_fmdse_id
          from dual;
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_fmdse_id,
                 decode(pz.default_value,'',610290109,pz.default_value),
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 v_fprod_id,
                 decode(pz.attr_desc,'','101',pz.attr_desc),
                 poi.status_date,
                 cr.up_region_id,
                 poi.eff_date,
                 poi.update_date,
                 poi.service_nbr,
                 'Y'
            from prod_offer_inst poi,
                 (select a.java_code,a.attr_desc, a.default_value
                    from sys_class sc, attr_spec a
                   where sc.java_code = 'ProdOfferIdRel'
                     and sc.class_id = a.class_id) pz,common_region cr
           where poi.prod_offer_inst_id = v_prod_offer_inst_id
             and poi.prod_offer_id = pz.java_code(+)
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_fmdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_fmdse_id,'0',i_batch_id,'同步销售品表');

        --获取天翼超无的主号ID
        select p.attr_value_id into v_zfk_id
         from prod_inst_attr p
        where p.attr_id = 800004083
          and p.prod_inst_id = v_tycy_pid;

          if v_zfk_id <> v_prod_inst_id then
             v_mdse_ida := v_fmdse_id;
             v_mdse_idb := v_mdse_id;
          else
             v_mdse_ida := v_mdse_id;
             v_mdse_idb := v_fmdse_id;
          end if;
        o_result := '添加销售品关联信息错误2';
        select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross
          into v_mdse_rela_seq
          from dual;
        insert into crm.mdse_rela@lk_tocrm1_cross
          (RELA_ID,
           MDSE_IDB,
           RELA_TYPE,
           STATE,
           MDSE_IDA,
           CREATE_DATE,
           MODIFY_DATE,
           a_region,
           b_region,
           ext_flag1)
          select v_mdse_rela_seq,
                 v_mdse_idb,
                 '178', --天翼超无
                 '70A',
                 v_mdse_ida,
                 sysdate,
                 sysdate,
                 v_region_cd,
                 v_region_cd,
                 'Y'
            from dual;

        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela_seq,'RELA_ID');
        proc_cross_localarea_log('MDSE_RELA', v_mdse_rela_seq, null,i_batch_id,'同步天翼超无关联表');
        end if;
        ---同步军翼网、综合虚拟网的数据
        for prodRel in i_prod_rel loop
            select prodRel.prod_inst_id,po.prod_offer_id into v_vpn_prod_id,v_vpn_offer_id
              from offer_prod_inst_rel r,
                   prod_offer_inst     poi,
                   prod_offer          po
             where po.offer_sub_type = 'T01'
               and r.prod_offer_inst_id = poi.prod_offer_inst_id
               and poi.prod_offer_id = po.prod_offer_id
               and r.prod_inst_id = prodRel.prod_inst_id;

        o_result := '添加产品关联信息错误3';

        select crm.prod_id_seq.nextval@LK_TOCRM1_CROSS into v_fprod_id from dual;
        insert into crm.prod@LK_TOCRM1_CROSS
          (prod_id, --id
           property_custid, --产权客户标识
           cust_id, --使用客户标识
           prod_spec_id, --产品规格标识
           create_date, --生成时间
           modify_date, --修改时间
           staff, --操作员工号
           state, --状态
           prod_spec_type, --产品规格类型
           service_code, --业务号码
           address_id, --地址id
           stop_status, --停机状态
           exch_id, --局向
           region, --区域
           area_code, --区号
           acct_cycle, --帐务周期类型
           pay_type, --付费方式
           rent_date, --起租日
           remark, --备注
           account, --业务号码
           address_name, --地址名称
           real_modify_date,
           ext_flag1)
          select v_fprod_id,
                 i_kh_seq,
                 i_kh_seq,
                 p.ext_prod_id,
                 pi.create_date,
                 pi.status_date,
                 pi.create_staff,
                 '70A',
                 p.prod_func_type,
                 pi.account,
                 pi.address_id,
                 pi.stop_status,
                 pi.exch_id,
                 cr.up_region_id,
                 pi.area_code,
                 pi.pay_cycle,
                 decode(pi.payment_mode_cd,'1200','2','2100','3','1201','1'),
                 pi.begin_rent_time,
                 pi.remark,
                 pi.acc_nbr,
                 pi.address_desc,
                 pi.update_date,
                 'Y'
            from prod_inst pi, product p,common_region cr
           where pi.prod_inst_id = v_vpn_prod_id
             and pi.product_id = p.product_id
             and pi.common_region_id = cr.common_region_id;
         proc_cross_ins_billing_update('V_PROD',v_fprod_id,'PROD_ID');
         --同步日志
         proc_cross_localarea_log('PROD',v_fprod_id,v_vpn_prod_id,i_batch_id,'同步综合虚拟网或军翼网的IVPN产品信息');

         o_result := '添加综合虚拟网或军翼网销售品信息';
          select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS
          into v_fmdse_id
          from dual;
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_fmdse_id,
                 decode(pz.default_value,'',610290109,pz.default_value),
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 v_prod_id,
                 decode(pz.attr_desc,'','101',pz.attr_desc),
                 poi.status_date,
                 cr.up_region_id,
                 poi.eff_date,
                 poi.update_date,
                 poi.service_nbr,
                 'Y'
            from prod_offer_inst poi,
                 (select a.java_code,a.attr_desc, a.default_value
                    from sys_class sc, attr_spec a
                   where sc.java_code = 'ProdOfferIdRel'
                     and sc.class_id = a.class_id) pz,common_region cr
           where poi.prod_offer_inst_id = v_prod_offer_inst_id
             and poi.prod_offer_id = pz.java_code(+)
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_fmdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_fmdse_id,'0',i_batch_id,'同步销售品表');

        o_result := '添加销售品关联信息错误3';
        select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross
          into v_mdse_rela_seq
          from dual;
        insert into crm.mdse_rela@lk_tocrm1_cross
          (RELA_ID,
           MDSE_IDB,
           RELA_TYPE,
           STATE,
           MDSE_IDA,
           CREATE_DATE,
           MODIFY_DATE,
           a_region,
           b_region,
           ext_flag1)
          select v_mdse_rela_seq,
                 v_mdse_id,
                 '105', --综合虚拟网
                 '70A',
                 v_fmdse_id,
                 sysdate,
                 sysdate,
                 v_region_cd,
                 v_region_cd,
                 'Y'
            from dual;

        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela_seq,'RELA_ID');
        proc_cross_localarea_log('MDSE_RELA', v_mdse_rela_seq, null,i_batch_id,'同步综合虚拟网或军翼网关联表');
        end loop;
        else
        o_result := '添加销售品信息错误3';
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_mdse_id,
                 decode(pz.default_value, '', '610290109', pz.default_value),
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 v_prod_id,
                 decode(pz.attr_desc,'','101',pz.attr_desc),
                 poi.status_date,
                 cr.up_region_id,
                 poi.eff_date,
                 poi.update_date,
                 poi.service_nbr,
                 'Y'
            from prod_offer_inst poi,
                 (select a.java_code,a.attr_desc, a.default_value
                    from sys_class sc, attr_spec a
                   where sc.java_code = 'ProdOfferIdRel'
                     and sc.class_id = a.class_id) pz,common_region cr
           where poi.prod_offer_inst_id = v_prod_offer_inst_id
             and poi.prod_offer_id = pz.java_code(+)
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_mdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_mdse_id,v_prod_offer_inst_id,i_batch_id,'同步销售品表');

        if v_prod_offer_id <> 800001837 then
        o_result := '添加套餐信息错误';
        select crm.MDSE_ID_SEQ.Nextval@lk_tocrm1_cross into v_mdse_price_rela_id from dual;
        insert into crm.mdse_price_rela@lk_tocrm1_cross
        (rela_id,
         price_id,
         mdse_id,
         price_type,
         eff_date,
         exp_date,
         create_date,
         modify_date,
         state,
         region,
         real_modify_date)
        select v_mdse_price_rela_id,
               n.id_v1,
               v_mdse_id,
               '104', --程控类型
               sysdate,
               to_date('2199-2-1','yyyy-MM-dd'),
               sysdate,
               sysdate,
               '70A',
               v_region_cd,
               sysdate
          from mdse_ys_lisy_new n
         where n.id_v2 = v_prod_offer_id;

        proc_cross_ins_billing_update('MDSE_PRICE_RELA',v_mdse_price_rela_id,'RELA_ID');
        --同步日志
        proc_cross_localarea_log('MDSE_PRICE_RELA',v_mdse_price_rela_id,'0',i_batch_id,'1.0套餐表');
        end if;
        ---vpn如果还有帽子销售品存在同步帽子销售pin
        select count(1) into v_is_count
          from attr_value av
         where exists (select 1
                  from sys_class t, attr_spec a
                 where t.java_code = 'AssiAttrSpecConfig'
                   and t.class_id = a.class_id
                   and a.java_code = 'vpnPoId'
                   and av.attr_id = a.attr_id)
            and av.attr_value = ''||v_prod_offer_id||'';
        --vpn等同步时把成员加入到vpn_phs2cdma表中
        if v_is_count > 0 then
        for pir in i_prod_inst_rel loop
           insert into crm.vpn_phs2cdma@lk_tocrm1_cross
           (member_id,
            vpn_id,
            vpn_type,
            area_code,
            service_code,
            mdse_id,
            eff_date,
            exp_date,
            create_date,
            real_modify_date)
           values(
            crm.vpn_phs2cdma_id_seq.nextval@lk_tocrm1_cross,
            v_mdse_id,
            -99,
            pir.area_code,
            pir.acc_nbr,
            null,
            sysdate,
            to_date('2199/1/1','yyyy-MM-dd'),
            sysdate,
            sysdate
           );
        end loop;
        --同步总机服务套餐等销售品
        for poir in i_prod_offer_inst_rel loop
         select count(1) into v_is_count2
        from attr_value av
       where exists (select 1
                from sys_class t, attr_spec a
               where t.java_code = 'AssiAttrSpecConfig'
                 and t.class_id = a.class_id
                 and a.java_code = 'vpnHPoId'
                 and av.attr_id = a.attr_id)
          and av.attr_value = ''||poir.prod_offer_id||'';
        if v_is_count2 > 0 then
        o_result := '添加VPN产品信息';
        select poi.service_nbr into v_acc_nbr2 from prod_offer_inst poi where poi.prod_offer_inst_id = poir.prod_offer_inst_id;

        select crm.prod_id_seq.nextval@LK_TOCRM1_CROSS into v_xprod_id from dual;
        insert into crm.prod@LK_TOCRM1_CROSS
          (prod_id, --id
           property_custid, --产权客户标识
           cust_id, --使用客户标识
           prod_spec_id, --产品规格标识
           create_date, --生成时间
           modify_date, --修改时间
           staff, --操作员工号
           state, --状态
           prod_spec_type, --产品规格类型
           service_code, --业务号码
           address_id, --地址id
           stop_status, --停机状态
           exch_id, --局向
           region, --区域
           area_code, --区号
           acct_cycle, --帐务周期类型
           pay_type, --付费方式
           rent_date, --起租日
           remark, --备注
           account, --业务号码
           address_name, --地址名称
           real_modify_date,
           ext_flag1)
          select v_xprod_id,
                 i_kh_seq,
                 i_kh_seq,
                 594001183,
                 sysdate,
                 sysdate,
                 pi.create_staff,
                 '70A',
                 '103',
                 v_acc_nbr2,
                 '',
                 '0',
                 '',
                 cr.up_region_id,
                 pi.area_code,
                 pi.pay_cycle,
                 decode(pi.payment_mode_cd,'1200','2','2100','3','1201','1'),
                 pi.begin_rent_time,
                 '',
                 v_acc_nbr2,
                 '',
                 sysdate,
                 'Y'
            from prod_inst pi, common_region cr
           where pi.prod_inst_id = v_prod_inst_id
             and pi.common_region_id = cr.common_region_id;

         proc_cross_ins_billing_update('V_PROD',v_xprod_id,'PROD_ID');
         --同步日志
         proc_cross_localarea_log('PROD',v_xprod_id,'0',i_batch_id,'同步产品表');
         o_result := '添加VPN群销售品信息错误';
         select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS
          into v_xmdse_id
          from dual;
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_xmdse_id,
                 600013680,
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 v_xprod_id,
                 '108',
                 sysdate,
                 cr.up_region_id,
                 sysdate,
                 sysdate,
                 v_acc_nbr2,
                 'Y'
            from prod_offer_inst poi,common_region cr
           where poi.prod_offer_inst_id = poir.prod_offer_inst_id
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_xmdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_xmdse_id,'0',i_batch_id,'同步销售品表');
        o_result := '添加VPN上挂的总机服务套餐等销售品信息错误';
        select crm.mdse_id_seq.nextval@LK_TOCRM1_CROSS
          into v_vmdse_id
          from dual;
        insert into crm.mdse@LK_TOCRM1_CROSS
          (mdse_id,
           mdse_spec_id,
           property_custid,
           create_date,
           exp_date,
           state,
           prod_id,
           mdse_type,
           modify_date,
           region,
           eff_date,
           real_modify_date,
           mdse_serv_number,
           ext_flag1)
          select v_vmdse_id,
                 decode(pz.default_value, '', '610290109', pz.default_value),
                 i_kh_seq,
                 poi.create_date,
                 poi.exp_date,
                 '70A',
                 0,
                 decode(pz.attr_desc,'','101',pz.attr_desc),
                 poi.status_date,
                 cr.up_region_id,
                 poi.eff_date,
                 poi.update_date,
                 poi.service_nbr,
                 'Y'
            from prod_offer_inst poi,
                 (select a.java_code,a.attr_desc, a.default_value
                    from sys_class sc, attr_spec a
                   where sc.java_code = 'ProdOfferIdRel'
                     and sc.class_id = a.class_id) pz,common_region cr
           where poi.prod_offer_inst_id = poir.prod_offer_inst_id
             and poi.prod_offer_id = pz.java_code(+)
             and poi.region_cd = cr.common_region_id;
        proc_cross_ins_billing_update('MDSE',v_vmdse_id,'MDSE_ID');
        --同步日志
        proc_cross_localarea_log('MDSE',v_vmdse_id,poir.prod_offer_inst_id,i_batch_id,'同步销售品表');
        o_result := '添加总机服务与省内vpn的关联关系';
        select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross
          into v_mdse_rela1
          from dual;
        insert into crm.mdse_rela@lk_tocrm1_cross
          (RELA_ID,
           MDSE_IDB,
           RELA_TYPE,
           STATE,
           MDSE_IDA,
           CREATE_DATE,
           MODIFY_DATE,
           a_region,
           b_region,
           ext_flag1)
          select v_mdse_rela1,
                 v_mdse_id,
                 '150',
                 '70A',
                 v_vmdse_id,
                 sysdate,
                 sysdate,
                 v_region_cd,
                 v_region_cd,
                 'Y'
            from dual;

        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela1,'RELA_ID');
        proc_cross_localarea_log('MDSE_RELA', v_mdse_rela1, null,i_batch_id,'同步群组套餐跟vpn群组的关联关系');
         o_result := '添加总机服务与vpn群商品信息错误';
        select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross
          into v_mdse_rela2
          from dual;
        insert into crm.mdse_rela@lk_tocrm1_cross
          (RELA_ID,
           MDSE_IDB,
           RELA_TYPE,
           STATE,
           MDSE_IDA,
           CREATE_DATE,
           MODIFY_DATE,
           a_region,
           b_region,
           ext_flag1)
          select v_mdse_rela2,
                 v_xmdse_id,
                 '151',
                 '70A',
                 v_vmdse_id,
                 sysdate,
                 sysdate,
                 v_region_cd,
                 v_region_cd,
                 'Y'
            from dual;

        proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela2,'RELA_ID');
        proc_cross_localarea_log('MDSE_RELA', v_mdse_rela2, null,i_batch_id,'同步群组套餐跟vpn套餐的关联关系');
        end if;
        end loop;
        end if;
        end if;
        v_num := 0;
        /*if main_accnbr_regin is not null then
           for mn in mc_acc_nbr loop
              if v_num = 0 then
                m_acc_nbr := mn.column_value;
                v_num     := v_num + 1;
              else
                if v_num = 1 then
                  m_region_cd := mn.column_value;
                end if;
              end if;
            end loop;
            --
            o_result := '添加销售品关联信息错误';
            select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross into v_mdse_rela_seq from dual;
            insert into crm.mdse_rela@lk_tocrm1_cross
            (RELA_ID,
             MDSE_IDB,
             RELA_TYPE,
             STATE,
             MDSE_IDA,
             CREATE_DATE,
             MODIFY_DATE,
             a_region,
             b_region,
             ext_flag1)
            select crm.mdse_rela_id_seq.nextval@lk_tocrm1_cross,
                   v_mdse_id,
                   '197',
                   '70A',
                   mr.mdse_id,
                   sysdate,
                   sysdate,
                   11,
                   mr.region,
                   'Y'
             from crm.prod@lk_tocrm1_cross pr,crm.mdse@lk_tocrm1_cross mr
            where pr.region = m_region_cd
              and pr.account = m_acc_nbr
              and pr.prod_id = mr.prod_id
              and mr.mdse_type = '101';

           proc_cross_ins_billing_update('MDSE_RELA',v_mdse_rela_seq,'RELA_ID');
        end if;*/
        o_result := '添加电信账户信息错误';
        --同步账户信息
        for ac in i_acct loop
          select count(1)
            into v_acct_count
            from crm.telecom_account@LK_TOCRM1_CROSS
           where agreement_code = ac.account_number;

          if v_acct_count = 0 then
            select crm.tel_acct_id_seq.nextval@LK_TOCRM1_CROSS
              into v_tel_acct_id_seq
              from dual;
            insert into crm.telecom_account@LK_TOCRM1_CROSS
              (tel_acct_id, --电信账户标识
               agreement_code, --合同号
               customer_id, --客户标识
               tel_acct_code, --电信账户编码
               tel_acct_name, --电信账户名称
               state, --状态
               create_date, --创建时间
               deduct_charge, --扣款金额
               deduct_limit, --扣款阀值
               modify_date,
               REAL_MODIFY_DATE,
               region,
               ext_flag1)
              select v_tel_acct_id_seq,
                     a.account_number,
                     i_kh_seq,
                     a.account_number,
                     a.account_name,
                     '10A',
                     a.create_date,
                     a.deduct_charge,
                     a.deduct_limit,
                     a.status_date,
                     a.update_date,
                     a.region_cd,
                     'Y'
                from account a
               where a.account_id = ac.account_id;
               proc_cross_ins_billing_update('TELECOM_ACCOUNT',v_tel_acct_id_seq,'TEL_ACCT_ID');
               --同步日志
               proc_cross_localarea_log('TELECOM_ACCOUNT',v_tel_acct_id_seq,ac.account_id,i_batch_id,'同步电信账户表');

               o_result := '添加账户信息错误';
          select crm.zhid_seq.nextval@LK_TOCRM1_CROSS into v_zh_id from dual;

          insert into crm.zh@LK_TOCRM1_CROSS
            (zhid,
             zhyh,
             zhmc,
             zhzh,
             zhlx,
             zhkh,
             zhrq,
             zhgr,
             zhzt,
             region,
             real_modify_date,
             acc_agreement_code,
             send_method_type,
             entrust_type,
             ext_flag1)
            select v_zh_id,
                   pp.payment_bank_id,
                   pp.payment_account_name,
                   pp.payment_account,
                   pp.payment_method_id,
                   i_kh_seq,
                   pp.create_date,
                   pp.status_date,
                   '10A',
                   pp.region_cd,
                   pp.update_date,
                   pp.acc_agreement_code,
                   pp.send_entrust_method,
                   pp.entrust_type,
                   'Y'
              from payment_plan pp, prod_inst_acct pia
             where pia.account_id = pp.account_id
               and pia.prod_inst_id = v_prod_inst_id
               and rownum < 2;
          proc_cross_localarea_log('ZH',v_zh_id,0,i_batch_id,'同步ZH表');

          o_result := '添加支付方案信息错误';
          select crm.payment_plan_id_seq.nextval@LK_TOCRM1_CROSS into v_payment_plan_seq from dual;
          --获取2.0账务定制关系表ID v_prod_inst_acct_id
          select pia.prod_inst_acct_id into v_prod_inst_acct_id
            from prod_inst_acct pia
           where pia.prod_inst_id = v_prod_inst_id
             and pia.account_id = ac.account_id;

          select pp.payment_plan
            into v_payment_plan_id
            from payment_plan pp, prod_inst_acct pia
           where pia.account_id = pp.account_id
             and pia.prod_inst_acct_id = v_prod_inst_acct_id
             and rownum <2;
          --v_payment_plan_id
          insert into crm.payment_plan@LK_TOCRM1_CROSS
            (payment_plan_id,
             proportion,
             limitation,
             cust_acct_id,
             tel_acct_id,
             priority,
             create_date,
             modify_date,
             state,
             region,
             real_modify_date,
             ext_flag1)
            select v_payment_plan_seq,
                   pia.payment_limit,
                   pia.payment_limit,
                   v_zh_id,
                   v_tel_acct_id_seq,
                   pp.priority,
                   pp.create_date,
                   pp.status_date,
                   '10A',
                   pp.region_cd,
                   pp.update_date,
                   'Y'
              from payment_plan pp, prod_inst_acct pia
             where pia.account_id = pp.account_id
               and pia.prod_inst_acct_id = v_prod_inst_acct_id
               and rownum <2;
          proc_cross_ins_billing_update('PAYMENT_PLAN',v_payment_plan_seq,'PAYMENT_PLAN_ID');

          proc_cross_localarea_log('PAYMENT_PLAN',v_payment_plan_seq,v_payment_plan_id,i_batch_id,'同步zg表');

          else
            select tel_acct_id
              into v_tel_acct_id_seq
              from crm.telecom_account@LK_TOCRM1_CROSS
             where agreement_code = ac.account_number;
          end if;
          --
          o_result := '添加账户信息错误';
          select crm.zgid_seq.nextval@LK_TOCRM1_CROSS
            into v_zgid_seq
            from dual;

          --获取2.0账务定制关系表ID v_prod_inst_acct_id
          select pia.prod_inst_acct_id into v_prod_inst_acct_id
            from prod_inst_acct pia
           where pia.prod_inst_id = v_prod_inst_id
             and pia.account_id = ac.account_id;

          insert into crm.zg@LK_TOCRM1_CROSS
            (zgid, --账户id
             zgzr, --产品id
             zgzh, --电信账户标识
             zgzl,
             zgff,
             zgxe,
             zgxs,
             zgrq,
             zggr,
             zgzt,
             zgfg,
             zgtl,
             zgfp,
             zgqy,
             zgfl,
             real_modify_date,
             ext_flag1)
            select v_zgid_seq,
                   v_prod_id,
                   v_tel_acct_id_seq,
                   pia.acct_item_type_group_id,
                   decode(pia.payment_limit_type,'10','1','11','2',pia.payment_limit_type),
                   pia.payment_limit,
                   pia.priority,
                   pia.create_date,
                   pia.status_date,
                   '70A',
                   pia.charge_type,
                   decode(pia.def_acct_flag,'T','true','flase'),
                   pia.invoice_formart_flag,
                   cr.up_region_id,
                   0,
                   pia.update_date,
                   'Y'
              from prod_inst_acct pia,common_region cr
             where pia.prod_inst_acct_id = v_prod_inst_acct_id
             and pia.region_cd = cr.common_region_id;

          proc_cross_localarea_log('ZG',v_zgid_seq,v_prod_inst_acct_id,i_batch_id,'同步zg表');


        end loop;
      /*else
      --获取虚号码的销售品ID
      if op_flag is not null then
       select mdse_id
         into v_mdse_idb
         from crm.prod@LK_TOCRM1_CROSS p, crm.mdse@lk_tocrm1_cross m
        where p.region = v_region_cd
          and p.account = v_acc_nbr
          and p.prod_id = m.prod_id
          and m.mdse_type = '101';
         if op_flag = '3' then --拆机
          delete from crm.mdse@lk_tocrm1_cross where mdse_id = v_mdse_idb;
          delete from crm.prod@lk_tocrm1_cross where region=v_region_cd and account = v_acc_nbr;
          delete from crm.mdse_rela@lk_tocrm1_cross where mdse_idb = v_mdse_idb;
         else
         --分解得到主号码的号码与区域
         v_num := 0;
         if main_accnbr_regin is not null then
           for mn in mc_acc_nbr loop
              if v_num = 0 then
                m_acc_nbr := mn.column_value;
                v_num     := v_num + 1;
              else
                if v_num = 1 then
                  m_region_cd := mn.column_value;
                end if;
              end if;
            end loop;
            --获取主号的销售品ID
            select mr.mdse_id
              into v_mdse_ida
              from crm.prod@lk_tocrm1_cross pr, crm.mdse@lk_tocrm1_cross mr
             where pr.region = m_region_cd
               and pr.account = m_acc_nbr
               and pr.prod_id = mr.prod_id
               and mr.mdse_type = '101';
            --修改对应的销售品关联信息
            o_result := '添加销售品关联信息错误';
            if op_flag = '1' then --修改
             update crm.mdse_rela@lk_tocrm1_cross
                set mdse_ida = v_mdse_ida
              where mdse_idb = v_mdse_idb;
            else if op_flag = '2' then --删除
             delete from crm.mdse_rela@lk_tocrm1_cross
                   where mdse_idb = v_mdse_idb
                     and mdse_ida = v_mdse_ida;
             end if;
            end if;
            end if;
          end if;
         end if;*/
         end if;
      end if;
    end;
  end loop;
  o_result := 'TRUE';
  commit;
exception
  when others then
    o_result := o_result;
end;
/
