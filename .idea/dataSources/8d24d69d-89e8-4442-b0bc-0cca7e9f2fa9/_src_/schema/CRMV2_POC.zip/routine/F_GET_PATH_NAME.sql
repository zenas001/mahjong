CREATE FUNCTION           F_GET_PATH_NAME(I_COLUMN_NAME VARCHAR2,
                                           I_WHERE_NAME VARCHAR2,
                                           I_VALUE_ID VARCHAR2,
                                           I_CHAR VARCHAR2) RETURN VARCHAR2 IS
  RESULT VARCHAR2(4000);
  V_SQL  VARCHAR2(512);
  V_CHAR VARCHAR2(30);
BEGIN
  --功能说明，是从根节点把对应的name串联起来  如:郑--志--浩 为了通用传参要求很多
  --I_COLUMN_NAME 传需要输出的字段
  --WHERE_NAME 这个直接传要执行的表的逻辑，但是参数ID不填写例子如下：
  --SELECT REPLACE(TO_CHAR(WM_CONCAT(ATTR_VALUE_NAME)), ',', '--')
  --  FROM (SELECT ATTR_VALUE_NAME, ROWNUM RID
  --           FROM CRMV2.ATTR_VALUE A
  --          WHERE ATTR_ID = 46
  --         CONNECT BY PRIOR A.ATTR_VALUE_ID = A.PARENT_VALUE_ID
  --          START WITH A.PARENT_VALUE_ID =);
  --I_VALUE_ID 传需要实现的参数值
  --i_char 分隔符的展示，默认为逗号','

  IF I_WHERE_NAME IS NULL AND I_COLUMN_NAME IS NULL AND I_VALUE_ID IS NULL THEN
    RESULT := 'I_WHERE_NAME,I_COLUMN_NAME,I_VALUE_ID不能为空';
    RETURN(RESULT);
  END IF;
  V_CHAR := I_CHAR;
  IF V_CHAR IS NULL THEN
    V_CHAR := ',';
  END IF;
  V_SQL := 'SELECT TO_CHAR(WM_CONCAT(' || I_COLUMN_NAME || '))' || 'FROM (' ||
           I_WHERE_NAME || ':1 ORDER BY LEVEL DESC)';

  EXECUTE IMMEDIATE V_SQL
    INTO RESULT
    USING I_VALUE_ID;
  RETURN(REPLACE(RESULT, ',', V_CHAR));
END F_GET_PATH_NAME;
/
