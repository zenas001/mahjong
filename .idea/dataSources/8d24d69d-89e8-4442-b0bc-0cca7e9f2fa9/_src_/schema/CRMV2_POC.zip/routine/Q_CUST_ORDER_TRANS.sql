CREATE PROCEDURE           Q_CUST_ORDER_TRANS(I_CUST_ORDER_ID IN NUMBER) IS
  v_offer_type number;
BEGIN
  ----AUTOTEST_CUSTOMER_ORDER
  INSERT INTO CRMV2.AUTOTEST_CUSTOMER_ORDER
    (CUST_ORDER_ID,
     CHANNEL_NBR,
     STAFF_ID,
     ORG_ID,
     CUST_SO_NUMBER,
     STATUS_CD,
     STATUS_DATE,
     DEV_STAFF_ID,
     DEV_ORG_ID,
     ORDER_CONTACT_NAME,
     ORDER_CONTACT_PHONE,
     ACCEPT_TIME,
     CUST_SO_NUMBER_NEW,
     RESULT,
     REMOTE_URL,
     MANUAL_STATUS,
     BATCH_ID,
     ISQRYACCT,
     CREATE_DATE,
     UPDATE_DATE)
    SELECT CO.CUST_ORDER_ID,
           (SELECT CHANNEL_NBR
              FROM CRMV2.CHANNEL A
             WHERE A.CHANNEL_ID = CO.CHANNEL_ID) AS CHANNEL_NBR,
           CO.CREATE_STAFF AS STAFF_ID,
           CO.ORG_ID,
           CO.CUST_SO_NUMBER,
           '70A' STATUS_CD,
           NULL STATUS_DATE,
           (SELECT ATTR_VALUE
              FROM CRMV2.ORDER_ATTR_HIS OA
             WHERE OA.ATTR_ID = '800024423'
               AND OA.CUST_ORDER_ID = CO.CUST_ORDER_ID
               AND ROWNUM < 2) AS DEV_STAFF_ID,
           (SELECT ATTR_VALUE
              FROM ORDER_ATTR_HIS OA
             WHERE OA.ATTR_ID = '800024424'
               AND OA.CUST_ORDER_ID = CO.CUST_ORDER_ID
               AND ROWNUM < 2) AS DEC_ORG_ID,
           (SELECT CONTACT_NAME
              FROM ORDER_CONTACT_INFO_HIS OCI, PARTY_CONTACT_INFO PCI
             WHERE OCI.CONTACT_ID = PCI.CONTACT_ID
               AND OCI.CUST_ORDER_ID = CO.CUST_ORDER_ID
               AND ROWNUM < 2) AS ORDER_CONTACT_NAME,
           (SELECT NVL(NVL(PCI1.MOBILE_PHONE, PCI1.HOME_PHONE),
                       PCI1.OFFICE_PHONE)
              FROM ORDER_CONTACT_INFO_HIS OCI1, PARTY_CONTACT_INFO PCI1
             WHERE OCI1.CONTACT_ID = PCI1.CONTACT_ID
               AND OCI1.CUST_ORDER_ID = CO.CUST_ORDER_ID
               AND ROWNUM < 2) AS ORDER_CONTACT_PHONE,
           CO.ACCEPT_TIME,
           NULL CUST_SO_NUMBER_NEW,
           NULL RESULT,
           NULL REMOTE_URL,
           NULL MANUAL_STATUS,
           (SELECT ATTR_VALUE
              FROM CRMV2.ORDER_ATTR_HIS OA
             WHERE OA.ATTR_ID = '800070630'
               AND OA.CUST_ORDER_ID = CO.CUST_ORDER_ID
               AND ROWNUM < 2) BATCH_ID,
           1 ISQRYACCT,
           SYSDATE CREATE_DATE,
           NULL UPDATE_DATE
      FROM CRMV2.CUSTOMER_ORDER_HIS CO
     WHERE ORG_ID <> '1020001'
       AND CUST_ORDER_ID = I_CUST_ORDER_ID;
  ----AUTOTEST_ORDER_ATTR
  INSERT INTO AUTOTEST_ORDER_ATTR
    (AUTOTEST_ORDER_ATTR_ID,
     CUST_ORDER_ID,
     EXT_ATTR_NBR,
     ATTR_VALUE_ID,
     ATTR_VALUE,
     CREATE_DATE)
    SELECT SEQ_AUTOTEST_ORDER_ATTR_ID.NEXTVAL,
           A.CUST_ORDER_ID,
           B.EXT_ATTR_NBR,
           A.ATTR_VALUE_ID,
           A.ATTR_VALUE,
           SYSDATE
      FROM CRMV2.ORDER_ATTR_HIS A, CRMV2.ATTR_SPEC B
     WHERE A.ATTR_ID = B.ATTR_ID
       AND CUST_ORDER_ID = I_CUST_ORDER_ID;

  begin
    for rec in (SELECT a.order_item_id,
                       b.action_type,
                       a.ENTT_SPEC_TYPE,
                       c.proc,
                       a.order_item_obj_id
                  FROM crmv2.order_item_his         a,
                       ZZH_AUTOTEST_SERVICE_OFFER   b,
                       FZQIANTY_OBJ_ATTR_ORDER_ITEM c
                 where a.service_offer_id = b.service_offer_id
                   and a.class_id = c.class_id(+)
                   and a.cust_order_id = I_CUST_ORDER_ID

                ) loop
      if rec.proc = 'PROD_TRANS' and rec.entt_spec_type is null then
        begin
          q_t01_prod_trans(rec.order_item_id, rec.action_type);
        end;
      elsif rec.proc = 'PROD_TRANS' and rec.entt_spec_type = 'AP' then
        begin
          q_t01_prod_trans(rec.order_item_id, rec.action_type);
        end;
      elsif rec.proc = 'OFFER_TRANS' then
        select b.offer_sub_type
          into v_offer_type
          from crmv2.prod_offer_inst a, crmv2.prod_offer b
         where a.prod_offer_id = b.prod_offer_id
           and a.prod_offer_inst_id = rec.order_item_obj_id;
        if v_offer_type = 'T05' then
          begin
            q_main_offer_trans(rec.order_item_id, rec.action_type);
          end;
        else
          begin
            q_offer_trans(rec.order_item_id, rec.action_type);
          end;
        end if;
      elsif rec.proc = 'CUST_TRANS' then
        begin
          q_cust_trans(rec.order_item_id, rec.action_type);
        end;
      elsif rec.proc = 'ACCOUNT_TRANS' then
        begin
          q_account_trans(rec.order_item_id, rec.action_type);
        end;
      elsif rec.proc = 'PROD_INST_ACCT_TRANS' then
        begin
          q_prod_inst_acct_trans(rec.order_item_id, rec.action_type);
        end;
      elsif rec.proc = 'MEMBER_REL_TRANS' then
        begin
          q_member_rel_trans(rec.order_item_id);
        end;
      else
        null;
      end if;

    end loop;
  end;

END Q_CUST_ORDER_TRANS;
/
