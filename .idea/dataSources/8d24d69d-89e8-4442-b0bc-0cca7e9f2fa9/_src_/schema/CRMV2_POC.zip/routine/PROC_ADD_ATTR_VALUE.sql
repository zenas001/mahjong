CREATE procedure           proc_add_attr_value(i_table_name      varchar2,
                                                i_attr_cd         varchar2,
                                                i_attr_value      varchar2,
                                                i_attr_value_name varchar2) is

  v_class_id      number;
  v_attr_id       number;
  v_attr_value_id number;
begin
  select a.class_id
    into v_class_id
    from sys_class a
   where a.table_name = i_table_name;

  select b.attr_id
    into v_attr_id
    from attr_spec b
   where b.class_id = v_class_id
     and b.attr_cd = i_attr_cd;

  insert into attr_value
    (attr_value_id,
     attr_value,
     attr_value_name,
     attr_id,
     create_date,
     status_cd,
     status_date)
  values
    (seq_attr_value_id.nextval,
     i_attr_value,
     i_attr_value_name,
     v_attr_id,
     sysdate,
     '1000',
     sysdate);

  commit;
end proc_add_attr_value;
/
