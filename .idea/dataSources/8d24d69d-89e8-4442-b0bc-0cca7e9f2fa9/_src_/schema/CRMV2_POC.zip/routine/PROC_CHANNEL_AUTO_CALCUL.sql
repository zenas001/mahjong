CREATE procedure           proc_channel_Auto_calcul(O_RESULT  OUT VARCHAR2,O_MSG  OUT VARCHAR2) is
  /**
  *crm00058042：关于渠道视图优化的IT需求--增加连锁商圈审批制度
  *add by 黄伟超     2014-12-31
  **/
  --销售点专属属性和实体渠道归属保持同步
  CURSOR  cur_STQDGS is
  select cna.CHANNEL_ID,cna.channel_attr_id,cna.attr_value from channel_attr cna where cna.attr_id in(select ap.attr_id from attr_spec ap where
  ap.attr_name='实体渠道归属' and ap.class_id=30)  and cna.attr_value != '3' and cna.status_cd='1000';

  --2.1如果销售点有商圈关系，‘专营门店类别’自动填写为商圈店(过滤已经是商圈店)
  CURSOR  cur_ZYMDLB_hasBiz is
  select cn.channel_id from channel cn where cn.status_cd='1000' and cn.channel_class is not null and exists(select * from channel_biz_zone_rela cbz where cn.channel_id=cbz.channel_id
   and cbz.status_cd='1000') and not exists(select * from channel_attr cna where
    cna.channel_id=cn.channel_id and cna.attr_id in(select ap.attr_id from attr_spec ap where
  ap.attr_name='专营门店类别' and ap.class_id=30) and cna.attr_value='20' and cna.status_cd='1000');

    --2.2如果销售点无商圈关系，‘专营门店类别’自动填写为社区店(过滤已经是社区店)
    CURSOR  cur_ZYMDLB_noBiz is
  select cn.channel_id from channel cn where cn.status_cd='1000' and cn.channel_class is not null and not exists(select * from channel_biz_zone_rela cbz where cn.channel_id=cbz.channel_id
   and cbz.status_cd='1000') and not exists(select * from channel_attr cna where
    cna.channel_id=cn.channel_id and cna.attr_id in(select ap.attr_id from attr_spec ap where
  ap.attr_name='专营门店类别' and ap.class_id=30) and cna.attr_value='30' and cna.status_cd='1000');

  --3销售点卖场类型，把空变为“非全网通手机卖场”(过滤已经存在“销售点卖场类型”属性的数据)
  CURSOR  cur_XSDMCLX_noExist is
  select cn.channel_id from channel cn where cn.status_cd='1000' and cn.channel_class is not null
  and not exists(select * from channel_attr cna where cna.channel_id=cn.channel_id and cna.attr_id
  in(select ap.attr_id from attr_spec ap where ap.attr_name='销售点卖场类型' and ap.class_id=30)
   and cna.status_cd='1000');

   --4分级信息置灰，同步于“授权门店级别”（根据值对应）(过滤已经对应的数据)
    CURSOR  cur_FJXX is
   select cna.CHANNEL_ID,cna.channel_attr_id,decode(cna.attr_value,'50','10','40','20','30','30','20','40','10','50') as attr_value from channel_attr cna where  cna.status_cd='1000' and cna.attr_id in(select ap.attr_id
 from attr_spec ap  where ap.attr_name='授权门店级别' and ap.class_id=30) and cna.attr_value !='60'
 and not exists(select cna2.channel_attr_id from channel_attr cna2  where cna2.attr_id in(select ap2.attr_id
 from attr_spec ap2  where ap2.attr_name='分级信息' and ap2.class_id=30) and cna.channel_id=cna2.channel_id  and decode(cna.attr_value,'50','10','40','20','30','30','20','40','10','50') = cna2.attr_value);

 --5是否龙终端接入置灰,根据集团龙编码(organization.ctg_channel_nbr不为空)自动改是(过滤已经是龙终端接入的数据)
 CURSOR  cur_LXTJR is
select cn.channel_id from channel cn where cn.status_cd='1000' and cn.channel_class is not null and exists(
select cor.channel_id from channel_org_rela cor where exists (select o.org_id from organization o where o.ctg_channel_nbr is not null
 and o.org_id=cor.org_id) and cor.status_cd='1000' and cn.channel_id=cor.channel_id) and not exists(select * from channel_attr cna where
    cna.channel_id=cn.channel_id and cna.attr_id in(select ap.attr_id from attr_spec ap where
  ap.attr_name='是否龙终端接入' and ap.class_id=30) and cna.attr_value='10' and cna.status_cd='1000');

 --6.1业务排他,置灰，系统自动填写，二级类型自有厅、专营店填写(过滤已经是专营渠道的数据)
 CURSOR  cur_ywpt_Franchise is
 select cn.channel_id from channel cn  where cn.status_cd='1000' and cn.channel_class is not null
and concat(substr(cn.channel_type_cd,1,4),'00') in('110100','110200')
 and not exists(select * from channel_attr cna where cna.channel_id=cn.channel_id and cna.attr_id
  in(select ap.attr_id from attr_spec ap where ap.attr_name='业务排他' and ap.class_id=30) and cna.attr_value='10'
   and cna.status_cd='1000');
  --6.2业务排他,置灰，系统自动填写，二级类型独立店、连锁店、便利店填写(过滤已经是开放渠道的数据)
 CURSOR  cur_ywpt_ToOpenUp is
 select cn.channel_id from channel cn  where cn.status_cd='1000' and cn.channel_class is not null
and concat(substr(cn.channel_type_cd,1,4),'00') in('110300','110400','110500')
 and not exists(select * from channel_attr cna where cna.channel_id=cn.channel_id and cna.attr_id
  in(select ap.attr_id from attr_spec ap where ap.attr_name='业务排他' and ap.class_id=30) and cna.attr_value='20'
   and cna.status_cd='1000');

 --7.1自营厅经营方式,置灰，系统自动填写，三级类型外包厅填写 (过滤已经是业务外包的数据)
 CURSOR  cur_ZYTJYFS_Outsourcing is
 select cn.channel_id from channel cn  where cn.status_cd='1000'
 and cn.channel_class is not null and cn.channel_type_cd='110102'
 and not exists(select * from channel_attr cna where cna.channel_id=cn.channel_id and cna.attr_id
  in(select ap.attr_id from attr_spec ap where ap.attr_name='自营厅经营方式' and ap.class_id=30) and cna.attr_value='20'
   and cna.status_cd='1000');
  --7.2自营厅经营方式,置灰，系统自动填写，三级类型直营厅填写 (过滤已经是整厅外包（包括业务及人员外包）的数据)
 CURSOR  cur_ZYTJYFS_wholeOutsourcing is
 select cn.channel_id from channel cn  where cn.status_cd='1000'
 and cn.channel_class is not null and cn.channel_type_cd='110101'
 and not exists(select * from channel_attr cna where cna.channel_id=cn.channel_id and cna.attr_id
  in(select ap.attr_id from attr_spec ap where ap.attr_name='自营厅经营方式' and ap.class_id=30) and cna.attr_value='30'
   and cna.status_cd='1000');

   --8城市级别（城市），集团有个配置表，什么城市什么级别(过滤已经有城市级别（城市）属性的数据)
    CURSOR  cur_CSJB is
    select cn.channel_id,cn.common_region_id from channel cn  where cn.status_cd='1000'  and cn.channel_class is not null
/*and not exists(select * from channel_attr cna where cna.channel_id=cn.channel_id and cna.attr_id in(select ap.attr_id
from attr_spec ap where ap.attr_name='城市级别（城市）' and ap.class_id=30)  and cna.status_cd='1000')*/;

  --9连锁店,销售点'连锁店'有，经营主体没有'连锁分类标识'则销售点改为'县级连锁'否则和经营主体一致
  CURSOR  cur_lsflbs is
  select cn.channel_id,cn.channel_type_cd  from channel cn where cn.status_cd = '1000'
and cn.channel_class is not null   and concat(substr(cn.channel_type_cd, 1, 4), '00') in ('110300');

  V_attr_id_ZSSX          NUMBER(9):=0; --销售点专属属性的规格ID
  V_attr_id_ZYMDLB        NUMBER(9):=0; --2专营门店类别的规格ID
  V_attr_id_XSDMCLX       NUMBER(9):=0; --3销售点卖场类型的规格ID
  V_attr_id_FJXX          NUMBER(9):=0; --4分级信息的规格ID
  V_attr_id_LXTJR         NUMBER(9):=0; --5是否龙终端接入的规格ID
  V_attr_id_ywpt          NUMBER(9):=0; --6业务排他的规格ID
  V_attr_id_ZYTJYFS       NUMBER(9):=0; --7自营厅经营方式的规格ID
  V_attr_id_CSJB          NUMBER(9):=0; --8城市级别（城市）的规格ID
  V_attr_id_lsflbs        NUMBER(9):=0; --9经营主体连锁分类标识属性的规格ID
  V_COUNT_ZSSX            NUMBER;--销售点专属属性(用于有“实体渠道归属”属性是否有存在“销售点专属属性”)
  V_COUNT_ZYMDLB          NUMBER;--2用于判断是否存在‘专营门店类别’，有MOD没有ADD
  V_COUNT_FJXX            NUMBER;--4用于判断是否存在‘分级信息’，有MOD没有ADD
  V_COUNT_LXTJR           NUMBER;--5用于判断是否存在‘是否龙终端接入’，有MOD没有ADD
  V_COUNT_ywpt            NUMBER;--6用于判断是否存在‘业务排他’，有MOD没有ADD
  V_COUNT_ZYTJYFS         NUMBER;--7用于判断是否存在‘自营厅经营方式’，有MOD没有ADD
  V_COUNT_CSJB            NUMBER;--8用于判断是否存在‘城市级别（城市）’，有MOD没有ADD
  V_COUNT_CITY_LEVEL_CONFIG NUMBER;--8用于判断是否存在‘城市级别配置’,有才往下做
  V_COUNT_lsflbs          NUMBER;--9用于判断是经营主体否存在‘连锁分类标识属性’，有MOD没有ADD
  V_ZSSX_VALUE            VARCHAR2(4000);--销售点专属属性的属性值(用于同步或判断“实体渠道归属”和“销售点专属属性”的值是否已经同步了)
  V_ZYMDLB_VALUE          VARCHAR2(4000);--2专营门店类别的属性值
  V_XSDMCLX_VALUE         VARCHAR2(4000);--3销售点卖场类型的属性值
  V_FJXX_VALUE            VARCHAR2(4000);--4分级信息的属性值
  V_LXTJR_VALUE           VARCHAR2(4000);--5是否龙终端接入的属性值
  V_ywpt_VALUE            VARCHAR2(4000);--6业务排他的属性值
  V_ZYTJYFS_VALUE         VARCHAR2(4000);--7自营厅经营方式的属性值
  V_CSJB_VALUE            VARCHAR2(4000);--8城市级别（城市）的属性值
  V_CSJB_OLD_VALUE        VARCHAR2(4000);--8城市级别（城市）旧的的属性值
  V_lsflbs_VALUE          VARCHAR2(4000);--9经营主体连锁分类标识属性的属性值
  V_CHANNEL_TYPE_CD_VALUE VARCHAR2(4000);--9销售点（渠道类型）'连锁店'节点下的值
  V_ZSSX_ATTR_VALUE_ID    NUMBER(9):=0; --销售点专属属性的属性值ID
  V_ZYMDLB_ATTR_VALUE_ID  NUMBER(9):=0; --2专营门店类别的属性值ID
  V_XSDMCLX_ATTR_VALUE_ID NUMBER(9):=0; --3销售点卖场类型的属性值ID
  V_FJXX_ATTR_VALUE_ID    NUMBER(9):=0; --4分级信息的属性值ID
  V_LXTJR_ATTR_VALUE_ID   NUMBER(9):=0; --5是否龙终端接入的属性值ID
  V_ywpt_ATTR_VALUE_ID    NUMBER(9):=0; --6业务排他的属性值ID
  V_ZYTJYFS_ATTR_VALUE_ID NUMBER(9):=0; --7自营厅经营方式的属性值ID
  V_CSJB_ATTR_VALUE_ID    NUMBER(9):=0; --8城市级别（城市）的属性值ID
  V_channel_attr_id       NUMBER(12):=0;--销售点特性ID
  V_COUNT_group_cd        NUMBER;--用于判断是否集团属性，是的话上传集团
  V_ACTION                varchar2(12) := '';--处理动作(ADD|MOD|DEL)
  V_description           VARCHAR2(2000):='proc_channel_Auto_calcul过程同步';
  V_TABLE_NAME            varchar2(30):='';--上传表名
  V_in_key_id             varchar2(12) := '';--上传对应表的主键
  V_in_modi_man           varchar2(50) := 'fztest';--修改人
  V_in_modi_reason        varchar2(256) := 'proc_channel_Auto_calcul自动算过程';--修改原因
begin
     V_COUNT_group_cd := 0;--每次记得恢复0
     --1、销售点专属属性和实体渠道归属保持同步
     select ap.attr_id into V_attr_id_ZSSX from attr_spec ap where  ap.attr_name='销售点专属属性'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_ZSSX and ap.group_cd is not null;
     FOR REC_STQDGS IN cur_STQDGS LOOP
        V_COUNT_ZSSX := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_ZSSX_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_ZSSX_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        select count(cna.attr_id) into V_COUNT_ZSSX from channel_attr cna where cna.attr_id = V_attr_id_ZSSX
         and cna.channel_id=REC_STQDGS.CHANNEL_ID and cna.status_cd='1000';
        --判断是否存在销售点专属属性
        if V_COUNT_ZSSX > 0 then
            --存在，就MOD
            V_ACTION :='MOD';
            select cna.attr_value into V_ZSSX_VALUE from channel_attr cna where cna.attr_id =  V_attr_id_ZSSX
            and cna.channel_id=REC_STQDGS.CHANNEL_ID and cna.status_cd='1000';
            if V_ZSSX_VALUE = '10' and REC_STQDGS.ATTR_VALUE ='1' then
                 --"销售点专属属性"为校园实体店10 并且“实体渠道归属”为商客1的话，那么"销售点专属属性"就修改为商客实体店20
                 V_ZSSX_VALUE := '20';
            elsif V_ZSSX_VALUE = '20' and REC_STQDGS.ATTR_VALUE ='2' then
                 --"销售点专属属性"为商客实体店20 并且“实体渠道归属”为校园2的话，那么"销售点专属属性"就修改为校园实体店10
                 V_ZSSX_VALUE := '10';
            else
                 --已经同步不需要变更及上传集团
                 V_ACTION := '';--恢复（清空）
            end if;
            --若动作不为空表示有修改
            if V_ACTION = 'MOD' then
                V_in_key_id :=REC_STQDGS.CHANNEL_ATTR_ID;
                select av.attr_value_id into V_ZSSX_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZSSX
               and av.attr_value=V_ZSSX_VALUE and av.status_cd='1000' and rownum <2;
               update channel_attr cna set cna.attr_value = V_ZSSX_VALUE,cna.description=V_description,cna.attr_value_id=V_ZSSX_ATTR_VALUE_ID
                 where cna.attr_id = V_attr_id_ZSSX and cna.channel_id=REC_STQDGS.CHANNEL_ID and cna.status_cd='1000';
            end if;
        else
             --不存在，就ADD
             V_ACTION :='ADD';
             if   REC_STQDGS.ATTR_VALUE ='1' then
                 --“实体渠道归属”为商客1的话，那么"销售点专属属性"就设置为商客实体店20
                 V_ZSSX_VALUE := '20';
             elsif REC_STQDGS.ATTR_VALUE ='2' then
                 --“实体渠道归属”为校园2的话，那么"销售点专属属性"就设置为为校园实体店10
                 V_ZSSX_VALUE := '10';
             else
                 --已经同步不需要变更及上传集团
                 V_ACTION := '';--恢复（清空）
             end if;
            --若动作不为空表示要插入数据
            if V_ACTION = 'ADD' then
               select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
               select av.attr_value_id into V_ZSSX_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZSSX
               and av.attr_value=V_ZSSX_VALUE and av.status_cd='1000' and rownum <2;
               V_in_key_id := V_channel_attr_id;
               insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_ZSSX, REC_STQDGS.CHANNEL_ID, V_ZSSX_VALUE, V_ZSSX_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
            end if;
        end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     select ap.attr_id into V_attr_id_ZYMDLB from attr_spec ap where  ap.attr_name='专营门店类别'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
      V_COUNT_group_cd := 0;--每次记得恢复0
      select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_ZYMDLB and ap.group_cd is not null;
      V_ZYMDLB_VALUE := '20';
      V_ZYMDLB_ATTR_VALUE_ID :=0;--每次记得恢复0
      select av.attr_value_id into V_ZYMDLB_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZYMDLB
      and av.attr_value=V_ZYMDLB_VALUE and av.status_cd='1000' and rownum <2;
     --2.1、专营门店类别：1如果销售点有商圈关系，自动填写为商圈店
     FOR REC_ZYMDLB_hasBiz IN cur_ZYMDLB_hasBiz LOOP
         V_COUNT_ZYMDLB :=0;--恢复0
         V_ACTION := '';--恢复（清空）
         V_in_key_id  :='';--恢复（清空）
         V_channel_attr_id :=0;--恢复0
         select count(cna.attr_id) into V_COUNT_ZYMDLB from channel_attr cna where cna.attr_id = V_attr_id_ZYMDLB
         and cna.channel_id=REC_ZYMDLB_hasBiz.CHANNEL_ID and cna.status_cd='1000';
         if V_COUNT_ZYMDLB > 0 then
             --存在，就MOD
             V_ACTION :='MOD';
             select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_ZYMDLB
             and cna.channel_id=REC_ZYMDLB_hasBiz.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
             V_in_key_id := V_channel_attr_id;
             update channel_attr cna set cna.attr_value = V_ZYMDLB_VALUE,cna.description=V_description,cna.attr_value_id=V_ZYMDLB_ATTR_VALUE_ID
              where cna.channel_attr_id = V_channel_attr_id and cna.channel_id=REC_ZYMDLB_hasBiz.CHANNEL_ID and cna.status_cd='1000';
         else
             --不存在，就ADD
             V_ACTION :='ADD';
             select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
             V_in_key_id := V_channel_attr_id;
              insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_ZYMDLB, REC_ZYMDLB_hasBiz.CHANNEL_ID, V_ZYMDLB_VALUE, V_ZYMDLB_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
         end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

      V_ZYMDLB_VALUE := '30';
      V_ZYMDLB_ATTR_VALUE_ID :=0;--每次记得恢复0
      select av.attr_value_id into V_ZYMDLB_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZYMDLB
      and av.attr_value=V_ZYMDLB_VALUE and av.status_cd='1000' and rownum <2;
     --2.2、专营门店类别：2如果销售点无商圈关系，自动填写为社区店
     FOR REC_ZYMDLB_noBiz IN cur_ZYMDLB_noBiz LOOP
         V_COUNT_ZYMDLB :=0;--恢复0
         V_ACTION := '';--恢复（清空）
         V_in_key_id  :='';--恢复（清空）
         V_channel_attr_id :=0;--恢复0
         select count(cna.attr_id) into V_COUNT_ZYMDLB from channel_attr cna where cna.attr_id = V_attr_id_ZYMDLB
         and cna.channel_id=REC_ZYMDLB_noBiz.CHANNEL_ID and cna.status_cd='1000';
         if V_COUNT_ZYMDLB > 0 then
             --存在，就MOD
             V_ACTION :='MOD';
             select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_ZYMDLB
             and cna.channel_id=REC_ZYMDLB_noBiz.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
             V_in_key_id := V_channel_attr_id;
             update channel_attr cna set cna.attr_value = V_ZYMDLB_VALUE,cna.description=V_description,cna.attr_value_id=V_ZYMDLB_ATTR_VALUE_ID
              where cna.channel_attr_id = V_channel_attr_id and cna.channel_id=REC_ZYMDLB_noBiz.CHANNEL_ID and cna.status_cd='1000';
         else
             --不存在，就ADD
             V_ACTION :='ADD';
             select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
             V_in_key_id := V_channel_attr_id;
              insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_ZYMDLB, REC_ZYMDLB_noBiz.CHANNEL_ID, V_ZYMDLB_VALUE, V_ZYMDLB_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
         end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     select ap.attr_id into V_attr_id_XSDMCLX from attr_spec ap where  ap.attr_name='销售点卖场类型'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
      V_COUNT_group_cd := 0;--每次记得恢复0
      select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_XSDMCLX and ap.group_cd is not null;
      V_XSDMCLX_VALUE := '20';
      V_XSDMCLX_ATTR_VALUE_ID :=0;--每次记得恢复0
      select av.attr_value_id into V_XSDMCLX_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_XSDMCLX
      and av.attr_value=V_XSDMCLX_VALUE and av.status_cd='1000' and rownum <2;
     --3、销售点卖场类型，把空变为“非全网通手机卖场”
     FOR REC_XSDMCLX_noExist IN cur_XSDMCLX_noExist LOOP
         V_channel_attr_id :=0;--恢复0

         --不存在，就ADD
         V_ACTION :='ADD';
         select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
         V_in_key_id := V_channel_attr_id;
         insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
           values (V_channel_attr_id, V_attr_id_XSDMCLX, REC_XSDMCLX_noExist.CHANNEL_ID, V_XSDMCLX_VALUE, V_XSDMCLX_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);

        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     V_COUNT_group_cd := 0;--每次记得恢复0
     --4、分级信息置灰，同步于“授权门店级别”（根据值对应）
     select ap.attr_id into V_attr_id_FJXX from attr_spec ap where  ap.attr_name='分级信息'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_FJXX and ap.group_cd is not null;
     FOR REC_FJXX IN cur_FJXX LOOP
        V_COUNT_FJXX := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_FJXX_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_FJXX_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        select count(cna.attr_id) into V_COUNT_FJXX from channel_attr cna where cna.attr_id = V_attr_id_FJXX
         and cna.channel_id=REC_FJXX.CHANNEL_ID and cna.status_cd='1000';
        --判断是否存在分级信息
        if V_COUNT_FJXX > 0 then
            --存在，就MOD
            V_ACTION :='MOD';
            V_FJXX_VALUE := REC_FJXX.attr_value;
            --若动作不为空表示有修改
            if V_ACTION = 'MOD' then
                V_in_key_id :=REC_FJXX.CHANNEL_ATTR_ID;
                select av.attr_value_id into V_FJXX_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_FJXX
               and av.attr_value=V_FJXX_VALUE and av.status_cd='1000' and rownum <2;
               update channel_attr cna set cna.attr_value = V_FJXX_VALUE,cna.description=V_description,cna.attr_value_id=V_FJXX_ATTR_VALUE_ID
                 where cna.attr_id = V_attr_id_FJXX and cna.channel_id=REC_FJXX.CHANNEL_ID and cna.status_cd='1000';
            end if;
        else
             --不存在，就ADD
             V_ACTION :='ADD';
             V_FJXX_VALUE := REC_FJXX.attr_value;
            --若动作不为空表示要插入数据
            if V_ACTION = 'ADD' then
               select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
               select av.attr_value_id into V_FJXX_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_FJXX
               and av.attr_value=V_FJXX_VALUE and av.status_cd='1000' and rownum <2;
               V_in_key_id := V_channel_attr_id;
               insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_FJXX, REC_FJXX.CHANNEL_ID, V_FJXX_VALUE, V_FJXX_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
            end if;
        end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     V_COUNT_group_cd := 0;--每次记得恢复0
     --5是否龙终端接入置灰,根据集团龙编码(organization.ctg_channel_nbr不为空)自动改是
     select ap.attr_id into V_attr_id_LXTJR from attr_spec ap where  ap.attr_name='是否龙终端接入'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_LXTJR and ap.group_cd is not null;
     FOR REC_LXTJR IN cur_LXTJR LOOP
        V_COUNT_LXTJR := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_LXTJR_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_LXTJR_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        select count(cna.attr_id) into V_COUNT_LXTJR from channel_attr cna where cna.attr_id = V_attr_id_LXTJR
         and cna.channel_id=REC_LXTJR.CHANNEL_ID and cna.status_cd='1000';
        --判断是否存在是否龙终端接入
        if V_COUNT_LXTJR > 0 then
            --存在，就MOD
            V_ACTION :='MOD';
            V_LXTJR_VALUE := '10';
            --若动作不为空表示有修改
            if V_ACTION = 'MOD' then
                 select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_LXTJR
                 and cna.channel_id=REC_LXTJR.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
                 V_in_key_id := V_channel_attr_id;
                select av.attr_value_id into V_LXTJR_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_LXTJR
               and av.attr_value=V_LXTJR_VALUE and av.status_cd='1000' and rownum <2;
               update channel_attr cna set cna.attr_value = V_LXTJR_VALUE,cna.description=V_description,cna.attr_value_id=V_LXTJR_ATTR_VALUE_ID
                 where cna.channel_attr_id = V_channel_attr_id and cna.channel_id=REC_LXTJR.CHANNEL_ID and cna.status_cd='1000';
            end if;
        else
             --不存在，就ADD
             V_ACTION :='ADD';
             V_LXTJR_VALUE := '10';
            --若动作不为空表示要插入数据
            if V_ACTION = 'ADD' then
               select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
               select av.attr_value_id into V_LXTJR_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_LXTJR
               and av.attr_value=V_LXTJR_VALUE and av.status_cd='1000' and rownum <2;
               V_in_key_id := V_channel_attr_id;
               insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_LXTJR, REC_LXTJR.CHANNEL_ID, V_LXTJR_VALUE, V_LXTJR_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
            end if;
        end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     V_COUNT_group_cd := 0;--每次记得恢复0
     --6.1业务排他,置灰，系统自动填写，二级类型自有厅、专营店填写(填写专营渠道)
     select ap.attr_id into V_attr_id_ywpt from attr_spec ap where  ap.attr_name='业务排他'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_ywpt and ap.group_cd is not null;
     FOR REC_ywpt_Franchise IN cur_ywpt_Franchise LOOP
        V_COUNT_ywpt := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_ywpt_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_ywpt_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        select count(cna.attr_id) into V_COUNT_ywpt from channel_attr cna where cna.attr_id = V_attr_id_ywpt
         and cna.channel_id=REC_ywpt_Franchise.CHANNEL_ID and cna.status_cd='1000';
        --判断是否存在业务排他
        if V_COUNT_ywpt > 0 then
            --存在，就MOD
            V_ACTION :='MOD';
            V_ywpt_VALUE := '10';
            --若动作不为空表示有修改
            if V_ACTION = 'MOD' then
                 select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_ywpt
                 and cna.channel_id=REC_ywpt_Franchise.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
                 V_in_key_id := V_channel_attr_id;
                select av.attr_value_id into V_ywpt_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ywpt
               and av.attr_value=V_ywpt_VALUE and av.status_cd='1000' and rownum <2;
               update channel_attr cna set cna.attr_value = V_ywpt_VALUE,cna.description=V_description,cna.attr_value_id=V_ywpt_ATTR_VALUE_ID
                 where cna.channel_attr_id = V_channel_attr_id and cna.channel_id=REC_ywpt_Franchise.CHANNEL_ID and cna.status_cd='1000';
            end if;
        else
             --不存在，就ADD
             V_ACTION :='ADD';
             V_ywpt_VALUE := '10';
            --若动作不为空表示要插入数据
            if V_ACTION = 'ADD' then
               select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
               select av.attr_value_id into V_ywpt_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ywpt
               and av.attr_value=V_ywpt_VALUE and av.status_cd='1000' and rownum <2;
               V_in_key_id := V_channel_attr_id;
               insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_ywpt, REC_ywpt_Franchise.CHANNEL_ID, V_ywpt_VALUE, V_ywpt_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
            end if;
        end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     V_COUNT_group_cd := 0;--每次记得恢复0
     --6.2业务排他,置灰，系统自动填写，二级类型独立店、连锁店、便利店填写(填写开放渠道)
     select ap.attr_id into V_attr_id_ywpt from attr_spec ap where  ap.attr_name='业务排他'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_ywpt and ap.group_cd is not null;
     FOR REC_ywpt_ToOpenUp IN cur_ywpt_ToOpenUp LOOP
        V_COUNT_ywpt := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_ywpt_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_ywpt_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        select count(cna.attr_id) into V_COUNT_ywpt from channel_attr cna where cna.attr_id = V_attr_id_ywpt
         and cna.channel_id=REC_ywpt_ToOpenUp.CHANNEL_ID and cna.status_cd='1000';
        --判断是否存在业务排他
        if V_COUNT_ywpt > 0 then
            --存在，就MOD
            V_ACTION :='MOD';
            V_ywpt_VALUE := '20';
            --若动作不为空表示有修改
            if V_ACTION = 'MOD' then
                 select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_ywpt
                 and cna.channel_id=REC_ywpt_ToOpenUp.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
                 V_in_key_id := V_channel_attr_id;
                select av.attr_value_id into V_ywpt_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ywpt
               and av.attr_value=V_ywpt_VALUE and av.status_cd='1000' and rownum <2;
               update channel_attr cna set cna.attr_value = V_ywpt_VALUE,cna.description=V_description,cna.attr_value_id=V_ywpt_ATTR_VALUE_ID
                 where cna.channel_attr_id = V_channel_attr_id and cna.channel_id=REC_ywpt_ToOpenUp.CHANNEL_ID and cna.status_cd='1000';
            end if;
        else
             --不存在，就ADD
             V_ACTION :='ADD';
             V_ywpt_VALUE := '20';
            --若动作不为空表示要插入数据
            if V_ACTION = 'ADD' then
               select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
               select av.attr_value_id into V_ywpt_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ywpt
               and av.attr_value=V_ywpt_VALUE and av.status_cd='1000' and rownum <2;
               V_in_key_id := V_channel_attr_id;
               insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_ywpt, REC_ywpt_ToOpenUp.CHANNEL_ID, V_ywpt_VALUE, V_ywpt_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
            end if;
        end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     V_COUNT_group_cd := 0;--每次记得恢复0
     --7.1自营厅经营方式,置灰，系统自动填写，三级类型外包厅填写 (填写业务外包)
     select ap.attr_id into V_attr_id_ZYTJYFS from attr_spec ap where  ap.attr_name='自营厅经营方式'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_ZYTJYFS and ap.group_cd is not null;
     FOR REC_ZYTJYFS_Outsourcing IN cur_ZYTJYFS_Outsourcing LOOP
        V_COUNT_ZYTJYFS := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_ZYTJYFS_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_ZYTJYFS_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        select count(cna.attr_id) into V_COUNT_ZYTJYFS from channel_attr cna where cna.attr_id = V_attr_id_ZYTJYFS
         and cna.channel_id=REC_ZYTJYFS_Outsourcing.CHANNEL_ID and cna.status_cd='1000';
        --判断是否存在自营厅经营方式
        if V_COUNT_ZYTJYFS > 0 then
            --存在，就MOD
            V_ACTION :='MOD';
            V_ZYTJYFS_VALUE := '20';
            --若动作不为空表示有修改
            if V_ACTION = 'MOD' then
                 select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_ZYTJYFS
                 and cna.channel_id=REC_ZYTJYFS_Outsourcing.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
                 V_in_key_id := V_channel_attr_id;
                select av.attr_value_id into V_ZYTJYFS_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZYTJYFS
               and av.attr_value=V_ZYTJYFS_VALUE and av.status_cd='1000' and rownum <2;
               update channel_attr cna set cna.attr_value = V_ZYTJYFS_VALUE,cna.description=V_description,cna.attr_value_id=V_ZYTJYFS_ATTR_VALUE_ID
                 where cna.attr_id = V_attr_id_ZYTJYFS and cna.channel_id=REC_ZYTJYFS_Outsourcing.CHANNEL_ID and cna.status_cd='1000';
            end if;
        else
             --不存在，就ADD
             V_ACTION :='ADD';
             V_ZYTJYFS_VALUE := '20';
            --若动作不为空表示要插入数据
            if V_ACTION = 'ADD' then
               select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
               select av.attr_value_id into V_ZYTJYFS_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZYTJYFS
               and av.attr_value=V_ZYTJYFS_VALUE and av.status_cd='1000' and rownum <2;
               V_in_key_id := V_channel_attr_id;
               insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_ZYTJYFS, REC_ZYTJYFS_Outsourcing.CHANNEL_ID, V_ZYTJYFS_VALUE, V_ZYTJYFS_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
            end if;
        end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     V_COUNT_group_cd := 0;--每次记得恢复0
     --7.2自营厅经营方式,置灰，系统自动填写，三级类型直营厅填写(填写整厅外包（包括业务及人员外包）)
     select ap.attr_id into V_attr_id_ZYTJYFS from attr_spec ap where  ap.attr_name='自营厅经营方式'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_ZYTJYFS and ap.group_cd is not null;
     FOR REC_ZYTJYFS_wholeOutsourcing IN cur_ZYTJYFS_wholeOutsourcing LOOP
        V_COUNT_ZYTJYFS := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_ZYTJYFS_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_ZYTJYFS_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        select count(cna.attr_id) into V_COUNT_ZYTJYFS from channel_attr cna where cna.attr_id = V_attr_id_ZYTJYFS
         and cna.channel_id=REC_ZYTJYFS_wholeOutsourcing.CHANNEL_ID and cna.status_cd='1000';
        --判断是否存在自营厅经营方式
        if V_COUNT_ZYTJYFS > 0 then
            --存在，就MOD
            V_ACTION :='MOD';
            V_ZYTJYFS_VALUE := '30';
            --若动作不为空表示有修改
            if V_ACTION = 'MOD' then
                 select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_ZYTJYFS
                 and cna.channel_id=REC_ZYTJYFS_wholeOutsourcing.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
                 V_in_key_id := V_channel_attr_id;
                select av.attr_value_id into V_ZYTJYFS_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZYTJYFS
               and av.attr_value=V_ZYTJYFS_VALUE and av.status_cd='1000' and rownum <2;
               update channel_attr cna set cna.attr_value = V_ZYTJYFS_VALUE,cna.description=V_description,cna.attr_value_id=V_ZYTJYFS_ATTR_VALUE_ID
                 where cna.attr_id = V_attr_id_ZYTJYFS and cna.channel_id=REC_ZYTJYFS_wholeOutsourcing.CHANNEL_ID and cna.status_cd='1000';
            end if;
        else
             --不存在，就ADD
             V_ACTION :='ADD';
             V_ZYTJYFS_VALUE := '30';
            --若动作不为空表示要插入数据
            if V_ACTION = 'ADD' then
               select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
               select av.attr_value_id into V_ZYTJYFS_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_ZYTJYFS
               and av.attr_value=V_ZYTJYFS_VALUE and av.status_cd='1000' and rownum <2;
               V_in_key_id := V_channel_attr_id;
               insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
               values (V_channel_attr_id, V_attr_id_ZYTJYFS, REC_ZYTJYFS_wholeOutsourcing.CHANNEL_ID, V_ZYTJYFS_VALUE, V_ZYTJYFS_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
            end if;
        end if;
        --是集团属性的话，先提交事务再同步集团
        if V_COUNT_group_cd >0 then
            --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
            if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                COMMIT;
                V_TABLE_NAME :='CHANNEL_ATTR';
                --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
            end if;
        end if;
     end loop;

     V_COUNT_group_cd := 0;--每次记得恢复0
     --8城市级别（城市），集团有个配置表，什么城市什么级别
     select ap.attr_id into V_attr_id_CSJB from attr_spec ap where  ap.attr_name='城市级别（城市）'
      and ap.class_id=30   and ap.status_cd='1000' and rownum<2;
     select count(*) into V_COUNT_group_cd from attr_spec ap where ap.attr_id=V_attr_id_CSJB and ap.group_cd is not null;
     FOR REC_CSJB IN cur_CSJB LOOP
        V_COUNT_CSJB := 0;--恢复0
        V_COUNT_CITY_LEVEL_CONFIG :=0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_CSJB_VALUE :='';--恢复（清空）
        V_CSJB_OLD_VALUE :='';--恢复（清空）
        V_channel_attr_id :=0;--恢复0
        V_CSJB_ATTR_VALUE_ID :=0;--恢复0
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）
        if REC_CSJB.COMMON_REGION_ID is not null then
              select count(av2.attr_value) into V_COUNT_CITY_LEVEL_CONFIG from attr_value av2 where av2.attr_id=950022490 and av2.attr_value_name in(select cr.common_region_id from common_region cr
              connect by cr.common_region_id = prior cr.up_region_id start with cr.common_region_id=REC_CSJB.COMMON_REGION_ID  and cr.status_cd='1000');
             if V_COUNT_CITY_LEVEL_CONFIG >0 then
                  select av2.attr_value into V_CSJB_VALUE from attr_value av2 where av2.attr_id=950022490 and av2.attr_value_name in(select cr.common_region_id from common_region cr
                  connect by cr.common_region_id = prior cr.up_region_id start with cr.common_region_id=REC_CSJB.COMMON_REGION_ID  and cr.status_cd='1000') and rownum<2;
                  select count(cna.attr_id) into V_COUNT_CSJB from channel_attr cna where cna.attr_id = V_attr_id_CSJB
                   and cna.channel_id=REC_CSJB.CHANNEL_ID and cna.status_cd='1000';
                  --判断是否存在城市级别（城市）
                  if V_COUNT_CSJB > 0 then
                      select cna.attr_value into V_CSJB_OLD_VALUE from channel_attr cna where cna.attr_id = V_attr_id_CSJB
                      and cna.channel_id=REC_CSJB.CHANNEL_ID and cna.status_cd='1000';
                      if V_CSJB_OLD_VALUE = V_CSJB_VALUE then
                        --相等表示不必要修改
                        V_ACTION :='';
                      else
                        --不想等，就MOD
                        V_ACTION :='MOD';
                      end if;
                      --若动作不为空表示有修改
                      if V_ACTION = 'MOD' then
                           select cna.channel_attr_id into V_channel_attr_id from channel_attr cna where cna.attr_id = V_attr_id_CSJB
                           and cna.channel_id=REC_CSJB.CHANNEL_ID and cna.status_cd='1000' and rownum <2;
                           V_in_key_id := V_channel_attr_id;
                          select av.attr_value_id into V_CSJB_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_CSJB
                         and av.attr_value=V_CSJB_VALUE and av.status_cd='1000' and rownum <2;
                         update channel_attr cna set cna.attr_value = V_CSJB_VALUE,cna.description=V_description,cna.attr_value_id=V_CSJB_ATTR_VALUE_ID
                           where cna.channel_attr_id = V_channel_attr_id and cna.channel_id=REC_CSJB.CHANNEL_ID and cna.status_cd='1000';
                      end if;
                  else
                       --不存在，就ADD
                       V_ACTION :='ADD';
                      --若动作不为空表示要插入数据
                      if V_ACTION = 'ADD' then
                         select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
                         select av.attr_value_id into V_CSJB_ATTR_VALUE_ID from attr_value av where av.attr_id=V_attr_id_CSJB
                         and av.attr_value=V_CSJB_VALUE and av.status_cd='1000' and rownum <2;
                         V_in_key_id := V_channel_attr_id;
                         insert into channel_attr (CHANNEL_ATTR_ID, ATTR_ID, CHANNEL_ID, ATTR_VALUE, ATTR_VALUE_ID, DESCRIPTION, STATUS_CD, STATUS_DATE, CREATE_DATE, AREA_ID, REGION_CD, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
                         values (V_channel_attr_id, V_attr_id_CSJB, REC_CSJB.CHANNEL_ID, V_CSJB_VALUE, V_CSJB_ATTR_VALUE_ID, V_description, '1000', sysdate, sysdate, 2, 11, null, sysdate, null);
                      end if;
                  end if;
                  --是集团属性的话，先提交事务再同步集团
                  if V_COUNT_group_cd >0 then
                      --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
                      if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
                          COMMIT;
                          V_TABLE_NAME :='CHANNEL_ATTR';
                          --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
                          fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
                      end if;
                  end if;
            end if;
        end if;
     end loop;


     --9连锁店,销售点'连锁店'有，经营主体没有'连锁分类标识'则销售点改为'县级连锁'否则和经营主体一致
     select ap.attr_id into V_attr_id_lsflbs from attr_spec ap where  ap.attr_name='连锁分类标识'
      and ap.class_id=950000068   and ap.status_cd='1000' and rownum<2;
     FOR REC_lsflbs IN cur_lsflbs LOOP
        V_COUNT_lsflbs := 0;--恢复0
        V_ACTION := '';--恢复（清空）
        V_lsflbs_VALUE :='';--恢复（清空）
        V_CHANNEL_TYPE_CD_VALUE :='';--恢复（清空）
        V_TABLE_NAME :='';--恢复（清空）
        V_in_key_id  :='';--恢复（清空）

        select count(opsa.attr_value) into V_COUNT_lsflbs  from operators_attr opsa where opsa.attr_id = V_attr_id_lsflbs
        and opsa.status_cd = '1000'   and exists (select cnop.operators_id from channel_operators_rela cnop
         where cnop.channel_id = REC_lsflbs.Channel_Id   and cnop.operators_id = opsa.operators_id);

        if V_COUNT_lsflbs > 0 then
            select decode(opsa.attr_value,'1','110301','2','110302','3','110304','3','110304','5','110303') into V_lsflbs_VALUE
             from operators_attr opsa where opsa.attr_id = V_attr_id_lsflbs
            and opsa.status_cd = '1000'   and exists (select cnop.operators_id from channel_operators_rela cnop
             where cnop.channel_id = REC_lsflbs.Channel_Id   and cnop.operators_id = opsa.operators_id) and rownum<2;
             if V_lsflbs_VALUE is not null then
                V_CHANNEL_TYPE_CD_VALUE := V_lsflbs_VALUE;
             end if;
        else
            --经营主体没有'连锁分类标识'则销售点改为'县级连锁'
            V_CHANNEL_TYPE_CD_VALUE := '110304';
        end if;
        if REC_lsflbs.Channel_Type_Cd = V_CHANNEL_TYPE_CD_VALUE then
             V_ACTION := '';
        else
             if V_CHANNEL_TYPE_CD_VALUE is not null then
                 V_ACTION := 'MOD';
                 V_in_key_id := REC_lsflbs.Channel_Id;
                 update channel cn set cn.channel_type_cd = V_CHANNEL_TYPE_CD_VALUE where cn.channel_id = REC_lsflbs.Channel_Id;
             end if;
      end if;
        --若动作不为空表示要上传集团,先提交事务，再调用同步集团的包过程
        if  V_ACTION = 'ADD' or V_ACTION = 'MOD' then
            COMMIT;
            V_TABLE_NAME :='CHANNEL';
            --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
            fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,V_in_key_id,V_ACTION,V_in_modi_man,V_in_modi_reason);
        end if;

     end loop;

      COMMIT;

      O_RESULT := 'TRUE';
    EXCEPTION
      WHEN OTHERS THEN
        O_RESULT := 'FALSE';
        O_MSG    := '失败:' || SQLERRM;
        ROLLBACK;
end proc_channel_Auto_calcul;
/
