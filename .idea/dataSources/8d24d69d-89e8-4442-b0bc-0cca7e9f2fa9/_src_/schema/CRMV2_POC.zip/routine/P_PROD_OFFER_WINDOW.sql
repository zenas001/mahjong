CREATE PROCEDURE           "P_PROD_OFFER_WINDOW"(PROD_OFFER_INPUT VARCHAR2, -- A端输入规格id集合
                                                  ATTR_ID_INPUT    VARCHAR2, -- B端输入规格id集合
                                                  EVENT_ID         VARCHAR2, -- 存储过程编码
                                                  AREA_ID          VARCHAR2,
                                                  STAFF            NUMBER,
                                                  IF_NEW_GRID      NUMBER,
                                                  REMARK           VARCHAR2,
                                                  RESULT_MESSAGE   OUT VARCHAR2) is

  v_staff     int; -- varchar2(50);
  v_area_id   int;
  v_event_sql varchar2(1000);
  v_attr_sql  varchar2(1000);

  v_window_id             int;
  v_win_componet_id       int;
  v_componet_id           int;
  v_display_order         int;
  v_prod_offer_attr_order int;
  v_display_type          varchar2(50);

  sys_class_num         int;
  num                   int;
  num1                  int;
  num2                  int;
  v_prod_offer_attr_num int;

  type t_pm_extend_restrict1 is ref cursor;
  c1 t_pm_extend_restrict1;
  r1 prod_offer%rowtype;

  type t_pm_extend_restrict2 is ref cursor;
  c2 t_pm_extend_restrict1;
  r2 service_offer%rowtype;

  type t_pm_extend_restrict3 is ref cursor;
  c3 t_pm_extend_restrict1;
  r3 attr_spec%rowtype;

begin

  if PROD_OFFER_INPUT is null then
    RESULT_MESSAGE := '销售品查询语句是必输项！';
    return;
  end if;

  if REMARK is null then
    RESULT_MESSAGE := '请输入备注信息！';
    return;
  end if;

  if staff is not null then
    v_staff := staff;
  else
    RESULT_MESSAGE := '员工工号是必输项！';
    return;
  end if;

  if EVENT_ID is null then
    v_event_sql := 'select * from service_offer where sort=''OFFER'' and service_offer_id in (''500'',''503'')';
  end if;

  if EVENT_ID is not null then
    v_event_sql := 'select * from service_offer where sort=''OFFER'' and service_offer_id in (' ||
                   event_id || ')';
    /* v_pos_start:=1;
    while v_position<length(EVENT_ID) loop
      v_substr(EVENT_ID,v_pos_start,instr(EVENT_ID,',',v_pos_start,1)-1);
    end loop;*/
  end if;

  if area_id is null then
    v_area_id := 1;
  else
    v_area_id := area_id;
  end if;

  open c1 for PROD_OFFER_INPUT;
  fetch c1
    into r1;
  while (c1%found) loop

    if ATTR_ID_INPUT is null then
      v_attr_sql := 'select distinct b.* from prod_offer_attr a,attr_spec b where a.prod_offer_id=' ||
                    r1.prod_offer_id ||
                    ' and a.status_cd<>''1100'' and a.attr_id=b.attr_id order by b.attr_id';
    end if;
    if ATTR_ID_INPUT is not null then
      if instr(v_attr_sql, 'order by', 1, 1) = 0 then
        v_attr_sql := ATTR_ID_INPUT || ' order by attr_id';
      end if;
    end if;

    RESULT_MESSAGE := v_attr_sql;

    open c2 for v_event_sql;
    fetch c2
      into r2;
    while (c2%found) loop

      select count(*)
        into v_prod_offer_attr_num
        from prod_offer_attr a
       where prod_offer_id = r1.prod_offer_id
         and status_cd <> '1100'
         and not exists
       (select 1
                from sys_win_componet
               where attr_id = a.attr_id
                 and status_cd <> '1100'
                 and win_id in
                     (select obj_id
                        from sys_class_rel_obj
                       where event_id = r2.service_offer_id));

      RESULT_MESSAGE := v_prod_offer_attr_num;

      -- 存在未配置页面的属性
      if v_prod_offer_attr_num <> 0 then

        select count(*)
          into sys_class_num
          from sys_class_rel_obj a, sys_window b
         where a.class_id = r1.prod_offer_id
           and a.status_cd = '1000'
           and a.obj_id = b.win_id
           and b.class_id = r1.prod_offer_id
           and a.event_id = r2.action_cd;

        if sys_class_num <> 0 then
          select b.win_id
            into v_window_id
            from sys_class_rel_obj a, sys_window b
           where a.class_id = r1.prod_offer_id
             and a.status_cd = '1000'
             and a.obj_id = b.win_id
             and b.class_id = r1.prod_offer_id
             and a.event_id = r2.action_cd;
          UPDATE sys_window
             SET WIN_DESC = WIN_DESC || ';' || REMARK
           WHERE WIN_ID IN (SELECT OBJ_ID
                              FROM sys_class_rel_obj
                             WHERE class_id = r1.prod_offer_id
                               AND status_cd = '1000'
                               AND event_id = r2.action_cd)
             AND class_id = r1.prod_offer_id;
        end if;

        if sys_class_num = 0 then
          select seq_sys_window_id.nextval into v_window_id from dual;
          insert into sys_window
          values
            (v_window_id,
             r1.prod_offer_id || '-' || r2.service_offer_id || 'WIN',
             r1.prod_offer_name || '-' || r2.service_offer_name,
             '',
             REMARK, -- 描述，备注信息
             '',
             '',
             r1.prod_offer_id,
             '1000',
             sysdate,
             sysdate,
             sysdate,
             '',
             '',
             '',
             v_area_id,
             v_area_id,
             v_staff,
             v_staff);
          insert into sys_class_rel_obj
          values
            (seq_sys_class_rel_obj_id.nextval,
             r1.prod_offer_id,
             r2.service_offer_id,
             'WIN',
             v_window_id,
             '',
             '1000',
             sysdate,
             sysdate,
             sysdate,
             '',
             v_area_id,
             v_area_id,
             v_staff,
             v_staff);
        end if;

        if (IF_NEW_GRID = 0 or IF_NEW_GRID is null) then
          select nvl(max(componet_id), 0)
            into v_win_componet_id
            from sys_win_componet
           where win_id = v_window_id
             and componet_code = 'GRID';
          if v_win_componet_id = 0 then
            select seq_sys_win_componet_id.nextval
              into v_win_componet_id
              from dual;
            insert into sys_win_componet
            values
              (v_win_componet_id,
               '-1',
               v_window_id,
               '',
               'GRID',
               '表格',
               '',
               '',
               1,
               '',
               '',
               '',
               '',
               0,
               1,
               1,
               2,
               1,
               '',
               '1000',
               sysdate,
               sysdate,
               sysdate,
               'grid',
               '',
               '',
               'LAYOUT',
               area_id,
               area_id,
               v_staff,
               v_staff,
               '',
               1);
          end if;
        end if;

        if IF_NEW_GRID = 1 then
          select nvl(max(display_order), 0) + 1
            into v_display_order
            from sys_win_componet
           where win_id = v_window_id
             and componet_code = 'GRID';

          select seq_sys_win_componet_id.nextval
            into v_win_componet_id
            from dual;
          insert into sys_win_componet
          values
            (v_win_componet_id,
             '-1',
             v_window_id,
             '',
             'GRID',
             '表格',
             '',
             '',
             1,
             '',
             '',
             '',
             '',
             0,
             v_display_order,
             1,
             2,
             1,
             '',
             '1000',
             sysdate,
             sysdate,
             sysdate,
             'grid',
             '',
             '',
             'LAYOUT',
             area_id,
             area_id,
             v_staff,
             v_staff,
             '',
             1);

        end if;

        open c3 for v_attr_sql;
        fetch c3
          into r3;
        while (c3%found) loop
          select count(*)
            into num
            from prod_offer_attr
           where prod_offer_id = r1.prod_offer_id
             and attr_id = r3.attr_id
             and status_cd <> '1100';

          select count(*)
            into num1
            from sys_win_componet
           where win_id = v_window_id
             and attr_id = r3.attr_id
             and status_cd <> '1100';

          if num <> 0 and num1 = 0 then

            select count(*)
              into num2
              from prod_offer_attr a
             where prod_offer_id = r1.prod_offer_id
               and status_cd <> '1100'
               and not exists (select 1
                      from sys_win_componet
                     where attr_id = a.attr_id
                       and status_cd <> '1100')
               and attr_id = r3.attr_id;

            if num2 <> 0 then
              select nvl(row_num, 0)
                into v_prod_offer_attr_order
                from (select prod_offer_attr_id, attr_id, rownum row_num
                        from prod_offer_attr a
                       where prod_offer_id = r1.prod_offer_id
                         and status_cd <> '1100'
                         and not exists
                       (select 1
                                from sys_win_componet
                               where attr_id = a.attr_id
                                 and status_cd <> '1100')
                       order by prod_offer_attr_id)
               where attr_id = r3.attr_id;

              select nvl(max(display_order), 0) + v_prod_offer_attr_order
                into v_display_order
                from sys_win_componet
               where win_id = v_window_id
                 and parent_componet_id = v_win_componet_id;

              if r3.attr_type = 'T3' then
                v_display_type := 'selectlist';
              end if;
              if (r3.attr_type = 'T1' and r3.attr_value_type = 'F') then
                v_display_type := 'money';
              end if;
              if (r3.attr_type = 'T1' and r3.attr_value_type <> 'F') then
                v_display_type := 'text';
              end if;

              insert into sys_win_componet
              values
                (seq_sys_win_componet_id.nextval,
                 r3.attr_id,
                 v_window_id,
                 v_win_componet_id,
                 r3.attr_cd,
                 r3.attr_name,
                 r3.attr_desc,
                 r3.attr_desc,
                 1,
                 '',
                 '', -- 宽度
                 '',
                 '',
                 0, -- 只读
                 v_display_order, --排序
                 0, -- 是否换行
                 1,
                 1,
                 '',
                 '1000',
                 sysdate,
                 sysdate,
                 sysdate,
                 v_display_type, -- 显示类型
                 '',
                 '',
                 'LAYOUT', -- 或'INPUT'
                 area_id,
                 area_id,
                 v_staff,
                 v_staff,
                 r3.class_id,
                 1);
            end if;
          end if;
          fetch c3
            into r3;
        end loop;
        close c3;
      end if;
      fetch c2
        into r2;
    end loop;
    close c2;
    fetch c1
      into r1;
  end loop;
  close c1;
end;
/
