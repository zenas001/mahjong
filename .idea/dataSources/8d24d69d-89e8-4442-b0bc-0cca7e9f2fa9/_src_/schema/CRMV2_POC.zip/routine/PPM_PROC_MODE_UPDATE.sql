CREATE procedure           ppm_proc_mode_update(v_area_id varchar2,v_proc_mode_code varchar2) as
v_proc_mode_id1 number; -- 临时表配置能力ID
v_proc_mode_id2 number; -- 1表配置能力ID
--v_proc_attr_id1 number;-- 临时表配置能力ID
v_proc_attr_id2 number; -- 1表配置能力ID

  -- attrspec 动态游标
  type attr_sor_type is ref cursor return tmp_proc_mode_attr%rowtype;
  type value_sor_type is ref cursor return tmp_proc_mode_attr_value%rowtype;

  attr_sor  attr_sor_type;
  value_sor value_sor_type;

  tmp_attr tmp_proc_mode_attr%rowtype;

begin
  -- 获取临时表ID
  SELECT p.proc_mode_id into v_proc_mode_id1 FROM tmp_proc_mode p where p.proc_mode_code = v_proc_mode_code;
  -- 获取配置能力规格数据
  begin
     SELECT p.proc_mode_id into v_proc_mode_id2 FROM proc_mode p where p.proc_mode_code = v_proc_mode_code;
  exception
    when NO_DATA_FOUND then
    -- 对于新增的数据 配置能力ID各个环境保持一致
     insert into proc_mode(PROC_MODE_ID,PROC_MODE_NAME,PROC_MODE_CODE,PROC_MODE_DESC,PROC_MODE_TYPE,VERSION_NUMBER,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF) SELECT PROC_MODE_ID,PROC_MODE_NAME,PROC_MODE_CODE,PROC_MODE_DESC,PROC_MODE_TYPE,VERSION_NUMBER,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF FROM tmp_proc_mode p where p.proc_mode_code = v_proc_mode_code;
     SELECT p.proc_mode_id into v_proc_mode_id2 FROM proc_mode p where p.proc_mode_code = v_proc_mode_code;

     insert into ppm_proc_service_rel(PROC_SERVICE_REL_ID,PROC_MODE_ID,SERVICE_OFFER_ID,AREA_ID,REGION_CD,STATUS_CD)
      SELECT SEQ_PROC_SERVICE_REL_ID.Nextval,v_proc_mode_id2,SERVICE_OFFER_ID,AREA_ID,REGION_CD,STATUS_CD FROM tmp_ppm_proc_service_rel rel where rel.proc_mode_id = v_proc_mode_id1;

     insert into proc_mode_real_sys(CONF_ABILITY_SPEC_RELA_SYS_ID,CONF_ABILITY_SPEC_ID,SYSTEM_CODE,STATUS_CD)
     SELECT SEQ_PROC_MODE_REAL_SYS_ID.Nextval,v_proc_mode_id2,SYSTEM_CODE,STATUS_CD FROM tmp_proc_mode_real_sys rel where rel.conf_ability_spec_id = v_proc_mode_id1;

     insert into proc_mode_catalog_item(PROC_MODE_CATALOG_ITEM_ID,CATALOG_ITEM_ID,PROC_MODE_ID,STATUS_CD)
      SELECT SEQ_PROC_MODE_CATALOG_ITEM_ID.Nextval,(SELECT t.catalog_item_id FROM catalog_item t where t.catalog_item_cd = '103000' and t.catalog_id = 102),v_proc_mode_id2,STATUS_CD FROM tmp_proc_mode_catalog_item where proc_mode_id = v_proc_mode_id1;
  end;

  delete from proc_mode_attr_value p2 where p2.proc_mode_attr_id IN ( SELECT p1.proc_mode_attr_id FROM proc_mode_attr p1 where p1.proc_mode_id = v_proc_mode_id2 ) ;
  delete proc_mode_attr p1 where p1.proc_mode_id = v_proc_mode_id2;


  --  插入主数据,tmp_proc_mode_attr 的remark字段为新的attr_id。 proc_mode_attr 的remark字段为 tmp_proc_mode_attr 的proc_mode_attr_id
   open attr_sor for SELECT * FROM tmp_proc_mode_attr t where t.proc_mode_id = v_proc_mode_id1;
    loop
    fetch attr_sor into tmp_attr;
    exit when attr_sor%notfound;
         --插入数据
         select seq_proc_mode_attr_id.nextval into v_proc_attr_id2 from dual;
         insert into proc_mode_attr(PROC_MODE_ATTR_ID,PROC_MODE_ID,ATTR_ID,STATUS_CD,remark)
         SELECT v_proc_attr_id2,v_proc_mode_id2,p.NEW_ATTR_ID,STATUS_CD,remark
         FROM tmp_proc_mode_attr p where  P.PROC_MODE_ATTR_ID = tmp_attr.proc_mode_attr_id;

         insert into proc_mode_attr_value (PROC_MODE_VALUE_ID,PROC_MODE_ATTR_ID,ATTR_VALUE_ID,REMARK,STATUS_CD)
         SELECT SEQ_PROC_MODE_VALUE_ID.Nextval,v_proc_attr_id2,t.NEW_VALUE_ID,remark,STATUS_CD
         FROM tmp_proc_mode_attr_value t
         where t.proc_mode_attr_id =  tmp_attr.proc_mode_attr_id ;


    end loop;
	close attr_sor;
  --insert into proc_mode_attr(PROC_MODE_ATTR_ID,PROC_MODE_ID,ATTR_ID,STATUS_CD,remark)
  --SELECT seq_proc_mode_attr_id.nextval,v_proc_mode_id2,p.remark,STATUS_CD,p.proc_mode_attr_id
  --FROM tmp_proc_mode_attr p where p.proc_mode_id = v_proc_mode_id1;

  --insert into proc_mode_attr_value (PROC_MODE_VALUE_ID,PROC_MODE_ATTR_ID,ATTR_VALUE_ID,REMARK,STATUS_CD)
 -- SELECT SEQ_PROC_MODE_VALUE_ID.Nextval,( SELECT p3.proc_mode_attr_id FROM proc_mode_attr p3 where p3.remark = to_char( t.proc_mode_attr_id)),t.remark,REMARK,STATUS_CD FROM tmp_proc_mode_attr_value t
 -- where t.proc_mode_attr_id IN ( SELECT t2.proc_mode_attr_id FROM tmp_proc_mode_attr t2 where t2.proc_mode_id = v_proc_mode_id1 ) ;

  update_proc_mode_bycode(v_area_id,v_proc_mode_code);
end;
/
