CREATE PROCEDURE           JUDGE_EXIST_ECP_RELA(IN_PROD_INST_ID NUMBER,
                                                 IN_PRODUCT_ID NUMBER,
                                                 OUT_RET OUT NUMBER) IS
  I               NUMBER := 0;
  J               NUMBER := 0;
  K               NUMBER := 0;
  P_PROD_ID       NUMBER := 0;
  P_RELA_IDA      NUMBER := 0;
  P_RELA_IDB      NUMBER := 0;
  P_PROD_SPEC_ID  NUMBER := 0;
  P_OFFER_SPEC_ID NUMBER := 0;
  ORET            NUMBER := 0;
BEGIN
  /*
  判断传入的功能销售品，与同客户下，是否与E家存在构成关系,如果存在，返回E家销售品实例ID
  created by zhengzhh 2011-10-19
  */
  --1.判断规格层面是否构成关系(PARENT_RELA_ID不能为空)
  SELECT COUNT(1)
    INTO I
    FROM ZZH_ECP_OFFER_PROD_RELA ZE
   WHERE ZE.PARENT_RELA_ID IS NOT NULL
     AND ZE.PRODUCT_ID = IN_PRODUCT_ID;
  IF I > 0 THEN
    --获取对应主产品实例ID
    SELECT PR.PROD_INST_A_ID, PI.PRODUCT_ID
      INTO P_PROD_ID, P_PROD_SPEC_ID
      FROM PROD_INST_REL PR, PROD_INST PI
     WHERE PI.STATUS_CD = '10'
       AND PR.STATUS_CD = '10'
       AND PI.PROD_INST_ID = PROD_INST_A_ID
       AND PR.PROD_INST_Z_ID = IN_PROD_INST_ID;
    --2.判断对应的主产品实例，是否在E家构成关系里
    SELECT COUNT(1)
      INTO J
      FROM ZZH_OFFER_PROD_INST_ECP
     WHERE PROD_INST_ID = P_PROD_ID;
    IF J > 0 THEN
      --存在关系，取出E家销售品id及规格
      SELECT PROD_OFFER_INST_ID, PROD_OFFER_ID
        INTO ORET, P_OFFER_SPEC_ID
        FROM ZZH_OFFER_PROD_INST_ECP
       WHERE PROD_INST_ID = P_PROD_ID;
      --获取构成关系
      --获取构成关系表中功能类销售品的父关联节点ID
      SELECT PARENT_RELA_ID
        INTO P_RELA_IDA
        FROM ZZH_ECP_OFFER_PROD_RELA ZE
       WHERE ZE.PRODUCT_ID = IN_PRODUCT_ID
         AND ZE.PROD_OFFER_ID = P_OFFER_SPEC_ID;
      --获取功能类销售品父产品在构成关系中的ID
      SELECT OFFER_PROD_RELA_ID
        INTO P_RELA_IDB
        FROM ZZH_ECP_OFFER_PROD_RELA ZE
       WHERE ZE.PRODUCT_ID = P_PROD_SPEC_ID
         AND ZE.PROD_OFFER_ID = P_OFFER_SPEC_ID;
      IF P_RELA_IDA = P_RELA_IDB THEN
        --判定成功
        OUT_RET := ORET;
      ELSE
        OUT_RET := 0;
      END IF;
    ELSE
      OUT_RET := 0;
    END IF;
  ELSE
    OUT_RET := 0;
  END IF;
  --如果发生异常错误，返回-1
EXCEPTION
  WHEN OTHERS THEN
    NULL;
    OUT_RET := -1;
END JUDGE_EXIST_ECP_RELA;
/
