CREATE function           getProductDesc(in_product_id in long) return varchar2 is
  Result varchar2(5000);
begin
  Result := '';
  select a.product_name || '[' || c.attr_value_name || '-' || b.attr_value_name || ']' into Result from product a, attr_value b, attr_value c where a.product_id = in_product_id
  and a.product_type = c.attr_value and c.attr_id = 318
  and a.prod_func_type= b.attr_value and b.attr_id = 322;
  return(Result);
end getProductDesc;
/
