CREATE procedure           niud_p_test(o_msg out varchar2) is
  cursor cur is
    select a1.prefer_spec_id,
           a1.name           prefer_name,
           a1.cre_area_id,
           a2.rela_id,
           a2.name           role_name,
           a4.name           mdse_name
      from crm.prefer_price_spec@lk_crmv1     a1,
           crm.prefer_mdse_spec_rela@lk_crmv1 a2,
           crm.pm_special_mdse_spec@lk_crmv1  a3,
           crm.mdse_spec@lk_crmv1             a4
     where a1.prefer_spec_id = a2.prefer_spec_id
       and a2.rela_id = a3.role_id
       and a3.mdse_spec_id = a4.mdse_spec_id
       and a3.mdse_spec_id in (600261489)
       and a1.state <> '70X'
       and a2.state = '70A'
       and a3.state = '70A'
       and a1.name not like '%e%'
       and a1.type = '105';
  v_msg varchar2(8000);
  v_ret number(6);
begin
  for rec in cur loop
    v_ret := niud_f_ehome_tel_importer(rec.prefer_spec_id, v_msg);
    if v_ret = 0 then
      o_msg := o_msg || to_char(rec.prefer_spec_id) || ',';
    end if;
  end loop;
end;
/
