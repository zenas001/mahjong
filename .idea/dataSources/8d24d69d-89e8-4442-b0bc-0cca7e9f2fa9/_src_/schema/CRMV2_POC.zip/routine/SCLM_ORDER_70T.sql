CREATE PROCEDURE           SCLM_ORDER_70T(O_CODE OUT VARCHAR2,
                                           O_MSG  OUT VARCHAR2) IS

  /**
  *接口描述：查询推荐工单表中70A、70B的超时未回复的单，更改状态70T周时进完成表
  *执行成功返回1，失败返回0
  **/
  V_TIME        NUMBER; --存储历史表序列
  V_MOBILEPHONE VARCHAR2(20); --专业手机号
  V_MSG_CONTENT VARCHAR2(500); --短信内容
  V_DATE        VARCHAR2(20);
  PRAGMA AUTONOMOUS_TRANSACTION; --实现自治事务处理
BEGIN
  --取规则的时限配置：
  O_CODE := '0'; ---失败标识返回
  FOR REC IN (SELECT SCLM_TJ_ORDER_ID,
                     SCLM_PARTNER_ID,
                     SERVICE_CODE,
                     REGION_ID,
                     TO_CHAR(CREATE_DATE, 'yyyy-mm-dd hh24:mi:ss') AS CREATE_DATE
                FROM SCLM_TJ_ORDER
               WHERE STATUS IN ('70A', '70B')
                 and ROWNUM < 100) LOOP
    select paramValue
      into V_TIME
      from (SELECT nvl(C.SCLM_RULE_PARAMS_VALUE, 0) paramValue
              FROM SCLM_RULE             A,
                   SCLM_RULE_REGION      B,
                   SCLM_RULE_PARAMS      C,
                   SCLM_RULE_SPEC        D,
                   SCLM_RULE_PARAMS_SPEC E
             WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
               AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
               AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
               AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_HFYXQ'
               AND C.SCLM_RULE_PARAMS_SPEC_ID = E.SCLM_RULE_PARAMS_SPEC_ID
               AND E.SCLM_RULE_PARAMS_SPEC_CODE = 'HFYXQ_TIME'
               AND B.AREA_ID IN
                   (SELECT ID
                      FROM P_AREA
                    CONNECT BY PRIOR SUPER = ID
                     START WITH ID = REC.REGION_ID)
             order by b.area_id desc)
     where ROWNUM < 2;

    SELECT TO_CHAR(SYSDATE - NVL(V_TIME, 0) / 24, 'yyyy-mm-dd hh24:mi:ss')
      INTO V_DATE
      FROM DUAL;
    /* dbms_output.put_line(V_TIME);
    dbms_output.put_line(V_DATE);
    if V_TIME<>0 then
       dbms_output.put_line('T');
    ELSE
      dbms_output.put_line('F');
    end if;*/
    --dbms_output.put_line(V_TIME<>'');
    IF NVL(V_TIME, 0) <> 0 AND REC.CREATE_DATE < V_DATE THEN
      --取短信回肉
      select content
        INTO V_MSG_CONTENT
        from (SELECT C.SMS_CONTENT content

                FROM SCLM_RULE             A,
                     SCLM_RULE_REGION      B,
                     SCLM_RULE_SMS_CONTENT C,
                     SCLM_RULE_SPEC        D
               WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
                 AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
                 AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
                 AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_HFYXQ'
                 AND B.AREA_ID IN
                     (SELECT ID
                        FROM P_AREA
                      CONNECT BY PRIOR SUPER = ID
                       START WITH ID = REC.REGION_ID)
               order by b.area_id desc)
       where ROWNUM < 2;
      --取推荐人信息
      SELECT MOBILE_PHONE
        INTO V_MOBILEPHONE
        FROM SCLM_PARTNER
       WHERE SCLM_PARTNER_ID = REC.SCLM_PARTNER_ID;

      INSERT INTO SCLM_TJ_ORDER_FINISH
        (SCLM_TJ_ORDER_ID, SCLM_PARTNER_ID, ID, SERVICE_CODE, CREATE_DATE, STATUS, SEND_DATE, FINISH_DATE, STATUS_DATE, IS_AUTO, AUTO_PROC_DATE, AUTO_PROC_TIMES, AUTO_PROC_RESULT, AUTO_PROC_FAIL_REASON, IS_MANUAL, MANUAL_ASIGN_DATE, MANUAL_RESP_DATE, MANUAL_RESP_RESULT, MANUAL_RESP_FAIL_REASON, AREA_ID, REGION_ID, SALE_ORD_SERIAL, REAL_MODIFY_DATE)
        SELECT SCLM_TJ_ORDER_ID,
               SCLM_PARTNER_ID,
               ID,
               SERVICE_CODE,
               CREATE_DATE,
               '70T',
               SMS_SEND_DATE,
               SYSDATE,
               SYSDATE,
               IS_AUTO,
               AUTO_PROC_DATE,
               AUTO_PROC_TIMES,
               AUTO_PROC_RESULT,
               AUTO_PROC_FAIL_REASON,
               IS_MANUAL,
               MANUAL_ASIGN_DATE,
               MANUAL_RESP_DATE,
               MANUAL_RESP_RESULT,
               MANUAL_RESP_FAIL_REASON,
               AREA_ID,
               REGION_ID,
               SALE_ORD_SERIAL,
               REAL_MODIFY_DATE
          FROM SCLM_TJ_ORDER
         WHERE SCLM_TJ_ORDER_ID = REC.SCLM_TJ_ORDER_ID;
      DELETE FROM SCLM_TJ_ORDER
       WHERE SCLM_TJ_ORDER_ID = REC.SCLM_TJ_ORDER_ID;
      --周时要插入短信表通知推荐人
      INSERT INTO SCLM_SMS_SEND_LOG
        (SCLM_SMS_SEND_LOG_ID, SCLM_TJ_ORDER_ID, SCLM_SMS_SERIAL_ID, SCLM_SMS_SEND_NUM, SCLM_SMS_RECV_NUM, SCLM_SMS_CONTENT, SCLM_SMS_SEND_DATE, SCLM_SMS_IS_LIMIT, SCLM_SMS_REAL_SEND_DATE, SCLM_SMS_STATUS, SCLM_SMS_IS_RESP)
      VALUES
        (SEQ_SCLM_SMS_SEND_LOG.NEXTVAL, REC.SCLM_TJ_ORDER_ID, NULL, '', V_MOBILEPHONE, REPLACE(V_MSG_CONTENT, '[recMobilePhone]', REC.SERVICE_CODE), SYSDATE, 'Y', NULL, '0', 'N');

    END IF;
  END LOOP;
  O_CODE := '1'; ---成功标识返回
  O_MSG  := '成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      O_CODE := 0; --失败返回值
      O_MSG  := '处理失败';
      O_MSG  := SQLERRM;
      ROLLBACK;
    END;
END SCLM_ORDER_70T;
/
