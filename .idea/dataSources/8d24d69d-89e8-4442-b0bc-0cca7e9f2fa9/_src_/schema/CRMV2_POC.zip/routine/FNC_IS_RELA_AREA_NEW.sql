CREATE FUNCTION           FNC_IS_RELA_AREA_NEW(
                       I_CLASS_ID    IN NUMBER, --类ID
                                             I_OBJ_ID         IN NUMBER, --实例ID
                                             I_MY_AREA_ID     IN NUMBER, --登录工号AREA_ID
                                             I_MY_REGION_CD   IN NUMBER, --登录工号REGION_CD
                                             I_ENTT_AREA_ID   IN NUMBER, --配置实例AREA_ID
                                             I_ENTT_REGION_CD IN NUMBER, --配置实例REGION_CD
                                             I_OBJ_AREA_RELA  IN VARCHAR2) --适用区域合集OBJ_AREA_RELA
  RETURN INTEGER IS
  --1：适用，0：不适用
  V_CNT INTEGER;
  V_SQL VARCHAR2(2000);
BEGIN

  --1.判断I_MY_AREA_ID,I_MY_REGION_CD,1(省区域)是否在I_OBJ_AREA_RELA.
  IF I_OBJ_AREA_RELA IS NOT NULL AND LENGTH(TRIM(I_OBJ_AREA_RELA)) > 0 THEN

    V_CNT := 0;
    V_SQL := ' SELECT INSTR(:I_OBJ_AREA_RELA, :I_MY_AREA_ID) FROM DUAL ';
    EXECUTE IMMEDIATE V_SQL INTO V_CNT USING  I_OBJ_AREA_RELA , ',' || I_MY_AREA_ID || ',';

    IF V_CNT > 0 THEN
      RETURN 1;
    END IF;

    V_CNT := 0;
    V_SQL := ' SELECT INSTR(:I_OBJ_AREA_RELA, :I_MY_REGION_CD) FROM DUAL ';
    EXECUTE IMMEDIATE V_SQL INTO V_CNT USING I_OBJ_AREA_RELA, ',' || I_MY_REGION_CD || ',';

    IF V_CNT > 0 THEN
      RETURN 1;
    END IF;

    V_CNT := 0;
    V_SQL := ' SELECT INSTR(:I_OBJ_AREA_RELA, '',1,'') FROM DUAL ';
    EXECUTE IMMEDIATE V_SQL INTO V_CNT USING I_OBJ_AREA_RELA;

    IF V_CNT > 0 THEN
      RETURN 1;
    END IF;

    RETURN 0;

  END IF;


  IF I_ENTT_AREA_ID = 1 OR I_ENTT_AREA_ID = I_MY_AREA_ID THEN
    RETURN 1;
  END IF;

  RETURN 0;

END FNC_IS_RELA_AREA_NEW;
/
