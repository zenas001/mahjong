CREATE procedure           dealProdAttr is
  cursor QUERY_PROD_FEA is
    SELECT * FROM TEMP_HMM_PROD_FEA_SPEC;

begin
  FOR REC IN QUERY_PROD_FEA LOOP
    DECLARE
      V_CONT         NUMBER(12);
      V_ATTR_SPEC_ID NUMBER(12);
    BEGIN
      --查询公共属性是否存在
      SELECT COUNT(*)
        INTO V_CONT
        FROM TEMP_HMM_ATTR_SPEC ATTR
       WHERE ATTR.ATTR_CD = REC.CODE
         AND ATTR.ATTR_NAME = REC.NAME;
      --如果不存在插入，存在则查询出ATTR_ID，做产品选择关系处理
      IF V_CONT = 0 THEN
        --公共属性处理
        SELECT SEQ_ATTR_SPEC.NEXTVAL INTO V_ATTR_SPEC_ID FROM DUAL;
        INSERT INTO TEMP_HMM_ATTR_SPEC
          (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC)
        VALUES
          (V_ATTR_SPEC_ID, REC.CODE, REC.NAME, REC.NAME);
      ELSE
        SELECT ATTR.ATTR_ID
          INTO V_ATTR_SPEC_ID
          FROM TEMP_HMM_ATTR_SPEC ATTR
         WHERE ATTR.ATTR_CD = REC.CODE
           AND ATTR.ATTR_NAME = REC.NAME;
      END IF;
      --处理产品选择属性
      INSERT INTO TEMP_HMM_PRODUCT_ATTR
        (PRODUCT_ATTR_ID, PRODUCT_ID, ATTR_ID,OLD_FEA_SPEC_ID)
        SELECT SEQ_PRODUCT_ATTR_ID.NEXTVAL,
               REC.PROD_SPEC_ID,
               V_ATTR_SPEC_ID,
               REC.FEA_SPEC_ID
          FROM DUAL;
      --查询属性关联
      DECLARE
        V_RELA_ID             NUMBER(12); --关联标识
        V_RELA_CONT           NUMBER(12); --计数
        V_FEA_VALUE           NUMBER(12); --是否为值计数
        V_SUB_FEA             NUMBER(12); --下级属性规格
        V_CODE                VARCHAR2(60);
        V_NAME                VARCHAR2(200);
        V_RELA_COUNT          NUMBER(12); --公共属性关联计数
        V_PARENT              NUMBER(12);
        V_PARENT_COUNT        NUMBER(12);
        V_SUB_FEA_COUNT       NUMBER(12);
        V_PROD_FEA_SPEC_COUNT NUMBER(12);
        CURSOR QUERY_FEA_RELA_A IS
          SELECT *
            FROM TEMP_HMM_PROD_FEA_SPEC_RELA RELA
           WHERE RELA.FEA_ID_A = REC.FEA_SPEC_ID AND RELA_TYPE = '0';
      BEGIN
        --处理和上级属性的关系
        SELECT COUNT(*)
          INTO V_PARENT_COUNT
          FROM TEMP_HMM_ATTR_SPEC ATTR, TEMP_HMM_PROD_FEA_SPEC FEA
         WHERE FEA.FEA_SPEC_ID = REC.UP_FEA_SPEC_ID
           AND ATTR.ATTR_CD = FEA.CODE
           AND ATTR.ATTR_NAME = FEA.NAME;
        --如果上级已经写入，建立上级的关系
        IF V_PARENT_COUNT > 0 THEN
          SELECT ATTR.ATTR_ID
            INTO V_PARENT
            FROM TEMP_HMM_ATTR_SPEC ATTR, TEMP_HMM_PROD_FEA_SPEC FEA
           WHERE FEA.FEA_SPEC_ID = REC.UP_FEA_SPEC_ID
             AND ATTR.ATTR_CD = FEA.CODE
             AND ATTR.ATTR_NAME = FEA.NAME;
          --与上级属性关联是否存在
          SELECT COUNT(*)
            INTO V_RELA_CONT
            FROM TEMP_HMM_BUSI_OBJECT_ATTR_REL REL
           WHERE REL.ATTR_ID = V_PARENT
             AND REL.RELATED_ATTR_ID = V_ATTR_SPEC_ID;
          --建立和上级的关联
          IF V_RELA_CONT = 0 THEN
            INSERT INTO TEMP_HMM_BUSI_OBJECT_ATTR_REL
              (ATTR_RELA_ID, RELATED_ATTR_ID, ATTR_ID)
              SELECT SEQ_BUSI_OBJECT_ATTR_REL.NEXTVAL,
                     V_ATTR_SPEC_ID,
                     V_PARENT
                FROM DUAL;
          END IF;
        END IF;
        --先定位下级是否有属性，如果没有直接生成值ID，如果下级为值规格，则直接进入值表
        SELECT COUNT(*)
          INTO V_RELA_CONT
          FROM TEMP_HMM_PROD_FEA_SPEC_RELA
         WHERE FEA_ID_A = REC.FEA_SPEC_ID AND RELA_TYPE = '0';
        IF V_RELA_CONT = 0 THEN
          --生成值规格,先判断值规格是否已经生成
          DECLARE
            V_VALUE NUMBER(12);
          BEGIN
            SELECT COUNT(*)
              INTO V_VALUE
              FROM TEMP_HMM_ATTR_VALUE
             WHERE ATTR_ID = V_ATTR_SPEC_ID;
            IF V_VALUE = 0 THEN
              INSERT INTO TEMP_HMM_ATTR_VALUE
                (ATTR_VALUE_ID, ATTR_VALUE_NAME, ATTR_ID)
                SELECT SEQ_ATTR_VALUE.NEXTVAL, REC.NAME||'的属性值', V_ATTR_SPEC_ID
                  FROM DUAL;
            END IF;
          END;
        ELSE
          --如果有下级，则先查询下级是不是为值
          --下级关系处理
          FOR REC1 IN QUERY_FEA_RELA_A LOOP
            --判断是否为值
            V_FEA_VALUE := 0;
            V_CODE      := '';
            V_NAME      := '';
            --查询下级属性
            SELECT COUNT(*)
              INTO V_FEA_VALUE
              FROM TEMP_HMM_PROD_FEA_SPEC AA
             WHERE AA.FEA_SPEC_ID = REC1.FEA_ID_B;
            IF V_FEA_VALUE > 0 THEN
              SELECT CODE, NAME
                INTO V_CODE, V_NAME
                FROM TEMP_HMM_PROD_FEA_SPEC AA
               WHERE AA.FEA_SPEC_ID = REC1.FEA_ID_B;
              --判断下级属性是否已经写入
              SELECT COUNT(*)
                INTO V_PROD_FEA_SPEC_COUNT
                FROM TEMP_HMM_ATTR_SPEC BB
               WHERE BB.ATTR_CD = V_CODE
                 AND BB.ATTR_NAME = V_NAME;

              --查询下级属性
              IF V_PROD_FEA_SPEC_COUNT > 0 THEN
                SELECT BB.ATTR_ID
                  INTO V_SUB_FEA
                  FROM TEMP_HMM_ATTR_SPEC BB
                 WHERE BB.ATTR_CD = V_CODE
                   AND BB.ATTR_NAME = V_NAME;
              END IF;
              --判断关联是否已经建立
              IF V_SUB_FEA > 0 THEN
                SELECT COUNT(*)
                  INTO V_RELA_COUNT
                  FROM TEMP_HMM_BUSI_OBJECT_ATTR_REL REL
                 WHERE REL.RELATED_ATTR_ID = V_SUB_FEA
                   AND REL.ATTR_ID = V_ATTR_SPEC_ID;
                --建立关联
                IF V_RELA_COUNT = 0 THEN
                  INSERT INTO TEMP_HMM_BUSI_OBJECT_ATTR_REL
                    (ATTR_RELA_ID, RELATED_ATTR_ID, ATTR_ID)
                    SELECT SEQ_BUSI_OBJECT_ATTR_REL.NEXTVAL,
                           V_SUB_FEA,
                           V_ATTR_SPEC_ID
                      FROM DUAL;
                END IF;
              END IF;
            END IF;
          END LOOP;
        END IF;
      END;
    END;
    commit;
  END LOOP;

end dealProdAttr;
/
