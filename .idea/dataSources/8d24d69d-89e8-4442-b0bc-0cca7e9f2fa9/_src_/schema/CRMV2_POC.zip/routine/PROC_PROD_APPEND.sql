CREATE procedure           proc_prod_append is
v_insid     number(12);
v_cnt       number := 0;
v_pfid      number(12);
v_mdseid    number(12);
v_relamdse  number(12);
v_relaprod  number(12);
v_feaspec   number(12);
v_prodcode  varchar2(12);
v_prodspec  number(12);
v_time      number(12);
begin
select max(ss.prod_inst_id)+1 into v_insid from prod_inst ss;
for REC in (select * from temp_zcb_mdse m where m.mdse_type='102')
  loop
    v_pfid := 0;
    v_mdseid := 0;
    v_relamdse := 0;
    v_relaprod := 0;
    v_feaspec := 0;
    v_prodcode := null;
    select count(*) into v_cnt  from prod_offer_inst i where i.prod_offer_inst_id=rec.mdse_id;
    if v_cnt>0 then
      v_mdseid := rec.mdse_id;
      select count(*) into v_cnt from prod_fea pf where pf.prod_fea_id=rec.prod_fea_id;
      if v_cnt>0 then
        v_pfid := rec.prod_fea_id;
        select pf.fea_spec_id  into  v_feaspec from prod_fea pf where pf.prod_fea_id=rec.prod_fea_id;
        select count(*) into v_cnt from prod_fea_spec pp where pp.fea_spec_id=v_feaspec;
        if v_cnt>0 then
          select  pp.code into v_prodcode from prod_fea_spec pp where pp.fea_spec_id=v_feaspec;
        end if;
        select count(*) into v_cnt from product c where c.product_nbr=v_prodcode;
        if v_cnt>0 then
          select c.product_id into v_prodspec  from product c where c.product_nbr=v_prodcode;
        end if;
      end if;
      select count(*) into v_cnt from mdse_rela r where r.mdse_idb=rec.mdse_id and r. ='101';
      if v_cnt>0 then
         select r.mdse_ida into v_relamdse from mdse_rela r where r.mdse_idb=rec.mdse_id and r. ='101';
      end if;
      select count(*) into v_cnt from mdse m where m.mdse_id=v_relamdse and m.mdse_type='101';
      if v_cnt>0 then
         select m.prod_id into v_relaprod from mdse m where m.mdse_id=v_relamdse and m.mdse_type='101';
      end if;
      insert into temp_zcb_prod_inst_append
      (PROD_INST_ID,PRODUCT_ID,ACC_PROD_INST_ID,
      ADDRESS_ID,OWNER_CUST_ID,PROD_TYPE_CD,
      PAYMENT_MODE_CD,PRODUCT_PASSWORD,IMPORTANT_LEVEL,
      AREA_CODE,ACC_NBR,ADDRESS_NAME,EXCH_ID,REGION,
      REMARK,PAY_CYCLE,BEGIN_RENT_TIME,
      STOP_RENT_TIME,FINISH_TIME,STOP_STATUS,
      STATUS_CD,CREATE_DATE,AREA_ID,STATUS_DATE,
      CREATE_STAFF,UPDATE_DATE,UPDATE_STAFF,
      REGION_CD,PROC_SERIAL,relamdse_id,
      rela_prodid,fea_spec_id,fea_code)
   values (v_insid, v_prodspec, v_insid,
         '', rec.owner_cust_id,'12',
         '11','', '',
         '','','','',rec.region
         rec.EXCH_ID, rec.region, rec.REMARK,
         '', ,,, to_date('2199-1-1', 'YYYY-MM-DD'),
         rec.create_date, rec.state, decode(a.state, '70A', '10', '70X', '11', state),
         rec.create_date, rec.area_code, rec.modify_date,
         '',rec.real_modify_date,'',
         rec.region, '',v_relamdse,
         v_relaprod,v_feaspec,v_prodcode);
    v_insid := v_insid+1;
    v_time := v_time+1;
    if mod(v_time,1000)=0 then
        commit;
    end if;
   end if;
  end loop:
 commit;
end proc_prod_append;
/
