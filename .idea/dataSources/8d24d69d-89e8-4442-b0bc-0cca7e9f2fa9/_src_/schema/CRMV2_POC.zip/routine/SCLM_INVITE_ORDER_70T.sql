CREATE PROCEDURE           SCLM_INVITE_ORDER_70T(O_CODE OUT VARCHAR2,
                                                  O_MSG  OUT VARCHAR2) IS

  /**
  *接口描述：查询推荐工单表中70A、70B的超时未回复的单，更改状态70T周时进完成表
  *执行成功返回1，失败返回0
  **/
  V_TIME        NUMBER; --存储历史表序列
  V_MOBILEPHONE VARCHAR2(20); --专业手机号
  V_MSG_CONTENT VARCHAR2(500); --短信内容
  V_DATE        VARCHAR2(20);
  PRAGMA AUTONOMOUS_TRANSACTION; --实现自治事务处理
BEGIN
  --取规则的时限配置：
  O_CODE := '0'; ---失败标识返回
  FOR REC IN (SELECT SCLM_INVITE_ORDER_ID,
                     SCLM_PARTNER_ID,
                     SERVICE_CODE,
                     TO_CHAR(CREATE_DATE, 'yyyy-mm-dd hh24:mi:ss') AS CREATE_DATE,
                     REGION_ID
                FROM SCLM_INVITE_ORDER
               WHERE STATUS IN ('70A')) LOOP
    SELECT nvl(C.SCLM_RULE_PARAMS_VALUE, 0)
      INTO V_TIME
      FROM SCLM_RULE             A,
           SCLM_RULE_REGION      B,
           SCLM_RULE_PARAMS      C,
           SCLM_RULE_SPEC        D,
           SCLM_RULE_PARAMS_SPEC E
     WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
       AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
       AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
       AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_INVITE_HFYXQ'
       AND C.SCLM_RULE_PARAMS_SPEC_ID = E.SCLM_RULE_PARAMS_SPEC_ID
       AND E.SCLM_RULE_PARAMS_SPEC_CODE = 'INVITE_HFYXQ_TIME'
       AND B.AREA_ID IN (SELECT ID
                           FROM P_AREA
                         CONNECT BY PRIOR SUPER = ID
                          START WITH ID = REC.REGION_ID)
       AND ROWNUM < 2;

    SELECT TO_CHAR(SYSDATE - NVL(V_TIME, 0) / 24, 'yyyy-mm-dd hh24:mi:ss')
      INTO V_DATE
      FROM DUAL;
    /* dbms_output.put_line(V_TIME);
    dbms_output.put_line(V_DATE);
    if V_TIME<>0 then
       dbms_output.put_line('T');
    ELSE
      dbms_output.put_line('F');
    end if;*/
    --dbms_output.put_line(V_TIME<>'');
    IF NVL(V_TIME, 0) <> 0 AND REC.CREATE_DATE < V_DATE THEN
      --取短信内容
      SELECT C.SMS_CONTENT
        INTO V_MSG_CONTENT
        FROM SCLM_RULE             A,
             SCLM_RULE_REGION      B,
             SCLM_RULE_SMS_CONTENT C,
             SCLM_RULE_SPEC        D
       WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
         AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
         AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
         AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_INVITE_HFYXQ'
         AND B.AREA_ID IN (SELECT ID
                             FROM P_AREA
                           CONNECT BY PRIOR SUPER = ID
                            START WITH ID = REC.REGION_ID)
         AND ROWNUM < 2;
      --取推荐人信息
      SELECT MOBILE_PHONE
        INTO V_MOBILEPHONE
        FROM SCLM_PARTNER
       WHERE SCLM_PARTNER_ID = REC.SCLM_PARTNER_ID;

      UPDATE SCLM_INVITE_ORDER
         SET STATUS = '70T', STATUS_DATE = SYSDATE
       WHERE SCLM_INVITE_ORDER_ID = REC.SCLM_INVITE_ORDER_ID;
      --周时要插入短信表通知邀请人
      INSERT INTO SCLM_SMS_SEND_LOG
        (SCLM_SMS_SEND_LOG_ID, SCLM_TJ_ORDER_ID, SCLM_SMS_SERIAL_ID, SCLM_SMS_SEND_NUM, SCLM_SMS_RECV_NUM, SCLM_SMS_CONTENT, SCLM_SMS_SEND_DATE, SCLM_SMS_IS_LIMIT, SCLM_SMS_REAL_SEND_DATE, SCLM_SMS_STATUS, SCLM_SMS_IS_RESP, SCLM_SMS_TYPE)
      VALUES
        (SEQ_SCLM_SMS_SEND_LOG.NEXTVAL, REC.SCLM_INVITE_ORDER_ID, NULL, '', V_MOBILEPHONE, REPLACE(V_MSG_CONTENT, '[recMobilePhone]', REC.SERVICE_CODE), SYSDATE, 'Y', NULL, '0', 'N', '02');

    END IF;
  END LOOP;
  O_CODE := '1'; ---成功标识返回
  O_MSG  := '成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      O_CODE := 0; --失败返回值
      O_MSG  := '处理失败';
      O_MSG  := SQLERRM;
      ROLLBACK;
    END;
END SCLM_INVITE_ORDER_70T;
/
