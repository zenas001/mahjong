CREATE procedure           proc_attr_spec as
  v_new_value varchar2(2000) := '';
  v_cnt       int := 0;
  CURSOR c IS
    select * from attr_spec c where Upper(c.default_value) like '%HTTP%';
begin
  FOR rec IN c LOOP
    -- dbms_output.put_line(rec.java_code);
    v_new_value := '';
    v_cnt       := 0;
    select count(1)
      into v_cnt
      from attr_spec@ycold a
     where a.java_code = rec.java_code;
    if v_cnt = 1 then
      select a.default_value
        into v_new_value
        from attr_spec@ycold a
       where a.java_code = rec.java_code;
      update attr_spec a
      set a.default_value = v_new_value
      where a.java_code = rec.java_code ;

    end if;
  END LOOP;
commit ;
end;
/
