CREATE procedure           INSERTINTOYKJH_LIX is

  v_ACCOUNT      PROD_INST.ACCOUNT%TYPE;
  V_PROD_INST_ID PROD_INST.PROD_INST_ID%type;
  flag           number;
  ykt_flag       varchar2(12);
begin

  For Rec In (SELECT *
                FROM YKJH
               where prod_inst_id is null
                 and create_date > trunc(sysdate) - 1) Loop
    begin
      SELECT C.ACCOUNT, C.PROD_INST_ID
        INTO v_ACCOUNT, V_PROD_INST_ID
        FROM CUSTOMER_ORDER_HIS A, order_item_his B, PROD_INST C
       where a.cust_so_number = rec.SALE_ORD_SERIAL
         and A.CUST_ORDER_ID = B.CUST_ORDER_ID
         AND B.CLASS_ID = '4'
         AND B.ORDER_ITEM_OBJ_ID = C.PROD_INST_ID
         AND C.PRODUCT_ID = '800000002';
      flag := 0;

      UPDATE YKJH
         SET PROD_INST_ID = V_PROD_INST_ID, ACCOUNT = v_ACCOUNT
       WHERE SALE_ORD_SERIAL = Rec.SALE_ORD_SERIAL;
      COMMIT;
    exception
      when others then
        rollback;
    end;
  End Loop;
end;
/
