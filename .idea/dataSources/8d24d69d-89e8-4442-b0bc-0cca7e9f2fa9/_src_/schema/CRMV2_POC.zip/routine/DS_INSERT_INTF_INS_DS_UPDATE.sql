CREATE procedure           ds_insert_intf_ins_ds_update(v_table_name        in varchar2,
                                                         v_primary_key       in varchar2,
                                                         v_primary_key_value in number,
                                                         v_name              in varchar2,
                                                         v_from              in varchar2,
                                                         v_op_type           in varchar2,
                                                         v_sharding_id       in varchar2) is
  /*
  将表信息插入intf_ins_ds_update表中
  参数：
  v_table_name 表名 对应TABLE_NAME字段
  v_primary_key 主键字段名 对应COLUMN_NAME字段
  v_primary_key_value 主键值 对应KEY_ID字段
  v_name 表名说明 对应TOPIC字段
  v_from 来源说明 对应REASON字段
  v_op_type 数据库操作类型 对应OP_TYPE字段 CREATE、UPDATE、DELETE
  v_sharding_id 分片键值
  */
begin
  insert into intf_ins_ds_update
    (INS_ID,
     TABLE_NAME,
     COLUMN_NAME,
     KEY_ID,
     TOPIC,
     TYPE,
     REASON,
     OPERATOR,
     STATE,
     STATE_DATE,
     CREATE_DATE,
     UPDATE_DATE,
     DEAL_NUM,
     NEXT_DEAL_TIME,
     ERR_MSG,
     REMARK,
     AREA_NBR,
     OP_TYPE,
     SHARDING_ID)
  values
    (seq_intf_ins_ds_update_id.nextval,
     v_table_name,
     v_primary_key,
     v_primary_key_value,
     v_name,
     '1001',
     v_from,
     null,
     '70A',
     sysdate,
     sysdate,
     sysdate,
     0,
     null,
     null,
     null,
     null,
     v_op_type,
     v_sharding_id);
end ds_insert_intf_ins_ds_update;
/
