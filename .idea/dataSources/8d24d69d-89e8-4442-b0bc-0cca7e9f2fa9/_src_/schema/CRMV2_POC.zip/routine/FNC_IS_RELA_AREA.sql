CREATE function           fnc_is_rela_area(i_class_id       in number, --类ID
                                                i_obj_id         in number, --实例ID
                                                i_my_area_id     in number, --登录工号AREA_ID
                                                i_my_region_cd   in number, --登录工号REGION_CD
                                                i_entt_area_id   in number, --配置实例AREA_ID
                                                i_entt_region_cd in number) --配置实例REGION_CD
 return integer is
  --1：适用，0：不适用
  v_cnt integer;
  v_mod number;
  v_sql VARCHAR2(2000);
begin
  v_mod := 1;
  if i_my_area_id is not null and i_my_area_id > 1 then
    v_mod := i_my_area_id;
  end if;
  v_sql := 'select count(' || v_mod ||
           ')  from obj_area_rela a  where a.obj_class_id =:i_class_id and a.obj_id =:i_obj_id  and a.rela_type = ''10'' and a.status_cd <> ''1100''';
  execute immediate v_sql
    into v_cnt
    using i_class_id, i_obj_id;
  /*select count(1)
   into v_cnt
   from obj_area_rela a
  where a.obj_class_id = i_class_id
    and a.obj_id = i_obj_id
    and a.rela_type = '10'
    and a.status_cd <> '1100';*/
  if v_cnt > 0 then
    v_sql := 'select count(1) from obj_area_rela a  where a.obj_class_id =:i_class_id and a.obj_id =:i_obj_id  and a.rela_type = ''10'' and a.status_cd <> ''1100'' and a.rela_area_id in (1,' ||
             i_my_area_id || ',' || i_my_region_cd || ')';
    execute immediate v_sql
      into v_cnt
      using i_class_id, i_obj_id;
    /*select count(1)
     into v_cnt
     from obj_area_rela a
    where a.obj_class_id = i_class_id
      and a.obj_id = i_obj_id
      and a.rela_type = '10'
      and a.status_cd <> '1100'
      and a.rela_area_id in (1, i_my_area_id, i_my_region_cd);*/
    if v_cnt > 0 then
      return 1;
    end if;
    return 0;
  end if;

  if i_entt_area_id = 1 or i_entt_area_id = i_my_area_id then
    return 1;
  end if;
  return 0;
end fnc_is_rela_area;
/
