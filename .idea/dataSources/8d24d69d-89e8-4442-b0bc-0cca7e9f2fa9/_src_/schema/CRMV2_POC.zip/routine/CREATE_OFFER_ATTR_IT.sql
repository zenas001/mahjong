CREATE procedure           create_offer_attr_it(v_prod_offer_id  in varchar2, v_area_id in varchar2 ,v_attr_code in varchar2,v_attr_value in varchar2)

as
v_attr_spec_id number;
v_attr_value_id number;
begin

   SELECT a.attr_id into v_attr_spec_id FROM attr_spec a ,sys_class sc where sc.java_code = 'PpmProdOffer' and sc.class_id = a.class_id and a.java_code = v_attr_code;
   begin
          SELECT b.attr_value_id into v_attr_value_id FROM attr_value b, attr_spec a ,sys_class sc where sc.java_code = 'PpmProdOffer' and sc.class_id = a.class_id and a.java_code = v_attr_code and a.attr_id = b.attr_id and b.attr_value = v_attr_value;
   exception
          when NO_DATA_FOUND then
          v_attr_value_id := null;
   end;

   insert into ppm_prod_offer_attr ( PROD_OFFER_ATTR_ID, ATTR_ID, ATTR_VALUE_ID, PROD_OFFER_ID, ATTR_VALUE, AREA_ID, REGION_CD, STATUS_CD, STATUS_DATE, CREATE_DATE, CREATE_STAFF, UPDATE_DATE, UPDATE_STAFF)
   values ( seq_ppm_prod_offer_attr_id.nextval, v_attr_spec_id, v_attr_value_id, v_prod_offer_id, v_attr_value, v_area_id, v_area_id, '1000', sysdate, sysdate, null, sysdate, null);
end;
/
