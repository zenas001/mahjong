CREATE procedure           PROC_CHANNEL_SDQY(O_RESULT OUT VARCHAR2,
                                                O_MSG    OUT VARCHAR2) is
  V_attr_id_SDQY       NUMBER(9); --售点区域attrid
  V_channel_attr_id    NUMBER(12) := 0; --销售点特性ID
  V_COUNT_group_cd     NUMBER; --用于判断是否集团属性，是的话上传集团
  V_TABLE_NAME         varchar2(30) := 'CHANNEL_ATTR'; --上传表名
  V_ACTION             varchar2(12) := 'ADD'; --处理动作(ADD)
  V_in_modi_man        varchar2(50) := 'fztest'; --修改人
  V_in_modi_reason     varchar2(256) := 'PROC_CHANNEL_SDQY售点区域自动更新过程'; --修改原因
  SDQY_ATTR_VALUE      VARCHAR2(4000);
  V_SDQY_ATTR_VALUE_ID NUMBER(12);
  V_in_key_id          NUMBER(12);

  --查找还没同步过来的做新增
  CURSOR cur_SDQY is
  --用测
     select *
      from Mytable_channel mc
     where mc.channel_id not in
           (select ca.channel_id
              from channel_attr ca
             where ca.attr_id in (select a.attr_id
                                    from attr_spec a
                                   where a.class_id = 30
                                     and a.attr_name = '售点区域'
                                     and a.status_cd = 1000
                                     and rownum < 2));
  /*select icpr.channel_id, icoc.is_city from intf_crm.INTF_CHANNEL_PLACE_RELA@lk_fj_cms_temp icpr,
  FJCMS.INTF_COMM_ORG_CRM icoc ,channel c where icpr.place_node=icoc.comm_org_id
  and icpr.channel_id=c.channel_id and icpr.channel_id not in(
    select ca.channel_id from channel_attr ca where ca.attr_id in( select a.attr_id from
   attr_spec a where a.class_id=30 and a.attr_name='售点区域'
   and a.status_cd=1000 and rownum < 2));*/
begin

  select a.attr_id
    into V_attr_id_SDQY
    from attr_spec a
   where a.class_id = 30
     and a.attr_name = '售点区域'
     and a.status_cd = 1000
     and rownum < 2;
  select count(*)
    into V_COUNT_group_cd
    from attr_spec ap
   where ap.attr_id = V_attr_id_SDQY
     and ap.group_cd is not null;

  FOR REC_SDQY IN cur_SDQY LOOP
    if REC_SDQY.is_city = '1' then
      --城市
      SDQY_ATTR_VALUE := '10';
    end if;
    if REC_SDQY.is_city = '2' then
      --农村
      SDQY_ATTR_VALUE := '50'; --乡
    end if;
    select seq_channel_attr_id.nextval into V_channel_attr_id from dual;
    V_in_key_id := V_channel_attr_id;

    select av.attr_value_id
      into V_SDQY_ATTR_VALUE_ID
      from attr_value av
     where av.attr_id = V_attr_id_SDQY
       and av.attr_value = SDQY_ATTR_VALUE
       and av.status_cd = '1000'
       and rownum < 2;

    insert into channel_attr
      (CHANNEL_ATTR_ID,
       ATTR_ID,
       CHANNEL_ID,
       ATTR_VALUE,
       ATTR_VALUE_ID,
       DESCRIPTION,
       STATUS_CD,
       STATUS_DATE,
       CREATE_DATE,
       AREA_ID,
       REGION_CD,
       CREATE_STAFF,
       UPDATE_DATE,
       UPDATE_STAFF)
    values
      (V_channel_attr_id,
       V_attr_id_SDQY,
       REC_SDQY.channel_id,
       SDQY_ATTR_VALUE,
       V_SDQY_ATTR_VALUE_ID,
       '',
       '1000',
       sysdate,
       sysdate,
       2,
       11,
       null,
       sysdate,
       null);

    --是集团属性的话，先提交事务再同步集团
    if V_COUNT_group_cd > 0 then
      --生产修改为fflinyx.PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main
      PKG_JT_CHANNEL_UPLOAD.prc_jt_channel_main(V_TABLE_NAME,
                                                V_in_key_id,
                                                V_ACTION,
                                                V_in_modi_man,
                                                V_in_modi_reason);
    end if;
  END LOOP;
  COMMIT;

  O_RESULT := 'TRUE';
EXCEPTION
  WHEN OTHERS THEN
    O_RESULT := 'FALSE';
    O_MSG    := '失败:' || SQLERRM;
    ROLLBACK;
end PROC_CHANNEL_SDQY;
/
