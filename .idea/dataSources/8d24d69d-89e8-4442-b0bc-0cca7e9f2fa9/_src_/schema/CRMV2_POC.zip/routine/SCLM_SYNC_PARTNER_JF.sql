CREATE PROCEDURE           "SCLM_SYNC_PARTNER_JF"(O_CODE OUT VARCHAR2,
                                                   O_MSG  OUT VARCHAR2) IS

  /**
  *接口描述：从ODS同步积分
  *执行成功返回1，失败返回0
  **/
  V_SWITCH          VARCHAR2(1);
  V_CYCLE_ID        NUMBER(12);
  V_MOBILEPHONE     VARCHAR2(20); --专员号码
  V_TOTAL_JF        NUMBER(12); --累计积分
  V_CAN_EXCHANGE_JF NUMBER(12); --当前可兑换积分
  V_SMS_CONTENT     VARCHAR2(1000);
  PRAGMA AUTONOMOUS_TRANSACTION; --实现自治事务处理
BEGIN
  O_CODE := '0'; ---出参初始化
  SELECT IS_NEW, END_CYCLE_ID
    INTO V_SWITCH, V_CYCLE_ID
    FROM INT_CRM_STATUS@lk_crm2ods
   WHERE INT_ID = 17132;
  --更新初始积分,开关打开时，读取积分
  IF V_SWITCH = '1' THEN
    FOR REC IN (SELECT *
                  FROM INTF_EVL_CU_INITIAL@lk_crm2ods
                 WHERE CYCLE_ID = V_CYCLE_ID) LOOP
      SELECT A.MOBILE_PHONE, B.TOTAL_JF, B.CUR_CAN_EXCHANG_JF
        INTO V_MOBILEPHONE, V_TOTAL_JF, V_CAN_EXCHANGE_JF
        FROM SCLM_PARTNER A, SCLM_PARTNER_JF B
       WHERE A.SCLM_PARTNER_ID = B.SCLM_PARTNER_ID
         AND A.SCLM_PARTNER_ID = REC.CU_PARTNER_ID;
      INSERT INTO SCLM_PARTNER_JF_LOG
        (SCLM_PARTNER_JF_LOG_ID, SCLM_PARTNER_ID, LOG_JF_ACTION, LOG_JF_TYPE, LOG_JF_VALUE, LOG_JF_CYCLE, REAL_MODIFY_DATE)
        (SELECT SEQ_SCLM_PARTNER_JF_LOG.NEXTVAL,
                REC.CU_PARTNER_ID,
                '初始积分奖励',
                '初始积分',
                REC.CNT_POINTS,
                REC.CYCLE_ID,
                SYSDATE
           FROM INTF_EVL_CU_INITIAL@lk_crm2ods
          WHERE CYCLE_ID = REC.CYCLE_ID
            AND CU_PARTNER_ID = REC.CU_PARTNER_ID);
      --更新初始积分
      UPDATE SCLM_PARTNER_JF
         SET CUR_INIT_JF      = CUR_INIT_JF + REC.CNT_POINTS,
             TOTAL_JF         = TOTAL_JF + REC.CNT_POINTS,
             REAL_MODIFY_DATE = SYSDATE
       WHERE SCLM_PARTNER_ID = REC.CU_PARTNER_ID;
      --短信通知专业
      /*      dbms_output.put_line(V_MOBILEPHONE);
      dbms_output.put_line(Trim(nvl(V_MOBILEPHONE,'')));
      if Length(V_MOBILEPHONE)>0 THEN
        dbms_output.put_line(Length(V_MOBILEPHONE));
       dbms_output.put_line('T');
      ELSE
       dbms_output.put_line('F');
      end if;*/
      IF Length(V_MOBILEPHONE) > 0 THEN
        SELECT '您' || SUBSTR(V_CYCLE_ID, 5, 2) || '月' ||
               SUBSTR(V_CYCLE_ID, 7, 2) || '日推荐业务，获得' || REC.CNT_POINTS ||
               '分。目前累计积分' || (V_TOTAL_JF + REC.CNT_POINTS) || '，其中可兑换积分' ||
               V_CAN_EXCHANGE_JF
          INTO V_SMS_CONTENT
          FROM DUAL;
        INSERT INTO SCLM_SMS_SEND_LOG
          (SCLM_SMS_SEND_LOG_ID, SCLM_TJ_ORDER_ID, SCLM_SMS_SERIAL_ID, SCLM_SMS_SEND_NUM, SCLM_SMS_RECV_NUM, SCLM_SMS_CONTENT, SCLM_SMS_SEND_DATE, SCLM_SMS_IS_LIMIT, SCLM_SMS_REAL_SEND_DATE, SCLM_SMS_STATUS, SCLM_SMS_IS_RESP)
        VALUES
          (SEQ_SCLM_SMS_SEND_LOG.NEXTVAL, NULL, NULL, '', V_MOBILEPHONE, V_SMS_CONTENT, SYSDATE, 'Y', NULL, '0', 'N');
      END IF;

    END LOOP;
    UPDATE INT_CRM_STATUS@lk_crm2ods SET IS_NEW = '0' WHERE INT_ID = 17132;
  END IF;
  --每月更新（可兑换积分）
  SELECT IS_NEW, END_CYCLE_ID
    INTO V_SWITCH, V_CYCLE_ID
    FROM INT_CRM_STATUS@lk_crm2ods
   WHERE INT_ID = 17133;
  IF V_SWITCH = '1' THEN
    FOR REC2 IN (SELECT *
                   FROM INTF_EVL_CU_EXCHANGE@lk_crm2ods
                  WHERE CYCLE_ID = V_CYCLE_ID) LOOP
      --1可兑换积分
      IF REC2.POINT_TYPE = 'EXCHANGE' THEN
        INSERT INTO SCLM_PARTNER_JF_LOG
          (SCLM_PARTNER_JF_LOG_ID, SCLM_PARTNER_ID, LOG_JF_ACTION, LOG_JF_TYPE, LOG_JF_VALUE, LOG_JF_CYCLE, REAL_MODIFY_DATE)
          (SELECT SEQ_SCLM_PARTNER_JF_LOG.NEXTVAL,
                  REC2.CU_PARTNER_ID,
                  '可兑换积分转化',
                  '可兑换积分',
                  REC2.POINT_VALUE,
                  REC2.CYCLE_ID,
                  SYSDATE
             FROM INTF_EVL_CU_EXCHANGE@lk_crm2ods
            WHERE CYCLE_ID = REC2.CYCLE_ID
              AND CU_PARTNER_ID = REC2.CU_PARTNER_ID);

        INSERT INTO SCLM_PARTNER_JF_LOG
          (SCLM_PARTNER_JF_LOG_ID, SCLM_PARTNER_ID, LOG_JF_ACTION, LOG_JF_TYPE, LOG_JF_VALUE, LOG_JF_CYCLE, REAL_MODIFY_DATE)
          (SELECT SEQ_SCLM_PARTNER_JF_LOG.NEXTVAL,
                  REC2.CU_PARTNER_ID,
                  '可兑换积分转化',
                  '初始积分',
                  -REC2.POINT_VALUE,
                  REC2.CYCLE_ID,
                  SYSDATE
             FROM INTF_EVL_CU_EXCHANGE@lk_crm2ods
            WHERE CYCLE_ID = REC2.CYCLE_ID
              AND CU_PARTNER_ID = REC2.CU_PARTNER_ID);
        --更新初始积分
        UPDATE SCLM_PARTNER_JF
           SET CUR_INIT_JF        = CUR_INIT_JF - REC2.POINT_VALUE,
               CUR_CAN_EXCHANG_JF = CUR_CAN_EXCHANG_JF + REC2.POINT_VALUE,
               REAL_MODIFY_DATE   = SYSDATE
         WHERE SCLM_PARTNER_ID = REC2.CU_PARTNER_ID;
      ELSE
        ----更新奖罚积分
        INSERT INTO SCLM_PARTNER_JF_LOG
          (SCLM_PARTNER_JF_LOG_ID, SCLM_PARTNER_ID, LOG_JF_ACTION, LOG_JF_TYPE, LOG_JF_VALUE, LOG_JF_CYCLE, REAL_MODIFY_DATE)
          (SELECT SEQ_SCLM_PARTNER_JF_LOG.NEXTVAL,
                  REC2.CU_PARTNER_ID,
                  '处罚',
                  '奖罚积分',
                  -REC2.POINT_VALUE,
                  REC2.CYCLE_ID,
                  SYSDATE
             FROM INTF_EVL_CU_EXCHANGE@lk_crm2ods
            WHERE CYCLE_ID = REC2.CYCLE_ID
              AND CU_PARTNER_ID = REC2.CU_PARTNER_ID);
        /**
        *如果当前可兑换积分不足以扣减，则将剩余处罚积分记录到当前将罚积分字段
        */
        UPDATE SCLM_PARTNER_JF
           SET CUR_PUNISH_JF      = CUR_PUNISH_JF +
                                    DECODE(Sign(CUR_CAN_EXCHANG_JF -
                                                REC2.POINT_VALUE), -1, REC2.POINT_VALUE -
                                            CUR_CAN_EXCHANG_JF, 0),
               CUR_CAN_EXCHANG_JF = DECODE(Sign(CUR_CAN_EXCHANG_JF -
                                                REC2.POINT_VALUE), -1, 0, (CUR_CAN_EXCHANG_JF -
                                            REC2.POINT_VALUE)),
               REAL_MODIFY_DATE   = SYSDATE
         WHERE SCLM_PARTNER_ID = REC2.CU_PARTNER_ID;
      END IF;
    END LOOP;
    UPDATE INT_CRM_STATUS@lk_crm2ods SET IS_NEW = '0' WHERE INT_ID = 17133;
  END IF;
  O_CODE := '1'; ---成功标识返回
  O_MSG  := '成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      O_CODE := 0; --失败返回值
      O_MSG  := '处理失败';
      O_MSG  := SQLERRM;
      ROLLBACK;
    END;
END SCLM_SYNC_PARTNER_JF;
/
