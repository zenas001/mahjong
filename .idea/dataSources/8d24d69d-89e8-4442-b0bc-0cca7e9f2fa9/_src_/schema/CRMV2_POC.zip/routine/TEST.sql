CREATE procedure           test is
  filepath    varchar2(100);
  file_handle varchar2(100);
begin
  filepath    := '\\192.168.6.29\DependencyFile ';
  file_handle := utl_file.fopen(filepath, filename, 'W ');
  utl_file.put_line(file_handle,
                    to_char(sysdate, 'YYYY-MM-DD,HH24:MI:SS '));
  utl_file.fclose(file_handle);
end test;
/
