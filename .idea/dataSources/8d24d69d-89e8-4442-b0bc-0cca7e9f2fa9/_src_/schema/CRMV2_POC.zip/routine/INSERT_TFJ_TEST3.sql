CREATE PROCEDURE           INSERT_TFJ_TEST3(o_result        in VARCHAR2) IS
  begin
  FOR  REC IN  (
        SELECT poi.prod_offer_inst_id  SRC_INST_ID
      FROM prod_offer_inst poi ,prod_offer po
     where po.prod_offer_id = poi.prod_offer_id and po.offer_sub_type = 'T04' and po.status_cd = '1000'
     and poi.status_cd = '1000'
     and to_char(poi.exp_date,'YYYY-MM-DD HH24:MM:SS') < '2016-03-10 00:00:00'
     and to_char(poi.exp_date,'YYYY-MM-DD HH24:MM:SS') > '2016-02-10 00:00:00'
      and rownum < 1001
      ) LOOP
  insert into o_auto_proc_queue
  (QUEUE_ID,
   SUPER_QUEUE_ID,
   PRIORITY,
   SRC_TYPE,
   SRC_INST_ID,
   SRC_ACTION,
   PROC_TYPE,
   CUST_ORDER_ID,
   ORDER_ITEM_ID,
   REMARK,
   QUEUE_DESC,
   EXTEND,
   EFF_DATE,
   AREA_ID,
   REGION_CD,
   CREATE_STAFF,
   CREATE_DATE,
   STATUS_CD,
   STATUS_DATE,
   UPDATE_STAFF,
   UPDATE_DATE,
   CUST_ID,
   BEGIN_DATE,
   PROD_INST_ID)
values
  (seq_o_auto_proc_queue_id.nextval,
   0,
   null,
   'ProdOfferInst',
   REC.SRC_INST_ID,
   '3030100000',
   'MOD',
   null,
   null,
   '',
   '',
   null,
   null,
   7,
   44,
   51447,
   sysdate,
   '400000',
   sysdate,
   49822,
   sysdate,
   null,
   null,
   null);
   END LOOP;
  commit;
END INSERT_TFJ_TEST3;
/
