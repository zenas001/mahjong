CREATE PROCEDURE           CREATE_SYNONYM IS
  CURSOR CUR IS
    SELECT *
      FROM ALL_OBJECTS A
     WHERE A.OWNER = 'CRMV2'
       AND A.OBJECT_TYPE NOT IN
           ('INDEX', 'INDEX PARTITION', 'TABLE SUBPARTITION',
            'INDEX SUBPARTITION', 'TABLE PARTITION', 'TYPE')
       -- and rownum<5
            ;
  v_str clob;
BEGIN
  FOR REC IN CUR LOOP
    v_str :=  'create or replace synonym ' || rec.OBJECT_NAME ||
             '  for CRMV2.' || rec.OBJECT_NAME ||';
             ';
                 EXECUTE IMMEDIATE ( v_str );
  END loop;

end;
/
