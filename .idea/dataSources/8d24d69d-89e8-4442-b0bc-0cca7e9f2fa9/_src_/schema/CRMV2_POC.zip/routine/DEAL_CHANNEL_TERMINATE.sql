CREATE procedure           deal_Channel_Terminate is
  cursor channel_chg_info is
    select *
      from channel_chg_info
     where qualification_chg_type_cd = 'ZZ'
       and to_char(apply_date, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd');
begin
  for rec in channel_chg_info loop
    update channel
       set status_cd = '12', status_date = sysdate
     where channel_id = rec.channel_id;
    update third_party_chn_info
       set status_cd = '12', status_date = sysdate
     where channel_id = rec.channel_id;
    update channel_applications
       set status_cd = '12', status_date = sysdate
     where channel_id = rec.channel_id;
    for rel in (select *
                  from channel_agreement_rel
                 where channel_id = rec.channel_id) loop
      update agreement
         set status_cd = '11'
       where agreement_id = rel.agreement_id;
    end loop;
    commit;
  end loop;
end;
/
