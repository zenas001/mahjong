CREATE procedure           PROC_JT_TABLE_CHECK is
  cursor cur is
    select * from JT_TABLES_CHECK a order by a.table_name;

  v_hasTable      int := 0;
  v_hasCol        int := 0;
  v_cnt           int := 0;
  v_col_type_name varchar2(4000) := '';
  v_col_type_len  varchar2(4000) := '';
  v_sql           varchar2(4000) := '';
 v_col_number_len  varchar2(4000) := '';
begin
  for rec in cur loop
    v_hasTable      := 0;
    v_hasCol        := 0;
    v_cnt           := v_cnt + 1;
    v_col_type_name := '';
    v_col_type_len  := '';
    v_col_number_len:='';
    select nvl(count(1), 0)
      into v_hasTable
      from user_tables a
     where a.table_name = rec.table_name;

    if v_hasTable > 0 then
      --有找到表
      update JT_TABLES_CHECK a
         set a.have_table = 'TRUE'
       where a.table_name = rec.table_name;

      select count(1)
        into v_hasCol
        from user_tab_columns a
       where a.table_name = rec.table_name
         and a.COLUMN_NAME = rec.column_name;

      if v_hasCol > 0 then

        select a.DATA_TYPE, a.DATA_LENGTH,a.DATA_PRECISION
          into v_col_type_name, v_col_type_len,v_col_number_len
          from user_tab_columns a
         where a.table_name = rec.table_name
           and a.COLUMN_NAME = rec.column_name;

 --如果是NUMBER 则长度用精度代替
          if upper(rec.data_type_name) = upper('NUMBER') then
           v_col_type_len:=v_col_number_len;
        end if;

        --找到相应字段
        update JT_TABLES_CHECK a
           set a.local_data_type_name   = v_col_type_name,
               a.local_data_type_length = v_col_type_len,
               a.local_data_type        = v_col_type_name || '(' ||
                                          v_col_type_len || ')'
         where a.table_name = rec.table_name
           and a.column_name = rec.column_name;
      --字段类型一致
        if v_col_type_name = rec.data_type_name then

          if v_col_type_len = rec.data_type_length then
            --长度一致
            update JT_TABLES_CHECK a
               set a.check_result = '通过',
                   a.fix_script   = '集团字段跟我们字段完全一致'
             where a.table_name = rec.table_name
               and a.column_name = rec.column_name;

          elsif v_col_type_len > rec.data_type_length then
            --我们比集团长
            update JT_TABLES_CHECK a
               set a.check_result = '通过',
                   a.fix_script   = '我们字段长度比集团长，可不调整'
             where a.table_name = rec.table_name
               and a.column_name = rec.column_name;

          elsif v_col_type_len < rec.data_type_length then
            --我们比集团短
            v_sql := '--我们字段长度比集团短，调整脚本如下(历史表也要做调整)

            alter table ' || rec.table_name ||
                     ' modify   ' || rec.column_name || '   ' ||
                     rec.data_type_name || '(' || rec.data_type_length || ');

                     ';

            v_sql := v_sql || ' alter table ' || rec.table_name ||
                     '_HIS   modify   ' || rec.column_name || '   ' ||
                     rec.data_type_name || '(' || rec.data_type_length || ');

                     ';

            update JT_TABLES_CHECK a
               set a.check_result = '不通过', a.fix_script = v_sql
             where a.table_name = rec.table_name
               and a.column_name = rec.column_name;

          elsif upper(v_col_type_name) = upper('DATE') then
            --长度一致
            update JT_TABLES_CHECK a
               set a.check_result = '通过',
                   a.fix_script   = '集团字段跟我们字段完全一致'
             where a.table_name = rec.table_name
               and a.column_name = rec.column_name;

          end if;

        else
          --字段类型不一致
          update JT_TABLES_CHECK a
             set a.check_result = '不通过',
                 a.fix_script   = '集团字段跟我们字段的类型不一致'
           where a.table_name = rec.table_name
             and a.column_name = rec.column_name;

        end if;

      else
        --未找到相应字段

        v_sql := '--未找到对应的字段，调整脚本如下(历史表也要做调整)

            alter table ' || rec.table_name || ' ADD   ' ||
                 rec.column_name || '   ' || rec.data_type_name || '(' ||
                 rec.data_type_length || ');';
        if upper(rec.data_type_name) = upper('DATE') then
          v_sql := substr(v_sql, 0, length(v_sql) - 3);
          v_sql := v_sql || ';';
        end if;
        v_sql := v_sql || '

           ';
        v_sql := v_sql || ' alter table ' || rec.table_name ||
                 '_HIS   ADD   ' || rec.column_name || '   ' ||
                 rec.data_type_name || '(' || rec.data_type_length || ');';
        if upper(rec.data_type_name) = upper('DATE') then
          v_sql := substr(v_sql, 0, length(v_sql) - 3);
          v_sql := v_sql || ';';
        end if;
        v_sql := v_sql || '

           ';
        update JT_TABLES_CHECK a
           set a.check_result = '不通过', a.fix_script = v_sql
         where a.table_name = rec.table_name
           and a.column_name = rec.column_name;

      end if;

    else
      --没有找到表
      update JT_TABLES_CHECK a
         set a.have_table   = 'FALSE',
             a.check_result = '不通过',
             a.fix_script   = '未找到对应的表'
       where a.table_name = rec.table_name;

    end if;

    if v_cnt > 99 then
      --100条提交一次
      v_cnt := 0;
      commit;
    end if;

  end loop;

  commit;
end;
/
