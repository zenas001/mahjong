CREATE procedure           Pro_insert_attr_info is
    v_interval           number(12) ;
begin

     --删除竞争状态的属性值
     delete from attr_value t where t.attr_id in (select  a.attr_id  from attr_spec  a where a.java_code='gridCompeteSts' and a.class_id='5');
      --删除竞争状态的属性
     delete from attr_spec t  where t.java_code='gridCompeteSts' and t.class_id='5';
     --删除路段属性
     delete from attr_spec t  where t.java_code='gridRoadAddr' and t.class_id='5';
     --删除广告数属性
     delete from attr_spec t  where t.java_code='gridAdviseNum' and t.class_id='5';
     --删除广告栏描述属性
     delete from attr_spec t  where t.java_code='gridAdviseDesc' and t.class_id='5';
     --删除市场空间的店铺数属性
     delete from attr_spec t  where t.java_code='gridMarketUnit' and t.class_id='5';
     --删除市场空间的店铺数属性
     delete from attr_spec t  where t.java_code='gridMarketIdel' and t.class_id='5';
     --删除市场空间我网客户数属性
     delete from attr_spec t  where t.java_code='gridMarketMyCust' and t.class_id='5';
     --删除市场空间的他网客户数属性
     delete from attr_spec t  where t.java_code='gridMarketOtherCust' and t.class_id='5';
     --删除市场空间的无通信客户数属性
     delete from attr_spec t  where t.java_code='gridMarketNoCust' and t.class_id='5';
     --删除行业客户属性
     delete from attr_spec t  where t.java_code='gridIndustryCust' and t.class_id='5';

     select seq_attr_spec_id.nextval into v_interval from dual;
        --添加竟争状态
    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (v_interval, 'GRID_COMPETE_STS', '竞争状态', '竞争状态', 'C', '', '', '', '', '', '', null, null, 5, 'T3', 'gridCompeteSts', 129, 'NA', null, '', 1, 0);

    insert into attr_value (ATTR_VALUE_ID, ATTR_VALUE_NAME, ATTR_ID, ATTR_DESC, ATTR_VALUE_TYPE, ATTR_FORMAT, ATTR_LENGTH, ATTR_VALUE, MAX_VALUE, MIN_VALUE, STATUS_DATE, CREATE_DATE, STATUS_CD, PARENT_VALUE_ID, ATTR_VALUE_SEQ)
    values (seq_attr_value_id.nextval, '高', v_interval, '高', '', '', 4, '10', '', '', to_date('17-12-2010 09:08:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-12-2010 09:08:15', 'dd-mm-yyyy hh24:mi:ss'), 'H0A', null, null);

    insert into attr_value (ATTR_VALUE_ID, ATTR_VALUE_NAME, ATTR_ID, ATTR_DESC, ATTR_VALUE_TYPE, ATTR_FORMAT, ATTR_LENGTH, ATTR_VALUE, MAX_VALUE, MIN_VALUE, STATUS_DATE, CREATE_DATE, STATUS_CD, PARENT_VALUE_ID, ATTR_VALUE_SEQ)
    values (seq_attr_value_id.nextval, '中', v_interval, '中', '', '', 4, '11', '', '', to_date('17-12-2010 09:08:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-12-2010 09:08:15', 'dd-mm-yyyy hh24:mi:ss'), 'H0A', null, null);

    insert into attr_value (ATTR_VALUE_ID, ATTR_VALUE_NAME, ATTR_ID, ATTR_DESC, ATTR_VALUE_TYPE, ATTR_FORMAT, ATTR_LENGTH, ATTR_VALUE, MAX_VALUE, MIN_VALUE, STATUS_DATE, CREATE_DATE, STATUS_CD, PARENT_VALUE_ID, ATTR_VALUE_SEQ)
    values (seq_attr_value_id.nextval, '低', v_interval, '低', '', '', 4, '12', '', '', to_date('17-12-2010 09:08:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-12-2010 09:08:15', 'dd-mm-yyyy hh24:mi:ss'), 'H0A', null, null);


    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_ROAD_ADDR', '路段', '路段', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridRoadAddr', 129, 'NA', null, '', 1, 0);

    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_MARKET_UNIT', '店铺/单位数', '店铺/单位数', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridMarketUnit', 129, 'NA', null, '', 1, 0);

    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_ADVISE_NUM', '广告栏个数', '广告栏个数', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridAdviseNum', 129, 'NA', null, '', 1, 0);

    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_ADVISE_DESC', '广告栏描述', '广告栏描述', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridAdviseDesc', 129, 'NA', null, '', 1, 0);

    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_MARKET_IDEL', '空置数', '空置数', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridMarketIdel', 129, 'NA', null, '', 1, 0);

    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_MARKET_MY_CUST', '我网客户数', '我网客户数', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridMarketMyCust', 129, 'NA', null, '', 1, 0);

   insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_MARKET_OTHER_CUST', '他网客户数', '他网客户数', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridMarketOtherCust', 129, 'NA', null, '', 1, 0);

   insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
    values (seq_attr_spec_id.nextval, 'GRID_MARKET_NO_CUST', '无通信客户数', '无通信客户数', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridMarketNoCust', 129, 'NA', null, '', 1, 0);

    insert into attr_spec (ATTR_ID, ATTR_CD, ATTR_NAME, ATTR_DESC, ATTR_VALUE_CODE, DEFAULT_VALUE, VALUE_FROM, VALUE_TO, IS_UNIQUE, IS_NULLABLE, STATUS_CD, STATUS_DATE, CREATE_DATE, CLASS_ID, ATTR_TYPE, JAVA_CODE, ATTR_SEQ, CNS_TYPE, REF_CLASS_ID, ATTR_LEVEL, IS_DANY_ATTR, IS_MULTI_VALUE)
   values (seq_attr_spec_id.nextval, 'GRID_INDUSTRY_CUST', '行业客户', '行业客户', 'C', '', '', '', '', '', '', null, null, 5, 'T1', 'gridIndustryCust', 129, 'NA', null, '', 1, 0);
   commit;
  exception
  when others then
    rollback;
end Pro_insert_attr_info;
/
