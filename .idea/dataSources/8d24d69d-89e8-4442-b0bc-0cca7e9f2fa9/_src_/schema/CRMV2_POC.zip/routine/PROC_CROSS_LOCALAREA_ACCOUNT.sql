CREATE procedure           proc_cross_localarea_account(cust_num in varchar2, --客户编码
                                                         acct_num in varchar2, --账户编码
                                                         o_result out varchar2) is
  i_cust_count number := 0;
  i_acct_count number := 0;
  i_cy_seq     number;
  i_kh_seq     number;
  i_tel_acct_id_seq number;
  i_batch_num  number;
  i_cust_id    number;
  i_party_id   number;
  i_acct_id    number;
  /**
   功能说明：crm2.0跨本地网业务，账户同步到1.0
   author：luxb
   创建时间：2012-4-14
  **/
begin
  select seq_cross_localarea_batch_id.nextval into i_batch_num from dual;
  /**先通过客户编码查询crm1.0中这个客户是否存在，不存在则添加**/
  select count(1) into i_cust_count from crm.kh@LK_TOCRM1_CROSS where khbm = cust_num;

   --获取2.0客户表的客户ID，参与人ID
    select c.cust_id, c.party_id
      into i_cust_id, i_party_id
      from cust c
     where cust_number = cust_num;

  if i_cust_count = 0 then
    --插入数据到客户
    o_result := '添加参与人信息错误';
    select crm.cyid_seq.nextval@LK_TOCRM1_CROSS into i_cy_seq from dual;
    --参与人信息添加
    insert into crm.cy@LK_TOCRM1_CROSS
      (cyid, --参与人id
       cymc, --参与人名称
       cyzl, --常用证件类型
       cymk, --常用证件号码
       cyrq, --生成日期
       cyzt, --参与人状态
       cyjp, --名称简拼
       cypm, --英文名称
       cylx, --参与人类型
       cygr, --修改日期
       identify_addr, --证件地址
       region, --区域
       ext_flag1 --虚拟档案标识‘Y’代表虚档案
       )
      select i_cy_seq,
             p.party_name,
             pc.cert_type,
             pc.cert_number,
             sysdate,
             '10A',
             p.party_abbrname,
             p.english_name,
             p.party_type,
             sysdate,
             pc.cert_address,
             p.region_cd,
             'Y'
        from party p, party_certification pc
       where p.party_id = i_party_id
         and p.party_id = pc.party_id;
    --计费增量信息
    proc_cross_ins_billing_update('V_PARTY', i_cy_seq, 'PARTY_ID');
    --同步日志表
    proc_cross_localarea_log('PARTY',i_cy_seq,i_party_id,i_batch_num,'同步参与人信息');

    --客户信息添加
    o_result := '添加客户信息错误';
    select crm.khid_seq.nextval@LK_TOCRM1_CROSS into i_kh_seq from dual;
    insert into crm.kh@LK_TOCRM1_CROSS
      (khid, --客户id
       khcy, --参与人id
       khzy, --客户重要标识
       khxz, --客户类型
       khzt, --客户状态
       khbm, --客户编码
       khlx, --客户行业
       khrq, --生成日期
       khgr, --修改日期
       khxd, --客户级别
       khqy, --客户区域
       main_group_id, --战略群标识
       correspondent,
       cust_year_type,
       ext_flag1)
      select i_kh_seq,
             i_cy_seq,
             c.important_level,
             decode(c.cust_type,'1000','1','3'),
             '10A',
             c.cust_number,
             substr(c.industry_cd, 0, 5),
             sysdate,
             sysdate,
             c.cust_area_grade,
             c.region_cd,
             decode(c.cust_type,'1000','1','3'),
             c.cust_address,
             c.cur_year_type,
             'Y'
        from cust c
       where c.cust_id = i_cust_id;
    proc_cross_ins_billing_update('V_CUST', i_kh_seq, 'CUST_ID');
    proc_cross_localarea_log('CUST',i_kh_seq,i_cust_id,i_batch_num,'同步参与人信息');
  else
    select khid
      into i_kh_seq
      from crm.kh@LK_TOCRM1_CROSS
     where khbm = cust_num;
  end if;

  --同步账户信息
  o_result := '添加电信账户信息错误';
  select count(1) into i_acct_count from crm.telecom_account@LK_TOCRM1_CROSS
   where agreement_code = acct_num
     and customer_id = i_kh_seq;

  if i_acct_count = 0 then
    select crm.tel_acct_id_seq.nextval@LK_TOCRM1_CROSS into i_tel_acct_id_seq from dual;
    select account_id into i_acct_id from account
     where account_number = acct_num
       and cust_id = i_cust_id;

    insert into crm.telecom_account@LK_TOCRM1_CROSS
      (tel_acct_id, --电信账户标识
       agreement_code, --合同号
       customer_id, --客户标识
       tel_acct_code, --电信账户编码
       tel_acct_name, --电信账户名称
       state, --状态
       create_date, --创建时间
       deduct_charge, --扣款金额
       deduct_limit, --扣款阀值
       modify_date,
       REAL_MODIFY_DATE,
       region,
       ext_flag1)
      select i_tel_acct_id_seq,
             a.account_number,
             i_kh_seq,
             a.account_number,
             a.account_name,
             '10A',
             a.create_date,
             a.deduct_charge,
             a.deduct_limit,
             a.status_date,
             a.update_date,
             a.region_cd,
             'Y'
        from account a
       where a.account_id = i_acct_id;
    proc_cross_ins_billing_update('TELECOM_ACCOUNT',i_tel_acct_id_seq,'TEL_ACCT_ID');
    proc_cross_localarea_log('TELECOM_ACCOUNT',i_tel_acct_id_seq,i_acct_id,i_batch_num,'同步电信账户信息');
  end if;
  o_result := 'TRUE';
  commit;
exception
  when others then
    o_result := o_result;
end;
/
