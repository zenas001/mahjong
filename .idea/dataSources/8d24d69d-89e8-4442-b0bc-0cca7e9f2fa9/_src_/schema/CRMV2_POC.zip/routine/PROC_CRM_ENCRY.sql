CREATE procedure           PROC_CRM_ENCRY(i_srcstr in varchar2, o_desstr out varchar2, o_errcode out integer,o_errmsg  out varchar2) is
       i number;
       j integer;
       m integer;
       n integer;
       keystr varchar2(32);
       tmpstr varchar2(2);
       validstring varchar2(100);
       hexstr varchar2(10);

      FUNCTION hex_to_dec (hexin IN VARCHAR2) RETURN NUMBER IS
        v_charpos NUMBER;
        v_charval CHAR(1);
        v_return NUMBER DEFAULT 0;
        v_power NUMBER DEFAULT 0;
        v_string VARCHAR2(2000);
      BEGIN
        v_string := UPPER(hexin);
        v_charpos := LENGTH(v_string);
        WHILE v_charpos > 0 LOOP
          v_charval := SUBSTR(v_string,v_charpos,1);
          IF v_charval BETWEEN '0' AND '9' THEN
            v_return := v_return + TO_NUMBER(v_charval) * POWER(16,v_power);
          ELSE
            IF v_charval = 'A' THEN
              v_return := v_return + 10 * POWER(16,v_power);
            ELSIF v_charval = 'B' THEN
              v_return := v_return + 11 * POWER(16,v_power);
            ELSIF v_charval = 'C' THEN
              v_return := v_return + 12 * POWER(16,v_power);
            ELSIF v_charval = 'D' THEN
              v_return := v_return + 13 * POWER(16,v_power);
            ELSIF v_charval = 'E' THEN
              v_return := v_return + 14 * POWER(16,v_power);
            ELSIF v_charval = 'F' THEN
              v_return := v_return + 15 * POWER(16,v_power);
            ELSE
              raise_application_error(-20621,'Invalid input');
            END IF;
          END IF;
          v_charpos := v_charpos - 1;
          v_power := v_power + 1;
        END LOOP;
        RETURN v_return;
      END hex_to_dec;

      FUNCTION dec_to_hex (decin IN NUMBER) RETURN VARCHAR2 IS
        v_decin NUMBER;
        v_next_digit NUMBER;
        v_result varchar(2000);
      BEGIN
        v_decin := decin;
        WHILE v_decin > 0 LOOP
          v_next_digit := mod(v_decin,16);
          IF v_next_digit > 9 THEN
            IF v_next_digit = 10 THEN v_result := 'a' || v_result;
            ELSIF v_next_digit = 11 THEN v_result := 'b' || v_result;
            ELSIF v_next_digit = 12 THEN v_result := 'c' || v_result;
            ELSIF v_next_digit = 13 THEN v_result := 'd' || v_result;
            ELSIF v_next_digit = 14 THEN v_result := 'e' || v_result;
            ELSIF v_next_digit = 15 THEN v_result := 'f' || v_result;
            ELSE raise_application_error(-20600,'Untrapped exception');
            END IF;
          ELSE
            v_result := to_char(v_next_digit) || v_result;
          END IF;
          v_decin := floor(v_decin / 16);
        END LOOP;
        RETURN v_result;
      END dec_to_hex;

      function isvalidsrc(src in varchar2,validstr in varchar2) return number is
         i number;
      begin
        while(i<=length(src)) loop
           if (Instr(validstr,substr(src,i,1))= 0) and ''''<> substr(src,i,1) then
             return 1;
           end if;

           i:=i+1;
        end loop;
        return 0;
      end;

begin
     o_errcode := 0;
     o_errmsg  := '';
     hexstr  := '';

     j:= 1;
     i:= 1;
     keystr := '*bv_.azqadec;d7efbikop,01-fre382';

     validstring := 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890~!@#$%^&*()_+{}[]/\|;:.<>,?"`=-';

     if isvalidsrc(i_srcstr,validstring)=1 then
        o_errcode := 1;
        o_errmsg := ' string is invalid!';
        return;
     end if;

     if(length(i_srcstr)>250) then
        o_errcode := 1;
        o_errmsg := 'length of source string is error!';
        return;
     end if;

     while(i<=length(i_srcstr)) loop
          tmpstr := substr(i_srcstr,i,1);

          m := ascii(substr(keystr,j,1));
          n := ascii(tmpstr);

          hexstr := dec_to_hex(m+n-bitand(m,n)*2);
          if length(hexstr)=0 or (hexstr is null) then
             o_desstr := o_desstr || '00';
          end if;

          if length(hexstr)=1 then
             o_desstr := o_desstr || '0' || hexstr;
          end if;

          if length(hexstr)=2 then
             o_desstr := o_desstr || hexstr ;
          end if;

          --desstr := o_desstr || dec_to_hex(m+n-bitand(m,n)*2) ;

          j:=j+1;
          if j>length(keystr) then
             j := 1;
          end if;

          i:=i+1;
     end loop;

     while(i<=16) loop
         n := 0;
         m := ascii(substr(keystr,j,1));

          hexstr := dec_to_hex(m+n-bitand(m,n)*2);
          if length(hexstr)=0 or (hexstr is null) then
             o_desstr := o_desstr || '00';
          end if;

          if length(hexstr)=1 then
             o_desstr := o_desstr || '0' || hexstr;
          end if;

          if length(hexstr)=2 then
             o_desstr := o_desstr || hexstr ;
          end if;

          j:=j+1;
          if j>length(keystr) then
             j := 1;
          end if;

         i:=i+1;
     end loop;

     -- dbms_output.put_line(rtrim(o_desstr));

/*     i := 49;
     j := ascii('*');

     select bitand(i,j) into k from dual;

     select i+j-bitand(i,j)*2 into l from dual;
     dbms_output.put_line(to_char(l));
 */
/*    select k+j-bitand(k,j)*2 into i from dual;
     dbms_output.put_line(to_char(i)); */

end PROC_CRM_ENCRY;
/
