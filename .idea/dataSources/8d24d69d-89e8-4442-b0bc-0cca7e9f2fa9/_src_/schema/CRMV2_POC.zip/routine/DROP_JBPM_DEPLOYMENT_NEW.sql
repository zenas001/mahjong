CREATE function           drop_jbpm_deployment_new(key_name in string)
  return boolean is

  result        boolean;
  deployment_id number(12);
begin
  --查询流程定义ID
  select a.deployment_
    into deployment_id
    from jbpm4_deployprop a
   where a.objname_ = key_name
     and a.key_ = 'pdkey';

  --任务执行实例
  --select* from jbpm4_task d ,jbpm4_execution c  where procdefid_ like 'SaleWorkOrderFlow%' and d.execution_ = c.dbid_;
  delete jbpm4_task
   where rowid in (select d.rowid
                     from jbpm4_task d, jbpm4_execution c
                    where procdefid_ like key_name || '%'
                      and d.execution_ = c.dbid_);

  --流程变量实例
  --select * from jbpm4_variable d ,jbpm4_execution c  where procdefid_ like 'SaleWorkOrderFlow%' and d.execution_ = c.dbid_;
  delete jbpm4_variable
   where rowid in (select d.rowid
                     from jbpm4_variable d, jbpm4_execution c
                    where procdefid_ like key_name || '%'
                      and d.execution_ = c.dbid_);

  --流程执行实例
  --select * from jbpm4_execution c  where procdefid_ like 'SaleWorkOrderFlow%';
  delete jbpm4_execution
   where rowid in (select rowid
                     from jbpm4_execution c
                    where procdefid_ like key_name || '%');

  --流程作业
  --select * from jbpm4_job c

  --流程LOB变量
  --select * from jbpm4_lob c, jbpm4_deployprop a, jbpm4_deployment b  where key_='pdkey' and a.deployment_=b.dbid_ and c.deployment_ = a.dbid_;

  --流程定义属性
  delete jbpm4_deployprop a where a.deployment_ = deployment_id;

  --流程定义
  delete jbpm4_deployment b where b.dbid_ = deployment_id;

  return(result);
end drop_jbpm_deployment_new;
/
