CREATE FUNCTION           fnc_crmv2_build_class(in_tab_name IN STRING)
  RETURN BOOLEAN IS
  RESULT     BOOLEAN;
  i_class_id INT := 0;
BEGIN
  RESULT := TRUE;
  --删除实体原有配置数据
  --delete attr_value where attr_id in(select attr_id from attr_spec a, sys_class b where a.class_id=b.class_id and b.table_name=in_tab_name);
  --delete attr_spec where class_id in (select class_id from sys_class where table_name=in_tab_name );
  --delete sys_class where table_name=in_tab_name;

  SELECT MAX(class_id) + 1 INTO i_class_id FROM sys_class;
  --插入类配置数据
  INSERT INTO sys_class
    (class_id,
     super_class_id,
     class_name,
     java_code,
     table_name,
     is_entity,
     class_desc,
     class_hint,
     is_change_log,
     is_dany_class,
     status_cd,
     create_date,
     status_date,
     create_staff,
     update_staff)
    SELECT i_class_id,
           -2,
           substr(comments, 0, 11),
           in_tab_name,
           in_tab_name,
           1,
           comments,
           comments,
           1,
           0,
           '1000',
           SYSDATE,
           SYSDATE,
           -1,
           -1
      FROM user_tab_comments
     WHERE table_name = in_tab_name;
  --  commit;

  --根据表名更新实体名字
  UPDATE sys_class
     SET java_code = initcap(substr(java_code, 0, instr(java_code, '_') - 1)) ||
                     initcap(substr(java_code, instr(java_code, '_') + 1))
   WHERE class_id = i_class_id;
  FOR i IN 1 .. 7
  LOOP
    UPDATE sys_class
       SET java_code = substr(java_code, 0, instr(java_code, '_') - 1) ||
                       initcap(substr(java_code, instr(java_code, '_') + 1))
     WHERE class_id = i_class_id
       AND java_code LIKE '%\_%' ESCAPE '\';
  END LOOP;
  --  commit;
  --插入属性配置数据
  INSERT INTO attr_spec
    (attr_id,
     attr_cd,
     attr_name,
     attr_desc,
     attr_value_type,
     class_id,
     attr_type,
     attr_seq,
     is_dany_attr,
     is_multi_value,
     java_code,
     create_date,
     status_date,
     create_staff,
     update_staff,
     status_cd)
    SELECT seq_attr_spec_id.nextval,
           b.column_name,
           substr(comments, 1, 30),
           substr(comments, 1, 50),
           decode(data_type,
                  'TIMESTAMP(6)',
                  'T',
                  'FLOAT',
                  'F',
                  'NUMBER',
                  'N',
                  'CHAR',
                  'C',
                  'CLOB',
                  'B',
                  'DATE',
                  'D',
                  'VARCHAR2',
                  'C',
                  'BLOB',
                  'B',
                  'C'),
           i_class_id,
           'T1',
           rownum,
           0,
           0,
           b.column_name,
           SYSDATE,
           SYSDATE,
           -1,
           -1,
           '1000'
      FROM user_col_comments a, user_tab_columns b
     WHERE a.table_name(+) = b.table_name
       AND a.column_name(+) = b.column_name
       AND b.table_name = in_tab_name
       AND b.column_name NOT IN ('STATUS_CD',
                                 'STATUS_DATE',
                                 'CREATE_DATE',
                                 'UPDATE_DATE',
                                 'AREA_ID',
                                 'REGION_CD',
                                 'UPDATE_STAFF',
                                 'CREATE_STAFF');
  --   commit;
  --根据数据库列名，更新java_code
  UPDATE attr_spec
     SET java_code = lower(substr(attr_cd, 0, instr(attr_cd, '_') - 1)) ||
                     initcap(substr(attr_cd, instr(attr_cd, '_') + 1))
   WHERE class_id = i_class_id;
  COMMIT;
  FOR i IN 1 .. 7
  LOOP
    UPDATE attr_spec
       SET java_code = substr(java_code, 0, instr(java_code, '_') - 1) ||
                       initcap(substr(java_code, instr(java_code, '_') + 1))
     WHERE class_id = i_class_id
       AND java_code LIKE '%\_%' ESCAPE '\';
  END LOOP;

  --插入外键关联的对象引用关系属性
  INSERT INTO attr_spec
    (attr_id,
     attr_cd,
     attr_name,
     attr_desc,
     attr_value_type,
     class_id,
     attr_type,
     attr_seq,
     is_dany_attr,
     is_multi_value,
     java_code,
     ref_class_id,
     create_date,
     status_date,
     create_staff,
     update_staff,
     status_cd)
    SELECT seq_attr_spec_id.nextval,
           substr(column_namea, 1, length(column_namea) - 3),
           attr_name,
           attr_desc,
           'N',
           class_ida,
           'T2',
           rownum,
           0,
           0,
           substr(java_code, 1, length(java_code) - 2),
           class_idb,
           SYSDATE,
           SYSDATE,
           -1,
           -1,
           '1000'
      FROM (SELECT DISTINCT cls.class_id     class_ida,
                            cls.table_name   tablea,
                            ucc.column_name  column_namea,
                            rela.table_name  b,
                            rela.column_name column_nameb,
                            rela.class_id    class_idb,
                            asp.java_code    java_code,
                            asp.attr_desc,
                            asp.attr_name
              FROM user_constraints uc,
                   user_cons_columns ucc,
                   sys_class cls,
                   attr_spec asp,
                   (SELECT class_id,
                           t2.table_name,
                           t2.column_name,
                           t1.r_constraint_name
                      FROM user_constraints  t1,
                           user_cons_columns t2,
                           sys_class         cls
                     WHERE t1.r_constraint_name = t2.constraint_name
                       AND t2.table_name = cls.table_name) rela
             WHERE uc.constraint_name = ucc.constraint_name
               AND uc.r_constraint_name = rela.r_constraint_name
               AND uc.table_name = cls.table_name
               AND asp.class_id = cls.class_id
               AND asp.attr_cd = ucc.column_name
               AND cls.table_name = in_tab_name);

  COMMIT;
  RETURN RESULT;

END fnc_crmv2_build_class;
/
