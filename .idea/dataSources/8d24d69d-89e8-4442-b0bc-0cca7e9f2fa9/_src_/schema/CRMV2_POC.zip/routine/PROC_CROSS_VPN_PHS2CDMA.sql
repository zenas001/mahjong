CREATE procedure           proc_cross_vpn_phs2cdma(i_serv_code      in varchar2, --销售品接入号码
                                                    i_macc_nbr       in varchar2, --产品接入号码
                                                    i_acc_nbr        in varchar2,--成员产品接入号码
                                                    i_region_cd      in number,
                                                    op_flag          in varchar2,
                                                    o_result         out varchar2
                                                    ) is
  /**
   功能说明：crm2.0跨本地网业务，vpn_phs2cdma信息保存
   author：luxb
   创建时间：2012-5-26
  **/
  i_mdse_ida  number;
  i_mdse_count number;
  i_area_code varchar(10);
begin
   if i_serv_code is not null then
        --对应2.0群组销售品
        select count(*) into i_mdse_count
       from crm.prod@lk_tocrm1_cross      p,
            crm.mdse@lk_tocrm1_cross      m,
            crm.mdse_rela@lk_tocrm1_cross r
      where p.prod_id = m.prod_id
        and p.account = i_serv_code
        and m.mdse_id = r.mdse_idb;
        if i_mdse_count <> 0 then
        select r.mdse_ida into i_mdse_ida
        from crm.prod@lk_tocrm1_cross      p,
            crm.mdse@lk_tocrm1_cross      m,
            crm.mdse_rela@lk_tocrm1_cross r
      where p.prod_id = m.prod_id
        and p.account = i_serv_code
        and m.mdse_id = r.mdse_idb;
        end if;
     else if i_macc_nbr is not null then
        --对应2.0产品是群组产品
         select count(*) into i_mdse_count from crm.mdse@lk_tocrm1_cross m,crm.prod@lk_tocrm1_cross p
        where m.prod_id = p.prod_id
          and p.account = i_macc_nbr
          and (m.mdse_type='107' or m.mdse_type='101');
        if i_mdse_count <> 0 then
          select mdse_id into i_mdse_ida from crm.mdse@lk_tocrm1_cross m,crm.prod@lk_tocrm1_cross p
          where m.prod_id = p.prod_id
            and p.account = i_macc_nbr
            and (m.mdse_type='107' or m.mdse_type='101');
        end if;

     end if;
     end if;
   --获取区域
   select area_code into i_area_code from area_code where region_id = i_region_cd;
   --入网插入数据
   if i_mdse_count <> 0 then
   if op_flag = '0' then
     insert into crm.vpn_phs2cdma@lk_tocrm1_cross
     (member_id,
      vpn_id,
      vpn_type,
      area_code,
      service_code,
      mdse_id,
      eff_date,
      exp_date,
      create_date,
      real_modify_date)
     values(
      crm.vpn_phs2cdma_id_seq.nextval@lk_tocrm1_cross,
      i_mdse_ida,
      -99,
      i_area_code,
      i_acc_nbr,
      null,
      sysdate,
      to_date('2199/1/1','yyyy-MM-dd'),
      sysdate,
      sysdate
     );
   else if op_flag = '1' then --退网、拆机
      insert into crm.vpn_phs2cdma_his@lk_tocrm1_cross
      (his_id,
       member_id,
       vpn_id,
       area_code,
       service_code,
       mdse_id,
       eff_date,
       exp_date,
       create_dat,
       real_modify_date,
       vpn_type)
  select crm.vpn_phs2cdma_his_id_seq.nextval@lk_tocrm1_cross,
         member_id,
         vpn_id,
         area_code,
         service_code,
         decode(mdse_id,'',0,mdse_id),
         eff_date,
         exp_date,
         create_date,
         real_modify_date,
         vpn_type
    from crm.vpn_phs2cdma@lk_tocrm1_cross
   where vpn_id = i_mdse_ida
     and service_code = i_acc_nbr
     and vpn_type = '-99';
   delete from crm.vpn_phs2cdma@lk_tocrm1_cross where vpn_id =i_mdse_ida and service_code = i_acc_nbr and area_code = area_code and vpn_type='-99';
   else if op_flag = '2' then --拆网
      insert into crm.vpn_phs2cdma_his@lk_tocrm1_cross
      (his_id,
       member_id,
       vpn_id,
       area_code,
       service_code,
       mdse_id,
       eff_date,
       exp_date,
       create_dat,
       real_modify_date,
       vpn_type)
      select crm.vpn_phs2cdma_his_id_seq.nextval@lk_tocrm1_cross,
             member_id,
             vpn_id,
             area_code,
             service_code,
             decode(mdse_id,'',0,mdse_id),
             eff_date,
             exp_date,
             create_date,
             real_modify_date,
             vpn_type
        from crm.vpn_phs2cdma@lk_tocrm1_cross
       where vpn_id = i_mdse_ida
         and vpn_type = '-99';
      delete from crm.vpn_phs2cdma@lk_tocrm1_cross where vpn_id =i_mdse_ida and vpn_type = '-99';
   end if;
   end if;
   end if;
   end if;
   o_result := 'TRUE';
   commit;
exception
  when others then
    o_result := o_result;
end;
/
