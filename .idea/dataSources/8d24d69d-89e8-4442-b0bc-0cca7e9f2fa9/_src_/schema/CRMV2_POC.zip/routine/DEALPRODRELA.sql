CREATE procedure           dealprodrela is
  cursor prod_attr is
    select * from PRODUCT where PROD_FUNC_TYPE = '102';
begin
  for rec in prod_attr loop
    DECLARE
      v_append_count number(12);
      V_COUNT        NUMBER(12);
      CURSOR PROD_APPEND IS
        SELECT b.fea_spec_id fea_spec_id, B.PROD_SPEC_ID
          FROM TEMP_HMM_PROD_FEA_SPEC B
         WHERE B.CODE = rec.product_nbr
           and b.name = rec.product_name;
    begin
      SELECT COUNT(*)
        INTO v_append_count
        FROM TEMP_HMM_PROD_FEA_SPEC B
       WHERE B.CODE = rec.product_nbr
         and b.name = rec.product_name;
      IF v_append_count > 0 THEN
        FOR REC1 IN PROD_APPEND LOOP
          V_COUNT := 0;
          SELECT COUNT(*)
            INTO V_COUNT
            FROM PRODUCT X
           WHERE X.PRODUCT_ID = REC.PRODUCT_ID;
          IF V_COUNT > 0 THEN
            V_COUNT := 0;
            SELECT COUNT(*)
              INTO V_COUNT
              FROM PRODUCT PT
             WHERE PT.PRODUCT_ID = REC1.PROD_SPEC_ID;
            IF V_COUNT > 0 THEN
              INSERT INTO PRODUCT_REL
                (PRODUCT_REL_ID,
                 RELATION_TYPE_CD,
                 PRODUCT_A_ID,
                 PRODUCT_Z_ID)
                SELECT SEQ_PRODUCT_RELA_ID.NEXTVAL,
                       '102',
                       REC1.PROD_SPEC_ID,
                       REC.PRODUCT_ID
                  FROM DUAL;
            END IF;
          END IF;
        end loop;
      END IF;
    END;
  end loop;
end dealprodrela;
/
