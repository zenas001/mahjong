CREATE PROCEDURE           mod_prod_offer_inst_1097   ( V_PROD_OFFER_INST_ID IN VARCHAR2) is
/*cursor cur is --定义档案游标
 --select * from ITSC_CRMV2.yyx_prod_offer_inst_1097b WHERE STATUS_CD='1097' and prod_offer_inst_id='2527268351';

 select * from CRMV2.prod_offer_inst WHERE prod_offer_inst_iD='2528469021' AND  STATUS_CD='1097';*/
  his_Id_min    VARCHAR2(30); -- 割接步骤
   his_Id_max VARCHAR2(4000);
   v_eff_date date ;
   v_exp_date  date ;
    cn1097 number;
     v_attr_value  VARCHAR2(40);
      V_ERR_MSS  VARCHAR2(4000);
BEGIN
 /* 1.prod_offer_inst_hIS HIS_iD 大的STATUS_CD 改成1000
2.取 HIS小的 EXP_DATE 更新到 HIS大的EFF_DATE
3.取 HIS小REC_UPDATE_DATE 更新  HIS大的STATUS_DATE

2.PROD_OFFER_INST STATUS_CD 改成1000  EFF_DATE= HIS小的 EXP_DATE ，STATE_DATE= HIS大的REC_uPDATE
4.ROD_OFFER_INST_ATTR STATUS_CD 改成1000 ,生失效时间和销售品实例保持一致
create table  ITSC_CRMV2.yyx_prod_offer_inst_1097b as
select  a.*
  from ITSC_CRMV2.yyx_prod_offer_inst_1097a  A where
    (select count(1) from  crmv2.prod_offer_inst_hIs where Prod_Offer_Inst_Id=a.Prod_Offer_Inst_Id and STATUS_CD='1097')>0
 AND  (select count(1)  from   crmv2.prod_offer_inst_hIs where Prod_Offer_Inst_Id=a.Prod_Offer_Inst_Id and STATUS_CD='1299')>0
*

订单竣工 但是销售品实例一表状态1097状态数据
获取销售品实例生效方式（prod_offer_inst_attr attr_id = 800000577）
将1097状态移到二表，一表添加状态1000数据，生效时间根据生效方式计算，
0立即生效时取关联接入类产品的起租时间
1次月生效时 基准时间用下面这个语句去
生效方式为3的 销售品实例生效时间取prod_offer_inst_attr属性上的延期生效时间 attr_id -700003120
select finish_time from order_item_his where order_item_obj_id = '3'
and class_id = 6 and service_offer_id = '500'

*/
begin
-------------判断是否符合要求----------------
select count(1) into      cn1097 from CRMV2.PROD_OFFER_INST a
WHERE   NOT  exists (select 1
          from CRMV2.ORDER_ITEM
         where order_item_obj_id = a.prod_offer_inst_id
           and service_offer_id in ('627','600','601','603','625','626','81','612','613','609','500')
           and class_id = 6)
       and NOT  exists (select 1
          from CRMV2.ORDER_ITEM_his
         where order_item_obj_id = a.prod_offer_inst_id
           and service_offer_id  = 500
           and class_id = 6
           and status_cd = '401300')
       and NOT  exists (select 1
          from CRMV2.ORDER_ITEM_his
         where order_item_obj_id = a.prod_offer_inst_id
           and service_offer_id in ('627','600','601','603','625','626','81','612','613','609')
           and class_id = 6) and
            NOT EXISTS (select param2 from CRMV2.o_auto_order_src_info where status_cd=1000
   AND a.PROD_OFFER_INST_ID=PARAM2)
and  EXISTS
(select 1 from prod_offer where  offer_sub_type='T01'
and prod_offer_id=a.prod_offer_id)
and STATUS_CD='1097'
and prod_offer_id=v_PROD_OFFER_INST_ID;

if  cn1097=0 then
  return;
end if;
-----------------------
----备份-----
--insert into  yyx_prod_offer_inst_1097b
INSERT INTO itsc_crmv2.yyx_PRO_201301083898
select *
  from prod_offer_inst
                  where prod_offer_inst_id = V_PROD_OFFER_INST_ID;

  --insert into YYX_PROD_OFFER_INST_HIS_1097
 INSERT INTO yyx_PRO_201301083898_hIS
 select * from prod_offer_inst_HIS
  WHERE    prod_offer_inst_id = V_PROD_OFFER_INST_ID;


INSERT INTO  yyx_PRO_201301083898_attr
select * from prod_offer_inst_attr where  prod_offer_inst_id = V_PROD_OFFER_INST_ID;
  COMMIT;
---------------
 select count(1) into cn1097 from  crmv2.prod_offer_inst_hIs ---历史1097是否大于10
 where Prod_Offer_Inst_Id=V_Prod_Offer_Inst_Id and STATUS_CD='1097';

 if cn1097>0 then
   Select min(his_Id) into his_Id_min
                   from prod_offer_inst_hIs
                  where prod_offer_inst_id =V_PROD_OFFER_INST_ID
                    and STATUS_CD = '1097';

 select mAX(his_Id) into his_Id_max
                   from prod_offer_inst_hIs
                  where prod_offer_inst_id = V_PROD_OFFER_INST_ID
                    and STATUS_CD = '1097';


update prod_offer_inst_his
   set STATUS_CD   = '1000',
       EFF_DATE   =
       (select EXP_DATE
          from prod_offer_inst_hIs
         where his_id = his_id_min
           and PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID),
       status_date =
       (select REC_UPDATE_DATE
          from prod_offer_inst_hIs
         where his_id = his_id_min
           and PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID)
 where his_Id = his_Id_max
   and prod_offer_inst_id = V_PROD_OFFER_INST_ID;


 update crmv2.prod_offer_inst
    set STATUS_CD   = '1000',
        status_date =
        (select REC_UPDATE_DATE
           from prod_offer_inst_hIs
          where his_id = his_id_max
            and PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID),
        EFF_DATE   =
        (select EXP_DATE
           from prod_offer_inst_hIs
          where his_id = his_id_min
            and PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID)
  where PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID;
 commit;

update crmv2.prod_offer_inst_attr
   set exp_date =
       (select exp_date
          from crmv2.prod_offer_inst
         where prod_offer_inst_id = v_prod_offer_inst_id),
       eff_date =
       (select eff_date
          from crmv2.prod_offer_inst
         where prod_offer_inst_id =  v_prod_offer_inst_id),
       STATUS_CD = '1000'
 where PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID;
if cn1097>1 then
  DELETE prod_offer_inst_his
 where his_Id<> his_Id_min
 AND prod_offer_inst_id = V_PROD_OFFER_INST_ID
            and STATUS_CD = '1097';
 end if;
commit;
end if;

if   cn1097=0 then


select ATTR_VALUE
  into v_ATTR_VALUE
  from prod_offer_inst_attr
 where prod_offer_inst_id = v_prod_offer_inst_id
   and attr_id = 800000577;


if   v_ATTR_VALUE=0 then
  select Trunc(B.BEGIN_RENT_TIME)
    into v_eff_date
    from CRMV2.OFFER_PROD_INST_REL a, prod_inst b, crmv2.prodUCT C
   WHERE A.prod_offer_inst_id = v_prod_offer_inst_id
     and a.prod_Inst_Id = b.prod_inst_id
     AND B.PRODUCT_ID = C.PRODUCT_ID
     AND C.PROD_FUNC_TYPE = '101';
 ELSIF v_attr_value=1 then
 select Trunc(finish_time)
  into v_eff_date
  from CRMV2.order_item_his
 where order_item_obj_id = v_prod_offer_inst_id
   and class_id = 6
   and service_offer_id = '500';
elsif  v_attr_value=3 then
 select to_date(attr_value, 'yyyy-mm-dd')
   into v_eff_date
   from CRMV2.prod_offer_inst_attr
  where prod_offer_inst_id = v_prod_offer_inst_id
    and attr_id = 800000577;
end if;


insert into crmv2.prod_offer_inst_his
      (PROD_OFFER_INST_ID,
       PROD_OFFER_ID,
       CUST_ID,
       CHANNEL_ID,
       CREATE_DATE,
       STATUS_CD,
       STATUS_DATE,
       EFF_DATE,
       EXP_DATE,
       REGION,
       UPDATE_DATE,
       PROC_SERIAL,
       EXT_PROD_OFFER_INST_ID,
       LAN_ID,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       HIS_ID,
       REC_UPDATE_DATE,
       TRIAL_EFF_DATE,
       TRIAL_EXP_DATE,
       SERVICE_NBR,
       VERSION)
      select PROD_OFFER_INST_ID,
             PROD_OFFER_ID,
             CUST_ID,
             CHANNEL_ID,
             CREATE_DATE,
             STATUS_CD,
             STATUS_DATE,
             EFF_DATE,
             v_eff_date,
             REGION,
             sysdate + 1 / 24,
             PROC_SERIAL,
             EXT_PROD_OFFER_INST_ID,
             null,
             AREA_ID,
             REGION_CD,
             UPDATE_STAFF,
             CREATE_STAFF,
             crmv2.seq_prod_offer_inst_his_id.nextval,
             v_eff_date,
             TRIAL_EFF_DATE,
             TRIAL_EXP_DATE,
             SERVICE_NBR,
             VERSION
        from crmv2.prod_offer_inst
       where prod_offer_inst_id = v_prod_offer_inst_id;

update prod_offer_inst  set status_date = v_eff_date,eff_date=v_eff_date,STATUS_CD='1000'
where  prod_offer_inst_id = v_prod_offer_inst_id;
commit;
end if ;

update crmv2.prod_offer_inst_attr
   set exp_date =
       (select exp_date
          from crmv2.prod_offer_inst
         where prod_offer_inst_id = v_prod_offer_inst_id),
       eff_date =
       (select eff_date
          from crmv2.prod_offer_inst
         where prod_offer_inst_id = v_prod_offer_inst_id),
       STATUS_CD = '1000'
 where PROD_OFFER_INST_ID = V_PROD_OFFER_INST_ID;
commit;
itsc_crmv2.new_p_ins_billing_update('prod_offer_inst','prod_offer_inst_id',v_prod_offer_inst_id,'PRO_201301083898修复1097','yangyx');


EXCEPTION
      WHEN OTHERS THEN
        V_ERR_MSS := SQLERRM;
        INSERT INTO yyx_xf_ERR_LOG
        VALUES
          (null, v_prod_offer_inst_id, SYSDATE, V_ERR_MSS);
        COMMIT;
  END;
 --end loop;

end;
/
