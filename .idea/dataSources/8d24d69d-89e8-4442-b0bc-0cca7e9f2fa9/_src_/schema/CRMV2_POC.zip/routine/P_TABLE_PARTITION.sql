CREATE PROCEDURE           P_TABLE_PARTITION(V_USER      IN VARCHAR2,
                                              V_TABLE     IN VARCHAR2,
                                              V_TBS       IN VARCHAR2,
                                              V_PARTITION IN VARCHAR2)
/***************************************************************
   PROG NAME : 建立分区表
   VERSION : V1.0.0
   AUTHOR: SHENSHB
   CREATE_DATE: 20120319
  ****************************************************************/
 IS
  VC_OWNER        VARCHAR2(20);
  VC_SQL          VARCHAR2(10000);
  V_MSG           VARCHAR2(100);


BEGIN
  declare
       CURSOR TABLE_INDEX_CURSOR IS
      SELECT A.Index_Name
     FROM DBA_IND_COLUMNS A, DBA_INDEXES B
    WHERE A.TABLE_OWNER = V_USER
    AND A.TABLE_OWNER = B.TABLE_OWNER
    AND A.TABLE_NAME = V_TABLE
    AND A.INDEX_NAME = B.INDEX_NAME
    AND NOT EXISTS (SELECT *
           FROM DBA_CONSTRAINTS
          WHERE OWNER = V_USER
            AND CONSTRAINT_NAME = A.INDEX_NAME);

    CURSOR TABLE_PK_CURSOR IS
    select a.constraint_name
    from dba_constraints a where
    a.owner = V_USER and
    a.table_name = V_TABLE
    and (a.constraint_type = 'P'
    or a.constraint_type = 'R')  ;
  begin
    VC_SQL := 'create table ' || V_TABLE || '_new  ' ||
              'partition by list (' || V_PARTITION || ')
     (
    partition P_FZ_591 values (2)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_XM_592 values (3)
   tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_ND_593 values (4)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_PT_594 values (5)
    tablespace tbs_data_gc
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_QZ_595 values (6)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_ZZ_596 values (7)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_LY_597 values (8)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_SM_598 values (9)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_NP_599 values (10)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    ),
  partition P_590 values (default)
    tablespace ' || V_TBS || '
    pctfree 30
    initrans 5
    maxtrans 255
    storage
    (
      initial 64M
      next 1M
      minextents 1
      maxextents unlimited
    )
) as select * from  ' || V_TABLE;
    --execute immediate VC_SQL;
dbms_output.put_line(VC_SQL);
    --重命名
    VC_SQL := 'alter table  ' || V_TABLE || ' rename to ' || V_TABLE ||
              '_OTHER ';
  --  execute immediate VC_SQL;
    VC_SQL := 'alter table  ' || V_TABLE || '_new rename to ' || V_TABLE;
   -- execute immediate VC_SQL;
 --dbms_output.put_line(VC_SQL);
    COMMIT;
  end;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;

    V_MSG := VC_OWNER || '建立分区表出错';
    V_MSG:=sqlerrm;
    dbms_output.put_line(V_MSG);

END P_TABLE_PARTITION;
/
