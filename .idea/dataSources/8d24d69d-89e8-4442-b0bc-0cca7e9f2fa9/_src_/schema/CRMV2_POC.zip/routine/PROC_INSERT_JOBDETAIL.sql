CREATE procedure           proc_insert_jobdetail(jobId   in number,
                                            jobName in varchar2,
                                            startNum in number,
                                            procNum in number,
                                            appid   in varchar2,
                                            prcCounst in number)
is
  /**
   功能说明：
   author：luxb
   创建时间：2012-7-19
  **/
  i_num number;
  inm   number;
begin
   inm := startNum;
   while inm <=procNum loop
   i_num := startNum + 1;
   insert into intf_scheduler_jobdetail (JOBDETAIL_ID, JOB_ID, JOBDETAIL_NAME, START_TIME, END_TIME, REPEAT_COUNT, REPEAT_INTERVAL, START_UP_ONLOAD, SHOULD_RECOVER, ARGUMENTS, APPIDS, PROC_NUMBER, PROC_COUNT)
   values (seq_intf_scheduler_id.nextval, jobId, jobName||'-'||inm, sysdate, null, null, 60, null, 1, '', appid, inm, prcCounst);
   inm := inm +1;
   end loop;
   commit;
end;
/
