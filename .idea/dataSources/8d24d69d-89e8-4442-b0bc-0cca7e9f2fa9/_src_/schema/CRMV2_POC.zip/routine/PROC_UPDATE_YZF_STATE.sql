CREATE PROCEDURE           proc_update_yzf_state IS
  CURSOR c IS
    SELECT * FROM prod_inst_yzf a WHERE a.status_cd = '1099';
i       NUMBER := 0;
  v_cnt   number:= 0;
  str_msg VARCHAR2(2000);
BEGIN

  BEGIN
    FOR cur IN c LOOP
      BEGIN
        ----数据插入历史表
        INSERT INTO prod_inst_yzf_his
          (PROD_INST_YZF_ID,
           ORDER_ITEM_ID,
           PROD_INST_ID,
           TYPE,
           REMARK,
           STATUS_CD,
           STATUS_DATE,
           HIS_ID,
           AREA_ID,
           REGION_CD,
           CREATE_DATE,
           CREATE_STAFF,
           UPDATE_DATE,
           UPDATE_STAFF)
          (SELECT PROD_INST_YZF_ID,
                  ORDER_ITEM_ID,
                  PROD_INST_ID,
                  TYPE,
                  REMARK,
                  STATUS_CD,
                  STATUS_DATE,
                  seq_prod_inst_yzf_his_id.nextval,
                  AREA_ID,
                  REGION_CD,
                  CREATE_DATE,
                  CREATE_STAFF,
                  UPDATE_DATE,
                  UPDATE_STAFF
             FROM prod_inst_yzf oa
            WHERE oa.PROD_INST_YZF_ID = cur.PROD_INST_YZF_ID and oa.status_cd='1099');

        UPDATE prod_inst_yzf a
           SET a.status_cd    = '1000',
               a.update_date  = SYSDATE,
               a.status_date  = SYSDATE,
               a.update_staff = -1,
               a.remark=''
         WHERE a.PROD_INST_YZF_ID = cur.PROD_INST_YZF_ID and a.status_cd='1099';

         /*INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval,
         'ProdInstYzf轮询处理更新状态次数',
         to_char(v_cnt),
         SYSDATE
        );*/

        i     := i + 1;
        v_cnt := v_cnt + 1;

        IF i > 50 THEN
          COMMIT;
          i := 0;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval,
             'ProdInstYzf轮询处理异常状态,队列ID:' || cur.prod_inst_yzf_id,
             str_msg,
             SYSDATE);
          COMMIT;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval,
         'ProdInstYzf轮询处理后状态更新异常',
         str_msg,
         SYSDATE);
      COMMIT;
  END;

  BEGIN
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval,
         'ProdInstYzf轮询处理最后提交队列状态失败',
         str_msg,
         SYSDATE);
      COMMIT;
  END;
  COMMIT;
END proc_update_yzf_state;
/
