CREATE Procedure           CRM1TO2(IN_prod_inst_id IN number) IS
  v_prod_inst_id number(12);
begin

  v_prod_inst_id := IN_prod_inst_id;

  -- prod_inst_rel 表A
  insert into qrl_prod_inst_rel
    select * from prod_inst_rel where prod_inst_a_id = v_prod_inst_id;
  delete from prod_inst_rel where prod_inst_a_id = v_prod_inst_id;
  insert into prod_inst_rel
    select *
      from crmgc2.prod_inst_rel
     where prod_inst_a_id = v_prod_inst_id;

/*  -- prod_inst_rel_his
  insert into qrl_prod_inst_rel_his
    select * from prod_inst_rel_his where prod_inst_a_id = v_prod_inst_id;
  delete from prod_inst_rel_his where prod_inst_a_id = v_prod_inst_id;
  insert into prod_inst_rel_his
    select *
      from crmgc2.prod_inst_rel_his
     where prod_inst_a_id = v_prod_inst_id;
*/
  -- prod_inst 表
  insert into qrl_prod_inst
    select *
      from prod_inst
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  delete from prod_inst
   where prod_inst_id in
         (select prod_inst_z_id
            from crmgc2.prod_inst_rel
           where prod_inst_a_id = v_prod_inst_id);

  insert into prod_inst
    select *
      from crmgc2.prod_inst
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  -- prod_inst_his 表
  insert into qrl_prod_inst_his
    select *
      from prod_inst_his
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  delete from prod_inst_his
   where prod_inst_id in
         (select prod_inst_z_id
            from crmgc2.prod_inst_rel
           where prod_inst_a_id = v_prod_inst_id);

/*  insert into prod_inst_his
    select *
      from crmgc2_his.prod_inst_his
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);
*/
  -- prod_inst_attr 表
  insert into qrl_prod_inst_attr
    select *
      from prod_inst_attr
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  delete from prod_inst_attr
   where prod_inst_id in
         (select prod_inst_z_id
            from crmgc2.prod_inst_rel
           where prod_inst_a_id = v_prod_inst_id);

  insert into prod_inst_attr
    select *
      from crmgc2.prod_inst_attr
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  -- prod_inst_attr_his 表
  insert into qrl_prod_inst_attr_his
    select *
      from prod_inst_attr_his
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  delete from prod_inst_attr_his
   where prod_inst_id in
         (select prod_inst_z_id
            from crmgc2.prod_inst_rel
           where prod_inst_a_id = v_prod_inst_id);

  /*insert into prod_inst_attr_his
    select *
      from crmgc2_his.prod_inst_attr_his
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);*/

  -- offer_prod_inst_rel 表
  insert into qrl_offer_prod_inst_rel
    select *
      from offer_prod_inst_rel
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  delete from offer_prod_inst_rel
   where prod_inst_id in
         (select prod_inst_z_id
            from crmgc2.prod_inst_rel
           where prod_inst_a_id = v_prod_inst_id);
  insert into offer_prod_inst_rel
    select *
      from crmgc2.offer_prod_inst_rel
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  -- offer_prod_inst_rel_his 表

  insert into qrl_offer_prod_inst_rel_his
    select *
      from offer_prod_inst_rel_his
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);

  delete from offer_prod_inst_rel_his
   where prod_inst_id in
         (select prod_inst_z_id
            from crmgc2.prod_inst_rel
           where prod_inst_a_id = v_prod_inst_id);

  /*insert into offer_prod_inst_rel_his
    select *
      from crmgc2_his.offer_prod_inst_rel_his
     where prod_inst_id in
           (select prod_inst_z_id
              from crmgc2.prod_inst_rel
             where prod_inst_a_id = v_prod_inst_id);*/

  -- prod_offer_inst 表
  insert into qrl_prod_offer_inst
    select *
      from prod_offer_inst
     where prod_offer_inst_id in
           (select b.prod_offer_inst_id
              from crmgc2.prod_inst_rel a, crmgc2.offer_prod_inst_rel b
             where a.prod_inst_a_id = v_prod_inst_id
               and a.prod_inst_z_id = b.prod_inst_id);

  delete from prod_offer_inst
   where prod_offer_inst_id in
         (select b.prod_offer_inst_id
            from crmgc2.prod_inst_rel a, crmgc2.offer_prod_inst_rel b
           where a.prod_inst_a_id = v_prod_inst_id
             and a.prod_inst_z_id = b.prod_inst_id);

  insert into prod_offer_inst
    select *
      from crmgc2.prod_offer_inst
     where prod_offer_inst_id in
           (select b.prod_offer_inst_id
              from crmgc2.prod_inst_rel a, crmgc2.offer_prod_inst_rel b
             where a.prod_inst_a_id = v_prod_inst_id
               and a.prod_inst_z_id = b.prod_inst_id);

/*  -- prod_offer_inst_his 表
  insert into qrl_prod_offer_inst_his
    select *
      from prod_offer_inst_his
     where prod_offer_inst_id in
           (select b.prod_offer_inst_id
              from crmgc2_his.prod_inst_rel_his       a,
                   crmgc2_his.offer_prod_inst_rel_his b
             where a.prod_inst_a_id = v_prod_inst_id
               and a.prod_inst_z_id = b.prod_inst_id);*/

/*  delete from prod_offer_inst_his
   where prod_offer_inst_id in
         (select b.prod_offer_inst_id
            from crmgc2_his.prod_inst_rel_his       a,
                 crmgc2_his.offer_prod_inst_rel_his b
           where a.prod_inst_a_id = v_prod_inst_id
             and a.prod_inst_z_id = b.prod_inst_id);*/

/*  insert into prod_offer_inst_his
    select *
      from crmgc2_his.prod_offer_inst_his
     where prod_offer_inst_id in
           (select b.prod_offer_inst_id
              from crmgc2_his.prod_inst_rel_his       a,
                   crmgc2_his.offer_prod_inst_rel_his b
             where a.prod_inst_a_id = v_prod_inst_id
               and a.prod_inst_z_id = b.prod_inst_id);*/

  INSERT INTO QRL_PROD_INST_ACCT
    SELECT * FROM PROD_INST_ACCT WHERE PROD_INST_ID = v_prod_inst_id;
  DELETE FROM PROD_INST_ACCT WHERE PROD_INST_ID = v_prod_inst_id;
  INSERT INTO QRL_PROD_INST_ACCT
    SELECT *
      FROM CRMGC2.PROD_INST_ACCT
     WHERE PROD_INST_ID = v_prod_inst_id;

  INSERT INTO QRL_PROD_INST_ACCT_HIS
    SELECT * FROM PROD_INST_ACCT_HIS WHERE PROD_INST_ID = v_prod_inst_id;
  DELETE FROM PROD_INST_ACCT_HIS WHERE PROD_INST_ID = v_prod_inst_id;
/*  INSERT INTO QRL_PROD_INST_ACCT_HIS
    SELECT *
      FROM CRMGC2_HIS.PROD_INST_ACCT_HIS
     WHERE PROD_INST_ID = v_prod_inst_id;*/

end;
/
