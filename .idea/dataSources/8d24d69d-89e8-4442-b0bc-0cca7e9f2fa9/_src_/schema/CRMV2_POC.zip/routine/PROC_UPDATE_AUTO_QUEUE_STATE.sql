CREATE PROCEDURE           proc_update_auto_queue_state IS
  CURSOR c IS
    SELECT *
      FROM o_auto_proc_queue a
     WHERE a.status_cd = '400000'
       AND a.super_queue_id = 0;
  i       NUMBER := 0;
  str_msg VARCHAR2(2000);
  v_cnt   NUMBER := 0;
  isDirectProcBF      number:=0;
  v_statusCd VARCHAR2(6);
BEGIN

  BEGIN
    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '开始更新队列状态', '', SYSDATE);
    COMMIT;
    FOR cur IN c
    LOOP
      BEGIN
      ---zhengcl 20140707  crm00052976 队列属性有obj_type='directProcBF为直接档案处理，状态更改为200097
      v_statusCd:='200098';
      select count(*) into isDirectProcBF from proc_queue_attr p where p.queue_id=cur.queue_id and p.obj_type='directProcBF';
      if isDirectProcBF>0 then
         v_statusCd:='200097';
      end if;
        ----数据插入历史表
        INSERT INTO o_auto_proc_queue_his
          (queue_id, super_queue_id, priority, src_type, src_inst_id, src_action, proc_type, cust_order_id, order_item_id, remark, queue_desc, EXTEND, eff_date, area_id, region_cd, create_staff, create_date, status_cd, status_date, update_staff, update_date, cust_id, his_id)
          (SELECT queue_id, super_queue_id, priority, src_type, src_inst_id, src_action, proc_type, cust_order_id, order_item_id, remark, queue_desc, EXTEND, eff_date, area_id, region_cd, create_staff, create_date, status_cd, status_date, update_staff, update_date, cust_id, crmv2.seq_o_auto_proc_queue_his_id.nextval
             FROM o_auto_proc_queue oa
            WHERE oa.queue_id = cur.queue_id);

        UPDATE o_auto_proc_queue a
           SET a.status_cd    = v_statusCd,
               a.update_date  = SYSDATE,
               a.status_date  = SYSDATE,
               a.update_staff = -1
         WHERE a.queue_id = cur.queue_id;

        i     := i + 1;
        v_cnt := v_cnt + 1;

        IF i > 50
        THEN
          COMMIT;
          i := 0;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          str_msg := substr(SQLERRM, 0, 1000);
          INSERT INTO vip_info_log
            (log_id, msg, err, op_date)
          VALUES
            (seq_vip_info_log_id.nextval, '更新自动队列状态更新异常,队列ID:' ||
              cur.queue_id, str_msg, SYSDATE);
          COMMIT;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval, '更新自动队列状态更新异常', str_msg, SYSDATE);
      COMMIT;
  END;

  BEGIN
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval, '最后提交队列状态失败', str_msg, SYSDATE);
      COMMIT;
  END;

  INSERT INTO vip_info_log
    (log_id, msg, err, op_date)
  VALUES
    (seq_vip_info_log_id.nextval, '共计更新队列状态', to_char(v_cnt), SYSDATE);
  INSERT INTO vip_info_log
    (log_id, msg, err, op_date)
  VALUES
    (seq_vip_info_log_id.nextval, '结束更新队列状态', '', SYSDATE);
  COMMIT;
END proc_update_auto_queue_state;
/
