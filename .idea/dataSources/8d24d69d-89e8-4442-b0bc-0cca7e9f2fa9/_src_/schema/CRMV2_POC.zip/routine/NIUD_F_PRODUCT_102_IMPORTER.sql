CREATE function           niud_f_product_102_importer(i_fea_spec_id in number,
                                                       i_attr_flag   in boolean,
                                                       i_win_flag    in boolean,
                                                       o_msg         out varchar2)
  return number is

  /****
    功能：
        将1.0的程控属性
        导入2.0的功能类产品
    入参：
        i_fea_spec_id - 1.0的程控属性ID（不同产品的同名程控任取一个）
        i_attr_flag - 是否需要在主数据中配置属性及属性值
        i_win_flag - 是否需要配置窗体页面
    出参：
        o_msg - 提示信息
    返回：
        1 - 正常执行
        -1 - 存在重复的页面配置
        -2 - 2.0功能类产品存在重名
        -3 - 1.0规格ID有误
        -4 - 2.0功能类销售品存在重名
        -5 - 显示类型映射表不存在对应的2.0类型

                           by niud, 120510
  ****/

  v_name               product.product_name%type;
  v_code               varchar2(40);
  v_product_z_id       product.product_id%type;
  v_prod_offer_id      prod_offer.prod_offer_id%type;
  v_tmp                number(4);
  v_mdse_spec_id       number(10);
  v_fea_spec_id_attr   number(10);
  v_fea_spec_id        number(10);
  v_remark             varchar2(100) := 'imported via niud_f_product_102_importer';
  v_attr_id            attr_spec.attr_id%type;
  v_attr_value_id      attr_value.attr_value_id%type;
  v_product_attr_id    product_attr.product_attr_id%type;
  v_prod_attr_value_id prod_attr_value.prod_attr_value_id%type;
  v_grid_id            sys_win_componet.componet_id%type;
  v_win_id             sys_window.win_id%type;
  v_component_type     sys_win_componet.componet_type%type;
  v_component_catalog  sys_win_componet.componet_catalog%type;
  v_display_order      number(3);
  v_product_flag       boolean := false;
  v_prod_offer_flag    boolean := false;
  v_service_flag       boolean := false;
  v_attr_flag          boolean := false;
  v_value_flag         boolean := false;
  v_prod_rela_flag     boolean := false;
  v_offer_rela_flag    boolean := false;
  v_win_flag           boolean := false;

  cursor cur_serv is
    select *
      from service_offer
     where service_offer_name in ('新装', '属性变更')
       and sort = 'PROD';

  cursor cur_attr is
    select *
      from prod_fea_spec@lk_crmv1
     where fea_spec_id in (select fea_id_b
                             from prod_fea_spec_rela@lk_crmv1
                            where rela_type = '0'
                              and fea_id_a = i_fea_spec_id);

  cursor cur_value is
    select *
      from prod_fea_spec@lk_crmv1
     where fea_spec_id in
           (select fea_id_b
              from prod_fea_spec_rela@lk_crmv1
             where rela_type = '0'
               and fea_id_a = v_fea_spec_id_attr);

  cursor cur_prod is
    select distinct p.prod_id_2
      from prod_fea_spec@lk_crmv1 fs, mdse_ys_product p
     where fs.prod_spec_id = p.prod_id_1
       and fs.state = '70A'
       and p.state_cd = '在售'
       and fs.name = v_name
       and fs.code = v_code;

  cursor cur_attr_new is
    select *
      from attr_spec
     where attr_id in (select attr_id
                         from product_attr
                        where product_id = v_product_z_id
                          and status_cd = '1000')
       and status_cd = '1000';

begin
  begin
    select name, code
      into v_name, v_code
      from prod_fea_spec@lk_crmv1
     where fea_spec_id = i_fea_spec_id
       and sort = '1';
  exception
    when no_data_found then
      o_msg := '1.0程控属性规格有误！';
      return(-3);
  end;

  select count(*)
    into v_tmp
    from product
   where product_name = v_name
     and product_type = '10' --原子产品
     and prod_func_type = '102' --功能性产品
     and status_cd = '1000';
  if v_tmp > 1 then
    o_msg := '“' || v_name || '”在2.0存在多个同名功能类性产品！';
    return(-2);
  elsif v_tmp = 1 then
    select product_id
      into v_product_z_id
      from product
     where product_name = v_name
       and product_type = '10'
       and prod_func_type = '102'
       and status_cd = '1000';
  else
    select seq_product_id.nextval into v_product_z_id from dual;
    insert into product
    values
      (v_product_z_id,
       null, --产品目录编码先放空
       v_name,
       v_name,
       '11',
       '10',
       '1',
       sysdate,
       null,
       '102',
       null,
       null,
       null,
       null, --system_code先放空
       v_product_z_id,
       '1000',
       sysdate,
       sysdate,
       sysdate,
       1,
       11,
       49822,
       49822,
       null,
       '200',
       null,
       v_remark,
       200);
    v_product_flag := true;
  end if;

  if v_product_flag = true then
    o_msg := '新增功能类产品规格' || to_char(v_product_z_id) || '；';
  else
    o_msg := '已存在功能类产品规格' || to_char(v_product_z_id) || '；';
  end if;

  for rec_prod in cur_prod loop
    select count(*)
      into v_tmp
      from product_relation
     where product_a_id = rec_prod.prod_id_2
       and product_z_id = v_product_z_id
       and relation_type_cd = '100600'; --主从关系
    if v_tmp = 0 then
      insert into product_relation
      values
        (seq_product_rela_id.nextval,
         '100600',
         rec_prod.prod_id_2,
         v_product_z_id,
         0,
         '1000',
         sysdate,
         sysdate,
         sysdate,
         null,
         1,
         null,
         -1,
         -1,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         v_remark,
         null,
         sysdate,
         null);
      v_prod_rela_flag := true;
    end if;
  end loop;
  if v_prod_rela_flag = true then
    o_msg := o_msg || '插入产品主从关系；';
  end if;

  select count(*)
    into v_tmp
    from prod_offer
   where prod_offer_name = v_name
     and offer_type = 10 --基础销售品
     and offer_sub_type = 'T02' --功能类销售品
     and status_cd = '1000';

  if v_tmp > 1 then
    o_msg := '“' || v_name || '”在2.0存在多个同名功能类销售品！';
    return(-4);
  elsif v_tmp = 1 then
    select prod_offer_id
      into v_prod_offer_id
      from prod_offer
     where prod_offer_name = v_name
       and offer_type = 10
       and offer_sub_type = 'T02'
       and status_cd = '1000';
  else
    select seq_prod_offer_id.nextval into v_prod_offer_id from dual;

    begin
      select max(mdse_spec_id)
        into v_mdse_spec_id
        from mdse_spec@lk_crmv1
       where type = '102'
         and fea_spec_id = i_fea_spec_id;
    exception
      when no_data_found then
        v_mdse_spec_id := 0;
    end;
    insert into prod_offer
    values
      (v_prod_offer_id,
       v_name,
       null,
       '1000',
       sysdate,
       null,
       null,
       null, --销售品编码先放空
       null,
       null,
       null,
       null,
       null,
       null,
       null,
       v_remark,
       null,
       sysdate,
       '10',
       sysdate,
       sysdate,
       null,
       null,
       null,
       1,
       null,
       -1,
       -1,
       'T02',
       null,
       null,
       null,
       null,
       'Y',
       v_mdse_spec_id,
       0,
       null,
       '10030',
       null,
       null);
    v_prod_offer_flag := true;
  end if;
  if v_prod_offer_flag = true then
    o_msg := o_msg || '插入功能类销售品；';
  end if;

  select count(*)
    into v_tmp
    from offer_prod_rel
   where product_id = v_product_z_id
     and prod_offer_id = v_prod_offer_id
     and rule_type = '10';
  if v_tmp = 0 then
    insert into offer_prod_rel
    values
      (seq_offer_prod_rel_id.nextval,
       v_product_z_id,
       v_prod_offer_id,
       null,
       null,
       null,
       '10', --可选关系
       '1000',
       sysdate,
       sysdate,
       sysdate,
       null,
       1,
       null,
       -1,
       -1,
       'Y', --默认销售品
       '2',
       null,
       null,
       null,
       null,
       null,
       v_remark,
       null,
       sysdate);
    v_offer_rela_flag := true;
  end if;
  if v_offer_rela_flag = true then
    o_msg := o_msg || '插入销售品产品可选关系；';
  end if;

  v_attr_id := -1;
  if i_attr_flag = true then
    for rec_attr in cur_attr loop
      v_fea_spec_id_attr := rec_attr.fea_spec_id;
      begin
        select a.attr_id, pa.product_attr_id
          into v_attr_id, v_product_attr_id
          from product_attr pa, attr_spec a
         where pa.attr_id = a.attr_id
           and a.attr_name = rec_attr.name
           and pa.product_id = v_product_z_id;
      exception
        when no_data_found then
          select seq_attr_id.nextval into v_attr_id from dual;
          select seq_product_attr_id.nextval
            into v_product_attr_id
            from dual;
          insert into attr_spec
          values
            (v_attr_id,
             rec_attr.code,
             rec_attr.name,
             v_remark,
             'C',
             null,
             null,
             null,
             case rec_attr.unique_value when 'Y' then '1' else '0' end,
             '0',
             '1000',
             sysdate,
             sysdate,
             -4,
             'T1',
             rec_attr.code,
             null,
             'NA',
             null,
             null,
             1,
             0,
             1,
             null,
             -1,
             -1,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             1,
             '1',
             rec_attr.fea_spec_id,
             null);
          insert into product_attr
          values
            (v_product_attr_id,
             v_product_z_id,
             v_attr_id,
             null,
             null,
             '1000',
             sysdate,
             sysdate,
             sysdate,
             1,
             null,
             -1,
             -1,
             null,
             '0',
             v_remark,
             null);
          v_attr_flag := true;

          v_tmp := 0;
          for rec_value in cur_value loop
            begin
              select av.attr_value_id, pav.prod_attr_value_id
                into v_attr_value_id, v_prod_attr_value_id
                from attr_value av, prod_attr_value pav
               where av.attr_value_id = pav.attr_value_id
                 and av.attr_id = v_attr_id
                 and av.attr_value_name = rec_value.name;
            exception
              when no_data_found then
                select seq_attr_value_id.nextval
                  into v_attr_value_id
                  from dual;
                select seq_prod_attr_value_id.nextval
                  into v_prod_attr_value_id
                  from dual;
                insert into attr_value
                values
                  (v_attr_value_id,
                   rec_value.name,
                   v_attr_id,
                   null,
                   null,
                   null,
                   null,
                   rec_value.code,
                   null,
                   null,
                   sysdate,
                   sysdate,
                   '1000',
                   null,
                   null,
                   1,
                   null,
                   -1,
                   -1,
                   v_remark,
                   null);
                insert into prod_attr_value
                values
                  (v_prod_attr_value_id,
                   v_product_attr_id,
                   v_attr_value_id,
                   null,
                   '1000',
                   sysdate,
                   sysdate,
                   sysdate,
                   1,
                   null,
                   -1,
                   -1,
                   null,
                   v_remark);
                v_value_flag := true;
                v_tmp        := 1;
            end;
          end loop;
          if v_tmp = 1 then
            update attr_spec
               set attr_type = 'T3'
             where attr_id = v_attr_id
               and attr_type = 'T1';
          end if;
      end;
    end loop;

    if v_attr_flag = true then
      o_msg := o_msg || '插入主数据；';
    end if;
    if v_value_flag = true then
      o_msg := o_msg || '插入主数据值；';
    end if;
  end if;

  if v_attr_id > -1 then
    /*有下级属性的功能类产品才需要配置产品服务*/
    for rec_serv in cur_serv loop
      select count(*)
        into v_tmp
        from product_service_rel
       where product_id = v_product_z_id
         and service_offer_id = rec_serv.service_offer_id;
      if v_tmp = 0 then
        insert into product_service_rel
        values
          (seq_product_service_rel_id.nextval,
           rec_serv.service_offer_id,
           v_product_z_id,
           '1000',
           sysdate,
           sysdate,
           sysdate,
           1,
           null,
           -1,
           -1,
           null,
           v_remark);
        v_service_flag := true;
      end if;
    end loop;
  end if;

  if v_service_flag = true then
    o_msg := o_msg || '插入产品服务；';
  end if;

  if i_win_flag = true then
    if v_attr_id = -1 then
      o_msg := o_msg || '不需要配置页面。';
    else
      for rec_serv in cur_serv loop
        begin
          select sw.win_id
            into v_win_id
            from sys_class_rel_obj ro, sys_window sw
           where ro.obj_id = sw.win_id
             and ro.event_id = rec_serv.service_offer_id
             and ro.class_id = v_product_z_id;
        exception
          when too_many_rows then
            o_msg := '该功能性产品发现重复的页面配置！';
            return(-1);
          when no_data_found then
            select seq_sys_window_id.nextval into v_win_id from dual;
            insert into sys_window
            values
              (v_win_id,
               to_char(v_product_z_id) || '-' ||
               to_char(rec_serv.service_offer_id) || 'WIN',
               v_name || '-' || rec_serv.service_offer_name,
               null,
               v_remark,
               null,
               null,
               v_product_z_id,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               null,
               null,
               1,
               null,
               -1,
               -1);
            insert into sys_class_rel_obj
            values
              (seq_sys_class_rel_obj_id.nextval,
               v_product_z_id,
               rec_serv.service_offer_id,
               'WIN',
               v_win_id,
               null,
               '1000',
               sysdate,
               sysdate,
               sysdate,
               null,
               1,
               null,
               -1,
               -1);
        end;

        select count(*)
          into v_tmp
          from sys_win_componet
         where win_id = v_win_id;
        if v_tmp = 0 then
          select seq_sys_win_componet_id.nextval into v_grid_id from dual;
          insert into sys_win_componet
          values
            (v_grid_id,
             -1,
             v_win_id,
             null,
             'GRID',
             '表格',
             null,
             v_remark,
             1,
             null,
             null,
             null,
             null,
             0,
             1,
             1,
             1,
             1,
             null,
             '1000',
             sysdate,
             sysdate,
             sysdate,
             'grid',
             null,
             null,
             'LAYOUT',
             1,
             null,
             -1,
             -1,
             null,
             1);
          v_win_flag := true;
        end if;

        v_display_order := 1;
        for rec_attr_new in cur_attr_new loop
          select count(*)
            into v_tmp
            from attr_value av
           where attr_id = rec_attr_new.attr_id
             and exists
           (select 1
                    from prod_attr_value pav, product_attr pa
                   where pav.product_attr_id = pa.product_attr_id
                     and pav.attr_value_id = av.attr_value_id
                     and pa.product_id = v_product_z_id
                     and pav.status_cd = '1000');
          if v_tmp = 0 then
            v_component_catalog := 'INPUT';

            select fea_spec_id
              into v_fea_spec_id
              from prod_fea_spec@lk_crmv1 s
             where exists (select 1
                      from prod_fea_spec_rela@lk_crmv1 r
                     where s.fea_spec_id = r.fea_id_b
                       and r.fea_id_a = i_fea_spec_id
                       and r.rela_type = '0')
               and name = rec_attr_new.attr_name;

            select disp_type
              into v_tmp
              from inter_disp@lk_crmv1 d
             where exists (select 1
                      from inter_fea@lk_crmv1 f
                     where d.fea_spec_id = f.fea_spec_id
                       and f.rela_fea_spec = v_fea_spec_id)
             group by disp_type
            having count(*) = (select max(count(*))
                                 from inter_disp@lk_crmv1 d
                                where exists
                                (select 1
                                         from inter_fea@lk_crmv1 f
                                        where d.fea_spec_id = f.fea_spec_id
                                          and f.rela_fea_spec = v_fea_spec_id)
                                group by disp_type);
            begin
              select type_v2
                into v_component_type
                from niud_t_disp_type_mapping
               where code_v1 = v_tmp;
            exception
              when no_data_found then
                o_msg := 'niud_t_disp_type_mapping找不到对应的显示类型！';
                return(-5);
            end;
          else
            v_component_catalog := 'LAYOUT';
            v_component_type    := 'selectlist';
          end if;

          insert into sys_win_componet
          values
            (seq_sys_win_componet_id.nextval,
             rec_attr_new.attr_id,
             v_win_id,
             v_grid_id,
             rec_attr_new.attr_cd,
             rec_attr_new.attr_name,
             null,
             v_remark,
             1,
             null,
             null,
             null,
             null,
             0,
             v_display_order,
             0,
             1,
             1,
             null,
             '1000',
             sysdate,
             sysdate,
             sysdate,
             v_component_type,
             null,
             null,
             v_component_catalog,
             1,
             null,
             -1,
             -1,
             -4,
             1);
          v_display_order := v_display_order + 1;
        end loop;

      end loop;
    end if;
  end if;
  if v_win_flag = true then
    o_msg := o_msg || '插入页面。';
  end if;

  return(1);
end;
/
