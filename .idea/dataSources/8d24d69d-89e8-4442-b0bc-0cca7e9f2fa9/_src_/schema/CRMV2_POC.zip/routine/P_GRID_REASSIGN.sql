CREATE PROCEDURE           p_grid_reassign(class_id IN VARCHAR2,
                                            obj_inst_id IN VARCHAR2,
                                            op_type IN VARCHAR2,
                                            tag_grid_id IN VARCHAR2,
                                            o_result OUT VARCHAR2) IS
  /*功能说明
  用于人工划配网格关联产品实例，
  将参数保存接口表,自动划配根据网格单元下所有产品实例重新划配
  */
  i NUMBER := 0;
BEGIN
  IF tag_grid_id IS NOT NULL
     AND class_id IS NOT NULL
     AND obj_inst_id IS NOT NULL THEN

    --插入重新划配表，让产品或者客户可以重新自动划配
    INSERT INTO grid_reassign
      (grid_reassign_id, class_id, obj_inst_id,
       grid_id, op_result, event_cd, status_cd,
       create_date, update_date)
      SELECT seq_grid_reassign_id.NEXTVAL,
             class_id, obj_inst_id, tag_grid_id,
             '0', op_type, '10', SYSDATE, SYSDATE
      FROM   dual
    COMMIT;

    o_result := 'TRUE'; --TRUE成功，其余失败

  END IF;
EXCEPTION
  WHEN OTHERS THEN
    o_result := -1;
END;
/
