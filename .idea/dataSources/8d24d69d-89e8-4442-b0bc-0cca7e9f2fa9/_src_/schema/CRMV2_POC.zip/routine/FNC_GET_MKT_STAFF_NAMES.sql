CREATE FUNCTION           FNC_GET_MKT_STAFF_NAMES(IN_TYPE VARCHAR2,IN_ID IN NUMBER)
  RETURN VARCHAR2 IS
  V_RESULT VARCHAR2(1000);
  V_RESULT2 VARCHAR2(1000);
BEGIN
  IF IN_ID IS NULL THEN
    RETURN(NULL);
  END IF;

IF(IN_TYPE='NAMESALL')THEN

   SELECT substr(MAX(sys_connect_by_path(party_name, ',')), 2)  paramcode  INTO V_RESULT
   FROM (SELECT a.*,c.party_name, row_number() over(ORDER BY c.party_name) rn
          FROM jbpm4_participation a,Staff b ,party c WHERE a.task_= IN_ID and b.staff_id=a.userid_ and c.party_id=b.party_id/* and a.userid_!=''*/ )
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;

   SELECT substr(MAX(sys_connect_by_path(party_name, ',')), 2)  paramcode  INTO V_RESULT2
   FROM (SELECT a.*,c.party_name ,row_number() over(ORDER BY c.party_name) rn
          FROM jbpm4_task a,Staff b ,party c WHERE a.dbid_= IN_ID and b.staff_id=a.assignee_ and c.party_id=b.party_id /*and a.assignee_!=''*/)
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;

   RETURN(nvl(V_RESULT,'')||nvl(V_RESULT2,''));

END IF;

IF(IN_TYPE='IDSALL')THEN

   SELECT substr(MAX(sys_connect_by_path(userid_, ',')), 2)  paramcode  INTO V_RESULT
   FROM (SELECT a.*, row_number() over(ORDER BY a.userid_) rn
          FROM jbpm4_participation a WHERE a.dbid_= IN_ID )
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;

   SELECT substr(MAX(sys_connect_by_path(assignee_, ',')), 2)  paramcode  INTO V_RESULT2
   FROM (SELECT a.*,row_number() over(ORDER BY a.assignee_) rn
          FROM jbpm4_task a WHERE a.dbid_= IN_ID )
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;

   RETURN(nvl(V_RESULT,'')||nvl(V_RESULT2,''));

END IF;

IF(IN_TYPE='NAMES')THEN

   SELECT substr(MAX(sys_connect_by_path(party_name, ',')), 2)  paramcode  INTO V_RESULT
   FROM (SELECT a.*,c.party_name, row_number() over(ORDER BY c.party_name) rn
          FROM jbpm4_participation a,Staff b ,party c WHERE a.task_= IN_ID and a.userid_ = b.staff_id and b.party_id=c.party_id )
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;
END IF;

IF(IN_TYPE='NAME')THEN
  SELECT substr(MAX(sys_connect_by_path(party_name, ',')), 2)  paramcode  INTO V_RESULT
   FROM (SELECT a.*, c.party_name, row_number() over(ORDER BY c.party_name) rn
  FROM jbpm4_task a, Staff b, party c
 WHERE decode(a.assignee_,'null',0,'',0,a.assignee_) = b.staff_id and  a.dbid_= IN_ID
   and b.party_id=c.party_id  )
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;
END IF;

IF(IN_TYPE='IDS')THEN
 SELECT substr(MAX(sys_connect_by_path(userid_, ',')), 2)  paramcode  INTO V_RESULT
   FROM (SELECT a.*, row_number() over(ORDER BY a.userid_) rn
          FROM jbpm4_participation a WHERE a.task_= IN_ID )
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;

END IF;

IF(IN_TYPE='ID')THEN
 SELECT substr(MAX(sys_connect_by_path(assignee_, ',')), 2)  paramcode  INTO V_RESULT
   FROM (SELECT a.*,row_number() over(ORDER BY a.assignee_) rn
          FROM jbpm4_task a WHERE a.dbid_= IN_ID )
   START WITH rn = 1 CONNECT BY rn - 1 = PRIOR rn;
END If;

RETURN(V_RESULT);

END FNC_GET_MKT_STAFF_NAMES;
/
