CREATE function           qianty_f_get_value(tn              varchar2,
                                              cn              varchar2,
                                              i_order_item_id varchar2)
  return varchar2 is
  Result  varchar2(4000);
  Result2 varchar2(4000);
  t       varchar2(80);
  v_sql   varchar2(4000);
begin

  select a.new_value
    into Result
    from order_item_proc_attr_his a, fzqianty_obj_attr_desc_1 b
   where a.order_item_id = i_order_item_id
     and a.obj_attr_id = b.obj_attr_id
     and b.to_table = tn
     and b.to_columns = cn
     and rownum < 2;

  select vtype
    into t
    from fzqianty_obj_attr_desc_1
   where to_table = tn
     and to_columns = cn
     and rownum < 2;

  if t = 'sql' then
    select vsql
      into v_sql
      from fzqianty_obj_attr_desc_1
     where to_table = tn
       and to_columns = cn
       and rownum < 2;

    execute immediate v_sql
      into Result2
      using Result;
    return(Result2);

  else
    return(Result);

  end if;
exception
  when NO_DATA_FOUND then
    Result := '';
    return(Result);

end qianty_f_get_value;
/
