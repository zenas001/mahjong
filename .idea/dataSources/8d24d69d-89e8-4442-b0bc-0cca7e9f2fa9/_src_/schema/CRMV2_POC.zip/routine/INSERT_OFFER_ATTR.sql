CREATE procedure           insert_offer_attr(in_offer_id    in number,
                                              in_attr_spec   in number,
                                              in_attr_val    in varchar2,
                                              in_modi_staff  in varchar2,
                                              in_modi_reason in varchar2,
                                              o_result       out varchar2) is
  --功　　能：添加销售品参数
  --创建时间：2012-8-7
  --开山始祖：lud
  --参    数：
  /*
  in_offer_id :销售品实例ID
  in_attr_spec ：属性 规格
  in_attr_val : 属性值
  o_result : 返回结果
  modi_staff :表示修改数据的操作人
  modi_reason: 修改原因
  */

  v_err      varchar2(100);
  v_n1       number(10);
  v_n2       number(10);
  v_n3       number(10);
  v_n4       number(10);
  v_id       number(10);
  v_value_id number(10);
begin
  select count(1)
    into v_n1
    from crmv2.prod_offer_inst a, crmv2.prod_offer_attr c
   where a.prod_offer_inst_id = in_offer_id
     and a.prod_offer_id = c.prod_offer_id
     and c.attr_id = in_attr_spec
     and c.status_cd = '1000';

  if v_n1 = 0 then

    v_err := '套餐规格没有需要添加的这个特性';
    return;
  end if;

  select count(1)
    into v_n2
    from crmv2.attr_value a
   where a.attr_id = in_attr_spec;

  if v_n2 > 0 then

    select count(1)
      into v_n3
      from crmv2.attr_value a
     where a.attr_id = in_attr_spec
       and a.attr_value = in_attr_val;

    if v_n3 = 0 then
      v_err := '属性取值在规格中不存在';
      return;
    end if;

  end if;

  select count(1)
    into v_n4
    from crmv2.prod_offer_inst_attr a
   where a.prod_offer_inst_id = in_offer_id
     and a.attr_id = in_attr_spec;

  if v_n4 > 0 then
    v_err := '属性在实例中已存在';
    return;
  else
    select a.attr_value_id
      into v_value_id
      from crmv2.attr_value a
     where a.attr_id = in_attr_spec
       and a.attr_value = in_attr_val;

    select itsc_crmv2.wh_common_process.qry_seq('prod_offer_inst_attr')
      into v_id
      from dual;
    insert into crmv2.prod_offer_inst_attr
      (PROD_OFFER_INST_ATTR_ID,
       PROD_OFFER_INST_ID,
       ATTR_ID,
       ATTR_VALUE_ID,
       ATTR_VALUE,
       CREATE_DATE,
       EXP_DATE,
       EFF_DATE,
       STATUS_DATE,
       STATUS_CD,
       UPDATE_DATE,
       PROC_SERIAL,
       AREA_ID,
       REGION_CD,
       UPDATE_STAFF,
       CREATE_STAFF,
       REC_UPDATE_DATE,
       VERSION)
      select v_id,
             in_offer_id,
             in_attr_spec,
             v_value_id,
             trim(in_attr_val),
             sysdate,
             exp_date,
             eff_date,
             status_date,
             status_cd,
             sysdate,
             '',
             area_id,
             region_cd,
             '',
             '',
             '',
             '0'
        from crmv2.prod_offer_inst a
       where a.prod_offer_inst_id = in_offer_id;
    itsc_crmv2.new_p_ins_billing_update('prod_offer_inst_attr',
                                        'PROD_OFFER_INST_ATTR_ID',
                                        v_id,
                                        in_modi_reason,
                                        in_modi_staff);

    v_err := '添加成功';
  end if;
exception
  when others then
    v_err    := '其他异常';
    o_result := v_err;
end;
/
