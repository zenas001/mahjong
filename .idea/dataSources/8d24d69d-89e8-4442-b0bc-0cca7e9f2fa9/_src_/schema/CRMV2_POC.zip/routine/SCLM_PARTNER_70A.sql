CREATE PROCEDURE           SCLM_PARTNER_70A(O_CODE OUT VARCHAR2,
                                             O_MSG  OUT VARCHAR2) IS

  /**
  *接口描述：判断激活专员状态过程
  *执行成功返回1，失败返回0
  **/
  --V_ROW_COUNT  NUMBER; --作为分批次提交的判断条件
  V_SEQ_NUMBER NUMBER; --存储历史表序列
  V_OP_TYPE    VARCHAR2(100); --操作类型
  V_OP_STAFF   VARCHAR2(100); --操作工号
  V_OP_REASON  VARCHAR2(300); --操作原因
  PRAGMA AUTONOMOUS_TRANSACTION; --实现自治事务处理
BEGIN
  O_CODE      := '0'; ---出参初始化
  V_OP_TYPE   := 'AUTOMOD';
  V_OP_REASON := '系统自动操作';
  V_OP_STAFF  := '';
  --状态为“冻结”，并且冻结结束时间小于系统当前时间
  FOR REC IN (SELECT *
                FROM SCLM_PARTNER
               WHERE DJ_END_DATE < SYSDATE
                 AND STATUS_CD = '70T') LOOP
    SELECT SEQ_SCLM_PARTNER_HIS.NEXTVAL INTO V_SEQ_NUMBER FROM DUAL;
    INSERT INTO SCLM_PARTNER_HIS
      (SCLM_PARTNER_HIS_ID, SCLM_PARTNER_ID, PARTNER_ID, PARENT_CODE, SCLM_PARTNER_CODE, NICK_NAME, IDENTIFY_CODE, MOBILE_PHONE, STATUS_CD, CREATE_DATE, CREATE_STAFF, STATUS_DATE, STATUS_STAFF, MODIFY_DATE, MODIFY_STAFF, AREA_ID, REGION_ID, BRANCH_ID, REAL_MODIFY_DATE, ROLE, DJ_BEGIN_DATE, DJ_END_DATE, DJ_REASON, CREATE_SOURCE, BRANCH_NAME, OP_DATE, OP_TYPE, OP_STAFF, OP_REASON)
      SELECT V_SEQ_NUMBER,
             REC.SCLM_PARTNER_ID,
             REC.PARTNER_ID,
             REC.PARENT_CODE,
             REC.SCLM_PARTNER_CODE,
             REC.NICK_NAME,
             REC.IDENTIFY_CODE,
             REC.MOBILE_PHONE,
             REC.STATUS_CD,
             REC.CREATE_DATE,
             REC.CREATE_STAFF,
             REC.STATUS_DATE,
             REC.STATUS_STAFF,
             REC.MODIFY_DATE,
             REC.MODIFY_STAFF,
             REC.AREA_ID,
             REC.REGION_ID,
             REC.BRANCH_ID,
             REC.REAL_MODIFY_DATE,
             REC.ROLE,
             REC.DJ_BEGIN_DATE,
             REC.DJ_END_DATE,
             REC.DJ_REASON,
             REC.CREATE_SOURCE,
             REC.BRANCH_NAME,
             SYSDATE,
             V_OP_TYPE,
             V_OP_STAFF,
             V_OP_REASON
        FROM DUAL;
    --激活该推荐员状态，同时冻结时间置空
    UPDATE SCLM_PARTNER
       SET STATUS_CD     = '70A',
           DJ_BEGIN_DATE = NULL,
           DJ_END_DATE   = NULL,
           MODIFY_DATE   = SYSDATE,
           STATUS_DATE   = SYSDATE
     WHERE SCLM_PARTNER_ID = REC.SCLM_PARTNER_ID; --按照主键添加
  END LOOP;
  --COMMIT;
  O_CODE := '1'; ---成功标识返回
  O_MSG  := '成功';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      O_CODE := 0; --失败返回值
      O_MSG  := '处理失败';
      O_MSG  := SQLERRM;
      ROLLBACK;
    END;
END SCLM_PARTNER_70A;
/
