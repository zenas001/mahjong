CREATE function           drop_jbpm_deployment(key_name in string)
  return boolean is
  result boolean;
begin

  --任务执行实例
  --select* from jbpm4_task d ,jbpm4_execution c  where procdefid_ like 'SaleWorkOrderFlow%' and d.execution_ = c.dbid_;
  delete jbpm4_task
   where rowid in (select d.rowid
                     from jbpm4_task d, jbpm4_execution c
                    where procdefid_ like key_name || '%'
                      and d.execution_ = c.dbid_);

  --流程变量实例
  --select * from jbpm4_variable d ,jbpm4_execution c  where procdefid_ like 'SaleWorkOrderFlow%' and d.execution_ = c.dbid_;
  delete jbpm4_variable
   where rowid in (select d.rowid
                     from jbpm4_variable d, jbpm4_execution c
                    where procdefid_ like key_name || '%'
                      and d.execution_ = c.dbid_);

  --流程执行实例
  --select * from jbpm4_execution c  where procdefid_ like 'SaleWorkOrderFlow%';
  delete jbpm4_execution
   where rowid in (select rowid
                     from jbpm4_execution c
                    where procdefid_ like key_name || '%');

  --流程作业
  --select * from jbpm4_job c

  --流程LOB变量
  --select * from jbpm4_lob c, jbpm4_deployprop a, jbpm4_deployment b  where key_='pdkey' and a.deployment_=b.dbid_ and c.deployment_ = a.dbid_;

  --流程定义属性
  --select * from jbpm4_deployprop   where objname_='CustOrderProcess';
  delete jbpm4_deployprop
   where rowid in
         (select rowid from jbpm4_deployprop where objname_ = key_name);

  --流程定义
  --select * from jbpm4_deployprop a, jbpm4_deployment b where key_='pdkey' and a.deployment_=b.dbid_;
  delete jbpm4_deployment
   where rowid in (select b.rowid
                     from jbpm4_deployprop a, jbpm4_deployment b
                    where key_ = 'pdkey'
                      and a.deployment_ = b.dbid_
                      and a.objname_ = key_name);

  return(result);
end drop_jbpm_deployment;
/
