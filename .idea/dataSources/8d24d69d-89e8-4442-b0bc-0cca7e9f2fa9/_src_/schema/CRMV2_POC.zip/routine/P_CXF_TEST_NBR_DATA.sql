CREATE procedure           p_cxf_test_nbr_data is

  cursor cur is
    select a.prod_offer_id,
           a.offer_sub_type,
           a.offer_type,
           a.prod_offer_name,
           10 rn
      from crmv2.prod_offer a;
begin
  for rec in cur loop
    /*接入和组合类销售品*/
    if rec.OFFER_SUB_TYPE IN ('T01', 'T03') then
      begin
        INSERT INTO crmv2.CHENXF_TEMP_IMPORT_NBR
          (prod_offer_id, prod_offer_name, acc_nbr, OFFER_TYPE_NAME)
          SELECT rec.prod_offer_Id, REC.PROD_OFFER_NAME, ACC_NBR, '接入类'
            FROM (SELECT P.ACC_NBR
                    FROM crmv2.PROD_INST           P,
                         crmv2.PROD_OFFER_INST     PI,
                         crmv2.OFFER_PROD_INST_REL OPR
                   WHERE P.PROD_INST_ID = OPR.PROD_INST_ID
                     AND P.PRODUCT_ID IN
                         (SELECT PRODUCT_ID
                            FROM crmv2.PRODUCT
                           WHERE PROD_FUNC_TYPE = '101')
                     AND PI.PROD_OFFER_INST_ID = OPR.PROD_OFFER_INST_ID
                     AND PI.PROD_OFFER_ID = REC.PROD_OFFER_ID)
           WHERE ROWNUM <= rec.rn;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          rollback;
      END;
      /*促销包和可选包*/
    elsif REC.OFFER_TYPE IN ('12', '13') then
      BEGIN
        INSERT INTO crmv2.CHENXF_TEMP_IMPORT_NBR
          (prod_offer_id, prod_offer_name, acc_nbr, OFFER_TYPE_NAME)
          SELECT rec.prod_offer_Id, REC.PROD_OFFER_NAME, ACC_NBR, '可选包'
            FROM (SELECT *
                    FROM (SELECT PROD_INST_ID, ACC_NBR, PRODUCT_ID
                            FROM crmv2.PROD_INST
                           WHERE PRODUCT_ID IN
                                 (SELECT PRODUCT_ID
                                    FROM crmv2.PRODUCT
                                   WHERE PRODUCT_TYPE = '10'
                                     AND PROD_FUNC_TYPE = '101')) P,
                         OFFER_PROD_INST_REL OP
                   WHERE P.PROD_INST_ID = OP.PROD_INST_ID
                     AND OP.PROD_OFFER_INST_ID IN
                         (SELECT POR.RELA_PROD_OFFER_INST_ID
                            FROM crmv2.PROD_OFFER_INST     PI,
                                 crmv2.PROD_OFFER_INST_REL POR
                           WHERE POR.RELATED_PROD_OFFER_INST_ID =
                                 PI.PROD_OFFER_INST_ID
                             AND PI.PROD_OFFER_ID = REC.PROD_OFFER_ID))
           WHERE ROWNUM <= rec.rn;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          rollback;
      END;
      /*功能类销售品*/
    elsif REC.OFFER_SUB_TYPE IN ('T02') then
      BEGIN
        INSERT INTO crmv2.CHENXF_TEMP_IMPORT_NBR
          (PROD_OFFER_ID,
           prod_offer_name,
           PROD_OFFER_T02_NAME,
           acc_nbr,
           OFFER_TYPE_NAME)
          SELECT OFFER_Z_ID,
                 PO1.PROD_OFFER_NAME,
                 PO2.PROD_OFFER_NAME,
                 ACC_NBR,
                 '功能类'
            FROM (SELECT OFFER_A_ID,
                         OFFER_Z_ID,
                         ACC_NBR,
                         RANK() OVER(PARTITION BY OFFER_A_ID, OFFER_Z_ID ORDER BY ACC_NBR) CN
                    FROM CHENXF_OFFER_T02_NBR) A,
                 CRMV2.PROD_OFFER PO1,
                 CRMV2.PROD_OFFER PO2
           WHERE PO2.PROD_OFFER_ID = A.OFFER_Z_ID
             AND PO1.PROD_OFFER_ID = A.OFFER_A_ID
             AND ROWNUM <= rec.rn;
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          rollback;
      END;
      null;
    END if;
  end loop;
end p_cxf_test_nbr_data;
/
