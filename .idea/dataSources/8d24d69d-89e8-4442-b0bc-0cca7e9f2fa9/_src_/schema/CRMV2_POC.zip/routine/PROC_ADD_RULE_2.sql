CREATE procedure           proc_add_rule_2(i_rule_name           varchar2, --规则名称
                                            i_comments            varchar2, --规则备注
                                            i_rule_excecute_class varchar2, --规则执行类
                                            i_rule_excecute_meth  varchar2 --规则执行方法
                                            ) is

  v_rule_id number;
begin
  select seq_rlm_rule_id.nextval into v_rule_id from dual;
  insert into rlm_rule
    (rule_id,
     rule_name,
     comments,
     rule_type,
     manage_level,
     rule_excecute_class,
     rule_excecute_meth,
     cfg_url,
     status_cd,
     status_date,
     create_person,
     create_date,
     update_date,
     area_id,
     region_cd,
     update_staff,
     create_staff,
     bak_data,
     data,
     rule_seq)
  values
    (v_rule_id,
     i_rule_name,
     i_comments,
     'JVA',
     'GRP',
     i_rule_excecute_class,
     i_rule_excecute_meth,
     '',
     '1000',
     sysdate,
     '',
     sysdate,
     sysdate,
     1,
     1,
     49822,
     49822,
     '',
     null,
     null);

  commit;
end proc_add_rule_2;
/
