CREATE procedure           proc_auto_order_except
is
  /**
   功能说明：批量单数据抽取
   author：luxb
   创建时间：2012-7-19
  **/
  cursor i_order  is
  select co.cust_order_id, co.cust_so_number
    from customer_order co
   where co.cust_order_type = '201'
     and co.status_cd = '200098'
     and co.org_id not in (350162,98586,98585)
     and co.proc_priority not in ('100','10');
begin
   --
   for ia in i_order loop
   /*insert into BATCH_ORDER_tmp
   (cust_so_number)
   values
   (ia.cust_so_number);
   update customer_order set status_cd = '200099' where cust_order_id = ia.cust_order_id;
   */
   update customer_order set proc_priority='100'  where cust_order_id = ia.cust_order_id;
   end loop;
   commit;
end;
/
