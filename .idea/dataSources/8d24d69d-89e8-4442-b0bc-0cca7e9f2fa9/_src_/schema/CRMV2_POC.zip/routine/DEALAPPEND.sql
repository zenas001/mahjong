CREATE procedure           dealAppend is
  cursor prod_attr is
    select * from PRODUCT where PROD_FUNC_TYPE = '102';
begin
  for rec in prod_attr loop
    DECLARE
      v_append_count number(12);
      CURSOR PROD_APPEND IS
        SELECT b.fea_spec_id fea_spec_id
          FROM TEMP_HMM_PROD_FEA_SPEC B
         WHERE B.CODE = rec.product_nbr
           and b.name = rec.product_name;
    begin
      SELECT COUNT(*)
        INTO v_append_count
        FROM TEMP_HMM_PROD_FEA_SPEC B
       WHERE B.CODE = rec.product_nbr
         and b.name = rec.product_name;
      IF v_append_count > 0 THEN
        FOR REC1 IN PROD_APPEND LOOP
          --更新数据
          UPDATE TEMP_HMM_PRODUCT_ATTR M
             SET M.PRODUCT_ID = REC.PRODUCT_ID
           WHERE OLD_FEA_SPEC_ID IN
                 (SELECT R.FEA_ID_B
                    FROM TEMP_HMM_PROD_FEA_SPEC_RELA R
                   WHERE R.FEA_ID_A = REC1.fea_spec_id);
                   COMMIT;
        END LOOP;
      END IF;
    end;
  end loop;
end dealAppend;
/
