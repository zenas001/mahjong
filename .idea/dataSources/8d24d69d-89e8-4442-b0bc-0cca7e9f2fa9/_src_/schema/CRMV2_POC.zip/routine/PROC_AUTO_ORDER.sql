CREATE procedure           proc_auto_order
is
  /**
   功能说明：核对互拨免费套餐数据信息
   author：luxb
   创建时间：2012-7-19
  **/
  i_auto_seq varchar2(10);
  cursor i_auto_order  is
  select oa.param1, oa.param2, oa.src_info_id,oa.region_cd,oa.area_id
  from o_auto_order_src_info oa
 where oa.src_type = 'extEffOrder'
   and round(to_number(begin_date - sysdate)) < 15;
begin
   --
   for ia in i_auto_order loop
   select seq_o_auto_proc_queue_id.nextval into i_auto_seq from dual;
   insert into crmv2.o_auto_proc_queue
   (queue_id,
    super_queue_id,
    src_type,
    src_inst_id,
    src_action,
    queue_desc,
    status_cd,
    create_date,
    status_date,
    update_date,
    region_cd,
    area_id)
   values
   (i_auto_seq,
    '0',
    'ProdOfferInst',
    ia.param1,
    '2631341278',
    '互改转正处理',
    '200098',
    sysdate,
    sysdate,
    sysdate,
    ia.region_cd,
    ia.area_id);
   insert into crmv2.proc_queue_attr
   (attr_id,
    queue_id,
    obj_type,
    remark,
    create_date,
    status_cd,
    status_date,
    update_date,
    obj_value,
    region_cd,
    area_id
    )
   values
   (seq_proc_queue_attr_id.nextval,
    i_auto_seq,
    'refinishOiid',
    '互改转正处理',
    sysdate,
    '1299',
    sysdate,
    sysdate,
    ia.param2,
    ia.region_cd,
    ia.area_id);
   insert into o_auto_order_src_info_his
   (his_id,
    src_info_id,
          order_item_id,
          src_type,
          cust_id,
          proc_type,
          param1,
          param2,
          param3,
          param4,
          param5,
          param6,
          remark,
          auto_order_desc,
          extend,
          eff_date,
          area_id,
          region_cd,
          create_staff,
          create_date,
          status_cd,
          status_date,
          update_staff,
          update_date,
          begin_date
   )
   select SEQ_O_AUTO_ORDER_SRC_HIS_ID.nextval,
          src_info_id,
          order_item_id,
          src_type,
          cust_id,
          proc_type,
          param1,
          param2,
          param3,
          param4,
          param5,
          param6,
          remark,
          auto_order_desc,
          extend,
          eff_date,
          area_id,
          region_cd,
          create_staff,
          create_date,
          status_cd,
          status_date,
          update_staff,
          update_date,
          begin_date
    from o_auto_order_src_info where src_info_id =ia.src_info_id;
   delete o_auto_order_src_info where src_info_id = ia.src_info_id;
   end loop;
   commit;
end;
/
