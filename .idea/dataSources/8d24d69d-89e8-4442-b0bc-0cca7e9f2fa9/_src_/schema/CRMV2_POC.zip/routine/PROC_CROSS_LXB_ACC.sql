CREATE procedure           proc_cross_lxb_acc is
  i_prod_inst_a_id number;
  i_count          number;
  cursor i_q is
    select prod_inst_id from lxb_pl_21q t where prod_inst_id <> 3000984055;
  /**
   功能说明：修改程控的acc_prod_inst_id
   author：luxb
   创建时间：2012-5-23
  **/
begin
  for tt in i_q loop
    declare
      cursor i_a is
        select pi.prod_inst_id
          from crmv2.prod_inst pi
         where pi.acc_prod_inst_id = tt.prod_inst_id;
    begin
      for tm in i_a loop
        select count(*)
          into i_count
          from crmv2.prod_inst_rel r
         where r.prod_inst_z_id = tm.prod_inst_id;

        if i_count <> 0 then
          select r.prod_inst_a_id
            into i_prod_inst_a_id
            from crmv2.prod_inst_rel r
           where r.prod_inst_z_id = tm.prod_inst_id;

          if tt.prod_inst_id <> i_prod_inst_a_id then
            insert into lxb_update_accprodid2
              (prod_inst_id, acc_prod_inst_id, up_prod_inst_id)
            values
              (tm.prod_inst_id, tt.prod_inst_id, i_prod_inst_a_id);
            update prod_inst
               set acc_prod_inst_id = i_prod_inst_a_id
             where prod_inst_id = tm.prod_inst_id;
            commit;
          end if;
        end if;
      end loop;
    end;
  end loop;
end;
/
