CREATE procedure           cloudcard_tj is
begin

  INSERT INTO crmv2.YKKT
    (SALE_ORD_SERIAL, account, create_date, insert_date)
    select CUST_SO_NUMBER, prod_inst_id, create_date, sysdate
      from crmv2.intf_group_log
     where channel_nbr = '600105C053'
       and create_date > TRUNC(sysdate) - 1
       and create_date < TRUNC(sysdate)
       AND RESULT = '1';
  commit;

  --这个是云卡激活的数据
  insert INTO crmv2.YKJH
    (SALE_ORD_SERIAL, account, create_date, insert_date)
    select CUST_SO_NUMBER, prod_inst_id, create_date, sysdate
      from crmv2.intf_group_log
     where channel_nbr = '600105C054'
       and create_date > TRUNC(sysdate) - 1
       and create_date < TRUNC(sysdate)
       AND RESULT = '1';
  commit;

  crmv2.INSERTINTOYKKT_LIX;
  crmv2.INSERTINTOYKJH_LIX;

exception
  when others then
    rollback;
end cloudcard_tj;
/
