CREATE procedure           niud_prod_offer_rel_restr_del(o_msg out number) is
  v_cnt number(10);
  cursor cur is
    select *
      from prod_offer
     where prod_offer_name in
           ('免NP月缴优惠套餐', 'ALL_ZC_30元包50M套餐', '天翼手机报增值包',
            '掌中宽带－88元包月套餐（省内40小', '国际长途押金套餐', '省号百割接免费天翼助理套餐',
            '政企客户手机重点优惠套餐', '免NP一次性缴套餐', 'ALL_ZC_UNI/掌宽捆绑计费测试包',
            '无线宽带T2(3G)年缴套餐', 'T7亲情套餐', '本地总机服务－虚拟网加装组合（09版）',
            'ALL_ZC_掌中宽带98套餐', 'ALL_ZC_掌中宽带258套餐', '集团功能费3元',
            'FTTH割接免宽带连接费套餐', '彩信套餐', '手机上网流量包（20元包300M)',
            '厦门3G流量体验套餐（2000M）', '省内总机服务－虚拟网加装组合（09版）', '天翼超无分时分帐套餐',
            '福州宽带1M提速套餐-e家优惠', '集团功能费1元', '适用测试套餐六，省内上网每小时2',
            '天翼助理当月免费包_09版', '新华专线－掌中宽带省内时长包月41', '无线宽带T2（3G）包月套餐200（2010版）',
            '掌中宽带－新包月套餐228元(包月不', '集团功能费12元', '福彩天翼手机卡存费送费套餐',
            'C网通信助理免费试用套餐', '集团功能费0.01元', '省内总机服务－虚拟网加装组合',
            '手机上网流量包（300元包10G)', 'ALL_ZC_掌中宽带经销渠道128半年套餐', '福州宽带1M提速套餐（收费）',
            '掌中宽带1188元优惠包', '首月免预存套餐', '集团彩铃制作费', 'e家-商务领航宽带当月过渡套餐', '军翼网套餐',
            '初始包预存话费套餐', '手机报-理财时报（包月）免费包', 'ALL_ZC_掌中宽带本地不限时长活动',
            '福州宽带1M提速套餐', '手机上网流量包（200元包5G)', '短信包2', '集团功能费20元',
            '201012流量包100元', '掌中宽带包月120', '无线宽带（一号双卡）包月套餐',
            '无线宽带T2（3G）年缴套餐300（2010版）', '政企信用卡缴费担保租机套餐', '集团功能费7元',
            '掌中宽带联想优惠', '家庭亲情包', '无线宽带年缴套餐', 'e家天翼_20元漫游包',
            '无线宽带T2（3G）年缴10送2套餐100（200909版）', '掌中宽带预付卡B',
            '无线宽带T2（3G）年缴11送1套餐200（200909版）', 'ALL_ZC_掌中宽带经销商营业128套餐',
            '本地总机服务－固话加装包（09版）', 'e9随翼版_家庭亲情包', '掌中宽带688元包半年优惠包',
            'ALL_ZC_80元套餐', '省智能提速套餐', '手机报理财时报当月免费包_09版',
            '掌中宽带－经济套餐48元(20小时内2', 'ALL_ZC_98元套餐', '集团功能费10元',
            '无线宽带T2（3G）包月套餐100（2010版）', '省内总机服务－固话加装包', '短信包1',
            'ALL_ZC_48元套餐', '集团功能费5元', '无线宽带T2（3G）包月套餐300（200909版）',
            '集团功能费25元', '集团功能费0元', '3G手机上网体验包', '集团功能费15元',
            '手机报天翼快讯当月免费包_09版', '掌中宽带经济套餐2：48元，免100M', '省际漫游包',
            '手机报-天翼快讯免费包', '手机上网流量包（100元包2G)', '手机上网流量包（50元包1G)',
            '掌中宽带1180＋208元优惠包', '天翼来电显示免费包', 'ALL_ZC_掌中宽带158套餐',
            '201012流量包5元', '掌宽990＋208元优惠包', '短信包3', '手机上网流量包（30元包500M）',
            '无线宽带T2(3G)包月套餐', 'ALL_ZC_158元预存半年套餐', 'ALL_ZC_40元套餐',
            '本地总机服务－虚拟网加装组合', '无线宽带T2（3G）包月套餐100（省内主推200909版）',
            '翼行天下（GPSONE）', 'ALL_ZC_掌中宽带48套餐', '漫游包', '国内漫游包',
            '无线宽带T2（3G）年缴套餐200（2010版）', '无线宽带半年缴套餐', '201012流量包20元',
            '手机上网流量包（100元包3G)', '新装天翼当月过渡套餐_09版', '手机上网套餐', '电脑医生功能费（包年-套餐）',
            '福州宽带1M提速套餐（收费）-e家优惠', '无线宽带T2（3G）包月套餐300（2010版）', '集团功能费2元',
            '新装套餐生效前当月手机资费', '七彩铃音当月免费包_09版', 'ALL_ZC_10元包10M套餐',
            '洽洽集团30元短信包', 'ALL_ZC_掌中宽带无线ATM', '无线宽带T2（3G）包月套餐50（200909版）',
            '掌中宽带－高级套餐(包月50元,免', '无线宽带T2（3G）包月套餐100（200909版）',
            '掌中宽带－30元行业应用套餐', '无线宽带T2（3G）年缴11送1套餐100（省内主推200909版）',
            '掌中宽带1288元包全年优惠包', '号百调度信息服务返还等额话费', '一卡双芯主副卡关系副卡受理套餐',
            '爱音乐半年缴套餐', '省内总机服务－固话加装包（09版）', 'ALL_ZC_50元包100M套餐',
            '七彩铃音免费体验套餐', 'ALL_ZC_掌中宽带128套餐', '集团功能费4元', '短信大使', 'e家移机不改号优惠',
            '本地总机服务－固话加装包', '福州宽带1M免费提速套餐', '号百信息调度服务', '集团功能费8元',
            '无线宽带T2（3G）年缴套餐100（2010版）', '201012流量包10元', '电脑医生当月免费包_09版',
            'c网通信助理增值版套餐', '集团功能费6元', '201012流量包30元', 'ALL_ZC_158元套餐',
            '无线宽带T2（3G）年缴10送2套餐200（200909版）', '网厅预存优惠套餐', '天翼全国被叫免费升级包（割接）',
            '国际漫游押金套餐', '无线宽带T2（3G）年缴11送1套餐100（200909版）', '手机上网流量日套餐',
            '无线宽带包月套餐', '手机上网流量包（5元包50M）',
            '无线宽带T2（3G）年缴10送2套餐100（省内主推200909版）', '集团功能费40元', '爱音乐年缴套餐',
            '天翼加密通信加装包');
begin
  o_msg := 0;
  for rec in cur loop
    select count(distinct po4.prod_offer_name)
      into v_cnt
      from PROD_OFFER_REL_RESTRICT porr,
           prod_offer_rel          por,
           offer_prod_rel          opr1,
           offer_prod_rel          opr2,
           prod_offer              po1,
           prod_offer              po2,
           product                 p1,
           prod_offer              po3,
           product                 p2,
           prod_offer              po4,
           sys_class               tab1,
           attr_spec               col1,
           attr_value              val1,
           sys_class               tab2,
           attr_spec               col2,
           attr_value              val2,
           sys_class               tab3,
           attr_spec               col3,
           attr_value              val3,
           sys_class               tab4,
           attr_spec               col4,
           attr_value              val4
     where porr.prod_offer_rel_id = por.prod_offer_rela_id
       and porr.offer_prod_rel_id_a = opr1.offer_prod_rela_id
       and porr.offer_prod_rel_id_z = opr2.offer_prod_rela_id
       and por.offer_a_id = po1.prod_offer_id
       and por.offer_z_id = po2.prod_offer_id
       and opr1.product_id = p1.product_id
       and opr1.prod_offer_id = po3.prod_offer_id
       and opr2.product_id = p2.product_id
       and opr2.prod_offer_id = po4.prod_offer_id
       and tab1.class_id = col1.class_id
       and col1.attr_id = val1.attr_id
       and tab1.table_name = 'PROD_OFFER_REL'
       and col1.attr_cd = 'RELATION_TYPE_CD'
       and val1.attr_value = por.relation_type_cd
       and tab2.class_id = col2.class_id
       and col2.attr_id = val2.attr_id
       and tab2.table_name = 'OFFER_PROD_REL'
       and col2.attr_cd = 'RULE_TYPE'
       and val2.attr_value = opr1.rule_type
       and tab3.class_id = col3.class_id
       and col3.attr_id = val3.attr_id
       and tab3.table_name = 'OFFER_PROD_REL'
       and col3.attr_cd = 'RULE_TYPE'
       and val3.attr_value = opr2.rule_type
       and tab4.class_id = col4.class_id
       and col4.attr_id = val4.attr_id
       and tab4.table_name = 'PROD_OFFER_REL_RESTRICT'
       and col4.attr_cd = 'RULE_TYPE'
       and val4.attr_value = porr.rule_type
       and po2.prod_offer_id = rec.prod_offer_id;
    if v_cnt = 1 then
      delete from PROD_OFFER_REL_RESTRICT
       where prod_offer_rel_restrict_id in
             (select porr.prod_offer_rel_restrict_id
                from PROD_OFFER_REL_RESTRICT porr,
                     prod_offer_rel          por,
                     offer_prod_rel          opr1,
                     offer_prod_rel          opr2,
                     prod_offer              po1,
                     prod_offer              po2,
                     product                 p1,
                     prod_offer              po3,
                     product                 p2,
                     prod_offer              po4,
                     sys_class               tab1,
                     attr_spec               col1,
                     attr_value              val1,
                     sys_class               tab2,
                     attr_spec               col2,
                     attr_value              val2,
                     sys_class               tab3,
                     attr_spec               col3,
                     attr_value              val3,
                     sys_class               tab4,
                     attr_spec               col4,
                     attr_value              val4
               where porr.prod_offer_rel_id = por.prod_offer_rela_id
                 and porr.offer_prod_rel_id_a = opr1.offer_prod_rela_id
                 and porr.offer_prod_rel_id_z = opr2.offer_prod_rela_id
                 and por.offer_a_id = po1.prod_offer_id
                 and por.offer_z_id = po2.prod_offer_id
                 and opr1.product_id = p1.product_id
                 and opr1.prod_offer_id = po3.prod_offer_id
                 and opr2.product_id = p2.product_id
                 and opr2.prod_offer_id = po4.prod_offer_id
                 and tab1.class_id = col1.class_id
                 and col1.attr_id = val1.attr_id
                 and tab1.table_name = 'PROD_OFFER_REL'
                 and col1.attr_cd = 'RELATION_TYPE_CD'
                 and val1.attr_value = por.relation_type_cd
                 and tab2.class_id = col2.class_id
                 and col2.attr_id = val2.attr_id
                 and tab2.table_name = 'OFFER_PROD_REL'
                 and col2.attr_cd = 'RULE_TYPE'
                 and val2.attr_value = opr1.rule_type
                 and tab3.class_id = col3.class_id
                 and col3.attr_id = val3.attr_id
                 and tab3.table_name = 'OFFER_PROD_REL'
                 and col3.attr_cd = 'RULE_TYPE'
                 and val3.attr_value = opr2.rule_type
                 and tab4.class_id = col4.class_id
                 and col4.attr_id = val4.attr_id
                 and tab4.table_name = 'PROD_OFFER_REL_RESTRICT'
                 and col4.attr_cd = 'RULE_TYPE'
                 and val4.attr_value = porr.rule_type
                 and po2.prod_offer_id = rec.prod_offer_id);
      o_msg := o_msg + 1;
    end if;
  end loop;
end;
/
