CREATE PROCEDURE           proc_update_acct_vip_info IS

  /*
  功能说明
     用于更新ACCT_VIP_INFO表的记录
     创建人：林志强
     日期：2012-2-23
  */

  CURSOR c IS
    SELECT *
      FROM acct_vip_info@lk_fj_vip
     WHERE acct_course_code = to_char(add_months(SYSDATE, -1), 'YYYYMM');

  i                 NUMBER(10) := 0;
  v_begin_cycle_id3 NUMBER(10);
  v_cnt3            NUMBER(2) DEFAULT 0;
  str_msg           VARCHAR2(1000);
  v_count           NUMBER(20) := 0;
BEGIN
  BEGIN
    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '开始同步ACCT_VIP_INFO', str_msg, SYSDATE);
    COMMIT;
    SELECT MAX(begin_cycle_id)
      INTO v_begin_cycle_id3
      FROM doone_int_status@lk_fj_vip
     WHERE src_table_name = 'ACCT_VIP_INFO'
       AND area_code = '590';
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      BEGIN
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval, '查询开关状态ACCT_VIP_INFO', str_msg, SYSDATE);
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
  END;
  BEGIN
    SELECT COUNT(*)
      INTO v_cnt3
      FROM doone_int_status@lk_fj_vip
     WHERE src_table_name = 'ACCT_VIP_INFO'
       AND begin_cycle_id = v_begin_cycle_id3
       AND flag = 3
       AND area_code = '590';

    IF v_cnt3 > 0 THEN
      UPDATE doone_int_status@lk_fj_vip
         SET flag = '2'
       WHERE src_table_name = 'ACCT_VIP_INFO'
         AND begin_cycle_id = v_begin_cycle_id3
         AND area_code = '590';
      COMMIT;
      SELECT COUNT(*)
        INTO v_count
        FROM acct_vip_info@lk_fj_vip
       WHERE acct_course_code = to_char(add_months(SYSDATE, -1), 'YYYYMM');
      INSERT INTO vip_info_log
        (log_id, msg, err, op_date)
      VALUES
        (seq_vip_info_log_id.nextval, '同步ACCT_VIP_INFO数据量', v_count, SYSDATE);

      FOR rec IN c LOOP
        BEGIN
          i := i + 1;

          INSERT INTO acct_vip_info
          VALUES
            (rec.vip_nbr, rec.acct_course_code, rec.this_cycle_integral, rec.year_eff_integral, rec.cycle_curr_integral, rec.cycle_used_integral, rec.cycle_new_integral, rec.area_id, rec.area_code, rec.etl_date);

          IF i > 1000 THEN
            COMMIT;
            i := 0;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            str_msg := substr(SQLERRM, 0, 1000);
            BEGIN
              INSERT INTO vip_info_log
                (log_id, msg, err, op_date)
              VALUES
                (seq_vip_info_log_id.nextval, '插入数据异常-' || rec.vip_nbr, str_msg, SYSDATE);
              COMMIT;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
        END;
      END LOOP;
      COMMIT;
      UPDATE doone_int_status@lk_fj_vip
         SET flag = '4', crm_end_time = SYSDATE
       WHERE src_table_name = 'ACCT_VIP_INFO'
         AND begin_cycle_id = v_begin_cycle_id3
         AND area_code = '590';
      COMMIT;

    END IF;

    INSERT INTO vip_info_log
      (log_id, msg, err, op_date)
    VALUES
      (seq_vip_info_log_id.nextval, '结束同步ACCT_VIP_INFO', str_msg, SYSDATE);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      str_msg := substr(SQLERRM, 0, 1000);
      BEGIN
        INSERT INTO vip_info_log
          (log_id, msg, err, op_date)
        VALUES
          (seq_vip_info_log_id.nextval, '同步ACCT_VIP_INFO异常', str_msg, SYSDATE);
        COMMIT;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
  END;
END proc_update_acct_vip_info;
/
