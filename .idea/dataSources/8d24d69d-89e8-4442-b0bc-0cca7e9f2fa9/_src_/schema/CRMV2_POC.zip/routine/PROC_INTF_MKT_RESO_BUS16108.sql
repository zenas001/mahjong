CREATE procedure           proc_intf_mkt_reso_BUS16108 as
  v_sql    varchar2(2000);
  g_number integer := 240000;
  i        integer;
  j        integer;
begin
  BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE intf_mkt_reso_BUS16108';
  exception
    when others then
      null;
  END;
  v_sql := 'create table intf_mkt_reso_BUS16108 as
select A.MKT_RESO_KEY, A.MKT_RESO_ID, A.STATE, A.SALESTATE, ''0'' subState,''0'' seq
  from crmv1.MKT_RESOURCE A
 WHERE A.STATE != ''70Z''
   and a.mkt_reso_spec_type in (610004005, 610005325, 610005805, 610006025,
        610006165, 610006166, 610006585)
   AND NOT EXISTS (SELECT 1
          FROM crmv1.MKT_RESO_FEA B
         WHERE B.MKT_RESO_ID = A.MKT_RESO_ID
           AND B.FEA_SPEC_ID = 620116584
           AND B.PARAM1 = ''1'')
 UNION
SELECT A.MKT_RESO_KEY, A.MKT_RESO_ID, A.STATE, A.SALESTATE, ''1'' SUBSTATE,''0'' seq
  FROM CRMV1.MKT_RESOURCE A
 WHERE A.STATE = ''70Z''
   and a.mkt_reso_spec_type in (610004005, 610005325, 610005805, 610006025,
        610006165, 610006166, 610006585)
   and to_char(a.modi_time, ''yyyymm'') = to_char(sysdate - 30, ''yyyymm'')';

  delete intf_mkt_file_log
   where state = '00'
     and intf_type = 'BUS16108';
  commit;
  INSERT INTO intf_mkt_file_log
    (intf_mkt_file_log_id, intf_type, state, seq)
  VALUES
    (seq_intf_mkt_file_log_id.nextval, 'BUS16108', '00', 1);
  COMMIT;
  execute immediate v_sql;
  loop
    select max(seq)
      into j
      from intf_mkt_file_log b
     where intf_type = 'BUS16108';

    execute immediate ' select count(*) from crmv2.INTF_CDMA_ALL a where seq=0 '
      into i;

    if i > g_number then
      execute immediate ' update crmv2.INTF_CDMA_ALL a set seq = ' || j ||
                        ' where seq =0 and rownum < ' || (g_number + 1);
    else
      execute immediate ' update crmv2.INTF_CDMA_ALL set seq = ' || j ||
                        ' where seq =0 ';
    end if;

    commit;
    exit when i <= g_number;

    insert into intf_mkt_file_log
      (intf_mkt_file_log_id, intf_type, state, seq)
      select SEQ_INTF_FTP_CONTROL_ID.NEXTVAL, 'BUS16108', '00', j + 1
        from dual;

    commit;
  end loop;
end;
/
