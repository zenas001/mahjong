CREATE procedure           proc_cross_localarea_log(table_name      in varchar2, --客户编码
                                                           primary_key1    in number, --实例对象ID
                                                           primary_key2    in number, --字段名称
                                                           batch_num       in number,
                                                           cross_remark    in varchar2
                                                           ) is
  /**
   功能说明：crm2.0跨本地网日志记录
   author：luxb
   创建时间：2012-5-22
  **/
begin
  insert into CROSS_LOCALAREA_LOG
    (CROSS_ID, CROSS_DIREC, CROSS_TABLE, CRM1_ID, CRM2_ID, CROSS_DATE, REMARK,batch_id)
  values
    (SEQ_CROSS_LOCALAREA_LOG_ID.Nextval,
     '2T1',--crm2.0同步数据到1.0
     table_name,--
     primary_key1,--
     primary_key2,--
     sysdate,
     cross_remark,
     batch_num);
end;
/
