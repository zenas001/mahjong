CREATE FUNCTION           "GETMD5" (input_string IN VARCHAR2)
    RETURN VARCHAR2
IS
    raw_input                        RAW (128)
                                           := UTL_RAW.cast_to_raw (input_string);
    decrypted_raw                    RAW (2048);
    error_in_input_buffer_length     EXCEPTION;
BEGIN
    DBMS_OBFUSCATION_TOOLKIT.md5 (input => raw_input,
                                  checksum => decrypted_raw
                                 );
    RETURN UPPER (RAWTOHEX (decrypted_raw));
END;
/
