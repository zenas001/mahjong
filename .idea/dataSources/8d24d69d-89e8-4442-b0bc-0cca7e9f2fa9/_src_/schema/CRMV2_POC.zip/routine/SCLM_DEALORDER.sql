CREATE PROCEDURE           SCLM_DEALORDER(I_INFO IN VARCHAR2,
                                           O_CODE OUT VARCHAR2,
                                           O_MSG  OUT VARCHAR2) IS
  /***************************************************************
  *i_type:01为推荐单;02为人工单;03为过户拆机
  *i_value:01时传CRM定单流水号(sclm_tj_order:sale_ord_serial)
           02时传推广专员平台流水号(sclm_tj_order:sclm_tj_order_id)
           03时传手机号码(sclm_tj_order:service_code)
  *i_prod_offer_id:销售品ID
  *i_accept_date:受理日期
  *i_prod_id:
  *i_new_account:
  *o_code:处理成功或失败编码(1-成功，0失败)
  *o_msg:处理结果信息
  ****************************************************************/
  PRAGMA AUTONOMOUS_TRANSACTION; --实现自治事务处理
  I_VALUE            VARCHAR2(30);
  I_TYPE             VARCHAR2(4);
  I_PROD_OFFER_ID    NUMBER(20);
  I_ACCEPT_DATE      DATE;
  I_PROD_ID          NUMBER(20);
  I_NEW_ACCOUNT      VARCHAR2(20);
  I_GHGH             VARCHAR2(20);
  I_ACCOUNT          VARCHAR2(20);
  V_SCLM_PARTNER_ID  NUMBER(12); --推荐专员ID
  V_ID               NUMBER(12); --sclm_prod表ID
  V_SCLM_AREA_ID     VARCHAR2(12);
  V_SCLM_REGION_ID   VARCHAR2(12);
  V_PROD_OFFER_ID    NUMBER(12); --销售品ID
  V_PROD_OFFER_TYPE  VARCHAR2(6); --销售品类型
  V_CREATE_DATE      DATE; --工单推荐日期
  V_STATUS           VARCHAR2(6); --工单状态
  V_CONFIG_DAYS      NUMBER(4); --配置日期
  V_MOBILEPHONE      VARCHAR2(21); --被推荐人手机号
  V_REGION_ID        VARCHAR2(12); --地区
  V_SCLM_TJ_ORDER_ID NUMBER(12); --推荐工单ID
  V_SCLM_PROD_ID     NUMBER(12); --推荐业务ID
  V_SCLM_PROD_NAME   VARCHAR2(100); --推荐业务名称
  V_MSG_CONTENT      VARCHAR2(500); --短信内容
  V_IS_AUTO_FEA      VARCHAR2(1); --是否自动产生特性
  IS_PROD_LEGAL      BOOLEAN;
  IS_DATE_LEGAL      BOOLEAN;
  IS_STATUS_LEGAL    BOOLEAN;
BEGIN
  --解析XML
  SELECT SUBSTR(I_INFO
               ,INSTR(I_INFO, '<value>', 1) + LENGTH('<value>')
               ,INSTR(I_INFO, '</value>') - INSTR(I_INFO, '<value>') - LENGTH('<value>'))
    INTO I_VALUE
    FROM DUAL;
  SELECT SUBSTR(I_INFO
               ,INSTR(I_INFO, '<type>', 1) + LENGTH('<type>')
               ,INSTR(I_INFO, '</type>') - INSTR(I_INFO, '<type>') - LENGTH('<type>'))
    INTO I_TYPE
    FROM DUAL;
  SELECT SUBSTR(I_INFO
               ,INSTR(I_INFO, '<prodOfferId>', 1) + LENGTH('<prodOfferId>')
               ,INSTR(I_INFO, '</prodOfferId>') - INSTR(I_INFO, '<prodOfferId>') - LENGTH('<prodOfferId>'))
    INTO I_PROD_OFFER_ID
    FROM DUAL;
  SELECT TO_DATE(SUBSTR(I_INFO
                       ,INSTR(I_INFO, '<acceptDate>', 1) + LENGTH('<acceptDate>')
                       ,INSTR(I_INFO, '</acceptDate>') - INSTR(I_INFO, '<acceptDate>') - LENGTH('<acceptDate>'))
                ,'YYYY-MM-DD')
    INTO I_ACCEPT_DATE
    FROM DUAL;
  SELECT SUBSTR(I_INFO
               ,INSTR(I_INFO, '<pordId>', 1) + LENGTH('<pordId>')
               ,INSTR(I_INFO, '</pordId>') - INSTR(I_INFO, '<pordId>') - LENGTH('<pordId>'))
    INTO I_PROD_ID
    FROM DUAL;
  SELECT SUBSTR(I_INFO
               ,INSTR(I_INFO, '<newAccount>', 1) + LENGTH('<newAccount>')
               ,INSTR(I_INFO, '</newAccount>') - INSTR(I_INFO, '<newAccount>') - LENGTH('<newAccount>'))
    INTO I_NEW_ACCOUNT
    FROM DUAL;
  SELECT SUBSTR(I_INFO
               ,INSTR(I_INFO, '<ghgh>', 1) + LENGTH('<ghgh>')
               ,INSTR(I_INFO, '</ghgh>') - INSTR(I_INFO, '<ghgh>') - LENGTH('<ghgh>'))
    INTO I_GHGH
    FROM DUAL;
  SELECT SUBSTR(I_INFO
               ,INSTR(I_INFO, '<account>', 1) + LENGTH('<account>')
               ,INSTR(I_INFO, '</account>') - INSTR(I_INFO, '<account>') - LENGTH('<account>'))
    INTO I_ACCOUNT
    FROM DUAL;

  --记录日志
  /*INSERT INTO SCLM_CALL_LOG
    (CALL_ID,
     OBJ_ID,
     MOBILE_PHONE,
     OP_STAFF,
     DUTY_ORGAN,
     CALL_DATE,
     RETURN_DATE,
     OBJ_TYPE,
     CALL_TYPE,
     CALL_RESULT,
     CALL_INTERFACE,
     REMARK,CALL_XML)
  VALUES
    (seq_sclm_call_log.nextval,
     0,
     '',
     '',
     NULL,
     SYSDATE,
     SYSDATE,
     'DEALORDER',
     'SCLM',
     '1',
     'SCLM_DEALORDER',
     '',TO_CHAR(I_INFO));*/


  IF I_TYPE = '01' THEN
    INSERT INTO SCLM_TJ_ORDER_FINISH
      (SCLM_TJ_ORDER_ID,
       SCLM_PARTNER_ID,
       ID,
       SERVICE_CODE,
       CREATE_DATE,
       STATUS,
       SEND_DATE,
       FINISH_DATE,
       STATUS_DATE,
       IS_AUTO,
       AUTO_PROC_DATE,
       AUTO_PROC_TIMES,
       AUTO_PROC_RESULT,
       AUTO_PROC_FAIL_REASON,
       IS_MANUAL,
       MANUAL_ASIGN_DATE,
       MANUAL_RESP_DATE,
       MANUAL_RESP_RESULT,
       MANUAL_RESP_FAIL_REASON,
       AREA_ID,
       REGION_ID,
       SALE_ORD_SERIAL,
       REAL_MODIFY_DATE,
       PROD_ID,
       NEW_ACCOUNT,
       CREATE_SOURCE)
      SELECT SCLM_TJ_ORDER_ID,
             SCLM_PARTNER_ID,
             ID,
             SERVICE_CODE,
             CREATE_DATE,
             '70X',
             SMS_SEND_DATE,
             SYSDATE,
             STATUS_DATE,
             IS_AUTO,
             AUTO_PROC_DATE,
             AUTO_PROC_TIMES,
             AUTO_PROC_RESULT,
             AUTO_PROC_FAIL_REASON,
             IS_MANUAL,
             MANUAL_ASIGN_DATE,
             MANUAL_RESP_DATE,
             MANUAL_RESP_RESULT,
             MANUAL_RESP_FAIL_REASON,
             AREA_ID,
             REGION_ID,
             SALE_ORD_SERIAL,
             SYSDATE,
             I_PROD_ID,
             I_NEW_ACCOUNT,
             CREATE_SOURCE
        FROM SCLM_TJ_ORDER
       WHERE SALE_ORD_SERIAL = I_VALUE;

    --取被推荐人手机号、地区等信息
    SELECT A.SERVICE_CODE, A.REGION_ID, A.SCLM_TJ_ORDER_ID, B.ID, B.NAME, B.IS_AUTO_FEA
      INTO V_MOBILEPHONE, V_REGION_ID, V_SCLM_TJ_ORDER_ID, V_SCLM_PROD_ID, V_SCLM_PROD_NAME, V_IS_AUTO_FEA
      FROM SCLM_TJ_ORDER A, SCLM_PROD B
     WHERE A.SALE_ORD_SERIAL = I_VALUE
           AND A.ID = B.ID;

    --IS_AUTO_FEA=1 发短信将初始密码通知用户
    IF V_IS_AUTO_FEA = '1' THEN

      SELECT C.SMS_CONTENT
        INTO V_MSG_CONTENT
        FROM SCLM_RULE A, SCLM_RULE_REGION B, SCLM_RULE_SMS_CONTENT C, SCLM_RULE_SPEC D
       WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
             AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
             AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
             AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_MMBG'
             AND B.AREA_ID IN (SELECT ID
                                 FROM P_AREA
                               CONNECT BY PRIOR SUPER = ID
                                START WITH ID = V_REGION_ID)
             AND ROWNUM < 2;

      INSERT INTO SCLM_SMS_SEND_LOG
        (SCLM_SMS_SEND_LOG_ID,
         SCLM_TJ_ORDER_ID,
         SCLM_SMS_SERIAL_ID,
         SCLM_SMS_SEND_NUM,
         SCLM_SMS_RECV_NUM,
         SCLM_SMS_CONTENT,
         SCLM_SMS_SEND_DATE,
         SCLM_SMS_IS_LIMIT,
         SCLM_SMS_REAL_SEND_DATE,
         SCLM_SMS_STATUS,
         SCLM_SMS_IS_RESP)
      VALUES
        (SEQ_SCLM_SMS_SEND_LOG.NEXTVAL,
         V_SCLM_TJ_ORDER_ID,
         NULL,
         '',
         V_MOBILEPHONE,
         REPLACE(V_MSG_CONTENT, '[prodName]', V_SCLM_PROD_NAME),
         SYSDATE,
         'Y',
         NULL,
         '0',
         'N');
    END IF;

    --业务推荐成功后增加天翼联盟短信，引导用户由被推荐者成为推广专员
    SELECT C.SMS_CONTENT
      INTO V_MSG_CONTENT
      FROM SCLM_RULE A, SCLM_RULE_REGION B, SCLM_RULE_SMS_CONTENT C, SCLM_RULE_SPEC D
     WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
           AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
           AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
           AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_YDTJ'
           AND B.AREA_ID IN (SELECT ID
                               FROM P_AREA
                             CONNECT BY PRIOR SUPER = ID
                              START WITH ID = V_REGION_ID)
           AND ROWNUM < 2;

    INSERT INTO SCLM_SMS_SEND_LOG
      (SCLM_SMS_SEND_LOG_ID,
       SCLM_TJ_ORDER_ID,
       SCLM_SMS_SERIAL_ID,
       SCLM_SMS_SEND_NUM,
       SCLM_SMS_RECV_NUM,
       SCLM_SMS_CONTENT,
       SCLM_SMS_SEND_DATE,
       SCLM_SMS_IS_LIMIT,
       SCLM_SMS_REAL_SEND_DATE,
       SCLM_SMS_STATUS,
       SCLM_SMS_IS_RESP)
    VALUES
      (SEQ_SCLM_SMS_SEND_LOG.NEXTVAL,
       V_SCLM_TJ_ORDER_ID,
       NULL,
       '',
       V_MOBILEPHONE,
       REPLACE(REPLACE(V_MSG_CONTENT, '[prodCode]', V_SCLM_PROD_ID), '[prodName]', V_SCLM_PROD_NAME),
       SYSDATE,
       'Y',
       NULL,
       '0',
       'N');

    DELETE FROM SCLM_TJ_ORDER
     WHERE SALE_ORD_SERIAL = I_VALUE;

    O_CODE := 1;
    O_MSG  := '处理成功';
  ELSIF I_TYPE = '02' THEN
    IS_PROD_LEGAL   := FALSE;
    IS_DATE_LEGAL   := FALSE;
    IS_STATUS_LEGAL := FALSE;
    --判断销售品是否一致
    BEGIN
      SELECT PROD_OFFER_ID, PROD_OFFER_TYPE
        INTO V_PROD_OFFER_ID, V_PROD_OFFER_TYPE
        FROM SCLM_PROD
       WHERE ID = (SELECT ID
                     FROM SCLM_TJ_ORDER
                    WHERE SCLM_TJ_ORDER_ID = I_VALUE);
      IF I_PROD_OFFER_ID = V_PROD_OFFER_ID THEN
        IS_PROD_LEGAL := TRUE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        IS_PROD_LEGAL := FALSE;
    END;
    --判断工单状态是否70E
    BEGIN
      SELECT STATUS
        INTO V_STATUS
        FROM SCLM_TJ_ORDER
       WHERE SCLM_TJ_ORDER_ID = I_VALUE;
      IF V_STATUS = '70E' THEN
        IS_STATUS_LEGAL := TRUE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        IS_STATUS_LEGAL := FALSE;
    END;
    --判断受理日期是否在工单日期+配置天数内
    BEGIN
      SELECT CREATE_DATE
        INTO V_CREATE_DATE
        FROM SCLM_TJ_ORDER
       WHERE SCLM_TJ_ORDER_ID = I_VALUE;
      SELECT ZBBM
        INTO V_CONFIG_DAYS
        FROM ZB
       WHERE ZBFL = 'SCLM_CONFIG_DAYS';
      IF TO_CHAR((V_CREATE_DATE + V_CONFIG_DAYS), 'yyyy-mm-dd') > TO_CHAR(I_ACCEPT_DATE, 'yyyy-mm-dd') THEN
        IS_DATE_LEGAL := TRUE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        IS_DATE_LEGAL := FALSE;
    END;

    --取被推荐人手机号、地区等信息
    SELECT A.SERVICE_CODE, A.REGION_ID, A.SCLM_TJ_ORDER_ID, B.ID, B.NAME
      INTO V_MOBILEPHONE, V_REGION_ID, V_SCLM_TJ_ORDER_ID, V_SCLM_PROD_ID, V_SCLM_PROD_NAME
      FROM SCLM_TJ_ORDER A, SCLM_PROD B
     WHERE A.SCLM_TJ_ORDER_ID = I_VALUE
           AND A.ID = B.ID;

    IF V_PROD_OFFER_TYPE = '101' THEN
      IF IS_PROD_LEGAL AND IS_DATE_LEGAL AND IS_STATUS_LEGAL THEN
        INSERT INTO SCLM_TJ_ORDER_FINISH
          (SCLM_TJ_ORDER_ID,
           SCLM_PARTNER_ID,
           ID,
           SERVICE_CODE,
           CREATE_DATE,
           STATUS,
           SEND_DATE,
           FINISH_DATE,
           STATUS_DATE,
           IS_AUTO,
           AUTO_PROC_DATE,
           AUTO_PROC_TIMES,
           AUTO_PROC_RESULT,
           AUTO_PROC_FAIL_REASON,
           IS_MANUAL,
           MANUAL_ASIGN_DATE,
           MANUAL_RESP_DATE,
           MANUAL_RESP_RESULT,
           MANUAL_RESP_FAIL_REASON,
           AREA_ID,
           REGION_ID,
           SALE_ORD_SERIAL,
           REAL_MODIFY_DATE,
           PROD_ID,
           NEW_ACCOUNT,
           CREATE_SOURCE)
          SELECT SCLM_TJ_ORDER_ID,
                 SCLM_PARTNER_ID,
                 ID,
                 SERVICE_CODE,
                 CREATE_DATE,
                 '70X',
                 SMS_SEND_DATE,
                 SYSDATE,
                 STATUS_DATE,
                 IS_AUTO,
                 AUTO_PROC_DATE,
                 AUTO_PROC_TIMES,
                 AUTO_PROC_RESULT,
                 AUTO_PROC_FAIL_REASON,
                 IS_MANUAL,
                 MANUAL_ASIGN_DATE,
                 MANUAL_RESP_DATE,
                 MANUAL_RESP_RESULT,
                 MANUAL_RESP_FAIL_REASON,
                 AREA_ID,
                 REGION_ID,
                 SALE_ORD_SERIAL,
                 SYSDATE,
                 I_PROD_ID,
                 I_NEW_ACCOUNT,
                 CREATE_SOURCE
            FROM SCLM_TJ_ORDER
           WHERE SCLM_TJ_ORDER_ID = I_VALUE;

        DELETE FROM SCLM_TJ_ORDER
         WHERE SCLM_TJ_ORDER_ID = I_VALUE;

        --业务推荐成功后增加天翼联盟短信，引导用户由被推荐者成为推广专员
        SELECT C.SMS_CONTENT
          INTO V_MSG_CONTENT
          FROM SCLM_RULE A, SCLM_RULE_REGION B, SCLM_RULE_SMS_CONTENT C, SCLM_RULE_SPEC D
         WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
               AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
               AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
               AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_YDTJ'
               AND B.AREA_ID IN (SELECT ID
                                   FROM P_AREA
                                 CONNECT BY PRIOR SUPER = ID
                                  START WITH ID = V_REGION_ID)
               AND ROWNUM < 2;

        INSERT INTO SCLM_SMS_SEND_LOG
          (SCLM_SMS_SEND_LOG_ID,
           SCLM_TJ_ORDER_ID,
           SCLM_SMS_SERIAL_ID,
           SCLM_SMS_SEND_NUM,
           SCLM_SMS_RECV_NUM,
           SCLM_SMS_CONTENT,
           SCLM_SMS_SEND_DATE,
           SCLM_SMS_IS_LIMIT,
           SCLM_SMS_REAL_SEND_DATE,
           SCLM_SMS_STATUS,
           SCLM_SMS_IS_RESP)
        VALUES
          (SEQ_SCLM_SMS_SEND_LOG.NEXTVAL,
           V_SCLM_TJ_ORDER_ID,
           NULL,
           '',
           V_MOBILEPHONE,
           REPLACE(REPLACE(V_MSG_CONTENT, '[prodCode]', V_SCLM_PROD_ID), '[prodName]', V_SCLM_PROD_NAME),
           SYSDATE,
           'Y',
           NULL,
           '0',
           'N');
        O_CODE := 1;
        O_MSG  := '处理成功';
      ELSE
        O_CODE := 0;
        IF IS_PROD_LEGAL = FALSE THEN
          O_MSG := '销售品不一致';
        ELSIF IS_DATE_LEGAL = FALSE THEN
          O_MSG := '受理日期不在时限内';
        ELSIF IS_STATUS_LEGAL = FALSE THEN
          O_MSG := '工单状态非70E';
        END IF;
        UPDATE SCLM_TJ_ORDER
           SET REMARK = O_MSG, STATUS = '70Y'
         WHERE SCLM_TJ_ORDER_ID = I_VALUE;
      END IF;
    ELSE
      INSERT INTO SCLM_TJ_ORDER_FINISH
        (SCLM_TJ_ORDER_ID,
         SCLM_PARTNER_ID,
         ID,
         SERVICE_CODE,
         CREATE_DATE,
         STATUS,
         SEND_DATE,
         FINISH_DATE,
         STATUS_DATE,
         IS_AUTO,
         AUTO_PROC_DATE,
         AUTO_PROC_TIMES,
         AUTO_PROC_RESULT,
         AUTO_PROC_FAIL_REASON,
         IS_MANUAL,
         MANUAL_ASIGN_DATE,
         MANUAL_RESP_DATE,
         MANUAL_RESP_RESULT,
         MANUAL_RESP_FAIL_REASON,
         AREA_ID,
         REGION_ID,
         SALE_ORD_SERIAL,
         REAL_MODIFY_DATE,
         PROD_ID,
         NEW_ACCOUNT,
         CREATE_SOURCE)
        SELECT SCLM_TJ_ORDER_ID,
               SCLM_PARTNER_ID,
               ID,
               SERVICE_CODE,
               CREATE_DATE,
               '70X',
               SMS_SEND_DATE,
               SYSDATE,
               STATUS_DATE,
               IS_AUTO,
               AUTO_PROC_DATE,
               AUTO_PROC_TIMES,
               AUTO_PROC_RESULT,
               AUTO_PROC_FAIL_REASON,
               IS_MANUAL,
               MANUAL_ASIGN_DATE,
               MANUAL_RESP_DATE,
               MANUAL_RESP_RESULT,
               MANUAL_RESP_FAIL_REASON,
               AREA_ID,
               REGION_ID,
               SALE_ORD_SERIAL,
               SYSDATE,
               I_PROD_ID,
               I_NEW_ACCOUNT,
               CREATE_SOURCE
          FROM SCLM_TJ_ORDER
         WHERE SCLM_TJ_ORDER_ID = I_VALUE;

      DELETE FROM SCLM_TJ_ORDER
       WHERE SCLM_TJ_ORDER_ID = I_VALUE;

      --业务推荐成功后增加天翼联盟短信，引导用户由被推荐者成为推广专员
      SELECT C.SMS_CONTENT
        INTO V_MSG_CONTENT
        FROM SCLM_RULE A, SCLM_RULE_REGION B, SCLM_RULE_SMS_CONTENT C, SCLM_RULE_SPEC D
       WHERE A.SCLM_RULE_ID = B.SCLM_RULE_ID
             AND A.SCLM_RULE_ID = C.SCLM_RULE_ID
             AND A.SCLM_RULE_SPEC_ID = D.SCLM_RULE_SPEC_ID
             AND D.SCLM_RULE_SPEC_CODE = 'SCLM_RULE_YDTJ'
             AND B.AREA_ID IN (SELECT ID
                                 FROM P_AREA
                               CONNECT BY PRIOR SUPER = ID
                                START WITH ID = V_REGION_ID)
             AND ROWNUM < 2;

      INSERT INTO SCLM_SMS_SEND_LOG
        (SCLM_SMS_SEND_LOG_ID,
         SCLM_TJ_ORDER_ID,
         SCLM_SMS_SERIAL_ID,
         SCLM_SMS_SEND_NUM,
         SCLM_SMS_RECV_NUM,
         SCLM_SMS_CONTENT,
         SCLM_SMS_SEND_DATE,
         SCLM_SMS_IS_LIMIT,
         SCLM_SMS_REAL_SEND_DATE,
         SCLM_SMS_STATUS,
         SCLM_SMS_IS_RESP)
      VALUES
        (SEQ_SCLM_SMS_SEND_LOG.NEXTVAL,
         V_SCLM_TJ_ORDER_ID,
         NULL,
         '',
         V_MOBILEPHONE,
         REPLACE(REPLACE(V_MSG_CONTENT, '[prodCode]', V_SCLM_PROD_ID), '[prodName]', V_SCLM_PROD_NAME),
         SYSDATE,
         'Y',
         NULL,
         '0',
         'N');
      O_CODE := 1;
      O_MSG  := '处理成功';
    END IF;

    --如果SCLM_REMOVE_ORDER有互斥记录，移到SCLM_REMOVE_ORDER_FINISH
    INSERT INTO SCLM_REMOVE_ORDER_FINISH T
      (SCLM_REMOVE_ORDER_ID, SCLM_TJ_ORDER_ID, MDSE_ID)
      SELECT SCLM_REMOVE_ORDER_ID, SCLM_TJ_ORDER_ID, MDSE_ID
        FROM SCLM_REMOVE_ORDER
       WHERE SCLM_TJ_ORDER_ID = I_VALUE;

  ELSIF I_TYPE = '04' THEN

    IF I_GHGH IS NULL THEN
      O_CODE := 0;
      O_MSG  := '工号不能为空';
      RETURN;
    END IF;
    IF I_PROD_OFFER_ID IS NULL THEN
      O_CODE := 0;
      O_MSG  := '销售品规格不能为空';
      RETURN;
    END IF;

    BEGIN
      SELECT SCLM_PARTNER_ID, AREA_ID, REGION_ID
        INTO V_SCLM_PARTNER_ID, V_SCLM_AREA_ID, V_SCLM_REGION_ID
        FROM SCLM_PARTNER
       WHERE DEVELOPER = I_GHGH
             AND ROWNUM < 2;
    EXCEPTION
      WHEN OTHERS THEN
        V_SCLM_PARTNER_ID := NULL;
        V_SCLM_AREA_ID    := NULL;
        V_SCLM_REGION_ID  := NULL;
    END;

    BEGIN
      SELECT ID, PROD_OFFER_TYPE
        INTO V_ID, V_PROD_OFFER_TYPE
        FROM SCLM_PROD
       WHERE PROD_OFFER_ID = I_PROD_OFFER_ID
             AND ROWNUM < 2;
    EXCEPTION
      WHEN OTHERS THEN
        V_ID              := NULL;
        V_PROD_OFFER_TYPE := NULL;
    END;

    IF V_PROD_OFFER_TYPE = '101' THEN
      INSERT INTO SCLM_TJ_ORDER_FINISH
        (SCLM_TJ_ORDER_ID,
         SCLM_PARTNER_ID,
         ID,
         SERVICE_CODE,
         CREATE_DATE,
         STATUS,
         SEND_DATE,
         FINISH_DATE,
         STATUS_DATE,
         IS_AUTO,
         AUTO_PROC_DATE,
         AUTO_PROC_TIMES,
         AUTO_PROC_RESULT,
         AUTO_PROC_FAIL_REASON,
         IS_MANUAL,
         MANUAL_ASIGN_DATE,
         MANUAL_RESP_DATE,
         MANUAL_RESP_RESULT,
         MANUAL_RESP_FAIL_REASON,
         AREA_ID,
         REGION_ID,
         SALE_ORD_SERIAL,
         REAL_MODIFY_DATE,
         PROD_ID,
         NEW_ACCOUNT,
         CREATE_SOURCE)
      VALUES
        (SEQ_SCLM_TJ_ORDER.NEXTVAL,
         V_SCLM_PARTNER_ID,
         V_ID,
         I_ACCOUNT,
         SYSDATE,
         '70X',
         SYSDATE,
         SYSDATE,
         SYSDATE,
         '2',
         NULL,
         NULL,
         NULL,
         NULL,
         '1',
         NULL,
         NULL,
         NULL,
         NULL,
         V_SCLM_AREA_ID,
         V_SCLM_REGION_ID,
         I_VALUE,
         SYSDATE,
         I_PROD_ID,
         I_NEW_ACCOUNT,
         '02');
    END IF;
    O_CODE := 1;
    O_MSG  := '处理成功';
  ELSE
    --只需要更新推广专员信息表就可以
    INSERT INTO SCLM_PARTNER_HIS
      (SCLM_PARTNER_HIS_ID,
       SCLM_PARTNER_ID,
       PARTNER_ID,
       PARENT_CODE,
       SCLM_PARTNER_CODE,
       NICK_NAME,
       IDENTIFY_CODE,
       MOBILE_PHONE,
       STATUS_CD,
       CREATE_DATE,
       CREATE_STAFF,
       STATUS_DATE,
       STATUS_STAFF,
       MODIFY_DATE,
       MODIFY_STAFF,
       AREA_ID,
       REGION_ID,
       BRANCH_ID,
       BRANCH_NAME,
       REAL_MODIFY_DATE,
       DJ_BEGIN_DATE,
       DJ_END_DATE,
       ROLE,
       DJ_REASON,
       CREATE_SOURCE,
       OP_DATE,
       OP_TYPE,
       OP_STAFF,
       OP_REASON)
      SELECT SEQ_SCLM_PARTNER_HIS.NEXTVAL,
             SCLM_PARTNER_ID,
             PARTNER_ID,
             PARENT_CODE,
             SCLM_PARTNER_CODE,
             NICK_NAME,
             IDENTIFY_CODE,
             MOBILE_PHONE,
             STATUS_CD,
             CREATE_DATE,
             CREATE_STAFF,
             STATUS_DATE,
             STATUS_STAFF,
             MODIFY_DATE,
             MODIFY_STAFF,
             AREA_ID,
             REGION_ID,
             BRANCH_ID,
             BRANCH_NAME,
             REAL_MODIFY_DATE,
             DJ_BEGIN_DATE,
             DJ_END_DATE,
             ROLE,
             DJ_REASON,
             CREATE_SOURCE,
             SYSDATE OP_DATE,
             'UPDATE' OP_TYPE,
             '' OP_STAFF,
             '用户拆机或是过户' OP_REASON
        FROM SCLM_PARTNER
       WHERE MOBILE_PHONE = I_VALUE;

    UPDATE SCLM_PARTNER
       SET STATUS_CD = '70X', STATUS_DATE = SYSDATE, REAL_MODIFY_DATE = SYSDATE, MODIFY_DATE = SYSDATE
     WHERE MOBILE_PHONE = I_VALUE;

    O_CODE := 1;
    O_MSG  := '处理成功';
  END IF;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    O_CODE := 0; --失败返回值
    O_MSG  := SQLERRM;
    ROLLBACK;

END SCLM_DEALORDER;
/
