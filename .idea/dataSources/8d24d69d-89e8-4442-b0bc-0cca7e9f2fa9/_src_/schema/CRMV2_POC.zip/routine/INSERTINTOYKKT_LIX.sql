CREATE procedure           INSERTINTOYKKT_LIX is

  V_PROD_INST_ID PROD_INST.PROD_INST_ID%type;
  flag           number;
  v_err          varchar2(500);
  ykt_flag       varchar2(12);
begin

  For Rec In (SELECT *
                FROM YKKT
               where prod_inst_id is null
                 and account is not null
                 and create_date > trunc(sysdate) - 1) Loop
    begin
      ykt_flag := 0;
      SELECT C.PROD_INST_ID
        INTO V_PROD_INST_ID
        FROM PROD_INST C
       where c.acc_nbr = rec.account
         AND C.PRODUCT_ID = '800000002';
      flag := 0;
      select count(*)
        into flag
        from prod_inst_attr
       where prod_inst_id = v_prod_inst_id
         and attr_id = '800000280';
      if flag > 0 then
        ykt_flag := '1';
      end if;
      UPDATE YKKT
         SET PROD_INST_ID = V_PROD_INST_ID, ISYKT = ykt_flag
       WHERE SALE_ORD_SERIAL = Rec.SALE_ORD_SERIAL
         and ACCOUNT = rec.account;
      COMMIT;
    exception
      when others then
        v_err := sqlerrm;
        rollback;
    end;
  End Loop;
  commit;
end;
/
