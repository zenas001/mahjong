CREATE procedure           copy_offer_from_it(v_prod_offer_id  in varchar2, v_area_id in varchar2)
as
v_offer_prod_role_id number;

v_attr_code varchar2(50);
v_attr_value varchar2(50);

begin
   -- 销售品基本信息
   insert into ppm_prod_offer (PROD_OFFER_ID,PROD_OFFER_NAME,PROD_OFFER_PUBLISHER,STATUS_CD,EFF_DATE,EXP_DATE,MANAGE_GRADE,OFFER_NBR,OFFER_PROVIDER_ID,BRAND_ID,SERV_BRAND_ID,TEMPLET_ID,DEFAULT_TIME_PERIOD,GROUP_CD,VERSION_CD,KEY_WORD,STATUS_DATE,OFFER_TYPE,CREATE_DATE,UPDATE_DATE,EFFECTIVE_TYPE,EXPIRE_TYPE,MKT_RES_SPEC_ID,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,OFFER_SUB_TYPE,PROD_OFFER_PICTURE,EXP_PROC_METHOD,TRANS_EFF_TYPE,TRANS_EXP_TYPE,INTF_FLAG,EXT_OFFER_NBR,PRICE_PLAN_ID,OFFER_BUSI_TYPE,IBS_OFFER_TYPE,EXT_FLAG1,EXT_FLAG2,OBJECT_SOURCE,PROD_OFFER_DESC,remark) SELECT PROD_OFFER_ID,PROD_OFFER_NAME,PROD_OFFER_PUBLISHER,STATUS_CD,EFF_DATE,EXP_DATE,MANAGE_GRADE,OFFER_NBR,OFFER_PROVIDER_ID,BRAND_ID,SERV_BRAND_ID,TEMPLET_ID,DEFAULT_TIME_PERIOD,GROUP_CD,VERSION_CD,KEY_WORD,STATUS_DATE,OFFER_TYPE,CREATE_DATE,UPDATE_DATE,EFFECTIVE_TYPE,EXPIRE_TYPE,MKT_RES_SPEC_ID,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,OFFER_SUB_TYPE,PROD_OFFER_PICTURE,EXP_PROC_METHOD,TRANS_EFF_TYPE,TRANS_EXP_TYPE,INTF_FLAG,EXT_OFFER_NBR,PRICE_PLAN_ID,OFFER_BUSI_TYPE,IBS_OFFER_TYPE,EXT_FLAG1,EXT_FLAG2,OBJECT_SOURCE,PROD_OFFER_DESC, 'IT数据割接至业务'||sysdate FROM prod_offer p where p.prod_offer_id = v_prod_offer_id;
   -- 更新内部名称
   update ppm_prod_offer p set p.inner_offer_name = to_char(p.create_date,'yyyyMM') || p.prod_offer_name where p.prod_offer_id = v_prod_offer_id;
   -- 更新管理级别
   update ppm_prod_offer p set p.manage_grade = '12'
    where p.prod_offer_id =v_prod_offer_id and( p.manage_grade not IN ('10','11','12','13'  ) or p.manage_grade is null);
   -- 到期处理方式 expProcMethod
   -- 自动续约 0 --> 自动续订 10
   update ppm_prod_offer p set p.exp_proc_method = '10' where p.prod_offer_id = v_prod_offer_id and p.exp_proc_method = '0';
   -- 通知客户 1 --> 再次协议续订 20
   update ppm_prod_offer p set p.exp_proc_method = '20' where p.prod_offer_id = v_prod_offer_id and p.exp_proc_method = '1';
   -- 到期自动拆除	2-->  自动退订 30
   -- 到期对应销售品停机	3-->  自动退订 30
   -- 到期对应销售品拆机	5-->  自动退订 30
   -- 到期对应销售品拆机停	6-->  自动退订 30
   update ppm_prod_offer p set p.exp_proc_method = '30' where p.prod_offer_id = v_prod_offer_id
   and p.exp_proc_method IN ( '2','3','5','6' ) ;
   -- 空值为自动续约
   update ppm_prod_offer p set p.exp_proc_method = '10' where p.prod_offer_id = v_prod_offer_id
   and p.exp_proc_method is null ;

   -- 生效方式（老客户）
   v_attr_code := 'ORDER_EFFECT_METHOD_OLD';
   v_attr_value := '1100'; --次月生效
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 生效方式（新客户）
   v_attr_code := 'ORDER_EFFECT_METHOD_NEW';
   v_attr_value := '1100'; --次月生效
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 订购协议期
   v_attr_code := 'clientTreatyStage';
   v_attr_value := '12'; --12个月
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 客户要求 新老客户都要
   v_attr_code := 'clientRequire';
   v_attr_value := '1'; -- 新客户
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);
   v_attr_value := '2'; -- 老客户
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);
   -- 订购确认方式
   v_attr_code := 'orderConfirmMethod';
   v_attr_value := '1000'; -- 纸质协议
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 续订期限（月）
   v_attr_code := 'dueTmeOfContinueOrder';
   v_attr_value := '12'; -- 12个月
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 续订确认方式
   v_attr_code := 'extendConfirmMethod';
   v_attr_value := '1000'; -- 纸质协议
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 变更生效方式
   v_attr_code := 'changeEffectMethod';
   v_attr_value := '1100'; -- 次月生效
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 变更确认方式
   v_attr_code := 'changeConfirmMethod';
   v_attr_value := '1000'; -- 纸质协议
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 退订生效方式
   v_attr_code := 'fadeEffectMethod';
   v_attr_value := '1100'; -- 次月生效
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 退订方
   v_attr_code := 'fadeParty';
   v_attr_value := '1'; -- 局方
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   v_attr_value := '2'; -- 客户
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);


   -- 受理区域
   v_attr_code := 'channelSubtypeCd';
   v_attr_value := '100100'; -- 自营厅
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 适用付费方式
   v_attr_code := 'suitPaidMethod';
   v_attr_value := '2100'; -- 预付费
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);

   -- 目标客户群
   v_attr_code := 'offerCustGroup';
   v_attr_value := '1100'; -- 公众客户
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);
   v_attr_value := '9900'; -- 其他客户
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);
   v_attr_value := '1000'; -- 政企客户
   create_offer_attr_it(v_prod_offer_id,v_area_id,v_attr_code,v_attr_value);


   -- 销售品目录
   insert into ppm_catalog_item_element SELECT * FROM catalog_item_element t where t.prod_offer_id = v_prod_offer_id and t.status_cd = '1000';
   -- 销售品角色
   insert into ppm_prod_offer_rela_role(ROLE_CD,PARENT_ROLE_CD,ROLE_CODE,ROLE_NUM_MAX,ROLE_NUM_MIN,ROLE_NAME,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,PROC_SERIAL,PROD_OFFER_ID,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,HOT_SPOT_NO,REMARK)  SELECT ROLE_CD,PARENT_ROLE_CD,ROLE_CODE,ROLE_NUM_MAX,ROLE_NUM_MIN,ROLE_NAME,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,PROC_SERIAL,PROD_OFFER_ID,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,HOT_SPOT_NO,REMARK FROM prod_offer_rela_role r where r.prod_offer_id = v_prod_offer_id;
   update ppm_prod_offer_rela_role p set p.role_num_max = 1 where p.role_num_max is null and p.prod_offer_id = v_prod_offer_id;
   update ppm_prod_offer_rela_role p set p.role_num_min = 1 where p.role_num_min is null and p.prod_offer_id = v_prod_offer_id;

   -- 销售品关联关系
   insert into ppm_prod_offer_rel(PROD_OFFER_RELA_ID,OFFER_A_ID,OFFER_Z_ID,ROLE_CD,RELATION_TYPE_CD,EFF_DATE,EXP_DATE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,HOT_SPOT_NO,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,SYNC_CUST,EFFECTIVE_TYPE,DEFAULT_TIME_PERIOD,EXPIRE_TYPE,RULE_TYPE,REMARK)
   SELECT PROD_OFFER_RELA_ID,OFFER_A_ID,OFFER_Z_ID,ROLE_CD,RELATION_TYPE_CD,EFF_DATE,EXP_DATE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,HOT_SPOT_NO,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,SYNC_CUST,EFFECTIVE_TYPE,DEFAULT_TIME_PERIOD,EXPIRE_TYPE,RULE_TYPE,REMARK FROM prod_offer_rel rel
   where( rel.offer_a_id = v_prod_offer_id or rel.offer_z_id = v_prod_offer_id)
   and rel.prod_offer_rela_id not IN (
   SELECT rel2.prod_offer_rela_id FROM ppm_prod_offer_rel rel2
    )
    ;

    -- 替换删除
    delete FROM ppm_prod_offer_rel rel where rel.relation_type_cd = '400000';
    -- 选择依赖，强制依赖转换成依赖
    update ppm_prod_offer_rel rel set rel.relation_type_cd = '100000' where rel.relation_type_cd IN ( '109999','109998' ) ;
    -- 销售品构成
   SELECT SEQ_OFFER_PROD_REL_ROLE_ID.Nextval into v_offer_prod_role_id FROM dual;
   insert into ppm_offer_prod_rel_role (ROLE_CD, PARENT_ROLE_CD, ROLE_NAME, ROLE_NUM_MAX, ROLE_NUM_MIN, STATUS_CD, STATUS_DATE, CREATE_DATE, UPDATE_DATE, ROLE_CODE, PROD_OFFER_ID, AREA_ID, REGION_CD, UPDATE_STAFF, CREATE_STAFF, REMARK, ROLE_DEFAULT_NUM, EXIST_TYPE)
values (v_offer_prod_role_id, null, '基础', 1, 1, '1000', sysdate,sysdate,sysdate, '10000000', v_prod_offer_id, 95, 95, null, null, '', null, '');

   insert into ppm_offer_prod_rel(OFFER_PROD_RELA_ID,PRODUCT_ID,PROD_OFFER_ID,ROLE_CD,MAX_COUNT,MIN_COUNT,RULE_TYPE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,PARENT_RELA_ID,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,IS_DEFAULT,EXIST_TYPE,SYNC_CUST,HOT_SPOT_NO,EFFECTIVE_TYPE,DEFAULT_TIME_PERIOD,EXPIRE_TYPE,REMARK)
   SELECT OFFER_PROD_RELA_ID,PRODUCT_ID,PROD_OFFER_ID,v_offer_prod_role_id,MAX_COUNT,MIN_COUNT,RULE_TYPE,STATUS_CD,STATUS_DATE,CREATE_DATE,UPDATE_DATE,PARENT_RELA_ID,AREA_ID,REGION_CD,UPDATE_STAFF,CREATE_STAFF,IS_DEFAULT,EXIST_TYPE,SYNC_CUST,HOT_SPOT_NO,EFFECTIVE_TYPE,DEFAULT_TIME_PERIOD,EXPIRE_TYPE,REMARK FROM offer_prod_rel rel where rel.prod_offer_id = v_prod_offer_id;

   update ppm_offer_prod_rel p set p.max_count = 1 where p.max_count is null and p.prod_offer_id = v_prod_offer_id;
   update ppm_offer_prod_rel p set p.min_count = 1 where p.min_count is null and p.prod_offer_id = v_prod_offer_id;

   -- 适用区域
   insert into ppm_prod_offer_region(  PROD_OFFER_AREA_ID ,PROD_OFFER_ID,COMMON_REGION_ID,STATUS_CD)  SELECT  PROD_OFFER_REGION ,PROD_OFFER_ID,COMMON_REGION_ID,STATUS_CD FROM prod_offer_region r where r.prod_offer_id = v_prod_offer_id;
   -- 未配置适用区域，则默认配置一个
   insert into ppm_prod_offer_region(  PROD_OFFER_AREA_ID ,PROD_OFFER_ID,COMMON_REGION_ID,STATUS_CD)
   SELECT  seq_prod_offer_region_id.nextval ,v_prod_offer_id,v_area_id,STATUS_CD
  FROM ppm_prod_offer p where p.prod_offer_id not IN ( SELECT r.prod_offer_id FROM ppm_prod_offer_region r where r.prod_offer_id = v_prod_offer_id ) and p.prod_offer_id = v_prod_offer_id ;


  -- 生效失效失效时间
  update ppm_prod_offer p set p.eff_date = p.create_date where p.prod_offer_id = v_prod_offer_id and p.eff_date is null;
  update ppm_prod_offer p set p.exp_date = to_date('21990101','yyyyMMdd')  where p.prod_offer_id = v_prod_offer_id and p.exp_date is null;
  update ppm_prod_offer p set p.default_time_period =  to_number(to_char(p.exp_date,'mm')) -  to_number(to_char(p.eff_date,'mm')) + (to_number(to_char(p.exp_date,'yyyy')) -  to_number(to_char(p.eff_date,'yyyy')))*12
  where p.prod_offer_id = v_prod_offer_id;

end;
/
