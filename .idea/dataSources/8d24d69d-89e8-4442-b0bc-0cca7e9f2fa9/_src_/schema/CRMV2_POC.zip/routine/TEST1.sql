CREATE procedure           test1 is
begin

 null;
exception
  when others then
    rollback;
end test1;
/
