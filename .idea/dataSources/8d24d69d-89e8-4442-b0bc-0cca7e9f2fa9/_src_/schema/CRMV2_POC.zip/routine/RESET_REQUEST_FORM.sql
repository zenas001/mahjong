CREATE procedure           reset_request_form(v_request_form_id in varchar2)
as
v_new_request_form_id number(10);
begin
select seq_request_form_id.nextval into v_new_request_form_id from dual;
update request_form f set f.request_form_id = v_new_request_form_id,f.status_cd = '10' where f.request_form_id = v_request_form_id;
update request_inst r set r.request_form_id = v_new_request_form_id where r.request_form_id = v_request_form_id;
end;
/
